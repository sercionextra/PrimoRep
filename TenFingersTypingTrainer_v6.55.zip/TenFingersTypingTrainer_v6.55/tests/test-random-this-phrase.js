#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const root = path.resolve(__dirname, "..");
const elements = {};
const listeners = {};

function makeElement(id, tagName = "div") {
  return {
    id,
    tagName: tagName.toUpperCase(),
    style: {},
    classList: {
      _classes: new Set(),
      add(c) { this._classes.add(c); },
      remove(c) { this._classes.delete(c); },
      toggle(c, force) {
        if (force === undefined) {
          if (this._classes.has(c)) this._classes.delete(c);
          else this._classes.add(c);
        } else if (force) this._classes.add(c);
        else this._classes.delete(c);
      },
      contains(c) { return this._classes.has(c); },
    },
    checked: false,
    disabled: false,
    value: "",
    innerText: "",
    innerHTML: "",
    textContent: "",
    title: "",
    scrollTop: 0,
    appendChild() {},
    setAttribute() {},
    getAttribute() { return ""; },
    querySelectorAll() { return []; },
    querySelector() { return null; },
    addEventListener(evt, fn) {
      listeners[`${id}:${evt}`] = fn;
    },
    click() {
      if (listeners[`${id}:click`]) listeners[`${id}:click`]({ target: this });
    },
    focus() {},
  };
}

const sandbox = {
  console,
  KEY_MAP: {},
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
    createElement: (tag) => makeElement("anon_" + Math.random(), tag),
    body: { appendChild() {}, classList: { add() {}, remove() {}, toggle() {} }, style: {} },
    documentElement: { style: { setProperty() {} }, classList: { add() {}, remove() {}, toggle() {} } },
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  navigator: {},
  alert() {},
  confirm() { return false; },
  prompt() { return null; },
};

sandbox.window = sandbox;
vm.createContext(sandbox);

function loadScript(relPath) {
  const code = fs.readFileSync(path.join(root, relPath), "utf8");
  vm.runInContext(code, sandbox, { filename: relPath });
}

loadScript("js/domain/helpers.js");
loadScript("js/engines/typing-engine.js");
loadScript("js/app/controller/controller-core.js");
loadScript("js/app/controller/metodi-profili-modali.js");
loadScript("js/app/controller/metodi-toolbar-modalita.js");

const AppController = vm.runInContext("AppController", sandbox);
const TypingEngine = vm.runInContext("TypingEngine", sandbox);

function sortedChars(str) {
  return str.split("").sort().join("");
}

const standardLessons = [
  { name: "Lezione 1", phrases: ["frase standard corso uno"] },
];
const customLessons = [
  { name: "Custom 1", phrases: ["xyz123"] },
];

const profileMgr = {
  profile: { CustomText: "", Campioni: [], Caratteri: [] },
  defaultCustomText: "",
  saveProfile() { return true; },
};
const audio = { setMode() {}, setVolume() {}, playKey() {}, playError() {} };
const phonemeEng = { generate: () => "fomema test sillabe" };

const typingEng = new TypingEngine(standardLessons, profileMgr, audio, phonemeEng);
const ctrl = Object.create(AppController.prototype);
ctrl.standardLessons = standardLessons;
ctrl.customLessons = customLessons;
ctrl.lessons = standardLessons;
ctrl.activeLessonsSource = "standard";
ctrl.typingEng = typingEng;
ctrl.profileMgr = profileMgr;
ctrl.setControlEnabled = (el, enabled) => { if (el) el.disabled = !enabled; };
ctrl.updateFonemiDropdownSummary = () => {};
ctrl.returnFocusToTyping = () => {};
let lastNotice = "";
ctrl.notifyShortcutDisabled = (msg) => { lastNotice = msg; };
ctrl.startExercise = () => {
  typingEng.initSession(false);
};

ctrl.setupToolbar();

// 1. Provenienza da Phrases - Custom (mode 0) -> Random This Phrase (mode 5)
ctrl.setLessonsSource("custom");
typingEng.mode = 0;
ctrl.startExercise();
assert.strictEqual(typingEng.originText, "xyz123");

elements["btnRandomThisPhrase"].click();
assert.strictEqual(typingEng.mode, 5);
assert.strictEqual(sortedChars(typingEng.originText), sortedChars("xyz123"), "Deve rimescolare la frase custom attiva, non le lezioni standard");
assert.strictEqual(
  typingEng.getCurrentExerciseTitle(),
  "Random This Phrase (Custom 1: Custom 1)",
  "Deve conservare il titolo dell'esercizio Custom di origine"
);

// Ri-rimescolamento consecutivo in mode 5 non deve annidare il titolo
elements["btnRandomThisPhrase"].click();
assert.strictEqual(
  typingEng.getCurrentExerciseTitle(),
  "Random This Phrase (Custom 1: Custom 1)",
  "Ri-rimescolamento consecutivo non deve annidare Random This Phrase"
);

// 2. Provenienza da Fonemi (mode 2) -> Random This Phrase (mode 5)
typingEng.mode = 2;
ctrl.updateModeUI();
ctrl.startExercise();
const fonemiText = typingEng.originText;
assert.strictEqual(fonemiText, "fomema test sillabe");

elements["btnRandomThisPhrase"].click();
assert.strictEqual(typingEng.mode, 5);
assert.strictEqual(sortedChars(typingEng.originText), sortedChars(fonemiText), "Deve rimescolare il testo generato dai Fonemi");
assert.strictEqual(
  typingEng.getCurrentExerciseTitle(),
  "Random This Phrase (Fonemi Italiani)",
  "Deve conservare Fonemi Italiani come origine"
);

// 3. Provenienza da Digitazione Libera (mode 4) vuota -> blocco con notifica
typingEng.mode = 4;
ctrl.updateModeUI();
ctrl.startExercise();
typingEng.lastTypedPhrase = "";
assert.strictEqual(elements["btnRandomThisPhrase"].disabled, false, "Pulsante Random This Phrase abilitato in mode 4");
lastNotice = "";
elements["btnRandomThisPhrase"].click();
assert.strictEqual(typingEng.mode, 4, "Senza testo digitato in mode 4 non deve passare a mode 5");
assert.ok(lastNotice.length > 0, "Deve notificare l'utente quando typedText è vuoto");

// 4. Provenienza da Digitazione Libera (mode 4) con testo -> rimescola esattamente typedText
typingEng.typedText = "libera123";
elements["btnRandomThisPhrase"].click();
assert.strictEqual(typingEng.mode, 5);
assert.strictEqual(sortedChars(typingEng.originText), sortedChars("libera123"), "Deve rimescolare esattamente l'ultima frase digitata in Digitazione Libera");
assert.strictEqual(
  typingEng.getCurrentExerciseTitle(),
  "Random This Phrase (Digitazione Libera)",
  "Deve conservare Digitazione Libera come origine"
);

// 5. Completamento esercizio in Digitazione Libera (recordManualTypingSample -> resetTypingSession) -> cambio a mode 5
typingEng.mode = 4;
ctrl.updateModeUI();
ctrl.startExercise();
typingEng.typedText = "frase_salvata_typing";
typingEng.startTime = new Date(Date.now() - 5000);
typingEng.lastKeystrokeTime = new Date();
typingEng.recordManualTypingSample();
assert.strictEqual(typingEng.typedText, "", "recordManualTypingSample deve resettare typedText");
assert.strictEqual(typingEng.lastTypedPhrase, "frase_salvata_typing", "resetTypingSession deve preservare lastTypedPhrase");

typingEng.mode = 5;
ctrl.updateModeUI();
ctrl.startExercise();
assert.strictEqual(
  sortedChars(typingEng.originText),
  sortedChars("frase_salvata_typing"),
  "Dopo completamento Typing (recordManualTypingSample), il passaggio a mode 5 deve rimescolare la frase appena digitata"
);
typingEng.startTime = new Date(Date.now() - 5000);
typingEng.recordCompletedSample();
const lastSample = profileMgr.profile.Campioni[profileMgr.profile.Campioni.length - 1];
assert.strictEqual(lastSample.TipoCampione, 5, "TipoCampione deve restare 5");
assert.strictEqual(
  lastSample.Esercizio,
  "Random This Phrase (Digitazione Libera)",
  "Il campione salvato nelle statistiche deve riportare l'origine Digitazione Libera"
);

console.log("PASS: test-random-this-phrase.js (rimescolamento fedele e tracciamento origine)");
