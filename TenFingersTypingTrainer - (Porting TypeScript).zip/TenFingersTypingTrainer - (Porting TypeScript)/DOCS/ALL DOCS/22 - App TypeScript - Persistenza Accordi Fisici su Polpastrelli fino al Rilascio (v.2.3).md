# 22 - App TypeScript - Persistenza Accordi Fisici su Polpastrelli fino al Rilascio (v.2.3)

## 1. Analisi Tecnica e Obiettivo Architetturale

Nelle release precedenti (v.2.1 e v.2.2), l'animazione in tempo reale della finestra vettoriale "10 Fingers (Mani)" durante la digitazione a mano libera (modalità TYPING libera) o ad esercizio completato impiegava un timer di disattivazione temporale prefissato (180 millisecondi). 

Tale impostazione generava due limitazioni di natura ergonomica e didattica:
1. **Estinzione Prematura del Segnale Visivo**: In caso di prolungata pressione di un tasto o di un accordo (ad esempio trattenendo il tasto `Shift`, `Ctrl` o la barra spaziatrice per più di 180 ms), i polpastrelli e le dita tornavano allo stato di riposo benché l'utente stesse ancora fisicamente premendo i tasti.
2. **Perdita della Relazione d'Accordo (Polyphonic Chords)**: Se l'utente premeva un accordo a due o più mani (ad esempio `Shift` con la mano sinistra e un carattere con la mano destra), il rilascio del carattere spegneva contestualmente anche il modificatore ancora premuto, violando la fedeltà dello stato della tastiera reale.

La **Release 2.3 (v.2.3)** introduce una macchina a stati per la gestione dei tasti e degli accordi fisici (`Physical Key Chord State Machine`), eliminando ogni timer arbitrario e vincolando la persistenza dei tasti 3D e dell'illuminazione dei polpastrelli alla reale durata di pressione fisica: ciascun tasto dell'accordo permane in sovraimpressione fino al rilascio fisico effettivo del corrispondente tasto hardware (`keyup`).

*(Nota redazionale: il documento rispetta il divieto assoluto di formule o delimitatori LaTeX, impiegando notazioni testuali chiare e naturali).*

---

## 2. Struttura del Progetto e File Rilasciati

| File | Percorso Workspace | Percorso Repository Speculare (`SRC` / `DOCS`) | Stato Validazione |
| :--- | :--- | :--- | :--- |
| **Applicazione Principale** | `/workspace/index_(v.2.3).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/index_(v.2.3).html` | **0 Errori DevTools** |
| **Guida Utente e Manuale** | `/workspace/help_(v.2.3).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/help_(v.2.3).html` | Sincronizzato v.2.3 |
| **Asset SVG Mani** | `/workspace/hands_anatomical_model_(v.2.3).svg` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/hands_anatomical_model_(v.2.3).svg` | Allineato v.2.3 |
| **Documentazione Tecnica** | `/workspace/22 - App TypeScript - Persistenza Accordi Fisici su Polpastrelli fino al Rilascio (v.2.3).md` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/DOCS/ALL DOCS/` | Documento di rilascio e verifica architetturale |

---

## 3. Implementazione di Dettaglio

### 3.1 Chord Engine in `VisualRenderer`

In `VisualRenderer`, la tracciatura delle battute fisiche è demandata a una struttura reattiva `activePhysicalKeys` di tipo `Map<string, Array<{ finger: number, label: string }>>`:

```javascript
class VisualRenderer {
  constructor() {
    this.currentTargetKey = null;
    this.currentModifierKey = null;
    this.activePhysicalKeys = new Map(); // keyId -> Array<{ finger: number, label: string }>
  }

  getFingersForPhysicalKey(keyOrChar, eventCode = null, eventLocation = null) {
    let fingers = [];
    if (keyOrChar === " " || eventCode === "Space") {
      fingers = [{ finger: 5, label: "SPAZIO" }];
    } else if (keyOrChar === "Enter" || eventCode === "Enter") {
      fingers = [{ finger: 10, label: "INVIO" }];
    } else if (keyOrChar === "Backspace" || eventCode === "Backspace") {
      fingers = [{ finger: 10, label: "⌫" }];
    } else if (keyOrChar === "Tab" || eventCode === "Tab") {
      fingers = [{ finger: 1, label: "TAB" }];
    } else if (keyOrChar === "Shift") {
      const f = (eventCode === "ShiftRight" || eventLocation === 2) ? 10 : 1;
      fingers = [{ finger: f, label: "SHIFT" }];
    } else if (keyOrChar === "Control") {
      const f = (eventCode === "ControlRight" || eventLocation === 2) ? 10 : 1;
      fingers = [{ finger: f, label: "CTRL" }];
    } else if (keyOrChar === "Alt") {
      const f = (eventCode === "AltRight" || eventLocation === 2) ? 6 : 5;
      fingers = [{ finger: f, label: (f === 6 ? "ALT GR" : "ALT") }];
    } else if (keyOrChar === "AltGraph") {
      fingers = [{ finger: 6, label: "ALT GR" }];
    } else if (keyOrChar === "CapsLock") {
      fingers = [{ finger: 1, label: "CAPS" }];
    } else if (keyOrChar && keyOrChar.length === 1) {
      const chord = resolveTargetChord(keyOrChar);
      if (chord && chord.fingers && chord.fingers.length > 0) {
        fingers = chord.fingers;
      } else {
        const lower = keyOrChar.toLowerCase();
        if (KEY_MAP[lower]) {
          fingers = [{ finger: KEY_MAP[lower].finger, label: keyOrChar.toUpperCase() }];
        }
      }
    } else if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const ch = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[ch]) {
          fingers = [{ finger: KEY_MAP[ch].finger, label: ch.toUpperCase() }];
        }
      } else if (eventCode.startsWith("Digit")) {
        const d = eventCode.slice(5);
        if (KEY_MAP[d]) {
          fingers = [{ finger: KEY_MAP[d].finger, label: d }];
        }
      }
    }
    return fingers;
  }

  setPhysicalKeyDown(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (!keyId) return;

    const fingers = this.getFingersForPhysicalKey(keyOrChar, eventCode, eventLocation);
    if (fingers.length === 0) return;

    this.activePhysicalKeys.set(keyId, fingers);
    this.renderActivePhysicalChord();
  }

  setPhysicalKeyUp(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (keyId) {
      this.activePhysicalKeys.delete(keyId);
    }
    if (keyOrChar && this.activePhysicalKeys.has(keyOrChar)) {
      this.activePhysicalKeys.delete(keyOrChar);
    }

    if (this.activePhysicalKeys.size > 0) {
      this.renderActivePhysicalChord();
    } else {
      this.clearAllPhysicalFingers();
    }
  }

  renderActivePhysicalChord() {
    const activeFingerMap = new Map();

    for (const [, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        activeFingerMap.set(item.finger, item.label);
      }
    }

    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      const rect = document.getElementById(`hand_finger_keycap_rect_${f}`);

      if (activeFingerMap.has(f)) {
        const label = activeFingerMap.get(f);
        if (fingerEl) fingerEl.classList.add("finger-active");
        if (grp) grp.style.display = "inline";
        if (tip) tip.textContent = label;

        if (rect) {
          const textLen = (label || "").length;
          const origCx = parseFloat(rect.getAttribute("data-cx") || "215");
          const origCy = parseFloat(rect.getAttribute("data-cy") || "340");
          if (textLen > 2) {
            const w = Math.max(72, textLen * 15 + 26);
            rect.setAttribute("width", w);
            rect.setAttribute("x", origCx - w / 2);
          } else {
            rect.setAttribute("width", 58);
            rect.setAttribute("x", origCx - 29);
          }
          rect.setAttribute("height", 52);
          rect.setAttribute("y", origCy - 26);
        }
      } else {
        if (fingerEl) fingerEl.classList.remove("finger-active");
        if (grp) grp.style.display = "none";
        if (tip) tip.textContent = "";
      }
    }
  }

  clearAllPhysicalFingers() {
    this.activePhysicalKeys.clear();
    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      if (fingerEl) fingerEl.classList.remove("finger-active");
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }
  }
}
```

### 3.2 Binding negli Eventi di Digitazione (`setupTypingListeners`)

```javascript
// In handleKeyDown:
if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
  this.visual.setPhysicalKeyDown(e.key, e.code, e.location);
}

// In handleKeyUp:
if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
  this.visual.setPhysicalKeyUp(e.key, e.code, e.location);
}

// Su sfuocamento della finestra (window.blur):
window.addEventListener("blur", () => {
  document.querySelectorAll(".key.key-pressed").forEach(el => el.classList.remove("key-pressed"));
  this.visual.clearAllPhysicalFingers();
});
```

---

## 4. Considerazioni di Deployment, Ergonomia e Performance

1. **Assenza di Overhead da Timer**: L'eliminazione dei timer `setTimeout` per la gestione della grafica riduce i cicli di Garbage Collection ed evita race-condition tra eventi `keyup` ravvicinati e callback asincroni pendenti.
2. **Accordi Polifonici Multi-Dito**: L'architettura supporta combinazioni composte arbitrarie (fino a 10 dita contemporanee), gestendo correttamente sia tasti modificatori (`Shift`, `Ctrl`, `Alt`, `AltGr`) sia lettere, cifre e caratteri speciali.
3. **Resilienza alle Perdite di Focus**: L'ascoltatore sull'evento `blur` di `window` impedisce che tasti premuti rimangano permanentemente accesi qualora l'utente cambi finestra o apra la console DevTools durante la digitazione.

---

## 5. Report di Collaudo Automatizzato Headless Chrome (CDP)

I test di regressione eseguiti tramite Chrome DevTools Protocol su `index_(v.2.3).html` hanno certificato:
- **Test Inizializzazione**: Applicazione avviata correttamente con profilo `ALBERTO` e versione v.2.3.
- **Test Accordo in Modalità TYPING Libera**:
  1. Pressione `ShiftLeft`: Dito 1 attivato con label `SHIFT`.
  2. Attesa 250ms (superiore al vecchio limite di 180ms): Dito 1 permane stabilmente attivo (`step2_f1_still_active: true`).
  3. Pressione concomitante di `KeyK`: Dito 1 (`SHIFT`) e Dito 8 (`K`) sono contemporaneamente attivi e persistono insieme (`step4_chord_persists: true`).
  4. Rilascio di `KeyK`: Dito 8 si spegne, Dito 1 continua a mostrare `SHIFT` (`step5_f1_still_held: true`).
  5. Rilascio di `ShiftLeft`: Dito 1 si spegne, completando il ciclo (`step6_f1_released: true`).
- **Test Accordo ad Esercizio Concluso**: Accordo `ControlLeft` + `AltLeft` accende contemporaneamente Dito 1 (`CTRL`) e Dito 5 (`ALT`), persistendo fino al rilascio sequenziale dei due tasti.
- **Test Blur**: Lo sfuocamento della finestra disattiva istantaneamente tutti i tasti fisici registrati.
- **Totale Errori in Console DevTools**: **0**.
