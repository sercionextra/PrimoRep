#!/usr/bin/env node
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const wmCode = fs.readFileSync(path.join(root, "js/ui/window-manager.js"), "utf8");
const interrCtrlCode = fs.readFileSync(path.join(root, "js/app/controller/metodi-interrogazione.js"), "utf8");
const layoutCtrlCode = fs.readFileSync(path.join(root, "js/app/controller/metodi-finestre-layout.js"), "utf8");
const profCtrlCode = fs.readFileSync(path.join(root, "js/app/controller/metodi-profili-modali.js"), "utf8");

// 1. Verifica CSS: position: fixed e niente position: relative su .interrogation-dialog-wide
const interrCssMatch = css.match(/\.interrogation-dialog-wide\s*\{[\s\S]*?\}/);
assert(interrCssMatch, "Blocco CSS .interrogation-dialog-wide mancante");
assert(interrCssMatch[0].includes("position: fixed;"), ".interrogation-dialog-wide deve avere position: fixed");
assert(!interrCssMatch[0].includes("position: relative;"), ".interrogation-dialog-wide non deve avere position: relative");
assert(css.includes(".interrogation-dialog-wide.window-fullscreen"), "Regola .interrogation-dialog-wide.window-fullscreen mancante");
assert(css.includes("#interrogationWindowHeader"), "Regola #interrogationWindowHeader mancante");

// 2. Verifica HTML: header traslabile e pulsanti Ripristina / Ingrandisci
assert(html.includes('id="interrogationWindowHeader"'), "Header #interrogationWindowHeader mancante in index.html");
assert(html.includes('id="btnInterrogationResetLayout"'), "Pulsante #btnInterrogationResetLayout mancante in index.html");
assert(html.includes('id="btnInterrogationMaximize"'), "Pulsante #btnInterrogationMaximize mancante in index.html");
assert(html.includes("(v6.34)") || html.includes("(v6.33)"), "Badge versione (v6.34) mancante in index.html");

// 3. Verifica runtime in VM per drag, resize, maximize/restore, reset e resetAllWindowLayouts
function createMockElement(id) {
  const classes = new Set();
  const listeners = {};
  const el = {
    id,
    style: { left: "100px", top: "80px", width: "1000px", height: "640px", zoom: "" },
    dataset: {},
    innerText: "",
    title: "",
    classList: {
      add: (c) => classes.add(c),
      remove: (c) => classes.delete(c),
      contains: (c) => classes.has(c),
    },
    addEventListener: (ev, fn) => {
      listeners[ev] = listeners[ev] || [];
      listeners[ev].push(fn);
    },
    dispatchEvent: (ev, payload = {}) => {
      (listeners[ev] || []).forEach((fn) => fn(payload));
    },
    querySelectorAll: () => [],
    closest: () => null,
    getBoundingClientRect: () => ({
      left: parseInt(el.style.left, 10) || 100,
      top: parseInt(el.style.top, 10) || 80,
      width: parseInt(el.style.width, 10) || 1000,
      height: parseInt(el.style.height, 10) || 640,
      right: (parseInt(el.style.left, 10) || 100) + (parseInt(el.style.width, 10) || 1000),
      bottom: (parseInt(el.style.top, 10) || 80) + (parseInt(el.style.height, 10) || 640),
    }),
    get offsetWidth() { return parseInt(el.style.width, 10) || 1000; },
    get offsetHeight() { return parseInt(el.style.height, 10) || 640; },
    get offsetLeft() { return parseInt(el.style.left, 10) || 100; },
    get offsetTop() { return parseInt(el.style.top, 10) || 80; },
  };
  return el;
}

const elements = {
  interrogationModal: createMockElement("interrogationModal"),
  interrogationDialog: createMockElement("interrogationDialog"),
  interrogationWindowHeader: createMockElement("interrogationWindowHeader"),
  btnInterrogationMaximize: createMockElement("btnInterrogationMaximize"),
  btnInterrogationResetLayout: createMockElement("btnInterrogationResetLayout"),
  btnOpenInterrogation: createMockElement("btnOpenInterrogation"),
  statsFloatingWindow: createMockElement("statsFloatingWindow"),
  btnStatsMaximize: createMockElement("btnStatsMaximize"),
  customEditorWindow: createMockElement("customEditorWindow"),
};

const winListeners = {};
const sandbox = {
  console,
  Math,
  Number,
  parseInt,
  isNaN,
  AppController: function () {},
  InterrogationUI: function (opts) {
    this.opts = opts;
    this.open = async () => {};
    this.handleResize = () => { this.resizeCount = (this.resizeCount || 0) + 1; };
  },
  InterrogationCatalog: function () {},
  InterrogationRepository: function () {},
  InterrogationSessionManager: function () {},
  window: {
    innerWidth: 1440,
    innerHeight: 900,
    addEventListener: (ev, fn) => {
      winListeners[ev] = winListeners[ev] || [];
      winListeners[ev].push(fn);
    },
    getComputedStyle: () => ({ position: "fixed" }),
  },
  document: {
    body: { style: { overflow: "", zoom: "" } },
    documentElement: { clientWidth: 1440, scrollHeight: 900 },
    getElementById: (id) => elements[id] || null,
    querySelector: () => null,
  },
};
vm.createContext(sandbox);
vm.runInContext(wmCode + "\nthis.WindowManager = WindowManager;", sandbox);
vm.runInContext(layoutCtrlCode, sandbox);
vm.runInContext(profCtrlCode, sandbox);
vm.runInContext(interrCtrlCode, sandbox);

const wm = new sandbox.WindowManager();
let dragCb = null;
let resizeCb = null;
wm.makeDraggable = (el, hdr, cb) => { dragCb = cb; };
wm.makeResizable = (el, cb) => { resizeCb = cb; };

const ctrl = new sandbox.AppController();
ctrl.windowMgr = wm;
let savedCount = 0;
ctrl.profileMgr = {
  currentUser: "tester",
  profile: {},
  getCurrentProfile: () => ctrl.profileMgr.profile,
  saveProfile: () => { savedCount += 1; },
  save: () => { savedCount += 1; },
};
ctrl.returnFocusToTyping = () => {};
ctrl.resetHandsDefaultPosition = () => {};
ctrl.resetInstantSpeedDefaultPosition = () => {};
ctrl.applyZoom = () => {};
let lastAlert = "";
ctrl.showAppAlert = (msg) => { lastAlert = msg; };

ctrl.setupInterrogationControls();

// Test drag & resize callback persistence
assert(typeof dragCb === "function", "makeDraggable deve essere collegato a #interrogationWindowHeader");
assert(typeof resizeCb === "function", "makeResizable deve essere collegato a #interrogationDialog");
dragCb(150, 95);
assert.strictEqual(ctrl.profileMgr.profile.InterrLeft, 150);
assert.strictEqual(ctrl.profileMgr.profile.InterrTop, 95);

elements.interrogationDialog.style.left = "150px";
elements.interrogationDialog.style.top = "95px";
elements.interrogationDialog.style.width = "1100px";
elements.interrogationDialog.style.height = "680px";
resizeCb(1100, 680);
assert.strictEqual(ctrl.profileMgr.profile.InterrWidth, 1100);
assert.strictEqual(ctrl.profileMgr.profile.InterrHeight, 680);

// Test Maximize / Restore
elements.btnInterrogationMaximize.dispatchEvent("click");
assert(elements.interrogationDialog.classList.contains("window-fullscreen"), "Primo click su Ingrandisci deve attivare window-fullscreen");
assert.strictEqual(elements.btnInterrogationMaximize.innerText, "🗗 Riduci");
assert.strictEqual(sandbox.document.body.style.overflow, "hidden");

elements.btnInterrogationMaximize.dispatchEvent("click");
assert(!elements.interrogationDialog.classList.contains("window-fullscreen"), "Secondo click su Riduci deve disattivare window-fullscreen");
assert.strictEqual(elements.btnInterrogationMaximize.innerText, "⛶ Ingrandisci");
assert.strictEqual(sandbox.document.body.style.overflow, "");
assert.strictEqual(elements.interrogationDialog.style.width, "1100px");

// Test Reset Layout button
elements.interrogationDialog.style.left = "10px";
elements.interrogationDialog.style.top = "200px";
elements.btnInterrogationResetLayout.dispatchEvent("click");
assert.strictEqual(elements.interrogationDialog.style.width, "1280px");
assert.strictEqual(elements.interrogationDialog.style.height, "760px");
assert.strictEqual(elements.interrogationDialog.style.left, "80px");
assert.strictEqual(elements.interrogationDialog.style.top, "70px");

// Test resetAllWindowLayouts (Gestione Utenti -> Reset finestre)
elements.interrogationDialog.style.left = "33px";
elements.interrogationDialog.style.width = "700px";
ctrl.resetAllWindowLayouts();
assert.strictEqual(elements.interrogationDialog.style.width, "1280px");
assert.strictEqual(elements.interrogationDialog.style.left, "80px");
assert(lastAlert.includes("Interrogazione"), "Il messaggio di Reset finestre deve menzionare Interrogazione");

console.log("PASS: test-interrogation-v633 verificato con successo.");
