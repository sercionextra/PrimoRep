# TenFingersTypingTrainer – Schema IndexedDB INTERROGAZIONE

**Documento:** Schema_IndexedDB_Interrogazione_v1.1  
**Baseline:** TenFingersTypingTrainer v6.23  
**Contratto di riferimento:** Contratti_Backend_Interrogazione_v1.1  
**Riferimenti funzionali:** HANDOFF TECNICO INTERROGAZIONE v1.0, SPECIFICA TECNICA INTERROGAZIONE v1.0 e Decisione_Quote_Adattive_D77-D80_v1.1  
**Stato:** progettazione esecutiva della persistenza; nessuna modifica ai sorgenti  
**Destinazione:** `/workspace/Schema_IndexedDB_Interrogazione_v1.1.md`

---

## 1. Scopo e decisioni architetturali

Questo documento traduce i contratti di dominio in uno schema IndexedDB implementabile. Definisce object store, chiavi, indici, vincoli, confini transazionali, concorrenza, migrazioni e prove di accettazione della persistenza.

Decisioni:

- Database dedicato: `TenFingersTypingTrainer_Interrogation`.
- Versione iniziale dello schema: `1`.
- IndexedDB è la fonte persistente per catalogo Interrogazione, sessioni, eventi di conoscenza, correzioni, audit e proiezioni statistiche.
- LocalStorage continua a essere gestito dal `ProfileManager` esistente per i dati già presenti. Non si tenta di creare una transazione distribuita tra LocalStorage e IndexedDB.
- I dati di conoscenza sono sempre isolati per `profileId`; il catalogo e il relativo audit sono condivisi.
- Eventi, correzioni e audit sono append-only attraverso le normali API applicative.
- Le proiezioni `knowledgeStates` sono ricostruibili e non costituiscono lo storico primario.
- Le sessioni conservano snapshot sufficienti a riprendere senza dipendere dalla versione corrente del catalogo.
- Le operazioni persistenti espongono un `operationId` idempotente.
- Nessuna dipendenza server-side, libreria esterna o migrazione a ES modules è richiesta.
- Le sessioni nuove congelano `adaptiveQuotaAlgorithmVersion: "1.1"`, budget globale 10 punti percentuali e tetto individuale 20% della quota base normalizzata. La definizione completa del riparto è in `Decisione_Quote_Adattive_D77-D80_v1.1`.
- Le sessioni già avviate o sospese conservano i parametri e la versione dell'algoritmo presenti nel proprio snapshot; un aggiornamento dell'algoritmo non modifica sessioni esistenti.

## 2. Convenzioni dei record

### 2.1 Tipi e campi comuni

- Gli identificativi sono stringhe UUID generate dall'applicazione con prefissi leggibili solo dove utile (`event_`, `session_`, `audit_`). Il prefisso non è parte della semantica.
- Le date sono memorizzate come timestamp numerici Unix in millisecondi. La UI può convertirle in stringhe ISO 8601.
- I booleani sono booleani nativi.
- I valori enumerati sono stringhe validate dal dominio prima della scrittura.
- Le chiavi composte usano array di valori primitivi supportati da IndexedDB.
- Ogni record modificabile porta `revision`, intero incrementale a partire da 1.
- Ogni record che rappresenta una modifica logica porta `createdAt` e, quando modificabile, `updatedAt`.
- I record append-only non hanno `updatedAt`: un'eventuale rettifica è un nuovo record.

### 2.2 Identificativi e versioni

`semanticId` e `questionSemanticId` sono identità didattiche stabili, non chiavi tecniche di versione. Le definizioni versionate sono identificate dalla coppia semantic ID + contentVersion. Le sostituzioni collegano identità distinte senza trasferire conoscenza.

`catalogVersion` identifica una fotografia coerente del catalogo e delle relazioni. Una sessione usa una sola versione di catalogo, salvata nel proprio snapshot.

### 2.3 Isolamento per profilo

Ogni record relativo a sessioni, configurazioni, eventi, correzioni, conoscenza e ricevute operative di profilo deve contenere `profileId`. Le chiavi primarie e gli indici di tali store includono il profilo, così una lettura per un profilo non può restituire record di un altro profilo per semplice omissione del filtro applicativo.

## 3. Object store e chiavi primarie

| Object store | `keyPath` | `autoIncrement` | Contenuto |
|---|---|---:|---|
| `catalogVersions` | `catalogVersion` | no | Manifest e versioni del catalogo |
| `catalogElements` | `[semanticId, contentVersion]` | no | Versioni degli elementi didattici |
| `catalogRelations` | `relationId` | no | Relazioni versionate tra elementi |
| `questionDefinitions` | `[questionSemanticId, contentVersion]` | no | Definizioni versionate dei sotto-quesiti |
| `profileSettings` | `profileId` | no | Configurazione Interrogazione per profilo |
| `sessions` | `[profileId, sessionId]` | no | Stato e snapshot delle sessioni |
| `sessionItems` | `[profileId, sessionId, itemId]` | no | Domande e sotto-quesiti congelati nella sessione |
| `exposureEvents` | `[profileId, eventId]` | no | Esiti immutabili di esposizione |
| `eventCorrections` | `[profileId, correctionId]` | no | Rettifiche append-only degli eventi |
| `knowledgeStates` | `[profileId, questionSemanticId]` | no | Proiezione corrente della conoscenza |
| `catalogAudit` | `auditId` | no | Audit append-only del catalogo |
| `operationReceipts` | `[scope, operationId]` | no | Ricevute per idempotenza e recovery |

Nessuno store usa `autoIncrement`: gli identificativi vengono creati prima di aprire la transazione. Questo evita di usare il numero progressivo del database come identità applicativa e semplifica import/export, retry e test deterministici.

## 4. Indici

Gli indici seguenti sono parte dello schema versione 1. Gli indici composti sono indicati nell'ordine esatto dei rispettivi `keyPath`.

| Store | Nome indice | `keyPath` | Unique | Finalità |
|---|---|---|---:|---|
| `catalogVersions` | `byCreatedAt` | `createdAt` | no | Elenco cronologico |
| `catalogElements` | `byTypeLayoutStatus` | `[type, layoutId, status]` | no | Ricerca per tipologia, layout e stato |
| `catalogElements` | `byCategoryStatus` | `[categoryId, status]` | no | Costruzione delle categorie disponibili |
| `catalogElements` | `bySemanticId` | `semanticId` | no | Lettura di tutte le versioni di un'identità |
| `catalogElements` | `byRecordId` | `recordId` | yes | Risoluzione dell'identificativo tecnico |
| `catalogRelations` | `byCatalogFrom` | `[catalogVersion, fromSemanticId]` | no | Relazioni in uscita nella versione richiesta |
| `catalogRelations` | `byCatalogTo` | `[catalogVersion, toSemanticId]` | no | Relazioni in ingresso nella versione richiesta |
| `catalogRelations` | `byCatalogType` | `[catalogVersion, relationType]` | no | Consultazione per tipo di relazione |
| `questionDefinitions` | `byQuestionSemanticId` | `questionSemanticId` | no | Lettura delle versioni della definizione |
| `questionDefinitions` | `byElementStatus` | `[elementSemanticId, status]` | no | Sotto-quesiti attivi di un elemento |
| `profileSettings` | `byUpdatedAt` | `updatedAt` | no | Diagnostica e ordinamento |
| `sessions` | `byProfileStatus` | `[profileId, status]` | no | Sessioni per stato e profilo |
| `sessions` | `byProfileCreatedAt` | `[profileId, createdAt]` | no | Storico sessioni |
| `sessions` | `oneSuspendedPerProfile` | `suspendedProfileId` | yes | Impedisce più sessioni sospese per profilo |
| `sessionItems` | `bySessionOrder` | `[profileId, sessionId, order]` | yes | Recupero ordinato e ordine univoco |
| `sessionItems` | `byMainElement` | `[profileId, mainElementSemanticId]` | no | Ricerca delle occorrenze nelle sessioni |
| `exposureEvents` | `byQuestionTime` | `[profileId, questionSemanticId, occurredAt]` | no | Storico cronologico per sotto-quesito |
| `exposureEvents` | `bySession` | `[profileId, sessionId]` | no | Storico della sessione |
| `exposureEvents` | `byOperationId` | `operationId` | yes | Protezione ulteriore contro duplicazioni |
| `exposureEvents` | `byEventSequence` | `[profileId, sessionId, eventSequence]` | yes | Sequenza stabile degli eventi della sessione |
| `eventCorrections` | `byEvent` | `[profileId, eventId]` | no | Ricostruzione delle rettifiche di un evento |
| `eventCorrections` | `byOperationId` | `operationId` | yes | Idempotenza delle rettifiche |
| `eventCorrections` | `byCreatedAt` | `[profileId, createdAt]` | no | Audit cronologico per profilo |
| `knowledgeStates` | `byClassification` | `[profileId, classification]` | no | Selezione adattiva per classe |
| `knowledgeStates` | `byNextReview` | `[profileId, nextReviewAt]` | no | Elementi da ripassare |
| `catalogAudit` | `byEntityTime` | `[entitySemanticId, createdAt]` | no | Audit per entità |
| `catalogAudit` | `byOperationId` | `operationId` | yes | Idempotenza audit |
| `catalogAudit` | `byCatalogVersion` | `catalogVersion` | no | Audit di una pubblicazione |
| `operationReceipts` | `byCreatedAt` | `createdAt` | no | Recovery e diagnostica |

### 4.1 Indice della sessione sospesa

Il campo `suspendedProfileId` è presente esclusivamente nei record con `status: "suspended"`; per gli altri stati deve essere omesso, non valorizzato a `null`. Gli indici IndexedDB non indicizzano i record privi del campo. L'indice univoco impedisce quindi che due schede creino due sessioni sospese per lo stesso profilo.

La transizione verso `suspended` deve impostare `suspendedProfileId = profileId`; ogni transizione fuori da `suspended` deve rimuoverlo. La regola viene applicata dal repository, non dalla UI.

### 4.2 Unicità delle operazioni

Gli indici univoci `byOperationId` sono applicabili solo se `operationId` è globalmente univoco nell'intero database. Il generatore applicativo deve quindi produrre UUID non riutilizzati tra profili e domini. Le ricevute restano comunque indicizzate da `[scope, operationId]`, per rendere esplicito il dominio dell'operazione e conservare il risultato.

## 5. Struttura fisica dei record

Gli esempi sono schemi illustrativi: i valori effettivi e le enumerazioni definitive sono validati dai contratti di dominio.

### 5.1 `catalogVersions`

```js
{
  catalogVersion: "catalog-1",
  schemaRevision: 1,
  layoutIds: ["it-qwerty-105"],
  status: "published", // draft | published | superseded
  createdAt: 1760000000000,
  publishedAt: 1760000000000,
  createdBy: "system-seed",
  contentHash: "...",
  previousCatalogVersion: null,
  notes: "Catalogo iniziale"
}
```

Una versione pubblicata è immutabile. Una modifica genera una nuova versione e conserva quella precedente finché è referenziata da sessioni, eventi, correzioni o audit.

### 5.2 `catalogElements`

```js
{
  semanticId: "character.at",
  contentVersion: 1,
  recordId: "rec_<uuid>",
  type: "CARATTERE",
  layoutId: "it-qwerty-105",
  subjectType: "CHARACTER",
  subjectId: "@",
  categoryId: "CARATTERI",
  status: "active", // active | retired
  replacedBySemanticId: null,
  validFromCatalogVersion: "catalog-1",
  createdAt: 1760000000000,
  revision: 1,
  content: {}
}
```

La chiave primaria identifica una versione del contenuto. Una variazione sostanziale che cambia l'identità didattica crea un nuovo `semanticId`; una correzione editoriale conserva l'identità e incrementa `contentVersion`. Un elemento utilizzato nello storico viene dismesso, non eliminato. L'eliminazione fisica è ammessa soltanto se non esistono esposizioni, sessioni sospese, correzioni, relazioni o riferimenti storici.

### 5.3 `catalogRelations`

```js
{
  relationId: "rel_<uuid>",
  catalogVersion: "catalog-1",
  fromSemanticId: "character.at",
  relationType: "producedBy",
  toSemanticId: "key.physical.key_ò",
  attributes: {},
  status: "active",
  createdAt: 1760000000000
}
```

Le relazioni sono legate a una versione del catalogo. La pubblicazione di una nuova versione non modifica le relazioni precedenti. La validazione impedisce riferimenti a entità inesistenti nella versione di catalogo dichiarata.

### 5.4 `questionDefinitions`

```js
{
  questionSemanticId: "question.character.at.assigned-finger",
  contentVersion: 1,
  elementSemanticId: "character.at",
  aspectId: "assignedFinger",
  answerType: "FINGER_ID",
  answerDefinition: { acceptedFingerIds: [6] },
  presentationType: "keyboard-and-hands",
  evaluationPolicy: "exact-match",
  status: "active",
  createdAt: 1760000000000,
  revision: 1
}
```

La definizione è indipendente dal testo mostrato. Una variazione di formulazione non cambia `questionSemanticId`; un nuovo aspetto autonomo richiede una nuova identità. Le versioni precedenti restano disponibili per le sessioni storiche.

### 5.5 `profileSettings`

```js
{
  profileId: "profile-123",
  revision: 1,
  sessionQuestionCount: 10,
  defaultMode: "adaptive",
  defaultQuestionType: "mixed",
  categoryQuotas: {},
  reviewIntervalsDays: [1, 3, 7, 14, 30, 60],
  updatedAt: 1760000000000
}
```

I valori predefiniti devono essere inizializzati in modo deterministico per ogni profilo. La configurazione viene copiata nella sessione all'avvio; una modifica successiva non altera sessioni esistenti.

### 5.6 `sessions`

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  status: "in-progress", // in-progress | suspended | abandoned | completed
  suspendedProfileId: undefined,
  mode: "adaptive",
  questionType: "mixed",
  requestedQuestionCount: 10,
  effectiveQuestionCount: 10,
  configSnapshot: {},
  selectionSnapshot: {},
  catalogVersion: "catalog-1",
  algorithmVersion: "selection-1",
  currentItemIndex: 0,
  score: 0,
  revision: 1,
  createdAt: 1760000000000,
  updatedAt: 1760000000000,
  completedAt: null
}
```

Il campo `suspendedProfileId` deve essere omesso quando la sessione non è sospesa. `revision` è il token di concorrenza ottimistica. Ogni avanzamento o cambio di stato incrementa la revisione.

### 5.7 `sessionItems`

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  order: 0,
  mainElementSemanticId: "character.at",
  promptSnapshot: {},
  subQuestions: [
    {
      questionSemanticId: "question.character.at.assigned-finger",
      elementSemanticId: "character.at",
      definitionVersion: 1,
      definitionSnapshot: {},
      status: "pending", // pending | answered | consulted | unanswered
      outcome: null,
      score: 0,
      evaluatedAt: null,
      exposureEventId: null
    }
  ],
  revision: 1
}
```

L'array `subQuestions` è parte dello snapshot immutabile della sessione, ma il suo stato operativo può avanzare tramite aggiornamenti atomici del record `sessionItems`. Gli eventi di esposizione rimangono la fonte storica immutabile. Un sotto-quesito non può generare più di un evento valido ordinario nella stessa sessione.

### 5.8 `exposureEvents`

```js
{
  profileId: "profile-123",
  eventId: "event_<uuid>",
  operationId: "<uuid>",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  questionSemanticId: "question.character.at.assigned-finger",
  elementSemanticId: "character.at",
  outcome: "correct", // correct | incorrect | consulted
  score: 3,
  occurredAt: 1760000000000,
  eventSequence: 1,
  catalogVersion: "catalog-1",
  definitionVersion: 1
}
```

L'evento non contiene dati mutabili di proiezione. Una risposta non data non produce un evento; la semplice visualizzazione non produce un evento. La consultazione è un evento distinto e vale +1 punto; corretta +3; errata 0.

### 5.9 `eventCorrections`

```js
{
  profileId: "profile-123",
  correctionId: "correction_<uuid>",
  operationId: "<uuid>",
  eventId: "event_<uuid>",
  correctionType: "invalidate-event", // invalidate-event | reinstate-event | annotate
  reason: "Motivazione esplicita",
  reversesCorrectionId: null,
  createdAt: 1760000000000,
  catalogVersion: "catalog-1"
}
```

Le correzioni sono append-only. Più correzioni possono riferirsi allo stesso evento. L'annullamento di una correzione è una nuova registrazione che valorizza `reversesCorrectionId`; non si elimina né si modifica la correzione annullata. Il motore di proiezione deve validare la sequenza e rifiutare catene circolari o riferimenti inesistenti.

### 5.10 `knowledgeStates`

```js
{
  profileId: "profile-123",
  questionSemanticId: "question.character.at.assigned-finger",
  firstExposureAt: 1760000000000,
  lastExposureAt: 1760000000000,
  effectiveExposureCount: 4,
  equivalentExposures: 2.75,
  rawWeaknessIndex: 62,
  reliability: 0.3548,
  adjustedWeaknessIndex: 54.26,
  classification: "da-ripassare", // debole | da-ripassare | consolidato | mai-verificato
  nextReviewAt: 1760604800000,
  pendingConsultationPriority: false,
  projectionVersion: 1,
  calculatedAt: 1760000000000
}
```

La proiezione deve essere ricostruibile dagli eventi effettivi e dalle correzioni. I record `mai-verificato` possono essere creati dal catalogo/profilo anche senza esposizioni, per consentire la priorità dedicata; in tal caso i contatori e le date di esposizione sono assenti o null secondo un'unica convenzione di serializzazione. La proiezione non è mai usata come prova storica.

### 5.11 `catalogAudit`

```js
{
  auditId: "audit_<uuid>",
  operationId: "<uuid>",
  entitySemanticId: "character.at",
  operationType: "relation-updated",
  previousValue: {},
  newValue: {},
  reason: "Motivazione esplicita",
  createdAt: 1760000000000,
  catalogVersion: "catalog-2",
  reversesAuditId: null
}
```

L'audit registra creazioni, modifiche, dismissioni, riattivazioni, sostituzioni, pubblicazioni e rettifiche. Le operazioni di catalogo che modificano dati e audit devono avvenire nella stessa transazione IndexedDB.

### 5.12 `operationReceipts`

```js
{
  scope: "profile:profile-123",
  operationId: "<uuid>",
  operationType: "record-outcome",
  payloadHash: "...",
  result: {},
  createdAt: 1760000000000
}
```

La ricevuta viene scritta nella stessa transazione dell'operazione applicativa. Se arriva di nuovo lo stesso `operationId` con lo stesso `payloadHash`, il repository restituisce il risultato registrato senza ripetere l'operazione. Se il payload differisce, restituisce un conflitto di idempotenza.

## 6. Vincoli d'integrità applicativi

IndexedDB garantisce atomicità delle transazioni e unicità degli indici dichiarati, ma non supporta foreign key o vincoli referenziali relazionali. I seguenti vincoli sono quindi verificati dal repository all'interno della transazione che scrive i dati:

1. Ogni sessione appartiene a un profilo esistente nell'elenco profili applicativo.
2. Ogni `sessionItem` riferisce una sessione esistente con lo stesso `profileId`.
3. Ogni evento riferisce una sessione e un item appartenenti allo stesso profilo.
4. Ogni evento riferisce un sotto-quesito effettivamente presente nello snapshot dell'item.
5. Un sotto-quesito può essere valutato una sola volta nella sessione, salvo una procedura esplicita di rettifica append-only.
6. `eventSequence` è progressivo e univoco nella sessione.
7. Ogni correzione riferisce un evento dello stesso profilo.
8. Ogni annullamento riferisce una correzione esistente dello stesso evento e profilo.
9. Le relazioni di catalogo riferiscono elementi presenti nella versione catalogo dichiarata.
10. Una nuova sessione seleziona soltanto elementi attivi e definizioni attive della versione pubblicata corrente.
11. Una sessione sospesa conserva i propri snapshot anche se catalogo o definizioni vengono sostituiti o dismessi.
12. Nessun elemento con riferimenti storici può essere eliminato fisicamente.
13. Un `operationId` non può essere riutilizzato con payload diverso.
14. Ogni modifica a un record revisionato verifica la `revision` attesa e la incrementa.
15. Le modifiche a più store che costituiscono una singola operazione logica sono incluse nella stessa transazione IndexedDB.

## 7. Matrice delle transazioni

### 7.1 Registrazione di un esito (`recordOutcome`)

**Store in lettura/scrittura:** `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `operationReceipts`.  
**Modalità:** una singola transazione `readwrite`.

Sequenza obbligatoria:

1. Verificare la ricevuta `[scope, operationId]`.
2. Se esiste, confrontare `payloadHash` e restituire il risultato precedente oppure conflitto.
3. Leggere sessione e item, verificando profilo, stato, revisione e appartenenza del sotto-quesito.
4. Verificare che il sotto-quesito sia ancora `pending` e non abbia un evento associato.
5. Validare esito, punteggio e definizione congelata nella sessione.
6. Assegnare `eventId`, `eventSequence` e timestamp.
7. Inserire l'evento immutabile.
8. Aggiornare lo stato del sotto-quesito nello snapshot operativo dell'item.
9. Aggiornare la proiezione di conoscenza per il solo `questionSemanticId` interessato.
10. Aggiornare punteggio e revisione della sessione.
11. Inserire la ricevuta con il risultato completo.
12. Completare la transazione; solo dopo il completamento notificare la UI.

Se un passaggio fallisce, l'intera transazione viene annullata. Non deve essere possibile avere evento senza aggiornamento coerente di item, sessione, proiezione e ricevuta.

### 7.2 Sospensione e ripresa

**Store:** `sessions` e, se necessario, `sessionItems`; transazione `readwrite`.

- La sospensione verifica la revisione e che non esista già un'altra sessione sospesa per il profilo. Imposta `status: "suspended"` e `suspendedProfileId`.
- L'indice univoco è la protezione finale contro due sospensioni concorrenti.
- La ripresa verifica lo stato sospeso, rimuove `suspendedProfileId`, imposta `in-progress` e incrementa la revisione.
- Snapshot, selezione, ordine, esiti e posizione corrente non vengono ricalcolati.

### 7.3 Abbandono e completamento

**Store:** `sessions`; transazione `readwrite`.  
La transizione verifica revisione e stato ammesso, registra `abandoned` o `completed`, aggiorna timestamp e revisione. Il completamento formale è consentito soltanto dopo la conferma esplicita richiesta dalla UI. L'abbandono conserva eventi, item e punteggio già registrati.

### 7.4 Modifica del catalogo

**Store:** `catalogVersions`, `catalogElements`, `catalogRelations`, `questionDefinitions`, `catalogAudit`, `operationReceipts`; transazione `readwrite`.

- Verificare `operationId` e payload.
- Verificare la revisione attesa delle entità interessate.
- Validare relazioni e definizioni risultanti.
- Scrivere nuove versioni/record senza sovrascrivere le versioni storiche.
- Scrivere audit e ricevuta nella stessa transazione.
- Pubblicare la nuova `catalogVersion` soltanto se l'intero insieme è valido.

La dismissione di un elemento già utilizzato non cancella eventi né sessioni. L'eventuale `replacedBySemanticId` identifica la sostituzione, ma non trasferisce statistiche o conoscenza. Le catene A→B→C restano esplicite, senza shortcut automatiche.

### 7.5 Correzione di un evento

**Store:** `eventCorrections`, `knowledgeStates`, `operationReceipts`; transazione `readwrite`, con lettura dell'evento originale e delle correzioni precedenti.

La correzione originale non viene modificata. Il motore calcola la nuova sequenza effettiva e aggiorna la proiezione nella stessa transazione. Un errore lascia invariati correzioni e proiezione.

### 7.6 Ricostruzione delle proiezioni

**Store:** `exposureEvents`, `eventCorrections`, `knowledgeStates`.

La ricostruzione completa può essere eseguita per profilo in transazione dedicata, suddivisa in batch solo se viene introdotto un protocollo esplicito di staging/versione. Non è ammesso sostituire progressivamente le proiezioni visibili lasciandole in stato parziale. Per la prima implementazione, ricostruzione completa in una transazione unica per profili di dimensione supportata; se la quota o la durata rendono questa scelta non sostenibile, progettare una proiezione staging con marker atomico prima di implementarla.

## 8. Concorrenza tra schede

### 8.1 Controllo ottimistico

Ogni record modificabile contiene `revision`. Il chiamante fornisce la revisione letta; il repository rilegge il record nella transazione `readwrite` e confronta il valore.

- Revisione uguale: applica la modifica e salva `revision + 1`.
- Revisione diversa: abortisce l'operazione e restituisce `REVISION_CONFLICT` con dati correnti sufficienti per aggiornare la UI.
- Entità differenti: possono essere modificate indipendentemente, purché le operazioni non violino vincoli condivisi.

### 8.2 Concorrenza sessione

La registrazione di un esito, la sospensione, la ripresa, l'abbandono e il completamento devono verificare la revisione della sessione. Per il sotto-quesito si verifica anche lo stato `pending`. Questo impedisce che due schede registrino due volte la stessa risposta.

### 8.3 Concorrenza catalogo

Le modifiche a una stessa entità confrontano `revision`. La pubblicazione confronta anche la `catalogVersion` corrente attesa: se un'altra scheda ha pubblicato nel frattempo, l'operazione fallisce e richiede ricaricamento/riconciliazione. Non si applica un merge automatico di modifiche semantiche.

## 9. LocalStorage e IndexedDB: protocollo di coerenza

I due storage non condividono una transazione atomica. Non va simulata una garanzia che il browser non offre.

Per le operazioni che coinvolgono entrambi gli storage (in particolare importazione/esportazione profilo e cancellazione profilo), usare un protocollo recuperabile:

1. Validare integralmente il pacchetto e il profilo prima di modificare dati.
2. Creare in IndexedDB una ricevuta/marker di operazione con stato `prepared` e payload hash.
3. Applicare la fase LocalStorage tramite le API circoscritte del `ProfileManager`.
4. Applicare la fase IndexedDB in transazione atomica.
5. Marcare l'operazione `committed` in IndexedDB.
6. Se una fase fallisce, eseguire rollback compensativo quando possibile; altrimenti lasciare marker recuperabile e impedire che l'operazione venga dichiarata conclusa.
7. All'avvio successivo, esaminare marker incompleti e proporre/avviare recovery deterministico senza duplicare operazioni.

La procedura concreta dovrà essere integrata senza riscrivere `ProfileManager`. È già stato rilevato nella baseline che `importProfileData()` non verifica il successo della scrittura finale di `TFT_ACTIVE_USER`: il punto dovrà essere corretto in modo circoscritto nella fase implementativa, con test specifico di rollback.

La cancellazione di un profilo deve rimuovere soltanto i dati del profilo interessato dagli store profilati. I dati condivisi di catalogo e audit non vengono cancellati. L'operazione deve essere ripetibile e recuperabile.

## 10. Apertura database, upgrade e recovery

### 10.1 Apertura

- Aprire il database con versione esplicita.
- Gestire `onupgradeneeded` esclusivamente per creazione/upgrade schema.
- Gestire `onblocked` mostrando un messaggio che inviti a chiudere le altre schede dell'applicazione.
- Gestire `versionchange` chiudendo la connessione aperta e impedendo nuove operazioni su quella connessione.
- Gestire `error` e `blocked` senza dichiarare l'inizializzazione riuscita.
- Non cancellare e ricreare automaticamente un database esistente in caso di errore.

### 10.2 Regole di upgrade

Ogni incremento della versione IndexedDB deve avere una migrazione deterministica, atomica e monotona. La migrazione:

- crea nuovi store/indici;
- aggiunge o normalizza campi solo con default deterministici;
- non elimina eventi, correzioni, audit o snapshot storici;
- non modifica il significato di identità già utilizzate;
- registra la versione schema completata;
- fallisce integralmente se un prerequisito non è soddisfatto.

Le migrazioni IndexedDB devono essere sincrone rispetto alla transazione `versionchange`: niente attese di rete o operazioni asincrone esterne. Se è necessaria una trasformazione massiva non eseguibile in tale transazione, usare una migrazione applicativa staged con marker e versione dati, mantenendo leggibile lo stato precedente fino al commit finale.

### 10.3 Recovery all'avvio

All'avvio del dominio Interrogazione:

1. Aprire e verificare il database.
2. Recuperare marker `prepared` non conclusi.
3. Verificare l'esistenza di sessioni sospese e l'unicità per profilo.
4. Verificare eventuali ricevute senza risultato coerente, senza ricreare eventi alla cieca.
5. Verificare che le proiezioni dichiarino una `projectionVersion` supportata.
6. Ricostruire o segnalare proiezioni non coerenti a partire da eventi e correzioni.
7. Non eliminare dati storici per tentare una riparazione automatica.

## 11. Export, import e cancellazione profilo

### 11.1 Export

Il pacchetto Interrogazione deve includere, per il profilo selezionato:

- impostazioni;
- sessioni e relativi item/snapshot;
- eventi di esposizione;
- correzioni;
- proiezioni, marcate come ricostruibili;
- versione schema, versione algoritmo e riferimenti alle versioni catalogo necessarie.

Il catalogo condiviso non viene duplicato integralmente in ogni export. Il pacchetto include i riferimenti e, se necessari per rendere autosufficiente la ricostruzione storica, le sole versioni catalogo/definizioni effettivamente referenziate e non già garantite dal catalogo installato.

### 11.2 Import

- Validare struttura, versioni, profilo di destinazione, riferimenti e dimensioni prima della scrittura.
- Non sovrascrivere silenziosamente eventi con lo stesso ID ma contenuto diverso.
- Duplicati identici sono idempotenti; ID uguali con payload diversi generano conflitto esplicito.
- Scrivere i dati del profilo in transazione atomica IndexedDB.
- Ricostruire le proiezioni dagli eventi e dalle correzioni importati, oppure verificare l'hash/versione delle proiezioni fornite.
- Coordinare la fase LocalStorage con il protocollo recuperabile del capitolo 9.

### 11.3 Cancellazione profilo

La cancellazione elimina impostazioni, sessioni, item, eventi, correzioni, proiezioni e ricevute appartenenti al profilo. Non elimina catalogo, versioni condivise, relazioni o audit globale. La cancellazione deve essere isolata, verificabile e idempotente.

## 12. Gestione quota e errori

Il repository deve distinguere almeno:

- `DB_UNAVAILABLE`: IndexedDB assente o non utilizzabile;
- `DB_OPEN_FAILED`: apertura fallita;
- `DB_BLOCKED`: upgrade bloccato da altre connessioni;
- `DB_QUOTA_EXCEEDED`: quota browser esaurita;
- `REVISION_CONFLICT`: record modificato da un'altra scheda;
- `IDEMPOTENCY_CONFLICT`: stesso operationId con payload differente;
- `REFERENCE_INTEGRITY_ERROR`: riferimento mancante o incoerente;
- `INVALID_STATE_TRANSITION`: transizione non ammessa;
- `SCHEMA_VERSION_UNSUPPORTED`: schema o pacchetto non supportato;
- `IMPORT_VALIDATION_FAILED`: pacchetto non valido.

Un errore di quota non deve causare cancellazione automatica dello storico. L'utente deve ricevere un messaggio comprensibile e l'operazione deve risultare non completata. Il dettaglio tecnico può essere registrato in un log diagnostico separato, senza inserire dati sensibili o contenuti non necessari.

## 13. Strategia di test della persistenza

I test devono usare un database temporaneo isolato e dati deterministici. I test di concorrenza devono simulare almeno due connessioni/schede.

| ID | Prova | Risultato atteso |
|---|---|---|
| IDB-001 | Prima apertura database | Tutti gli store e gli indici della versione 1 sono presenti |
| IDB-002 | Seconda apertura | Nessuna ricreazione o perdita dati |
| IDB-003 | Due sessioni sospese stesso profilo | La seconda scrittura è rifiutata dall'indice univoco |
| IDB-004 | Sessioni sospese di profili diversi | Entrambe ammesse |
| IDB-005 | Due schede aggiornano stessa sessione con stessa revision | Una sola operazione riesce; l'altra riceve conflitto |
| IDB-006 | Due schede aggiornano entità catalogo differenti | Entrambe possono riuscire |
| IDB-007 | Stesso operationId e payload | Il risultato precedente viene restituito, senza duplicati |
| IDB-008 | Stesso operationId e payload diverso | Conflitto, nessuna modifica |
| IDB-009 | Errore a metà `recordOutcome` | Nessun evento, punteggio o proiezione parziale |
| IDB-010 | Esito registrato due volte sullo stesso sotto-quesito | Un solo evento valido |
| IDB-011 | Visualizzazione senza risposta | Nessun evento di esposizione |
| IDB-012 | Consultazione | Evento `consulted`, punteggio +1, conoscenza aggiornata con peso previsto |
| IDB-013 | Sospensione e ripresa | Ripristino esatto di item, sotto-quesiti, snapshot e indice corrente |
| IDB-014 | Sostituzione elemento durante sessione sospesa | Sessione riprende con snapshot originario; nuove sessioni usano il catalogo corrente |
| IDB-015 | Dismissione elemento storico | Storico conservato; elemento escluso dalle nuove selezioni |
| IDB-016 | Eliminazione elemento referenziato | Operazione rifiutata |
| IDB-017 | Correzione evento | Evento originale invariato; nuova proiezione coerente |
| IDB-018 | Annullamento correzione | Nuova correzione append-only; sequenza ricostruibile |
| IDB-019 | Errore durante modifica catalogo | Nessuna modifica parziale e nessun audit orfano |
| IDB-020 | Upgrade bloccato da altra scheda | `onblocked` gestito; nessuna falsa conferma di upgrade |
| IDB-021 | `versionchange` su altra scheda | Connessione precedente chiusa correttamente |
| IDB-022 | Quota esaurita | Operazione non dichiarata riuscita; storico non cancellato |
| IDB-023 | Import duplicato identico | Nessuna duplicazione |
| IDB-024 | Import con ID uguale e contenuto diverso | Conflitto esplicito e rollback |
| IDB-025 | Cancellazione profilo A | Dati profilo A rimossi; dati profilo B e catalogo condiviso invariati |
| IDB-026 | Recovery marker `prepared` | Operazione completata o compensata deterministicamente, senza duplicazioni |
| IDB-027 | Ricostruzione proiezione | Risultato identico al calcolo incrementale sugli stessi eventi/correzioni |
| IDB-028 | Migrazione schema | Dati storici e snapshot preservati |

## 14. Punti che restano da chiudere prima dell'implementazione

Questi punti non impediscono di fissare lo schema fisico, ma devono essere risolti nella progettazione esecutiva complessiva:

1. **Quote adattive D77–D80:** formalizzazione matematica conclusa in `Decisione_Quote_Adattive_D77-D80_v1.1`. Budget globale 10 punti percentuali, tetto individuale 20% della quota base normalizzata, prelievo proporzionale, riparto iterativo ai deficit e quota neutra per l'eventuale residuo. Restano da implementare e collaudare i test numerici e di determinismo definiti nell'addendum.
2. **Catalogo iniziale QWERTY italiano 105 tasti:** completamento e verifica delle identità, relazioni e sotto-quesiti rispetto a `KEY_MAP`, SVG, landmark e dita. Restano da risolvere le tre associazioni speciali CTRL-dx rilevate nella baseline.
3. **Selezione casuale riproducibile:** definizione del seed e dell'algoritmo versionato per consentire diagnosi e riproducibilità senza far leggere statistiche alla modalità casuale.
4. **Calendario di consolidamento:** specifica completa della transizione tra intervalli 1, 3, 7, 14, 30 e 60 giorni per corretta, errata, consultata e non risposta, prima di fissare i campi derivati definitivi.
5. **Dimensione massima dei dati:** misurazione su storico realistico per confermare la sostenibilità della ricostruzione in transazione unica o definire lo staging.
6. **Versionamento algoritmo:** identificatori e strategia di compatibilità per selezione, conoscenza e proiezione.
7. **Compatibilità profili:** contratto definitivo per profili rinominati, eliminati o importati mentre esistono sessioni sospese.

Non si devono anticipare decisioni su questi punti tramite valori impliciti nel repository. Il repository persiste e garantisce atomicità; le regole didattiche restano nei servizi di dominio.

## 15. Sequenza implementativa raccomandata

Dopo approvazione della progettazione, l'implementazione va eseguita in passaggi isolati e verificabili:

1. Repository IndexedDB: apertura, schema v1, upgrade, errori e test store/indici.
2. Seed e validatore catalogo: caricamento atomico, versioni e relazioni.
3. Repository profilo/sessione: impostazioni, sessioni, item, sospensione/ripresa e concorrenza.
4. Eventi e ricevute: `recordOutcome` atomico e idempotente.
5. Correzioni, audit e proiezioni: append-only, ricostruzione e test di coerenza.
6. Import/export e protocollo di recovery LocalStorage/IndexedDB.
7. Integrazione UI e collaudo browser, mantenendo l'ordine degli script classici `defer` della baseline.

Ogni passaggio deve avere una propria versione dei file modificati, test automatici mirati e verifica di regressione dei nove test già presenti nella baseline. Nessun file esistente va sostituito prima di averne conservato la versione precedente.

---

**Esito:** schema fisico IndexedDB v1.0 definito a livello progettuale. Non sono stati modificati sorgenti, documentazione utente, HELP o baseline applicativa.
