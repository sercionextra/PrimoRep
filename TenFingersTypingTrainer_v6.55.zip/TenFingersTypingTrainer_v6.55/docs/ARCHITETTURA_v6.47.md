# Architettura TenFingersTypingTrainer v6.47

Documento di aggiornamento architetturale rispetto alla v6.46.

## 1. Obiettivo della Release v6.47
Garantire che il passaggio a **Random This Phrase** (`mode === 5`) dopo il completamento di una sessione in **Digitazione Libera** (`mode === 4` tramite `#btnAddStatistic` / `recordManualTypingSample()`) utilizzi sempre l'ultima frase digitata dall'utente invece di ricadere sulle lezioni standard.

## 2. Interventi Tecnici
- **`TypingEngine.resetTypingSession()` (`js/engines/typing-engine.js`)**: salvataggio di `this.typedText` in `this.lastTypedPhrase` prima dell'azzeramento (`this.typedText = ""`), coprendo il percorso di completamento manuale `recordManualTypingSample()`.
- **`TypingEngine.loadExercise()` (`js/engines/typing-engine.js`)**: normalizzazione di `\n` in `®` nel ramo `mode === 5` per preservare eventuali ritorni a capo digitati in modalità libera.
- **`AppController.setupToolbar()` (`js/app/controller/metodi-toolbar-modalita.js`)**: il controllo di abilitazione su `#btnRandomThisPhrase` in `mode === 4` verifica la presenza di testo in `typedText` oppure in `lastTypedPhrase`.
