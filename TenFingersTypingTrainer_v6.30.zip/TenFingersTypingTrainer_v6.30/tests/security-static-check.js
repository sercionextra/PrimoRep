#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const failures = [];
const pass = (message) => console.log(`PASS ${message}`);
const fail = (message) => failures.push(message);
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");

const cspRequired = [
  "default-src 'none'",
  "base-uri 'none'",
  "form-action 'none'",
  "object-src 'none'",
  "frame-src 'none'",
  "worker-src 'none'",
  "connect-src 'none'",
  "media-src 'none'",
  "img-src 'self' file: data: blob:",
  "font-src 'self' file:",
  "script-src 'self' file:",
  "script-src-elem 'self' file:",
  "script-src-attr 'none'",
  "style-src 'self' file:",
  "style-src-elem 'self' file:",
  "style-src-attr 'none'",
];

for (const htmlFile of ["index.html", "help.html"]) {
  const html = read(htmlFile);
  const cspMatch = html.match(/<meta\s+http-equiv=["']Content-Security-Policy["']\s+content="([^"]+)"\s*\/?\s*>/i);
  if (!cspMatch) {
    fail(`${htmlFile}: CSP meta non presente.`);
    continue;
  }
  for (const directive of cspRequired) {
    if (!cspMatch[1].includes(directive)) fail(`${htmlFile}: direttiva CSP mancante: ${directive}`);
  }
  if (/unsafe-inline|unsafe-eval/i.test(cspMatch[1])) fail(`${htmlFile}: CSP contiene una deroga permissiva.`);
  if (/\sstyle\s*=/i.test(html)) fail(`${htmlFile}: attributi style inline ancora presenti.`);
  if (/\son[a-z]+\s*=/i.test(html)) fail(`${htmlFile}: event handler HTML inline ancora presente.`);
  if (/<script(?![^>]*\bsrc\s*=)[^>]*>/i.test(html)) fail(`${htmlFile}: blocco script inline ancora presente.`);
  if (!/name=["']referrer["']\s+content=["']no-referrer["']/i.test(html)) fail(`${htmlFile}: referrer policy no-referrer mancante.`);
  pass(`${htmlFile}: CSP restrittiva, nessuno script/style/event handler inline.`);
}

const htmlFiles = ["index.html", "help.html"];
for (const htmlFile of htmlFiles) {
  const html = read(htmlFile);
  const anchorTags = [...html.matchAll(/<a\b([^>]*)>/gi)];
  for (const [, attrs] of anchorTags) {
    const href = attrs.match(/\bhref=["']([^"']+)["']/i);
    if (href && /^(?:(?:https?:)?\/\/|ftp:|mailto:|tel:|javascript:|data:|file:)/i.test(href[1])) {
      fail(`${htmlFile}: navigazione non locale non autorizzata: ${href[1]}`);
    }
  }
  if (/<meta\b[^>]*http-equiv=["']refresh["']/i.test(html)) fail(`${htmlFile}: meta refresh non ammesso.`);
  if (/\b(?:src|srcset|href|action)\s*=\s*["']\/\//i.test(html)) fail(`${htmlFile}: URL protocol-relative non ammesso.`);
  const scriptTags = [...html.matchAll(/<script\b([^>]*)>/gi)];
  if (!scriptTags.length || !/src=["']js\/security\/network-isolation-guard\.js["']/i.test(scriptTags[0][1])) {
    fail(`${htmlFile}: network-isolation-guard.js non è il primo script.`);
  }
  const resourceTags = [...html.matchAll(/<(script|link)\b([^>]*)>/gi)];
  for (const [, tagName, attrs] of resourceTags) {
    const attrName = tagName.toLowerCase() === "script" ? "src" : "href";
    const match = attrs.match(new RegExp(`\\b${attrName}=["']([^"']+)["']`, "i"));
    if (!match) continue;
    const value = match[1];
    if (/^(?:https?:)?\/\//i.test(value) || /^data:/i.test(value) && tagName.toLowerCase() !== "link") {
      fail(`${htmlFile}: risorsa non locale: ${value}`);
    } else if (!/^(?:data:|#)/i.test(value)) {
      const localPath = path.resolve(root, value.split(/[?#]/, 1)[0]);
      if (!localPath.startsWith(root + path.sep) || !fs.existsSync(localPath)) {
        fail(`${htmlFile}: risorsa locale mancante o fuori directory: ${value}`);
      }
    }
  }
}
pass("Tutte le risorse script e stylesheet sono locali.");

const sourceFiles = [];
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== "tests") walk(full);
    } else if (/\.(js|css|html)$/i.test(entry.name)) {
      sourceFiles.push(full);
    }
  }
}
walk(root);

const remotePattern = /https?:\/\//i;
for (const file of sourceFiles) {
  let content = fs.readFileSync(file, "utf8");
  content = content.replace(/http:\/\/www\.w3\.org\/2000\/svg/g, "");
  if (remotePattern.test(content)) fail(`${path.relative(root, file)}: URL HTTP/HTTPS non autorizzato.`);
}

const cssFiles = sourceFiles.filter((file) => file.endsWith(".css"));
for (const file of cssFiles) {
  const css = fs.readFileSync(file, "utf8");
  if (/@import\s/i.test(css)) fail(`${path.relative(root, file)}: @import CSS non ammesso.`);
  if (/url\(\s*["']?(?:https?:)?\/\//i.test(css)) fail(`${path.relative(root, file)}: URL CSS remoto.`);
}
pass("Nessun URL remoto, @import o riferimento CSS remoto nei sorgenti.");

const appJsFiles = sourceFiles.filter((file) => file.endsWith(".js") && !file.includes(`${path.sep}security${path.sep}`));
const forbiddenApiPattern = /\b(?:fetch\s*\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon|serviceWorker|RTCPeerConnection|webkitRTCPeerConnection|getUserMedia|getDisplayMedia|enumerateDevices|SharedWorker|WebTransport|BroadcastChannel|navigator\.clipboard|navigator\.share|navigator\.credentials|navigator\.geolocation|navigator\.bluetooth|navigator\.usb|navigator\.serial|navigator\.hid|navigator\.nfc)\b/;
for (const file of appJsFiles) {
  const content = fs.readFileSync(file, "utf8");
  if (forbiddenApiPattern.test(content)) fail(`${path.relative(root, file)}: primitiva di rete/accesso non autorizzata.`);
  if (/style\s*=\s*["']|<[^>]+\son[a-z]+\s*=/i.test(content)) {
    fail(`${path.relative(root, file)}: markup dinamico con style/event handler inline non ammesso.`);
  }
  if (/location\.(?:assign|replace)\s*\(|location\.href\s*=|window\.open\s*\(/.test(content)) {
    const allowedHelpFallback = /window\.open\(["']help\.html["']/.test(content) && !/location\.(?:assign|replace)\s*\(|location\.href\s*=/.test(content);
    if (!allowedHelpFallback) fail(`${path.relative(root, file)}: navigazione dinamica da verificare.`);
  }
}
pass("Nessuna primitiva di rete o navigazione esterna nel codice applicativo.");

const guard = read("js/security/network-isolation-guard.js");
if (!/connect-src/.test(read("index.html")) || !/securitypolicyviolation/.test(guard)) {
  fail("Guard runtime o monitor CSP non configurati.");
}
if (!/localService\s*===\s*true/.test(read("js/engines/dictation-engine.js"))) {
  fail("La sintesi vocale non impone localService === true.");
}
if (!/activeVoice\.localService\s*!==\s*true/.test(read("js/engines/dictation-engine.js"))) {
  fail("La sintesi vocale può ricadere sulla voce predefinita del browser.");
}
pass("Sintesi vocale limitata a voci italiane dichiarate locali.");

if (failures.length) {
  console.error(`\nSECURITY STATIC CHECK FAILED (${failures.length})`);
  failures.forEach((message) => console.error(`- ${message}`));
  process.exit(1);
}
console.log("\nSECURITY STATIC CHECK PASSED.");
