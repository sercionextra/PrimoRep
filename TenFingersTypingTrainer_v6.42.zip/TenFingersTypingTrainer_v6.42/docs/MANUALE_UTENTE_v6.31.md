# Manuale Utente TenFingersTypingTrainer v6.31

## Novità pratiche nella finestra Interrogazione

### 1. Selezione e deselezione manuale (Tastiera, Mani e Chip)
- In modalità **Manuale**, cliccando su un tasto della tastiera in bianco e nero, su un dito o su un pallino del grafico delle mani, l'elemento viene aggiunto all'elenco ed evidenziato in verde.
- Un **secondo click** sullo stesso tasto, sullo stesso dito o sullo stesso pallino delle mani rimuove l'elemento dall'elenco e toglie l'evidenziazione verde (mantenendo evidenziati eventuali altri elementi ancora selezionati).
- Anche cliccando la **✕** accanto a un elemento nell'elenco viene rimossa la selezione verde dalla tastiera o dalle mani.
- La selezione rimane sincronizzata anche cambiando il **Tipo Interrogazione**.

### 2. Finestra ridimensionabile e "Mostra storico"
- La finestra **Interrogazione Layout Tastiera Italiana** è ridimensionabile dai bordi e dagli angoli: il grafico dello storico si adatta automaticamente alle nuove dimensioni.
- La vista **📈 Mostra storico** offre gli stessi strumenti del grafico delle velocità nelle Statistiche:
  - **Selettori del grafico:** scegli cosa visualizzare tra **Punteggio**, **% Rendimento**, **N. Totale**, **N. Corrette**, **N. Errate**, **N. Consultate** e **N. Ignorate**.
  - **Filtri per tipologia:** attiva o disattiva **CARATTERE**, **TASTO**, **DITO** e **HOME_ROW**.
  - **Filtro Data e Ora:** imposta **Inizio (Data/Ora)** e **Fine (Data/Ora)** con pulsanti singoli di cancellazione (`×`) e pulsante **Reset Periodo**.
  - **Cursore ed evidenziazione:** spostando il mouse sul grafico compaiono le linee guida (rossa orizzontale con il valore e azzurra verticale) e la data/ora del campione più vicino; passando sopra un punto esso si illumina in verde mostrando nella didascalia Data/Ora, Tipo di quesiti, Numero domande, Punteggio / Massimo e percentuale (es. 144 / 180 pt (80%)) e conteggio di risposte Corrette, Errate, Consultate e Ignorate.
  - **Selezione campioni ed eliminazione:** un primo click fissa l'inizio dell'intervallo, il secondo click seleziona i campioni compresi (o il campione singolo), il terzo click annulla la selezione. Puoi eliminare i campioni con **Elimina Selezionati**, **Elimina Non Selezionati** (visibili nel periodo filtrato) oppure svuotare tutto con **Elimina Archivio Storico**.
  - **Ripeti interrogazione:** selezionando un **singolo campione**, accanto alla didascalia compare il pulsante **🔁 Ripeti interrogazione**, che consente di avviare una nuova sessione con **Tutti i quesiti** di quella prova oppure filtrando solo quelli **Corretti**, **Errati**, **Consultati** o **Ignorati**.
