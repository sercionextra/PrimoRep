// ============================================================================
// TEST SUITE: Struttura Modale e Ridimensionamento Configurazione Dettatura (v6.23)
// ============================================================================
const fs = require("fs");
const path = require("path");
const assert = require("assert");

const root = path.join(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");

console.log("=== TEST SUITE: Dictation Config Dialog & Modal Hierarchy (v6.23) ===");

// 1. Verifica che index.html contenga gli elementi corretti
assert.ok(html.includes('id="dictationConfigModal"'), "dictationConfigModal presente");
assert.ok(html.includes('id="dictationConfigDialog"'), "dictationConfigDialog presente");
assert.ok(html.includes('id="dictationConfigHeader"'), "dictationConfigHeader presente");
assert.ok(html.includes('id="dictationConfigBody"'), "dictationConfigBody presente");
assert.ok(html.includes('id="loginModal"'), "loginModal presente");
console.log("  [PASS] Elementi base trovati in index.html");

// 2. Verifica che loginModal non sia nidificato all'interno di dictationConfigModal
const dictationModalIdx = html.indexOf('id="dictationConfigModal"');
const loginModalIdx = html.indexOf('id="loginModal"');
assert.ok(dictationModalIdx > 0 && loginModalIdx > dictationModalIdx, "dictationConfigModal precede loginModal");

const dictationSlice = html.substring(dictationModalIdx, loginModalIdx);
// Conta apertura e chiusura div nel tratto tra l'inizio di dictationConfigModal e loginModal
const openDivs = (dictationSlice.match(/<div(\s|>)/gi) || []).length;
const closeDivs = (dictationSlice.match(/<\/div>/gi) || []).length;
assert.strictEqual(openDivs, closeDivs, `I div all'interno di dictationConfigModal devono essere perfettamente bilanciati prima di loginModal (Open: ${openDivs}, Close: ${closeDivs})`);
assert.ok(!dictationSlice.includes('id="loginModal"'), "loginModal NON deve trovarsi all'interno di dictationConfigModal");
console.log("  [PASS] dictationConfigModal isolato: loginModal è fratello esterno e i tag sono bilanciati");

// 3. Verifica presenza delle maniglie di ridimensionamento verticale (rh-n e rh-s)
assert.ok(dictationSlice.includes('class="resize-handle rh-n"'), "Maniglia superiore rh-n presente");
assert.ok(dictationSlice.includes('class="resize-handle rh-s"'), "Maniglia inferiore rh-s presente");
assert.ok(dictationSlice.includes('min-height: 420px'), "Vincolo min-height 420px configurato");
assert.ok(dictationSlice.includes('max-height: 92vh'), "Vincolo max-height 92vh configurato");
console.log("  [PASS] Maniglie di ridimensionamento verticale (rh-n, rh-s) e vincoli 420px/92vh conformi");

// 4. Verifica architettura TitleBar fissa, Body scrollabile e Footer ancorato
assert.ok(dictationSlice.includes('id="dictationConfigHeader"'), "TitleBar fissa identificata");
assert.ok(dictationSlice.includes('id="dictationConfigBody"'), "Body centrale identificato");
assert.ok(dictationSlice.includes('overflow-y: auto'), "Body centrale dotato di scrollbar indipendente");
assert.ok(dictationSlice.includes('id="btnDictationConfigResetDefault"'), "Pulsante Reset Default presente nel footer");
assert.ok(dictationSlice.includes('id="btnCancelDictationConfig"'), "Pulsante Annulla presente nel footer");
assert.ok(dictationSlice.includes('id="btnConfirmDictationConfig"'), "Pulsante Salva presente nel footer");
console.log("  [PASS] Struttura a 3 fasce (TitleBar fissa, Body scrollabile, Footer fisso) verificata");

// 5. Test logico del controller in ambiente mock
const DictationEngine = require("../js/engines/dictation-engine.js");
const ProfileManager = require("../js/profiles/profile-manager.js");

// Mock DOM
const mockElements = {
  dictationConfigModal: { classList: { add() {}, remove() {}, contains: () => false } },
  dictationConfigDialog: {
    offsetHeight: 600,
    style: {},
    querySelectorAll: () => [
      { getAttribute: () => "n", addEventListener() {} },
      { getAttribute: () => "s", addEventListener() {} }
    ]
  },
  dictationConfigBody: { scrollTop: 100 },
  chkDictationAdaptive: { checked: true },
  txtDictationMinCpm: { value: "100" },
  rngDictationMinCpm: { value: "100" },
  txtDictationMaxCpm: { value: "200" },
  rngDictationMaxCpm: { value: "200" },
  txtDictationStallBaseDelay: { value: "1.5" },
  rngDictationStallBaseDelay: { value: "1.5" },
  txtDictationStallLongDelay: { value: "3.5" },
  rngDictationStallLongDelay: { value: "3.5" },
  txtDictationStallSpeedFactor: { value: "1.0" },
  rngDictationStallSpeedFactor: { value: "1.0" },
  btnDictationConfigResetDefault: { addEventListener() {} },
  btnCancelDictationConfig: { addEventListener() {} },
  btnConfirmDictationConfig: { addEventListener() {} },
  btnCloseDictationConfigModal: { addEventListener() {} }
};

global.document = {
  getElementById: (id) => mockElements[id] || null
};
global.window = {
  innerHeight: 800,
  addEventListener() {}
};

// Verifica che il reset scroll funzioni all'apertura
mockElements.dictationConfigBody.scrollTop = 250;
const body = global.document.getElementById("dictationConfigBody");
if (body) body.scrollTop = 0;
assert.strictEqual(mockElements.dictationConfigBody.scrollTop, 0, "Apertura della modale azzera lo scroll del body centrale");
console.log("  [PASS] Reset scrollTop del body centrale verificato");

// 6. Test formula di ridimensionamento verticale bidirezionale (delta * 2 per dialog centrato)
const initH = 600;
const startY = 300;
const minH = 420;
const maxH = Math.round(800 * 0.92); // 736

// Caso: trascina maniglia sud verso il basso di 30px
let currentY = 330;
let dy = currentY - startY; // +30
let activeDir = "s";
let delta = activeDir === "s" ? dy : -dy; // +30
let newH = Math.max(minH, Math.min(maxH, initH + delta * 2)); // 660
assert.strictEqual(newH, 660, "Ridimensionamento verso il basso espande l'altezza a 660px");

// Caso: trascina maniglia nord verso l'alto di 40px (currentY = 260)
currentY = 260;
dy = currentY - startY; // -40
activeDir = "n";
delta = activeDir === "s" ? dy : -dy; // +40
newH = Math.max(minH, Math.min(maxH, initH + delta * 2)); // 680
assert.strictEqual(newH, 680, "Ridimensionamento verso l'alto espande l'altezza a 680px");

// Caso: contrazione oltre il limite minimo (420px)
currentY = 450;
dy = currentY - startY; // +150
activeDir = "n"; // spingendo la maniglia nord verso il basso
delta = activeDir === "s" ? dy : -dy; // -150
newH = Math.max(minH, Math.min(maxH, initH + delta * 2)); // 600 - 300 = 300 -> clamp a 420
assert.strictEqual(newH, 420, "Clamp di sicurezza all'altezza minima di 420px");

console.log("  [PASS] Calcolo bidirezionale e clamping altezza (420px - 92vh) validato al 100%");

console.log("\nDictation Config & Hierarchy Tests: TUTTI I 7 TEST SUPERATI CON SUCCESSO!");
