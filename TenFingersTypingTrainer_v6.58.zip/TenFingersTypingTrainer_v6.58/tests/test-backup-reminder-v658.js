#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function assert(cond, msg) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exit(1);
  }
}

const toolbarJs = fs.readFileSync(path.join(root, "js/app/controller/metodi-toolbar-modalita.js"), "utf8");
const layoutJs = fs.readFileSync(path.join(root, "js/app/controller/metodi-finestre-layout.js"), "utf8");
const inputJs = fs.readFileSync(path.join(root, "js/app/controller/metodi-input-digitazione.js"), "utf8");
const interrJs = fs.readFileSync(path.join(root, "js/app/controller/metodi-interrogazione.js"), "utf8");
const coreJs = fs.readFileSync(path.join(root, "js/app/controller/controller-core.js"), "utf8");
const helpHtml = fs.readFileSync(path.join(root, "help.html"), "utf8");
const manualMd = fs.readFileSync(path.join(root, "docs/MANUALE_UTENTE_v6.58.md"), "utf8");

assert(
  toolbarJs.includes("Sessione di digitazione libera registrata con successo!\\n\\nPremere CTRL+SHIFT+X per avviare un nuovo esercizio."),
  "Messaggio Digitazione Libera con CTRL+SHIFT+X mancante in metodi-toolbar-modalita.js",
);
assert(coreJs.includes("this.backupReminderIntervalMs = 10 * 60 * 1000;"), "Intervallo configurabile backupReminderIntervalMs mancante in controller-core.js");
assert(inputJs.includes("this.maybeShowBackupReminderToast()"), "Chiamata maybeShowBackupReminderToast mancante in metodi-input-digitazione.js");
assert(toolbarJs.includes("this.maybeShowBackupReminderToast()"), "Chiamata maybeShowBackupReminderToast mancante in metodi-toolbar-modalita.js");
assert(interrJs.includes("this.maybeShowBackupReminderToast()"), "Chiamata maybeShowBackupReminderToast mancante in metodi-interrogazione.js");
assert(helpHtml.includes('id="avvisi-fondamentali"') && helpHtml.includes("Esporta Profilo") && helpHtml.includes("ALT + SHIFT"), "Sezione prioritaria in help.html incompleta");
assert(manualMd.includes("Esporta Profilo") && manualMd.includes("CTRL + Rotella del mouse") && manualMd.includes("ALT + SHIFT"), "Manuale utente v6.58 incompleto");

// Verifica comportamentale del throttling di maybeShowBackupReminderToast
const toastCalls = [];
const sandbox = {
  document: {
    getElementById: () => null,
    createElement: () => ({ style: {} }),
    body: { appendChild: () => {} },
  },
  window: {},
  AppController: function () {},
  setTimeout,
  clearTimeout,
};
sandbox.AppController.prototype = {};
vm.runInNewContext(layoutJs, sandbox);

const ctrl = Object.create(sandbox.AppController.prototype);
ctrl.backupReminderIntervalMs = 10 * 60 * 1000;
ctrl._lastBackupReminderAt = 0;
ctrl.showNotificationToast = (msg, icon, dur) => toastCalls.push({ msg, icon, dur });

const t0 = 1_000_000;
assert(ctrl.maybeShowBackupReminderToast(t0) === true, "Il primo completamento della sessione deve mostrare il Toast");
assert(ctrl.maybeShowBackupReminderToast(t0 + 5 * 60 * 1000) === false, "Prima di 10 minuti il Toast NON deve ripetersi");
assert(ctrl.maybeShowBackupReminderToast(t0 + 10 * 60 * 1000) === true, "Dopo 10 minuti il Toast deve ripetersi");
assert(toastCalls.length === 2, "Devono risultare esattamente 2 chiamate Toast");
assert(toastCalls[0].dur === 5000, "La durata del Toast di backup deve essere 5000 ms");
assert(
  toastCalls[0].msg === "Effettuare il Backup periodico dei dati di TUTTI i dati dell'applicazione: Profilo/StatoAvanzamento/Statistiche/Interrogazione/Configurazione",
  "Testo esatto del Toast di backup non corrispondente",
);

console.log("PASS: test-backup-reminder-v658 verificato.");
