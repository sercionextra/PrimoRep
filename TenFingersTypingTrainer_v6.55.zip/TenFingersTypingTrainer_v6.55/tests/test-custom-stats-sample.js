#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const root = path.resolve(__dirname, "..");
const elements = {};

function makeElement(id, tagName = "div") {
  return {
    id,
    tagName: tagName.toUpperCase(),
    style: {},
    classList: {
      _classes: new Set(),
      add(c) { this._classes.add(c); },
      remove(c) { this._classes.delete(c); },
      toggle(c, force) {
        if (force === undefined) {
          if (this._classes.has(c)) this._classes.delete(c);
          else this._classes.add(c);
        } else if (force) this._classes.add(c);
        else this._classes.delete(c);
      },
      contains(c) { return this._classes.has(c); },
    },
    checked: false,
    disabled: false,
    value: "",
    innerText: "",
    innerHTML: "",
    textContent: "",
    title: "",
    clientWidth: 800,
    clientHeight: 240,
    appendChild() {},
    setAttribute() {},
    getAttribute() { return ""; },
    querySelectorAll() { return []; },
    querySelector() { return null; },
    addEventListener() {},
    focus() {},
  };
}

const sandbox = {
  console,
  KEY_MAP: {},
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
    createElement: (tag) => makeElement("anon_" + Math.random(), tag),
    body: { appendChild() {}, classList: { add() {}, remove() {}, toggle() {} }, style: {} },
    documentElement: { style: { setProperty() {} }, classList: { add() {}, remove() {}, toggle() {} } },
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  navigator: {},
  alert() {},
  confirm() { return false; },
  prompt() { return null; },
};

sandbox.window = sandbox;
vm.createContext(sandbox);

function loadScript(relPath) {
  const code = fs.readFileSync(path.join(root, relPath), "utf8");
  vm.runInContext(code, sandbox, { filename: relPath });
}

loadScript("js/domain/helpers.js");
loadScript("js/engines/typing-engine.js");
loadScript("js/analytics/statistics-manager.js");
loadScript("js/app/controller/controller-core.js");
loadScript("js/app/controller/metodi-profili-modali.js");
loadScript("js/app/controller/metodi-toolbar-modalita.js");

const AppController = vm.runInContext("AppController", sandbox);
const TypingEngine = vm.runInContext("TypingEngine", sandbox);
const StatisticsManager = vm.runInContext("StatisticsManager", sandbox);

// Mock minimale per testare il contratto Controller <-> TypingEngine <-> StatisticsManager
const standardLessons = [
  { name: "Base Home Row", phrases: ["asdf jklò"] },
];
const customLessons = [
  { name: "Mio Testo Custom", phrases: ["ciao mondo custom"] },
];

const profile = {
  CustomText: "# Mio Testo Custom\nciao mondo custom",
  Campioni: [],
  Caratteri: [],
};

const profileMgr = {
  profile,
  defaultCustomText: "",
  saveProfile() { return true; },
};

const audio = { setMode() {}, setVolume() {}, playKey() {}, playError() {} };
const phonemeEng = {};

const typingEng = new TypingEngine(standardLessons, profileMgr, audio, phonemeEng);
assert.strictEqual(typingEng.lessonsSource, "standard", "lessonsSource iniziale deve essere standard");

// Simula AppController con i metodi reali caricati sul prototype
const ctrl = Object.create(AppController.prototype);
ctrl.standardLessons = standardLessons;
ctrl.customLessons = customLessons;
ctrl.lessons = standardLessons;
ctrl.activeLessonsSource = "standard";
ctrl.typingEng = typingEng;
ctrl.profileMgr = profileMgr;
let startExerciseCalls = 0;
ctrl.startExercise = () => { startExerciseCalls++; };
ctrl.setControlEnabled = () => {};
ctrl.updateFonemiDropdownSummary = () => {};

// 1. Esercizio Standard in mode 0 -> TipoCampione: 1, titolo "Lezione ..."
typingEng.mode = 0;
typingEng.originText = "asdf jklò";
typingEng.startTime = Date.now() - 10000;
typingEng.countErrors = 0;
typingEng.recordCompletedSample();

assert.strictEqual(profile.Campioni.length, 1);
assert.strictEqual(profile.Campioni[0].TipoCampione, 1, "Standard Phrases deve registrare TipoCampione 1");
assert.ok(profile.Campioni[0].Esercizio.startsWith("Lezione 1:"), "Titolo standard deve iniziare con Lezione 1:");

// 2. Commutazione a Phrases - Custom -> TipoCampione: 2, titolo "Custom ..."
ctrl.setLessonsSource("custom");
assert.strictEqual(ctrl.activeLessonsSource, "custom");
assert.strictEqual(typingEng.lessonsSource, "custom");
assert.strictEqual(startExerciseCalls, 1);

typingEng.originText = "ciao mondo custom";
typingEng.startTime = Date.now() - 10000;
typingEng.countErrors = 1;
typingEng.recordCompletedSample();

assert.strictEqual(profile.Campioni.length, 2);
assert.strictEqual(profile.Campioni[1].TipoCampione, 2, "Phrases - Custom deve registrare TipoCampione 2");
assert.ok(profile.Campioni[1].Esercizio.startsWith("Custom 1:"), "Titolo custom deve iniziare con Custom 1:");

// 3. Verifica filtro StatisticsManager per solo Custom (value=2)
const statsMgr = new StatisticsManager(profileMgr);
statsMgr.filterTypes = [2];
statsMgr.renderSpeedChart();
assert.strictEqual(statsMgr.currentFilteredSamples.length, 1, "Il filtro Custom [2] deve restituire esattamente il campione custom");
assert.strictEqual(statsMgr.currentFilteredSamples[0].TipoCampione, 2);

// 4. Passaggio a mode !== 0 (es. 3 = All Chars, 5 = Random Phrase) deve resettare a standard senza doppio startExercise
typingEng.mode = 3;
ctrl.updateModeUI();
assert.strictEqual(ctrl.activeLessonsSource, "standard", "mode !== 0 deve forzare reset activeLessonsSource a standard");
assert.strictEqual(typingEng.lessonsSource, "standard", "mode !== 0 deve forzare reset typingEng.lessonsSource a standard");
assert.strictEqual(startExerciseCalls, 1, "updateModeUI non deve invocare un startExercise extra");

ctrl.setLessonsSource("custom");
assert.strictEqual(startExerciseCalls, 2);
typingEng.mode = 5;
ctrl.updateModeUI();
assert.strictEqual(ctrl.activeLessonsSource, "standard", "mode 5 deve forzare reset activeLessonsSource a standard");
assert.strictEqual(typingEng.lessonsSource, "standard", "mode 5 deve forzare reset typingEng.lessonsSource a standard");
assert.strictEqual(startExerciseCalls, 2, "updateModeUI non deve invocare startExercise in mode 5");

console.log("PASS: test-custom-stats-sample.js (TipoCampione 2, titolo Custom, filtro StatisticsManager e reset mode !== 0)");
