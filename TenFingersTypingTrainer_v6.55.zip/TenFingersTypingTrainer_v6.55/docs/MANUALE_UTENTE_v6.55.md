# Manuale Utente TenFingersTypingTrainer v6.55

Questa guida integra il manuale della versione 6.54 con gli aggiornamenti introdotti nella versione 6.55.

## 1. Mantenimento dei colori e filtro rapido dal periodo selezionato
- **Colori sempre preservati:** quando deselezioni uno o più campioni sul grafico delle velocità (cliccando una terza volta sul grafico o completando un'operazione), ciascun pallino ritrova esattamente il colore originale della propria modalità senza bordo bianco.
- **Pulsante "Filtra Periodo Selezione":** quando uno o più campioni sono selezionati sul grafico, accanto ai pulsanti di eliminazione compare il pulsante **"Filtra Periodo Selezione"**. Cliccandolo, i campi **Inizio (Data/Ora)** e **Fine (Data/Ora)** vengono impostati automaticamente sull'intervallo dei campioni selezionati (con precisione al minuto), mostrando solo quel periodo e nascondendo tutti gli altri campioni. Per tornare alla vista completa è sufficiente premere **"Reset Periodo"**.
