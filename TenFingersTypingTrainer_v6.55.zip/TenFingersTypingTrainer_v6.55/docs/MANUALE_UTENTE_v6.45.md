# Manuale Utente TenFingersTypingTrainer v6.45

Questa guida integra il manuale della versione 6.44 con l'aggiornamento introdotto nella versione 6.45.

## 1. Statistiche per gli esercizi "Phrases - Custom"
Quando attivi la sorgente **Custom** nella barra degli strumenti (tramite il pulsante di commutazione Standard/Custom o salvando un testo dall'**Editor Custom**) ed esegui le frasi personalizzate:
- Ogni frase completata viene registrata automaticamente nella categoria **Custom**.
- Nella finestra **Statistiche** (grafico delle velocità), puoi spuntare o deselezionare la casella **Custom** per visualizzare o isolare l'andamento delle tue esercitazioni personalizzate separatamente dalle lezioni standard (**Phrases**).
- Passando il mouse sui punti del grafico, gli esercizi personalizzati mostrano il prefisso **Custom** seguito dal titolo della sezione.
- Se cambi modalità passando da **Phrases** a un'altra modalità (ad esempio *Random*, *All Chars* o *Random Phrase*), il programma torna automaticamente alla sorgente **Standard**.

## 2. Funzionalità confermate dalla versione 6.44
Tutte le funzioni di **🎓 Interrogazione su Piano di Studio**, **📈 Mostra storico** e **📊 Classifica Urgenza** descritte nel [Manuale Utente v6.44](MANUALE_UTENTE_v6.44.md) restano invariate.
