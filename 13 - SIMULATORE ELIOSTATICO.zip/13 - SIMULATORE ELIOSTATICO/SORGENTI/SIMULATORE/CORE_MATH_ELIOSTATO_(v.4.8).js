/**
 * =========================================================================================
 * CORE_MATH_ELIOSTATO_(v.4.8).js
 * 
 * Master Blueprint Ingegneristico - Libreria Standalone di Calcolo Fisico-Matematico
 * Robot Parallelo a Cavi (CDPR) Sottovincolato a 3 Cavi per Eliostato Solare
 * 
 * Release v.4.8 (Consolidamento Specifiche, Taratura a 3 Punti & Watchdog 0.50 N):
 *  - MODELLO COMPLETO SANDWICH POLICARBONATO-ACCIAIO: Calcolo analitico del baricentro (z_G)
 *    e del braccio di leva verticale (Z_B_OFFSET = z_pin - z_G) sui perni di aggancio (+4.92 mm).
 *  - COMPENSAZIONE STATICA DEL MOMENTO DI RIPRISTINO GRAVITAZIONALE: La cinematica inversa (IK)
 *    e l'equilibrio Levenberg-Marquardt compensano l'effetto pendolo indotto dall'offset baricentrico.
 *  - ARCHITETTURA ZERO-GARBAGE COLLECTION (Zero-GC) RIGOROSA: Preallocazione integrale dei
 *    buffer matriciali e vettoriali nello scratchpad numerico, eliminando ogni allocazione
 *    dinamica all'interno dei cicli a 60 FPS e nelle iterazioni del solutore.
 *  - GESTIONE AVVOLGIMENTO CABESTANO A 6 SPIRE CON PETTINE: Fune Dyneema SK78 d=1.20 mm,
 *    R_eff = 13.10 mm, 38877.54 passi/m, soglia di slittamento Eytelwein blindata a 1.41 g.
 *  - CORREZIONE RIFRAZIONE ATMOSFERICA DI BENNETT (1982) ad alta precisione per h > -0.5°.
 *  - CINEMATICA IBRIDA A DUE STADI 100% AUTOMATICA: Fast-Path deterministico C^1 con
 *    Watchdog fisico di sicurezza tarato a T_SAFE_MIN = 0.50 N per auto-fallback su Opzione B.
 *  - CINEMATICA DIRETTA PBD STABILIZZATA A ZERO-DRIFT: Riproiezione corretta dal baricentro pG.
 *  - TARATURA OTTICA ESTESA: Supporto duale a 2 punti e a 3 punti con residuo RMS e concordanza 3D.
 * =========================================================================================
 */

(function (global, factory) {
    if (typeof exports === 'object' && typeof module !== 'undefined') {
        module.exports = factory();
    } else if (typeof define === 'function' && define.amd) {
        define(factory);
    } else {
        global.HeliostatCDPR = factory();
    }
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    // =========================================================================
    // 1. COSTANTI FISICHE E PARAMETRI GEOMETRICI NOMINALI
    // =========================================================================
    const DEFAULTS = {
        R_A: 0.30,                 // Raggio pulegge fisse superiori a parete (m)
        r_b: 0.15,                 // Raggio vertici specchio mobile triangolare (m)

        // Geometria e Fisica del Sandwich Policarbonato + Piastra Zavorra Acciaio
        T_POLYCARBONATE: 0.0025,   // Spessore lastra policarbonato specchio (m, 2.5 mm)
        T_STEEL: 0.0025,           // Spessore piastra zavorra in acciaio (m, 2.5 mm)
        RHO_POLYCARBONATE: 1200.0, // Densità volumetrica policarbonato (kg/m^3)
        RHO_STEEL: 7850.0,         // Densità volumetrica acciaio (kg/m^3)
        Z_PIN_HEAD: 0.0040,        // Quota punto di attacco fune sul perno rispetto all'interfaccia (m)
        Z_B_OFFSET: null,          // Offset verticale perno-baricentro: se null, calcolato analiticamente (m)

        PLATE_THICKNESS: 0.005,    // Spessore complessivo sandwich (m, 5 mm)
        H_NOMINAL: 0.35,           // Quota baricentro nominale di riposo e STOW (m, pari a -0.35 m)
        H_MAX_DEPTH: 0.42,         // Quota massima Z-adattativa per forti inclinazioni G_min (m, pari a -0.42 m)
        H_MIN_DEPTH: 0.30,         // Quota minima di profondità baricentro G_max (m, pari a -0.30 m)
        M_TOTAL: 1.0,              // Massa complessiva specchio + piastra zavorra (kg)
        G_ACC: 9.80665,            // Accelerazione gravitazionale standard (m/s^2)
        MU_CAPSTAN: 0.13,          // Coefficiente attrito fune Dyneema su alluminio anodizzato
        WRAP_ANGLE: 12.0 * Math.PI,// 6 spire complete di avvolgimento attorno al tamburo con pettine (rad)
        D_CABLE: 0.0012,           // Diametro fune Dyneema SK78 (m, 1.20 mm)
        M_CW: 0.19,                // Massa contrappeso passivo per cavo (kg)
        R_CYLINDER: 0.0125,        // Raggio nominale tamburo cabestano (m, diametro 25mm)
        R_CYLINDER_EFF: 0.0131,    // Raggio primitivo efficace: R_CYLINDER + D_CABLE/2 (m, 13.10 mm)
        STEPS_PER_REV: 3200,       // Risoluzione stepper: 200 passi/giro x 16 microstep
        STEPS_PER_METER: 38877.54, // Risoluzione lineare: STEPS_PER_REV / (2*pi*R_CYLINDER_EFF) (passi/m)
        TARGET_DISTANCE: 40.0,     // Distanza nominale bersaglio ricevitore solare (m)

        // Modello Elastico Cavi e Opzioni di Controllo
        ENABLE_CABLE_ELASTICITY: false,      // Disattivato di default per retrocompatibilità pura
        ENABLE_ATMOSPHERIC_REFRACTION: true, // Correzione rifrazione atmosferica di Bennett (1982)
        AUTO_OPTIMIZE_Z: true,               // Fallback automatico 100% autonomo: attiva Opzione B se T_min < T_SAFE_MIN
        T_SAFE_MIN: 0.50,                    // Soglia sentinella prudenziale di tensione minima cavo (N)
        CABLE_EA: 113100.0,                  // Rigidezza assiale EA (N) per Dyneema SK78 d=1.20 mm

        CABLE_ANGLES: [            // Angoli geometrici pulegge nel piano orizzontale (rad)
            Math.PI / 2.0,         // Cavo 1: Nord (90°)
            7.0 * Math.PI / 6.0,   // Cavo 2: Sud-Ovest (210°)
            11.0 * Math.PI / 6.0   // Cavo 3: Sud-Est (330°)
        ]
    };

    // Tensione minima assoluta per scongiurare lo slittamento sul cabestano (Eytelwein)
    DEFAULTS.T_MIN_SLIP = (DEFAULTS.M_CW * DEFAULTS.G_ACC) / Math.exp(DEFAULTS.MU_CAPSTAN * DEFAULTS.WRAP_ANGLE);

    // =========================================================================
    // 2. LIVELLO 1: VMATH (ALGEBRA VETTORIALE/MATRICIALE ZERO-GC RIGOROSA)
    // =========================================================================
    const VMath = {
        create: (x = 0, y = 0, z = 0) => [x, y, z],
        clone: (v, out = [0, 0, 0]) => { out[0] = v[0]; out[1] = v[1]; out[2] = v[2]; return out; },
        set: (out, x, y, z) => { out[0] = x; out[1] = y; out[2] = z; return out; },

        add: (a, b, out = [0, 0, 0]) => {
            out[0] = a[0] + b[0]; out[1] = a[1] + b[1]; out[2] = a[2] + b[2];
            return out;
        },
        sub: (a, b, out = [0, 0, 0]) => {
            out[0] = a[0] - b[0]; out[1] = a[1] - b[1]; out[2] = a[2] - b[2];
            return out;
        },
        scale: (a, s, out = [0, 0, 0]) => {
            out[0] = a[0] * s; out[1] = a[1] * s; out[2] = a[2] * s;
            return out;
        },
        dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
        cross: (a, b, out = [0, 0, 0]) => {
            const x = a[1] * b[2] - a[2] * b[1];
            const y = a[2] * b[0] - a[0] * b[2];
            const z = a[0] * b[1] - a[1] * b[0];
            out[0] = x; out[1] = y; out[2] = z;
            return out;
        },
        norm: (a) => Math.hypot(a[0], a[1], a[2]),
        dist: (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]),
        normalize: (a, out = [0, 0, 0]) => {
            const n = Math.hypot(a[0], a[1], a[2]);
            if (n > 1e-12) {
                out[0] = a[0] / n; out[1] = a[1] / n; out[2] = a[2] / n;
            } else {
                out[0] = 0; out[1] = 0; out[2] = 1;
            }
            return out;
        },
        angleBetween: (a, b) => {
            const d = VMath.dot(a, b) / (Math.max(1e-12, VMath.norm(a) * VMath.norm(b)));
            return Math.acos(Math.max(-1.0, Math.min(1.0, d)));
        },

        /**
         * Calcola la matrice di rotazione Möller-Hughes con protezione singolarità (nz -> -1)
         * e supporto completo outR preallocato per Zero-GC.
         */
        rotationMatrixMollerHughes: (n_des, psi = 0, outR = null) => {
            const n = VMath.normalize(n_des);
            const c = n[2];
            const v0 = -n[1], v1 = n[0];

            let R0_00, R0_01, R0_02, R0_10, R0_11, R0_12, R0_20, R0_21, R0_22;
            if (c > -0.99999) {
                const factor = 1.0 / (1.0 + c);
                R0_00 = 1.0 - v1 * v1 * factor;
                R0_01 = v0 * v1 * factor;
                R0_02 = v1;
                R0_10 = v0 * v1 * factor;
                R0_11 = 1.0 - v0 * v0 * factor;
                R0_12 = -v0;
                R0_20 = -v1;
                R0_21 = v0;
                R0_22 = c;
            } else {
                // Caso limite degenere nz = -1 (ribaltamento specchio 180°)
                R0_00 = 1.0; R0_01 = 0.0; R0_02 = 0.0;
                R0_10 = 0.0; R0_11 = -1.0; R0_12 = 0.0;
                R0_20 = 0.0; R0_21 = 0.0; R0_22 = -1.0;
            }

            const c_psi = Math.cos(psi);
            const s_psi = Math.sin(psi);

            const R = outR || [ [0,0,0], [0,0,0], [0,0,0] ];
            R[0][0] =  R0_00 * c_psi + R0_01 * s_psi;
            R[0][1] = -R0_00 * s_psi + R0_01 * c_psi;
            R[0][2] =  R0_02;

            R[1][0] =  R0_10 * c_psi + R0_11 * s_psi;
            R[1][1] = -R0_10 * s_psi + R0_11 * c_psi;
            R[1][2] =  R0_12;

            R[2][0] =  R0_20 * c_psi + R0_21 * s_psi;
            R[2][1] = -R0_20 * s_psi + R0_21 * c_psi;
            R[2][2] =  R0_22;

            return R;
        },

        matVecMul3: (R, v, out = [0, 0, 0]) => {
            const x = R[0][0]*v[0] + R[0][1]*v[1] + R[0][2]*v[2];
            const y = R[1][0]*v[0] + R[1][1]*v[1] + R[1][2]*v[2];
            const z = R[2][0]*v[0] + R[2][1]*v[1] + R[2][2]*v[2];
            out[0] = x; out[1] = y; out[2] = z;
            return out;
        },

        solveLinear3x3: (A, b, out = [0, 0, 0]) => {
            const d = A[0][0]*(A[1][1]*A[2][2] - A[1][2]*A[2][1])
                    - A[0][1]*(A[1][0]*A[2][2] - A[1][2]*A[2][0])
                    + A[0][2]*(A[1][0]*A[2][1] - A[1][1]*A[2][0]);
            if (Math.abs(d) < 1e-12) return null;
            const invD = 1.0 / d;

            out[0] = (b[0]*(A[1][1]*A[2][2] - A[1][2]*A[2][1])
                    - A[0][1]*(b[1]*A[2][2] - A[1][2]*b[2])
                    + A[0][2]*(b[1]*A[2][1] - A[1][1]*b[2])) * invD;

            out[1] = (A[0][0]*(b[1]*A[2][2] - A[1][2]*b[2])
                    - b[0]*(A[1][0]*A[2][2] - A[1][2]*A[2][0])
                    + A[0][2]*(A[1][0]*b[2] - b[1]*A[2][0])) * invD;

            out[2] = (A[0][0]*(A[1][1]*b[2] - b[1]*A[2][1])
                    - A[0][1]*(A[1][0]*b[2] - b[1]*A[2][0])
                    + b[0]*(A[1][0]*A[2][1] - A[1][1]*A[2][0])) * invD;

            return out;
        }
    };

    // =========================================================================
    // 3. LIVELLO 2: ASTRONOMIA SOLARE PSA CON CALCOLO ORARI ALBA/TRAMONTO
    // =========================================================================
    const AstronomySolver = {
        dateToJulianDay: (date) => {
            let year = date.getUTCFullYear();
            let month = date.getUTCMonth() + 1;
            const day = date.getUTCDate() + (date.getUTCHours() + (date.getUTCMinutes() + (date.getUTCSeconds() + date.getUTCMilliseconds()/1000.0)/60.0)/60.0)/24.0;
            if (month <= 2) { year -= 1; month += 12; }
            const A = Math.floor(year / 100);
            const B = 2 - A + Math.floor(A / 4);
            return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
        },

        calculateSunPosition: (dateOrEpoch, latDeg, lonDeg) => {
            const date = (dateOrEpoch instanceof Date) ? dateOrEpoch : new Date(dateOrEpoch);
            const JD = AstronomySolver.dateToJulianDay(date);
            const n = JD - 2451545.0;

            const deg2rad = Math.PI / 180.0;
            const rad2deg = 180.0 / Math.PI;

            let L = (280.460 + 0.9856474 * n) % 360.0;
            if (L < 0) L += 360.0;
            let g = (357.528 + 0.9856003 * n) % 360.0;
            if (g < 0) g += 360.0;

            const lambda = L + 1.915 * Math.sin(g * deg2rad) + 0.020 * Math.sin(2.0 * g * deg2rad);
            const epsilon = 23.439 - 0.0000004 * n;

            const sinDelta = Math.sin(epsilon * deg2rad) * Math.sin(lambda * deg2rad);
            const delta = Math.asin(Math.max(-1.0, Math.min(1.0, sinDelta)));
            const alpha = Math.atan2(Math.cos(epsilon * deg2rad) * Math.sin(lambda * deg2rad), Math.cos(lambda * deg2rad));

            let gmst = (280.46061837 + 360.98564736629 * n) % 360.0;
            if (gmst < 0) gmst += 360.0;
            
            let lmstDeg = (gmst + lonDeg) % 360.0;
            if (lmstDeg < 0) lmstDeg += 360.0;
            const lmst = lmstDeg * deg2rad;

            let omega = lmst - alpha;
            omega = Math.atan2(Math.sin(omega), Math.cos(omega));

            const phi = latDeg * deg2rad;
            const cosPhi = Math.cos(phi);
            const sinAlpha = Math.sin(phi) * Math.sin(delta) + cosPhi * Math.cos(delta) * Math.cos(omega);
            const elevation = Math.asin(Math.max(-1.0, Math.min(1.0, sinAlpha)));

            const cosElev = Math.cos(elevation);
            let azimuth = Math.PI;
            if (cosElev > 1e-6 && Math.abs(cosPhi) > 1e-6) {
                const cosGamma = (Math.sin(delta) - Math.sin(phi) * Math.sin(elevation)) / (cosPhi * cosElev);
                azimuth = Math.acos(Math.max(-1.0, Math.min(1.0, cosGamma)));
                if (Math.sin(omega) > 0) {
                    azimuth = 2.0 * Math.PI - azimuth;
                }
            }

            // Correzione rifrazione atmosferica di Bennett (1982) ad alta precisione
            const hGeomDeg = elevation * rad2deg;
            let refrArcmin = 0.0;
            if (hGeomDeg > -0.833) {
                // Formula Bennett (1982) per condizioni standard (1010 hPa, 10°C, precisione ~0.07 primi d'arco)
                const denom = Math.tan((hGeomDeg + 10.3 / (hGeomDeg + 5.11)) * deg2rad);
                if (denom > 1e-5) {
                    refrArcmin = 1.02 / denom;
                }
            }
            const apparentElevationDeg = hGeomDeg + refrArcmin / 60.0;
            const apparentElevationRad = apparentElevationDeg * deg2rad;

            // Il vettore solare ottico effettivo usa l'elevazione apparente rifratta se sopra orizzonte
            const effElevRad = (hGeomDeg > -0.5) ? apparentElevationRad : elevation;

            // Vettore Sole nel sistema geografico ENU [Est, Nord, Zenit]
            const sunVector = [
                Math.cos(effElevRad) * Math.sin(azimuth),
                Math.cos(effElevRad) * Math.cos(azimuth),
                Math.sin(effElevRad)
            ];

            return {
                elevationRad: elevation,
                azimuthRad: azimuth,
                elevationDeg: elevation * rad2deg,
                apparentElevationDeg: apparentElevationDeg,
                apparentElevationRad: apparentElevationRad,
                refractionArcmin: refrArcmin,
                azimuthDeg: azimuth * rad2deg,
                sunVector: VMath.normalize(sunVector)
            };
        },

        computeRiseSetData: (year, dayOfYear, latDeg, lonDeg, tzOffsetHours = 2.0) => {
            const midDayDate = new Date(Date.UTC(year, 0, dayOfYear, 12, 0, 0));
            const JD = AstronomySolver.dateToJulianDay(midDayDate);
            const n = JD - 2451545.0;
            const deg2rad = Math.PI / 180.0;

            let L = (280.460 + 0.9856474 * n) % 360.0;
            if (L < 0) L += 360.0;
            let g = (357.528 + 0.9856003 * n) % 360.0;
            if (g < 0) g += 360.0;
            const lambda = L + 1.915 * Math.sin(g * deg2rad) + 0.020 * Math.sin(2.0 * g * deg2rad);
            const epsilon = 23.439 - 0.0000004 * n;
            const delta = Math.asin(Math.sin(epsilon * deg2rad) * Math.sin(lambda * deg2rad));
            const alpha = Math.atan2(Math.cos(epsilon * deg2rad) * Math.sin(lambda * deg2rad), Math.cos(lambda * deg2rad));

            let alphaDeg = alpha * (180.0 / Math.PI);
            if (alphaDeg < 0) alphaDeg += 360.0;
            const eotMinutes = 4.0 * (L - alphaDeg);

            const phi = latDeg * deg2rad;
            const cosPhi = Math.cos(phi);
            const h0 = -0.8333 * deg2rad; // Rifrazione atmosferica + raggio semidisco solare
            
            let azRise = 90.0, azSet = 270.0;
            let timeRiseStr = "--:--", timeSetStr = "--:--";

            if (Math.abs(cosPhi) > 1e-6) {
                const cosH0 = (Math.sin(h0) - Math.sin(phi) * Math.sin(delta)) / (cosPhi * Math.cos(delta));
                if (cosH0 >= -1.0 && cosH0 <= 1.0) {
                    const H0_rad = Math.acos(cosH0);
                    const H0_hours = H0_rad * (12.0 / Math.PI);

                    const cosAz = (Math.sin(delta) - Math.sin(phi) * Math.sin(h0)) / (cosPhi * Math.cos(h0));
                    const azRiseRad = Math.acos(Math.max(-1.0, Math.min(1.0, cosAz)));
                    azRise = azRiseRad * (180.0 / Math.PI);
                    azSet = 360.0 - azRise;

                    const transitUtcHours = 12.0 - (lonDeg / 15.0) - (eotMinutes / 60.0);
                    const riseUtc = transitUtcHours - H0_hours;
                    const setUtc = transitUtcHours + H0_hours;

                    const toHM = (decHours) => {
                        let localH = (decHours + tzOffsetHours + 24.0) % 24.0;
                        let h = Math.floor(localH);
                        let m = Math.floor((localH % 1.0) * 60.0);
                        return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`;
                    };

                    timeRiseStr = toHM(riseUtc);
                    timeSetStr = toHM(setUtc);
                }
            }
            return { azRise, azSet, timeRiseStr, timeSetStr, deltaRad: delta };
        }
    };

    // =========================================================================
    // 4. LIVELLO 3: CINEMATICA CDPR (SANDWICH COMPLETO, IK & PBD ZERO-GC)
    // =========================================================================
    class CDPRKinematics {
        constructor(config = {}) {
            this.cfg = Object.assign({}, DEFAULTS, config);
            this.L_SIDE = this.cfg.r_b * Math.sqrt(3.0);
            this.L_0_NOMINAL = Math.sqrt(Math.pow(this.cfg.R_A - this.cfg.r_b, 2) + Math.pow(this.cfg.H_NOMINAL, 2));

            // Calcolo analitico dell'offset baricentrico Z del sandwich se non specificato manualmente
            if (this.cfg.Z_B_OFFSET !== null && this.cfg.Z_B_OFFSET !== undefined) {
                this.Z_B_OFFSET = Number(this.cfg.Z_B_OFFSET);
            } else {
                const t_pc = this.cfg.T_POLYCARBONATE;
                const t_st = this.cfg.T_STEEL;
                const s_pc = this.cfg.RHO_POLYCARBONATE * t_pc;
                const s_st = this.cfg.RHO_STEEL * t_st;
                // z=0 all'interfaccia. Policarbonato sopra (+t_pc/2), Acciaio sotto (-t_st/2)
                const zG = (s_pc * (t_pc * 0.5) - s_st * (t_st * 0.5)) / (s_pc + s_st);
                // Braccio di leva = quota attacco perno - quota baricentro
                this.Z_B_OFFSET = this.cfg.Z_PIN_HEAD - zG;
            }

            // Punti di attacco superiori fissi a parete A_i (Z = 0)
            this.A_pts = this.cfg.CABLE_ANGLES.map(ang => [
                this.cfg.R_A * Math.cos(ang),
                this.cfg.R_A * Math.sin(ang),
                0.0
            ]);

            // Punti locali b_i: vertici dei 3 perni sul sandwich con quota Z_B_OFFSET rispetto al baricentro G
            this.b_pts = this.cfg.CABLE_ANGLES.map(ang => [
                this.cfg.r_b * Math.cos(ang),
                this.cfg.r_b * Math.sin(ang),
                this.Z_B_OFFSET
            ]);

            // Coordinate della superficie a specchio ottico (z_mirror = 0 all'interfaccia)
            this.b_mirror_pts = this.cfg.CABLE_ANGLES.map(ang => [
                this.cfg.r_b * Math.cos(ang),
                this.cfg.r_b * Math.sin(ang),
                0.0
            ]);

            // Scratchpad Zero-GC dedicato per IK Levenberg-Marquardt
            this._ikScratch = {
                r: [[0,0,0], [0,0,0], [0,0,0]],
                p: [[0,0,0], [0,0,0], [0,0,0]],
                u: [[0,0,0], [0,0,0], [0,0,0]],
                L_vec: [0,0,0],
                tmp: [0,0,0],
                R: [[0,0,0], [0,0,0], [0,0,0]],
                J: [ [0,0,0], [0,0,0], [0,0,0] ],
                A: [ [0,0,0], [0,0,0], [0,0,0] ],
                g: [0, 0, 0],
                dx: [0, 0, 0],
                statePert: [0, 0, 0],
                trialState: [0, 0, 0],
                res0: { F: [0,0,0], T: [0,0,0], isValid: false, isGripOk: false, detU: 0 },
                resPert: { F: [0,0,0], T: [0,0,0], isValid: false, isGripOk: false, detU: 0 },
                resTrial: { F: [0,0,0], T: [0,0,0], isValid: false, isGripOk: false, detU: 0 },
                finalLengths: [0, 0, 0],
                cmdLengths: [0, 0, 0],
                mirrorVertices: [[0,0,0], [0,0,0], [0,0,0]]
            };

            // Scratchpad Zero-GC per relaxForwardKinematics (PBD)
            this._fkScratch = {
                v: [[0,0,0], [0,0,0], [0,0,0]],
                toP: [0,0,0],
                pG: [0,0,0],
                e1: [0,0,0],
                e2: [0,0,0],
                n_plane: [0,0,0],
                vY: [0,0,0],
                vX: [0,0,0]
            };
        }

        computeStaticTensions(u, outObj = null) {
            const u2_x_u3_x = u[1][1] * u[2][2] - u[1][2] * u[2][1];
            const u2_x_u3_y = u[1][2] * u[2][0] - u[1][0] * u[2][2];
            const u2_x_u3_z = u[1][0] * u[2][1] - u[1][1] * u[2][0];

            const detU = u[0][0] * u2_x_u3_x + u[0][1] * u2_x_u3_y + u[0][2] * u2_x_u3_z;

            const res = outObj || { T: [0, 0, 0], detU: 0, isValid: false, isGripOk: false };
            res.detU = detU;

            if (Math.abs(detU) < 1e-6) {
                res.T[0] = 0; res.T[1] = 0; res.T[2] = 0;
                res.isValid = false;
                res.isGripOk = false;
                return res;
            }

            const W = this.cfg.M_TOTAL * this.cfg.G_ACC;
            const invDet = 1.0 / detU;

            const u0_x_u1_z = u[0][0] * u[1][1] - u[0][1] * u[1][0];
            const u2_x_u0_z = u[2][0] * u[0][1] - u[2][1] * u[0][0];

            res.T[0] = W * u2_x_u3_z * invDet;
            res.T[1] = W * u2_x_u0_z * invDet;
            res.T[2] = W * u0_x_u1_z * invDet;

            res.isValid = res.T[0] > 0.05 && res.T[1] > 0.05 && res.T[2] > 0.05;
            res.isGripOk = res.T[0] >= this.cfg.T_MIN_SLIP && res.T[1] >= this.cfg.T_MIN_SLIP && res.T[2] >= this.cfg.T_MIN_SLIP;
            return res;
        }

        // =========================================================================
        // STADIO 1: CINEMATICA INVERSA DETERMINISTICA (Opzione A)
        // =========================================================================
        _solveInverseKinematicsStageA(n_des, zTarget = -this.cfg.H_NOMINAL, applyAdaptiveParabola = true) {
            const sc = this._ikScratch;
            const nd = VMath.normalize(n_des);

            const tiltAngleRad = Math.acos(Math.max(-1.0, Math.min(1.0, nd[2])));
            const tiltDeg = tiltAngleRad * (180.0 / Math.PI);

            let effectiveZ = zTarget;
            if (applyAdaptiveParabola && tiltDeg > 28.0 && Math.abs(zTarget - (-this.cfg.H_NOMINAL)) < 1e-6) {
                const normTilt = Math.min(1.0, (tiltDeg - 28.0) / 22.0);
                effectiveZ = zTarget - (normTilt * normTilt) * (this.cfg.H_MAX_DEPTH - Math.abs(zTarget));
            }

            const evalResidualsFast = (state, curZ, outRes) => {
                const xG = state[0], yG = state[1], psi = state[2];
                VMath.rotationMatrixMollerHughes(nd, psi, sc.R);

                for (let i = 0; i < 3; i++) {
                    VMath.matVecMul3(sc.R, this.b_pts[i], sc.r[i]);
                    sc.p[i][0] = xG + sc.r[i][0];
                    sc.p[i][1] = yG + sc.r[i][1];
                    sc.p[i][2] = curZ + sc.r[i][2];

                    VMath.sub(this.A_pts[i], sc.p[i], sc.L_vec);
                    VMath.normalize(sc.L_vec, sc.u[i]);
                }

                this.computeStaticTensions(sc.u, outRes);

                let tauX = 0.0, tauY = 0.0, tauZ = 0.0;
                for (let i = 0; i < 3; i++) {
                    VMath.cross(sc.r[i], sc.u[i], sc.tmp);
                    tauX += outRes.T[i] * sc.tmp[0];
                    tauY += outRes.T[i] * sc.tmp[1];
                    tauZ += outRes.T[i] * sc.tmp[2];
                }

                outRes.F[0] = tauX;
                outRes.F[1] = tauY;
                outRes.F[2] = tauZ;
                return outRes;
            };

            // Inizializzazione adattativa migliorata con correzione per braccio di leva Z_B_OFFSET
            const initScale = 0.065 + (this.Z_B_OFFSET > 0 ? this.Z_B_OFFSET * 0.5 : 0.0);
            let state = [initScale * nd[0], initScale * nd[1], 0.0];
            let lambda = 1e-3;
            const EPS = 1e-4;
            let converged = false;
            let finalIter = 0;

            for (let iter = 0; iter < 16; iter++) {
                finalIter = iter;
                evalResidualsFast(state, effectiveZ, sc.res0);
                const normF = Math.hypot(sc.res0.F[0], sc.res0.F[1], sc.res0.F[2]);

                if (normF < 1e-5 && sc.res0.isValid) {
                    converged = true;
                    break;
                }

                for (let j = 0; j < 3; j++) {
                    sc.statePert[0] = state[0];
                    sc.statePert[1] = state[1];
                    sc.statePert[2] = state[2];
                    sc.statePert[j] += EPS;

                    evalResidualsFast(sc.statePert, effectiveZ, sc.resPert);
                    for (let i = 0; i < 3; i++) {
                        sc.J[i][j] = (sc.resPert.F[i] - sc.res0.F[i]) / EPS;
                    }
                }

                for (let i = 0; i < 3; i++) {
                    for (let j = 0; j < 3; j++) {
                        let dot = 0.0;
                        for (let k = 0; k < 3; k++) dot += sc.J[k][i] * sc.J[k][j];
                        sc.A[i][j] = dot;
                    }
                    sc.A[i][i] += lambda * (sc.A[i][i] > 1e-4 ? sc.A[i][i] : 1.0);

                    let dotG = 0.0;
                    for (let k = 0; k < 3; k++) dotG += sc.J[k][i] * sc.res0.F[k];
                    sc.g[i] = dotG;
                }

                const dx = VMath.solveLinear3x3(sc.A, sc.g, sc.dx);
                if (!dx) {
                    lambda *= 5.0;
                    continue;
                }

                let stepSize = 1.0;
                let accepted = false;

                for (let b = 0; b < 4; b++) {
                    sc.trialState[0] = state[0] - dx[0] * stepSize;
                    sc.trialState[1] = state[1] - dx[1] * stepSize;
                    sc.trialState[2] = state[2] - dx[2] * stepSize;

                    evalResidualsFast(sc.trialState, effectiveZ, sc.resTrial);
                    const trialNormF = Math.hypot(sc.resTrial.F[0], sc.resTrial.F[1], sc.resTrial.F[2]);

                    if (trialNormF < normF) {
                        state[0] = sc.trialState[0];
                        state[1] = sc.trialState[1];
                        state[2] = sc.trialState[2];
                        lambda = Math.max(1e-5, lambda * 0.5);
                        accepted = true;
                        break;
                    }
                    stepSize *= 0.5;
                }

                if (!accepted) lambda *= 4.0;
            }

            evalResidualsFast(state, effectiveZ, sc.res0);

            // Calcolo lunghezze geometriche nominali
            for (let i = 0; i < 3; i++) {
                sc.finalLengths[i] = VMath.dist(this.A_pts[i], sc.p[i]);
            }

            // Compensazione feed-forward elasticità fune (se abilitata)
            if (this.cfg.ENABLE_CABLE_ELASTICITY && this.cfg.CABLE_EA > 0) {
                for (let i = 0; i < 3; i++) {
                    const deltaL = (sc.res0.T[i] * sc.finalLengths[i]) / this.cfg.CABLE_EA;
                    sc.cmdLengths[i] = sc.finalLengths[i] - deltaL;
                }
            } else {
                sc.cmdLengths[0] = sc.finalLengths[0];
                sc.cmdLengths[1] = sc.finalLengths[1];
                sc.cmdLengths[2] = sc.finalLengths[2];
            }

            // Calcolo vertici effettivi della superficie a specchio (per rendering grafico senza offset perno)
            for (let i = 0; i < 3; i++) {
                VMath.matVecMul3(sc.R, this.b_mirror_pts[i], sc.tmp);
                sc.mirrorVertices[i][0] = state[0] + sc.tmp[0];
                sc.mirrorVertices[i][1] = state[1] + sc.tmp[1];
                sc.mirrorVertices[i][2] = effectiveZ + sc.tmp[2];
            }

            return {
                success: converged || sc.res0.isValid,
                pose: { x_G: state[0], y_G: state[1], z_G: effectiveZ, psi_rad: state[2] },
                lengths: [sc.cmdLengths[0], sc.cmdLengths[1], sc.cmdLengths[2]],
                lengthsNominal: [sc.finalLengths[0], sc.finalLengths[1], sc.finalLengths[2]],
                vertices: [ [...sc.p[0]], [...sc.p[1]], [...sc.p[2]] ],
                mirrorVertices: [ [...sc.mirrorVertices[0]], [...sc.mirrorVertices[1]], [...sc.mirrorVertices[2]] ],
                tensions: [sc.res0.T[0], sc.res0.T[1], sc.res0.T[2]],
                isGripOk: sc.res0.isGripOk,
                iterations: finalIter,
                isZAdapted: Math.abs(effectiveZ - zTarget) > 1e-4,
                zBOffset: this.Z_B_OFFSET
            };
        }

        // =========================================================================
        // STADIO 2 (Opzione B): Ricerca Quota z_G per Massimizzazione Tensione Minima
        // =========================================================================
        solveInverseKinematicsOptimalZ(n_des, zMin = -this.cfg.H_MAX_DEPTH, zMax = -this.cfg.H_MIN_DEPTH, steps = 7) {
            let bestRes = null;
            let maxMinTension = -1e9;
            const stepZ = (zMax - zMin) / (steps - 1);

            for (let i = 0; i < steps; i++) {
                const zTrial = zMin + i * stepZ;
                const res = this._solveInverseKinematicsStageA(n_des, zTrial, false);
                if (res.success) {
                    const minT = Math.min(res.tensions[0], res.tensions[1], res.tensions[2]);
                    if (minT > maxMinTension) {
                        maxMinTension = minT;
                        bestRes = res;
                    }
                }
            }
            if (bestRes) {
                bestRes.tier = "B_OPTIMAL";
                bestRes.isOptimalZ = true;
                return bestRes;
            }
            return this._solveInverseKinematicsStageA(n_des, -this.cfg.H_NOMINAL, true);
        }

        // =========================================================================
        // MASTER SOLVER 100% AUTOMATICO (Tiered Dual-Stage Kinematics)
        // Esegue di default l'Opzione A e attiva in autonomia l'Opzione B se T < T_SAFE
        // =========================================================================
        solveInverseKinematics(n_des, zTarget = -this.cfg.H_NOMINAL, allowAutoFallback = true) {
            // 1. Calcolo rapido nominale Opzione A (costo < 0.02 ms)
            const resA = this._solveInverseKinematicsStageA(n_des, zTarget, true);
            resA.tier = "A";

            if (!allowAutoFallback || !this.cfg.AUTO_OPTIMIZE_Z) {
                return resA;
            }

            // 2. Sentinella fisica (Watchdog anti-slittamento Eytelwein e anti-bando)
            const minT = Math.min(resA.tensions[0], resA.tensions[1], resA.tensions[2]);
            const safeThreshold = this.cfg.T_SAFE_MIN !== undefined ? this.cfg.T_SAFE_MIN : 0.50;

            // Se la soluzione A converge ed è ampiamente sicura, restituiscila immediatamente
            if (resA.success && minT >= safeThreshold) {
                return resA;
            }

            // 3. Trigger 100% automatico Opzione B (solo in caso di criticità o rischio bando)
            const resB = this.solveInverseKinematicsOptimalZ(n_des, -this.cfg.H_MAX_DEPTH, -this.cfg.H_MIN_DEPTH);
            if (resB && resB.success) {
                const minTB = Math.min(resB.tensions[0], resB.tensions[1], resB.tensions[2]);
                if (minTB > minT) {
                    resB.tier = "B_AUTO";
                    resB.autoFallbackTriggered = true;
                    return resB;
                }
            }

            return resA;
        }

        relaxForwardKinematics(currentVertices, targetLengths, subSteps = 16) {
            const sc = this._fkScratch;
            const v = sc.v;
            for (let i = 0; i < 3; i++) {
                v[i][0] = currentVertices[i][0];
                v[i][1] = currentVertices[i][1];
                v[i][2] = currentVertices[i][2] - 0.0015; // Spinta gravitazionale PBD
            }

            for (let s = 0; s < subSteps; s++) {
                for (let i = 0; i < 3; i++) {
                    VMath.sub(v[i], this.A_pts[i], sc.toP);
                    const d = VMath.norm(sc.toP);
                    const L = targetLengths[i];
                    if (d > L) {
                        const scale = L / d;
                        v[i][0] = this.A_pts[i][0] + sc.toP[0] * scale;
                        v[i][1] = this.A_pts[i][1] + sc.toP[1] * scale;
                        v[i][2] = this.A_pts[i][2] + sc.toP[2] * scale;
                    }
                }

                // Centroide geometrico dei tre perni di trazione
                const p_perni_x = (v[0][0] + v[1][0] + v[2][0]) / 3.0;
                const p_perni_y = (v[0][1] + v[1][1] + v[2][1]) / 3.0;
                const p_perni_z = (v[0][2] + v[1][2] + v[2][2]) / 3.0;

                // Calcolo versore normale del piano specchio
                VMath.sub(v[1], v[0], sc.e1);
                VMath.sub(v[2], v[0], sc.e2);
                VMath.cross(sc.e1, sc.e2, sc.n_plane);
                if (sc.n_plane[2] < 0) VMath.scale(sc.n_plane, -1.0, sc.n_plane);
                VMath.normalize(sc.n_plane, sc.n_plane);

                // FIX CHIRURGICO: Il baricentro reale pG si trova a -Z_B_OFFSET lungo la normale n_plane
                sc.pG[0] = p_perni_x - sc.n_plane[0] * this.Z_B_OFFSET;
                sc.pG[1] = p_perni_y - sc.n_plane[1] * this.Z_B_OFFSET;
                sc.pG[2] = p_perni_z - sc.n_plane[2] * this.Z_B_OFFSET;

                // Terna ortonormale locale nel piano dei perni
                sc.vY[0] = v[0][0] - p_perni_x;
                sc.vY[1] = v[0][1] - p_perni_y;
                sc.vY[2] = v[0][2] - p_perni_z;
                const proj = VMath.dot(sc.vY, sc.n_plane);
                sc.vY[0] -= sc.n_plane[0] * proj;
                sc.vY[1] -= sc.n_plane[1] * proj;
                sc.vY[2] -= sc.n_plane[2] * proj;
                VMath.normalize(sc.vY, sc.vY);
                VMath.cross(sc.vY, sc.n_plane, sc.vX);

                // Ripristino vincolo di rigidità triangolo: i perni si trovano a +Z_B_OFFSET da pG lungo n_plane
                for (let i = 0; i < 3; i++) {
                    const bx = this.b_pts[i][0], by = this.b_pts[i][1], bz = this.Z_B_OFFSET;
                    v[i][0] = sc.pG[0] + sc.vX[0] * bx + sc.vY[0] * by + sc.n_plane[0] * bz;
                    v[i][1] = sc.pG[1] + sc.vX[1] * bx + sc.vY[1] * by + sc.n_plane[1] * bz;
                    v[i][2] = sc.pG[2] + sc.vX[2] * bx + sc.vY[2] * by + sc.n_plane[2] * bz;
                }
            }

            VMath.sub(v[1], v[0], sc.e1);
            VMath.sub(v[2], v[0], sc.e2);
            const n_eff = VMath.cross(sc.e1, sc.e2);
            if (n_eff[2] < 0) VMath.scale(n_eff, -1.0, n_eff);
            VMath.normalize(n_eff, n_eff);

            return {
                vertices: [ [...v[0]], [...v[1]], [...v[2]] ],
                pG: [...sc.pG],
                n_eff: [...n_eff]
            };
        }
    }

    // =========================================================================
    // 5. LIVELLO 4: TARATURA OTTICA (WIZARD A 2 E A 3 PUNTI)
    // =========================================================================
    const CalibrationEngine = {
        invertTargetVector: (s, n) => {
            const sNorm = VMath.normalize(s);
            const nNorm = VMath.normalize(n);
            const dot = VMath.dot(sNorm, nNorm);
            return VMath.normalize(VMath.sub(VMath.scale(nNorm, 2.0 * dot), sNorm));
        },

        solveTwoPointCalibration: (p1, p2, latDeg, lonDeg) => {
            const s1_geo = AstronomySolver.calculateSunPosition(p1.epoch, latDeg, lonDeg).sunVector;
            const s2_geo = AstronomySolver.calculateSunPosition(p2.epoch, latDeg, lonDeg).sunVector;

            let bestGamma = 0.0;
            let minResidual = 1e9;

            const COARSE_STEP = (1.0 * Math.PI) / 180.0;
            for (let gamma = 0; gamma < 2.0 * Math.PI; gamma += COARSE_STEP) {
                const c = Math.cos(gamma);
                const s = Math.sin(gamma);
                const s1_b = [ s1_geo[0]*c - s1_geo[1]*s,  s1_geo[0]*s + s1_geo[1]*c, s1_geo[2] ];
                const s2_b = [ s2_geo[0]*c - s2_geo[1]*s,  s2_geo[0]*s + s2_geo[1]*c, s2_geo[2] ];

                const t1 = CalibrationEngine.invertTargetVector(s1_b, p1.n_eff);
                const t2 = CalibrationEngine.invertTargetVector(s2_b, p2.n_eff);

                let err = 1.0 - VMath.dot(t1, t2);
                if (t1[2] < -0.35 || t2[2] < -0.35) err += 10.0;

                if (err < minResidual) {
                    minResidual = err;
                    bestGamma = gamma;
                }
            }

            const FINE_STEP = (0.01 * Math.PI) / 180.0;
            const gStart = bestGamma - (1.5 * Math.PI) / 180.0;
            const gEnd   = bestGamma + (1.5 * Math.PI) / 180.0;

            for (let gamma = gStart; gamma <= gEnd; gamma += FINE_STEP) {
                const c = Math.cos(gamma);
                const s = Math.sin(gamma);
                const s1_b = [ s1_geo[0]*c - s1_geo[1]*s,  s1_geo[0]*s + s1_geo[1]*c, s1_geo[2] ];
                const s2_b = [ s2_geo[0]*c - s2_geo[1]*s,  s2_geo[0]*s + s2_geo[1]*c, s2_geo[2] ];

                const t1 = CalibrationEngine.invertTargetVector(s1_b, p1.n_eff);
                const t2 = CalibrationEngine.invertTargetVector(s2_b, p2.n_eff);

                let err = 1.0 - VMath.dot(t1, t2);
                if (t1[2] < -0.35 || t2[2] < -0.35) err += 10.0;

                if (err < minResidual) {
                    minResidual = err;
                    bestGamma = gamma;
                }
            }

            const c_opt = Math.cos(bestGamma);
            const s_opt = Math.sin(bestGamma);
            const s1_opt = [ s1_geo[0]*c_opt - s1_geo[1]*s_opt, s1_geo[0]*s_opt + s1_geo[1]*c_opt, s1_geo[2] ];
            const s2_opt = [ s2_geo[0]*c_opt - s2_geo[1]*s_opt, s2_geo[0]*s_opt + s2_geo[1]*c_opt, s2_geo[2] ];

            const t1_opt = CalibrationEngine.invertTargetVector(s1_opt, p1.n_eff);
            const t2_opt = CalibrationEngine.invertTargetVector(s2_opt, p2.n_eff);
            const t_target = VMath.normalize(VMath.add(t1_opt, t2_opt));

            let finalDeg = (bestGamma * 180.0 / Math.PI) % 360.0;
            if (finalDeg < 0) finalDeg += 360.0;

            return {
                gammaBaseRad: bestGamma,
                gammaBaseDeg: finalDeg,
                targetVectorBase: t_target,
                residualError: minResidual
            };
        },

        solveThreePointCalibration: (p1, p2, p3, latDeg, lonDeg) => {
            const s1_geo = AstronomySolver.calculateSunPosition(p1.epoch, latDeg, lonDeg).sunVector;
            const s2_geo = AstronomySolver.calculateSunPosition(p2.epoch, latDeg, lonDeg).sunVector;
            const s3_geo = AstronomySolver.calculateSunPosition(p3.epoch, latDeg, lonDeg).sunVector;

            let bestGamma = 0.0;
            let minResidual = 1e9;

            const COARSE_STEP = (1.0 * Math.PI) / 180.0;
            for (let gamma = 0; gamma < 2.0 * Math.PI; gamma += COARSE_STEP) {
                const c = Math.cos(gamma);
                const s = Math.sin(gamma);
                const s1_b = [ s1_geo[0]*c - s1_geo[1]*s, s1_geo[0]*s + s1_geo[1]*c, s1_geo[2] ];
                const s2_b = [ s2_geo[0]*c - s2_geo[1]*s, s2_geo[0]*s + s2_geo[1]*c, s2_geo[2] ];
                const s3_b = [ s3_geo[0]*c - s3_geo[1]*s, s3_geo[0]*s + s3_geo[1]*c, s3_geo[2] ];

                const t1 = CalibrationEngine.invertTargetVector(s1_b, p1.n_eff);
                const t2 = CalibrationEngine.invertTargetVector(s2_b, p2.n_eff);
                const t3 = CalibrationEngine.invertTargetVector(s3_b, p3.n_eff);

                let err = (1.0 - VMath.dot(t1, t2)) + (1.0 - VMath.dot(t2, t3)) + (1.0 - VMath.dot(t1, t3));
                if (t1[2] < -0.35 || t2[2] < -0.35 || t3[2] < -0.35) err += 30.0;

                if (err < minResidual) {
                    minResidual = err;
                    bestGamma = gamma;
                }
            }

            const FINE_STEP = (0.01 * Math.PI) / 180.0;
            const gStart = bestGamma - (1.5 * Math.PI) / 180.0;
            const gEnd   = bestGamma + (1.5 * Math.PI) / 180.0;

            for (let gamma = gStart; gamma <= gEnd; gamma += FINE_STEP) {
                const c = Math.cos(gamma);
                const s = Math.sin(gamma);
                const s1_b = [ s1_geo[0]*c - s1_geo[1]*s, s1_geo[0]*s + s1_geo[1]*c, s1_geo[2] ];
                const s2_b = [ s2_geo[0]*c - s2_geo[1]*s, s2_geo[0]*s + s2_geo[1]*c, s2_geo[2] ];
                const s3_b = [ s3_geo[0]*c - s3_geo[1]*s, s3_geo[0]*s + s3_geo[1]*c, s3_geo[2] ];

                const t1 = CalibrationEngine.invertTargetVector(s1_b, p1.n_eff);
                const t2 = CalibrationEngine.invertTargetVector(s2_b, p2.n_eff);
                const t3 = CalibrationEngine.invertTargetVector(s3_b, p3.n_eff);

                let err = (1.0 - VMath.dot(t1, t2)) + (1.0 - VMath.dot(t2, t3)) + (1.0 - VMath.dot(t1, t3));
                if (t1[2] < -0.35 || t2[2] < -0.35 || t3[2] < -0.35) err += 30.0;

                if (err < minResidual) {
                    minResidual = err;
                    bestGamma = gamma;
                }
            }

            const c_opt = Math.cos(bestGamma);
            const s_opt = Math.sin(bestGamma);
            const s1_opt = [ s1_geo[0]*c_opt - s1_geo[1]*s_opt, s1_geo[0]*s_opt + s1_geo[1]*c_opt, s1_geo[2] ];
            const s2_opt = [ s2_geo[0]*c_opt - s2_geo[1]*s_opt, s2_geo[0]*s_opt + s2_geo[1]*c_opt, s2_geo[2] ];
            const s3_opt = [ s3_geo[0]*c_opt - s3_geo[1]*s_opt, s3_geo[0]*s_opt + s3_geo[1]*c_opt, s3_geo[2] ];

            const t1_opt = CalibrationEngine.invertTargetVector(s1_opt, p1.n_eff);
            const t2_opt = CalibrationEngine.invertTargetVector(s2_opt, p2.n_eff);
            const t3_opt = CalibrationEngine.invertTargetVector(s3_opt, p3.n_eff);

            const t_target = VMath.normalize(VMath.add(VMath.add(t1_opt, t2_opt), t3_opt));

            let finalDeg = (bestGamma * 180.0 / Math.PI) % 360.0;
            if (finalDeg < 0) finalDeg += 360.0;

            return {
                gammaBaseRad: bestGamma,
                gammaBaseDeg: finalDeg,
                targetVectorBase: t_target,
                residualError: minResidual,
                rmsResidual: Math.sqrt(minResidual / 3.0),
                isThreePoint: true
            };
        }
    };

    // =========================================================================
    // 6. LIVELLO 5: GUI HELPERS & ADATTATORE THREE.JS
    // =========================================================================
    const GUIHelpers = {
        computeThreeOrthonormalBasis: (vertices, pG, n_eff) => {
            const vY = VMath.normalize(VMath.sub(vertices[0], pG));
            const vZ = VMath.normalize(n_eff);
            const vX = VMath.normalize(VMath.cross(vY, vZ));
            const vY_reortho = VMath.normalize(VMath.cross(vZ, vX));
            return { vX, vY: vY_reortho, vZ };
        },

        computeMirrorProjectionTrace: (pG, n_des, n_eff, r_b = DEFAULTS.r_b) => {
            const nd = VMath.normalize(n_des);
            const ne = VMath.normalize(n_eff);
            const dot = VMath.dot(nd, ne);

            const vProj = VMath.sub(nd, VMath.scale(ne, dot));
            const sinDeltaTheta = VMath.norm(vProj);

            const pStart = VMath.add(pG, VMath.scale(ne, 0.002));
            const displayLength = sinDeltaTheta * r_b;
            const pEnd = VMath.clone(pStart);

            if (sinDeltaTheta > 1e-5) {
                const dir = VMath.scale(vProj, 1.0 / sinDeltaTheta);
                pEnd[0] += dir[0] * displayLength;
                pEnd[1] += dir[1] * displayLength;
                pEnd[2] += dir[2] * displayLength;
            }

            return {
                pStart,
                pEnd,
                lengthMeters: displayLength,
                lengthMm: displayLength * 1000.0,
                vProj
            };
        },

        formatTelemetryData: (n_eff, n_des, cableLengths) => {
            const angleRad = VMath.angleBetween(n_eff, n_des);
            const errDeg = angleRad * (180.0 / Math.PI);

            let status = 'OFF TARGET';
            let badgeClass = 'error-bad';

            if (errDeg < 0.25) {
                status = 'LOCK (ALLINEATO)';
                badgeClass = 'error-good';
            } else if (errDeg < 2.5) {
                status = 'APPROACH';
                badgeClass = 'error-mid';
            }

            return {
                errorDeg: errDeg,
                errorDegFormatted: errDeg.toFixed(2) + '°',
                status,
                badgeClass,
                nEffFormatted: `[${n_eff[0].toFixed(2)}, ${n_eff[1].toFixed(2)}, ${n_eff[2].toFixed(2)}]`,
                nDesFormatted: `[${n_des[0].toFixed(2)}, ${n_des[1].toFixed(2)}, ${n_des[2].toFixed(2)}]`,
                cableLengthsMm: cableLengths.map(l => (l * 1000.0).toFixed(1))
            };
        }
    };

    // =========================================================================
    // 7. MASTER FACADE ENGINE
    // =========================================================================
    class HeliostatMasterEngine {
        constructor(config = {}) {
            this.config = Object.assign({}, DEFAULTS, config);
            this.kinematics = new CDPRKinematics(this.config);
            this.astronomy = AstronomySolver;
            this.calibration = CalibrationEngine;
            this.helpers = GUIHelpers;
            this.VMath = VMath;
            this.version = "4.8.0";
        }
    }

    return {
        VMath,
        AstronomySolver,
        CDPRKinematics,
        CalibrationEngine,
        GUIHelpers,
        HeliostatMasterEngine,
        VERSION: "4.8.0"
    };
}));