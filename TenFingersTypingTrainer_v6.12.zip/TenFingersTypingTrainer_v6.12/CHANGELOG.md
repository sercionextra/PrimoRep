# Changelog

## v6.12 — 31/10/2026

- Risolto in modo definitivo il bug di stallo nel generatore markoviano `PhonemeEngine.generate()`: quando la catena estraeva uno spazio e il testo terminava già con un delimitatore, l'istruzione `continue` manteneva invariato il prefisso di contesto, intrappolando il motore in un ciclo a vuoto fino all'esaurimento di `safetyCounter` (2000 iterazioni) e restituendo una singola parola di 5-8 caratteri.
- Integrato il ri-seeding immediato del prefisso di contesto tramite `getRandomWordSeed()` al verificarsi di delimitatori ridondanti, consentendo all'algoritmo di saltare a una nuova sequenza valida e progredire fino alla lunghezza target impostata (fino a 500 caratteri).
- Introdotta la clausola di salvaguardia `result.length >= this.targetLength + 40` nella condizione di stop naturale, evitando espansioni incontrollate (runaway words) in presenza di corpus custom con sequenze continue prive di spaziature.
- Aggiornati `index.html`, `help.html`, `docs/ARCHITETTURA_v6.12.md`, `docs/MANUALE_UTENTE_v6.12.md`, manifest di build e suite di test automatici alla release v6.12.

## v6.11 — 31/10/2026

- Aggiunto nella finestra di dialogo "Configurazione Fonemi" il campo numerico `Numero Caratteri per Esercizio` (`#txtFonemiTargetLength`) con intervallo validato compreso tra 20 e 500 caratteri e valore predefinito pari a 100.
- Integrato il pulsante inline dedicato `↺ 100` (`#btnFonemiTargetLengthDefault`) per ripristinare all'istante il default di 100 caratteri senza alterare gli altri parametri (lunghezza N-grammi o percentuali di probabilità).
- Aggiornato il pulsante di reset globale della modale in `↺ Default (N=4, 100 car., 30%)` per includere anche il ripristino della lunghezza target.
- Esteso il motore markoviano `PhonemeEngine.generate()` con supporto al parametro `targetLength` dinamico, preservando il completamento naturale della parola (Word Boundary) prima dell'arresto della frase.
- Persistito il parametro `FonemiTargetLength` nel profilo utente con inizializzazione difensiva a 100 e rigenerazione reattiva della sessione attiva in Modalità 2.
- Aggiornati `index.html`, `help.html`, `docs/ARCHITETTURA_v6.11.md`, `docs/MANUALE_UTENTE_v6.11.md`, manifest di build e suite di test automatici alla release v6.11.

## v6.10 — 31/10/2026

- Adottato il paradigma architetturale "Informativo/Guida" per il dimensionamento dell'applicazione, delegando interamente il controllo dello zoom al motore nativo del browser web (`CTRL+RotellinaMouse`, `CTRL+SHIFT++`, `CTRL+SHIFT+-`).
- Rimosso qualsiasi meccanismo invasivo di scaling software CSS (`document.body.style.zoom`) e rimosso il sequestro preventivo degli eventi (`e.preventDefault()`) sulle combinazioni `CTRL+SHIFT++` e `CTRL+SHIFT+-`, eliminando all'origine ogni anomalia geometrica di drag, resize, reflow o doppio calcolo delle coordinate per finestre flottanti e componenti SVG.
- Aggiunto il pulsante `🔍 Zoom-in e Zoom-out` (`#btnZoomInfo`) nell'header primario dell'applicazione, che apre la finestra modale focalizzata (`#zoomHelpModal`) con le indicazioni visive delle 3 scorciatoie native universali del browser.
- Integrato il feedback visivo immediato tramite notifiche temporizzate non bloccanti (mini-toast `showNotificationToast`) sui pulsanti `🔍+ Zoom-in` e `🔍- Zoom-out`, guidando l'utente all'utilizzo delle relative combinazioni native.
- Aggiornati `index.html`, `help.html`, `docs/ARCHITETTURA_v6.10.md`, `docs/MANUALE_UTENTE_v6.10.md`, build manifest e suite di test automatici alla release v6.10.

## v6.9 — 31/10/2026

- Introdotti i pulsanti `🔍+ Zoom-in` e `🔍- Zoom-out` sulla barra del titolo dell'applicazione (nella sezione delle azioni primarie della testata), corredati dai tooltip esplicativi `"Ingrandimento (CTRL+RotellinaMouse oppure CTRL+SHIFT++)"` e `"Riduzione (CTRL+RotellinaMouse oppure CTRL+SHIFT+-)"`.
- Implementato il sistema di scalatura proporzionale integrata dell'interfaccia via CSS zoom, con escursione protetta tra il 50% e il 250% e passo discreto del 10% (0.1).
- Integrata la triplice modalità di interazione: click diretto sui pulsanti della barra, rotellina del mouse con tasto CTRL premuto (`CTRL+RotellinaMouse`), e scorciatoie globali da tastiera `CTRL+SHIFT++` e `CTRL+SHIFT+-`.
- Garantito il perfetto reflow coordinato con il sistema di Ancoraggio Intelligente: durante ogni variazione di zoom, le finestre ancorate ("10 Fingers (Mani)" e "Velocità Istantanea") ricalcolano dinamicamente la propria posizione solidale rispetto alla base della scheda di digitazione (`cardBottom`).
- Persistito il parametro `ZoomLevel` nel profilo utente attivo con ripristino automatico al login e reinizializzazione al 100% (1.0) durante il ripristino globale dei layout delle finestre.
- Allineati `index.html`, guida in linea (`help.html`), documentazione tecnica (`ARCHITETTURA_v6.9.md`), manuale utente (`MANUALE_UTENTE_v6.9.md`), build manifest e test automatici alla release v6.9.

## v6.8 — 31/10/2026

- Aggiunto il pulsante `📍 Pinned` / `📌 Pin` nei controlli dell'header della finestra "Velocità Istantanea", posizionato tra "⚙ Parametri" e "↺ Default", con lo stesso funzionamento del pulsante Pin della finestra "10 Fingers (Mani)".
- Esteso il sistema di Ancoraggio Intelligente: in stato `Pinned`, la finestra di Velocità Istantanea è ancorata al fondo della scheda di digitazione (`cardBottom`) tramite coordinate relative (`InstantSpeedOffsetTop` e `InstantSpeedLeft`), traslando in modo solidale alla scheda in occasione di variazioni di zoom o visibilità degli elementi DOM (Testo Guida, Input, Errori, Tastiera).
- In stato `Unpinned` ("📌 Pin"), la finestra è libera di essere spostata in qualsiasi punto della pagina conservando le coordinate relative al container applicativo principale.
- Riprogettato il layout di default della finestra Velocità Istantanea (attivabile tramite il pulsante "↺ Default"): la finestra si posiziona in primo piano (`position: absolute`, `z-index: 1010`) con dimensioni estese a 1240 x 340 px, coprendo interamente l'area congiunta occupata da Tastiera virtuale e finestra "10 Fingers (Mani)".
- Integrata la normalizzazione difensiva dei profili utente storici nel `ProfileManager` e allineati `index.html`, `help.html`, documentazione tecnica (`ARCHITETTURA_v6.8.md`), manuale utente (`MANUALE_UTENTE_v6.8.md`), manifest e test di regressione alla versione v6.8.

## v6.7 — 31/10/2026

- Aggiunto il pulsante `🗑 Elimina` nell'ultima riga della finestra "Editor Frasi Personalizzate", posizionato tra "Export Testo di Input per Fonemi" e "Configurazione Fonemi", con dicitura compatta per minimizzare l'ingombro orizzontale e tooltip esplicativo.
- Implementata la rimozione controllata della fonte Fonemi personalizzata (`FonemiCustomText`) con dialogo modale di conferma `showAppConfirm()`, azzeramento del corpus nel profilo attivo, deselezione di `chkFonemiCustomFile`, aggiornamento della sintesi nel dropdown e salvataggio immediato in Local Storage.
- Gestito il ripristino automatico e trasparente della fonte fonemica predefinita di sistema: se l'utente è attualmente in modalità Fonemi, l'esercizio corrente viene immediatamente rigenerato con il corpus di default senza errori bloccanti.
- Se nessuna fonte personalizzata è presente nel profilo, la pressione del tasto fornisce un avviso informativo non distruttivo e ripristina il focus alla digitazione.
- Sincronizzati tutti i file applicativi, documentazione tecnica (`ARCHITETTURA_v6.7.md`), manuale utente (`MANUALE_UTENTE_v6.7.md`), guida in-app (`help.html`), manifest e suite di verifica automatica alla versione v6.7.

## v6.6 — 31/10/2026

- Risolto l'errore bloccante sulla digitazione dell'Invio (e del Tab) a fine riga: implementata l'equivalenza semantica tra caratteri strutturali (token canonico ® equivalente a \n, e → equivalente a \t) nei metodi `TypingEngine.getMatchLength()`, `TypingEngine.handleKeyInput()` e `AppController.updateOriginDisplay()`.
- Garantita la perfetta coincidenza di battuta tra testo digitato e testo guida anche in presenza di sequenze "SPAZIO INVIO", con accodamento reattivo del target effettivo in `typedText` per prevenire disallineamenti del cursore.
- Preservati integralmente i ritorni a capo per fonti Fonemi personalizzate (Custom File): la catena markoviana incontra normalmente i newline del testo caricato dall'utente e li propone durante la digitazione con il normale meccanismo probabilistico, ignorando la conversione a spazio.
- Sanitizzati i delimitatori di frase della fonte Fonemi predefinita (default corpus), impedendo l'estrazione spuria di newline orfani all'inizio dell'esercizio sulla prima riga.
- Allineata la suite di test automatici (static-check e runtime-smoke), il manifest di build e la documentazione tecnica alla versione v6.6.

## v6.5 — 30/10/2026

- Risolto il mancato ricalcolo retroattivo della Media Mobile nella finestra Velocità Istantanea: implementato il metodo `TypingEngine.recalculateInstantSpeedMovingAverages()`, che ricalcola all'istante l'intera serie dei campioni già digitati nell'esercizio corrente appena l'utente modifica il parametro N nel modale Parametri.
- La curva del grafico si rimodella immediatamente a schermo alla conferma del nuovo valore di N senza richiedere il riavvio dell'esercizio.
- Allineata la documentazione didattica in `help.html` e nel Manuale Utente per illustrare il comportamento del ricalcolo dinamico.
- Sincronizzati codice sorgente, documentazione, manifest e test automatici alla release v6.5.

## v6.4 — 30/10/2026

- Corretto il calcolo delle linee medie cumulative Netta e Lorda nella finestra Velocità Istantanea: applicata la formula basata sul tempo trascorso in secondi (Media Netta = Caratteri Corretti *60 / Tempo Secondi; Media Lorda = Caratteri Totali* 60 / Tempo Secondi).
- Ingrandito il font dei caratteri in ascissa a 18px bold e dei timestamp sss.mmm verticali a 13px bold, aumentando il margine inferiore a 112px per garantire assenza di sovrapposizioni o troncamenti.
- Ingrandita l'indicazione BPM del crosshair orizzontale rosso a 18px bold con ancoraggio dinamico allo scorrimento orizzontale per rimanere sempre visibile nella porzione di finestra visualizzata.
- Ingrandita l'indicazione del crosshair verticale azzurro a 16px bold con mantenimento all'interno dei bordi visibili dello schermo.
- Ingranditi i font delle etichette delle Medie Lorda e Netta a 15px bold con posizionamento sticky visibile durante lo scorrimento.
- Risolto il blocco della finestra "Parametri Velocità Istantanea": registrata l'inizializzazione dei listener in AppController.start() e in setupFloatingWindows(), abilitati tasto di chiusura "x", pulsanti Conferma, Annulla, Default, tasto Escape e click sull'overlay esterno.
- Integrata nell'Help in linea e nel Manuale Utente la spiegazione pedagogica sull'uso della finestra tachimetrica: strumento avanzato da utilizzare dopo il completamento del programma per stimare i limiti di velocità superiori tramite i picchi del grafico.
- Sincronizzati tutti i file applicativi, documentazione, manuale utente e test alla versione v6.4.

## v6.3 — 30/10/2026

- Introdotta la nuova funzionalità "Velocità Istantanea": finestra fluttuante traslabile e ridimensionabile con 8 maniglie perimetrali per il monitoraggio in tempo reale del ritmo di battitura.
- Implementato il grafico SVG ad auto-scorrimento orizzontale continuo con passo costante (30 px) e timestamp sss.mmm ruotati in verticale a 90 gradi antiorari.
- Calcolo della velocità tramite Media Mobile fisicamente consistente (Metodo B: tempo cumulato degli ultimi N intervalli).
- Parametro N della finestra mobile (range 1-10, default 3) configurabile tramite modale dedicato "Parametri" e persistito nel profilo utente.
- Visualizzazione di due linee medie orizzontali di riferimento per la velocità cumulativa lorda e netta.
- Integrazione del crosshair interattivo al passaggio del mouse con lettura dei BPM sull'asse delle ordinate e del tempo sull'asse delle ascisse.
- Aggiunto il checkbox dedicato nella toolbar dei controlli e assegnata la scorciatoia da tastiera globale CTRL+SHIFT+I.
- Pulsante "Default" per il ripristino immediato della posizione e dimensione standard ancorata sopra l'area tastiera.
- Aggiornata la documentazione didattica, il manuale utente, la guida in linea, i test statici e i manifest alla release v6.3.

## v6.2 — 29/10/2026

- Risolta l'anomalia nella cancellazione dei campioni non selezionati nelle statistiche in presenza di filtri attivi: il pulsante "Elimina non selezionati" cancella solo i campioni visibili nel grafico che rispettano i filtri applicati ma non appartengono alla selezione corrente.
- Preservati intatti sia i campioni selezionati sia l'intero archivio storico dei campioni esterni ai filtri attivi.
- Disabilitazione contestuale coerente del pulsante "Elimina non selezionati" all'avvio e quando non ci sono campioni da eliminare nella vista corrente.
- Aggiornati dialoghi di conferma modale, messaggi di notifica, documentazione, manuale utente, guida in linea e suite di verifica alla v6.2.

## v6.1 — 29/10/2026

- Risolto il blocco della dettatura vocale dopo la correzione degli errori: rimossa la formula prolissa di completamento ed eliminata l'interruzione brusca dell'audio alla digitazione.
- La dettatura riprende direttamente dal primo carattere non ancora digitato appena gli errori tornano a zero con Backspace.
- Ottimizzato il tracciamento del token attivo e del lookahead predittivo durante la digitazione rapida, prevenendo desincronizzazioni e blocchi della voce.
- Allineati codice sorgente, documentazione, manuale utente, help in-app e suite di verifica alla v6.1.

## v6.0 — 27/10/2026

- Avviato il refactoring strutturale dei sorgenti in file separati per responsabilità.
- Estratto il CSS dell'interfaccia in un asset dedicato.
- Conservati dataset didattico, motori, interfaccia e persistenza della v5.1 come baseline di equivalenza.
- Allineati titolo, percorsi degli asset e guida HTML alla v6.0.
- Aggiunti documentazione architetturale e checklist di regressione.
- Nessuna migrazione distruttiva dei dati browser introdotta.

Nota: questa release privilegia la compatibilità; la conversione completa a moduli ES/TypeScript richiede una fase ulteriore di estrazione delle dipendenze e test runtime.
