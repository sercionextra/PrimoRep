# Manuale Utente TenFingersTypingTrainer v6.46

Questa guida integra il manuale della versione 6.45 con l'aggiornamento introdotto nella versione 6.46.

## 1. Modalità "Random This Phrase" (Rimescola Frase Corrente)
Quando premi il pulsante **Random This Phrase** (o selezioni la modalità corrispondente), il programma mescola l'ordine dei caratteri esattamente dell'ultima frase su cui stavi lavorando, qualunque modalità fosse attiva in quel momento:
- Funziona con le frasi delle lezioni **Standard** e **Custom**, con le sequenze **Random**, **Fonemi**, **All Chars** e **Weaknesses (Carenze)**.
- Funziona anche partendo dalla **Digitazione Libera (Typing)**: dopo aver scritto un testo libero, puoi cliccare su **Random This Phrase** per rimescolare esattamente i caratteri che hai digitato. Se non hai ancora digitato alcun carattere, un messaggio ti avviserà di scrivere prima almeno un carattere.

## 2. Funzionalità confermate dalle versioni precedenti
Tutte le funzioni introdotte fino alla versione 6.45 (inclusa la registrazione separata delle statistiche **Custom** e le funzioni di **🎓 Interrogazione**) restano invariate.
