/* TenFingersTypingTrainer v6.0 — AppController: toolbar. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
    setupToolbar() {
      const cboLessons = document.getElementById("cboLessons");
      const cboMode = document.getElementById("cboMode");
      const btnToggleSource = document.getElementById("btnToggleLessonSource");

      if (cboLessons) {
        cboLessons.addEventListener("change", (e) => {
          this.typingEng.currentLessonIdx = parseInt(e.target.value, 10);
          this.typingEng.currentPhraseIdx = 0;
          if (
            this.profileMgr.profile &&
            this.activeLessonsSource === "standard"
          ) {
            this.profileMgr.profile.Lesson = this.typingEng.currentLessonIdx;
            this.profileMgr.profile.Exercise = 0;
            this.profileMgr.saveProfile();
          }
          this.startExercise();
          this.returnFocusToTyping();
        });
      }

      if (btnToggleSource) {
        btnToggleSource.addEventListener("click", () => {
          if ([1, 2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
            this.notifyShortcutDisabled(
              "Commutazione sorgente non disponibile nella modalità attiva",
            );
            this.returnFocusToTyping();
            return;
          }
          if (this.activeLessonsSource === "standard") {
            if (!this.customLessons || this.customLessons.length === 0) {
              const txt =
                this.profileMgr.profile?.CustomText ||
                this.profileMgr.defaultCustomText;
              this.customLessons = parseCustomExercises(txt);
            }
            if (this.customLessons.length > 0) {
              this.setLessonsSource("custom");
            } else {
              this.showAppAlert(
                "Nessun esercizio custom trovato. Apri l'Editor Custom per inserire o caricare un file.",
                "ℹ Esercizi Custom",
              );
            }
          } else {
            this.setLessonsSource("standard");
          }
          this.returnFocusToTyping();
        });
      }

      if (cboMode) {
        cboMode.addEventListener("change", (e) => {
          this.typingEng.mode = parseInt(e.target.value, 10);
          if (this.profileMgr.profile) {
            this.profileMgr.profile.Mode = this.typingEng.mode;
            this.profileMgr.saveProfile();
          }
          this.updateModeUI();
          this.startExercise();
          this.returnFocusToTyping();
        });
      }

      // Clic su ▲ e ▼ navigano direttamente (intenzionalità mouse)
      document
        .getElementById("btnPrevLesson")
        ?.addEventListener("click", () => {
          this.navLesson(-1);
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnNextLesson")
        ?.addEventListener("click", () => {
          this.navLesson(1);
          this.returnFocusToTyping();
        });

      document
        .getElementById("btnPrevPhrase")
        ?.addEventListener("click", () => {
          this.navPhrase(-1);
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnNextPhrase")
        ?.addEventListener("click", () => {
          this.navPhrase(1);
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnRestartPhrase")
        ?.addEventListener("click", () => {
          this.startExercise(true);
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnRandomPhrase")
        ?.addEventListener("click", () => {
          this.randomPhrase();
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnRandomThisPhrase")
        ?.addEventListener("click", () => {
          if (this.typingEng.mode === 4) {
            this.notifyShortcutDisabled(
              "Rimescola frase non disponibile in Digitazione Libera",
            );
            this.returnFocusToTyping();
            return;
          }
          this.typingEng.mode = 5;
          if (cboMode) cboMode.value = "5";
          this.updateModeUI();
          this.startExercise();
          this.returnFocusToTyping();
        });
      document
        .getElementById("btnRandomAllChars")
        ?.addEventListener("click", () => {
          this.typingEng.mode = 3;
          if (cboMode) cboMode.value = "3";
          this.updateModeUI();
          this.startExercise();
          this.returnFocusToTyping();
        });

      document.getElementById("btnOpenStats")?.addEventListener("click", () => {
        this.toggleStatsWindow();
        this.returnFocusToTyping();
      });
      document
        .getElementById("btnOpenCustomEditor")
        ?.addEventListener("click", () => {
          this.openCustomEditor();
          this.returnFocusToTyping();
        });

      document
        .getElementById("btnAddStatistic")
        ?.addEventListener("click", () => {
          if (this.typingEng.mode === 4) {
            this.typingEng.recordManualTypingSample();
            this.showAppAlert(
              "Sessione di digitazione libera registrata con successo!",
              "📊 Statistiche",
            );
            this.typingEng.initSession();
            this.typingEng.updateMetrics();

            // Ridisegno immediato dei grafici se la finestra Statistiche è aperta e visibile (v.2.32)
            const statsWin = document.getElementById("statsFloatingWindow");
            if (statsWin && statsWin.classList.contains("window-visible")) {
              this.statsMgr.renderHistogram();
              this.statsMgr.renderSpeedChart();
            }
          }
          this.returnFocusToTyping();
        });
    },

    // =======================================================
    // CLASSE: AppController (main_B_(v.4.9).js)
    // METODO: purgePreExistingErrors()
    // =======================================================
    // Bonifica immediata degli errori pre-esistenti all'attivazione dell'Auto-Correzione
    purgePreExistingErrors() {
      if (this.typingEng.mode === 4 || this.typingEng.isCompleted) return;
      const matchLen = this.typingEng.getMatchLength();
      if (this.typingEng.typedText.length > matchLen) {
        // Troncamento del testo digitato al prefisso coincidente privo di errori
        this.typingEng.typedText = this.typingEng.typedText.slice(0, matchLen);
        this.typingEng.currentTargetHasError = false;

        const input = document.getElementById("txtTypedInput");
        if (input) {
          input.value = this.formatInputDisplay(this.typingEng.typedText);
          input.classList.remove("error-active");
        }

        // Aggiornamento immediato di display guida, tastiera/mani e metriche
        this.updateOriginDisplay();
        this.updateTargetKey();
        this.typingEng.updateMetrics();

        // Sincronizzazione immediata della dettatura con riavvio del timer (Release v.4.9)
        if (this.typingEng.mode !== 4) {
          this.dictation.updateProgress(matchLen, matchLen);
        }
      }
    },

    setupCheckboxes() {
      document
        .getElementById("chkShowOrigin")
        ?.addEventListener("change", (e) => {
          this.toggleOriginVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkShowTyped")
        ?.addEventListener("change", (e) => {
          this.toggleTypedVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkShowErrors")
        ?.addEventListener("change", (e) => {
          this.toggleErrorsVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkShowKeyBoard")
        ?.addEventListener("change", (e) => {
          this.toggleKeyboardVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkShowHands")
        ?.addEventListener("change", (e) => {
          this.toggleHandsVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkShowInstantSpeed")
        ?.addEventListener("change", (e) => {
          this.toggleInstantSpeedVis(e.target.checked);
          this.returnFocusToTyping();
        });
      document
        .getElementById("chkAutomaticCorrection")
        ?.addEventListener("change", (e) => {
          if (this.profileMgr.profile) {
            this.profileMgr.profile.AutomaticCorrection = e.target.checked;
            this.profileMgr.saveProfile();
          }
          // Se l'Auto-Correzione viene attivata, elimina all'istante gli errori pendenti
          if (e.target.checked) {
            this.purgePreExistingErrors();
          }
          this.returnFocusToTyping();
        });
    },

    setControlEnabled(el, enabled) {
      if (!el) return;
      el.disabled = !enabled;
      if (enabled) {
        el.classList.remove("control-disabled");
        el.style.pointerEvents = "";
        el.style.opacity = "";
        if (el.id === "lblPhraseRange") {
          el.style.cursor = "pointer";
        }
      } else {
        el.classList.add("control-disabled");
        el.style.pointerEvents = "none";
        el.style.opacity = "0.38";
        if (el.id === "lblPhraseRange") {
          el.style.cursor = "default";
        }
      }
    },

    notifyShortcutDisabled(
      message = "Comando non disponibile nella modalità attiva",
    ) {
      this.audio.playError();
      let toast = document.getElementById("appNotificationToast");
      if (!toast) {
        toast = document.createElement("div");
        toast.id = "appNotificationToast";
        toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        background: rgba(30, 41, 59, 0.95);
        color: #f8fafc;
        border: 1px solid #475569;
        border-left: 4px solid #f59e0b;
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 600;
        box-shadow: 0 10px 25px rgba(0,0,0,0.4);
        z-index: 99999;
        pointer-events: none;
        opacity: 0;
        transform: translateY(10px);
        transition: opacity 0.2s ease, transform 0.2s ease;
      `;
        document.body.appendChild(toast);
      }
      toast.textContent = `⚠ ${message}`;
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
      if (this._toastTimer) clearTimeout(this._toastTimer);
      this._toastTimer = setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(10px)";
      }, 1500);
    },

    // Aggiornamento dinamico interfaccia per modalità (v.4.3)
    updateModeUI() {
      const input = document.getElementById("txtTypedInput");
      const btnAddStat = document.getElementById("btnAddStatistic");
      const mode = this.typingEng.mode;

      // Seleziona la sorgente Standard in modalità 1 (Random Caratteri) se precedentemente impostata su Custom
      if (mode === 1 && this.activeLessonsSource === "custom") {
        this.setLessonsSource("standard");
      }

      // GESTIONE VISIBILITÀ ESCLUSIVA PULSANTE STATISTICHE E PLACEHOLDER
      if (mode === 4) {
        if (btnAddStat) btnAddStat.style.display = "inline-flex";
        if (input)
          input.placeholder =
            "Digitazione libera: scrivi qualsiasi testo qui...";
      } else {
        if (btnAddStat) btnAddStat.style.display = "none";
        if (input) input.placeholder = "Inizia a digitare qui...";
      }

      // SOSTITUZIONE DINAMICA CONTROLLI TOOLBAR 1 PER MODALITÀ 2 (FONEMI) (v.4.3)
      const fonemiContainer = document.getElementById(
        "fonemiMultiselectContainer",
      );
      const lessonNavGroup = document.getElementById("lessonNavControlGroup");
      const lblExTitle = document.getElementById("lblExerciseTitle");

      if (mode === 2) {
        if (fonemiContainer) fonemiContainer.style.display = "inline-flex";
        if (lessonNavGroup) lessonNavGroup.style.display = "none";
        if (lblExTitle) lblExTitle.style.display = "none";
        this.updateFonemiDropdownSummary();
      } else {
        if (fonemiContainer) fonemiContainer.style.display = "none";
        if (lessonNavGroup) lessonNavGroup.style.display = "inline-flex";
        if (lblExTitle) lblExTitle.style.display = "block";
      }

      const btnPrevLesson = document.getElementById("btnPrevLesson");
      const cboLessons = document.getElementById("cboLessons");
      const btnToggleLessonSource = document.getElementById(
        "btnToggleLessonSource",
      );
      const btnNextLesson = document.getElementById("btnNextLesson");
      const btnPrevPhrase = document.getElementById("btnPrevPhrase");
      const btnNextPhrase = document.getElementById("btnNextPhrase");
      const btnSelectPhraseModal = document.getElementById(
        "btnSelectPhraseModal",
      );
      const lblPhraseRange = document.getElementById("lblPhraseRange");
      const btnRandomPhrase = document.getElementById("btnRandomPhrase");
      const btnRandomThisPhrase = document.getElementById(
        "btnRandomThisPhrase",
      );

      if (mode === 0) {
        // 0: PHRASES (Frasi) - Tutti i controlli abilitati
        this.setControlEnabled(btnPrevLesson, true);
        this.setControlEnabled(cboLessons, true);
        this.setControlEnabled(btnToggleLessonSource, true);
        this.setControlEnabled(btnNextLesson, true);
        this.setControlEnabled(btnPrevPhrase, true);
        this.setControlEnabled(btnNextPhrase, true);
        this.setControlEnabled(btnSelectPhraseModal, true);
        this.setControlEnabled(lblPhraseRange, true);
        this.setControlEnabled(btnRandomPhrase, true);
        this.setControlEnabled(btnRandomThisPhrase, true);
      } else if (mode === 1) {
        // 1: RANDOM (Caratteri)
        this.setControlEnabled(btnPrevLesson, true);
        this.setControlEnabled(cboLessons, true);
        this.setControlEnabled(btnToggleLessonSource, false);
        this.setControlEnabled(btnNextLesson, true);
        this.setControlEnabled(btnPrevPhrase, false);
        this.setControlEnabled(btnNextPhrase, true);
        this.setControlEnabled(btnSelectPhraseModal, false);
        this.setControlEnabled(lblPhraseRange, false);
        this.setControlEnabled(btnRandomPhrase, false);
        this.setControlEnabled(btnRandomThisPhrase, false);
      } else if (mode === 2 || mode === 3 || mode === 5 || mode === 6) {
        // 2: FONEMI, 3: ALL CHARS, 5: RANDOM THIS PHRASE, 6: WEAKNESSES
        this.setControlEnabled(btnPrevLesson, false);
        this.setControlEnabled(cboLessons, false);
        this.setControlEnabled(btnToggleLessonSource, false);
        this.setControlEnabled(btnNextLesson, false);
        this.setControlEnabled(btnPrevPhrase, false);
        this.setControlEnabled(btnNextPhrase, true);
        this.setControlEnabled(btnSelectPhraseModal, false);
        this.setControlEnabled(lblPhraseRange, false);
        this.setControlEnabled(btnRandomPhrase, false);
        this.setControlEnabled(btnRandomThisPhrase, mode === 5);
      } else if (mode === 4) {
        // 4: TYPING (Libera)
        this.setControlEnabled(btnPrevLesson, false);
        this.setControlEnabled(cboLessons, false);
        this.setControlEnabled(btnToggleLessonSource, false);
        this.setControlEnabled(btnNextLesson, false);
        this.setControlEnabled(btnPrevPhrase, false);
        this.setControlEnabled(btnNextPhrase, false);
        this.setControlEnabled(btnSelectPhraseModal, false);
        this.setControlEnabled(lblPhraseRange, false);
        this.setControlEnabled(btnRandomPhrase, false);
        this.setControlEnabled(btnRandomThisPhrase, false);
      }
    },

    navLesson(delta) {
      if ([2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
        this.notifyShortcutDisabled(
          "Navigazione lezione non disponibile nella modalità attiva",
        );
        return;
      }
      let next = this.typingEng.currentLessonIdx + delta;
      if (next < 0) next = 0;
      if (next >= this.lessons.length) next = this.lessons.length - 1;
      this.typingEng.currentLessonIdx = next;
      this.typingEng.currentPhraseIdx = 0;
      const cbo = document.getElementById("cboLessons");
      if (cbo) cbo.value = String(next);
      if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
        this.profileMgr.profile.Lesson = next;
        this.profileMgr.profile.Exercise = 0;
        this.profileMgr.saveProfile();
      }
      this.startExercise();
    },

    // Navigazione Lezione con conferma esplicita per scorciatoie da tastiera
    confirmNavLesson(delta) {
      if ([2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
        this.notifyShortcutDisabled(
          "Navigazione lezione non disponibile nella modalità attiva",
        );
        return;
      }
      if (delta < 0 && this.typingEng.currentLessonIdx === 0) {
        this.audio.playError();
        this.showLessonNavAlert("Sei già alla prima lezione.");
        return;
      }

      if (
        delta > 0 &&
        this.typingEng.currentLessonIdx >= this.lessons.length - 1
      ) {
        this.audio.playError();
        this.showLessonNavAlert("Sei già all'ultima lezione.");
        return;
      }

      const msg =
        delta < 0
          ? "Si vuole abbandonare la lezione corrente, e passare alla precedente?"
          : "Si vuole abbandonare la lezione corrente, e passare alla successiva?";

      this.showLessonNavConfirmCustom(msg, () => {
        this.navLesson(delta);
      });
    },

    // =======================================================
    // HELPER MODALI ASINCRONI TEMATIZZATI (Livello 3 - zIndex 4000)
    // =======================================================
    showAppAlert(message, title = "ℹ Informazione", onClose = null) {
      const modal = document.getElementById("lessonNavModal");
      if (!modal) return;

      const titleEl = document.getElementById("lessonNavModalTitle");
      const bodyEl = document.getElementById("lessonNavModalBody");
      const btnYes = document.getElementById("btnLessonNavYes");
      const btnNo = document.getElementById("btnLessonNavNo");
      const btnClose = document.getElementById("btnCloseLessonNavModal");
      if (!bodyEl || !btnYes) return;

      if (titleEl) titleEl.textContent = title;
      bodyEl.textContent = message;
      if (btnNo) btnNo.style.display = "none";
      btnYes.textContent = "OK";
      modal.style.zIndex = "4000"; // Elevato a Livello 3 per dominare su tutti i modali
      modal.classList.add("active");

      const cleanup = () => {
        modal.classList.remove("active");
        modal.style.zIndex = "";
        if (btnNo) btnNo.style.display = "";
        btnYes.textContent = "Sì";
        if (titleEl) titleEl.textContent = "📖 Navigazione Lezione";
        btnYes.removeEventListener("click", handleOk);
        btnClose?.removeEventListener("click", handleOk);
        window.removeEventListener("keydown", handleKey);
        if (onClose) onClose();
        this.returnFocusToTyping();
      };

      const handleOk = () => cleanup();
      const handleKey = (e) => {
        if (e.key === "Escape" || e.key === "Enter") {
          e.preventDefault();
          cleanup();
        }
      };

      btnYes.addEventListener("click", handleOk);
      btnClose?.addEventListener("click", handleOk);
      window.addEventListener("keydown", handleKey);
      btnYes.focus();
    },
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
