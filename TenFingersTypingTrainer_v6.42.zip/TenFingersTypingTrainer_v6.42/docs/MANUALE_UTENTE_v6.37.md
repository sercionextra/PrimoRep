# Manuale Utente — Aggiornamento v6.37

## Novità della versione v6.37

1. **Gestione sessione sospesa:**
   - Se esiste un'interrogazione sospesa, non è più possibile avviarne una nuova (né dalla schermata iniziale né da **Ripeti interrogazione** nello storico): è necessario prima riprendere o abbandonare la sessione sospesa.

2. **Finestra "Seleziona carattere / tasto" più ampia:**
   - La finestra è stata allargata in modo che tutte le 26 lettere dell'alfabeto siano visibili in un'unica riga.

3. **Obiettivo della domanda in grassetto:**
   - L'elemento evidenziato in giallo nel titolo della domanda è ora mostrato in grassetto.
