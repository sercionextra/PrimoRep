# Changelog — TenFingersTypingTrainer

## v6.26
- Migliorata la leggibilità di tutti gli esercizi di **Interrogazione**:
  - Sostituiti gli identificativi tecnici `finger.nn` con il nome italiano del dito e l'indicazione della mano ` - (sn)` o ` - (dx)` (es. `[HOME_ROW] mignolo - (sn)`).
  - Nelle voci `[DITO]` aggiunto anche il nome del tasto tra parentesi graffe (es. `[DITO] mignolo - (dx) - {meno}` nel selettore manuale), mantenendo il titolo della domanda in esecuzione privo di spoiler (`Tasto {meno}`).
  - Nelle voci `[TASTO]` mostrato il nome leggibile del tasto tra parentesi graffe (es. `[TASTO] {meno}`).
  - Nelle voci `[CARATTERE]` mostrati i nomi in chiaro dei caratteri e simboli dalla tabella di riferimento (es. `[CARATTERE] Euro`, `[CARATTERE] BACK`, `[CARATTERE] Spazio`).
- Centralizzata la formattazione leggibile in `InterrogationCatalog` (`js/interrogation/interrogation-catalog.js`).
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.26.md`, `docs/MANUALE_UTENTE_v6.26.md`, `README.md` e `BUILD_MANIFEST.json`.

## v6.25
- Ripristinata la selezione delle migliori voci di sintesi vocale (TTS) con consenso esplicito per profilo (`AllowRemoteTtsVoices`, predefinito `true`).
- Integrata la nuova funzionalità **Interrogazione sul layout della tastiera italiana** (Casuale, Adattiva 1/3/7/14/30/60 giorni, Manuale).
