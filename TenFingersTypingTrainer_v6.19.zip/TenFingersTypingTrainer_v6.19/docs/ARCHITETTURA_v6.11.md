# Architettura — TenFingersTypingTrainer v6.11

## Obiettivo

La release v6.11 introduce la parametrizzazione della lunghezza dell'esercizio per la modalità **FONEMI (Sillabario Italiano N-gram)**, integrando nella finestra di dialogo "Configurazione Fonemi":
1. Un campo di input numerico dedicato con etichetta **"Numero Caratteri per Esercizio"**;
2. Un pulsante inline dedicato **"↺ 100"** (`#btnFonemiTargetLengthDefault`) per ripristinare all'istante il valore predefinito a 100 caratteri senza alterare gli altri parametri (lunghezza N-grammi o percentuali di probabilità);
3. Un range operativo validato e protetto compreso tra **20** e **500** caratteri, con valore predefinito di fabbrica pari a **100**;
4. La perfetta integrazione nel pulsante di reset globale della modale (`↺ Default (N=4, 100 car., 30%)`), che reimposta tutti i parametri con un unico click.

L'architettura garantisce la coerenza tra il profilo utente, il motore markoviano e il ciclo di vita della sessione di battitura, preservando la semantica naturale di completamento della parola (Word Boundary) alla conclusione dell'esercizio.

---

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo con impostazioni di default (`FonemiTargetLength: 100`) |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico di default |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente con supporto `FonemiTargetLength` (normalizzazione difensiva, AppVersion v6.11) |
| `domain/phoneme-engine.js` | Generatore markoviano con supporto `targetLength` dinamico (range 20 - 500, default 100) |
| `ui/window-manager.js` | Finestre flottanti, drag & drop, z-index e vincoli al viewport |
| `engines/typing-engine.js` | Motore di digitazione, passaggio di `targetLength` a `phonemeEng.generate()` in Modalità 2 |
| `ui/visual-renderer.js` | Tastiera virtuale, rendering grafico mani e feedback |
| `engines/dictation-engine.js` | Dettatura vocale e sintesi vocale continua |
| `shared/export-utils.js` | Timestamp e utility di esportazione profili |
| `analytics/statistics-manager.js` | Metriche, grafici di velocità e istogrammi |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.11) |
| `app/controller/metodi-fonemi-dropdown.js` | Apertura, popolamento, gestione click pulsante default "↺ 100", validazione (20 - 500) e salvataggio nel profilo |
| `app/controller/metodi-finestre-layout.js` | Gestione layout finestre, modale scorciatoie zoom e notifiche toast |
| `app/controller/metodi-scorciatoie-editor-custom.js` | Gestione scorciatoie globali da tastiera |
| `app/controller/metodi-profili-modali.js` | Ripristino layout profili e reset pulito |
| `app/controller/metodi-avvio-temi-audio.js` | Ciclo di vita applicativo e registrazione bootstrap |
| `app/bootstrap.js` | Bootstrap e registrazione eventi DOM |

---

## Modello Architetturale della Lunghezza Fonemi (Release v6.11)

Il flusso dei dati e le decisioni di design si articolano in quattro livelli:

1. **Persistenza e Normalizzazione Difensiva (`ProfileManager`):**
   - La proprietà `profile.FonemiTargetLength` viene salvata atomicamente nel Local Storage dell'utente attivo.
   - All'atto del caricamento (`loadUser()`) e all'inizializzazione del profilo demo (`resetToDefaultArchive()`), il sistema verifica la presenza del parametro: se assente (`undefined`), assegna difensivamente il valore di fabbrica `100`, assicurando piena retrocompatibilità con tutti i backup JSON storici.

2. **Validazione e Clamping dell'Input (`metodi-fonemi-dropdown.js`):**
   - Alla conferma della modale (`btnConfirmFonemiConfig`), il valore acquisito da `#txtFonemiTargetLength` viene convertito in intero con fallback:
     - Se non numerico (`isNaN`), assume il valore 100;
     - Limite inferiore: minimo 20 caratteri;
     - Limite superiore: massimo 500 caratteri.
   - Il click sul pulsante inline `#btnFonemiTargetLengthDefault` imposta istantaneamente il valore `100` nel campo senza alterare gli altri controlli.

3. **Generazione Markoviana e Preservazione del Word Boundary (`PhonemeEngine`):**
   - La firma del metodo accetta il parametro di lunghezza:
     `generate(options = {}, probs = {}, customCorpus = "", nGramLength = 4, targetLength = 100)`
   - La soglia `this.targetLength` guida l'arresto naturale del flusso markoviano:
     ```javascript
     if (result.length >= this.targetLength) {
       if (result.endsWith(" ") || result.endsWith("\n") || result.endsWith("®") || result.endsWith("→") || safetyCounter > 1500) {
         break;
       }
     }
     ```
   - Questa semantica garantisce che la frase non venga mai troncata a metà parola, preservando la coerenza sintattica e la fluidità didattica.

4. **Reattività dell'Esercizio in Corso (`TypingEngine`):**
   - Al salvataggio delle impostazioni nella modale, se l'utente sta eseguendo la modalità Fonemi (`this.typingEng.mode === 2`), il controller invoca `this.startExercise(false)`, rigenerando all'istante una nuova frase con la lunghezza desiderata e azzerando i campioni tachimetrici.
