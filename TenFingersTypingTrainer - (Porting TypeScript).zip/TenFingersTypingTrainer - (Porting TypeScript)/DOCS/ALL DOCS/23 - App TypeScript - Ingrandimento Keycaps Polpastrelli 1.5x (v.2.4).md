# 23 - App TypeScript - Ingrandimento Keycaps Polpastrelli 1.5x (v.2.4)

## 1. Analisi Tecnica e Obiettivo Architetturale

La rappresentazione tridimensionale dei tasti (Keycaps 3D) posizionati sui polpastrelli del modello anatomico bimanuale vettoriale `10 Fingers (Mani)` costituiva già un elemento centrale per la guida visiva della dattilografia. Nella release precedente (v.2.1/v.2.3), i tasti presentavano dimensioni di base pari a 58 per 52 pixel con font tipografico a 32 pixel.

Per massimizzare ulteriormente la leggibilità e l'ergonomia visiva dell'interfaccia — in particolare su display ad alta densità di pixel (4K / Retina / QHD) o in configurazioni multi-finestra con ridimensionamento scalare della finestra fluttuante — la **Release 2.4 (v.2.4)** applica un **fattore di scala geometrica uniforme pari a 1.5x (150%)** a tutti gli elementi costitutivi dei pulsanti sui polpastrelli:
1. **Dimensioni Geometriche del Keycap**:
   - Larghezza di base: da 58 px a **87 px** (incremento di 1.5x).
   - Altezza di base: da 52 px a **78 px** (incremento di 1.5x).
   - Raggio di raccordo angolare (`rx`, `ry`): da 9 px a **14 px**.
2. **Dimensionamento Tipografico e Contrasto**:
   - Dimensione del font (`font-size`): da 32 px a **48 px** in stile ultra-bold 900.
   - Spessore del doppio contorno scuro anti-alone (`stroke-width` con `paint-order: stroke fill`): da 4 px a **6 px**.
3. **Bordo Cromatico e Tridimensionalità Glow**:
   - Spessore del contorno cromatico (`stroke-width` SVG): da 3.2 px a **4.8 px**.
   - Raggio di sfocatura volumetrica dell'alone luminescente (`drop-shadow`): da 12 px a **16 px**.
4. **Adattamento Dinamico per Modificatori e Accordi Estesi**:
   - I tasti con etichette a testo lungo (es. `SPAZIO`, `SHIFT`, `INVIO`, `ALT GR`) si espandono dinamicamente oltre 108 px (fino a 174 px per la barra spaziatrice) preservando il perfetto baricentro sui dati anatomici `(data-cx, data-cy)`.

*(Nota redazionale: il documento rispetta il divieto assoluto di formule o delimitatori LaTeX, impiegando notazioni testuali chiare e naturali).*

---

## 2. Struttura del Progetto e File Rilasciati

| File | Percorso Workspace | Percorso Repository Speculare (`SRC` / `DOCS`) | Stato Validazione |
| :--- | :--- | :--- | :--- |
| **Applicazione Principale** | `/workspace/index_(v.2.4).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/index_(v.2.4).html` | **0 Errori DevTools** |
| **Guida Utente e Manuale** | `/workspace/help_(v.2.4).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/help_(v.2.4).html` | Sincronizzato v.2.4 |
| **Asset SVG Mani** | `/workspace/hands_anatomical_model_(v.2.4).svg` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/hands_anatomical_model_(v.2.4).svg` | Allineato v.2.4 |
| **Documentazione Tecnica** | `/workspace/23 - App TypeScript - Ingrandimento Keycaps Polpastrelli 1.5x (v.2.4).md` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/DOCS/ALL DOCS/` | Documento di rilascio e verifica architetturale |

---

## 3. Implementazione di Dettaglio

### 3.1 Geometria SVG dei 10 Keycaps (`handsSvg`)

Coordinate anatomiche dei baricentri e nuovo dimensionamento 87 per 78 px:

```html
<!-- Dito 1: Mano Sinistra - Mignolo -->
<g id="hand_finger_keycap_group_1" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_1" class="finger-keycap-rect keycap-finger-1" data-cx="215" data-cy="340" x="171.5" y="301" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_1" class="finger-tip-label" x="215" y="341" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 2: Mano Sinistra - Anulare -->
<g id="hand_finger_keycap_group_2" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_2" class="finger-keycap-rect keycap-finger-2" data-cx="285" data-cy="205" x="241.5" y="166" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_2" class="finger-tip-label" x="285" y="206" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 3: Mano Sinistra - Medio -->
<g id="hand_finger_keycap_group_3" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_3" class="finger-keycap-rect keycap-finger-3" data-cx="388" data-cy="140" x="344.5" y="101" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_3" class="finger-tip-label" x="388" y="141" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 4: Mano Sinistra - Indice -->
<g id="hand_finger_keycap_group_4" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_4" class="finger-keycap-rect keycap-finger-4" data-cx="511" data-cy="148" x="467.5" y="109" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_4" class="finger-tip-label" x="511" y="149" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 5: Mano Sinistra - Pollice -->
<g id="hand_finger_keycap_group_5" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_5" class="finger-keycap-rect keycap-finger-5" data-cx="655" data-cy="325" x="611.5" y="286" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_5" class="finger-tip-label" x="655" y="326" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 6: Mano Destra - Pollice -->
<g id="hand_finger_keycap_group_6" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_6" class="finger-keycap-rect keycap-finger-6" data-cx="753" data-cy="325" x="709.5" y="286" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_6" class="finger-tip-label" x="753" y="326" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 7: Mano Destra - Indice -->
<g id="hand_finger_keycap_group_7" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_7" class="finger-keycap-rect keycap-finger-7" data-cx="897" data-cy="148" x="853.5" y="109" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_7" class="finger-tip-label" x="897" y="149" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 8: Mano Destra - Medio -->
<g id="hand_finger_keycap_group_8" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_8" class="finger-keycap-rect keycap-finger-8" data-cx="1020" data-cy="140" x="976.5" y="101" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_8" class="finger-tip-label" x="1020" y="141" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 9: Mano Destra - Anulare -->
<g id="hand_finger_keycap_group_9" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_9" class="finger-keycap-rect keycap-finger-9" data-cx="1123" data-cy="205" x="1079.5" y="166" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_9" class="finger-tip-label" x="1123" y="206" text-anchor="middle" dominant-baseline="central"></text>
</g>

<!-- Dito 10: Mano Destra - Mignolo -->
<g id="hand_finger_keycap_group_10" class="finger-keycap-group" style="display:none;">
  <rect id="hand_finger_keycap_rect_10" class="finger-keycap-rect keycap-finger-10" data-cx="1193" data-cy="340" x="1149.5" y="301" width="87" height="78" rx="14" ry="14" />
  <text id="hand_finger_tip_10" class="finger-tip-label" x="1193" y="341" text-anchor="middle" dominant-baseline="central"></text>
</g>
```

### 3.2 Regole CSS Aggiornate

```css
.finger-keycap-rect {
  fill: #0f172a;
  stroke-width: 4.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: all 0.12s ease;
}

.finger-keycap-rect.keycap-finger-1, .finger-keycap-rect.keycap-finger-10 {
  stroke: #ef4444;
  filter: drop-shadow(0 0 16px rgba(239, 68, 68, 0.95));
}
.finger-keycap-rect.keycap-finger-2, .finger-keycap-rect.keycap-finger-9 {
  stroke: #f59e0b;
  filter: drop-shadow(0 0 16px rgba(245, 158, 11, 0.95));
}
.finger-keycap-rect.keycap-finger-3, .finger-keycap-rect.keycap-finger-8 {
  stroke: #10b981;
  filter: drop-shadow(0 0 16px rgba(16, 185, 129, 0.95));
}
.finger-keycap-rect.keycap-finger-4, .finger-keycap-rect.keycap-finger-7 {
  stroke: #3b82f6;
  filter: drop-shadow(0 0 16px rgba(59, 130, 246, 0.95));
}
.finger-keycap-rect.keycap-finger-5, .finger-keycap-rect.keycap-finger-6 {
  stroke: #a855f7;
  filter: drop-shadow(0 0 16px rgba(168, 85, 247, 0.95));
}

.finger-tip-label {
  font-family: var(--font-mono);
  font-size: 48px;
  font-weight: 900;
  fill: #ffffff;
  paint-order: stroke fill;
  stroke: #020617;
  stroke-width: 6px;
  stroke-linecap: round;
  stroke-linejoin: round;
  pointer-events: none;
  user-select: none;
}
```

### 3.3 Logica di Calcolo Dinamico in `VisualRenderer`

Sia in `setTargetChar` sia in `renderActivePhysicalChord`:

```javascript
const textLen = (label || "").length;
const origCx = parseFloat(rect.getAttribute("data-cx") || "215");
const origCy = parseFloat(rect.getAttribute("data-cy") || "340");

if (textLen > 2) {
  // Dimensionamento esteso proporzionato a 1.5x per etichette multiple
  const w = Math.max(108, Math.round(textLen * 22.5 + 39));
  rect.setAttribute("width", w);
  rect.setAttribute("x", origCx - w / 2);
} else {
  // Dimensionamento standard 1.5x
  rect.setAttribute("width", 87);
  rect.setAttribute("x", origCx - 43.5);
}
rect.setAttribute("height", 78);
rect.setAttribute("y", origCy - 39);
```

---

## 4. Considerazioni di Deployment, Ergonomia e Collaudo

1. **Nitidezza a Bassa Risoluzione e su Schermi HiDPI**: Con il font a 48px e contorno scuro a 6px, la visibilità dei tasti attivi rimane nitida anche se la finestra fluttuante delle mani viene ridimensionata al 50% dell'area originale.
2. **Esito del Collaudo End-to-End Headless Chrome (CDP)**:
   - Proprietà geometriche statiche: `width: "87"`, `height: "78"`, `rx: "14"`.
   - Proprietà CSS computate: `stroke-width: "4.8px"`, `font-size: "48px"`.
   - Dimensionamento dinamico per carattere singolo: `w: 87`, `h: 78`.
   - Dimensionamento dinamico per modificatore esteso (`SPAZIO`): `w: 174`, `h: 78`.
   - **0 errori ed eccezioni in console DevTools**.
