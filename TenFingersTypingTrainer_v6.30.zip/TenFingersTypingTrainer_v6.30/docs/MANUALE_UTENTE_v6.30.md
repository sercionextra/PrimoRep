# Manuale Utente TenFingersTypingTrainer v6.30

## Novità pratiche nella finestra Interrogazione

### 1. Pulsante "Mostra storico"
Accanto al pulsante **Avvia Interrogazione** è disponibile il pulsante **📈 Mostra storico**, che apre il grafico dei punteggi ottenuti nelle interrogazioni completate:
- Spostando il cursore sul grafico compaiono una **riga orizzontale tratteggiata rossa** (con il valore del punteggio sull'asse verticale) e una **riga verticale tratteggiata verde** (con data e ora del campione più prossimo).
- Cliccando sui punti del grafico è possibile selezionarli per visualizzarne Data, Ora e Punteggio.
- I campi **Da** e **A** filtrano i campioni per intervallo di data e ora; i pulsanti **Elimina selezionati** ed **Elimina esclusi** consentono di ripulire lo storico.

### 2. Interrogazione per Carattere / Tasto
- I menu a discesa di **1) Descrizione Accordo** partono vuoti; cliccando direttamente sui **puntini sulle mani** o sulle **estensioni laterali** vengono precompilati automaticamente Mano, Dito, Estensione Laterale, Direzione sovraccarico ed Estensione Longitudinale (resta sempre necessario cliccare su **Conferma Accordo**).
- La palette **Seleziona carattere / tasto** si apre direttamente accanto al pulsante o tasto cliccato.
- Per il tasto **INVIO** sono accettati sia `0` che `+1` come estensione longitudinale, e a sinistra di INVIO sono accettati sia `+` che `ù` (entrambi vengono svelati sulla tastiera).
- I tasti `7`, `8`, `9`, `0` non mostrano più simboli errati `{`, `[`, `]`, `}`.

### 3. Interrogazione per Dito
- All'avvio della domanda non vengono mostrati suggerimenti colorati sulla tastiera.
- Clicca ciascun tasto che ritieni associato al dito indicato: il tasto si colora di **giallo** e si apre la palette per abbinarvi uno dei caratteri presenti sul tasto (che viene scritto sul tasto giallo).
- Alla pressione di **Conferma Selezione** (o **Consulta (+1)**), i tasti corretti del dito vengono evidenziati in **verde** con i loro caratteri reali, mentre eventuali tasti scelti fuori posto restano **gialli** con il carattere da te indicato.
