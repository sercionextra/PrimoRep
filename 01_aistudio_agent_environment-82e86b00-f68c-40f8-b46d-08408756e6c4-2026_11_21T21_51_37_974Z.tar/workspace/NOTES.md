# Working Notes

- **Lingua**: Italiano.
- **Strumento di pratica**: Simulatore virtuale [Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3) (niente cubo fisico).
- **Vincolo di orientamento su Cubzor**: Il simulatore impedisce di tenere la croce bianca in basso; la faccia bianca deve restare **sempre in alto (`U`)** (e la gialla in basso `D`). Tutte le lezioni vanno adattate a questo orientamento (es. `R' D' R D` per gli angoli del primo strato).
- **Preferenza metodo**: Metodo semplice e affidabile, niente speedcubing.
- **Esperienza pregressa**: Ha già provato in passato, quindi non parte completamente digiuno dell'oggetto, ma non ha ancora completato la padronanza autonoma.
