/* TenFingersTypingTrainer v6.25 | interrogation-selector.js | Motore di selezione puro (Casuale, Adattivo D77-D80 Alternativa B, Manuale). */
(function (global) {
  "use strict";

  const ALGORITHM_VERSION = "selection-1.0";
  const ADAPTIVE_QUOTA_ALGORITHM_VERSION = "1.1";
  const GLOBAL_ADAPTIVE_BUDGET = 0.1;
  const INDIVIDUAL_CAP_RATIO = 0.2;
  const CANONICAL_CATEGORIES = Object.freeze(["HOME_ROW", "TASTO", "CARATTERE", "DITO"]);

  function computeAdaptiveCategoryShares(baseSharesPercent, reliabilityByCategory) {
    const categories = Object.keys(baseSharesPercent || {});
    if (categories.length === 0) {
      return { finalSharesPercent: {}, supplementPoints: {}, neutralPointsPerCategory: 0 };
    }

    let sumBase = 0;
    for (let i = 0; i < categories.length; i++) {
      sumBase += Math.max(0, Number(baseSharesPercent[categories[i]]) || 0);
    }
    if (sumBase <= 0) {
      sumBase = categories.length * 25;
    }

    const b = {};
    const r = {};
    const d = {};
    const cap = {};
    const s = {};
    const eligible = [];

    for (let i = 0; i < categories.length; i++) {
      const cat = categories[i];
      b[cat] = Math.max(0, Number(baseSharesPercent[cat]) || 0) / sumBase;
      r[cat] = Math.max(0, Math.min(1, Number(reliabilityByCategory[cat]) || 0));
      d[cat] = 1 - r[cat];
      cap[cat] = INDIVIDUAL_CAP_RATIO * b[cat];
      s[cat] = 0;
      if (b[cat] > 0 && d[cat] > 0) {
        eligible.push(cat);
      }
    }

    if (eligible.length === 0) {
      const finalNoDeficit = {};
      const suppZero = {};
      for (let i = 0; i < categories.length; i++) {
        const cat = categories[i];
        finalNoDeficit[cat] = b[cat] * 100;
        suppZero[cat] = 0;
      }
      return {
        finalSharesPercent: finalNoDeficit,
        supplementPoints: suppZero,
        neutralPointsPerCategory: 0,
      };
    }

    let residuo = GLOBAL_ADAPTIVE_BUDGET;
    let active = eligible.slice();

    while (residuo > 1e-12 && active.length > 0) {
      let pesoTotale = 0;
      for (let i = 0; i < active.length; i++) {
        pesoTotale += d[active[i]];
      }
      if (pesoTotale <= 0) break;

      const saturated = [];
      for (let i = 0; i < active.length; i++) {
        const cat = active[i];
        const alloc = (residuo * d[cat]) / pesoTotale;
        const capResidua = cap[cat] - s[cat];
        if (alloc >= capResidua - 1e-12) {
          saturated.push({ cat, capResidua });
        }
      }

      if (saturated.length === 0) {
        for (let i = 0; i < active.length; i++) {
          const cat = active[i];
          const alloc = (residuo * d[cat]) / pesoTotale;
          s[cat] += alloc;
        }
        residuo = 0;
        break;
      }

      const saturatedSet = new Set();
      for (let i = 0; i < saturated.length; i++) {
        const item = saturated[i];
        s[item.cat] += item.capResidua;
        residuo -= item.capResidua;
        saturatedSet.add(item.cat);
      }
      active = active.filter((cat) => !saturatedSet.has(cat));
    }

    let totalS = 0;
    for (let i = 0; i < categories.length; i++) {
      totalS += s[categories[i]];
    }
    const neutralTotal = Math.max(0, GLOBAL_ADAPTIVE_BUDGET - totalS);
    const neutralPerCat = neutralTotal / categories.length;

    const finalSharesPercent = {};
    const supplementPoints = {};
    for (let i = 0; i < categories.length; i++) {
      const cat = categories[i];
      const finalRatio = b[cat] - GLOBAL_ADAPTIVE_BUDGET * b[cat] + s[cat] + neutralPerCat;
      finalSharesPercent[cat] = Number((finalRatio * 100).toFixed(6));
      supplementPoints[cat] = Number((s[cat] * 100).toFixed(6));
    }

    return {
      finalSharesPercent,
      supplementPoints,
      neutralPointsPerCategory: Number((neutralPerCat * 100).toFixed(6)),
    };
  }

  function allocateIntegerCounts(sharesPercent, totalCount) {
    const categories = Object.keys(sharesPercent || {}).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
    const counts = {};
    const remainders = [];
    let assigned = 0;

    for (let i = 0; i < categories.length; i++) {
      const cat = categories[i];
      const exact = (Math.max(0, sharesPercent[cat] || 0) / 100) * totalCount;
      const floored = Math.floor(exact);
      counts[cat] = floored;
      assigned += floored;
      remainders.push({ cat, rem: exact - floored });
    }

    remainders.sort((a, b) => {
      if (Math.abs(b.rem - a.rem) > 1e-12) return b.rem - a.rem;
      return a.cat < b.cat ? -1 : a.cat > b.cat ? 1 : 0;
    });

    let remaining = totalCount - assigned;
    for (let i = 0; i < remainders.length && remaining > 0; i++) {
      counts[remainders[i].cat] += 1;
      remaining -= 1;
    }

    return counts;
  }

  async function selectCandidates(input) {
    const PRNG = global.InterrogationPRNG;
    if (!PRNG) throw new Error("InterrogationPRNG non caricato.");

    const mode = input.mode || "random";
    const pool = Array.isArray(input.candidates) ? input.candidates.slice() : [];
    const requestedCount = Math.max(1, parseInt(input.requestedCount, 10) || 10);

    if (mode === "manual") {
      const manualIds = Array.isArray(input.manualCandidateIds) ? input.manualCandidateIds : [];
      const allowDuplicates = !!input.allowDuplicates;
      const byId = new Map(pool.map((c) => [c.candidateId, c]));
      const seen = new Set();
      const selected = [];
      for (let i = 0; i < manualIds.length; i++) {
        const id = manualIds[i];
        if (!allowDuplicates && seen.has(id)) continue;
        const cand = byId.get(id);
        if (cand) {
          seen.add(id);
          selected.push(cand);
        }
      }
      return {
        mode: "manual",
        selectedCandidates: selected,
        effectiveCount: selected.length,
        selectionSnapshot: {
          algorithmVersion: ALGORITHM_VERSION,
          adaptiveQuotaAlgorithmVersion: ADAPTIVE_QUOTA_ALGORITHM_VERSION,
          canonicalOrderingVersion: PRNG.CANONICAL_ORDERING_VERSION,
          canonicalCandidateOrder: selected.map((c) => c.candidateId),
          candidatePoolFingerprint: await PRNG.computePoolFingerprint(
            PRNG.canonicalSortCandidateIds(pool.map((c) => c.candidateId)),
          ),
          prngAlgorithmId: PRNG.ALGORITHM_ID,
          prngAlgorithmVersion: PRNG.ALGORITHM_VERSION,
          seed: null,
          seedEncoding: null,
          seedSource: "manual-selection",
          seedSecurity: "non-applicable",
          prngStateAfterSelection: null,
          prngDrawCount: 0,
          prngRejectionCount: 0,
        },
      };
    }

    const seedInfo = input.seed
      ? {
          seed: PRNG.parseHexSeed(input.seed).normalized,
          seedEncoding: PRNG.SEED_ENCODING,
          seedSource: input.seedSource || "explicit-seed",
          seedSecurity: input.seedSecurity || "deterministic",
          warnings: [],
        }
      : PRNG.generateSeed();

    const prng = new PRNG.Xoshiro128StarStar(seedInfo.seed);
    const canonicalIds = PRNG.canonicalSortCandidateIds(pool.map((c) => c.candidateId));
    const poolFingerprint = await PRNG.computePoolFingerprint(canonicalIds);
    const byId = new Map(pool.map((c) => [c.candidateId, c]));
    const effectiveCount = Math.min(requestedCount, canonicalIds.length);

    let selectedCandidates = [];
    let quotaSummary = null;

    if (mode === "random" || pool.length <= 1) {
      const shuffledIds = PRNG.shuffleFisherYates(canonicalIds, prng);
      const chosenIds = shuffledIds.slice(0, effectiveCount);
      selectedCandidates = chosenIds.map((id) => byId.get(id));
    } else if (mode === "adaptive") {
      const knowledgeMap = input.knowledgeByQuestionId || new Map();
      const prioritySet = new Set(input.pendingPriorityQuestionIds || []);

      const byCat = {};
      for (let i = 0; i < canonicalIds.length; i++) {
        const cand = byId.get(canonicalIds[i]);
        const cat = cand.categoryId || cand.questionType;
        if (!byCat[cat]) byCat[cat] = [];
        byCat[cat].push(cand);
      }

      const availableCats = Object.keys(byCat).sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
      const baseShares = {};
      const reliabilityByCat = {};
      const defaultShares = input.baseSharesPercent || {
        HOME_ROW: 25,
        TASTO: 25,
        CARATTERE: 25,
        DITO: 25,
      };

      for (let i = 0; i < availableCats.length; i++) {
        const cat = availableCats[i];
        baseShares[cat] = defaultShares[cat] !== undefined ? defaultShares[cat] : 25;
        const cands = byCat[cat];
        let sumRel = 0;
        let qCount = 0;
        for (let j = 0; j < cands.length; j++) {
          const qIds = cands[j].questionSemanticIds || [];
          for (let k = 0; k < qIds.length; k++) {
            const st = knowledgeMap instanceof Map ? knowledgeMap.get(qIds[k]) : knowledgeMap[qIds[k]];
            sumRel += st && typeof st.reliability === "number" ? st.reliability : 0;
            qCount += 1;
          }
        }
        reliabilityByCat[cat] = qCount > 0 ? sumRel / qCount : 0;
      }

      const adaptiveRes = computeAdaptiveCategoryShares(baseShares, reliabilityByCat);
      const targetCounts = allocateIntegerCounts(adaptiveRes.finalSharesPercent, effectiveCount);
      quotaSummary = {
        baseShares,
        reliabilityByCat,
        finalSharesPercent: adaptiveRes.finalSharesPercent,
        targetCounts,
      };

      const scoreCandidate = (cand) => {
        let hasPriority = false;
        let maxWeakness = 0;
        const qIds = cand.questionSemanticIds || [];
        for (let k = 0; k < qIds.length; k++) {
          if (prioritySet.has(qIds[k])) hasPriority = true;
          const st = knowledgeMap instanceof Map ? knowledgeMap.get(qIds[k]) : knowledgeMap[qIds[k]];
          const w = st && st.correctedWeaknessIndex !== null && st.correctedWeaknessIndex !== undefined
            ? st.correctedWeaknessIndex
            : 50;
          if (w > maxWeakness) maxWeakness = w;
        }
        return { hasPriority, maxWeakness };
      };

      const chosen = [];
      const chosenIds = new Set();

      for (let i = 0; i < availableCats.length; i++) {
        const cat = availableCats[i];
        const needed = targetCounts[cat] || 0;
        if (needed <= 0) continue;

        const catPoolIds = PRNG.shuffleFisherYates(
          byCat[cat].map((c) => c.candidateId),
          prng,
        );
        const catPool = catPoolIds.map((id) => byId.get(id));

        catPool.sort((a, b) => {
          const sa = scoreCandidate(a);
          const sb = scoreCandidate(b);
          if (sa.hasPriority !== sb.hasPriority) return sa.hasPriority ? -1 : 1;
          if (Math.abs(sb.maxWeakness - sa.maxWeakness) > 1e-6) {
            return sb.maxWeakness - sa.maxWeakness;
          }
          return 0;
        });

        for (let j = 0; j < catPool.length && chosen.length < effectiveCount && j < needed; j++) {
          chosen.push(catPool[j]);
          chosenIds.add(catPool[j].candidateId);
        }
      }

      if (chosen.length < effectiveCount) {
        const remainingIds = PRNG.shuffleFisherYates(
          canonicalIds.filter((id) => !chosenIds.has(id)),
          prng,
        );
        for (let i = 0; i < remainingIds.length && chosen.length < effectiveCount; i++) {
          chosen.push(byId.get(remainingIds[i]));
        }
      }

      selectedCandidates = PRNG.shuffleFisherYates(chosen, prng);
    } else {
      throw new Error(`Modalità selezione non supportata: ${mode}`);
    }

    const diag = prng.getDiagnostics();
    return {
      mode,
      selectedCandidates,
      effectiveCount: selectedCandidates.length,
      quotaSummary,
      selectionSnapshot: Object.assign({}, diag, {
        algorithmVersion: ALGORITHM_VERSION,
        adaptiveQuotaAlgorithmVersion: ADAPTIVE_QUOTA_ALGORITHM_VERSION,
        seedSource: seedInfo.seedSource,
        seedSecurity: seedInfo.seedSecurity,
        warnings: seedInfo.warnings,
        canonicalCandidateOrder: canonicalIds,
        candidatePoolFingerprint: poolFingerprint,
      }),
    };
  }

  global.InterrogationSelector = Object.freeze({
    ALGORITHM_VERSION,
    ADAPTIVE_QUOTA_ALGORITHM_VERSION,
    GLOBAL_ADAPTIVE_BUDGET,
    INDIVIDUAL_CAP_RATIO,
    CANONICAL_CATEGORIES,
    computeAdaptiveCategoryShares,
    allocateIntegerCounts,
    selectCandidates,
  });
})(typeof window !== "undefined" ? window : globalThis);
