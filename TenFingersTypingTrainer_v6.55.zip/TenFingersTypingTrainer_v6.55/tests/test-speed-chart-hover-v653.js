const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");

const chartJs = fs.readFileSync(
  path.join(root, "js/analytics/statistics-manager.js"),
  "utf8",
);
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const statsCtrl = fs.readFileSync(
  path.join(root, "js/app/controller/metodi-statistiche.js"),
  "utf8",
);

// 1. Nessun bordino bianco sui punti normali
assert.ok(
  chartJs.includes('stroke="${isSel ? "#ffffff" : "none"}"'),
  "I punti normali devono avere stroke=\"none\"",
);
assert.ok(
  chartJs.includes('stroke-width="${isSel ? 1.5 : 0}"'),
  "I punti normali devono avere stroke-width=\"0\"",
);

// 2. Regole CSS O(1) per Opzione A (attenuazione altri + ingrandimento matching a r: 8)
assert.ok(
  css.includes("#speedSvgPlot.hover-filter-active .speed-point") &&
    css.includes("opacity: 0.25;"),
  "Manca regola CSS Opzione A per attenuazione degli altri campioni",
);

for (let t = 1; t <= 8; t++) {
  assert.ok(
    css.includes(`#speedSvgPlot.hover-type-${t} .speed-point[data-type="${t}"]`),
    `Manca regola hover-type-${t} in app.css`,
  );
}

// 3. Listener O(1) in metodi-statistiche.js
assert.ok(
  statsCtrl.includes('document.querySelectorAll(".speed-filter-label")') &&
    statsCtrl.includes("hover-filter-active") &&
    statsCtrl.includes("hover-type-${typeVal}"),
  "Mancano i listener O(1) su .speed-filter-label in setupStatsUI()",
);

console.log("PASS test-speed-chart-hover-v653");
