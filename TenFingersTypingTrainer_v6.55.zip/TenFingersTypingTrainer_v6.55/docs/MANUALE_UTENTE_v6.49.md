# Manuale Utente TenFingersTypingTrainer v6.49

Questa guida integra il manuale della versione 6.48 con l'aggiornamento introdotto nella versione 6.49.

## 1. Semplificazione del pannello di avvio Interrogazione
Nel pannello di avvio di **🎓 Interrogazione** è stata rimossa la casella superflua **"Risposta Per Dito"**, rendendo più pulita l'impostazione della sessione. Nelle domande **Per Dito**, resta invariata l'interazione diretta sulla tastiera per abbinare ciascun tasto del dito al proprio carattere.
