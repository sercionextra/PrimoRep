# TenFingersTypingTrainer v6.34

Applicazione web stand-alone per l'allenamento alla digitazione a 10 dita su tastiera italiana QWERTY, dotata di dettatura vocale adattiva e modalità di Interrogazione grafica sul layout della tastiera.

## Novità principali v6.34

- **Finestra Interrogazione fino a tutta altezza (`100vh`) e `top: 0`:** `#interrogationDialog` può essere ridimensionata per l'intera altezza visibile della finestra del browser e trascinata fino a `top: 0` (coprendo anche l'header principale), mantenendo `minTop = 60` per le altre finestre fluttuanti.
- **Fix layout italiano `key_igrave` (`ì`) e `key_quote` (`'`):** rimossi i caratteri AltGr non presenti (`~` da `ì`/`^` e `` ` `` da `'`/`?`) dalla tastiera SVG, da `KEY_MAP`, dai metadati e dal catalogo dell'Interrogazione.
- **Popover "Seleziona carattere / tasto" ancorato orizzontalmente:** `#interrAsciiPopover` ora si posiziona dinamicamente in orizzontale (e sopra/sotto) in prossimità del pulsante cliccato, restando sempre entro i margini della viewport.

## Novità principali v6.33

- **Gestione completa finestra Interrogazione:** resa traslabile dalla barra del titolo, aggiunti i pulsanti `↺ Ripristina` e `⛶ Ingrandisci` / `🗗 Riduci`, integrato il ripristino in `Reset finestre` di Gestione Utenti e risolto il bug di spostamento verso il basso durante il ridimensionamento.
- **Fix pallini mani & riordino Blocco 1 (v6.32):** risolto il click sui pallini delle mani nei quesiti `CARATTERE`/`TASTO` per valorizzare tutti i 5 dropdown di `1) Descrizione Accordo`, con nuovo ordine delle colonne (a sinistra Mano, Dito, Direzione sovraccarico, Estensione laterale; a destra Estensione longitudinale, Accordo Modificatore, Conferma/Consulta).
- **Chiusura con riepilogo rapido (v6.32):** i pulsanti `Concludi sessione`, `Sospendi` e `Abbandona` chiudono la finestra Interrogazione e mostrano un riepilogo sintetico (`showAppAlert`) con punteggio e conteggi.

- **Toggle selezione manuale Interrogazione:** un secondo click su tasto, dito o pallino delle mani (o sulla "✕" del chip) rimuove l'elemento dall'elenco e toglie l'evidenziazione verde da tastiera e mani, mantenendo la selezione sincronizzata anche al cambio di tipo interrogazione.
- **Storico Interrogazioni allineato al grafico delle velocità:** finestra Interrogazione ridimensionabile, selettori per `Punteggio`, `% Rendimento`, `N. Totale`, `N. Corrette`, `N. Errate`, `N. Consultate`, `N. Ignorate`, filtri per tipologia (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`) e range Date/Ore separati con `Reset Periodo`, selezione a 3 click, crosshair rosso/azzurro, evidenziazione hover verde, `Elimina Selezionati`, `Elimina Non Selezionati`, `Elimina Archivio Storico` e `Ripeti interrogazione` su singolo campione (tutti o per esito).
- **Protezione di rete applicativa mantenuta:** CSP restrittiva (`connect-src 'none'`) e `network-isolation-guard.js` continuano a bloccare qualsiasi richiesta di rete diretta dal codice applicativo.

## Verifiche automatiche

Dalla directory del progetto eseguire:

```bash
for f in tests/*.js; do echo "=== $f ==="; node "$f"; done
```
