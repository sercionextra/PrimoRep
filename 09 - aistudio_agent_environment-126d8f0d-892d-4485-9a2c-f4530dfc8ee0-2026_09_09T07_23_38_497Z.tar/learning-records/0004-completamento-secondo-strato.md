# Risoluzione del secondo strato (F2L completo principianti)

L'utente ha completato l'inserimento di tutti e 4 gli spigoli della fascia centrale coordinando la rotazione preliminare di allontanamento (`U` / `U'`) con la combinazione di *Sexy Move Destra* e *Sexy Move Sinistra* (`L' U' L U`). Ha padroneggiato l'uso delle mosse speculari e la gestione dell'orientamento del cubo nello spazio. I primi due strati (F2L) sono ora completamente risolti.
