/* TenFingersTypingTrainer v6.0 | export-utils.js | Refactoring compatibile: comportamento sorgente preservato. */
// =======================================================
// File: /workspace/main_B_(v6.0).js
// Versione: 6.0
// Data rilascio: 27/10/2026
// Note di rilascio v6.0:
//   1. Allineamento globale alla Release v6.0.
//   2. Integrazione dei trigger vocali per battuta errata (notifyError) e correzione scalare con Backspace (notifyErrorCorrection).
// =======================================================

// =======================================================
// HELPER NOME FILE BACKUP: TFTT_YYYYMMAA_hhmm_<Nome Utente>.json (v.4.1)
// =======================================================
function getExportFileName(userName, d = new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  const yyyy = d.getFullYear();
  const mm = pad(d.getMonth() + 1);
  const aa = pad(d.getDate()); // Giorno del mese a due cifre
  const hh = pad(d.getHours());
  const min = pad(d.getMinutes());
  const cleanUser = (userName || "profile").replace(/[^a-zA-Z0-9_\-]/g, "_");
  return `TFTT_${yyyy}${mm}${aa}_${hh}${min}_${cleanUser}.json`;
}

// =======================================================
// STATISTICS MANAGER (Histogram & Speed Chart con Filtro Temporale Range)
// =======================================================
