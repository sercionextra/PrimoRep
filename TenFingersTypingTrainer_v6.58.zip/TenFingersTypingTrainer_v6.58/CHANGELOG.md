## [6.58]
- Aggiornamento messaggio Digitazione Libera, promemoria periodico di backup e avvisi prioritari in Guida e Manuale Utente (`metodi-toolbar-modalita.js`, `metodi-finestre-layout.js`, `metodi-input-digitazione.js`, `metodi-interrogazione.js`, `controller-core.js`, `help.html`, `docs/MANUALE_UTENTE_v6.58.md`):
  1. Aggiornato il messaggio al clic su "Aggiungi alle Statistiche" in modalità `Typing (Libera)` con l'indicazione di premere `CTRL+SHIFT+X` per avviare un nuovo esercizio.
  2. Esteso `showNotificationToast(message, icon, durationMs)` con durata configurabile e `max-width` leggibile; aggiunto `maybeShowBackupReminderToast()` con intervallo minimo configurabile (`backupReminderIntervalMs = 10 * 60 * 1000`, primo avvio immediato nella sessione) invocato al completamento degli esercizi, al salvataggio della Digitazione Libera e al termine di una sessione di Interrogazione.
  3. Inseriti come primo blocco prioritario in `help.html` e in `docs/MANUALE_UTENTE_v6.58.md` gli avvisi su Backup/Portabilità JSON (`💾 Esporta Profilo` / `📂 Importa Profilo`), ridimensionamento con `CTRL + Rotella del mouse` o zoom browser, ripristino layout tastiera con `ALT+SHIFT` e recupero del focus con click sull'applicazione.
- Aggiornati `index.html`, `help.html`, `README.md`, `docs/ARCHITETTURA_v6.58.md`, `docs/MANUALE_UTENTE_v6.58.md`, `tests/test-backup-reminder-v658.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.57]
- Aggiornato il colore di contrasto dei riquadri delle posizioni a riposo nei temi `Dark` e `Matrix` (`assets/styles/app.css`):
  1. Impostato `--base-dot: #fdfdfa;` sia in `body.theme-dark` che in `body.theme-matrix`.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.57.md`, `docs/MANUALE_UTENTE_v6.57.md`, `tests/test-home-row-colors-v657.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.56]
- Riquadratura delle posizioni a riposo sulla Tastiera Virtuale (`index.html`, `assets/styles/app.css`, `js/ui/interrogation-svg-renderer.js`):
  1. Rimossi gli 8 `<circle class="base-dot">` dai tasti `a, s, d, f, j, k, l, ò`, mantenendo i trattini tattili `.key-bump` su `f` e `j`.
  2. Aggiunti due rettangoli arrotondati `.home-row-frame` (`#homeRowFrameLeft` per `a, s, d, f` e `#homeRowFrameRight` per `j, k, l, ò`) sopra i tasti con `fill: none`, `stroke: var(--base-dot)`, `stroke-width: 2`, `rx="8"` e `pointer-events: none`.
  3. Rimozione esplicita di `.home-row-frame` dal clone SVG in `_mountKeyboard()` (`interrogation-svg-renderer.js`) e occultamento CSS sotto `.interr-keyboard-bn` in `app.css` per non fornire indizi in Modalità Interrogazione.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.56.md`, `docs/MANUALE_UTENTE_v6.56.md`, `tests/test-home-row-frames-v656.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.55]
- Risolto bug di perdita colori alla de-selezione nel grafico delle velocità e aggiunto filtro temporale da selezione (`statistics-manager.js`, `metodi-statistiche.js`, `index.html`, `app.css`):
  1. In `clearSelection()` e nel ramo `else` di `applySelection()` (`statistics-manager.js`), ripristinati `fill` tramite `this.getSampleTypeColor(sampleType)`, `stroke="none"`, `stroke-width="0"` e `r="4"` invece del precedente valore fisso `#3b82f6`.
  2. Aggiunto il metodo `applySelectionDateTimeRange()` in `StatisticsManager` e il pulsante `#btnFilterToSelection` ("🔍 Filtra Periodo Selezione") in `index.html` / `app.css` / `metodi-statistiche.js`, visibile solo quando uno o più campioni sono selezionati, per impostare automaticamente `filterStartDate`, `filterStartTime`, `filterEndDate` e `filterEndTime` sull'intervallo dei campioni selezionati.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.55.md`, `docs/MANUALE_UTENTE_v6.55.md`, `tests/test-selection-colors-filter-v655.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.54]
- Rifinitura visiva dell'evidenziazione in hover sui filtri sessione nel grafico delle velocità (`assets/styles/app.css`):
  1. Ridotto il raggio dei campioni evidenziati da `8px` a `5px` (`r: 5 !important`) e rimosso il bordino bianco durante l'hover sui filtri.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.54.md`, `docs/MANUALE_UTENTE_v6.54.md`, `tests/test-speed-chart-hover-v654.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.53]
- Miglioramento contrasto visivo ed evidenziazione interattiva O(1) nel grafico delle velocità (`statistics-manager.js`, `app.css`, `metodi-statistiche.js`):
  1. Aggiornata la palette in `getSampleTypeColor()` e `.speed-filter-type-1..8` su famiglie cromatiche ben distinte (`#3b82f6`, `#facc15`, `#06b6d4`, `#f472b6`, `#a855f7`, `#ef4444`, `#94a3b8`, `#be185d`).
  2. Rimosso il bordino bianco dai punti normali (`stroke="none"`, `stroke-width="0"`) per eliminare l'alone bianco nei cluster densi (mantenuto solo su `.selected` e `.inspected`).
  3. Aggiunto hover O(1) su `.speed-filter-label` in `setupStatsUI()`: al passaggio del mouse su un filtro, `#speedSvgPlot` riceve `hover-filter-active` + `hover-type-X`, attenuando gli altri campioni (`opacity: 0.25`) e ingrandendo a `8px` i campioni della modalità puntata.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.53.md`, `docs/MANUALE_UTENTE_v6.53.md`, `tests/test-speed-chart-hover-v653.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.52]
- Colorazione distinta per modalità dei campioni nel grafico delle velocità (`statistics-manager.js`, `app.css`, `index.html`):
  1. Aggiunto `getSampleTypeColor(tipoCampione)` in `StatisticsManager` con 8 tinte distinte per `TipoCampione` 1..8 (escludendo verde = campione evidenziato e arancione = campioni selezionati) e fallback neutro `#94a3b8`.
  2. Resa neutra la polilinea di collegamento (`rgba(148, 163, 184, 0.55)`, spessore `2`) e mantenuto il raggio dei punti normali a `4px` (`6px` per selezionati, `7px` per evidenziati).
  3. Aggiunte le classi `.speed-filter-label` e `.speed-filter-type-1..8` con `border-bottom: 4px solid ...` sulle `<label>` dei filtri sessione in `index.html` per fungere da legenda compatta compatibile con CSP (`style-src-attr 'none'`).
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.52.md`, `docs/MANUALE_UTENTE_v6.52.md`, `tests/test-speed-chart-colors-v652.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.51]
- Risolta la mancata persistenza dello stato in modalità **Phrases - Custom** alla chiusura e riapertura del browser (`profile-manager.js`, `metodi-profili-modali.js`, `metodi-toolbar-modalita.js`, `metodi-navigazione-dialoghi.js`):
  1. Esteso lo schema del profilo utente in `ProfileManager` con i campi `LessonsSource` (`"standard"` | `"custom"`), `CustomLesson` e `CustomExercise` (con inizializzazione difensiva in `loadUser()` per i profili esistenti), mantenendo isolato l'avanzamento del corso Standard (`Lesson`, `MaxLessonReached`, `Exercise`).
  2. Aggiornato `setLessonsSource()` per ripristinare automaticamente il cursore salvato della sorgente selezionata (con clamp sugli indici validi) e persistere `LessonsSource` quando `persist` è attivo.
  3. Aggiornato `loginUser()` per ri-parsare `customLessons` da `prof.CustomText` e ripristinare la sorgente salvata (`"custom"` se `Mode === 0` e `LessonsSource === "custom"`), evitando il reset forzato a `"standard"`.
  4. Aggiornati `cboLessons`, `navLesson()`, `navPhrase()`, `randomPhrase()` e `confirmSelectPhrase()` per persistere `CustomLesson` e `CustomExercise` quando `activeLessonsSource === "custom"`.
  5. Aggiornato `updateModeUI()` per commutare temporaneamente a `"standard"` nelle modalità diverse da `0` senza sovrascrivere `LessonsSource` sul profilo (Opzione B), ripristinando automaticamente `"custom"` al ritorno su `Phrases`.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.51.md`, `docs/MANUALE_UTENTE_v6.51.md`, `tests/test-custom-persistence-v651.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.50]
- Risolti due bug nei metadati e nella UI di **Interrogazione** (`interrogation-layout-metadata.js`, `interrogation-ui.js`):
  1. Corretto `lateralExt` del tasto `key_backslash` (`\` / `|`) da `1` a `2` (con `lateralDir: "sn"`, `longitudinalExt: 2`).
  2. Aggiunta l'opzione `-2` (`-2 (2 righe sotto riposo)`) nella DropDownList `Estensione longitudinale` (`selLongExt`) per consentire la selezione corretta della riga inferiore (tra cui `SPAZIO`, `Ctrl`, `Win`, `Alt`, `AltGr`, `Menu`).
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.50.md`, `docs/MANUALE_UTENTE_v6.50.md`, `tests/test-interrogation-v650.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.49]
- Rimossa dalla finestra **Interrogazione** la DropDownList orfana **"Risposta Per Dito"** (`#interrogationFingerModeSelect` in `index.html` e relativi riferimenti inutilizzati `this.fingerMode` in `js/ui/interrogation-ui.js`), mantenendo il comportamento standard a 1 carattere per tasto fisico.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.49.md`, `docs/MANUALE_UTENTE_v6.49.md`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.48]
- Tracciamento dell'origine nelle statistiche di **Random This Phrase** (`mode === 5`, `typing-engine.js`):
  - Aggiunte `this.lastOriginTitle` e `this.randomSourceTitle` in `TypingEngine` per catturare il titolo dell'esercizio di origine (`Custom X: ...`, `Lezione X: ...`, `Random: ...`, `Fonemi Italiani`, `All Chars`, `Digitazione Libera`, `Weaknesses (Carenze)`) prima dei reset di stato al cambio modalità.
  - In `getCurrentExerciseTitle()` per `mode === 5`, restituito il formato `"Random This Phrase (<Origine>)"`, preservando l'origine reale anche su rimescolamenti consecutivi senza annidamenti e mantenendo `TipoCampione: 5`.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.48.md`, `docs/MANUALE_UTENTE_v6.48.md`, `tests/test-random-this-phrase.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.47]
- Completata la fix di **Random This Phrase** (`mode === 5`) dopo il completamento di un esercizio in **Digitazione Libera** (`recordManualTypingSample()` / `#btnAddStatistic`):
  - In `TypingEngine.resetTypingSession()`, salvataggio preventivo del testo digitato non vuoto in `this.lastTypedPhrase` prima dell'azzeramento di `this.typedText` (evitando la perdita del testo quando `recordManualTypingSample()` chiude la sessione di Digitazione Libera).
  - In `TypingEngine.loadExercise()` (`mode === 5`), normalizzazione dei caratteri `\n` in `®` prima del rimescolamento.
  - In `AppController.setupToolbar()` (`#btnRandomThisPhrase`), verifica congiunta su `typedText` e `lastTypedPhrase` in `mode === 4`.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.47.md`, `docs/MANUALE_UTENTE_v6.47.md`, `tests/test-random-this-phrase.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.46]
- Risolta la modalità **Random This Phrase** (`mode === 5`) affinché rimescoli sempre i caratteri dell'ultima frase attiva/digitata in qualunque modalità precedente (`typing-engine.js`, `metodi-toolbar-modalita.js`, `metodi-navigazione-dialoghi.js`):
  - In `TypingEngine.initSession()`, salvataggio preventivo del testo digitato non vuoto in `this.lastTypedPhrase` prima dell'azzeramento della sessione.
  - In `TypingEngine.loadExercise()` (`mode === 5`), priorità assoluta a `this.originText`, poi `this.lastTypedPhrase` (per provenienza da *Digitazione Libera*), e solo come ultimo fallback alle lezioni del corso se non esiste alcun testo precedente.
  - Sbloccato `#btnRandomThisPhrase` anche in modalità `4` (*Digitazione Libera*): rimescola ciò che è stato digitato se presente, altrimenti mostra una notifica di avviso.
  - Aggiornata l'etichetta in `startExercise()` per `mode === 5` a `"N caratteri rimescolati"`.
- Aggiornati `index.html`, `help.html`, `README.md`, `js/app/controller/controller-core.js`, `docs/ARCHITETTURA_v6.46.md`, `docs/MANUALE_UTENTE_v6.46.md`, `tests/test-random-this-phrase.js`, `tests/runtime-smoke.js`, `tests/test-build-manifest.js` e `BUILD_MANIFEST.json`.

## [6.45]
- Risolta la mancata registrazione della statistica **Custom** (`TipoCampione: 2`) in modalità **Phrases - Custom** (`typing-engine.js`, `metodi-profili-modali.js`, `metodi-toolbar-modalita.js`):
  - Aggiunta la proprietà `lessonsSource` (`"standard"` | `"custom"`) in `TypingEngine`, sincronizzata da `AppController.setLessonsSource(source, { skipStart })`.
  - In `TypingEngine.recordCompletedSample()`, per `mode === 0` con `lessonsSource === "custom"`, il campione viene registrato con `TipoCampione: 2` (anziché `1`).
  - In `TypingEngine.getCurrentExerciseTitle()`, i campioni custom in `mode === 0` utilizzano il prefisso `"Custom X: ..."` invece di `"Lezione X: ..."`.
  - In `AppController.updateModeUI()`, esteso il ripristino automatico alla sorgente `"standard"` (con `skipStart: true`) per qualsiasi `mode !== 0`, in coerenza con il blocco del selettore sorgente nelle modalità `1..6`.
- Aggiornati `help.html`, `docs/MANUALE_UTENTE_v6.45.md`, `docs/ARCHITETTURA_v6.45.md`, `tests/test-custom-stats-sample.js`, `tests/test-build-manifest.js`, `tests/test-interrogation-v644.js` e `BUILD_MANIFEST.json`.

## [6.44]
- Estensione del mascheramento **Piano di Studio** alla sezione **3) Tasti intorno (Margherita)** (`lesson-curriculum-scope.js`, `interrogation-session-manager.js`, `interrogation-ui.js`):
  - I tasti confinanti non ancora studiati mostrano `"Da studiare (Lez. X)"` (o `"Non in programma"` per tasti di servizio non trattati nel corso, es. `CapsLock`/`Ctrl`/`Alt`).
  - I bordi tastiera (`NONE`) restano sempre in programma.
  - Nelle coppie miste (`Coppia sopra` / `Coppia sotto` con 1 solo tasto studiato), la scelta richiede esclusivamente il tasto in programma.
  - I gruppi della Margherita interamente fuori programma vengono disabilitati e i relativi 3 punti vengono scalati dal `maxScore` della sessione.
- Aggiornati `help.html`, `docs/MANUALE_UTENTE_v6.44.md`, `docs/ARCHITETTURA_v6.44.md`, `tests/test-interrogation-v644.js` e `BUILD_MANIFEST.json`.

## [6.43]
- Nuovo ambito predefinito **Piano di Studio (solo lezioni seguite)** in Interrogazione (`lesson-curriculum-scope.js`, `profile-manager.js`, `interrogation-catalog.js`, `interrogation-session-manager.js`, `interrogation-ui.js`, `metodi-interrogazione.js`, `metodi-toolbar-modalita.js`, `index.html`, `app.css`):
  - Proposto come prima opzione predefinita nel form di avvio Interrogazione, con selettore della lezione limite (`Fino alla lezione`) preimpostato su `MaxLessonReached` del profilo.
  - Pulsante **Imposta come traguardo** per correggere esplicitamente `MaxLessonReached` nel profilo (anche in riduzione, previa conferma) qualora l'utente avesse aperto per errore o curiosità una lezione futura.
  - Filtraggio rigoroso delle candidate (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`) e mascheramento in ingresso degli slot non ancora studiati nel Blocco 2 (`Da studiare (Lez. X)`), senza penalità sul punteggio né sulle statistiche.
  - Filtro ambito nello Storico (`Tutte` / `Piano di Studio` / `Tastiera Completa`) e filtraggio contestuale nella Classifica Urgenza.
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.43.md`, `docs/MANUALE_UTENTE_v6.43.md`, `tests/test-interrogation-v643.js` e `BUILD_MANIFEST.json`.

## [6.42]
- Correzione aggregazione eventi a blocchi in `computeUrgencyRanking()` (`interrogation-knowledge.js`):
  - Inclusi gli eventi di esposizione salvati da `recordBlockEvaluation()` con prefisso `${candidateId}.${blockId}` (oltre ai `questionSemanticIds` canonici), evitando che i tasti e le dita appena interrogati restassero bloccati a 0 verifiche ("Scarsa indagine" 25 pt).

## [6.41]
- Correzione rendering Grafico Urgenza (`interrogation-ui.js`):
  - Definita la funzione helper `createSvgEl(tag, attrs)` a livello di modulo (mancante nella v6.40, impediva il disegno delle barre SVG).
  - Corretto il caricamento eventi in `_loadUrgencyData()` usando `repo.getExposureEvents(profileId)` al posto del nome errato `getKnowledgeEvents`.

## [6.40]
- Secondo grafico nella vista "Mostra storico" dell'Interrogazione (`index.html`, `app.css`, `interrogation-knowledge.js`, `interrogation-ui.js`):
  - Switcher segmentato nell'header della finestra Interrogazioni (`📈 1. Storico` / `📊 2. Urgenza`, visibile solo in vista `history`), con scorrimento fluido tra `#interrHistorySection1` e `#interrHistorySection2` e sincronizzazione dei pulsanti su scroll manuale (stesso pattern di `Statistiche`).
  - Motore puro `InterrogationKnowledge.computeUrgencyRanking()` su scala 0–125 per tutti i Tasti/Caratteri (`CARATTERE` + `TASTO`) e le 10 Dita (`DITO` + `HOME_ROW`), con 5 contributi pesati: Errori (40), Consultazioni (25), Ritardo Ripasso (20), Mancato Consolidamento (15) e Scarsa Indagine (25).
  - Istogramma SVG a barre impilate a 5 colori con 5 checkbox per includere/escludere le motivazioni, filtro entità (`Tutti`, `Solo Tasti`, `Solo Dita`), box dettaglio al passaggio del mouse e click su una barra per avviare un'interrogazione mirata previa conferma.
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.40.md`, `docs/MANUALE_UTENTE_v6.40.md`, `tests/test-interrogation-v640.js` e `BUILD_MANIFEST.json`.

## [6.39]
- Notifica toast per sessione sospesa (`metodi-interrogazione.js`, `interrogation-ui.js`, `app.css`):
  - Collegata `showToast` a `this.showNotificationToast(msg, icon)` (lo stesso meccanismo usato dai pulsanti `Zoom-in` e `Zoom-out`).
  - Rimosso `btnStart.disabled = true` in `showSetupView()` (sostituito con classe `.is-blocked`) affinché il click su `Avvia Interrogazione` continui a essere intercettato per mostrare il messaggio toast `"Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova."` (anche in `_startRepeatSession()`).
- Richiamo target nella barra del titolo del selettore caratteri (`index.html`, `app.css`, `interrogation-ui.js`):
  - Aggiunto `#interrAsciiPopoverTarget` sulla destra della barra del titolo di `#interrAsciiPopover` (prima del pulsante `✕`), popolato automaticamente con il richiamo al carattere/target sotto esame (es. `CARATTERE: "X"`).

## [6.38]
- Finestra "Seleziona carattere / tasto" (`app.css`, `interrogation-ui.js`):
  - Ridotta la larghezza da `min(880px, 96vw)` a `min(780px, 96vw)` (circa 100px in meno), mantenendo tutte le 26 lettere su una riga.
  - Centrate orizzontalmente le righe dei tasti (`.interr-ascii-row { justify-content: center; }`) e i pulsanti `NESSUNO` (`.interr-ascii-none { align-self: center; }`).

## [6.37]
- Blocco avvio nuova interrogazione in presenza di sessione sospesa:
  - Backend (`interrogation-session-manager.js`): `createSession()` verifica `getSuspendedSession(profileId)` e rifiuta la creazione di una nuova sessione finché ne esiste una sospesa.
  - UI (`interrogation-ui.js`): `showSetupView()` disabilita `#btnStartInterrogation` in presenza di sessione sospesa; `handleStartSession()` e `_startRepeatSession()` bloccano l'avvio mostrando un messaggio esplicito.
- Finestra "Seleziona carattere / tasto" (`app.css`, `interrogation-ui.js`): allargata a `min(880px, 96vw)` affinché tutte le 26 lettere dell'alfabeto siano visibili su un'unica riga.
- Titolo domanda (`app.css`): aggiunto `font-weight: bold;` alla regola `#target`.

## [6.36]
- Fix chiusura sessione Interrogazione (`metodi-interrogazione.js`, `interrogation-ui.js`):
  - In `onSessionComplete` (`metodi-interrogazione.js`), sostituito `this.profileMgr.save()` (metodo inesistente su `ProfileManager`) con `saveProfile()` (con fallback guardato), eliminando il `TypeError` che impediva a `handleComplete()` di azzerare `this.activeSession`, chiudere la finestra e mostrare il riepilogo finale (e che causava gli errori sui click successivi di `Concludi sessione`, `Sospendi` e `Abbandona`).
  - In `handleSuspend()`, `handleAbandonActive()` e `handleComplete()` (`interrogation-ui.js`), usato `currentSess.profileId || this.getProfileId()` e protette le chiamate e la callback `onSessionComplete` con `try/catch`.

## [6.35]
- Tastiera B/N delle interrogazioni (`#interrKeyboardHost` / `.interr-keyboard-bn`): rimossi i punti azzurri della posizione di riposo sui tasti `[a, s, d, f, j, k, l, ò]` (`.base-dot`) e i trattini in rilievo sui tasti `f` e `j` (`.key-bump`).
- Titolo domanda interrogazione (`#interrogationQuestionTitle`): evidenziato lo scopo specifico della domanda tramite `<span id="target">` (sfondo giallo, testo nero, `x-large`) e titolo in giallo (`x-large`) per tutte le tipologie (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`).
- Interrogazione `HOME_ROW` (Posizione di Riposo): pulsante `Seleziona tasto #x su tastiera` spostato come ultimo controllo dopo `Carattere...` e `Dito...`; assegnato un colore distinto a ciascuna delle 4 righe (`interr-homerow-pick-0..3` e `interr-key-row-0..3`) abbinato al tasto evidenziato sulla tastiera B/N e rimosso l'indizio testuale del tasto tra parentesi sul pulsante.
- Finestra "Seleziona carattere / tasto" (`#interrAsciiPopover`): riordinati i caratteri e i tasti speciali per tipologie e righe con pulsante `NESSUNO` (valore canonico `NONE`) sia in alto che in basso; aggiunto il titolo dinamico dello scopo di selezione e semplificato l'input per `Coppia sopra` e `Coppia sotto` con un unico pulsante `Scegli...` che guida la selezione sequenziale dei due tasti nell'ordine sinistra → destra prima di chiudere la finestra.

## [6.34]
- Finestra Interrogazione (`#interrogationDialog`): abilitato il ridimensionamento fino a tutta l'altezza visibile (`100vh`) e il trascinamento (drag) fino a `top: 0` (coprendo anche l'header dell'app) tramite `data-allow-full-viewport="1"` in `WindowManager`, mantenendo `minTop = 60` per le altre finestre fluttuanti.
- Fix layout italiano QWERTY: rimossi i caratteri AltGr errati `~` dal tasto `ì`/`^` (`key_igrave`) e `` ` `` dal tasto `'`/`?` (`key_quote`) in `index.html`, `keyboard-map.js`, `interrogation-layout-metadata.js` e `interrogation-catalog-data.js` (catalogo aggiornato a 109 mapping, 439 definizioni, 223 candidate).
- Popover "Seleziona carattere / tasto" (`#interrAsciiPopover`): in `_openAsciiPopover`, calcolata dinamicamente la posizione orizzontale (centrata sul pulsante cliccato) e verticale (sotto o sopra a seconda dello spazio disponibile) entro i margini della viewport via CSSOM (CSP-safe).

## [6.33]
- Finestra Interrogazione (`#interrogationDialog`) resa traslabile dalla barra del titolo (`#interrogationWindowHeader`) con salvataggio di posizione e dimensioni nel profilo utente.
- Aggiunti i pulsanti `↺ Ripristina` (`#btnInterrogationResetLayout`) e `⛶ Ingrandisci` / `🗗 Riduci` (`#btnInterrogationMaximize`) nell'header della finestra Interrogazione, allineati alla finestra Statistiche.
- Integrato il ripristino della finestra Interrogazione nel pulsante `Reset finestre` della finestra "Gestione Utenti" (`resetAllWindowLayouts()`).
- Risolto il bug di ridimensionamento che spostava progressivamente `#interrogationDialog` verso il basso e fuori schermo (impostando `position: fixed; margin: 0;` invece di `position: relative;` all'interno della modale flex-centrata).

## [6.32]
- Corretto bug sul click dei pallini sulle mani nei quesiti `CARATTERE`/`TASTO` (`meta.getKeyExtension` invece di `meta.getKeyExtensions`, con fallback `resolveKeyIdFromToken`) per valorizzare Mano, Dito, Direzione sovraccarico, Estensione laterale ed Estensione longitudinale.
- Riordinati i controlli in "1) Descrizione Accordo": colonna sinistra (`Mano`, `Dito`, `Direzione sovraccarico`, `Estensione laterale`), colonna destra (`Estensione longitudinale`, `Accordo Modificatore`, pulsanti `Conferma Accordo` e `Consulta (+1)`).
- I pulsanti `Concludi sessione`, `Sospendi` e `Abbandona` ora chiudono la finestra Interrogazione e mostrano un breve riepilogo tramite `showAppAlert` con punteggio e conteggi (Corrette, Errate, Consultate, Ignorate).

## [6.31]
- Selezione manuale nell'Interrogazione: un secondo click su tasto, dito o pallino delle mani rimuove l'elemento dall'elenco e deseleziona l'evidenziazione verde; anche la rimozione tramite "✕" sul chip toglie l'evidenziazione verde da tastiera e mani; supportata la multi-selezione delle dita e la sincronizzazione al cambio tipo interrogazione.
- Finestra Interrogazione (`#interrogationDialog`) resa ridimensionabile con ricalcolo dinamico del grafico dello storico.
- Vista "Mostra storico" allineata al grafico delle velocità delle Statistiche:
  - Filtri per tipologia quesito (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`) e range Date/Ore separati con cancellazione singola, validazione e pulsante "Reset Periodo".
  - Selettori metriche: `Punteggio`, `% Rendimento`, `N. Totale`, `N. Corrette`, `N. Errate`, `N. Consultate`, `N. Ignorate`.
  - Selezione campioni/intervalli a 3 click, crosshair rosso/azzurro, scrubber Data/Ora, evidenziazione verde in hover con dettaglio completo (`score / maxScore pt (pct%)`, tipo, numero domande e conteggi).
  - Pulsanti `Elimina Selezionati`, `Elimina Non Selezionati` (visibili nel range), `Elimina Archivio Storico` con conferma modale.
  - Pulsante `🔁 Ripeti interrogazione` su singolo campione selezionato per ripetere tutti i quesiti o filtrarli per esito (`Corrette`, `Errate`, `Consultate`, `Ignorate`).
- Memorizzazione su `sessions` (e fallback da `sessionItems`) di `maxScore` reale, `questionTypes`, `totalBlocks`, `correctCount`, `incorrectCount`, `consultedCount` e `ignoredCount`.

## [6.30]
- Aggiunto pulsante "Mostra storico" nella finestra Interrogazione con grafico SVG interattivo, crosshair rosso/verde, filtro data/ora ed eliminazione campioni selezionati o esclusi.
- Rimossi simboli AltGr errati `{`, `[`, `]`, `}` dai tasti `7`, `8`, `9`, `0` su tastiera principale, tastiera Interrogazione e anteprima tasto.
- Compattata ulteriormente la finestra Interrogazione (spazi ridotti sopra/sotto tastiera e mani, layout compatto per Accordo Modificatore, Conferma e Consulta).
- Posizionata la palette ASCII "Seleziona carattere / tasto" in prossimità dell'elemento cliccato.
- Fix priorità click sui puntini delle mani e delle estensioni laterali (`pointer-events` + raggio hit aumentato) per valorizzare tutti i dropdown di Descrizione Accordo.
- Impostati tutti i dropdown di "1) Descrizione Accordo" su voce vuota iniziale.
- Accettati `0` e `+1` per `INVIO` (estensione longitudinale) e `+` / `ù` a sinistra di `INVIO` (con svelamento di entrambi).
- Rinnovata Interrogazione per Dito: nessun suggerimento iniziale, rimossi filtri Estensione/Direzione, click su tasto -> giallo + palette ASCII -> badge utente sul tasto -> verifica abbinamento tasto-carattere -> verde per corretti, giallo persistente per fuori posto.

## [6.29]
- Rimossi gli stati live dell'esercizio di digitazione (tasto rosso lampeggiante e contatore Errori) dalla finestra Interrogazione.
- Impedita l'anticipazione dei caratteri non ancora risposti sulle anteprime keycap e sulla tastiera B/N.
- Ridotta l'altezza della finestra Interrogazione spostando Domanda/Target/Punteggio (p/max) nella barra del titolo ed eliminando il footer duplicato.
- Sostituiti i tracciati dei polpastrelli con sagome anatomiche complete delle 10 dita e rimosso il doppio layer di pallini sulle mani.
- Collegato il clic su dita e pallini delle mani alla compilazione automatica dei dropdown del Blocco 1 (senza conferma automatica).

## [6.28]
- Spostato il pulsante Interrogazione tra Zoom-in e Zoom-out e Utenti nell'header.
- Rimosso il vincolo max-width: 460px sulla finestra Interrogazione (larghezza 98vw, tastiera B/N e mani affiancate senza scroll laterale).
- Risolta la derivazione di keyId, character e fingerId in InterrogationCatalog per sbloccare sia la modalita Casuale sia la modalita Manuale.
- Attivato automaticamente l'ascolto tastiera fisica in modalita Manuale e pointer-events sulle mani/pallini SVG.

# Changelog — TenFingersTypingTrainer

## v6.27
- Riprogettata l'interfaccia grafica della modalità **Interrogazione**:
  - Vista superiore affiancata con **Tastiera B/N anonima** (priva di simboli, che si popola progressivamente) e **Mani SVG interattive** con pallini cliccabili calibrati (almeno 3px reali) e dita selezionabili.
  - Scelta manuale multi-canale: clic su tastiera B/N, clic su pallini/dita mani SVG, ascolto tastiera fisica o griglia ASCII.
  - Interrogazione **Per Carattere / Per Tasto** strutturata in 3 blocchi sulla stessa pagina: 1) Descrizione Accordo (Mano, Dito, Estensione laterale 0..3 e direzione, Estensione longitudinale -1..+2, Modificatori `CTRL`, `SHIFT`, `ALT`, `AltGr` con equivalenza `AltGr` <-> `CTRL+ALT`), 2) Caratteri sul Tasto con mini-keycap SVG e popover ASCII/`NONE`, 3) Tasti intorno ("margherita") con popover ASCII/`NONE` e rosa completa sulla tastiera.
  - Interrogazione **Per Dito** con filtro progressivo di estensione laterale/direzione e opzione configurabile (`soli_tasti_fisici` | `tutti_i_singoli_caratteri`).
  - Interrogazione **Tasti Posizione di Riposo** (Sinistra / Destra) con selezione grafica dei 4 tasti, carattere e dito.
  - Salvataggio automatico del punteggio finale nelle statistiche del profilo (`profile.interrogationStats`).
- Aggiunti i moduli `js/interrogation/interrogation-layout-metadata.js` e `js/ui/interrogation-svg-renderer.js`, e aggiornati `docs/ARCHITETTURA_v6.27.md`, `docs/MANUALE_UTENTE_v6.27.md`, `help.html`, `README.md` e `BUILD_MANIFEST.json`.

## v6.26
- Migliorata la leggibilità di tutti gli esercizi di **Interrogazione**:
  - Sostituiti gli identificativi tecnici `finger.nn` con il nome italiano del dito e l'indicazione della mano ` - (sn)` o ` - (dx)` (es. `[HOME_ROW] mignolo - (sn)`).
  - Nelle voci `[DITO]` aggiunto anche il nome del tasto tra parentesi graffe (es. `[DITO] mignolo - (dx) - {meno}` nel selettore manuale), mantenendo il titolo della domanda in esecuzione privo di spoiler (`Tasto {meno}`).
  - Nelle voci `[TASTO]` mostrato il nome leggibile del tasto tra parentesi graffe (es. `[TASTO] {meno}`).
  - Nelle voci `[CARATTERE]` mostrati i nomi in chiaro dei caratteri e simboli dalla tabella di riferimento (es. `[CARATTERE] Euro`, `[CARATTERE] BACK`, `[CARATTERE] Spazio`).
- Centralizzata la formattazione leggibile in `InterrogationCatalog` (`js/interrogation/interrogation-catalog.js`).
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.26.md`, `docs/MANUALE_UTENTE_v6.26.md`, `README.md` e `BUILD_MANIFEST.json`.

## v6.25
- Ripristinata la selezione delle migliori voci di sintesi vocale (TTS) con consenso esplicito per profilo (`AllowRemoteTtsVoices`, predefinito `true`).
- Integrata la nuova funzionalità **Interrogazione sul layout della tastiera italiana** (Casuale, Adattiva 1/3/7/14/30/60 giorni, Manuale).
