/* TenFingersTypingTrainer v6.12 | phoneme-engine.js | Risoluzione stallo loop Markoviano a confine di parola (v6.12). */
class PhonemeEngine {
  constructor(corpus) {
    this.defaultCorpus = corpus || "";
    this.ngramLength = 4;
    this.targetLength = 100;
  }

  // Generatore di numeri formattati con stili realistici
  _generateFormattedNumber() {
    const types = [
      () => `0,${Math.floor(100 + Math.random() * 900)}`, // es. 0,123
      () =>
        `${Math.floor(10 + Math.random() * 90)}'${Math.floor(100 + Math.random() * 900)}`, // es. 12'345
      () =>
        `${Math.floor(10 + Math.random() * 90)}'${Math.floor(100 + Math.random() * 900)}'${Math.floor(100 + Math.random() * 900)}`, // es. 12'345'678
      () =>
        `${Math.floor(10 + Math.random() * 90)}'${Math.floor(100 + Math.random() * 900)},${Math.floor(10 + Math.random() * 90)}`, // es. 12'345,67
      () =>
        `${Math.floor(10 + Math.random() * 90)}'${Math.floor(100 + Math.random() * 900)}'${Math.floor(100 + Math.random() * 900)},${Math.floor(10 + Math.random() * 90)}`, // es. 12'345'678,91
    ];
    const fn = types[Math.floor(Math.random() * types.length)];
    return fn();
  }

  // Generatore di espressioni matematiche sintatticamente valide
  _generateMathExpression() {
    const ops = ["+", "-", "*", "/", "=", "<", ">", "^"];
    const count = 2 + Math.floor(Math.random() * 2); // 2 o 3 numeri
    let expr = `${Math.floor(1 + Math.random() * 99)}`;
    for (let i = 1; i < count; i++) {
      const op = ops[Math.floor(Math.random() * ops.length)];
      const num = Math.floor(1 + Math.random() * 99);
      expr += ` ${op} ${num}`;
    }
    return expr;
  }

  // Generatore di simboli isolati
  _generateRandomSymbol() {
    const symbols = [
      "\\",
      "|",
      "€",
      "£",
      "$",
      "%",
      "&",
      "@",
      "#",
      "§",
      "ç",
      "°",
    ];
    return symbols[Math.floor(Math.random() * symbols.length)];
  }

  // Estrazione di una parola base markoviana con lunghezza N-grammi dinamica (v.4.4)
  _generateMarkovWord(activeCorpus, starts, nLen = 4) {
    const effectiveN = Math.max(2, Math.min(8, nLen));
    let word = "";
    let currentPrefix =
      starts.length > 0
        ? starts[Math.floor(Math.random() * starts.length)]
        : "s";
    word += currentPrefix;

    let safety = 0;
    while (word.length < 10 && safety < 100) {
      safety++;
      const searchPattern = currentPrefix.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
      );
      const regex = new RegExp(searchPattern + "([a-zA-Zàèéìòùç ])", "g");
      const nextChars = [];
      let m;
      let count = 0;
      while ((m = regex.exec(activeCorpus)) !== null && count < 60) {
        nextChars.push(m[1]);
        count++;
      }

      if (nextChars.length > 0) {
        const nextChar =
          nextChars[Math.floor(Math.random() * nextChars.length)];
        if (nextChar === " ") {
          if (word.length >= 2) break;
          currentPrefix =
            starts[Math.floor(Math.random() * starts.length)] || "a";
          word += currentPrefix;
        } else {
          word += nextChar;
          currentPrefix = currentPrefix + nextChar;
          // Finestra scorrevole basata sul parametro N configurato dall'utente
          if (currentPrefix.length >= effectiveN) {
            currentPrefix = currentPrefix.slice(1);
          }
        }
      } else {
        break;
      }
    }
    return word.trim() || "sala";
  }

  // Metodo di generazione a flusso continuo markoviano con innesto filtri (Range N: 2 - 15, Range Lunghezza: 20 - 500)
  generate(options = {}, probs = {}, customCorpus = "", nGramLength = 4, targetLength = 100) {
    const useCustom =
      options.customFile && customCorpus && customCorpus.trim().length >= 20;
    const activeCorpus = useCustom
      ? customCorpus.replace(/\r/g, "")
      : this.defaultCorpus.replace(/\r/g, "").replace(/\n/g, " ");

    if (!activeCorpus || activeCorpus.length < 20) {
      return "fa la sala fa la salsa salda la falla";
    }

    // Esteso il limite massimo di N a 15
    const nLen = Math.max(2, Math.min(15, parseInt(nGramLength, 10) || 4));
    const contextLen = Math.max(1, nLen - 1);

    // Configurazione e validazione lunghezza target (Range 20 - 500 caratteri, Default 100) (v6.11)
    const tLen = Math.max(20, Math.min(500, parseInt(targetLength !== undefined ? targetLength : this.targetLength, 10) || 100));
    this.targetLength = tLen;

    const pMaiusc = probs.maiuscole !== undefined ? probs.maiuscole : 0.3;
    const pAllMaiusc =
      probs.allMaiuscole !== undefined ? probs.allMaiuscole : 0.3;
    const pPunt = probs.punteggiatura !== undefined ? probs.punteggiatura : 0.3;
    const pPar = probs.parentesi !== undefined ? probs.parentesi : 0.3;
    const pNum = probs.numeri !== undefined ? probs.numeri : 0.3;
    const pMat = probs.matematici !== undefined ? probs.matematici : 0.3;
    const pSim = probs.simboli !== undefined ? probs.simboli : 0.3;
    const pLay = probs.layout !== undefined ? probs.layout : 0.3;

    const punctSet = [",", ".", ";", ":", "-", "_", "?", "!", '"', "'"];
    const bracketPairs = [
      { open: "(", close: ")" },
      { open: "[", close: "]" },
      { open: "{", close: "}" },
    ];

    // =======================================================
    // CLASSE: PhonemeEngine (main_A_(v.4.9).js)
    // METODO: generate() - Cattura parole integra senza boundary ASCII \b
    // =======================================================
    // 1. Individuazione degli inizi di parola nel corpus compatibile con lettere accentate (Release v.4.9)
    const wordStartIndices = [];
    const wordStartRegex =
      /(?:^|\s|[.,;:!?"'()\[\]{}])([a-zA-ZàèéìòùçÀÈÉÌÒÙÇ])/g;
    let match;
    while ((match = wordStartRegex.exec(activeCorpus)) !== null) {
      // Indice esatto della prima lettera della parola
      const letterIndex = match.index + (match[0].length - 1);
      wordStartIndices.push(letterIndex);
      if (wordStartIndices.length > 800) break;
    }

    const getRandomWordSeed = () => {
      if (wordStartIndices.length === 0) return "sala";
      const startIdx =
        wordStartIndices[Math.floor(Math.random() * wordStartIndices.length)];
      const candidate = activeCorpus.slice(startIdx, startIdx + contextLen);
      return candidate.length > 0 ? candidate : "sala";
    };

    let currentPrefix = getRandomWordSeed();
    let result = currentPrefix;
    let safetyCounter = 0;
    let insideBracket = null;
    let bracketWordsRemaining = 0;

    // 2. Ciclo di generazione continuo attraverso parole e spazi
    while (safetyCounter < 2000) {
      safetyCounter++;

      // Condizione di arresto naturale: raggiunta la lunghezza target e completata la parola in corso
      if (result.length >= this.targetLength) {
        if (
          result.endsWith(" ") ||
          result.endsWith("\n") ||
          result.endsWith("®") ||
          result.endsWith("→") ||
          result.length >= this.targetLength + 40 ||
          safetyCounter > 1500
        ) {
          break;
        }
      }

      // Ricerca nel corpus delle continuazioni del prefisso di contesto
      const searchPattern = currentPrefix.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
      );
      const regex = new RegExp(
        searchPattern + "([a-zA-ZàèéìòùçÀÈÉÌÒÙÇ0-9 .,;:!?'\"\\-\\n])",
        "g",
      );
      const nextChars = [];
      let m;
      let count = 0;
      while ((m = regex.exec(activeCorpus)) !== null && count < 80) {
        const ch = m[1];
        if (ch !== "\r" && ch !== "\t") {
          nextChars.push(ch);
          count++;
        }
      }

      if (nextChars.length > 0) {
        let nextChar = nextChars[Math.floor(Math.random() * nextChars.length)];

        if (!useCustom && nextChar === "\n") nextChar = " ";

        // GESTIONE CONFINE DI PAROLA
        if (nextChar === " ") {
          if (
            result.endsWith(" ") ||
            result.endsWith("\n") ||
            result.endsWith("®") ||
            result.endsWith("→")
          ) {
            // Se il testo termina già con separatore, evita spazi consecutivi e sblocca il generatore con un nuovo seed
            currentPrefix = getRandomWordSeed();
            continue;
          }

          // A. Filtro Punteggiatura opzionale aggiuntiva
          if (options.punteggiatura && Math.random() < pPunt) {
            const p = punctSet[Math.floor(Math.random() * punctSet.length)];
            result += p;
          }

          // B. Chiusura eventuale gruppo parentesi
          if (insideBracket) {
            bracketWordsRemaining--;
            if (bracketWordsRemaining <= 0) {
              result += insideBracket.close;
              insideBracket = null;
            }
          }

          // C. Filtro Layout: INVIO ('®') o TAB ('→')
          let layoutEmitted = false;
          if (options.layout && Math.random() < pLay) {
            if (Math.random() < 0.5) {
              result += "®";
              layoutEmitted = true;
            } else {
              result += "→";
              layoutEmitted = true;
            }
          }

          if (!layoutEmitted) {
            result += " ";
          }

          // D. Iniezione Numeri formattati tra parole
          if (options.numeri && Math.random() < pNum) {
            result += this._generateFormattedNumber() + " ";
          }

          // E. Iniezione Espressioni Matematiche tra parole
          if (options.matematici && Math.random() < pMat) {
            result += this._generateMathExpression() + " ";
          }

          // F. Iniezione Simboli Speciali tra parole
          if (options.simboli && Math.random() < pSim) {
            result += this._generateRandomSymbol() + " ";
          }

          // G. Apertura nuovo gruppo Parentesi
          if (!insideBracket && options.parentesi && Math.random() < pPar) {
            insideBracket =
              bracketPairs[Math.floor(Math.random() * bracketPairs.length)];
            bracketWordsRemaining = 1 + Math.floor(Math.random() * 3);
            result += insideBracket.open;
          }

          currentPrefix = " ";
        } else {
          result += nextChar;
          currentPrefix = (currentPrefix + nextChar).slice(-contextLen);
        }
      } else {
        const newSeed = getRandomWordSeed();
        if (
          !result.endsWith(" ") &&
          !result.endsWith("\n") &&
          !result.endsWith("®") &&
          !result.endsWith("→")
        ) {
          result += " ";
        }
        result += newSeed;
        currentPrefix = newSeed;
      }
    }

    if (insideBracket) {
      result += insideBracket.close;
    }

    // H. Trasformazione Maiuscole con cattura integrale della parola (senza boundary ASCII \b - Release v.5.0 patch)
    if (options.maiuscole) {
      result = result.replace(/[a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]+/g, (w) => {
        if (Math.random() < pAllMaiusc) {
          // Normalizza ç/Ç in c/C prima di forzare l'uppercase
          return w.replace(/ç/gi, "c").toUpperCase();
        } else if (Math.random() < pMaiusc) {
          // Gestione Title Case: forza C se la parola inizia con ç/Ç
          let first =
            w.charAt(0).toLowerCase() === "ç" ? "C" : w.charAt(0).toUpperCase();
          return first + w.slice(1);
        }
        return w;
      });
    }

    // Normalizzazione deterministica e conversione globale vocali maiuscole accentate (Release v.4.9)
    const normalized = normalizeItalianAccents(result);
    return normalized
      .replace(/[ ]{2,}/g, " ")
      .replace(/ ®/g, "®")
      .replace(/® /g, "®")
      .replace(/ →/g, "→")
      .replace(/→ /g, "→")
      .trim();
  }
}

// WINDOW MANAGER (Draggable & Resizable con Viewport Boundary Guard)
