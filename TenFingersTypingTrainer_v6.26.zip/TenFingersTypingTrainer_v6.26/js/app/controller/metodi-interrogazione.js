/* TenFingersTypingTrainer v6.25 | metodi-interrogazione.js | Estensione AppController per apertura e collegamento della vista Interrogazione. */
Object.assign(AppController.prototype, {
  setupInterrogationControls() {
    if (!this.interrogationUI && typeof InterrogationSessionManager === "function") {
      const catalog = new InterrogationCatalog();
      const repository = new InterrogationRepository();
      const sessionManager = new InterrogationSessionManager({
        catalog,
        repository,
      });
      this.interrogationUI = new InterrogationUI({
        sessionManager,
        catalog,
        getProfileId: () => this.profileMgr?.currentUser || "default",
        onClose: () => this.returnFocusToTyping(),
      });
    }

    const btnOpen = document.getElementById("btnOpenInterrogation");
    if (btnOpen) {
      btnOpen.addEventListener("click", () => {
        this.openInterrogationModal();
      });
    }
  },

  async openInterrogationModal() {
    if (!this.interrogationUI) {
      this.setupInterrogationControls();
    }
    const modal = document.getElementById("interrogationModal");
    if (modal && this.windowMgr) {
      this.windowMgr.bringModalToFront(modal);
    }
    if (this.interrogationUI) {
      await this.interrogationUI.open();
    }
  },
});
