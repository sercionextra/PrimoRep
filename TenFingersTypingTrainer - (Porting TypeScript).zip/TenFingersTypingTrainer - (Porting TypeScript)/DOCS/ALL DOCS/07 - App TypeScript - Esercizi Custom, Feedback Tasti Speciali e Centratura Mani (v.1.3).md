# Documento di Avanzamento Tecnico e Specifica Funzionale (Versione 1.3)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Versione rilasciata**: **1.3**  
**Data**: 30/03/2026  
**File sorgente correlati**:
- `index_(v.1.3).html`
- `help_(v.1.3).html`

---

## 1. Sommario Esecutivo

Il rilascio della **Versione 1.3** completa i requisiti chiave relativi alla gestione degli **Esercizi Personalizzati Multilinea**, al riscontro visivo ed ergonomico della tastiera fisica e alla correzione anatomica del visualizzatore SVG delle mani:

1. **Integrazione Diretta degli Esercizi Custom nel Menu Lezioni**:
   - Il salvataggio o il caricamento di un file `.txt` nell'**Editor Esercizi Personalizzati** analizza immediatamente la sintassi degli esercizi (delimitatori `===== Titolo =====`) ed estrae i titoli delle lezioni.
   - Il menu a tendina `cboLessons` viene popolato direttamente con i titoli estratti (es. *Custom 1: Titolo*, *Custom 2: Titolo*).
   - Un pulsante di commutazione rapida nella toolbar (`btnToggleLessonSource`: **📚 Standard / Custom**) permette di passare liberamente dal catalogo delle 70 lezioni propedeutiche standard al set di esercizi personalizzati dell'utente.
2. **Supporto Multilinea con Digitazione dei Tasti Invio (`®`) e Tab (`→`)**:
   - I testi multilinea gestiscono i caratteri di a-capo e rientro:
     - **Invio (Return / A capo)**: rappresentato internamente dal codice `®`, visualizzato come `↵` (badge "INVIO ↵"), associato al **mignolo destro (dito 10)** e al tasto virtuale `key_enter`.
     - **Tabulazione (Tab / Rientro)**: rappresentata internamente dal codice `→`, visualizzata come `⇥` (badge "TAB ⇥"), associata al **mignolo sinistro (dito 1)** e al tasto virtuale `key_tab`.
   - Il motore di digitazione, il calcolo della velocità, l'interfaccia a riga continua e il sistema di suggerimento delle dita guidano l'utente in modo trasparente e coerente con l'architettura originaria C#.
3. **Illuminazione Azzurra per Tasti Funzione e Speciali alla Pressione Fisica**:
   - Alla pressione fisica da tastiera si illuminano istantaneamente con classe `.key-pressed` (sfondo azzurro tenue con alone di contrasto) tutti i seguenti tasti:
     - `Tab` (`key_tab`)
     - `Shift-Lock` / `Caps Lock` (`key_caps`)
     - `Shift Sinistro` e `Shift Destro` (`key_shift_l`, `key_shift_r`)
     - `Ctrl Sinistro` e `Ctrl Destro` (`key_ctrl_l`, `key_ctrl_r`)
     - `Alt Sinistro` (`key_alt_l`)
     - `AltGr` (`key_altgr`)
     - `Tasti Windows / Meta` (`key_win_l`, `key_win_r`)
     - `Backspace` (`key_backspace`)
     - `Return / Invio` (`key_enter`)
     - `Menu Contestuale` (`key_menu`)
4. **Trattamento come Errore della Pressione Fuori Luogo di Tasti Speciali**:
   - Se l'utente preme un tasto speciale non atteso dal contesto (es. pressione di Tab, Invio, CapsLock, Ctrl, Alt o Menu quando l'esercizio richiede una lettera o un simbolo diverso), l'azione viene intercettata e gestita rigorosamente come errore:
     - Riproduzione del segnale acustico d'errore (audio sintesi web).
     - Incremento del contatore errori (`countErrors`) e ricalcolo in tempo reale dell'accuratezza (%).
     - Proiezione immediata del badge rosso fluttuante direttamente sopra il carattere bersaglio, riportante il nome chiaro del tasto premuto (es. *CAPS LOCK*, *TAB*, *INVIO*, *CTRL*, *ALT*, *BACKSPACE*).
5. **Centratura Anatomica Grafica del Palmo delle Due Mani**:
   - Corretto l'allineamento dei tracciati vettoriali SVG del palmo per entrambe le mani:
     - Palmo mano sinistra traslato orizzontalmente verso sinistra (in direzione del mignolo 1): `transform="translate(-12, 0)"`.
     - Palmo mano destra traslato orizzontalmente verso destra (in direzione del mignolo 10): `transform="translate(12, 0)"`.
     - Riallineate leggermente le label descrittive per garantire perfetto equilibrio visivo ed eleganza anatomica.

---

## 2. Dettaglio Tecnico delle Modifiche Applicate

### 2.1 Parser Esercizi Custom e Commutazione Sorgente (`setLessonsSource`)
La funzione `parseCustomExercises(rawText)` separa il contenuto testuale analizzando le intestazioni con espressione regolare `/^={3,}\s*(.*?)\s*={3,}$/m`. Ogni sezione individuata genera un oggetto `LessonDef` con relative frasi opportunamente formattate (i ritorni a capo `\n` e `\r\n` vengono convertiti in `®` e i caratteri `\t` in `→`).

Nel controller `AppController`:
- Membri `standardLessons` (le 70 lezioni ufficiali) e `customLessons` (gli esercizi caricati o definiti dall'utente).
- Metodo `setLessonsSource(source: 'standard' | 'custom')`: aggiorna la sorgente attiva, ripopola `cboLessons` con i relativi prefissi (*Lezione N* oppure *Custom N*), aggiorna l'etichetta del pulsante `lblLessonSource` e avvia la prima frase del primo esercizio selezionato.
- All'interno del gestore di salvataggio (`btnCustomSave`) e di caricamento file (`btnCustomUpload` / `fileInput`), il testo viene salvato nel profilo dell'utente su `localStorage` e la visualizzazione passa istantaneamente alla modalità Custom.

### 2.2 Gestione Multilinea, Invio e Tab nel Motore di Digitazione
- `VisualRenderer.getFingerAndKey(char)`:
  - Carattere `®` (Invio): restituisce `finger: 10`, `keyId: "key_enter"`, `shift: false`.
  - Carattere `→` (Tab): restituisce `finger: 1`, `keyId: "key_tab"`, `shift: false`.
- `AppController.updateOriginDisplay()`:
  - Il carattere bersaglio `®` viene renderizzato come freccia di invio `↵` con etichetta *"INVIO ↵"*.
  - Il carattere bersaglio `→` viene renderizzato come simbolo di tabulazione `⇥` con etichetta *"TAB ⇥"*.
  - Entrambi i simboli mantengono il posizionamento verticale esatto per il badge d'errore.
- In `setupTypingListeners()`, l'intercettazione degli eventi `keydown` previene l'azione di default del browser (`e.preventDefault()`) per i tasti `Tab` ed `Enter`, consentendo una digitazione fluida e priva di perdite di focus o scroll indesiderati della pagina.

### 2.3 Riconoscimento ed Evidenziazione Tasti Fisici (`flashPressedKey`)
Nel componente `VisualRenderer`, il metodo `flashPressedKey(keyName, code, location)` associa l'evento della tastiera fisica al corrispondente ID SVG:
```typescript
switch (keyName) {
  case 'Tab': keyId = 'key_tab'; break;
  case 'CapsLock': keyId = 'key_caps'; break;
  case 'Backspace': keyId = 'key_backspace'; break;
  case 'Enter': keyId = 'key_enter'; break;
  case 'ContextMenu': keyId = 'key_menu'; break;
  case 'Shift': keyId = (location === 2 || code === 'ShiftRight') ? 'key_shift_r' : 'key_shift_l'; break;
  case 'Control': keyId = (location === 2 || code === 'ControlRight') ? 'key_ctrl_r' : 'key_ctrl_l'; break;
  case 'Alt': keyId = 'key_alt_l'; break;
  case 'AltGraph': keyId = 'key_altgr'; break;
  case 'Meta': keyId = (location === 2 || code === 'MetaRight') ? 'key_win_r' : 'key_win_l'; break;
}
```
L'elemento riceve la classe CSS `.key-pressed` e viene rimosso automaticamente dopo 180 ms con transizione morbida.

### 2.4 Controllo Errori per Tasti Non Pertinenti
Qualsiasi pressione di un tasto speciale quando l'esercizio non lo richiede viene bloccata e trattata come errore tramite la chiamata a `this.handleTypingError(displayLabel)`. I tasti modificatori solitari (`Shift` e `AltGr`), usati come prefisso per combinazioni di caratteri maiuscoli o simboli terziari, si illuminano di azzurro ma non incrementano gli errori a vuoto per consentire la corretta composizione del carattere successivo.

### 2.5 Correzione Grafica Palmi nel Visualizzatore Mani SVG
Nel file `index_(v.1.3).html`, all'interno dei due gruppi SVG `#leftHand` e `#rightHand`, gli elementi `<path class="palm" ... />` sono stati dotati dei rispettivi attributi di traslazione:
- Mano Sinistra: `<path class="palm" transform="translate(-12, 0)" ... />`
- Mano Destra: `<path class="palm" transform="translate(12, 0)" ... />`
Questo riallineamento compensa il disassamento della grafica originale C# e allinea perfettamente il baricentro del palmo rispetto alla base di mignolo, anulare, medio e indice.

---

## 3. Report del Collaudo Automatizzato E2E (Google Chrome CDP)

| Test Eseguito | Esito | Dettaglio Riscontro |
|---|:---:|---|
| **Centratura Palmo Mani SVG** | **PASS** | `leftPalmTransform: translate(-12, 0)`, `rightPalmTransform: translate(12, 0)`. Perfetto allineamento sotto le 4 dita. |
| **Illuminazione Tasti Speciali** | **PASS** | Verificata classe `.key-pressed` su tutti i tasti: Tab, Caps, Shift (Sx/Dx), Ctrl (Sx/Dx), Alt, AltGr, Win (Sx/Dx), Backspace, Invio, Menu. |
| **Rilevamento Errore Fuori Luogo** | **PASS** | Pressione indebita di `CapsLock` incrementa `newErrors: 1`, proietta `wrongCharFloatingBadge` visibile con testo *"CAPS LOCK"*. |
| **Toggle Modalità Custom & Standard** | **PASS** | Commutazione verificata: `activeLessonsSource = custom`, popolamento di 6 lezioni con titoli estratti e selezione istantanea. |
| **Salvataggio/Caricamento da Editor** | **PASS** | Parsing blocchi `===== Esercizio Alfa =====`, aggiornamento immediato di `cboLessons` e del testo bersaglio. |
| **Digitazione Multilinea (Invio e Tab)** | **PASS** | Bersaglio `Tab` (`⇥`) associato a mignolo 1 e digitato con successo; bersaglio `Invio` (`↵`) associato a mignolo 10 e digitato con successo. |

---

## 4. Riepilogo Deliverable in `/workspace`

- `/workspace/index_(v.1.3).html`: SPA monolitica v.1.3 con supporto esercizi custom, tasti speciali e correzione grafica mani.
- `/workspace/help_(v.1.3).html`: Manuale utente aggiornato con la Sezione 9 (Note di Rilascio v.1.3).
- `/workspace/07 - App TypeScript - Esercizi Custom, Feedback Tasti Speciali e Centratura Mani (v.1.3).md`: Documento di avanzamento tecnico e collaudo.
