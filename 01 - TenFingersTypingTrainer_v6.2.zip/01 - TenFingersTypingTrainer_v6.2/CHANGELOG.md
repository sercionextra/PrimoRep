# Changelog

## v6.2 — 29/10/2026

- Risolta l'anomalia nella cancellazione dei campioni non selezionati nelle statistiche in presenza di filtri attivi: il pulsante "Elimina non selezionati" cancella solo i campioni visibili nel grafico che rispettano i filtri applicati ma non appartengono alla selezione corrente.
- Preservati intatti sia i campioni selezionati sia l'intero archivio storico dei campioni esterni ai filtri attivi.
- Disabilitazione contestuale coerente del pulsante "Elimina non selezionati" all'avvio e quando non ci sono campioni da eliminare nella vista corrente.
- Aggiornati dialoghi di conferma modale, messaggi di notifica, documentazione, manuale utente, guida in linea e suite di verifica alla v6.2.

## v6.1 — 29/10/2026

- Risolto il blocco della dettatura vocale dopo la correzione degli errori: rimossa la formula prolissa di completamento ed eliminata l'interruzione brusca dell'audio alla digitazione.
- La dettatura riprende direttamente dal primo carattere non ancora digitato appena gli errori tornano a zero con Backspace.
- Ottimizzato il tracciamento del token attivo e del lookahead predittivo durante la digitazione rapida, prevenendo desincronizzazioni e blocchi della voce.
- Allineati codice sorgente, documentazione, manuale utente, help in-app e suite di verifica alla v6.1.

## v6.0 — 27/10/2026

- Avviato il refactoring strutturale dei sorgenti in file separati per responsabilità.
- Estratto il CSS dell'interfaccia in un asset dedicato.
- Conservati dataset didattico, motori, interfaccia e persistenza della v5.1 come baseline di equivalenza.
- Allineati titolo, percorsi degli asset e guida HTML alla v6.0.
- Aggiunti documentazione architetturale e checklist di regressione.
- Nessuna migrazione distruttiva dei dati browser introdotta.

Nota: questa release privilegia la compatibilità; la conversione completa a moduli ES/TypeScript richiede una fase ulteriore di estrazione delle dipendenze e test runtime.
