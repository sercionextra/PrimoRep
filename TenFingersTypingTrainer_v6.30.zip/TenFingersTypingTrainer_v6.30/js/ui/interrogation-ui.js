/* TenFingersTypingTrainer v6.27 | interrogation-ui.js | Interfaccia grafica interattiva Interrogazione (Tastiera B/N, Mani SVG, Popover ASCII, 3 blocchi Carattere, Dito, Riposo). */
(function (global) {
  "use strict";

  const FINGER_NAMES_BASE = [
    { id: "mignolo", label: "Mignolo" },
    { id: "anulare", label: "Anulare" },
    { id: "medio", label: "Medio" },
    { id: "indice", label: "Indice" },
    { id: "pollice", label: "Pollice" },
  ];

  const FINGER_NUM_TO_BASE = {
    "1": { hand: "left", base: "mignolo" },
    "2": { hand: "left", base: "anulare" },
    "3": { hand: "left", base: "medio" },
    "4": { hand: "left", base: "indice" },
    "5": { hand: "left", base: "pollice" },
    "6": { hand: "right", base: "pollice" },
    "7": { hand: "right", base: "indice" },
    "8": { hand: "right", base: "medio" },
    "9": { hand: "right", base: "anulare" },
    "10": { hand: "right", base: "mignolo" },
  };

  function resolveFingerNumber(hand, baseName) {
    const map = {
      left: { mignolo: "1", anulare: "2", medio: "3", indice: "4", pollice: "5" },
      right: { pollice: "6", indice: "7", medio: "8", anulare: "9", mignolo: "10" },
    };
    return (map[hand] && map[hand][baseName]) || "";
  }

  function createEl(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = String(text);
    return el;
  }

  class InterrogationUI {
    constructor(deps) {
      this.sessionMgr = deps.sessionManager;
      this.catalog = deps.catalog;
      this.getProfileId = deps.getProfileId || (() => "default");
      this.onClose = deps.onClose || (() => {});
      this.onSessionComplete = deps.onSessionComplete || (() => {});

      this.activeSession = null;
      this.activeItems = [];
      this.currentItemIdx = 0;
      this.bound = false;

      this.fingerMode = "soli_tasti_fisici";
      this.manualSelectedIds = [];
      this.manualListeningKeyboard = false;
      this._boundManualKeyHandler = null;
      this._popoverCallback = null;

      this.manualSvg = null;
      this.runSvg = null;
    }

    init() {
      if (this.bound) return;
      this.bound = true;

      document.getElementById("btnCloseInterrogationModal")?.addEventListener("click", () => this.close());
      document.getElementById("btnInterrogationCloseFooter")?.addEventListener("click", () => this.close());

      const selMode = document.getElementById("interrogationModeSelect");
      selMode?.addEventListener("change", () => {
        const manualBox = document.getElementById("interrogationManualBox");
        if (manualBox) {
          manualBox.classList.toggle("is-hidden", selMode.value !== "manual");
        }
        if (selMode.value === "manual") {
          this._mountManualSvg();
          this._setManualKeyboardListen(true);
        } else {
          this._setManualKeyboardListen(false);
        }
      });

      document.getElementById("interrogationFingerModeSelect")?.addEventListener("change", (e) => {
        this.fingerMode = e.target.value || "soli_tasti_fisici";
      });

      document.getElementById("btnInterrManualAsciiPicker")?.addEventListener("click", (e) => {
        this._openAsciiPopover(e.currentTarget, { includeSpecial: false, includeNone: false }, (val) => {
          this._addManualCandidateByChar(val);
        });
      });

      document.getElementById("btnInterrManualKeyboardListen")?.addEventListener("click", () => {
        this._setManualKeyboardListen(!this.manualListeningKeyboard);
      });

      document.getElementById("btnInterrManualClear")?.addEventListener("click", () => {
        this.manualSelectedIds = [];
        this._renderManualChips();
        if (this.manualSvg) {
          this.manualSvg.resetKeyboard();
          this.manualSvg.resetHands();
        }
      });

      document.getElementById("btnCloseAsciiPopover")?.addEventListener("click", () => {
        this._closeAsciiPopover();
      });

      document.getElementById("btnStartInterrogation")?.addEventListener("click", () => this.handleStartSession());
      document.getElementById("btnOpenInterrogationHistory")?.addEventListener("click", () => this.showHistoryView());
      document.getElementById("btnInterrHistBack")?.addEventListener("click", () => this.showSetupView());
      document.getElementById("btnInterrHistResetFilter")?.addEventListener("click", () => {
        const dFrom = document.getElementById("interrHistDateFrom");
        const dTo = document.getElementById("interrHistDateTo");
        if (dFrom) dFrom.value = "";
        if (dTo) dTo.value = "";
        this._renderHistoryChart();
      });
      document.getElementById("interrHistDateFrom")?.addEventListener("change", () => this._renderHistoryChart());
      document.getElementById("interrHistDateTo")?.addEventListener("change", () => this._renderHistoryChart());
      document.getElementById("btnInterrHistDeleteSelected")?.addEventListener("click", () => this._deleteHistorySamples("selected"));
      document.getElementById("btnInterrHistDeleteExcluded")?.addEventListener("click", () => this._deleteHistorySamples("excluded"));
      document.getElementById("btnResumeSuspendedInterrogation")?.addEventListener("click", () => this.handleResumeSuspended());
      document.getElementById("btnAbandonSuspendedInterrogation")?.addEventListener("click", () => this.handleAbandonSuspended());
      document.getElementById("btnInterrogationFinishItem")?.addEventListener("click", () => this.handleFinishMainQuestion());
      document.getElementById("btnInterrogationSuspend")?.addEventListener("click", () => this.handleSuspend());
      document.getElementById("btnInterrogationAbandon")?.addEventListener("click", () => this.handleAbandonActive());
      document.getElementById("btnInterrogationComplete")?.addEventListener("click", () => this.handleComplete());
      document.getElementById("btnInterrogationNewSession")?.addEventListener("click", () => this.showSetupView());
    }

    async open() {
      this.init();
      const modal = document.getElementById("interrogationModal");
      if (!modal) return;
      modal.classList.add("active");
      await this.showSetupView();
    }

    close() {
      this._setManualKeyboardListen(false);
      this._closeAsciiPopover();
      const modal = document.getElementById("interrogationModal");
      if (modal) modal.classList.remove("active");
      this.onClose();
    }

    _switchView(viewName) {
      this._closeAsciiPopover();
      this._setManualKeyboardListen(false);
      ["setup", "run", "summary", "history"].forEach((v) => {
        const el = document.getElementById(`interrogationView_${v}`);
        if (el) el.classList.toggle("is-hidden", v !== viewName);
      });
      const hdrMeta = document.getElementById("interrHeaderMeta");
      if (hdrMeta) {
        hdrMeta.classList.toggle("is-hidden", viewName !== "run");
      }
    }

    async showSetupView() {
      this._switchView("setup");
      const profileId = this.getProfileId();

      const progress = await this.sessionMgr.getProfileProgress(profileId);
      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt("interrStatTotal", progress.totalDefinitions);
      setTxt("interrStatNever", progress.neverVerified);
      setTxt("interrStatWeak", progress.weak);
      setTxt("interrStatReview", progress.review);
      setTxt("interrStatConsolidated", progress.consolidated);
      setTxt("interrStatDue", progress.dueNow);

      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      const suspBanner = document.getElementById("interrogationSuspendedBanner");
      if (suspBanner) {
        suspBanner.classList.toggle("is-hidden", !suspended);
        if (suspended) {
          setTxt(
            "interrogationSuspendedInfo",
            `Sessione sospesa (${suspended.mode}, domanda ${(suspended.currentItemIndex || 0) + 1} di ${suspended.effectiveCount}, punteggio ${suspended.score})`,
          );
        }
      }

      const selMode = document.getElementById("interrogationModeSelect");
      if (selMode && selMode.value === "manual") {
        this._mountManualSvg();
        this._setManualKeyboardListen(true);
      } else {
        this._setManualKeyboardListen(false);
      }
      this._renderManualChips();
    }

    _mountManualSvg() {
      const kbHost = document.getElementById("interrManualKeyboardHost");
      const hHost = document.getElementById("interrManualHandsHost");
      if (!kbHost || !hHost || typeof global.InterrogationSvgRenderer !== "function") return;

      if (!this.manualSvg) {
        this.manualSvg = new global.InterrogationSvgRenderer({
          onKeyClick: (keyId) => this._addManualCandidateByKeyId(keyId),
          onFingerClick: (fingerId) => this._addManualCandidateByFingerId(fingerId),
          onLandmarkClick: (info) => {
            const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
            if (typeVal === "DITO") {
              this._addManualCandidateByFingerId(info.fingerId);
            } else if (info.keyId) {
              this._addManualCandidateByKeyId(info.keyId);
            } else if (info.keyLabel) {
              this._addManualCandidateByChar(String(info.keyLabel).toLowerCase());
            } else if (info.fingerId) {
              this._addManualCandidateByFingerId(info.fingerId);
            }
          },
        });
      }
      this.manualSvg.mount(kbHost, hHost);
    }

    _setManualKeyboardListen(enabled) {
      this.manualListeningKeyboard = !!enabled;
      const btn = document.getElementById("btnInterrManualKeyboardListen");
      if (btn) {
        btn.textContent = enabled
          ? "Ascolta tastiera fisica: ON (premi un tasto)"
          : "Ascolta tastiera fisica: OFF";
        btn.classList.toggle("btn-primary", enabled);
      }

      if (this._boundManualKeyHandler) {
        window.removeEventListener("keydown", this._boundManualKeyHandler, true);
        this._boundManualKeyHandler = null;
      }

      if (enabled) {
        this._boundManualKeyHandler = (e) => {
          if (e.key === "Escape") {
            this._setManualKeyboardListen(false);
            return;
          }
          if (["Shift", "Control", "Alt", "AltGraph", "Meta", "CapsLock"].includes(e.key)) {
            return;
          }
          e.preventDefault();
          e.stopPropagation();
          this._addManualCandidateByChar(e.key);
        };
        window.addEventListener("keydown", this._boundManualKeyHandler, true);
      }
    }

    _addManualCandidateByKeyId(keyId) {
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const all = this.catalog.getCandidates({});
      let match = null;

      if (typeVal === "HOME_ROW") {
        const pk = this.catalog.getPhysicalKey(keyId);
        const hand = pk && Number(pk.assignedFinger) <= 5 ? "left" : "right";
        match = all.find((c) => c.questionType === "HOME_ROW" && (c.handId === hand || c.candidateId.includes(hand)));
      } else if (typeVal === "DITO") {
        const pk = this.catalog.getPhysicalKey(keyId);
        if (pk) {
          match = all.find((c) => c.questionType === "DITO" && String(c.fingerId) === String(pk.assignedFinger));
        }
      } else if (typeVal === "TASTO") {
        match = all.find((c) => c.questionType === "TASTO" && c.keyId === keyId);
      } else {
        // CARATTERE o MIXED: cerca carattere normale del tasto
        const slots = global.InterrogationLayoutMetadata?.getKeySlots(keyId);
        const targetChar = slots && slots.normal ? slots.normal : null;
        if (targetChar) {
          match = all.find((c) => c.questionType === "CARATTERE" && c.character === targetChar);
        }
        if (!match) {
          match = all.find((c) => c.keyId === keyId);
        }
      }

      if (match && !this.manualSelectedIds.includes(match.candidateId)) {
        this.manualSelectedIds.push(match.candidateId);
        if (this.manualSvg) {
          this.manualSvg.highlightKey(keyId, "interr-key-selected");
        }
        this._renderManualChips();
      }
    }

    _addManualCandidateByChar(ch) {
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const all = this.catalog.getCandidates({});
      let match = null;

      if (typeVal === "TASTO") {
        const charCand = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
        if (charCand && charCand.keyId) {
          match = all.find((c) => c.questionType === "TASTO" && c.keyId === charCand.keyId);
        }
      } else if (typeVal === "DITO") {
        const charCand = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
        if (charCand && charCand.keyId) {
          const pk = this.catalog.getPhysicalKey(charCand.keyId);
          if (pk) {
            match = all.find((c) => c.questionType === "DITO" && String(c.fingerId) === String(pk.assignedFinger));
          }
        }
      } else {
        match = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
      }

      if (match && !this.manualSelectedIds.includes(match.candidateId)) {
        this.manualSelectedIds.push(match.candidateId);
        if (this.manualSvg && match.keyId) {
          this.manualSvg.highlightKey(match.keyId, "interr-key-selected");
        }
        this._renderManualChips();
      }
    }

    _addManualCandidateByFingerId(fingerId) {
      const fNum = String(fingerId || "").replace(/^finger\./, "");
      const all = this.catalog.getCandidates({ questionType: "DITO" });
      const match = all.find((c) => String(c.fingerId) === fNum || String(c.mainElementSemanticId) === `finger.${fNum}`);
      if (match && !this.manualSelectedIds.includes(match.candidateId)) {
        this.manualSelectedIds.push(match.candidateId);
        if (this.manualSvg) {
          this.manualSvg.highlightFingerOnHands(fNum);
        }
        this._renderManualChips();
      }
    }

    _renderManualChips() {
      const box = document.getElementById("interrManualSelectedChips");
      if (!box) return;
      box.innerHTML = "";
      if (this.manualSelectedIds.length === 0) {
        box.appendChild(createEl("span", "interr-chip-empty", "Nessuna selezione manuale effettuata."));
        return;
      }
      this.manualSelectedIds.forEach((cid) => {
        const c = this.catalog.getCandidateById(cid);
        if (!c) return;
        const lbl =
          typeof this.catalog.getReadableCandidateLabel === "function"
            ? this.catalog.getReadableCandidateLabel(c)
            : cid;
        const chip = createEl("span", "interr-selected-chip");
        chip.appendChild(createEl("span", "", lbl));
        const rm = createEl("button", "interr-chip-remove", "✕");
        rm.type = "button";
        rm.addEventListener("click", () => {
          this.manualSelectedIds = this.manualSelectedIds.filter((id) => id !== cid);
          this._renderManualChips();
        });
        chip.appendChild(rm);
        box.appendChild(chip);
      });
    }

    _setSetupFeedback(msg, kind) {
      const el = document.getElementById("interrogationSetupFeedback");
      if (!el) return;
      el.textContent = msg || "";
      el.className = "interrogation-feedback" + (kind ? ` is-${kind}` : "");
    }

    _setFeedback(msg, kind) {
      const el = document.getElementById("interrogationFeedback");
      if (!el) return;
      el.textContent = msg || "";
      el.className = "interrogation-feedback" + (kind ? ` is-${kind}` : "");
    }

    async handleStartSession() {
      const profileId = this.getProfileId();
      const mode = document.getElementById("interrogationModeSelect")?.value || "random";
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const countVal = parseInt(document.getElementById("interrogationCountSelect")?.value || "10", 10);
      this.fingerMode = document.getElementById("interrogationFingerModeSelect")?.value || "soli_tasti_fisici";

      let manualIds = [];
      if (mode === "manual") {
        manualIds = this.manualSelectedIds.slice();
        if (manualIds.length === 0) {
          this._setSetupFeedback(
            "Seleziona almeno un elemento (clic su tastiera B/N, mani, tastiera fisica o griglia ASCII).",
            "error",
          );
          return;
        }
      }

      this._setSetupFeedback("", "");
      const created = await this.sessionMgr.createSession({
        profileId,
        mode,
        questionTypes: typeVal === "MIXED" ? ["HOME_ROW", "TASTO", "CARATTERE", "DITO"] : [typeVal],
        requestedCount: mode === "manual" ? manualIds.length : countVal,
        manualCandidateIds: manualIds,
      });

      this.activeSession = created.session;
      this.activeItems = created.items;
      this.currentItemIdx = 0;
      this._setFeedback("", "");
      this._renderRunView();
    }

    async handleResumeSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      const resumed = await this.sessionMgr.resumeSession(profileId, suspended.sessionId);
      this.activeSession = resumed.session;
      this.activeItems = resumed.items;
      this.currentItemIdx = resumed.session.currentItemIndex || 0;
      this._renderRunView();
    }

    async handleAbandonSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      await this.sessionMgr.abandonSession(profileId, suspended.sessionId);
      await this.showSetupView();
    }

    _mountRunSvg() {
      const kbHost = document.getElementById("interrRunKeyboardHost");
      const hHost = document.getElementById("interrRunHandsHost");
      if (!kbHost || !hHost || typeof global.InterrogationSvgRenderer !== "function") return;
      if (!this.runSvg) {
        this.runSvg = new global.InterrogationSvgRenderer({
          onKeyClick: (keyId) => this._handleRunKeyboardClick(keyId),
          onFingerClick: (fingerId) => {
            if (typeof this._activeRunFingerClickHandler === "function") {
              this._activeRunFingerClickHandler(fingerId);
            }
          },
          onLandmarkClick: (info) => {
            if (typeof this._activeRunLandmarkClickHandler === "function") {
              this._activeRunLandmarkClickHandler(info);
            }
          },
        });
      }
      this.runSvg.mount(kbHost, hHost);
    }

    _handleRunKeyboardClick(keyId) {
      if (typeof this._activeRunKeyClickHandler === "function") {
        this._activeRunKeyClickHandler(keyId);
      }
    }

    _computeSessionMaxScore() {
      if (!Array.isArray(this.activeItems) || this.activeItems.length === 0) {
        return (this.activeSession && this.activeSession.maxScore) || 0;
      }
      return this.activeItems.reduce((acc, it) => {
        if (it.questionType === "CARATTERE" || it.questionType === "TASTO") {
          return acc + 18; // 3 (Accordo) + 3 (Slot Tasto) + 12 (4 direzioni Margherita)
        }
        return acc + 3;
      }, 0);
    }

    _updateRunScoreHeader() {
      const scoreEl = document.getElementById("interrogationRunScore");
      if (scoreEl && this.activeSession) {
        const maxScore = this._computeSessionMaxScore();
        scoreEl.textContent = `Punteggio: ${this.activeSession.score} / ${maxScore}`;
      }
    }

    _resolveTargetCharacterForItem(item) {
      const meta = global.InterrogationLayoutMetadata;
      let resolvedKeyId = item.keyId || null;
      let resolvedChar = item.character || null;

      if (!resolvedChar && item.mainElementSemanticId && this.catalog) {
        const mapping = this.catalog.getCharacterMappingBySemanticId(item.mainElementSemanticId);
        if (mapping) {
          resolvedChar = mapping.value;
          if (!resolvedKeyId && mapping.physicalKeySemanticId) {
            resolvedKeyId = String(mapping.physicalKeySemanticId).replace(/^key\./, "");
          }
        }
      }
      if (!resolvedKeyId && item.mainElementSemanticId && String(item.mainElementSemanticId).startsWith("key.")) {
        resolvedKeyId = String(item.mainElementSemanticId).replace(/^key\./, "");
      }
      if (!resolvedKeyId && resolvedChar && meta) {
        resolvedKeyId = meta.getKeyIdForChar(resolvedChar);
      }

      if (item.questionType === "CARATTERE" && resolvedChar) {
        return { char: resolvedChar, keyId: resolvedKeyId };
      }
      if (item.questionType === "TASTO" && resolvedKeyId && meta) {
        if (!item._resolvedRandomChar) {
          const slots = meta.getKeySlots(resolvedKeyId) || {};
          const available = [slots.normal, slots.shift, slots.altgr, slots.shiftAltgr].filter(Boolean);
          const idx = available.length > 0 ? Math.floor(Math.random() * available.length) : 0;
          item._resolvedRandomChar = available[idx] || resolvedKeyId;
        }
        return { char: item._resolvedRandomChar, keyId: resolvedKeyId };
      }
      return { char: resolvedChar || "", keyId: resolvedKeyId };
    }

    _renderRunView() {
      this._switchView("run");
      this._mountRunSvg();
      this._activeRunKeyClickHandler = null;
      this._activeRunFingerClickHandler = null;
      this._activeRunLandmarkClickHandler = null;

      const total = this.activeItems.length;
      const item = this.activeItems[this.currentItemIdx];
      if (!item) return;

      const progEl = document.getElementById("interrogationRunProgress");
      const badgeEl = document.getElementById("interrTargetBadge");
      const titleEl = document.getElementById("interrogationQuestionTitle");
      const panelEl = document.getElementById("interrInteractivePanel");
      const btnNext = document.getElementById("btnInterrogationFinishItem");
      const btnComp = document.getElementById("btnInterrogationComplete");

      if (progEl) progEl.textContent = `Domanda ${this.currentItemIdx + 1} di ${total}`;
      this._updateRunScoreHeader();

      if (btnNext) btnNext.classList.toggle("is-hidden", this.currentItemIdx >= total - 1);
      if (btnComp) btnComp.classList.toggle("is-hidden", this.currentItemIdx < total - 1);

      this.runSvg.resetKeyboard();
      this.runSvg.resetHands();
      if (panelEl) panelEl.innerHTML = "";

      if (item.questionType === "CARATTERE" || item.questionType === "TASTO") {
        const target = this._resolveTargetCharacterForItem(item);
        if (badgeEl) badgeEl.textContent = `CARATTERE: "${target.char}"`;
        if (titleEl) {
          titleEl.textContent =
            item.questionType === "TASTO"
              ? `Tasto selezionato (carattere estratto): "${target.char}"`
              : `Carattere da analizzare: "${target.char}"`;
        }
        this._renderCharacterQuestionPanel(panelEl, item, target.char, target.keyId);
      } else if (item.questionType === "DITO") {
        const fId = String(item.fingerId || item.mainElementSemanticId || "").replace(/^finger\./, "");
        const fLabel = this.catalog.getReadableFingerName(fId);
        if (badgeEl) badgeEl.textContent = `DITO: ${fLabel}`;
        if (titleEl) titleEl.textContent = `Individua i tasti/caratteri per il dito: ${fLabel}`;
        this._renderFingerQuestionPanel(panelEl, item, fId);
      } else if (item.questionType === "HOME_ROW") {
        const hand =
          item.handId ||
          (String(item.candidateId || "").includes("right") ? "right" : "left");
        const handLabel = hand === "right" ? "Mano Destra" : "Mano Sinistra";
        if (badgeEl) badgeEl.textContent = `RIPOSO: ${handLabel}`;
        if (titleEl) titleEl.textContent = `Tasti in Posizione di Riposo — ${handLabel}`;
        this._renderHomeRowQuestionPanel(panelEl, item, hand);
      }
    }

    async _recordBlock(item, blockId, outcome, userAnswer) {
      const res = await this.sessionMgr.recordBlockEvaluation({
        profileId: this.getProfileId(),
        sessionId: this.activeSession.sessionId,
        itemId: item.itemId,
        blockId,
        outcome,
        userAnswer,
      });
      this.activeSession.score = res.sessionScore;
      this._updateRunScoreHeader();
      return res;
    }

    _applyBlockBadge(badgeEl, outcome, detailText) {
      if (!badgeEl) return;
      badgeEl.className = "interr-outcome-badge";
      if (outcome === "correct") {
        badgeEl.classList.add("is-ok");
        badgeEl.textContent = `OK (+3 pt) ${detailText || ""}`.trim();
      } else if (outcome === "consulted") {
        badgeEl.classList.add("is-consulted");
        badgeEl.textContent = `CONSULTA (+1 pt) ${detailText || ""}`.trim();
      } else {
        badgeEl.classList.add("is-ko");
        badgeEl.textContent = `KO (0 pt) ${detailText || ""}`.trim();
      }
    }

    _getModifierKeyIdsForMode(modMode) {
      const norm = global.InterrogationLayoutMetadata?.normalizeModifierMode(modMode) || "none";
      if (norm === "shift") return ["key_shift_l", "key_shift_r"];
      if (norm === "altgr") return ["key_altgr", "key_ctrl_l", "key_alt_l"];
      if (norm === "shiftAltgr") return ["key_shift_l", "key_altgr", "key_ctrl_l", "key_alt_l"];
      return [];
    }

    _renderCharacterQuestionPanel(panelEl, item, targetChar, keyId) {
      const meta = global.InterrogationLayoutMetadata;
      const pk = this.catalog.getPhysicalKey(keyId);
      const ext = meta.getKeyExtension(keyId);
      const slots = meta.getKeySlots(keyId) || {};
      const neighbors = meta.getNeighbors(keyId) || {};

      // Determina lo slot noto del carattere target
      let knownSlot = "normal";
      let expectedModMode = "none";
      if (slots.shift === targetChar) {
        knownSlot = "shift";
        expectedModMode = "shift";
      } else if (slots.altgr === targetChar) {
        knownSlot = "altgr";
        expectedModMode = "altgr";
      } else if (slots.shiftAltgr === targetChar) {
        knownSlot = "shiftAltgr";
        expectedModMode = "shiftAltgr";
      }

      const expectedFingerNum = String(pk ? pk.assignedFinger : item.fingerId || "");
      const expectedFingerInfo = FINGER_NUM_TO_BASE[expectedFingerNum] || { hand: "left", base: "indice" };

      const grid = createEl("div", "interr-char-blocks-grid");

      // =========================================================
      // BLOCCO 1: DESCRIZIONE ACCORDO
      // =========================================================
      const blk1 = createEl("section", "interr-block-card");
      const h1 = createEl("div", "interr-block-header");
      h1.appendChild(createEl("h5", "", "1) Descrizione Accordo"));
      const badge1 = createEl("span", "interr-outcome-badge");
      h1.appendChild(badge1);
      blk1.appendChild(h1);

      const form1 = createEl("div", "interr-accord-grid-compact");
      const leftCol = createEl("div", "interr-accord-left-col");
      const rightCol = createEl("div", "interr-accord-right-col");

      const addEmptyOpt = (sel, label = "—") => {
        const opt = createEl("option", "", label);
        opt.value = "";
        sel.appendChild(opt);
      };

      const selHand = createEl("select", "interr-input");
      addEmptyOpt(selHand);
      [
        { v: "left", l: "Sinistra (sn)" },
        { v: "right", l: "Destra (dx)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selHand.appendChild(opt);
      });
      selHand.value = "";

      const selFinger = createEl("select", "interr-input");
      addEmptyOpt(selFinger);
      FINGER_NAMES_BASE.forEach((f) => {
        const opt = createEl("option", "", f.label);
        opt.value = f.id;
        selFinger.appendChild(opt);
      });
      selFinger.value = "";

      const selLatExt = createEl("select", "interr-input");
      addEmptyOpt(selLatExt);
      ["0", "1", "2", "3"].forEach((v) => {
        const opt = createEl("option", "", v === "0" ? "0 (normale)" : v);
        opt.value = v;
        selLatExt.appendChild(opt);
      });
      selLatExt.value = "";

      const selLatDir = createEl("select", "interr-input");
      addEmptyOpt(selLatDir);
      [
        { v: "none", l: "Nessuna (0)" },
        { v: "sn", l: "Sinistra (sn)" },
        { v: "dx", l: "Destra (dx)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selLatDir.appendChild(opt);
      });
      selLatDir.value = "";

      const selLongExt = createEl("select", "interr-input");
      addEmptyOpt(selLongExt);
      [
        { v: "2", l: "+2 (2 righe sopra riposo)" },
        { v: "1", l: "+1 (1 riga sopra riposo)" },
        { v: "0", l: "0 (Posizione di Riposo)" },
        { v: "-1", l: "-1 (1 riga sotto riposo)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selLongExt.appendChild(opt);
      });
      selLongExt.value = "";

      const addRowTo = (parent, lbl, ctrl) => {
        const r = createEl("div", "interr-field-row");
        r.appendChild(createEl("label", "", lbl));
        r.appendChild(ctrl);
        parent.appendChild(r);
      };
      addRowTo(leftCol, "Mano:", selHand);
      addRowTo(leftCol, "Dito:", selFinger);
      addRowTo(leftCol, "Estensione laterale:", selLatExt);
      addRowTo(leftCol, "Estensione longitudinale:", selLongExt);

      addRowTo(rightCol, "Direzione sovraccarico:", selLatDir);

      // Checkboxes modificatori: CTRL, SHIFT, ALT, AltGr
      const modBox = createEl("div", "interr-mod-checkboxes");
      modBox.appendChild(createEl("span", "interr-mod-title", "Accordo Modificatore:"));
      const modCbs = {};
      ["CTRL", "SHIFT", "ALT", "AltGr"].forEach((mName) => {
        const lbl = createEl("label", "interr-cb-label");
        const cb = document.createElement("input");
        cb.type = "checkbox";
        modCbs[mName.toLowerCase()] = cb;
        lbl.appendChild(cb);
        lbl.appendChild(createEl("span", "", mName));
        modBox.appendChild(lbl);
      });
      rightCol.appendChild(modBox);

      const act1 = createEl("div", "interr-block-actions");
      const btnOk1 = createEl("button", "btn btn-primary btn-sm", "Conferma Accordo");
      const btnCons1 = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk1.type = "button";
      btnCons1.type = "button";
      act1.appendChild(btnOk1);
      act1.appendChild(btnCons1);
      rightCol.appendChild(act1);

      form1.appendChild(leftCol);
      form1.appendChild(rightCol);
      blk1.appendChild(form1);

      // Scorciatoia grafica: clic su dito o pallino delle mani pre-compila i dropdown senza confermare
      this._activeRunFingerClickHandler = (fId) => {
        if (btnOk1.disabled) return;
        const info = FINGER_NUM_TO_BASE[String(fId)];
        if (info) {
          selHand.value = info.hand;
          selFinger.value = info.base;
          this.runSvg.highlightFingerOnHands(fId);
        }
      };

      this._activeRunLandmarkClickHandler = (info) => {
        if (btnOk1.disabled || !info) return;
        const fInfo = FINGER_NUM_TO_BASE[String(info.fingerId)];
        if (fInfo) {
          selHand.value = fInfo.hand;
          selFinger.value = fInfo.base;
        }
        if (info.keyId && meta) {
          const lmExt = meta.getKeyExtensions(info.keyId);
          if (lmExt) {
            selLatExt.value = String(lmExt.lateralExt);
            selLatDir.value = String(lmExt.lateralDir || "none");
            selLongExt.value = String(lmExt.longitudinalExt);
          }
        }
        if (info.fingerId) {
          this.runSvg.highlightFingerOnHands(info.fingerId);
        }
      };

      const showAccordSolution = (outcome) => {
        btnOk1.disabled = true;
        btnCons1.disabled = true;
        this.runSvg.highlightTargetLandmark(
          keyId,
          expectedFingerNum,
          this._getModifierKeyIdsForMode(expectedModMode),
        );
        const partialSlots = { [knownSlot]: targetChar };
        this.runSvg.revealKey(keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-ko", partialSlots);
        const longLabel = keyId === "key_enter"
          ? "0 o +1"
          : (ext.longitudinalExt > 0 ? "+" + ext.longitudinalExt : ext.longitudinalExt);
        const solText = `Mano ${expectedFingerInfo.hand === "left" ? "sn" : "dx"}, ${expectedFingerInfo.base}, est. lat ${ext.lateralExt} (${ext.lateralDir}), est. long ${longLabel}, mod: ${expectedModMode}`;
        this._applyBlockBadge(badge1, outcome, `— ${solText}`);
      };

      btnOk1.addEventListener("click", async () => {
        if (!selHand.value || !selFinger.value || selLatExt.value === "" || !selLatDir.value || selLongExt.value === "") {
          this._setFeedback("Seleziona tutti i menu a tendina di Descrizione Accordo prima di confermare.", "error");
          return;
        }
        this._setFeedback("", "");
        const chosenFinger = resolveFingerNumber(selHand.value, selFinger.value);
        const fingerOk = chosenFinger === expectedFingerNum;
        const latExtOk = Number(selLatExt.value) === Number(ext.lateralExt);
        const latDirOk = Number(ext.lateralExt) === 0
          ? (selLatDir.value === "none" || Number(selLatExt.value) === 0)
          : selLatDir.value === ext.lateralDir;
        const longOk = keyId === "key_enter"
          ? (selLongExt.value === "0" || selLongExt.value === "1")
          : Number(selLongExt.value) === Number(ext.longitudinalExt);
        const modOk = meta.isModifierMatch(expectedModMode, {
          ctrl: modCbs.ctrl.checked,
          shift: modCbs.shift.checked,
          alt: modCbs.alt.checked,
          altgr: modCbs.altgr.checked,
        });
        const isOk = fingerOk && latExtOk && latDirOk && longOk && modOk;
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "accord", outcome, {
          hand: selHand.value,
          finger: selFinger.value,
          latExt: selLatExt.value,
          latDir: selLatDir.value,
          longExt: selLongExt.value,
        });
        showAccordSolution(outcome);
      });

      btnCons1.addEventListener("click", async () => {
        await this._recordBlock(item, "accord", "consulted", null);
        showAccordSolution("consulted");
      });

      grid.appendChild(blk1);

      // =========================================================
      // BLOCCO 2: CARATTERI SUL TASTO
      // =========================================================
      const blk2 = createEl("section", "interr-block-card");
      const h2 = createEl("div", "interr-block-header");
      h2.appendChild(createEl("h5", "", "2) Caratteri sul Tasto"));
      const badge2 = createEl("span", "interr-outcome-badge");
      h2.appendChild(badge2);
      blk2.appendChild(h2);

      const slotsWrap = createEl("div", "interr-key-slots-wrap");
      const miniHost = createEl("div", "interr-mini-keycap-host");
      const slotList = createEl("div", "interr-slot-list");

      const slotAnswers = {
        normal: knownSlot === "normal" ? targetChar : "",
        shift: knownSlot === "shift" ? targetChar : "",
        altgr: knownSlot === "altgr" ? targetChar : "",
        shiftAltgr: knownSlot === "shiftAltgr" ? targetChar : "",
      };

      const refreshMini = () => {
        this.runSvg.renderKeycapPreview(miniHost, keyId, slotAnswers);
      };
      refreshMini();

      const slotDefs = [
        { key: "normal", label: "NORMALE" },
        { key: "shift", label: "(SHIFT)" },
        { key: "altgr", label: "(CTRL + ALT / AltGr)" },
        { key: "shiftAltgr", label: "(CTRL + ALT + SHIFT)" },
      ];

      slotDefs.forEach((sd) => {
        const row = createEl("div", "interr-slot-row");
        row.appendChild(createEl("span", "interr-slot-name", sd.label));
        const btnPick = createEl(
          "button",
          "btn btn-sm interr-slot-btn",
          sd.key === knownSlot ? targetChar : "Scegli...",
        );
        btnPick.type = "button";
        if (sd.key === knownSlot) {
          btnPick.disabled = true;
          btnPick.classList.add("is-prefilled");
        } else {
          btnPick.addEventListener("click", (e) => {
            this._openAsciiPopover(
              e.currentTarget,
              { includeSpecial: false, includeNone: true },
              (val) => {
                slotAnswers[sd.key] = val;
                btnPick.textContent = val;
                refreshMini();
              },
            );
          });
        }
        row.appendChild(btnPick);
        slotList.appendChild(row);
      });

      slotsWrap.appendChild(slotList);
      slotsWrap.appendChild(miniHost);
      blk2.appendChild(slotsWrap);

      const act2 = createEl("div", "interr-block-actions");
      const btnOk2 = createEl("button", "btn btn-primary btn-sm", "Conferma Caratteri");
      const btnCons2 = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk2.type = "button";
      btnCons2.type = "button";
      act2.appendChild(btnOk2);
      act2.appendChild(btnCons2);
      blk2.appendChild(act2);

      const showSlotsSolution = (outcome) => {
        btnOk2.disabled = true;
        btnCons2.disabled = true;
        this.runSvg.renderKeycapPreview(miniHost, keyId, {
          normal: true,
          shift: true,
          altgr: true,
          shiftAltgr: true,
        });
        this.runSvg.revealKey(keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-ko");
        this.runSvg.highlightTargetLandmark(
          keyId,
          expectedFingerNum,
          this._getModifierKeyIdsForMode(expectedModMode),
        );
        const summary = `N: ${slots.normal || "NONE"} | S: ${slots.shift || "NONE"} | AG: ${slots.altgr || "NONE"} | S+AG: ${slots.shiftAltgr || "NONE"}`;
        this._applyBlockBadge(badge2, outcome, `— ${summary}`);
      };

      btnOk2.addEventListener("click", async () => {
        const expected = {
          normal: slots.normal || "NONE",
          shift: slots.shift || "NONE",
          altgr: slots.altgr || "NONE",
          shiftAltgr: slots.shiftAltgr || "NONE",
        };
        const isOk = slotDefs.every((sd) => {
          const ans = slotAnswers[sd.key] || "NONE";
          return ans === expected[sd.key];
        });
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "keyChars", outcome, slotAnswers);
        showSlotsSolution(outcome);
      });

      btnCons2.addEventListener("click", async () => {
        await this._recordBlock(item, "keyChars", "consulted", null);
        showSlotsSolution("consulted");
      });

      grid.appendChild(blk2);

      // =========================================================
      // BLOCCO 3: TASTI INTORNO (MARGHERITA)
      // =========================================================
      const blk3 = createEl("section", "interr-block-card interr-block-wide");
      const h3 = createEl("div", "interr-block-header");
      h3.appendChild(createEl("h5", "", "3) Tasti intorno (Margherita)"));
      const badge3 = createEl("span", "interr-outcome-badge");
      h3.appendChild(badge3);
      blk3.appendChild(h3);

      const margheritaGrid = createEl("div", "interr-margherita-grid");
      const neighborGroups = [
        { id: "top", label: "Coppia sopra", slots: ["topLeft", "topRight"] },
        { id: "left", label: "Sinistra", slots: ["left"] },
        { id: "right", label: "Destra", slots: ["right"] },
        { id: "bottom", label: "Coppia sotto", slots: ["bottomLeft", "bottomRight"] },
      ];

      const neighborAnswers = {};
      neighborGroups.forEach((grp) => {
        const gCard = createEl("div", "interr-neighbor-group");
        gCard.appendChild(createEl("div", "interr-neighbor-title", grp.label));

        const gSlots = createEl("div", "interr-neighbor-slots");
        grp.slots.forEach((sName) => {
          neighborAnswers[sName] = "";
          const btn = createEl("button", "btn btn-sm interr-slot-btn", "Scegli...");
          btn.type = "button";
          btn.addEventListener("click", (e) => {
            this._openAsciiPopover(
              e.currentTarget,
              { includeSpecial: true, includeNone: true },
              (val) => {
                neighborAnswers[sName] = val;
                btn.textContent = val;
              },
            );
          });
          gSlots.appendChild(btn);
        });
        gCard.appendChild(gSlots);

        const gBadge = createEl("span", "interr-outcome-badge interr-mini-badge");
        const gActs = createEl("div", "interr-block-actions");
        const bOk = createEl("button", "btn btn-primary btn-sm", "Conferma");
        const bCons = createEl("button", "btn btn-sm", "Consulta (+1)");
        bOk.type = "button";
        bCons.type = "button";
        gActs.appendChild(bOk);
        gActs.appendChild(bCons);
        gCard.appendChild(gActs);
        gCard.appendChild(gBadge);

        const isEnterLeft = keyId === "key_enter" && grp.id === "left";

        const revealGroup = (outcome) => {
          bOk.disabled = true;
          bCons.disabled = true;
          let expectedLabels;
          if (isEnterLeft) {
            this.runSvg.revealKey("key_plus", "interr-key-neighbor");
            this.runSvg.revealKey("key_ugrave", "interr-key-neighbor");
            expectedLabels = ["+ / ù"];
          } else {
            expectedLabels = grp.slots.map((sName) => {
              const nk = neighbors[sName];
              if (nk) {
                this.runSvg.revealKey(nk, "interr-key-neighbor");
              }
              return meta.getKeyDisplayToken(nk);
            });
          }
          this._applyBlockBadge(gBadge, outcome, `— ${expectedLabels.join(" , ")}`);
          this.runSvg.revealKey(
            keyId,
            "interr-key-target",
            btnOk2.disabled ? null : { [knownSlot]: targetChar },
          );
          this.runSvg.highlightTargetLandmark(
            keyId,
            expectedFingerNum,
            this._getModifierKeyIdsForMode(expectedModMode),
          );
        };

        bOk.addEventListener("click", async () => {
          const isOk = grp.slots.every((sName) => {
            const expectedKeyId = neighbors[sName];
            const givenToken = neighborAnswers[sName] || "NONE";
            if (isEnterLeft && sName === "left") {
              const resolved = meta.resolveKeyIdFromToken(givenToken);
              return resolved === "key_plus" || resolved === "key_ugrave" || givenToken === "+" || givenToken === "ù";
            }
            if (!expectedKeyId) return givenToken === "NONE";
            return meta.resolveKeyIdFromToken(givenToken) === expectedKeyId;
          });
          const outcome = isOk ? "correct" : "incorrect";
          await this._recordBlock(item, `neighbors_${grp.id}`, outcome, neighborAnswers);
          revealGroup(outcome);
        });

        bCons.addEventListener("click", async () => {
          await this._recordBlock(item, `neighbors_${grp.id}`, "consulted", null);
          revealGroup("consulted");
        });

        margheritaGrid.appendChild(gCard);
      });

      blk3.appendChild(margheritaGrid);
      grid.appendChild(blk3);
      panelEl.appendChild(grid);
    }

    _renderFingerQuestionPanel(panelEl, item, fingerId) {
      const meta = global.InterrogationLayoutMetadata;
      const card = createEl("section", "interr-block-card interr-block-wide");
      const h = createEl("div", "interr-block-header");
      h.appendChild(createEl("h5", "", "Tasti e Caratteri associati al Dito"));
      const badge = createEl("span", "interr-outcome-badge");
      h.appendChild(badge);
      card.appendChild(h);

      // Evidenzia solo il dito sulle mani; NESSUNA evidenziazione preventiva dei tasti (nessun suggerimento)
      this.runSvg.highlightFingerOnHands(fingerId);

      const selectedDisplay = createEl("div", "interr-selected-chips");
      // Mappa keyId -> carattere/token scelto dall'utente
      const userChoices = new Map();
      let isLocked = false;

      const renderSelectionChips = () => {
        selectedDisplay.innerHTML = "";
        if (userChoices.size === 0) {
          selectedDisplay.appendChild(
            createEl(
              "span",
              "interr-chip-empty",
              "Clicca un tasto sulla tastiera B/N per colorarlo di giallo e abbinargli il carattere dalla palette.",
            ),
          );
          return;
        }
        userChoices.forEach((chosenChar, kId) => {
          const chip = createEl("span", "interr-selected-chip", chosenChar);
          if (!isLocked) {
            const rm = createEl("button", "interr-chip-remove", "×");
            rm.type = "button";
            rm.title = "Rimuovi selezione tasto";
            rm.addEventListener("click", () => {
              userChoices.delete(kId);
              this.runSvg.unhighlightKey(kId, "interr-key-yellow");
              this.runSvg.setKeyUserBadge(kId, "");
              renderSelectionChips();
            });
            chip.appendChild(rm);
          }
          selectedDisplay.appendChild(chip);
        });
      };
      renderSelectionChips();

      this._activeRunKeyClickHandler = (keyId) => {
        if (isLocked) return;
        this.runSvg.highlightKey(keyId, "interr-key-yellow");
        const keyEl = document.querySelector(`#interrKeyboardHost [data-key-id="${keyId}"]`);
        this._openAsciiPopover(
          keyEl || selectedDisplay,
          { includeSpecial: true, includeNone: false },
          (chosenChar) => {
            if (isLocked) return;
            userChoices.set(keyId, chosenChar);
            this.runSvg.highlightKey(keyId, "interr-key-yellow");
            this.runSvg.setKeyUserBadge(keyId, chosenChar);
            renderSelectionChips();
          },
        );
      };

      card.appendChild(selectedDisplay);

      const acts = createEl("div", "interr-block-actions");
      const btnOk = createEl("button", "btn btn-primary btn-sm", "Conferma Selezione");
      const btnCons = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk.type = "button";
      btnCons.type = "button";
      acts.appendChild(btnOk);
      acts.appendChild(btnCons);
      card.appendChild(acts);

      const doesCharBelongToKey = (keyId, ch) => {
        if (!ch) return false;
        const sl = meta.getKeySlots(keyId) || {};
        const token = meta.getKeyDisplayToken(keyId);
        const valid = [sl.normal, sl.shift, sl.altgr, sl.shiftAltgr, token].filter(Boolean);
        if (valid.includes(ch)) return true;
        return meta.resolveKeyIdFromToken(ch) === keyId;
      };

      const revealFingerSolution = (outcome) => {
        isLocked = true;
        btnOk.disabled = true;
        btnCons.disabled = true;
        this._closeAsciiPopover();

        const expected = meta.getKeysForFinger(this.catalog, fingerId, {});
        const expectedSet = new Set(expected.map((k) => k.keyId));

        // Tasti corretti del dito: verde con caratteri reali svelati
        expected.forEach((k) => {
          this.runSvg.unhighlightKey(k.keyId, "interr-key-yellow");
          this.runSvg.setKeyUserBadge(k.keyId, "");
          this.runSvg.revealKey(k.keyId, "interr-key-ok");
        });

        // Tasti scelti dall'utente fuori posto: restano gialli con l'informazione inserita dall'utente
        userChoices.forEach((chosenChar, kId) => {
          if (!expectedSet.has(kId)) {
            this.runSvg.highlightKey(kId, "interr-key-yellow");
            this.runSvg.setKeyUserBadge(kId, chosenChar);
          }
        });

        renderSelectionChips();
        const txt = expected.map((k) => meta.getKeyDisplayToken(k.keyId)).join(", ");
        this._applyBlockBadge(badge, outcome, `— Tasti attesi: ${txt}`);
      };

      btnOk.addEventListener("click", async () => {
        const expectedKeys = meta.getKeysForFinger(this.catalog, fingerId, {});
        const expSet = new Set(expectedKeys.map((k) => k.keyId));
        const isOk =
          expSet.size === userChoices.size &&
          Array.from(expSet).every((kId) => userChoices.has(kId) && doesCharBelongToKey(kId, userChoices.get(kId)));

        const outcome = isOk ? "correct" : "incorrect";
        const payload = Array.from(userChoices.entries()).map(([keyId, char]) => ({ keyId, char }));
        await this._recordBlock(item, "fingerKeys", outcome, payload);
        revealFingerSolution(outcome);
      });

      btnCons.addEventListener("click", async () => {
        await this._recordBlock(item, "fingerKeys", "consulted", null);
        revealFingerSolution("consulted");
      });

      panelEl.appendChild(card);
    }

    _renderHomeRowQuestionPanel(panelEl, item, hand) {
      const meta = global.InterrogationLayoutMetadata;
      const expectedList = meta.HOME_ROW_KEYS[hand] || meta.HOME_ROW_KEYS.left;

      const card = createEl("section", "interr-block-card interr-block-wide");
      const h = createEl("div", "interr-block-header");
      h.appendChild(createEl("h5", "", `Clicca i 4 tasti in Posizione di Riposo (${hand === "left" ? "Sinistra" : "Destra"}) sulla tastiera B/N e indica carattere + dito`));
      const badge = createEl("span", "interr-outcome-badge");
      h.appendChild(badge);
      card.appendChild(h);

      const rowsBox = createEl("div", "interr-homerow-rows");
      const entries = [0, 1, 2, 3].map((idx) => ({
        idx,
        keyId: "",
        char: "",
        fingerId: "",
      }));

      let activeRowIdx = 0;

      const renderRows = () => {
        rowsBox.innerHTML = "";
        entries.forEach((ent) => {
          const r = createEl("div", "interr-homerow-row" + (ent.idx === activeRowIdx ? " is-active" : ""));
          const btnPickKey = createEl(
            "button",
            "btn btn-sm",
            ent.keyId ? `Tasto: ${ent.idx + 1} (${ent.keyId.replace("key_", "")})` : `Seleziona tasto #${ent.idx + 1} su tastiera`,
          );
          btnPickKey.type = "button";
          btnPickKey.addEventListener("click", () => {
            activeRowIdx = ent.idx;
            renderRows();
          });

          const btnChar = createEl("button", "btn btn-sm interr-slot-btn", ent.char || "Carattere...");
          btnChar.type = "button";
          btnChar.addEventListener("click", (e) => {
            this._openAsciiPopover(e.currentTarget, { includeSpecial: false, includeNone: false }, (ch) => {
              ent.char = ch;
              btnChar.textContent = ch;
            });
          });

          const selFinger = createEl("select", "interr-input");
          const optEmpty = createEl("option", "", "Dito...");
          optEmpty.value = "";
          selFinger.appendChild(optEmpty);
          Object.entries(FINGER_NUM_TO_BASE).forEach(([id, info]) => {
            const opt = createEl("option", "", `${info.base} (${info.hand === "left" ? "sn" : "dx"})`);
            opt.value = id;
            selFinger.appendChild(opt);
          });
          selFinger.value = ent.fingerId;
          selFinger.addEventListener("change", () => {
            ent.fingerId = selFinger.value;
          });

          r.appendChild(btnPickKey);
          r.appendChild(btnChar);
          r.appendChild(selFinger);
          rowsBox.appendChild(r);
        });
      };
      renderRows();

      this._activeRunKeyClickHandler = (keyId) => {
        entries[activeRowIdx].keyId = keyId;
        this.runSvg.highlightKey(keyId, "interr-key-selected");
        if (activeRowIdx < 3) activeRowIdx++;
        renderRows();
      };

      card.appendChild(rowsBox);

      const acts = createEl("div", "interr-block-actions");
      const btnOk = createEl("button", "btn btn-primary btn-sm", "Conferma Posizione Riposo");
      const btnCons = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk.type = "button";
      btnCons.type = "button";
      acts.appendChild(btnOk);
      acts.appendChild(btnCons);
      card.appendChild(acts);

      const revealHomeSolution = (outcome) => {
        btnOk.disabled = true;
        btnCons.disabled = true;
        expectedList.forEach((exp) => {
          this.runSvg.revealKey(exp.keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-neighbor");
        });
        const txt = expectedList.map((e) => `${e.char} (${e.fingerLabel})`).join(" | ");
        this._applyBlockBadge(badge, outcome, `— ${txt}`);
      };

      btnOk.addEventListener("click", async () => {
        const isOk = expectedList.every((exp) => {
          return entries.some(
            (ent) => ent.keyId === exp.keyId && ent.char === exp.char && String(ent.fingerId) === exp.fingerId,
          );
        });
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "homeRow", outcome, entries);
        revealHomeSolution(outcome);
      });

      btnCons.addEventListener("click", async () => {
        await this._recordBlock(item, "homeRow", "consulted", null);
        revealHomeSolution("consulted");
      });

      panelEl.appendChild(card);
    }

    _openAsciiPopover(anchorEl, options, onSelect) {
      const pop = document.getElementById("interrAsciiPopover");
      const body = document.getElementById("interrAsciiPopoverBody");
      const dialog = document.getElementById("interrogationDialog");
      if (!pop || !body) return;

      const opts = options || {};
      const meta = global.InterrogationLayoutMetadata;
      body.innerHTML = "";

      if (opts.includeNone) {
        const noneBtn = createEl("button", "btn btn-sm interr-ascii-btn interr-ascii-none", "NONE");
        noneBtn.type = "button";
        noneBtn.addEventListener("click", () => {
          this._closeAsciiPopover();
          onSelect("NONE");
        });
        body.appendChild(noneBtn);
      }

      if (opts.includeSpecial && meta) {
        const specWrap = createEl("div", "interr-ascii-special-row");
        meta.SPECIAL_PICKER_KEYS.forEach((sk) => {
          const b = createEl("button", "btn btn-sm interr-ascii-btn interr-ascii-special", sk.label);
          b.type = "button";
          b.addEventListener("click", () => {
            this._closeAsciiPopover();
            onSelect(sk.label);
          });
          specWrap.appendChild(b);
        });
        body.appendChild(specWrap);
      }

      const charsWrap = createEl("div", "interr-ascii-grid");
      const chars = (meta && meta.ASCII_CHARACTERS) || [];
      chars.forEach((ch) => {
        const b = createEl("button", "btn btn-sm interr-ascii-btn", ch);
        b.type = "button";
        b.title = `ASCII ${ch.charCodeAt(0)}`;
        b.addEventListener("click", () => {
          this._closeAsciiPopover();
          onSelect(ch);
        });
        charsWrap.appendChild(b);
      });
      body.appendChild(charsWrap);

      pop.classList.remove("is-hidden");

      // Posiziona accanto all'anchor senza usare style inline (usa offset/classi o coordinate solo se necessario)
      if (anchorEl && dialog) {
        pop.classList.add("is-positioned");
      }
    }

    _closeAsciiPopover() {
      const pop = document.getElementById("interrAsciiPopover");
      if (pop) pop.classList.add("is-hidden");
    }

    async handleFinishMainQuestion() {
      const item = this.activeItems[this.currentItemIdx];
      if (!item || !this.activeSession) return;
      await this.sessionMgr.finishMainQuestion({
        profileId: this.getProfileId(),
        sessionId: this.activeSession.sessionId,
        itemId: item.itemId,
      });
      if (this.currentItemIdx < this.activeItems.length - 1) {
        this.currentItemIdx++;
        this._setFeedback("", "");
        this._renderRunView();
      }
    }

    async handleSuspend() {
      if (!this.activeSession) return;
      await this.sessionMgr.suspendSession(this.getProfileId(), this.activeSession.sessionId);
      this.activeSession = null;
      await this.showSetupView();
    }

    async handleAbandonActive() {
      if (!this.activeSession) return;
      await this.sessionMgr.abandonSession(this.getProfileId(), this.activeSession.sessionId);
      this.activeSession = null;
      await this.showSetupView();
    }

    async handleComplete() {
      if (!this.activeSession) return;
      const completed = await this.sessionMgr.completeSession(
        this.getProfileId(),
        this.activeSession.sessionId,
      );
      this.activeSession = completed;
      this.onSessionComplete(completed);
      this._renderSummaryView(completed);
    }

    _renderSummaryView(session) {
      this._switchView("summary");
      const sumScore = document.getElementById("interrogationSummaryScore");
      if (sumScore) {
        sumScore.textContent = `Punteggio finale: ${session.score} punti`;
      }

      const items = this.activeItems || [];
      let c = 0, cons = 0, inc = 0, unans = 0;
      items.forEach((it) => {
        const evals = Object.values(it.blockEvaluations || {});
        if (evals.length > 0) {
          evals.forEach((ev) => {
            if (ev.outcome === "correct") c++;
            else if (ev.outcome === "consulted") cons++;
            else if (ev.outcome === "incorrect") inc++;
          });
        } else {
          (it.subQuestions || []).forEach((sq) => {
            if (sq.outcome === "correct") c++;
            else if (sq.outcome === "consulted") cons++;
            else if (sq.outcome === "incorrect") inc++;
            else unans++;
          });
        }
      });

      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt("interrSumCorrect", c);
      setTxt("interrSumConsulted", cons);
      setTxt("interrSumIncorrect", inc);
      setTxt("interrSumUnanswered", unans);

      const notice = document.getElementById("interrSummaryStatsNotice");
      if (notice) {
        notice.textContent = `Punteggio (+${session.score} pt) salvato nelle statistiche del profilo.`;
      }
    }

    async showHistoryView() {
      this._switchView("history");
      this._historySelectedIds = new Set();
      await this._loadHistorySessions();
      this._renderHistoryChart();
    }

    async _loadHistorySessions() {
      const profileId = this.getProfileId();
      const all = await this.sessionMgr.repository.getSessionsByProfile(profileId);
      this._historyAllSessions = (all || [])
        .filter((s) => s.status === "completed")
        .sort((a, b) => (a.completedAt || a.createdAt || 0) - (b.completedAt || b.createdAt || 0));
    }

    _getFilteredHistorySessions() {
      const all = this._historyAllSessions || [];
      const fromVal = document.getElementById("interrHistDateFrom")?.value || "";
      const toVal = document.getElementById("interrHistDateTo")?.value || "";
      const fromMs = fromVal ? new Date(fromVal).getTime() : null;
      const toMs = toVal ? new Date(toVal).getTime() : null;
      return all.filter((s) => {
        const ts = s.completedAt || s.createdAt || 0;
        if (fromMs !== null && !Number.isNaN(fromMs) && ts < fromMs) return false;
        if (toMs !== null && !Number.isNaN(toMs) && ts > toMs) return false;
        return true;
      });
    }

    _formatDateTimeIT(ts) {
      const d = new Date(ts || Date.now());
      const dd = String(d.getDate()).padStart(2, "0");
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const yyyy = d.getFullYear();
      const hh = String(d.getHours()).padStart(2, "0");
      const min = String(d.getMinutes()).padStart(2, "0");
      return { dateStr: `${dd}/${mm}/${yyyy}`, timeStr: `${hh}:${min}`, full: `${dd}/${mm}/${yyyy} ${hh}:${min}` };
    }

    _renderHistoryChart() {
      const host = document.getElementById("interrHistoryChartHost");
      const detailBox = document.getElementById("interrHistoryDetailBox");
      if (!host) return;
      host.innerHTML = "";

      const samples = this._getFilteredHistorySessions();
      if (!this._historySelectedIds) this._historySelectedIds = new Set();

      if (samples.length === 0) {
        host.appendChild(createEl("div", "interr-history-empty", "Nessuna interrogazione completata trovata nell'intervallo selezionato."));
        if (detailBox) detailBox.textContent = "Nessun campione disponibile.";
        return;
      }

      const W = 820;
      const H = 260;
      const padL = 56;
      const padR = 26;
      const padT = 22;
      const padB = 42;
      const plotW = W - padL - padR;
      const plotH = H - padT - padB;

      const scores = samples.map((s) => Number(s.score || 0));
      const minY = Math.min(0, ...scores);
      const maxY = Math.max(10, ...scores);
      const spanY = maxY - minY || 1;

      const times = samples.map((s) => Number(s.completedAt || s.createdAt || 0));
      let minT = Math.min(...times);
      let maxT = Math.max(...times);
      if (minT === maxT) {
        minT -= 60000;
        maxT += 60000;
      }
      const spanT = maxT - minT;

      const svgNS = "http://www.w3.org/2000/svg";
      const svgEl = (tag, attrs) => {
        const el = document.createElementNS(svgNS, tag);
        Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, String(v)));
        return el;
      };

      const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, class: "interr-history-svg" });

      // Griglia orizzontale e asse Y
      const ticks = 4;
      for (let i = 0; i <= ticks; i++) {
        const ratio = i / ticks;
        const yVal = Math.round(maxY - ratio * spanY);
        const yPos = padT + ratio * plotH;
        svg.appendChild(svgEl("line", { x1: padL, y1: yPos, x2: W - padR, y2: yPos, stroke: "#334155", "stroke-width": 1 }));
        const lbl = svgEl("text", { x: padL - 8, y: yPos + 4, "text-anchor": "end", fill: "#94a3b8", "font-size": 11 });
        lbl.textContent = String(yVal);
        svg.appendChild(lbl);
      }

      // Assi principali
      svg.appendChild(svgEl("line", { x1: padL, y1: padT, x2: padL, y2: H - padB, stroke: "#64748b", "stroke-width": 1.5 }));
      svg.appendChild(svgEl("line", { x1: padL, y1: H - padB, x2: W - padR, y2: H - padB, stroke: "#64748b", "stroke-width": 1.5 }));

      // Calcola punti
      const points = samples.map((s) => {
        const t = Number(s.completedAt || s.createdAt || 0);
        const sc = Number(s.score || 0);
        const x = padL + ((t - minT) / spanT) * plotW;
        const y = padT + ((maxY - sc) / spanY) * plotH;
        return { session: s, x, y, t, sc, fmt: this._formatDateTimeIT(t) };
      });

      // Spezzata
      if (points.length > 1) {
        const polyPts = points.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
        svg.appendChild(svgEl("polyline", { points: polyPts, fill: "none", stroke: "#3b82f6", "stroke-width": 2.5 }));
      }

      // Crosshair: linea orizzontale tratteggiata ROSSA + valore in ordinata
      const hLine = svgEl("line", {
        x1: padL, y1: padT, x2: W - padR, y2: padT,
        stroke: "#ef4444", "stroke-width": 1.5, "stroke-dasharray": "5 4", display: "none",
      });
      const hLabel = svgEl("text", {
        x: padL - 6, y: padT, "text-anchor": "end", fill: "#ef4444", "font-size": 11, "font-weight": "700", display: "none",
      });

      // Crosshair: linea verticale tratteggiata VERDE + data-ora campione più prossimo
      const vLine = svgEl("line", {
        x1: padL, y1: padT, x2: padL, y2: H - padB,
        stroke: "#22c55e", "stroke-width": 1.5, "stroke-dasharray": "5 4", display: "none",
      });
      const vLabel = svgEl("text", {
        x: padL, y: H - padB + 16, "text-anchor": "middle", fill: "#22c55e", "font-size": 11, "font-weight": "700", display: "none",
      });

      svg.appendChild(hLine);
      svg.appendChild(vLine);
      svg.appendChild(hLabel);
      svg.appendChild(vLabel);

      const updateDetailBox = (pt, prefix) => {
        if (!detailBox || !pt) return;
        const selMark = this._historySelectedIds.has(pt.session.sessionId) ? " [SELEZIONATO]" : "";
        detailBox.textContent = `${prefix} Data: ${pt.fmt.dateStr} | Ora: ${pt.fmt.timeStr} | Punteggio: ${pt.sc} pt${selMark}`;
      };

      // Cerchi cliccabili per ogni campione
      points.forEach((pt) => {
        const isSel = this._historySelectedIds.has(pt.session.sessionId);
        const circle = svgEl("circle", {
          cx: pt.x.toFixed(1),
          cy: pt.y.toFixed(1),
          r: isSel ? 7.5 : 5.5,
          fill: isSel ? "#f59e0b" : "#3b82f6",
          stroke: "#ffffff",
          "stroke-width": 1.8,
          class: "interr-history-point",
        });
        circle.addEventListener("click", (e) => {
          e.stopPropagation();
          if (this._historySelectedIds.has(pt.session.sessionId)) {
            this._historySelectedIds.delete(pt.session.sessionId);
          } else {
            this._historySelectedIds.add(pt.session.sessionId);
          }
          updateDetailBox(pt, "Campione:");
          this._renderHistoryChart();
        });
        svg.appendChild(circle);
      });

      svg.addEventListener("mousemove", (e) => {
        const rect = svg.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        const rawX = ((e.clientX - rect.left) / rect.width) * W;
        const rawY = ((e.clientY - rect.top) / rect.height) * H;
        const cx = Math.max(padL, Math.min(W - padR, rawX));
        const cy = Math.max(padT, Math.min(H - padB, rawY));

        // Linea orizzontale rossa + valore Y
        const yVal = Math.round(maxY - ((cy - padT) / plotH) * spanY);
        hLine.setAttribute("y1", cy.toFixed(1));
        hLine.setAttribute("y2", cy.toFixed(1));
        hLine.setAttribute("display", "inline");
        hLabel.setAttribute("y", (cy + 4).toFixed(1));
        hLabel.textContent = String(yVal);
        hLabel.setAttribute("display", "inline");

        // Campione più prossimo orizzontalmente -> linea verticale verde + data-ora
        let nearest = points[0];
        let bestDist = Math.abs(points[0].x - cx);
        for (let i = 1; i < points.length; i++) {
          const d = Math.abs(points[i].x - cx);
          if (d < bestDist) {
            bestDist = d;
            nearest = points[i];
          }
        }
        vLine.setAttribute("x1", nearest.x.toFixed(1));
        vLine.setAttribute("x2", nearest.x.toFixed(1));
        vLine.setAttribute("display", "inline");
        const clampedLblX = Math.max(padL + 45, Math.min(W - padR - 45, nearest.x));
        vLabel.setAttribute("x", clampedLblX.toFixed(1));
        vLabel.textContent = nearest.fmt.full;
        vLabel.setAttribute("display", "inline");

        updateDetailBox(nearest, "Campione prossimo:");
      });

      svg.addEventListener("mouseleave", () => {
        hLine.setAttribute("display", "none");
        hLabel.setAttribute("display", "none");
        vLine.setAttribute("display", "none");
        vLabel.setAttribute("display", "none");
      });

      host.appendChild(svg);
    }

    async _deleteHistorySamples(mode) {
      const profileId = this.getProfileId();
      const filtered = this._getFilteredHistorySessions();
      const selectedIds = this._historySelectedIds || new Set();
      let idsToDelete = [];

      if (mode === "selected") {
        idsToDelete = filtered
          .filter((s) => selectedIds.has(s.sessionId))
          .map((s) => s.sessionId);
      } else if (mode === "excluded") {
        if (selectedIds.size > 0) {
          idsToDelete = filtered
            .filter((s) => !selectedIds.has(s.sessionId))
            .map((s) => s.sessionId);
        } else {
          const visibleSet = new Set(filtered.map((s) => s.sessionId));
          idsToDelete = (this._historyAllSessions || [])
            .filter((s) => !visibleSet.has(s.sessionId))
            .map((s) => s.sessionId);
        }
      }

      if (idsToDelete.length === 0) return;
      await this.sessionMgr.repository.deleteSessions(profileId, idsToDelete);
      this._historySelectedIds.clear();
      await this._loadHistorySessions();
      this._renderHistoryChart();
    }
  }

  global.InterrogationUI = InterrogationUI;
})(typeof window !== "undefined" ? window : globalThis);
