# Cubo di Rubik (3x3) Resources

## Knowledge

- [J Perm: 3x3 Beginner Tutorial](https://jperm.net/3x3)
  Guida di riferimento standard per il metodo a strati per principianti, con spiegazioni chiare degli algoritmi fondamentali. Da usare per: sequenze di mosse e transizione logica tra gli strati.
- [Ruwix: Guida al Metodo a Strati per Principianti](https://ruwix.com/)
  Enciclopedia completa dei twisty puzzles con scomposizione passo-passo della risoluzione. Da usare per: diagrammi visivi e schemi di rotazione.
- [Online 3D Rubik's Cube Simulator (OnlineCube.com)](https://onlinecube.com/)
  Simulatore virtuale 3D interattivo con rotazioni da tastiera e trascinamento mouse. Da usare per: fare pratica pratica in assenza di un cubo fisico.

## Wisdom (Communities)

- [r/Cubers (Reddit)](https://reddit.com/r/Cubers)
  La più grande community globale di appassionati del cubo di Rubik. Da usare per: chiarimenti su dubbi specifici, raccomandazioni sui cubi da acquistare e troubleshooting.
- [World Cube Association (WCA)](https://www.worldcubeassociation.org/)
  Organo ufficiale delle competizioni e regolamento internazionale dei puzzle. Da usare per: notazione standard ufficiale e standardizzazione dei movimenti.
