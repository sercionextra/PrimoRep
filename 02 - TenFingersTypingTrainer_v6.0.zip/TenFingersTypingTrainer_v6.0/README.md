# TenFingersTypingTrainer v6.0

Release di refactoring browser-first, costruita sui sorgenti v5.1 del 27/10/2026.

## Avvio

Aprire `index.html` in un browser moderno. L'applicazione non richiede Node.js, server applicativi, pacchetti npm o servizi remoti per il normale funzionamento. Alcune API del browser (per esempio sintesi vocale e import/export file) dipendono dal supporto del browser e dai permessi disponibili.

## Struttura

- `index.html`: interfaccia principale e ordine di caricamento dei componenti.
- `assets/styles/app.css`: foglio di stile estratto dall'interfaccia originale.
- `js/data/`: dataset didattico, profilo demo, testo Custom predefinito e corpus fonemico.
- `js/domain/`: helper puri, mappature della tastiera, landmark anatomici e logica di dominio.
- `js/engines/`: motori audio, digitazione e dettatura.
- `js/profiles/`: profili e persistenza browser.
- `js/ui/`: finestre e rendering visivo.
- `js/analytics/`: statistiche e grafici.
- `js/app/`: coordinamento dell'applicazione, metodi del controller suddivisi per responsabilità e avvio.
- `js/shared/`: utilità condivise.
- `docs/`: manuale e specifica comportamentale di riferimento.
- `tests/`: controlli di regressione eseguibili e checklist manuale.

## Compatibilità e strategia architetturale

Per minimizzare il rischio di regressioni, i componenti JavaScript sono separati in file per responsabilità ma mantengono in questa release il modello di caricamento classico e ordinato. Questo conserva le binding globali condivise dai sorgenti storici e permette l'apertura diretta come sito statico. La migrazione a moduli ES/TypeScript deve avvenire per dipendenze esplicite e con test di equivalenza, non tramite una conversione automatica che possa cambiare il comportamento.

## Metodo didattico

La filosofia del trainer resta invariata: precisione prima della velocità, ritorno alla posizione di riposo, apprendimento progressivo, uso delle modalità didattiche originali e feedback degli errori. Le lezioni, il corpus fonemico, il profilo demo e il formato degli esercizi Custom sono conservati nel codice sorgente estratto.

## Persistenza

La versione originale usa Local Storage con le chiavi TFTT esistenti. Questa release conserva tali chiavi e il modello dati: non effettua migrazioni distruttive e non richiede di cancellare i dati del browser. Prima di distribuire aggiornamenti successivi, verificare sempre importazione/esportazione e compatibilità dei profili.

## Verifiche

Con Node.js installato, dalla cartella del progetto eseguire `node tests/static-check.js` e `node tests/runtime-smoke.js`. Il primo controlla la presenza e il collegamento degli asset; il secondo carica in un contesto JavaScript simulato i componenti nell’ordine previsto e verifica i dataset e i contratti essenziali. Consultare inoltre `tests/REGRESSION_CHECKLIST.md`: i test automatici non sostituiscono la verifica completa nel browser di tutte le interazioni e dei dati persistenti.
