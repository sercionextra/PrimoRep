/* Test v6.27: Metadati margherita, estensioni (INVIO 3 dx), equivalenza AltGr/CTRL+ALT, ASCII picker e recordBlockEvaluation. */
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function loadIntoContext(ctx, relPath) {
  const code = fs.readFileSync(path.join(root, relPath), "utf8");
  vm.runInContext(code, ctx, { filename: relPath });
}

const sandbox = {
  console,
  Math,
  Date,
  Map,
  Set,
  Array,
  Object,
  String,
  Number,
  Boolean,
  JSON,
  Error,
  Promise,
  TextEncoder,
  TextDecoder,
  Uint8Array,
  crypto: require("crypto").webcrypto,
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

loadIntoContext(sandbox, "js/data/interrogation-catalog-data.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-prng.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-layout-metadata.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-catalog.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-knowledge.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-selector.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-repository.js");
loadIntoContext(sandbox, "js/interrogation/interrogation-session-manager.js");

const meta = sandbox.InterrogationLayoutMetadata;
assert(meta, "InterrogationLayoutMetadata non caricato");

// 1. Margherita su tasto centrale (key_g) e bordo (key_1)
const gNeigh = meta.getNeighbors("key_g");
assert.strictEqual(gNeigh.topLeft, "key_t");
assert.strictEqual(gNeigh.topRight, "key_y");
assert.strictEqual(gNeigh.left, "key_f");
assert.strictEqual(gNeigh.right, "key_h");
assert.strictEqual(gNeigh.bottomLeft, "key_v");
assert.strictEqual(gNeigh.bottomRight, "key_b");

const k1Neigh = meta.getNeighbors("key_1");
assert.strictEqual(k1Neigh.topLeft, null);
assert.strictEqual(k1Neigh.topRight, null);
assert.strictEqual(meta.getKeyDisplayToken(k1Neigh.topLeft), "NONE");

// 2. Estensioni laterali e longitudinali (INVIO = 3 dx)
const enterExt = meta.getKeyExtension("key_enter");
assert.strictEqual(enterExt.lateralExt, 3);
assert.strictEqual(enterExt.lateralDir, "dx");

const fExt = meta.getKeyExtension("key_f");
assert.strictEqual(fExt.longitudinalExt, 0);
assert.strictEqual(fExt.lateralExt, 0);
assert.strictEqual(fExt.lateralDir, "none");

const qExt = meta.getKeyExtension("key_q");
assert.strictEqual(qExt.longitudinalExt, 1);

const zExt = meta.getKeyExtension("key_z");
assert.strictEqual(zExt.longitudinalExt, -1);

// 3. Equivalenza AltGr <-> CTRL + ALT
assert.strictEqual(meta.isModifierMatch("altgr", { altgr: true, ctrl: false, alt: false, shift: false }), true);
assert.strictEqual(meta.isModifierMatch("altgr", { altgr: false, ctrl: true, alt: true, shift: false }), true);
assert.strictEqual(meta.isModifierMatch("altgr", { altgr: false, ctrl: true, alt: false, shift: false }), false);
assert.strictEqual(meta.isModifierMatch("shiftAltgr", { altgr: true, ctrl: false, alt: false, shift: true }), true);
assert.strictEqual(meta.isModifierMatch("shiftAltgr", { altgr: false, ctrl: true, alt: true, shift: true }), true);

// 4. ASCII ordinati
for (let i = 1; i < meta.ASCII_CHARACTERS.length; i++) {
  assert(
    meta.ASCII_CHARACTERS[i - 1].charCodeAt(0) < meta.ASCII_CHARACTERS[i].charCodeAt(0),
    "ASCII_CHARACTERS non ordinati strettamente",
  );
}

// 5. recordBlockEvaluation (+3, +1, 0)
(async () => {
  const catalog = new sandbox.InterrogationCatalog();
  const repo = new sandbox.InterrogationRepository({ useMemory: true });
  const mgr = new sandbox.InterrogationSessionManager({ catalog, repository: repo });

  const created = await mgr.createSession({
    profileId: "test_v627",
    mode: "random",
    questionTypes: ["CARATTERE"],
    requestedCount: 1,
    seed: "0123456789abcdef0123456789abcdef",
  });
  const item = created.items[0];

  const r1 = await mgr.recordBlockEvaluation({
    profileId: "test_v627",
    sessionId: created.session.sessionId,
    itemId: item.itemId,
    blockId: "accord",
    outcome: "correct",
  });
  assert.strictEqual(r1.score, 3);
  assert.strictEqual(r1.sessionScore, 3);

  const r2 = await mgr.recordBlockEvaluation({
    profileId: "test_v627",
    sessionId: created.session.sessionId,
    itemId: item.itemId,
    blockId: "keyChars",
    outcome: "consulted",
  });
  assert.strictEqual(r2.score, 1);
  assert.strictEqual(r2.sessionScore, 4);

  const r3 = await mgr.recordBlockEvaluation({
    profileId: "test_v627",
    sessionId: created.session.sessionId,
    itemId: item.itemId,
    blockId: "neighbors_top",
    outcome: "incorrect",
  });
  assert.strictEqual(r3.score, 0);
  assert.strictEqual(r3.sessionScore, 4);

  console.log("PASS: Interrogation v6.27 (margherita, estensioni, AltGr<->CTRL+ALT, ASCII, recordBlockEvaluation).");
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
