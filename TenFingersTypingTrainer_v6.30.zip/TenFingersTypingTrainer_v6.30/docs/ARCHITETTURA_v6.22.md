# Architettura — TenFingersTypingTrainer v6.22

## Obiettivo

La release v6.22 introduce miglioramenti ergonimici e strutturali all'interfaccia utente (UI) e al gestore delle finestre (`WindowManager`), focalizzandosi su quattro direttrici principali:
1. **Uniformazione dello stile dei pulsanti di chiusura ("x")**: standardizzazione grafica a 26 pixel con effetto visivo al passaggio del mouse su tutte le finestre modali e fluttuanti;
2. **Evidenziazione primaria coerente dei comandi di testata**: allineamento visivo (`btn btn-primary`) dei pulsanti "Utenti", "Guida (Help)", "⚙ Config." ed "Editor Custom" con il pulsante "Statistiche";
3. **Ottimizzazione della didascalia (caption) del pulsante di configurazione**: passaggio da "⚙ Dettatura" a "⚙ Config.", conservando il tooltip descrittivo completo;
4. **Gestione dinamica dello stack z-index (Ordinamento finestre in primo piano)**: implementazione di un modello a due fasce con incremento continuo ad ogni interazione (click, trascinamento, apertura), garantendo che l'ultima finestra o modale trattata si posizioni sempre al livello più alto.

---

## Dettaglio dei Requisiti e Soluzioni Architetturali

### 1. Gestione Dinamica dello Stack z-index (`WindowManager`)

Nelle versioni precedenti:
* Le finestre fluttuanti avevano uno z-index statico o reimpostato a quota 1000 al rilascio del mouse (`mouseup`);
* Il tachimetro fluttuante della velocità istantanea aveva uno z-index statico pari a 1010, rischiando di sovrapporsi in modo rigido ad altre finestre anche quando l'utente interagiva con queste ultime;
* Le finestre modali condividevano una quota fissa (2000), senza una gestione automatica dell'ordine relativo qualora venissero richiamate modali secondarie (es. inserimento titolo lezioni custom, risoluzione conflitti importazione profili).

Nella release v6.22, la classe `WindowManager` (`js/ui/window-manager.js`) è stata estesa con:
* Due contatori dinamici interni:
  * `this.highestZIndex = 1000`: gestisce la fascia delle finestre fluttuanti (Mani, Statistiche, Editor Custom, Velocità Istantanea);
  * `this.highestModalZIndex = 2000`: gestisce la fascia delle finestre modali (Login Utenti, Selezione Frasi, Parametri Velocità Istantanea, Configurazione Dettatura, Navigazione Lezione, Scorciatoie Zoom, Inserimento Titolo Custom, Conflitto Import).
* Due metodi centralizzati:
  * `bringToFront(windowElem)`: incrementa `highestZIndex` e lo assegna alla proprietà `windowElem.style.zIndex`;
  * `bringModalToFront(modalElem)`: incrementa `highestModalZIndex` e lo assegna alla proprietà `modalElem.style.zIndex`.
* Aggancio listener per interazione:
  * Nella funzione `makeDraggable(windowElem, headerElem)`: registrato l'evento `mousedown` su `windowElem` (e sul relativo header/resize-handle) in modo che qualsiasi click all'interno della finestra porti immediatamente la finestra in primo piano;
  * Al termine del trascinamento o ridimensionamento (`mouseup`), la finestra mantiene la quota acquisita senza essere declassata a 1000;
  * In `initGlobalEvents()`: registrato l'evento `mousedown` su tutti gli elementi con classe `.modal-overlay` per portare in cima la modale cliccata.

La rigida separazione tra fascia fluttuante (da quota 1001 in su) e fascia modale (da quota 2001 in su) assicura che nessuna finestra fluttuante possa mai coprire una finestra di dialogo modale attiva.

### 2. Evidenziazione Primaria Coordinata dei Pulsanti di Testata

Per conferire uniformità visiva e risalto ai comandi operativi principali dell'applicazione, è stata estesa la classe di stile `btn btn-primary` (sfondo blu istituzionale con contrasto ottimizzato):
* `#btnHeaderSwitchUser` ("👤 Utenti"): evidenziazione primaria;
* `#btnHelpLink` ("❓ Guida (Help)"): evidenziazione primaria;
* `#btnDictationConfig` ("⚙ Config."): evidenziazione primaria;
* `#btnOpenCustomEditor` ("📝 Editor Custom"): evidenziazione primaria;
* `#btnOpenStats` ("📊 Statistiche"): classe `btn btn-primary` confermata.

### 3. Rinominazione del Pulsante "⚙ Dettatura" in "⚙ Config."

* La caption del pulsante `#btnDictationConfig` è stata aggiornata da `⚙ Dettatura` a `⚙ Config.`, garantendo maggiore compattezza nella barra controlli senza sacrificare la chiarezza;
* Il tooltip informativo (`title`) è stato preservato: `"Configurazione avanzata Dettatura Adattiva Dinamica (Soglie velocità & ripresa ritmo)"`.

### 4. Uniformazione dei Pulsanti di Chiusura ("x") delle Finestre Modali

Precedentemente, i pulsanti di chiusura presentavano stili disomogenei:
* In `app.css` le regole erano vincolate a selettori a catena specifici (es. `.floating-window-close.hands-close-btn`), lasciando modali come `#dictationConfigModal` e `#zoomHelpModal` con stili generici;
* La modale di navigazione `#lessonNavModal` utilizzava proprietà CSS inline con bordo e sfondo assenti.

Nella v6.22:
* In `assets/styles/app.css`: la regola `.floating-window-close`, `.modal-header .floating-window-close`, `.modal-header .modal-close-btn` è stata generalizzata, garantendo altezza di 26 pixel, bordo coerente con il tema (`--border-color`), sfondo superficiale (`--surface-color`) e transizione al colore di pericolo/errore (`--error-color`) al passaggio del cursore (`:hover`);
* Nel file `index.html`: sono state applicate in modo uniforme le classi `floating-window-close` e rimossi gli stili inline non conformi da tutti i pulsanti di chiusura (`#btnCloseDictationConfigModal`, `#btnCloseZoomHelpModal`, `#btnCloseLessonNavModal`).

---

## Mappa dei File Modificati (Release v6.22)

1. `assets/styles/app.css`:
   * Centralizzazione delle regole CSS per `.floating-window-close`, `.modal-header .floating-window-close` e `.modal-header .modal-close-btn` con altezza 26px e hover ad alta visibilità.
2. `index.html`:
   * Aggiornamento numero di versione a v6.22 in titolo e badge testata;
   * Aggiunta della classe `btn-primary` a `#btnHeaderSwitchUser`, `#btnHelpLink`, `#btnOpenCustomEditor`, `#btnDictationConfig`;
   * Modifica della caption di `#btnDictationConfig` in `⚙ Config.`;
   * Uniformazione dei pulsanti di chiusura con classe `floating-window-close`.
3. `js/ui/window-manager.js`:
   * Aggiunta dei contatori `highestZIndex` (1000) e `highestModalZIndex` (2000);
   * Implementazione dei metodi `bringToFront(windowElem)` e `bringModalToFront(modalElem)`;
   * Gestione dell'evento `mousedown` su finestre e modali per portarle in primo piano al tocco.
4. `js/app/controller/controller-core.js`:
   * Aggiornamento versione runtime a `6.22`.
5. `js/profiles/profile-manager.js`:
   * Aggiornamento `AppVersion` a `6.22` in `demoProf` e in `saveProfile()`.
6. `js/app/controller/metodi-finestre-layout.js`:
   * Invocazione di `bringToFront` all'apertura delle finestre fluttuanti (Mani, Statistiche, Velocità Istantanea) e `bringModalToFront` per le finestre modali.
7. `js/app/controller/metodi-scorciatoie-editor-custom.js`:
   * Invocazione di `bringToFront` per l'Editor Custom e `bringModalToFront` per la modale del titolo.
8. `js/app/controller/metodi-dettatura.js`:
   * Invocazione di `bringModalToFront` per la modale di configurazione dettatura.
9. `js/app/controller/metodi-fonemi-dropdown.js`:
   * Invocazione di `bringModalToFront` per la modale dei fonemi.
10. `js/app/controller/metodi-profili-modali.js`:
    * Invocazione di `bringModalToFront` per le modali login, scelta frase, conflitto importazione e parametri velocità istantanea.
11. `js/app/controller/metodi-navigazione-dialoghi.js`:
    * Invocazione di `bringModalToFront` per gli avvisi e conferme della navigazione lezioni.
12. `tests/test-window-stacking.js`:
    * Nuova suite automatizzata di test per la validazione dello stacking z-index dinamico, classi dei pulsanti e uniformità CSS.
