#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const metodiInterr = fs.readFileSync(path.join(root, "js/app/controller/metodi-interrogazione.js"), "utf8");
const uiJs = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

// 1. Verifica collegamento toast come Zoom-in / Zoom-out
assert(metodiInterr.includes("this.showNotificationToast(msg, icon)"), "metodi-interrogazione.js deve collegare showToast a showNotificationToast");
assert(uiJs.includes('Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova.'), "Messaggio esatto per sessione sospesa mancante in interrogation-ui.js");
assert(uiJs.includes("this.showToast(msg,"), "handleStartSession / _startRepeatSession devono invocare this.showToast");

// 2. Verifica richiamo target nella barra del titolo del popover caratteri
assert(html.includes('id="interrAsciiPopoverTarget"'), "Elemento #interrAsciiPopoverTarget mancante in index.html");
assert(css.includes("#interrAsciiPopoverTarget"), "Regola CSS #interrAsciiPopoverTarget mancante in app.css");
assert(uiJs.includes('document.getElementById("interrAsciiPopoverTarget")'), "_openAsciiPopover deve valorizzare #interrAsciiPopoverTarget");

console.log("PASS: Tutte le verifiche v6.39 superate.");
