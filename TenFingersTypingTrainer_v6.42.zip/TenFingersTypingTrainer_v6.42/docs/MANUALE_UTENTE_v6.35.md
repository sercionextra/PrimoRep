# Manuale Utente — Aggiornamento v6.35

## Novità della versione v6.35

1. **Tastiera B/N dell'Interrogazione senza indizi visivi:**
   - Nella modalità Interrogazione, la tastiera in bianco e nero non mostra più i punti azzurri della posizione di riposo sui tasti `[a, s, d, f]` e `[j, k, l, ò]` né i trattini tattili di riferimento sui tasti `f` e `j`.

2. **Titolo domanda e obiettivo evidenziati:**
   - L'elemento principale richiesto dalla domanda (carattere, tasto, dito o mano in posizione di riposo) è ora chiaramente evidenziato in giallo nel titolo della domanda.

3. **Interrogazione "Posizione di Riposo" migliorata:**
   - In ogni riga, il pulsante **Seleziona tasto #x su tastiera** si trova ora come ultimo controllo, dopo **Carattere...** e **Dito...**.
   - Ogni riga ha un colore dedicato: cliccando il tasto corrispondente sulla tastiera B/N, il tasto si illumina con lo stesso colore della riga.
   - Una volta scelto il tasto, il pulsante non mostra più tra parentesi il carattere del tasto per non fornire suggerimenti sulla risposta.

4. **Finestra "Seleziona carattere / tasto" più chiara e ordinata:**
   - Caratteri e tasti speciali sono ora organizzati in righe ordinate per tipologia (maiuscole, minuscole, accentate, numeri, operatori/parentesi, simboli, punteggiatura, tasti speciali).
   - Il pulsante **NESSUNO** è disponibile sia in cima che in fondo alla finestra.
   - Il titolo della finestra indica sempre lo scopo della scelta corrente (es. *Tasto a sinistra*, *Tasto a destra*).
   - Per **Coppia sopra** e **Coppia sotto** è presente un unico pulsante **Scegli...**: la finestra resta aperta per consentire di scegliere in ordine prima il 1° tasto (a sinistra) e poi il 2° tasto (a destra), guidati da un messaggio chiaro, prima di chiudersi automaticamente.
