# Architettura & Note Tecniche — Release v6.38

## Ottimizzazione larghezza e centramento finestra "Seleziona carattere / tasto"
- **`assets/styles/app.css`**:
  - Ridotta la larghezza di `.interr-ascii-popover` da `min(880px, 96vw)` a `min(780px, 96vw)` (circa 100px in meno), sufficiente a contenere tutte le 26 lettere su una singola riga.
  - Aggiunto `justify-content: center;` a `.interr-ascii-row` e `align-self: center;` a `.interr-ascii-none` per centrare orizzontalmente tutte le righe dei tasti e i pulsanti `NESSUNO`.
- **`js/ui/interrogation-ui.js`**: in `_openAsciiPopover()` aggiornato il fallback `popW` a `Math.min(780, Math.round(vpW * 0.96))`.
