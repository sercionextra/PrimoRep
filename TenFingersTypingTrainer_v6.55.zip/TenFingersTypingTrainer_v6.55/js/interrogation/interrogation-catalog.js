/* TenFingersTypingTrainer v6.25 | interrogation-catalog.js | Gestione e validazione del catalogo statico Interrogazione (52 tasti, 111 mapping, 445 definizioni, 225 candidate). */
(function (global) {
  "use strict";

  class InterrogationCatalog {
    constructor(rawData) {
      const source = rawData || global.INTERROGATION_CATALOG_DATA;
      if (!source || !source.seed || !source.questions || !source.candidates) {
        throw new Error("INTERROGATION_CATALOG_DATA mancante o incompleto.");
      }

      this.seed = source.seed;
      this.questions = source.questions;
      this.candidatesData = source.candidates;

      this.catalogVersion = String(this.candidatesData.catalogVersion || "1.0");
      this.layoutId = String(this.candidatesData.layoutId || "it-qwerty-105");

      this.physicalKeysById = new Map();
      this.physicalKeysBySemanticId = new Map();
      this.charMappingsBySemanticId = new Map();
      this.definitionsBySemanticId = new Map();
      this.templatesBySemanticId = new Map();
      this.candidatesById = new Map();
      this.candidatesList = [];

      this._indexAndValidate();
    }

    _indexAndValidate() {
      const keys = this.seed.physicalKeys || [];
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        this.physicalKeysById.set(k.keyId, k);
        const semId = k.semanticId || k.elementSemanticId;
        if (semId) {
          this.physicalKeysBySemanticId.set(semId, k);
        }
      }

      const mappings = this.seed.characterMappings || [];
      for (let i = 0; i < mappings.length; i++) {
        const m = mappings[i];
        const semId = m.semanticId || m.elementSemanticId;
        if (semId) {
          this.charMappingsBySemanticId.set(semId, m);
        }
      }

      const defs = this.questions.questionDefinitions || [];
      for (let i = 0; i < defs.length; i++) {
        const d = defs[i];
        if (d.status === "active") {
          this.definitionsBySemanticId.set(d.questionSemanticId, d);
        }
      }

      const templates = this.questions.mainQuestionTemplates || [];
      for (let i = 0; i < templates.length; i++) {
        const t = templates[i];
        const tid = t.templateId || t.templateSemanticId;
        if (tid && (!t.status || t.status === "active")) {
          this.templatesBySemanticId.set(tid, t);
        }
      }

      const rawCandidates = this.candidatesData.candidates || [];
      for (let i = 0; i < rawCandidates.length; i++) {
        const c = rawCandidates[i];
        if (!c || !c.candidateId || this.candidatesById.has(c.candidateId)) {
          throw new Error(`Candidate duplicato o non valido: ${c && c.candidateId}`);
        }
        const tplId = c.templateId || c.templateSemanticId;
        if (!this.templatesBySemanticId.has(tplId)) {
          throw new Error(`Template mancante o inattivo: ${tplId}`);
        }
        const subQuestions = [];
        const qIds = c.questionSemanticIds || [];
        for (let j = 0; j < qIds.length; j++) {
          const def = this.definitionsBySemanticId.get(qIds[j]);
          if (!def) {
            throw new Error(`Definizione mancante o inattiva: ${qIds[j]}`);
          }
          subQuestions.push(def);
        }

        const mainElemId =
          c.mainElementSemanticId ||
          (Array.isArray(c.elementSemanticIds) && c.elementSemanticIds[0]) ||
          null;
        const elems = Array.isArray(c.elementSemanticIds) ? c.elementSemanticIds : [];

        let resolvedKeyId = c.keyId || null;
        let resolvedChar = c.character !== undefined ? c.character : null;
        let resolvedMod = c.modifierMode || null;
        let resolvedFinger = c.fingerId || null;
        let resolvedHand = c.handId || null;

        const charSem = elems.find((e) => String(e).startsWith("char.")) || (String(mainElemId || "").startsWith("char.") ? mainElemId : null);
        if (charSem) {
          const mapping = this.charMappingsBySemanticId.get(charSem);
          if (mapping) {
            if (resolvedChar === null) resolvedChar = mapping.value;
            if (!resolvedMod) resolvedMod = mapping.modifier || "none";
            if (!resolvedFinger && mapping.assignedFinger) resolvedFinger = String(mapping.assignedFinger);
            if (!resolvedKeyId && mapping.physicalKeySemanticId) {
              resolvedKeyId = String(mapping.physicalKeySemanticId).replace(/^key\./, "");
            }
          }
        }

        const keySem = elems.find((e) => String(e).startsWith("key.")) || (String(mainElemId || "").startsWith("key.") ? mainElemId : null);
        if (keySem) {
          if (!resolvedKeyId) resolvedKeyId = String(keySem).replace(/^key\./, "");
          const pk = this.physicalKeysBySemanticId.get(keySem) || this.physicalKeysById.get(resolvedKeyId);
          if (pk && !resolvedFinger && pk.assignedFinger) {
            resolvedFinger = String(pk.assignedFinger);
          }
        }

        const fingerSem = elems.find((e) => String(e).startsWith("finger.")) || (String(mainElemId || "").startsWith("finger.") ? mainElemId : null);
        if (fingerSem && !resolvedFinger) {
          resolvedFinger = String(fingerSem).replace(/^finger\./, "");
        }

        if (!resolvedHand && resolvedFinger) {
          resolvedHand = Number(resolvedFinger) <= 5 ? "left" : "right";
        } else if (!resolvedHand && String(c.candidateId || "").includes("right")) {
          resolvedHand = "right";
        } else if (!resolvedHand && String(c.candidateId || "").includes("left")) {
          resolvedHand = "left";
        }

        const materialized = Object.freeze({
          candidateId: c.candidateId,
          questionType: c.questionType,
          categoryId: c.categoryId || c.questionType,
          templateSemanticId: tplId,
          templateContentVersion: c.templateContentVersion || 1,
          catalogVersion: this.catalogVersion,
          layoutId: this.layoutId,
          mainElementSemanticId: mainElemId,
          elementSemanticIds: Object.freeze(elems.slice()),
          keyId: resolvedKeyId,
          character: resolvedChar,
          modifierMode: resolvedMod,
          fingerId: resolvedFinger,
          handId: resolvedHand,
          questionSemanticIds: Object.freeze(qIds.slice()),
          subQuestions: Object.freeze(subQuestions),
        });

        this.candidatesById.set(materialized.candidateId, materialized);
        this.candidatesList.push(materialized);
      }
    }

    getCoverageSummary() {
      return {
        catalogVersion: this.catalogVersion,
        layoutId: this.layoutId,
        verifiedPhysicalKeys: this.physicalKeysById.size,
        verifiedCharacterMappings: this.charMappingsBySemanticId.size,
        activeDefinitions: this.definitionsBySemanticId.size,
        activeTemplates: this.templatesBySemanticId.size,
        totalCandidates: this.candidatesList.length,
        countsByType: Object.assign({}, this.candidatesData.candidateCountsByType || {}),
        excludedItemsCount:
          (this.candidatesData.coverage &&
            this.candidatesData.coverage.excludedNotInSvgCount) ||
          53,
      };
    }

    isCandidateInCurriculum(cand, maxLessonIndex, precomputedScope) {
      if (maxLessonIndex === null || maxLessonIndex === undefined) return true;
      const scopeApi = global.LessonCurriculumScope;
      if (!scopeApi || typeof scopeApi.getScopeUpToLesson !== "function") return true;
      const scope = precomputedScope || scopeApi.getScopeUpToLesson(maxLessonIndex);

      if (cand.questionType === "CARATTERE") {
        return cand.character !== null && cand.character !== undefined && scope.unlockedChars.has(cand.character);
      }
      if (cand.questionType === "TASTO") {
        return !!cand.keyId && scope.unlockedKeyIds.has(String(cand.keyId).replace(/^key\./, ""));
      }
      if (cand.questionType === "DITO") {
        return !!cand.fingerId && scope.unlockedFingerIds.has(String(cand.fingerId));
      }
      if (cand.questionType === "HOME_ROW") {
        const sq = Array.isArray(cand.subQuestions) && cand.subQuestions[0];
        const keyIds = sq && sq.answerDefinition && Array.isArray(sq.answerDefinition.acceptedKeyIds)
          ? sq.answerDefinition.acceptedKeyIds
          : [];
        if (keyIds.length > 0) {
          return keyIds.every((k) => scope.unlockedKeyIds.has(String(k).replace(/^key\./, "")));
        }
        return !!cand.fingerId && scope.unlockedFingerIds.has(String(cand.fingerId));
      }
      return true;
    }

    getCandidates(filter) {
      const f = filter || {};
      const types = Array.isArray(f.questionTypes) && f.questionTypes.length > 0
        ? new Set(f.questionTypes)
        : f.questionType
          ? new Set([f.questionType])
          : null;

      const hasLessonLimit =
        f.maxLessonIndex !== null &&
        f.maxLessonIndex !== undefined &&
        global.LessonCurriculumScope &&
        typeof global.LessonCurriculumScope.getScopeUpToLesson === "function";
      const scope = hasLessonLimit
        ? global.LessonCurriculumScope.getScopeUpToLesson(f.maxLessonIndex)
        : null;

      return this.candidatesList.filter((c) => {
        if (types && !types.has(c.questionType)) return false;
        if (f.categoryId && c.categoryId !== f.categoryId) return false;
        if (scope && !this.isCandidateInCurriculum(c, f.maxLessonIndex, scope)) return false;
        return true;
      });
    }

    getCandidateById(candidateId) {
      return this.candidatesById.get(candidateId) || null;
    }

    getQuestionDefinition(questionSemanticId) {
      return this.definitionsBySemanticId.get(questionSemanticId) || null;
    }

    getPhysicalKey(keyId) {
      return this.physicalKeysById.get(keyId) || null;
    }

    getPhysicalKeyBySemanticId(semanticId) {
      return this.physicalKeysBySemanticId.get(semanticId) || null;
    }

    getCharacterMappingBySemanticId(semanticId) {
      return this.charMappingsBySemanticId.get(semanticId) || null;
    }

    getAllPhysicalKeys() {
      return Array.from(this.physicalKeysById.values());
    }

    getReadableFingerName(fingerIdOrSemantic) {
      const FINGER_LABELS = {
        "1": "mignolo - (sn)",
        "2": "anulare - (sn)",
        "3": "medio - (sn)",
        "4": "indice - (sn)",
        "5": "pollice - (sn)",
        "6": "pollice - (dx)",
        "7": "indice - (dx)",
        "8": "medio - (dx)",
        "9": "anulare - (dx)",
        "10": "mignolo - (dx)",
      };
      const raw = String(fingerIdOrSemantic || "").replace(/^finger\./, "");
      return FINGER_LABELS[raw] || String(fingerIdOrSemantic || "");
    }

    getReadableKeyName(keyIdOrSemantic) {
      const keyId = String(keyIdOrSemantic || "").replace(/^key\./, "");
      const KEY_SPECIAL_NAMES = {
        key_minus: "meno",
        key_plus: "più",
        key_comma: "virgola",
        key_period: "punto",
        key_quote: "apostrofo",
        key_backslash: "backslash",
        key_less: "minore",
        key_space: "spazio",
        key_enter: "invio",
        key_tab: "tab",
        key_backspace: "backspace",
        key_egrave: "è",
        key_igrave: "ì",
        key_ograve: "ò",
        key_agrave: "à",
        key_ugrave: "ù",
      };
      if (KEY_SPECIAL_NAMES[keyId]) return KEY_SPECIAL_NAMES[keyId];
      const keyObj = this.physicalKeysById.get(keyId);
      if (keyObj && Array.isArray(keyObj.labelVariants) && keyObj.labelVariants.length > 0) {
        return String(keyObj.labelVariants[0]);
      }
      return keyId.replace(/^key_/, "");
    }

    getReadableCandidateLabel(candidate) {
      if (!candidate) return "";
      const type = candidate.questionType;
      const elems = Array.isArray(candidate.elementSemanticIds) ? candidate.elementSemanticIds : [];
      const elem = candidate.mainElementSemanticId || elems[0] || candidate.candidateId;

      if (type === "HOME_ROW") {
        return `[HOME_ROW] ${this.getReadableFingerName(elem)}`;
      }
      if (type === "DITO") {
        const keySem =
          elems.find((e) => String(e).startsWith("key.")) ||
          candidate.keyId ||
          (String(candidate.candidateId || "").startsWith("candidate.finger.")
            ? String(candidate.candidateId).replace("candidate.finger.", "")
            : elem);
        const fingerSem = elems.find((e) => String(e).startsWith("finger.")) || candidate.fingerId;
        const keyObj = this.physicalKeysBySemanticId.get(keySem) || this.physicalKeysById.get(keySem);
        const fingerText = fingerSem
          ? this.getReadableFingerName(fingerSem)
          : keyObj
            ? this.getReadableFingerName(keyObj.assignedFinger)
            : "";
        const keyText = this.getReadableKeyName(keySem);
        return `[DITO] ${fingerText} - {${keyText}}`;
      }
      if (type === "TASTO") {
        const keySem = elems.find((e) => String(e).startsWith("key.")) || elem;
        return `[TASTO] {${this.getReadableKeyName(keySem)}}`;
      }
      if (type === "CARATTERE") {
        const mapping = this.charMappingsBySemanticId.get(elem);
        const disp = mapping
          ? mapping.displayName || mapping.value || elem
          : elem;
        return `[CARATTERE] ${disp}`;
      }
      return `[${type}] ${elem}`;
    }

    getReadablePromptTitle(item) {
      if (!item) return "";
      const elems = Array.isArray(item.elementSemanticIds) ? item.elementSemanticIds : [];
      const elem = item.mainElementSemanticId || elems[0] || item.candidateId;
      switch (item.questionType) {
        case "HOME_ROW":
          return `Posizione Base (Home Row) — ${this.getReadableFingerName(elem)}`;
        case "TASTO": {
          const keySem = elems.find((e) => String(e).startsWith("key.")) || elem;
          return `Identificazione Tasto Fisico — {${this.getReadableKeyName(keySem)}}`;
        }
        case "CARATTERE": {
          const mapping = this.charMappingsBySemanticId.get(elem);
          const disp = mapping ? mapping.displayName || mapping.value || elem : elem;
          return `Produzione Carattere — ${disp}`;
        }
        case "DITO": {
          // Non svelare il dito atteso nel titolo della domanda in esecuzione
          const keySem =
            elems.find((e) => String(e).startsWith("key.")) ||
            item.keyId ||
            (String(item.candidateId || "").startsWith("candidate.finger.")
              ? String(item.candidateId).replace("candidate.finger.", "")
              : elem);
          return `Assegnazione Dito & Mano — Tasto {${this.getReadableKeyName(keySem)}}`;
        }
        default:
          return elem;
      }
    }

    // --- Metodi v6.27: Layout topologico, margherita, estensioni anatomiche, griglia ASCII ---
    getLayoutV627() {
      return global.INTERROGATION_LAYOUT_V627 || null;
    }

    getKeyLayoutMeta(keyId) {
      const layout = this.getLayoutV627();
      if (!layout || !layout.keyTopology) return null;
      const normalized = String(keyId || "").replace(/^key\./, "");
      return layout.keyTopology[normalized] || null;
    }

    getKeyIdForChar(ch) {
      const layout = this.getLayoutV627();
      if (!layout || !layout.keyTopology) return null;
      const target = String(ch);
      for (const [keyId, meta] of Object.entries(layout.keyTopology)) {
        const s = meta.slots || {};
        if (s.normal === target || s.shift === target || s.altgr === target || s.shiftAltgr === target) {
          return keyId;
        }
      }
      return null;
    }

    getCharsForKey(keyId) {
      const meta = this.getKeyLayoutMeta(keyId);
      if (!meta || !meta.slots) return [];
      const res = [];
      ["normal", "shift", "altgr", "shiftAltgr"].forEach((slotName) => {
        if (meta.slots[slotName]) {
          res.push({ slot: slotName, char: meta.slots[slotName] });
        }
      });
      return res;
    }

    getNeighborsForKey(keyId) {
      const meta = this.getKeyLayoutMeta(keyId);
      if (!meta || !meta.neighbors) return null;
      const n = meta.neighbors;
      const toToken = (kId) => {
        if (!kId) return "NONE";
        const km = this.getKeyLayoutMeta(kId);
        return km ? km.displayLabel : kId;
      };
      return {
        topLeft: n.topLeft || null,
        topRight: n.topRight || null,
        left: n.left || null,
        right: n.right || null,
        bottomLeft: n.bottomLeft || null,
        bottomRight: n.bottomRight || null,
        tokens: {
          topLeft: toToken(n.topLeft),
          topRight: toToken(n.topRight),
          left: toToken(n.left),
          right: toToken(n.right),
          bottomLeft: toToken(n.bottomLeft),
          bottomRight: toToken(n.bottomRight),
        },
      };
    }

    getKeysForFinger(fingerId, filter) {
      const layout = this.getLayoutV627();
      if (!layout || !layout.keyTopology) return [];
      const fNum = parseInt(String(fingerId || "").replace(/^finger\./, ""), 10);
      const f = filter || {};
      return Object.values(layout.keyTopology).filter((meta) => {
        if (meta.finger !== fNum) return false;
        if (f.lateralExt !== undefined && f.lateralExt !== null && meta.lateralExt !== Number(f.lateralExt)) {
          return false;
        }
        if (f.lateralDir && f.lateralDir !== "all" && meta.lateralDir !== f.lateralDir) {
          return false;
        }
        return true;
      });
    }

    getAsciiSelectionItems() {
      const layout = this.getLayoutV627();
      if (!layout) return { asciiCharacters: [], specialTokens: [], noneToken: "NONE" };
      return {
        asciiCharacters: layout.asciiCharacters || [],
        specialTokens: layout.specialTokens || [],
        noneToken: "NONE",
      };
    }

    getHomeRowTargets(side) {
      const layout = this.getLayoutV627();
      if (!layout || !layout.homeRowTargets) return [];
      return layout.homeRowTargets[side === "right" ? "right" : "left"] || [];
    }
  }

  global.InterrogationCatalog = InterrogationCatalog;
})(typeof window !== "undefined" ? window : globalThis);
