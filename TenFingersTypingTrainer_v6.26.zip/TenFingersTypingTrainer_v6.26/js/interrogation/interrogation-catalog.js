/* TenFingersTypingTrainer v6.25 | interrogation-catalog.js | Gestione e validazione del catalogo statico Interrogazione (52 tasti, 111 mapping, 445 definizioni, 225 candidate). */
(function (global) {
  "use strict";

  class InterrogationCatalog {
    constructor(rawData) {
      const source = rawData || global.INTERROGATION_CATALOG_DATA;
      if (!source || !source.seed || !source.questions || !source.candidates) {
        throw new Error("INTERROGATION_CATALOG_DATA mancante o incompleto.");
      }

      this.seed = source.seed;
      this.questions = source.questions;
      this.candidatesData = source.candidates;

      this.catalogVersion = String(this.candidatesData.catalogVersion || "1.0");
      this.layoutId = String(this.candidatesData.layoutId || "it-qwerty-105");

      this.physicalKeysById = new Map();
      this.physicalKeysBySemanticId = new Map();
      this.charMappingsBySemanticId = new Map();
      this.definitionsBySemanticId = new Map();
      this.templatesBySemanticId = new Map();
      this.candidatesById = new Map();
      this.candidatesList = [];

      this._indexAndValidate();
    }

    _indexAndValidate() {
      const keys = this.seed.physicalKeys || [];
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        this.physicalKeysById.set(k.keyId, k);
        const semId = k.semanticId || k.elementSemanticId;
        if (semId) {
          this.physicalKeysBySemanticId.set(semId, k);
        }
      }

      const mappings = this.seed.characterMappings || [];
      for (let i = 0; i < mappings.length; i++) {
        const m = mappings[i];
        const semId = m.semanticId || m.elementSemanticId;
        if (semId) {
          this.charMappingsBySemanticId.set(semId, m);
        }
      }

      const defs = this.questions.questionDefinitions || [];
      for (let i = 0; i < defs.length; i++) {
        const d = defs[i];
        if (d.status === "active") {
          this.definitionsBySemanticId.set(d.questionSemanticId, d);
        }
      }

      const templates = this.questions.mainQuestionTemplates || [];
      for (let i = 0; i < templates.length; i++) {
        const t = templates[i];
        const tid = t.templateId || t.templateSemanticId;
        if (tid && (!t.status || t.status === "active")) {
          this.templatesBySemanticId.set(tid, t);
        }
      }

      const rawCandidates = this.candidatesData.candidates || [];
      for (let i = 0; i < rawCandidates.length; i++) {
        const c = rawCandidates[i];
        if (!c || !c.candidateId || this.candidatesById.has(c.candidateId)) {
          throw new Error(`Candidate duplicato o non valido: ${c && c.candidateId}`);
        }
        const tplId = c.templateId || c.templateSemanticId;
        if (!this.templatesBySemanticId.has(tplId)) {
          throw new Error(`Template mancante o inattivo: ${tplId}`);
        }
        const subQuestions = [];
        const qIds = c.questionSemanticIds || [];
        for (let j = 0; j < qIds.length; j++) {
          const def = this.definitionsBySemanticId.get(qIds[j]);
          if (!def) {
            throw new Error(`Definizione mancante o inattiva: ${qIds[j]}`);
          }
          subQuestions.push(def);
        }

        const mainElemId =
          c.mainElementSemanticId ||
          (Array.isArray(c.elementSemanticIds) && c.elementSemanticIds[0]) ||
          null;

        const materialized = Object.freeze({
          candidateId: c.candidateId,
          questionType: c.questionType,
          categoryId: c.categoryId || c.questionType,
          templateSemanticId: tplId,
          templateContentVersion: c.templateContentVersion || 1,
          catalogVersion: this.catalogVersion,
          layoutId: this.layoutId,
          mainElementSemanticId: mainElemId,
          elementSemanticIds: Object.freeze((c.elementSemanticIds || []).slice()),
          keyId: c.keyId || null,
          character: c.character !== undefined ? c.character : null,
          modifierMode: c.modifierMode || null,
          fingerId: c.fingerId || null,
          handId: c.handId || null,
          questionSemanticIds: Object.freeze(qIds.slice()),
          subQuestions: Object.freeze(subQuestions),
        });

        this.candidatesById.set(materialized.candidateId, materialized);
        this.candidatesList.push(materialized);
      }
    }

    getCoverageSummary() {
      return {
        catalogVersion: this.catalogVersion,
        layoutId: this.layoutId,
        verifiedPhysicalKeys: this.physicalKeysById.size,
        verifiedCharacterMappings: this.charMappingsBySemanticId.size,
        activeDefinitions: this.definitionsBySemanticId.size,
        activeTemplates: this.templatesBySemanticId.size,
        totalCandidates: this.candidatesList.length,
        countsByType: Object.assign({}, this.candidatesData.candidateCountsByType || {}),
        excludedItemsCount:
          (this.candidatesData.coverage &&
            this.candidatesData.coverage.excludedNotInSvgCount) ||
          53,
      };
    }

    getCandidates(filter) {
      const f = filter || {};
      const types = Array.isArray(f.questionTypes) && f.questionTypes.length > 0
        ? new Set(f.questionTypes)
        : f.questionType
          ? new Set([f.questionType])
          : null;

      return this.candidatesList.filter((c) => {
        if (types && !types.has(c.questionType)) return false;
        if (f.categoryId && c.categoryId !== f.categoryId) return false;
        return true;
      });
    }

    getCandidateById(candidateId) {
      return this.candidatesById.get(candidateId) || null;
    }

    getQuestionDefinition(questionSemanticId) {
      return this.definitionsBySemanticId.get(questionSemanticId) || null;
    }

    getPhysicalKey(keyId) {
      return this.physicalKeysById.get(keyId) || null;
    }

    getPhysicalKeyBySemanticId(semanticId) {
      return this.physicalKeysBySemanticId.get(semanticId) || null;
    }

    getCharacterMappingBySemanticId(semanticId) {
      return this.charMappingsBySemanticId.get(semanticId) || null;
    }

    getAllPhysicalKeys() {
      return Array.from(this.physicalKeysById.values());
    }

    getReadableFingerName(fingerIdOrSemantic) {
      const FINGER_LABELS = {
        "1": "mignolo - (sn)",
        "2": "anulare - (sn)",
        "3": "medio - (sn)",
        "4": "indice - (sn)",
        "5": "pollice - (sn)",
        "6": "pollice - (dx)",
        "7": "indice - (dx)",
        "8": "medio - (dx)",
        "9": "anulare - (dx)",
        "10": "mignolo - (dx)",
      };
      const raw = String(fingerIdOrSemantic || "").replace(/^finger\./, "");
      return FINGER_LABELS[raw] || String(fingerIdOrSemantic || "");
    }

    getReadableKeyName(keyIdOrSemantic) {
      const keyId = String(keyIdOrSemantic || "").replace(/^key\./, "");
      const KEY_SPECIAL_NAMES = {
        key_minus: "meno",
        key_plus: "più",
        key_comma: "virgola",
        key_period: "punto",
        key_quote: "apostrofo",
        key_backslash: "backslash",
        key_less: "minore",
        key_space: "spazio",
        key_enter: "invio",
        key_tab: "tab",
        key_backspace: "backspace",
        key_egrave: "è",
        key_igrave: "ì",
        key_ograve: "ò",
        key_agrave: "à",
        key_ugrave: "ù",
      };
      if (KEY_SPECIAL_NAMES[keyId]) return KEY_SPECIAL_NAMES[keyId];
      const keyObj = this.physicalKeysById.get(keyId);
      if (keyObj && Array.isArray(keyObj.labelVariants) && keyObj.labelVariants.length > 0) {
        return String(keyObj.labelVariants[0]);
      }
      return keyId.replace(/^key_/, "");
    }

    getReadableCandidateLabel(candidate) {
      if (!candidate) return "";
      const type = candidate.questionType;
      const elems = Array.isArray(candidate.elementSemanticIds) ? candidate.elementSemanticIds : [];
      const elem = candidate.mainElementSemanticId || elems[0] || candidate.candidateId;

      if (type === "HOME_ROW") {
        return `[HOME_ROW] ${this.getReadableFingerName(elem)}`;
      }
      if (type === "DITO") {
        const keySem =
          elems.find((e) => String(e).startsWith("key.")) ||
          candidate.keyId ||
          (String(candidate.candidateId || "").startsWith("candidate.finger.")
            ? String(candidate.candidateId).replace("candidate.finger.", "")
            : elem);
        const fingerSem = elems.find((e) => String(e).startsWith("finger.")) || candidate.fingerId;
        const keyObj = this.physicalKeysBySemanticId.get(keySem) || this.physicalKeysById.get(keySem);
        const fingerText = fingerSem
          ? this.getReadableFingerName(fingerSem)
          : keyObj
            ? this.getReadableFingerName(keyObj.assignedFinger)
            : "";
        const keyText = this.getReadableKeyName(keySem);
        return `[DITO] ${fingerText} - {${keyText}}`;
      }
      if (type === "TASTO") {
        const keySem = elems.find((e) => String(e).startsWith("key.")) || elem;
        return `[TASTO] {${this.getReadableKeyName(keySem)}}`;
      }
      if (type === "CARATTERE") {
        const mapping = this.charMappingsBySemanticId.get(elem);
        const disp = mapping
          ? mapping.displayName || mapping.value || elem
          : elem;
        return `[CARATTERE] ${disp}`;
      }
      return `[${type}] ${elem}`;
    }

    getReadablePromptTitle(item) {
      if (!item) return "";
      const elems = Array.isArray(item.elementSemanticIds) ? item.elementSemanticIds : [];
      const elem = item.mainElementSemanticId || elems[0] || item.candidateId;
      switch (item.questionType) {
        case "HOME_ROW":
          return `Posizione Base (Home Row) — ${this.getReadableFingerName(elem)}`;
        case "TASTO": {
          const keySem = elems.find((e) => String(e).startsWith("key.")) || elem;
          return `Identificazione Tasto Fisico — {${this.getReadableKeyName(keySem)}}`;
        }
        case "CARATTERE": {
          const mapping = this.charMappingsBySemanticId.get(elem);
          const disp = mapping ? mapping.displayName || mapping.value || elem : elem;
          return `Produzione Carattere — ${disp}`;
        }
        case "DITO": {
          // Non svelare il dito atteso nel titolo della domanda in esecuzione
          const keySem =
            elems.find((e) => String(e).startsWith("key.")) ||
            item.keyId ||
            (String(item.candidateId || "").startsWith("candidate.finger.")
              ? String(item.candidateId).replace("candidate.finger.", "")
              : elem);
          return `Assegnazione Dito & Mano — Tasto {${this.getReadableKeyName(keySem)}}`;
        }
        default:
          return elem;
      }
    }
  }

  global.InterrogationCatalog = InterrogationCatalog;
})(typeof window !== "undefined" ? window : globalThis);
