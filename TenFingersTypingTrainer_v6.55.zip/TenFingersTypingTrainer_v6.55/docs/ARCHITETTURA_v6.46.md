# Architettura TenFingersTypingTrainer v6.46

Documento di aggiornamento architetturale rispetto alla v6.45.

## 1. Obiettivo della Release v6.46
Correggere la modalità **Random This Phrase** (`mode === 5`) affinché rimescoli sempre l'ordine dei caratteri dell'ultima frase visualizzata o digitata dall'utente, indipendentemente dalla modalità di provenienza (*Phrases* standard o custom, *Random*, *Fonemi*, *All Chars*, *Digitazione Libera* o *Weaknesses*).

## 2. Gestione Sorgente in `TypingEngine` (`js/engines/typing-engine.js`)
- Aggiunta la proprietà `this.lastTypedPhrase = ""` nel costruttore di `TypingEngine`.
- In `initSession(keepExercise)`, prima di azzerare `this.typedText`, il testo digitato non vuoto viene preservato in `this.lastTypedPhrase` per consentire il passaggio diretto da *Digitazione Libera* (`mode === 4`, dove `this.originText` è vuoto).
- In `loadExercise()`, per `this.mode === 5`, la sorgente `candidateSource` segue l'ordine di priorità:
  1. `this.originText` (se non vuoto, per tutte le modalità guidate o ripetizioni in `mode === 5`).
  2. `this.lastTypedPhrase` (se non vuoto, per provenienza da *Digitazione Libera*).
  3. Fallback alla frase della lezione corrente o `"asdfl"` solo in assenza di qualsiasi testo precedente.

## 3. Controlli Toolbar e UI (`metodi-toolbar-modalita.js`, `metodi-navigazione-dialoghi.js`)
- In `updateModeUI()`, `#btnRandomThisPhrase` resta abilitato anche in `mode === 4` (*Digitazione Libera*).
- Nel listener di `#btnRandomThisPhrase`, se `mode === 4` e `typedText` è vuoto, l'operazione viene bloccata con notifica utente; se `typedText` è valorizzato, la modalità passa a `5` e avvia il rimescolamento.
- In `startExercise()`, l'etichetta `#lblPhraseRange` per `mode === 5` espone `${this.typingEng.originText.length} caratteri rimescolati` invece del riferimento alla singola frase di lezione.
