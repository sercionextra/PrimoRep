# Architettura TenFingersTypingTrainer v6.56

Documento di aggiornamento architetturale rispetto alla v6.55.

## 1. Obiettivo della Release v6.56
1. Sostituire i precedenti indicatori puntiformi (`.base-dot`) sui tasti di riposo della Tastiera Virtuale con due riquadri a bordi arrotondati dedicati rispettivamente alla mano sinistra (`a, s, d, f`) e alla mano destra (`j, k, l, ò`).
2. Mantenere i trattini tattili `.key-bump` sui tasti `f` e `j`.
3. Garantire che nella Modalità Interrogazione i nuovi riquadri siano completamente rimossi/nascosti dal clone SVG, preservando i test di regressione esistenti.

## 2. Interventi Architetturali
1. **Markup SVG in `index.html` (`#keyboardSvg`):**
   - Rimossi gli 8 `<circle class="base-dot" cx="42" cy="10" r="3.5" />` dai gruppi `key_a`, `key_s`, `key_d`, `key_f`, `key_j`, `key_k`, `key_l`, `key_ograve`.
   - Mantenuti i due `<line class="key-bump" ... />` su `key_f` e `key_j`.
   - Aggiunti in coda a `#keyboardSvg` (sopra i tasti nello Z-order SVG) i due elementi:
     - `#homeRowFrameLeft.home-row-frame`: `x="101.5" y="123.5" width="231" height="57" rx="8" ry="8"`
     - `#homeRowFrameRight.home-row-frame`: `x="449.5" y="123.5" width="231" height="57" rx="8" ry="8"`
2. **Stili CSS in `assets/styles/app.css`:**
   - Aggiunta la regola `.home-row-frame` con `fill: none; stroke: var(--base-dot); stroke-width: 2; pointer-events: none;`, garantendo l'adattamento automatico a tutti i 4 temi (`Dark`, `Light`, `Matrix`, `Retro 2003`).
   - Aggiunta la regola `.interr-keyboard-bn .home-row-frame { display: none; }`, mantenendo inalterate le regole su `.base-dot` e `.key-bump` per compatibilità con `tests/test-interrogation-v635.js`.
3. **Isolamento in Interrogazione (`js/ui/interrogation-svg-renderer.js`):**
   - In `_mountKeyboard(container)`, aggiunta la rimozione esplicita `clone.querySelectorAll(".home-row-frame").forEach((el) => el.remove());` dopo la rimozione di `.base-dot` e `.key-bump`.
