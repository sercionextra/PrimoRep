// =======================================================
// File: /workspace/main_A_(v.3.0).js
// Versione: 3.0
// Data rilascio: 12/10/2026
// Note di rilascio v.3.0:
//   1. Major Release v.3.0: refactoring completo dell'algoritmo didattico Fonemi (PhonemeEngine).
//   2. Eliminazione totale dei caratteri fittizi di ripiego a favore di re-seed reale dal corpus.
//   3. Gestione deterministica dei vicoli ciechi: validazione fonotattica delle parole parziali
//      e rollback selettivo all'ultimo spazio valido con guardia anti-starvation.
//   4. Troncamento rigido e garantito a 100 caratteri netti per ogni sequenza sillabica.
//   5. Piena retrocompatibilità e preservazione delle feature, lezioni didattiche e profili precedenti.
// =======================================================

// Helper canonico: restituisce data e ora locale italiana di sistema (YYYY-MM-DDTHH:mm:ss)
function getLocalISODateTime(d = new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  const year = d.getFullYear();
  const month = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  const hours = pad(d.getHours());
  const minutes = pad(d.getMinutes());
  const seconds = pad(d.getSeconds());
  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}

// PARSER ESERCIZI PERSONALIZZATI (Formato C# ===== Titolo ===== con Invio e Tab)
function parseCustomExercises(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/);
  const lessons = [];
  let curLesson = null;
  let curLines = [];

  const flushPhrase = () => {
    if (!curLesson) return;
    if (curLines.length > 0) {
      // Unione delle righe fisiche con spazio separatore (ignorando il normale ritorno a capo).
      // Solo il token "®" genera un effettivo Invio da digitare.
      let phraseText = "";
      for (let i = 0; i < curLines.length; i++) {
        const seg = curLines[i];
        if (!seg) continue;
        if (phraseText.length === 0) {
          phraseText = seg;
        } else if (phraseText.endsWith(" ") || phraseText.endsWith("®")) {
          phraseText += seg;
        } else {
          phraseText += " " + seg;
        }
      }
      if (phraseText.trim().length > 0) {
        curLesson.phrases.push(phraseText);
      }
      curLines = [];
    }
  };

  for (let line of lines) {
    line = line.trimEnd();
    const titleMatch = line.match(/^=====(.*?)=====$/);
    if (titleMatch) {
      flushPhrase();
      const title = titleMatch[1].trim();
      curLesson = { name: title || "Esercizio Custom", phrases: [] };
      lessons.push(curLesson);
    } else if (line === "=====") {
      flushPhrase();
    } else if (curLesson) {
      // Conversione automatica di 4 spazi o tabulazioni fisiche nel token canonico "→"
      let proc = line.replace(/\t/g, "→").replace(/    /g, "→");
      curLines.push(proc);
    }
  }
  flushPhrase();
  return lessons.filter((l) => l.phrases.length > 0);
}

function htmlEscape(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Embedded Datasets (Invariati e preservati al 100%)
const EMBEDDED_LESSONS = [
  {
    name: "asdfl",
    phrases: [
      "sala falsa",
      "dalla sala",
      "falsa falla",
      "salda la falla",
      "la falla salda",
      "fa la sala",
      "la fa dalla sala",
      "la salsa falsa",
      "fa la salsa",
      "la salsa salda",
      "falla salda la salsa",
      "la falda salsa",
      "sala da salsa",
      "salda salda",
      "sa da salsa",
      "falla la salsa",
      "sala la salsa",
      "ala salda",
      "afa falsa",
      "falsa afa",
      "fa la falsa",
    ],
  },
  {
    name: "g",
    phrases: [
      "ala a galla",
      "afa a galla",
      "fa la glassa",
      "allaga la sala",
      "la daga a galla",
      "la daga falsa",
      "falsa la glassa",
      "la glassa falsa",
      "a galla",
      "salga la falda",
      "falla la daga",
      "salga a galla",
      "la falsa daga",
      "falla la glassa",
      "la falsa falla",
      "salsa alla glassa",
      "alla sala falsa",
      "alga a galla",
      "alga salga a galla",
      "alga salga la falda",
      "alga allaga la sala",
      "falsa alga",
      "falsa saga",
      "la saga glassa",
      "la saga fa la glassa",
    ],
  },
  {
    name: "h",
    phrases: [
      "ha la salsa",
      "ah la glassa",
      "ha la daga",
      "ha la falla",
      "ha la daga falsa",
      "ha la sala",
    ],
  },
  {
    name: "i",
    phrases: [
      "i dadi lisi",
      "fili di giada",
      "salsa gialla",
      "figlia saggia",
      "falsi saggi",
      "dadi di ghisa",
      "fila di gigli gialli",
      "fila di laghi",
      "la giada falsa",
      "i fidi asili",
      "i gigli gialli",
      "fila di ghiaia",
      "ha dadi fissi",
      "i fili fissi",
      "i falsi affissi",
      "falsi figli",
      "falsi assilli",
      "figli di faggi",
      "figli di ghisa",
      "gli dissi",
      "i fili gialli",
      "ghiaia gialla",
      "faggi di laghi",
      "la dalia gialla",
      "hai falsi fili di giada",
    ],
  },
  {
    name: "o",
    phrases: [
      "soldi falsi",
      "la glassa fa gola",
      "loda la folla",
      "filo di olio",
      "falso saggio",
      "foglia di faggio",
      "dado di ghisa",
      "odio il giglio",
      "salgo da solo",
      "odia i fagioli",
      "loda la folla",
      "la sfoglia fa gola",
      "il figlio fa gola",
      "il figlio soffia",
      "odio i dadi",
      "oggi ha lodato",
      "saggia follia",
      "assaggia i fagioli",
      "ha solo lodi",
      "aglio o olio",
      "i soldi gialli",
      "soldi falsi",
      "lodi di figlia",
      "il figlio sloggia",
      "il foglio giallo",
      "la foglia di faggio",
      "filo giallo",
      "salsa di olio",
      "oggi ha solo fagioli",
    ],
  },
  {
    name: "e",
    phrases: [
      "le foglie dei faggi",
      "sedie di faggio",
      "la sedia di ghisa",
      "le figlie fedeli",
      "le sedie delle figlie",
      "egli ha fede",
      "leghe di ghisa",
      "le sedi delle leghe",
      "idea fedele",
      "seggio fisso",
      "le folli daghe",
      "egli fa follie",
      "giogo folle",
      "ha delle false lodi",
      "le foglie folli",
      "il sole e la foglia",
      "ella si siede",
      "se si sedesse",
      "egli fa fallo",
      "sei sedie gialle",
      "le foglie al gelo",
      "aghi e fili",
      "file di foglie",
      "offesa dalle figlie",
      "laghi al gelo",
      "egli ha sei figlie",
      "le foglie gialle",
    ],
  },
  {
    name: "p",
    phrases: [
      "palla di ghisa",
      "olio e seppie",
      "pelle di pollo",
      "il pollo passa",
      "gli passo la palla",
      "si posa la foglia",
      "seppie e pollo",
      "i passi folli",
      "olio a galla",
      "le spalle della sposa",
      "la palla galleggia",
      "la sedia di paglia",
      "il piede del figlio",
      "la sposa fedele",
      "egli ha la pialla",
      "egli ha la pila",
      "il poggiolo fisso",
      "il figlio pallido",
      "giallo pallido",
      "la palla gialla",
      "pila di fogli",
      "polpa di pollo",
      "la foglia di pioppo",
      "pioppi e faggi",
      "doppio fallo",
      "osso di seppia",
      "salsa di pollo",
      "la pillola gialla",
    ],
  },
  {
    name: "r",
    phrases: [
      "olio e lardo per friggere",
      "perdere la palla per il fallo",
      "le farfalle sopra i gigli",
      "fiori gialli tra le rose",
      "saper perdere la gara",
      "il paggio del re",
      "era il regalo del re",
      "orrore per il freddo",
      "freddo e gelo alla sera",
      "il grosso pioppo",
      "era pallido e fragile",
      "dire delle frasi assai serie",
      "sorridere ai fiori",
      "sei di fiori",
      "le farfalle gialle",
      "presi dal desiderio",
      "farsi pregare",
      "perdere a dadi",
      "fare dei progressi",
      "progredire e salire",
      "il golf grigio perla",
      "freddo polare",
      "pregare di sera",
      "preferire fiori rari",
      "sedie di pregio",
      "sopra le pere",
      "aria fresca",
      "ferro e ghisa",
    ],
  },
  {
    name: "t",
    phrases: [
      "troppi grappoli nel piatto",
      "le proteste dei tifosi",
      "le trote del lago",
      "la grotta dei pipistrelli",
      "trippe e fagioli",
      "lo sparo della pistola",
      "egli le apre la porta",
      "il pregio del posto",
      "la serata era gelida",
      "fare delle ripide salite",
      "petrolio greggio",
      "trasportare dei grossi sassi",
      "il fragile trasporto",
      "ripido tratto di salita",
      "tradire per i soldi",
      "essere triste e poi lieto",
      "in attesa della paga",
      "la talpa sta sotto terra",
      "essere di fretta",
      "la trappola per i topi",
      "il tetto di paglia",
      "il posto di ristoro",
      "il gelato alla fragola",
      "la torta alle fragole",
      "lo stato estero",
      "era la stessa storia",
      "errore di tiro",
      "il test era errato",
      "fuggire di sera",
      "il passato e il futuro",
      "il gusto di leggere",
      "autore del furto",
      "la lunga giostra",
      "il fusto del pioppo",
      "la foglia sulla strada",
    ],
  },
  {
    name: "u",
    phrases: [
      "auto proprio lurida",
      "sei fedeli segugi",
      "luogo di preghiera",
      "era proprio tutta sudata",
      "era ladro e truffatore",
      "opera di autore russo",
      "perdere tutto ai dadi",
      "i trulli pugliesi",
      "sul fiore o sulla foglia",
      "il tratto superiore",
      "freddo da lupi",
      "odio e furore",
      "arresto per truffa",
      "profugo dalla russia",
      "gruppo di pugili",
      "il luogo dei giusti",
      "resti di frustate alle spalle",
      "luoghi luridi e fetidi",
      "il prete e la suora",
      "le spalle sussultavano dal ridere",
      "il gufo sopra il tetto",
      "pare che legga il futuro",
    ],
  },
  {
    name: "n",
    phrases: [
      "tanti panni stesi",
      "un pugnale affilato",
      "funghi saporiti",
      "lunghe file alle poste",
      "il ponte non regge",
      "polenta e funghi",
      "un lungo ponte",
      "lontano dalla gente",
      "una nonna proprio generosa",
      "una figlia gentile",
      "una gustosa frittella",
      "dare in prestito",
      "un piede ingessato",
      "un testo assai interessante",
      "una idea geniale",
      "un ingenuo figliolo",
      "un trucco infantile",
      "prendere tutto sul serio",
      "un pasto frugale",
      "una pioggia assai fastidiosa",
      "non aspettare in piedi",
      "pantaloni tutti infangati",
      "una alunna interessata",
      "lei non sta attenta",
      "un passerotto infreddolito",
      "insoddisfatto del suo postino",
      "non sentire niente",
    ],
  },
  {
    name: "c",
    phrases: [
      "uno spettatore incredulo",
      "giocare tutti a calcio",
      "una ciocca di capelli",
      "accendere un cero in chiesa",
      "non le piace accendere il fuoco",
      "leccare con gusto il gelato",
      "una coppa di gelato al cacao",
      "cocciuto e ostinato",
      "chi prima rideva adesso piange",
      "un chiodo arrugginito",
      "un pericoloso incidente stradale",
      "far cessare ogni eccesso",
      "un sincero confidente",
      "tu non sai cosa mi ha detto",
      "ci piacciono le coscie di pollo",
      "un frastuono incessante",
      "il cappotto era fradicio per la pioggia",
      "un esercito di galline",
      "pulisciti le orecchie",
      "farsi una doccia calda",
      "stare con le orecchie tese",
      "non nasconderti con la maschera",
      "chiedi le chiavi di casa",
      "chi ha un cruccio si sfoga",
      "andare a caccia di cinghiali",
      "il cagnolino sta nella cuccia",
      "sta a casa con gli orecchioni",
      "dei sacchi di ceci",
    ],
  },
  {
    name: "m",
    phrases: [
      "una macchia di inchiostro",
      "mi manda la mamma",
      "un mostro immondo",
      "ama molto la mamma",
      "immagina che giunga un mago",
      "una camera da letto molto ampia",
      "meglio imparare la matematica",
      "se hai male chiama il medico",
      "non mi piace la medicina amara",
      "se ha miagolato non era una mucca",
      "se ha muggito non era un gatto",
      "di studiare non le importa molto",
      "amo molto la montagna",
      "un campo di mais e uno di frumento",
      "stare immersa nel mare",
      "scimmie ammaestrate al circo",
      "la scimitarra del sultano",
      "impara a suonare il mandolino",
      "era partita con molti rimpianti",
      "occorre mettere ancora molto sale",
      "immagina di stare meglio",
      "molto rumore per nulla",
      "mille moscerini sulla macchina",
      "mangia maccheroni al sugo",
      "una matita affilatissima",
      "la maschera di ferro",
      "mai dire mai",
      "mi tocca mangiare la minestra",
    ],
  },
  {
    name: "z",
    phrases: [
      "porta fuori le immondizie",
      "mi piace molto la pizza",
      "gioca con pazienza e furbizia",
      "in piazza ci sono molte persone",
      "un fazzoletto con il pizzo",
      "dei mercanti in cerca di spezie",
      "era mezzo morto di paura",
      "non era una piazza molto spaziosa",
      "dei pezzi di pesce molto puzzolenti",
      "gli si rizzavano i capelli in testa",
      "spezzava i rami con ogni mezzo",
      "un tizzone acceso nel caminetto",
      "era molto amato dalle zie",
      "meglio la prudenza che la pazzia",
      "si sente una puzza pazzesca",
      "la tazza si ruppe in mille pezzi",
      "si azzuffano in mezzo alla piazza",
      "il mercato si fa in piazza",
      "la mazza da golf di mio zio",
      "andiamo pazzi per la pizza",
      "una stanza spaziosa",
      "un mazzo di azalee",
      "una pizza non mi sazia",
      "con un colpo di mazza si spezza",
      "attenti al precipizio",
      "non sempre il giusto sta nel mezzo",
    ],
  },
  {
    name: "q",
    phrases: [
      "in questa scuola si studia molto",
      "acqua inquinata in molti fiumi",
      "un giocatore squalificato",
      "non era questo il quaderno da portare",
      "salire le scale quatto quatto",
      "erano quattro o cinque amici",
      "era proprio una questione da chiarire",
      "mi piacciono tutti i quiz",
      "ricopiare tutto tale e quale",
      "un quintale di queste mele",
      "chiede solo acqua minerale frizzante",
      "esco dopo questo acquazzone",
      "una questione di interesse",
      "si era quasi addormentata",
      "un gesto inqualificabile",
      "tutto era quieto e silenzioso",
      "uscire per fare acquisti",
      "quindici persone qualsiasi",
      "il quattordici di luglio",
      "quarantaquattro gatti",
      "quando saremo in quattro",
      "un posto proprio tranquillo",
      "quattro quaderni a quadri",
      "una questione di quiz",
      "quasi quasi mangio qui",
      "preferisco questa acqua",
      "costa millecinquecento lire",
      "quasi un quintale di questi quaderni",
    ],
  },
  {
    name: "v",
    phrases: [
      "un veloce avvio di gara",
      "con la violenza si fa poca giustizia",
      "la tigre zoppica ma va a zonzo lo stesso",
      "mi serve un pezzo di legno",
      "sperava molto di vincere",
      "gli avvoltoi volano molto in alto",
      "pensava spesso ai suoi vecchi amici",
      "stava sempre vicina al tavolo",
      "mettiti davanti al tavolino",
      "non avvicinarti troppo al vetro",
      "raccontava delle storie avvincenti",
      "viveva da sola in una vecchia casa",
      "sapeva inventare storie stupende",
      "aveva un cagnolino vivacissimo",
      "sperava di vincere alla lotteria",
      "era avvilita per non aver vinto nulla",
      "nevicava da vari giorni",
      "la vasca del parco era sempre vuota",
      "un velivolo velocissimo",
      "una voce cavernosa",
      "rividi volentieri quel villaggio",
      "devi diventare veloce nelle divisioni",
      "sul prato verde fiorivano le viole",
      "un avvenimento davvero unico",
      "non avvicinarti al vulcano",
      "invece di viola lo vorrei verde",
      "vendere vestiti vecchi",
      "un vasetto vuoto",
      "voleva vincere almeno una volta",
      "cadeva spesso dal tavolo",
    ],
  },
  {
    name: "b",
    phrases: [
      "devi sviluppare bene questa vicenda",
      "bevi questa buona bibita",
      "era una brutta avventura",
      "basta stare attenti alle buche",
      "un bravo burattino",
      "la bilancia era sbilenca",
      "non buttare via i barattoli",
      "ha imbucato il biglietto di auguri",
      "era molto abile con le biglie",
      "devi sbucciare bene la banana",
      "non mi piace il brodo bollente",
      "deve andare ad abitare lontano",
      "la baracca era tutta bruciata",
      "attento alla buca vicino al burrone",
      "bere una bella tazza di latte",
      "ottimi i biscotti con il burro",
      "un breve giro nel bosco",
      "un barattolo di colore blu",
      "sembra una bella idea cambiare aula",
      "un dolce di ribes e albicocche",
      "non disturbare il babbo",
      "ai bufali piace brucare erba fresca",
      "un brutto scambio",
      "era un imbianchino molto bravo",
      "brontolava e borbottava sempre",
      "un albero di albicocche",
      "non mi faccio imbrogliare",
      "era arrabbiata per quel brutto voto",
      "bianco rosso e blu",
    ],
  },
  {
    name: "ò",
    phrases: [
      "andò via di corsa",
      "non si può continuare a discutere",
      "saltò dal treno in corsa",
      "arrivò primo assoluto",
      "frenò in ritardo",
      "non si può correre",
      "togliti pure il paltò",
      "accese un bel falò",
      "si salvi chi può",
      "si fermò e si girò",
      "andò a piedi fino a scuola",
      "tre civette sul comò",
      "gli tirò un sasso addosso",
      "un albero crollò di colpo",
      "il ramo si spezzò",
      "non si può continuare",
      "quanto prima finirò",
      "il campione saltò e vinse",
      "solo un giorno lo sopportò",
      "la barca salpò ma non tornò",
      "dopo il naufragio non navigò per due anni",
      "saltò al volo dal bus",
      "la nave aveva cento oblò",
      "non parlò con nessuno",
      "salirò fino al terzo piano",
      "non si può accendere qui un falò",
      "arrivò un poliziotto e lo arrestò",
    ],
  },
  {
    name: "à",
    phrases: [
      "chissà quando arriverà",
      "correva di qua e di là",
      "se frena si fermerà",
      "cercò sempre la libertà",
      "pietà per i vinti",
      "chi vivrà vedrà",
      "suonerà tutta la notte",
      "la felicità prima di tutto",
      "non disprezzò mai la povertà",
      "la libertà non si vende mai",
      "andrà in cerca della felicità",
      "se non ti muovi nessuno ti aiuterà",
      "se vai là nessuno ti troverà",
      "non mi dà mai retta",
      "riderà bene chi riderà ultimo",
      "entrò nella cavità del tronco",
      "quando lo saprà si pentirà",
      "una enorme quantità di terra",
      "aiutatemi per pietà",
      "arriverà in fine la felicità",
      "una penna di prima qualità",
      "questo letto ha poca elasticità",
      "non vincerà mai la sua golosità",
      "chi andrà di qua chi di là",
      "alla fine un eroe li salverà",
      "hai già avuto due possibilità",
      "era appeso alle estremità",
      "una macchina di grande utilità",
    ],
  },
  {
    name: "ù",
    phrases: [
      "non ne posso più",
      "lassù fa più freddo",
      "le vere virtù si notano poco",
      "più saliva e più aveva paura",
      "cadde a testa in giù",
      "chi più ne ha più ne metta",
      "erano andati tutti laggiù",
      "la virtù della carità",
      "lodò le vere virtù",
      "una poltrona di bambù",
      "non abita più qui",
      "saltò più in alto di te",
      "facciamo una corsa fino a laggiù",
      "una servitù pesante",
      "errori di gioventù",
      "pescava con una canna di bambù",
      "persona di grandi virtù",
      "più di qua che di là",
      "il menù del ristorante",
      "diritto di servitù",
      "quassù non si vede nulla",
      "viaggiare in treno mi piace di più",
      "non credo che mentire sia una virtù",
      "la gioventù non torna più",
      "vai giù e prendimi una bottiglia",
      "mi piace la musica indù",
      "per fortuna la schiavitù non esiste più",
      "stando giù si sentiva qualcosa di più",
    ],
  },
  {
    name: "èé",
    phrases: [
      "è veramente adatto a te",
      "è un buon caffè",
      "erano ventitrè amici",
      "non dirmi ma o cioè",
      "trentatrè trentini",
      "perché faceva tutto da sè?",
      "chi fa da sè fa per tre",
      "non è bello stare a testa in giù",
      "è andato tutto bene",
      "si è fermato subito",
      "benché lo sapesse, non lo aiutò mai",
      "questo libro non è per te",
      "chi è stanco si fermi",
      "ahimè che disgrazia",
      "mi piacciono i bignè",
      "olè olè gridavano al torero",
      "preparava un panino con il pan carrè",
      "ci vediamo alle ore ventitrè in punto",
      "è ora di andare in casa",
      "beviamo un buon caffè",
      "è nato nel novantatrè",
      "è meglio finire qui",
      "parlava tra sé e sé",
      "il treno non è in orario",
      "una torta di bignè",
      "è ora della pausa per il caffè",
      "gli piace fare tutto da sé",
      "non è il momento di dire sciocchezze",
      "è un caffè speciale",
    ],
  },
  {
    name: "ì",
    phrases: [
      "partì di corsa",
      "salì le scale",
      "non finì mai il dipinto",
      "lavorava notte e dì",
      "egli diceva sempre sì",
      "non stare lì impalato",
      "ci vediamo domani a mezzodì",
      "vieni via di lì",
      "la maestra punì tre scolari",
      "non era lì che dovevi andare",
      "salì in casa a mezzodì",
      "non riuscì a finire per mezzodì",
      "non si sa come finì la partita",
      "ottima la lepre in salmì",
      "se spingi ancora non si sposta da lì",
      "il volo del colibrì",
      "dopo il lunedì viene il martedì",
      "finì alle nove o giù di lì",
      "stai attento se passi di lì",
      "finì tutto in due minuti",
      "sta fermo così per qualche minuto",
      "arrivò giovedì a mezzodì",
      "di sicuro non riuscì a farlo così",
      "salì sulla torre e da lì lo vide partire",
      "partì giovedì con la nave",
      "corri a vedere cosa fanno quelli lì",
      "aspettò lì da solo tutto il dì",
      "rispondimi sì o no",
    ],
  },
  {
    name: ",",
    phrases: [
      "la condì con olio, aceto e sale",
      "non si può perdere, bisogna vincere",
      "era, sembra, un vero artista",
      "sentiva, di sera, i grilli cantare",
      "chi rompe, dice il proverbio, paga",
      "era, a detta di molti, un vero affare",
      "sono partiti tutti, anche gli ammalati",
      "se piove, purtroppo, si bagna tutto",
      "non è vero, sono tutte bugie",
      "vai piano, la strada è scivolosa",
      "se perdi, non arrabbiarti",
      "fiorirono rose, gigli e garofani",
      "studio italiano, matematica e storia",
      "la notte, dicono, porta consiglio",
      "mi piace, in particolare, il suono del violini",
      "io preferisco venerdì, sabato e domenica",
      "a scuola, lo sai, si viene per imparare",
      "è bello, quando piove, starsene in casa",
      "tuoni, lampi, fulmini e saette",
      "coraggio, mi dissi, devo farcela",
      "a colazione mangio latte, biscotti e miele",
    ],
  },
  {
    name: ".",
    phrases: [
      "salta sul carro.",
      "attenti al lupo.",
      "la forza delle braccia.",
      "non si può sempre correre.",
      "attenti alle curve.",
      "la frutta fa bene.",
      "spegni la televisione.",
      "suona bene il piano.",
      "era contento della sua maestra.",
      "un bel prato pieno di fiori.",
      "quando piove si sta bene in casa.",
      "non posso più uscire di sera.",
      "mi piace sentire la musica.",
      "è finito il temporale.",
      "quel treno è sempre in ritardo.",
      "vorrei invitare tutti per il mio compleanno.",
    ],
  },
  {
    name: "'",
    phrases: [
      "c'erano mele, pere, mandarini e pesche",
      "suona bene l'armonica",
      "l'albergo era tutto esaurito",
      "era un'estate caldissima",
      "l'incontro è andato bene",
      "sorpassò l'avversario ed arrivò primo",
      "l'aspetto era ottimo",
      "l'ospite è ben gradito",
      "versare l'olio e l'aceto",
      "è un'incredibile avventura",
      "era l'unica a stare attenta",
      "è l'ideale dei giovani d'oggi",
      "non c'è spazio per l'inganno",
      "c'era molta fiducia in lui.",
      "la figlia l'amava moltissimo.",
      "aveva un po' di fame.",
      "ce l'aveva un po' con lei.",
      "c'è dell'aranciata o dell'acqua fresca",
    ],
  },
  {
    name: "ShiftDestro",
    phrases: [
      "Devi fare gli auguri a Sandra.",
      "Arriveremo presto a Roma.",
      "Aiuta Elena a fare i compiti.",
      "Questo treno non va a Como.",
      "A Roma c'è il Vaticano.",
      "Era il famoso colpo di Zorro.",
      "Giulio Cesare sconfìsse i Galli.",
      "Vicenza è una città del Veneto.",
      "Tutte le strade portano a Roma.",
      "Firenze si trova in Toscana.",
      "Giuseppe Verdi era un musicista.",
      "Franco abita a Enna, in Sicilia.",
      "La Francia è uno dei più grandi stati d'Europa.",
      "Giorgio, Ernesto, Simone e Andrea verranno qui a dormire.",
    ],
  },
  {
    name: "ShiftSinistro",
    phrases: [
      "Il Milione di Marco Polo.",
      "Un bel viaggio in India.",
      "Lascia entrare prima Paola.",
      "Livorno è vicina a Pisa.",
      "Tra Verona e Padova c'è Vicenza.",
      "Un amico di Luigi.",
      "Grosso incidente a Milano.",
      "Un nuovo palazzo a Napoli.",
      "Oggi è il compleanno di Laura.",
      "Freddo polare in Norvegia.",
      "L'autostrada è interrotta a Udine.",
      "La pietà di Michelangelo.",
      "La capitale della Francia è Parigi.",
      "Un lungo viaggio in Libia e in Marocco",
    ],
  },
  {
    name: "Invio",
    phrases: [
      "Troppa gente in questa festa.®",
      "Il giardino, lo sai, è ben curato.®",
      "Non è venuto a sentire il concerto.®",
      "Spesso chi si lamenta sta bene.®",
      "Chiudi la finestra, ho freddo.®",
      "Oggi è una bella giornata di sole.®",
      "Non amo l'inverno, voglio il sole.®",
      "Oggi ho mangiato un buon pollo.®",
      "Domenica andremo a trovare i nonni.®",
      "Spero arrivi presto Natale.®",
      "Mi piace scrivere con il computer.®",
      "Alla mattina ho sempre molto sonno.®",
      "La sera non voglio andare a letto.®",
      "Suona il campanello, vai ad aprire.®",
    ],
  },
  {
    name: "7",
    phrases: [
      "Il 7 aprile vengo a trovarti.",
      "Alla corsa partecipano 77 concorrenti.",
      "Qualcuno considera il 7 un numero perfetto.",
      "Rivera giocava con la maglia numero 7.",
      "Alle superiori 7 era un bel voto.",
      "Con sole 7 note si possono fare tante musiche.",
      "Alla mattina mi alzo alle 7 per andare a scuola.",
      "Prende il treno delle 7 e un quarto.",
      "Per gli antichi 7 volte 7 era un'enormità.",
      "Abita a 7 chilometri di distanza.",
      "Una frittata con 7 uova.",
      "Un numero di telefono facile da ricordare è 777777.",
      "Roma è costruita su 7 colli.",
      "Alle 7 di sera ormai è già buio.",
    ],
  },
  {
    name: "8",
    phrases: [
      "Dopo il 7 viene il numero 8.",
      "La tavola era preparata per 8 invitati.",
      "Abito in via Roma al numero 88.",
      "Alle 8 il traffico è terribile.",
      "Sembra piccolissimo ma ha 8 anni.",
      "Non so quanto valgano questi 8 dollari.",
      "Questa canzone dura 8 minuti.",
      "Un libro di 78 pagine.",
      "Sono le 7 e 8 minuti.",
      "Mio papà è alto un metro e 87 centimetri.",
      "Io dico che non può tenere in casa 8 gatti.",
      "Alla fine della corsa sono arrivati solo in 8.",
      "Devo prendere l'autobus numero 88.",
      "Ha preso 8 in storia e 7 in scienze.",
    ],
  },
  {
    name: "9",
    phrases: [
      "Dopo il numero 8 c'è il 9.",
      "Ripeti il numero 789.",
      "Da 9 anni non facevamo una festa così.",
      "Domani è il 9 ottobre.",
      "Un palazzo di 9 piani.",
      "Domani alle 9 ti vengo a trovare.",
      "Il numero 89 è maggiore di 79.",
      "Ma 999999 non è un milione.",
      "Se siamo solo in 9 non si gioca a calcio.",
      "Un cesto con 9 mele.",
      "Un pranzo con 9 portate.",
      "Ricordati di telefonare al 799989",
      "Dicono che un cane di 9 anni sia molto vecchio.",
      "Ho 9 cugini e 8 zii.",
    ],
  },
  {
    name: "0",
    phrases: [
      "Il numero zero si scrive 0.",
      "Questa maglia costa 70.000 lire.",
      "Il famoso agente 007.",
      "Dopo il numero 799 c'è l'800.",
      "Anche questa partita è finita 0 a 0.",
      "Il termometro è sceso sotto 0.",
      "Mi servono subito 900.000 lire.",
      "Il tavolo è alto 90 centimetri.",
      "Non vendo a meno di 808.000 lire.",
      "C'erano 800 posti in quel teatro.",
      "Il Monte Everest è alto più di 8.000 metri.",
      "Una metropoli di 7.000.000 di abitanti.",
      "Anche se aveva 800 pagine l'ho letto tutto d'un fiato.",
      "Questa rivista costa 8.700 lire.",
    ],
  },
  {
    name: "/",
    phrases: [
      "Sette noni ovvero 7/9.",
      "La mia data di nascita è 09/07/99.",
      "Dimmi se 8/9 è maggiore di 7/8.",
      "La barra è sopra al numero 7.",
      "Il carattere barra si chiama anche segno di frazione.",
      "7/8, 77/88 e 777/888 sono tra loro equivalenti.",
      "Il carattere / viene usato anche come segno di divisione.",
    ],
  },
  {
    name: "()",
    phrases: [
      "( è il segno di aperta parentesi.",
      ") è il segno di chiusa parentesi.",
      "Il Marco (moneta tedesca) vale circa 998 lire.",
      "Vieri (Inter) ieri non ha segnato.",
      "Ho un PC (Personal Computer) è un po' vecchiotto.",
      "Dalla mia casa (settimo piano) vedo tanti tetti.",
      "Era Marco (non Luigi) quello che hai incontrato ieri.",
      "Marcello (il maestro) oggi era molto contento.",
      "Il nonno compie gli anni (87) e faremo una bella festa.",
      "La sua auto (una vecchia Fiat) non va più bene.",
      "Vieste (sul Gargano) ha un mare stupendo.",
    ],
  },
  {
    name: "=",
    phrases: [
      "Il simbolo di uguale è =",
      "8=8 e 9=9",
      "Il tasto = è sopra quello dello 0.",
      "7/8 = 77/88",
      "Il simbolo = significa uguale.",
      "Naturalmente 978=978 e 80=80.",
      "A volte si usa = anche per la divisione in sillabe.",
    ],
  },
  {
    name: "6",
    phrases: [
      "Eravamo in 6 amici.",
      "La squadra di pallavolo è composta di 6 giocatori.",
      "Abita al numero 66 di via Verdi.",
      "Mi servono 6.000 lire.",
      "Aprire il libro a pagina 86.",
      "Ha vinto il giocatore con la maglia numero 6.",
      "In maggio, il giorno 6, compie 6 anni.",
      "Il 6 gennaio arriva la Befana.",
      "Domenica il nonno compie 68 anni.",
      "Questi spaghetti cuociono in 6 minuti.",
      "Gli telefona 6 volte al giorno.",
      "Telefonami al numero 06 7866866.",
      "Ci vorrebbe un 6 al SuperEnalotto.",
      "Ha preso 6 e mezzo ma lui si aspettava almeno un 7.",
    ],
  },
  {
    name: "5",
    phrases: [
      "Una moneta da 500 lire.",
      "Una banconota da 5.000 lire.",
      "Domani è il 5 ottobre.",
      "Pesa solo 55 chili.",
      "Se compi 5 anni ci vogliono 5 candeline.",
      "Ogni 5 minuti suonava la sirena.",
      "Se siamo in 6, 5 sedie non bastano.",
      "Chi indovina 5 numeri fa cinquina.",
      "Hanno vinto 5 a 0, un vero trionfo.",
      "Devo cambiare questa banconota da 50.000 lire.",
      "Canale5 mi piace ma c'è troppa pubblicità.",
      "Ogni giorno per allenarsi fa 5 chilometri di corsa.",
      "Domani mi alzo alle 5 per andare a pescare.",
      "Abita in via Roma al numero 5",
    ],
  },
  {
    name: "4",
    phrases: [
      "44 gatti in fila per 6 con il resto di due.",
      "40 cani in fila per 4 con il resto di 0.",
      "A carte si gioca bene in 4.",
      "Un'automobile da 4 posti.",
      "Nel vaso c'erano 4 rose rosse.",
      "444.444 è un numero di telefono facile da ricordare.",
      "8 per 8 fa 64.",
      "Mi servono 4 quaderni nuovi.",
      "Le 4 gambe del tavolo",
      "Mio papà ha 44 anni.",
      "Si chiamano quadrupedi gli animali con 4 zampe.",
      "Un libro di 400 pagine.",
      "Le automobili hanno 4 ruote.",
      "Un paese di 540 abitanti.",
    ],
  },
  {
    name: "3",
    phrases: [
      "I 3 moschettieri veramente erano 4.",
      "Mi hanno regalato 3 dischi nuovi.",
      "Coi suoi piedoni usa scarpe numero 43.",
      "33 trentini trottavano verso Trento.",
      "Il 3 è un numero importante.",
      "Molti mesi hanno 30 giorni.",
      "il 3 è un numero dispari.",
      "L'autobus numero 3 è appena passato.",
      "Una casetta con solo 3 finestre.",
      "Il triciclo ha 3 ruote.",
      "Qui una bibita costa 3.000 lire.",
      "In classe siamo quasi in 30.",
      "Viene a casa mia oggi alle 3 e mezza.",
      "Ha preso un pesce di oltre 3 chili.",
    ],
  },
  {
    name: "2",
    phrases: [
      "Il 2 è il primo numero pari.",
      "Il 25 dicembre si festeggia il Natale.",
      "Una moneta da 2.000 lire.",
      "Marco ha 2 fratelli e una sorella.",
      "Mi servirebbero 200.000 lire.",
      "Se ve ne andate anche voi rimaniamo in 2.",
      "C'erano due passerotti sul ramo.",
      "Un cesto con 3 mele e 2 pere.",
      "Abbiamo 2 mani e 2 piedi.",
      "Abbiamo 2 occhi e 2 orecchie.",
      "Aveva un'auto sportiva con soli 2 posti.",
      "42 gradi all'ombra, proprio un caldo insopportabile.",
      "Il viaggio in treno durava circa 2 ore e 20 minuti.",
      "Il tandem è una bicicletta a 2 posti.",
    ],
  },
  {
    name: "1",
    phrases: [
      "Il numero 1",
      "Per chiamare la polizia usa il 113.",
      "Un mezzo si può scrivere anche 1/2.",
      "Sappiamo che 7/7=1, 8/8=1 e 9/9=1.",
      "Oggi è il 12/10/1999.",
      "Il 10/06/1940 l'Italia entrò in guerra.",
      "Per chiamare i carabinieri usa il 112.",
      "L'anno 1199 è l'ultimo del secolo.",
      "Garibaldi e i suoi 1.000 garibaldini.",
      "Una moneta da 100 lire.",
      "A calcio si gioca in 11 per squadra.",
      "Persero la partita per 4 a 1",
      "Ci vediamo alle 11 in punto.",
      "La montagna era alta esattamente 3111 metri.",
      "Nel 1918 finì la prima guerra mondiale.",
      "Mario è nato 10/11/1991.",
      "Arrivò primo tra 191 concorrenti.",
      "Aprite il libro a pagina 151.",
    ],
  },
  {
    name: '"',
    phrases: [
      'Questo è il simbolo delle virgolette ".',
      '"Il dado è tratto" disse Cesare.',
      'Il suo soprannome era "Stecchino".',
      '"Vieni subito qui" disse la mamma.',
      'Si dice che "Can che abbaia non morde".',
      'Il tasto delle " è sopra a quello del 2.',
      'Sul cancelletto era scritto "Attenti al cane".',
      '"Stop" gridò il poliziotto, ma il ladro scappò.',
      'Dimmi che cosa vuol dire, secondo te, la parola "amicizia".',
    ],
  },
  {
    name: "!",
    phrases: [
      "Fermi tutti!",
      "Aiuto! Il leone è scappato dalla gabbia!",
      "Questo quadro è meraviglioso!",
      "Ah! Che splendida gita!",
      "Bello! Veramente bello! Complimenti!",
      "Bene! Bravo! Bis!",
      "Evviva Natale! La festa più bella che ci sia!",
      "Tanti auguri! Buon compleanno!",
    ],
  },
  {
    name: "+",
    phrases: [
      "Il segno + indica l'addizione.",
      "12+4=16",
      "Il termometro segnava +2 gradi.",
      "Se sai quanto fa 5+5, rispondi!",
      "765.798 + 562.657 è un numero troppo difficile per me!",
      "Calcola 1+3+7+4+9+2+5+8+6",
      "Se 12+45 fa 57, anche 45+12 fa 57.",
    ],
  },
  {
    name: "-",
    phrases: [
      "Il segno - indica la sottrazione.",
      'Il segno - viene chiamato spesso "meno".',
      "calcola 100-10",
      "Che freddo! Saranno -10 gradi!",
      "Ecco una facile sottrazione 10-5.",
    ],
  },
  {
    name: "jJ",
    phrases: [
      "La lettera J si chiama anche i lunga.",
      "Il jet è un aereo molto veloce.",
      "Gennaro ha chiamato la figlia Jessica.",
      "Scrivi Jules e Jim, non Giules e Gim.",
      "La J è la decima lettera dell'alfabeto.",
      "A papà piace moltissimo la musica jazz.",
      "Qualcuno, per favore, chiami Jacopo.",
    ],
  },
  {
    name: "kK",
    phrases: [
      "Il carattere k si chiama cappa.",
      "Digita il tuo nome prima di cliccare su OK.",
      "Mi piacciono molto le merendine Kinder.",
      "La K è l'undicesima lettera dell'alfabeto.",
      "Alla sera giochiamo spesso a poker.",
      "Quando il pugile finisce KO, ha perso l'incontro.",
      'La sigla "CD" significa "Compact Disk"',
      "Il disco fisso del computer si chiama anche Hard Disk.",
    ],
  },
  {
    name: "wW",
    phrases: [
      "Il carattere w si chiama vu doppia.",
      'Il carattere W viene usato come segno di "Evviva!".',
      'Il programma "Typing Trainer" funziona in Windows.',
      "Welcome, vuol dire benvenuto.",
      "La W è la ventitreesima lettera dell'alfabeto.",
      "A me piacciono molto i kiwi.",
      "Water in inglese significa acqua.",
      "Come merenda Walter porta spesso dei wafer.",
    ],
  },
  {
    name: "xX",
    phrases: [
      "La lettera x si pronuncia ics.",
      "Tuo papà porta la XL o la XXL.",
      "Ieri ho mangiato dei pasticcini extra.",
      "Nel totocalcio la X indica il pareggio.",
      "La X è la ventiquattresima lettera dell'alfabeto.",
      "Nei numeri romani X significa dieci, XX venti.",
      "Giacomo mi ha spedito un fax di 4 pagine.",
    ],
  },
  {
    name: "yY",
    phrases: [
      "La lettera Y si chiama ipsilon o i greca.",
      "New York è famosa per i suoi grattacieli.",
      'Per ascoltare il CD, premi il pulsante "Play".',
      "La Y è la ventiquattresima lettera dell'alfabeto.",
      "Mary mi ha regalato un bel yo-yo.",
    ],
  },
  {
    name: "&",
    phrases: [
      'Il simbolo & si chiama "e commerciale".',
      'I famosi soci "Frank & William".',
      "Il supermercato A&O.",
      "La famosa coppia Tom & Jerry.",
    ],
  },
  {
    name: "%",
    phrases: [
      'Il simbolo % significa "per cento".',
      "Un prestito al 5% d'interessi.",
      "Sono stati promossi al 100%.",
      "Dire 50% è come dire metà",
      "Le vittorie sono passate dal 44% al 78%.",
    ],
  },
  {
    name: "<>",
    phrases: [
      'Il simbolo > significa "maggiore".',
      "Sappiamo che 100 > 90.",
      'Il simbolo < significa "minore".',
      "Naturalmente 45 < 50.",
      "Tutti i numeri <0 sono negativi.",
    ],
  },
  {
    name: "*",
    phrases: [
      "Il segno * si chiama asterisco",
      "Spesso nei computer * è il simbolo della moltiplicazione",
      "Mettere *** significa non volere dire il nome.",
      "Calcola 4*3",
    ],
  },
  {
    name: "@",
    phrases: [
      'Il carattere @ si chiama "chiocciola"',
      "Il simbolo @ è oggi molto usato negli indirizzi internet.",
      'Qualcuno chiama @ "at", ovvero "presso".',
      "Scrivimi all'indirizzo pinco.pallino@tin.it",
      "La mia email è: garibaldi@libero.it",
      "@ si ottiene con Alt Gr e il tasto ò",
    ],
  },
  {
    name: "#",
    phrases: [
      "Il simbolo # si chiama cancelletto.",
      "Il simbolo # si chiama anche diesis.",
      "Il simbolo # non è molto usato nei testi normali.",
      "Per ottenere il # deve usare il tasto Alt Gr.",
      "# si ottiene con Alt Gr e il tasto à.",
    ],
  },
  {
    name: "$",
    phrases: [
      "Il simbolo $ indica il dollaro.",
      "Il simbolo $ viene usato soprattutto in campo commerciale.",
      "Paperon de Paperoni ha come stemma il carattere $.",
      "Il simbolo $ si trova in tastiera sopra al 4.",
      "Una banconota da 100$",
    ],
  },
  {
    name: "£",
    phrases: [
      "Il simbolo £ indica la lira sterlina.",
      "Il simbolo £ viene anche usato per la lira italiana.",
      "Sopra al numero 3 si trova il carattere £.",
      "Un assegno da £ 2.000.000",
    ],
  },
  {
    name: "\\",
    phrases: [
      "Nella tastiera c'è anche il carattere \\.",
      'Il carattere \\ viene chiamato "barra rovescia"',
      "Le due barre, / e \\, sono tra loro simmetriche.",
      "Il tasto con il simbolo \\ si trova in alto a sinistra.",
      "Il simbolo \\ è molto usato in DOS.",
    ],
  },
  {
    name: "_",
    phrases: [
      "Il carattere _ indica il trattino basso o sottolineato.",
      "Il carattere _ si trova sopra il trattino normale -.",
      "Si usa spesso _ per unire due parole.",
      "Il carattere _ non è molto usato nei testi normali.",
    ],
  },
  {
    name: "[]",
    phrases: [
      "Le parentesi quadre si indicano con [].",
      "[ è la parentesi quadra aperta.",
      "] è la parentesi quadra chiusa.",
      "Le parentesi [ e ] si usano spesso in matematica.",
      "Calcola: 4-[(6+3)/3]",
      "Per ottenere i caratteri [] si usa il tasto Alt Gr.",
      "[ si ottiene con Alt Gr e il tasto è",
      "] si ottiene con Alt Gr e il tasto +",
    ],
  },
  {
    name: "{}",
    phrases: [
      "I simboli {} rappresentano le parentesi graffe.",
      "I simboli {} sono molto usati in matematica.",
      "Per ottenere il simbolo { si usa Ctrl Alt Shift e il tasto è",
      "Per ottenere il simbolo } si usa Ctrl Alt Shift e il tasto +",
      "{ è la parentesi graffa aperta",
      "} è la parentesi graffa chiusa",
    ],
  },
  {
    name: ":",
    phrases: [
      'Il simbolo : è detto "due punti"',
      "Trova l'errore: 12>10, 45<35, 41>27",
    ],
  },
  { name: ";", phrases: ['Il simbolo ; è detto "punto e virgola"'] },
  { name: "|", phrases: ['Il simbolo | è detto "pipe"'] },
  {
    name: "?",
    phrases: ["Il simbolo ? si usa al termine delle frasi interrogative."],
  },
  { name: "^", phrases: ["Il simbolo ^ si trova sopra alla lettera ì."] },
  { name: "§", phrases: ["Il simbolo § si trova sopra alla lettera ù."] },
  { name: "ç", phrases: ["Il carattere ç è molto usato in francese."] },
  { name: "°", phrases: ["Il simbolo ° indica i gradi."] },
  {
    name: "Tab",
    phrases: [
      "Nome:→Mario    Cognome:→Rossi",
      "Gennaio→100    Febbraio→200    Marzo→300",
      "Uno→Due→Tre→Quattro",
      "Colonna 1→Colonna 2→Colonna 3",
      "Capitolo 1:→Introduzione e Scopo",
      "Articolo→Quantità    Prezzo→Totale",
      "Tabella:→Riga 1    Dato A→Dato B",
      "Lunedì→Martedì    Mercoledì→Giovedì",
      "Indice:→Capitolo 1    Pagina 10",
      "Italia→Roma    Francia→Parigi    Spagna→Madrid",
      "Punto A→Punto B    Punto C→Punto D",
      "Valore 1→Valore 2    Totale→100%",
      "Prima colonna→Seconda colonna    Terza colonna",
      "Elenco:→Elemento A    Elemento B    Elemento C",
    ],
  },
];

const EMBEDDED_DEMO_PROFILE = {
  UserID: "UTENTE_DEMO",
  Mode: "1",
  Lesson: "1",
  Exercise: "-1",
  AutomaticCorrection: "false",
  ShowKeyBoard: "true",
  ShowHands: "true",
  ShowOrigin: "true",
  ShowTyped: "true",
  MainTop: "83",
  MainLeft: "184",
  StatTop: "80",
  StatLeft: "180",
  StatWidth: "820",
  StatHeight: "600",
  HandsTop: "120",
  HandsLeft: "660",
  HandsPinned: true,
  HandsOffsetTop: 16,
  StatRbGraficoErrorFreq: "false",
  StatRbGraficoVelocita: "true",
  StatRbOrdFrequenzaRel: "false",
  StatRbOrdErroriRelativi: "true",
  StatRbOrdErroriAssoluti: "false",
  StatRbOrdDitoRel: "false",
  StatChkDatiPhrasesAllLetters: "false",
  StatChkDatiPhrasesCustomFile: "false",
  StatChkDatiRandom: "true",
  StatChkDatiTyping: "false",
  StatChkDatiRandomThisPhrase: "false",
  StatChkDatiRandomAllChars: "true",
  StatChkDatiFonemi: "true",
  StatRbOrdFrequenzaAss: "false",
  StatRbOrdDitoAss: "false",
  StatRbGrafBattute: "true",
  StatRbGrafErroriRel: "false",
  StatRbGrafErroriAss: "false",
  StatRbGrafCaratteri: "false",
  TotaleCaratteri: 41700,
  TotaleErrori: 2712,
  Caratteri: [
    { Index: 101, CharUnicode: 64, Frequenza: 276, Errori: 45 },
    { Index: 83, CharUnicode: 232, Frequenza: 317, Errori: 47 },
    { Index: 8, CharUnicode: 33, Frequenza: 284, Errori: 41 },
    { Index: 99, CharUnicode: 167, Frequenza: 268, Errori: 38 },
    { Index: 87, CharUnicode: 249, Frequenza: 293, Errori: 41 },
    { Index: 95, CharUnicode: 233, Frequenza: 278, Errori: 37 },
    { Index: 105, CharUnicode: 125, Frequenza: 272, Errori: 34 },
    { Index: 55, CharUnicode: 89, Frequenza: 280, Errori: 33 },
    { Index: 20, CharUnicode: 90, Frequenza: 268, Errori: 31 },
    { Index: 80, CharUnicode: 242, Frequenza: 288, Errori: 32 },
    { Index: 96, CharUnicode: 176, Frequenza: 270, Errori: 30 },
    { Index: 104, CharUnicode: 123, Frequenza: 281, Errori: 31 },
    { Index: 19, CharUnicode: 83, Frequenza: 290, Errori: 31 },
    { Index: 64, CharUnicode: 107, Frequenza: 274, Errori: 29 },
    { Index: 102, CharUnicode: 93, Frequenza: 269, Errori: 28 },
    { Index: 10, CharUnicode: 81, Frequenza: 283, Errori: 29 },
    { Index: 103, CharUnicode: 35, Frequenza: 276, Errori: 28 },
    { Index: 100, CharUnicode: 91, Frequenza: 280, Errori: 28 },
    { Index: 12, CharUnicode: 62, Frequenza: 273, Errori: 27 },
    { Index: 86, CharUnicode: 43, Frequenza: 275, Errori: 27 },
    { Index: 70, CharUnicode: 48, Frequenza: 312, Errori: 30 },
    { Index: 28, CharUnicode: 88, Frequenza: 283, Errori: 27 },
    { Index: 41, CharUnicode: 38, Frequenza: 275, Errori: 26 },
    { Index: 94, CharUnicode: 94, Frequenza: 275, Errori: 26 },
    { Index: 40, CharUnicode: 67, Frequenza: 286, Errori: 27 },
    { Index: 16, CharUnicode: 122, Frequenza: 339, Errori: 32 },
    { Index: 3, CharUnicode: 50, Frequenza: 276, Errori: 26 },
    { Index: 66, CharUnicode: 41, Frequenza: 276, Errori: 26 },
    { Index: 47, CharUnicode: 121, Frequenza: 268, Errori: 25 },
    { Index: 68, CharUnicode: 75, Frequenza: 279, Errori: 26 },
    { Index: 92, CharUnicode: 231, Frequenza: 272, Errori: 25 },
    { Index: 98, CharUnicode: 42, Frequenza: 284, Errori: 26 },
    { Index: 13, CharUnicode: 51, Frequenza: 279, Errori: 25 },
    { Index: 81, CharUnicode: 46, Frequenza: 393, Errori: 35 },
    { Index: 17, CharUnicode: 163, Frequenza: 271, Errori: 24 },
    { Index: 84, CharUnicode: 224, Frequenza: 286, Errori: 25 },
    { Index: 69, CharUnicode: 77, Frequenza: 277, Errori: 24 },
    { Index: 62, CharUnicode: 57, Frequenza: 289, Errori: 25 },
    { Index: 76, CharUnicode: 76, Frequenza: 291, Errori: 25 },
    { Index: 24, CharUnicode: 120, Frequenza: 280, Errori: 24 },
    { Index: 52, CharUnicode: 106, Frequenza: 271, Errori: 23 },
    { Index: 78, CharUnicode: 39, Frequenza: 299, Errori: 25 },
    { Index: 14, CharUnicode: 119, Frequenza: 276, Errori: 23 },
    { Index: 85, CharUnicode: 45, Frequenza: 276, Errori: 23 },
    { Index: 73, CharUnicode: 44, Frequenza: 317, Errori: 26 },
    { Index: 90, CharUnicode: 63, Frequenza: 270, Errori: 22 },
    { Index: 7, CharUnicode: 124, Frequenza: 273, Errori: 22 },
    { Index: 33, CharUnicode: 54, Frequenza: 282, Errori: 22 },
    { Index: 18, CharUnicode: 87, Frequenza: 283, Errori: 22 },
    { Index: 82, CharUnicode: 236, Frequenza: 297, Errori: 23 },
    { Index: 60, CharUnicode: 74, Frequenza: 272, Errori: 21 },
    { Index: 93, CharUnicode: 58, Frequenza: 286, Errori: 22 },
    { Index: 97, CharUnicode: 95, Frequenza: 276, Errori: 21 },
    { Index: 26, CharUnicode: 69, Frequenza: 276, Errori: 21 },
    { Index: 6, CharUnicode: 60, Frequenza: 280, Errori: 21 },
    { Index: 27, CharUnicode: 68, Frequenza: 281, Errori: 21 },
    { Index: 39, CharUnicode: 70, Frequenza: 268, Errori: 20 },
    { Index: 0, CharUnicode: 92, Frequenza: 269, Errori: 20 },
    { Index: 50, CharUnicode: 56, Frequenza: 302, Errori: 22 },
    { Index: 49, CharUnicode: 98, Frequenza: 362, Errori: 26 },
    { Index: 61, CharUnicode: 78, Frequenza: 283, Errori: 20 },
    { Index: 77, CharUnicode: 59, Frequenza: 270, Errori: 19 },
    { Index: 59, CharUnicode: 85, Frequenza: 285, Errori: 20 },
    { Index: 4, CharUnicode: 113, Frequenza: 305, Errori: 21 },
    { Index: 42, CharUnicode: 84, Frequenza: 277, Errori: 19 },
    { Index: 1, CharUnicode: 49, Frequenza: 280, Errori: 19 },
    { Index: 56, CharUnicode: 72, Frequenza: 266, Errori: 18 },
    { Index: 79, CharUnicode: 112, Frequenza: 494, Errori: 33 },
    { Index: 67, CharUnicode: 73, Frequenza: 305, Errori: 20 },
    { Index: 91, CharUnicode: 80, Frequenza: 278, Errori: 18 },
    { Index: 36, CharUnicode: 118, Frequenza: 408, Errori: 26 },
    { Index: 37, CharUnicode: 37, Frequenza: 273, Errori: 17 },
    { Index: 25, CharUnicode: 36, Frequenza: 275, Errori: 17 },
    { Index: 75, CharUnicode: 79, Frequenza: 280, Errori: 17 },
    { Index: 44, CharUnicode: 86, Frequenza: 286, Errori: 17 },
    { Index: 38, CharUnicode: 82, Frequenza: 276, Errori: 16 },
    { Index: 54, CharUnicode: 47, Frequenza: 278, Errori: 16 },
    { Index: 43, CharUnicode: 71, Frequenza: 281, Errori: 16 },
    { Index: 9, CharUnicode: 34, Frequenza: 293, Errori: 16 },
    { Index: 30, CharUnicode: 114, Frequenza: 793, Errori: 43 },
    { Index: 15, CharUnicode: 115, Frequenza: 703, Errori: 38 },
    { Index: 31, CharUnicode: 102, Frequenza: 398, Errori: 21 },
    { Index: 11, CharUnicode: 65, Frequenza: 289, Errori: 15 },
    { Index: 21, CharUnicode: 52, Frequenza: 292, Errori: 15 },
    { Index: 23, CharUnicode: 100, Frequenza: 511, Errori: 26 },
    { Index: 46, CharUnicode: 55, Frequenza: 375, Errori: 19 },
    { Index: 63, CharUnicode: 105, Frequenza: 1184, Errori: 59 },
    { Index: 74, CharUnicode: 61, Frequenza: 281, Errori: 14 },
    { Index: 71, CharUnicode: 111, Frequenza: 996, Errori: 49 },
    { Index: 48, CharUnicode: 104, Frequenza: 357, Errori: 17 },
    { Index: 35, CharUnicode: 103, Frequenza: 465, Errori: 22 },
    { Index: 2, CharUnicode: 8594, Frequenza: 1049, Errori: 49 },
    { Index: 65, CharUnicode: 109, Frequenza: 471, Errori: 22 },
    { Index: 29, CharUnicode: 53, Frequenza: 285, Errori: 13 },
    { Index: 57, CharUnicode: 66, Frequenza: 275, Errori: 12 },
    { Index: 22, CharUnicode: 101, Frequenza: 1068, Errori: 45 },
    { Index: 34, CharUnicode: 116, Frequenza: 759, Errori: 31 },
    { Index: 5, CharUnicode: 97, Frequenza: 1328, Errori: 45 },
    { Index: 58, CharUnicode: 40, Frequenza: 278, Errori: 9 },
    { Index: 72, CharUnicode: 108, Frequenza: 859, Errori: 27 },
    { Index: 51, CharUnicode: 117, Frequenza: 514, Errori: 15 },
    { Index: 32, CharUnicode: 99, Frequenza: 556, Errori: 16 },
    { Index: 53, CharUnicode: 110, Frequenza: 808, Errori: 17 },
    { Index: 89, CharUnicode: 174, Frequenza: 2194, Errori: 42 },
    { Index: 45, CharUnicode: 32, Frequenza: 1817, Errori: 24 },
    { Index: 88, CharUnicode: 8592, Frequenza: 0, Errori: 0 },
  ],
  Campioni: [],
};

const EMBEDDED_CUSTOM_DEFAULT =
  '=====Intero Alfabeto=====\nabcdefghijklmnopqrstuvwxyz\nABCDEFGHIJKLMNOPQRSTUVWXYZ\n\u00f2\u00f9\u00e0\u00ec\u00e8\u00e9\n1234567890\n<>=    +-*/()[]{}\n.,:    ;?!\n\'^\u00a7"\\    |_@ #\u00e7\u00b0\u00a3$%&\n=====Mignolo Destro=====\n\u00a7}_\u00ec\u00a7{^]+*\u00b0\u00e8\n*#\u00e0-\u00e8\n+*\u00e8]\u00e9{\u00b0?\u00f2\u00e7\n\u00e0\u00e8*\u00f9]#@{\u00e0\u00e8*\n\u00ec\u00a7{^\u00e9[+\u00e8\n\u00f9]\u00a7{^]{^[+\u00e8]\u00b0\n\u00e9{{[\u00a7}\u00e8{[\'+_\u00ec\u00e9[+\u00e8\n\u00f9]\u00a7{^\u00b0]\u00a7{^]+*\u00e8\n\u00e9{[\'+*\u00e8{?\u00f2\u00e7\n\u00e0\u00e8*\u00b0\u00f9]#\u00e0-\u00e8\n+*\u00e8#@{\u00e0\u00e8*\n\u00ec\u00a7{^\u00b0]^[+\u00e8]\n\u00e9{[\u00b0\n=====Mignolo Sinistro=====\n\\q!2    "Qa<|1A>\n"    \\<2Q|Aq!a>1\n><2A|"Q!\\a1    q\n|!2Q    1A<">\\qa\n=====Mignoli=====\n?\u00e0    \u00f9Z.\u00b0+\u00e9^{1\\z#2:@q]>|\u00e8*x[A\'\u00f2"\u00a7}\u00a3\u00eca\u00e7<-!_\n\u00b0*    \u00e9a[-!x\u00f2_\u00a3}<:^{#\'1zA?\u00ec@2\u00a7]+Z\u00e7\u00e0".q>\\\u00e8|\n>-q\\\u00e9@"*x    |\u00e8}_<.\u00f2[!^{2\u00e7:#\u00a3\u00ec]Z\u00e0?\u00b0Az\u00f9+1\u00a7\'a\n=====Mignolo e Anulare Destro=====\n]\'p0P;*_^\u00a7\u00f2\u00b0\u00e7\u00ec\u00e8=+l[\u00e0,#.\u00f9-{o@}?L\u00e9O:\n#.\u00f9-\u00b0\u00e7?L;*_^\u00a7]\'\u00f20{o@p\u00ec\u00e8+\u00e9O:}=Pl[\u00e0,\n\u00e8+l]\'\u00f20{o@p[\u00e0,\u00f9-}=P#\u00a7\u00b0\u00e7?L\u00e9O:\u00ec.;*_^\n=====Mignolo Anulare Sinistro=====\n\\qs!2w"QZza    <|W1A>3\u00a3S\n"3\\W<2    1zSswQ|A\u00a3q!a>Z\n><\u00a32sZAq3w|a1"SzQ    !\\W\n|q!    2w\u00a3QZ1A<WS"3sz>\\a';

const EMBEDDED_FONEMI_CORPUS =
  "sala falsa \n dalla sala \n falsa falla \n salda la falla \n la falla salda \n fa la sala \n la fa dalla sala \n la salsa falsa \n fa la salsa \n la salsa salda \n falla salda la salsa \n la falda salsa \n sala da salsa \n salda salda \n sa da salsa \n falla la salsa \n sala la salsa \n ala salda \n afa falsa \n falsa afa \n fa la falsa \n ala a galla \n afa a galla \n fa la glassa \n allaga la sala \n la daga a galla \n la daga falsa \n falsa la glassa \n la glassa falsa \n a galla \n salga la falda \n falla la daga \n salga a galla \n la falsa daga \n falla la glassa \n la falsa falla \n salsa alla glassa \n alla sala falsa \n alga a galla \n alga salga a galla \n alga salga la falda \n alga allaga la sala \n falsa alga \n falsa saga \n la saga glassa \n la saga fa la glassa \n ha la salsa \n ah la glassa \n ha la daga \n ha la falla \n ha la daga falsa \n ha la sala \n i dadi lisi \n fili di giada \n salsa gialla \n figlia saggia \n falsi saggi \n dadi di ghisa \n fila di gigli gialli \n fila di laghi \n la giada falsa \n i fidi asili \n i gigli gialli \n fila di ghiaia \n ha dadi fissi \n i fili fissi \n i falsi affissi \n falsi figli \n falsi assilli \n figli di faggi \n figli di ghisa \n gli dissi \n i fili gialli \n ghiaia gialla \n faggi di laghi \n la dalia gialla \n hai falsi fili di giada \n soldi falsi \n la glassa fa gola \n loda la folla \n filo di olio \n falso saggio \n foglia di faggio \n dado di ghisa \n odio il giglio \n salgo da solo \n odia i fagioli \n loda la folla \n la sfoglia fa gola \n il figlio fa gola \n il figlio soffia \n odio i dadi \n oggi ha lodato \n saggia follia \n assaggia i fagioli \n ha solo lodi \n aglio o olio \n i soldi gialli \n soldi falsi \n lodi di figlia \n il figlio sloggia \n il foglio giallo \n la foglia di faggio \n filo giallo \n salsa di olio \n oggi ha solo fagioli \n le foglie dei faggi \n sedie di faggio \n la sedia di ghisa \n le figlie fedeli \n le sedie delle figlie \n egli ha fede \n leghe di ghisa \n le sedi delle leghe \n idea fedele \n seggio fisso \n le folli daghe \n egli fa follie \n giogo folle \n ha delle false lodi \n le foglie folli \n il sole e la foglia \n ella si siede \n se si sedesse \n egli fa fallo \n sei sedie gialle \n le foglie al gelo \n aghi e fili \n file di foglie \n offesa dalle figlie \n laghi al gelo \n egli ha sei figlie \n le foglie gialle \n palla di ghisa \n olio e seppie \n pelle di pollo \n il pollo passa \n gli passo la palla \n si posa la foglia \n seppie e pollo \n i passi folli \n olio a galla \n le spalle della sposa \n la palla galleggia \n la sedia di paglia \n il piede del figlio \n la sposa fedele \n egli ha la pialla \n egli ha la pila \n il poggiolo fisso \n il figlio pallido \n giallo pallido \n la palla gialla \n pila di fogli \n polpa di pollo \n la foglia di pioppo \n pioppi e faggi \n doppio fallo \n osso di seppia \n salsa di pollo \n la pillola gialla \n olio e lardo per friggere \n perdere la palla per il fallo \n le farfalle sopra i gigli \n fiori gialli tra le rose \n saper perdere la gara \n il paggio del re \n era il regalo del re \n orrore per il freddo \n freddo e gelo alla sera \n il grosso pioppo \n era pallido e fragile \n dire delle frasi assai serie \n sorridere ai fiori \n sei di fiori \n le farfalle gialle \n presi dal desiderio \n farsi pregare \n perdere a dadi \n fare dei progressi \n progredire e salire \n il golf grigio perla \n freddo polare \n pregare di sera \n preferire fiori rari \n sedie di pregio \n sopra le pere \n aria fresca \n ferro e ghisa \n troppi grappoli nel piatto \n le proteste dei tifosi \n le trote del lago \n la grotta dei pipistrelli \n trippe e fagioli \n lo sparo della pistola \n egli le apre la porta \n il pregio del posto \n la serata era gelida \n fare delle ripide salite \n petrolio greggio \n trasportare dei grossi sassi \n il fragile trasporto \n ripido tratto di salita \n tradire per i soldi \n essere triste e poi lieto \n in attesa della paga \n la talpa sta sotto terra \n essere di fretta \n la trappola per i topi \n il tetto di paglia \n il posto di ristoro \n il gelato alla fragola \n la torta alle fragole \n lo stato estero \n era la stessa storia \n errore di tiro \n il test era errato \n fuggire di sera \n il passato e il futuro \n il gusto di leggere \n autore del furto \n la lunga giostra \n il fusto del pioppo \n la foglia sulla strada \n auto proprio lurida \n sei fedeli segugi \n luogo di preghiera \n era proprio tutta sudata \n era ladro e truffatore \n opera di autore russo \n perdere tutto ai dadi \n i trulli pugliesi \n sul fiore o sulla foglia \n il tratto superiore \n freddo da lupi \n odio e furore \n arresto per truffa \n profugo dalla russia \n gruppo di pugili \n il luogo dei giusti \n resti di frustate alle spalle \n luoghi luridi e fetidi \n il prete e la suora \n le spalle sussultavano dal ridere \n il gufo sopra il tetto \n pare che legga il futuro \n tanti panni stesi \n un pugnale affilato \n funghi saporiti \n lunghe file alle poste \n il ponte non regge \n polenta e funghi \n un lungo ponte \n lontano dalla gente \n una nonna proprio generosa \n una figlia gentile \n una gustosa frittella \n dare in prestito \n un piede ingessato \n un testo assai interessante \n una idea geniale \n un ingenuo figliolo \n un trucco infantile \n prendere tutto sul serio \n un pasto frugale \n una pioggia assai fastidiosa \n non aspettare in piedi \n pantaloni tutti infangati \n una alunna interessata \n lei non sta attenta \n un passerotto infreddolito \n insoddisfatto del suo postino \n non sentire niente \n uno spettatore incredulo \n giocare tutti a calcio \n una ciocca di capelli \n accendere un cero in chiesa \n non le piace accendere il fuoco \n leccare con gusto il gelato \n una coppa di gelato al cacao \n cocciuto e ostinato \n chi prima rideva adesso piange \n un chiodo arrugginito \n un pericoloso incidente stradale \n far cessare ogni eccesso \n un sincero confidente \n tu non sai cosa mi ha detto \n ci piacciono le coscie di pollo \n un frastuono incessante \n il cappotto era fradicio per la pioggia \n un esercito di galline \n pulisciti le orecchie \n farsi una doccia calda \n stare con le orecchie tese \n non nasconderti con la maschera \n chiedi le chiavi di casa \n chi ha un cruccio si sfoga \n andare a caccia di cinghiali \n il cagnolino sta nella cuccia \n sta a casa con gli orecchioni \n dei sacchi di ceci \n una macchia di inchiostro \n mi manda la mamma \n un mostro immondo \n ama molto la mamma \n immagina che giunga un mago \n una camera da letto molto ampia \n meglio imparare la matematica \n se hai male chiama il medico \n non mi piace la medicina amara \n se ha miagolato non era una mucca \n se ha muggito non era un gatto \n di studiare non le importa molto \n amo molto la montagna \n un campo di mais e uno di frumento \n stare immersa nel mare \n scimmie ammaestrate al circo \n la scimitarra del sultano \n impara a suonare il mandolino \n era partita con molti rimpianti \n occorre mettere ancora molto sale \n immagina di stare meglio \n molto rumore per nulla \n mille moscerini sulla macchina \n mangia maccheroni al sugo \n una matita affilatissima \n la maschera di ferro \n mai dire mai \n mi tocca mangiare la minestra \n porta fuori le immondizie \n mi piace molto la pizza \n gioca con pazienza e furbizia \n in piazza ci sono molte persone \n un fazzoletto con il pizzo \n dei mercanti in cerca di spezie \n era mezzo morto di paura \n non era una piazza molto spaziosa \n dei pezzi di pesce molto puzzolenti \n gli si rizzavano i capelli in testa \n spezzava i rami con ogni mezzo \n un tizzone acceso nel caminetto \n era molto amato dalle zie \n meglio la prudenza che la pazzia \n si sente una puzza pazzesca \n la tazza si ruppe in mille pezzi \n si azzuffano in mezzo alla piazza \n il mercato si fa in piazza \n la mazza da golf di mio zio \n andiamo pazzi per la pizza \n una stanza spaziosa \n un mazzo di azalee \n una pizza non mi sazia \n con un colpo di mazza si spezza \n attenti al precipizio \n non sempre il giusto sta nel mezzo \n in questa scuola si studia molto \n acqua inquinata in molti fiumi \n un giocatore squalificato \n non era questo il quaderno da portare \n salire le scale quatto quatto \n erano quattro o cinque amici \n era proprio una questione da chiarire \n mi piacciono tutti i quiz \n ricopiare tutto tale e quale \n un quintale di queste mele \n chiede solo acqua minerale frizzante \n esco dopo questo acquazzone \n una questione di interesse \n si era quasi addormentata \n un gesto inqualificabile \n tutto era quieto e silenzioso \n uscire per fare acquisti \n quindici persone qualsiasi \n il quattordici di luglio \n quarantaquattro gatti \n quando saremo in quattro \n un posto proprio tranquillo \n quattro quaderni a quadri \n una questione di quiz \n quasi quasi mangio qui \n preferisco questa acqua \n costa millecinquecento lire \n quasi un quintale di questi quaderni \n un veloce avvio di gara \n con la violenza si fa poca giustizia \n la tigre zoppica ma va a zonzo lo stesso \n mi serve un pezzo di legno \n sperava molto di vincere \n gli avvoltoi volano molto in alto \n pensava spesso ai suoi vecchi amici \n stava sempre vicina al tavolo \n mettiti davanti al tavolino \n non avvicinarti troppo al vetro \n raccontava delle storie avvincenti \n viveva da sola in una vecchia casa \n sapeva inventare storie stupende \n aveva un cagnolino vivacissimo \n sperava di vincere alla lotteria \n era avvilita per non aver vinto nulla \n nevicava da vari giorni \n la vasca del parco era sempre vuota \n un velivolo velocissimo \n una voce cavernosa \n rividi volentieri quel villaggio \n devi diventare veloce nelle divisioni \n sul prato verde fiorivano le viole \n un avvenimento davvero unico \n non avvicinarti al vulcano \n invece di viola lo vorrei verde \n vendere vestiti vecchi \n un vasetto vuoto \n voleva vincere almeno una volta \n cadeva spesso dal tavolo \n devi sviluppare bene questa vicenda \n bevi questa buona bibita \n era una brutta avventura \n basta stare attenti alle buche \n un bravo burattino \n la bilancia era sbilenca \n non buttare via i barattoli \n ha imbucato il biglietto di auguri \n era molto abile con le biglie \n devi sbucciare bene la banana \n non mi piace il brodo bollente \n deve andare ad abitare lontano \n la baracca era tutta bruciata \n attento alla buca vicino al burrone \n bere una bella tazza di latte \n ottimi i biscotti con il burro \n un breve giro nel bosco \n un barattolo di colore blu \n sembra una bella idea cambiare aula \n un dolce di ribes e albicocche \n non disturbare il babbo \n ai bufali piace brucare erba fresca \n un brutto scambio \n era un imbianchino molto bravo \n brontolava e borbottava sempre \n un albero di albicocche \n non mi faccio imbrogliare \n era arrabbiata per quel brutto voto \n bianco rosso e blu \n and\u00f2 via di corsa \n non si pu\u00f2 continuare a discutere \n salt\u00f2 dal treno in corsa \n arriv\u00f2 primo assoluto \n fren\u00f2 in ritardo \n non si pu\u00f2 correre \n togliti pure il palt\u00f2 \n accese un bel fal\u00f2 \n si salvi chi pu\u00f2 \n si ferm\u00f2 e si gir\u00f2 \n and\u00f2 a piedi fino a scuola \n tre civette sul com\u00f2 \n gli tir\u00f2 un sasso addosso \n un albero croll\u00f2 di colpo \n il ramo si spezz\u00f2 \n non si pu\u00f2 continuare \n quanto prima finir\u00f2 \n il campione salt\u00f2 e vinse \n solo un giorno lo sopport\u00f2 \n la barca salp\u00f2 ma non torn\u00f2 \n dopo il naufragio non navig\u00f2 per due anni \n salt\u00f2 al volo dal bus \n la nave aveva cento obl\u00f2 \n non parl\u00f2 con nessuno \n salir\u00f2 fino al terzo piano \n non si pu\u00f2 accendere qui un fal\u00f2 \n arriv\u00f2 un poliziotto e lo arrest\u00f2 \n chiss\u00e0 quando arriver\u00e0 \n correva di qua e di l\u00e0 \n se frena si fermer\u00e0 \n cerc\u00f2 sempre la libert\u00e0 \n piet\u00e0 per i vinti \n chi vivr\u00e0 vedr\u00e0 \n suoner\u00e0 tutta la notte \n la felicit\u00e0 prima di tutto \n non disprezz\u00f2 mai la povert\u00e0 \n la libert\u00e0 non si vende mai \n andr\u00e0 in cerca della felicit\u00e0 \n se non ti muovi nessuno ti aiuter\u00e0 \n se vai l\u00e0 nessuno ti trover\u00e0 \n non mi d\u00e0 mai retta \n rider\u00e0 bene chi rider\u00e0 ultimo \n entr\u00f2 nella cavit\u00e0 del tronco \n quando lo sapr\u00e0 si pentir\u00e0 \n una enorme quantit\u00e0 di terra \n aiutatemi per piet\u00e0 \n arriver\u00e0 in fine la felicit\u00e0 \n una penna di prima qualit\u00e0 \n questo letto ha poca elasticit\u00e0 \n non vincer\u00e0 mai la sua golosit\u00e0 \n chi andr\u00e0 di qua chi di l\u00e0 \n alla fine un eroe li salver\u00e0 \n hai gi\u00e0 avuto due possibilit\u00e0 \n era appeso alle estremit\u00e0 \n una macchina di grande utilit\u00e0 \n non ne posso pi\u00f9 \n lass\u00f9 fa pi\u00f9 freddo \n le vere virt\u00f9 si notano poco \n pi\u00f9 saliva e pi\u00f9 aveva paura \n cadde a testa in gi\u00f9 \n chi pi\u00f9 ne ha pi\u00f9 ne metta \n erano andati tutti laggi\u00f9 \n la virt\u00f9 della carit\u00e0 \n lod\u00f2 le vere virt\u00f9 \n una poltrona di bamb\u00f9 \n non abita pi\u00f9 qui \n salt\u00f2 pi\u00f9 in alto di te \n facciamo una corsa fino a laggi\u00f9 \n una servit\u00f9 pesante \n errori di giovent\u00f9 \n pescava con una canna di bamb\u00f9 \n persona di grandi virt\u00f9 \n pi\u00f9 di qua che di l\u00e0 \n il men\u00f9 del ristorante \n diritto di servit\u00f9 \n quass\u00f9 non si vede nulla \n viaggiare in treno mi piace di pi\u00f9 \n non credo che mentire sia una virt\u00f9 \n la giovent\u00f9 non torna pi\u00f9 \n vai gi\u00f9 e prendimi una bottiglia \n mi piace la musica ind\u00f9 \n per fortuna la schiavit\u00f9 non esiste pi\u00f9 \n stando gi\u00f9 si sentiva qualcosa di pi\u00f9 \n \u00e8 veramente adatto a te \n \u00e8 un buon caff\u00e8 \n erano ventitr\u00e8 amici \n non dirmi ma o cio\u00e8 \n trentatr\u00e8 trentini \n perch\u00e9 faceva tutto da s\u00e8? \n chi fa da s\u00e8 fa per tre \n non \u00e8 bello stare a testa in gi\u00f9 \n \u00e8 andato tutto bene \n si \u00e8 fermato subito \n bench\u00e9 lo sapesse, non lo aiut\u00f2 mai \n questo libro non \u00e8 per te \n chi \u00e8 stanco si fermi \n ahim\u00e8 che disgrazia \n mi piacciono i bign\u00e8 \n ol\u00e8 ol\u00e8 gridavano al torero \n preparava un panino con il pan carr\u00e8 \n ci vediamo alle ore ventitr\u00e8 in punto \n \u00e8 ora di andare in casa \n beviamo un buon caff\u00e8 \n \u00e8 nato nel novantatr\u00e8 \n \u00e8 meglio finire qui \n parlava tra s\u00e9 e s\u00e9 \n il treno non \u00e8 in orario \n una torta di bign\u00e8 \n \u00e8 ora della pausa per il caff\u00e8 \n gli piace fare tutto da s\u00e9 \n non \u00e8 il momento di dire sciocchezze \n \u00e8 un caff\u00e8 speciale \n part\u00ec di corsa \n sal\u00ec le scale \n non fin\u00ec mai il dipinto \n lavorava notte e d\u00ec \n egli diceva sempre s\u00ec \n non stare l\u00ec impalato \n ci vediamo domani a mezzod\u00ec \n vieni via di l\u00ec \n la maestra pun\u00ec tre scolari \n non era l\u00ec che dovevi andare \n sal\u00ec in casa a mezzod\u00ec \n non riusc\u00ec a finire per mezzod\u00ec \n non si sa come fin\u00ec la partita \n ottima la lepre in salm\u00ec \n se spingi ancora non si sposta da l\u00ec \n il volo del colibr\u00ec \n dopo il luned\u00ec viene il marted\u00ec \n fin\u00ec alle nove o gi\u00f9 di l\u00ec \n stai attento se passi di l\u00ec \n fin\u00ec tutto in due minuti \n sta fermo cos\u00ec per qualche minuto \n arriv\u00f2 gioved\u00ec a mezzod\u00ec \n di sicuro non riusc\u00ec a farlo cos\u00ec \n sal\u00ec sulla torre e da l\u00ec lo vide partire \n part\u00ec gioved\u00ec con la nave \n corri a vedere cosa fanno quelli l\u00ec \n aspett\u00f2 l\u00ec da solo tutto il d\u00ec \n rispondimi s\u00ec o no \n la cond\u00ec con olio, aceto e sale \n non si pu\u00f2 perdere, bisogna vincere \n era, sembra, un vero artista \n sentiva, di sera, i grilli cantare \n chi rompe, dice il proverbio, paga \n era, a detta di molti, un vero affare \n sono partiti tutti, anche gli ammalati \n se piove, purtroppo, si bagna tutto \n non \u00e8 vero, sono tutte bugie \n vai piano, la strada \u00e8 scivolosa \n se perdi, non arrabbiarti \n fiorirono rose, gigli e garofani \n studio italiano, matematica e storia \n la notte, dicono, porta consiglio \n mi piace, in particolare, il suono del violini \n io preferisco venerd\u00ec, sabato e domenica \n a scuola, lo sai, si viene per imparare \n \u00e8 bello, quando piove, starsene in casa \n tuoni, lampi, fulmini e saette \n coraggio, mi dissi, devo farcela \n a colazione mangio latte, biscotti e miele \n salta sul carro. \n attenti al lupo. \n la forza delle braccia. \n non si pu\u00f2 sempre correre. \n attenti alle curve. \n la frutta fa bene. \n spegni la televisione. \n suona bene il piano. \n era contento della sua maestra. \n un bel prato pieno di fiori. \n quando piove si sta bene in casa. \n non posso pi\u00f9 uscire di sera. \n mi piace sentire la musica. \n \u00e8 finito il temporale. \n quel treno \u00e8 sempre in ritardo. \n vorrei invitare tutti per il mio compleanno. \n c'erano mele, pere, mandarini e pesche \n suona bene l'armonica \n l'albergo era tutto esaurito \n era un'estate caldissima \n l'incontro \u00e8 andato bene \n sorpass\u00f2 l'avversario ed arriv\u00f2 primo \n l'aspetto era ottimo \n l'ospite \u00e8 ben gradito \n versare l'olio e l'aceto \n \u00e8 un'incredibile avventura \n era l'unica a stare attenta \n \u00e8 l'ideale dei giovani d'oggi \n non c'\u00e8 spazio per l'inganno \n c'era molta fiducia in lui. \n la figlia l'amava moltissimo. \n aveva un po' di fame. \n ce l'aveva un po' con lei. \n c'\u00e8 dell'aranciata o dell'acqua fresca \n Devi fare gli auguri a Sandra. \n Arriveremo presto a Roma. \n Aiuta Elena a fare i compiti. \n Questo treno non va a Como. \n A Roma c'\u00e8 il Vaticano. \n Era il famoso colpo di Zorro. \n Giulio Cesare sconf\u00ecsse i Galli. \n Vicenza \u00e8 una citt\u00e0 del Veneto. \n Tutte le strade portano a Roma. \n Firenze si trova in Toscana. \n Giuseppe Verdi era un musicista. \n Franco abita a Enna, in Sicilia. \n La Francia \u00e8 uno dei pi\u00f9 grandi stati d'Europa. \n Giorgio, Ernesto, Simone e Andrea verranno qui a dormire. \n Il Milione di Marco Polo. \n Un bel viaggio in India. \n Lascia entrare prima Paola. \n Livorno \u00e8 vicina a Pisa. \n Tra Verona e Padova c'\u00e8 Vicenza. \n Un amico di Luigi. \n Grosso incidente a Milano. \n Un nuovo palazzo a Napoli. \n Oggi \u00e8 il compleanno di Laura. \n Freddo polare in Norvegia. \n L'autostrada \u00e8 interrotta a Udine. \n La piet\u00e0 di Michelangelo. \n La capitale della Francia \u00e8 Parigi. \n Un lungo viaggio in Libia e in Marocco \n Troppa gente in questa festa. \n Il giardino, lo sai, \u00e8 ben curato. \n Non \u00e8 venuto a sentire il concerto. \n Spesso chi si lamenta sta bene. \n Chiudi la finestra, ho freddo. \n Oggi \u00e8 una bella giornata di sole. \n Non amo l'inverno, voglio il sole. \n Oggi ho mangiato un buon pollo. \n Domenica andremo a trovare i nonni. \n Spero arrivi presto Natale. \n Mi piace scrivere con il computer. \n Alla mattina ho sempre molto sonno. \n La sera non voglio andare a letto. \n Suona il campanello, vai ad aprire. \n Il 7 aprile vengo a trovarti. \n Alla corsa partecipano 77 concorrenti. \n Qualcuno considera il 7 un numero perfetto. \n Rivera giocava con la maglia numero 7. \n Alle superiori 7 era un bel voto. \n Con sole 7 note si possono fare tante musiche. \n Alla mattina mi alzo alle 7 per andare a scuola. \n Prende il treno delle 7 e un quarto. \n Per gli antichi 7 volte 7 era un'enormit\u00e0. \n Abita a 7 chilometri di distanza. \n Una frittata con 7 uova. \n Un numero di telefono facile da ricordare \u00e8 777777. \n Roma \u00e8 costruita su 7 colli. \n Alle 7 di sera ormai \u00e8 gi\u00e0 buio. \n Dopo il 7 viene il numero 8. \n La tavola era preparata per 8 invitati. \n Abito in via Roma al numero 88. \n Alle 8 il traffico \u00e8 terribile. \n Sembra piccolissimo ma ha 8 anni. \n Non so quanto valgano questi 8 dollari. \n Questa canzone dura 8 minuti. \n Un libro di 78 pagine. \n Sono le 7 e 8 minuti. \n Mio pap\u00e0 \u00e8 alto un metro e 87 centimetri. \n Io dico che non pu\u00f2 tenere in casa 8 gatti. \n Alla fine della corsa sono arrivati solo in 8. \n Devo prendere l'autobus numero 88. \n Ha preso 8 in storia e 7 in scienze. \n Dopo il numero 8 c'\u00e8 il 9. \n Ripeti il numero 789. \n Da 9 anni non facevamo una festa cos\u00ec. \n Domani \u00e8 il 9 ottobre. \n Un palazzo di 9 piani. \n Domani alle 9 ti vengo a trovare. \n Il numero 89 \u00e8 maggiore di 79. \n Ma 999999 non \u00e8 un milione. \n Se siamo solo in 9 non si gioca a calcio. \n Un cesto con 9 mele. \n Un pranzo con 9 portate. \n Ricordati di telefonare al 799989 \n Dicono che un cane di 9 anni sia molto vecchio. \n Ho 9 cugini e 8 zii. \n Il numero zero si scrive 0. \n Questa maglia costa 70.000 lire. \n Il famoso agente 007. \n Dopo il numero 799 c'\u00e8 l'800. \n Anche questa partita \u00e8 finita 0 a 0. \n Il termometro \u00e8 sceso sotto 0. \n Mi servono subito 900.000 lire. \n Il tavolo \u00e8 alto 90 centimetri. \n Non vendo a meno di 808.000 lire. \n C'erano 800 posti in quel teatro. \n Il Monte Everest \u00e8 alto pi\u00f9 di 8.000 metri. \n Una metropoli di 7.000.000 di abitanti. \n Anche se aveva 800 pagine l'ho letto tutto d'un fiato. \n Questa rivista costa 8.700 lire. \n Sette noni ovvero 7/9. \n La mia data di nascita \u00e8 09/07/99. \n Dimmi se 8/9 \u00e8 maggiore di 7/8. \n La barra \u00e8 sopra al numero 7. \n Il carattere barra si chiama anche segno di frazione. \n 7/8, 77/88 e 777/888 sono tra loro equivalenti. \n Il carattere / viene usato anche come segno di divisione. \n ( \u00e8 il segno di aperta parentesi. \n ) \u00e8 il segno di chiusa parentesi. \n Il Marco (moneta tedesca) vale circa 998 lire. \n Vieri (Inter) ieri non ha segnato. \n Ho un PC (Personal Computer) \u00e8 un po' vecchiotto. \n Dalla mia casa (settimo piano) vedo tanti tetti. \n Era Marco (non Luigi) quello che hai incontrato ieri. \n Marcello (il maestro) oggi era molto contento. \n Il nonno compie gli anni (87) e faremo una bella festa. \n La sua auto (una vecchia Fiat) non va pi\u00f9 bene. \n Vieste (sul Gargano) ha un mare stupendo. \n Il simbolo di uguale \u00e8 = \n 8=8 e 9=9 \n Il tasto = \u00e8 sopra quello dello 0. \n 7/8 = 77/88 \n Il simbolo = significa uguale. \n Naturalmente 978=978 e 80=80. \n A volte si usa = anche per la divisione in sillabe. \n Eravamo in 6 amici. \n La squadra di pallavolo \u00e8 composta di 6 giocatori. \n Abita al numero 66 di via Verdi. \n Mi servono 6.000 lire. \n Aprire il libro a pagina 86. \n Ha vinto il giocatore con la maglia numero 6. \n In maggio, il giorno 6, compie 6 anni. \n Il 6 gennaio arriva la Befana. \n Domenica il nonno compie 68 anni. \n Questi spaghetti cuociono in 6 minuti. \n Gli telefona 6 volte al giorno. \n Telefonami al numero 06 7866866. \n Ci vorrebbe un 6 al SuperEnalotto. \n Ha preso 6 e mezzo ma lui si aspettava almeno un 7. \n Una moneta da 500 lire. \n Una banconota da 5.000 lire. \n Domani \u00e8 il 5 ottobre. \n Pesa solo 55 chili. \n Se compi 5 anni ci vogliono 5 candeline. \n Ogni 5 minuti suonava la sirena. \n Se siamo in 6, 5 sedie non bastano. \n Chi indovina 5 numeri fa cinquina. \n Hanno vinto 5 a 0, un vero trionfo. \n Devo cambiare questa banconota da 50.000 lire. \n Canale5 mi piace ma c'\u00e8 troppa pubblicit\u00e0. \n Ogni giorno per allenarsi fa 5 chilometri di corsa. \n Domani mi alzo alle 5 per andare a pescare. \n Abita in via Roma al numero 5 \n 44 gatti in fila per 6 con il resto di due. \n 40 cani in fila per 4 con il resto di 0. \n A carte si gioca bene in 4. \n Un'automobile da 4 posti. \n Nel vaso c'erano 4 rose rosse. \n 444.444 \u00e8 un numero di telefono facile da ricordare. \n 8 per 8 fa 64. \n Mi servono 4 quaderni nuovi. \n Le 4 gambe del tavolo \n Mio pap\u00e0 ha 44 anni. \n Si chiamano quadrupedi gli animali con 4 zampe. \n Un libro di 400 pagine. \n Le automobili hanno 4 ruote. \n Un paese di 540 abitanti. \n I 3 moschettieri veramente erano 4. \n Mi hanno regalato 3 dischi nuovi. \n Coi suoi piedoni usa scarpe numero 43. \n 33 trentini trottavano verso Trento. \n Il 3 \u00e8 un numero importante. \n Molti mesi hanno 30 giorni. \n il 3 \u00e8 un numero dispari. \n L'autobus numero 3 \u00e8 appena passato. \n Una casetta con solo 3 finestre. \n Il triciclo ha 3 ruote. \n Qui una bibita costa 3.000 lire. \n In classe siamo quasi in 30. \n Viene a casa mia oggi alle 3 e mezza. \n Ha preso un pesce di oltre 3 chili. \n Il 2 \u00e8 il primo numero pari. \n Il 25 dicembre si festeggia il Natale. \n Una moneta da 2.000 lire. \n Marco ha 2 fratelli e una sorella. \n Mi servirebbero 200.000 lire. \n Se ve ne andate anche voi rimaniamo in 2. \n C'erano due passerotti sul ramo. \n Un cesto con 3 mele e 2 pere. \n Abbiamo 2 mani e 2 piedi. \n Abbiamo 2 occhi e 2 orecchie. \n Aveva un'auto sportiva con soli 2 posti. \n 42 gradi all'ombra, proprio un caldo insopportabile. \n Il viaggio in treno durava circa 2 ore e 20 minuti. \n Il tandem \u00e8 una bicicletta a 2 posti. \n Il numero 1 \n Per chiamare la polizia usa il 113. \n Un mezzo si pu\u00f2 scrivere anche 1/2. \n Sappiamo che 7/7=1, 8/8=1 e 9/9=1. \n Oggi \u00e8 il 12/10/1999. \n Il 10/06/1940 l'Italia entr\u00f2 in guerra. \n Per chiamare i carabinieri usa il 112. \n L'anno 1199 \u00e8 l'ultimo del secolo. \n Garibaldi e i suoi 1.000 garibaldini. \n Una moneta da 100 lire. \n A calcio si gioca in 11 per squadra. \n Persero la partita per 4 a 1 \n Ci vediamo alle 11 in punto. \n La montagna era alta esattamente 3111 metri. \n Nel 1918 fin\u00ec la prima guerra mondiale. \n Mario \u00e8 nato 10/11/1991. \n Arriv\u00f2 primo tra 191 concorrenti. \n Aprite il libro a pagina 151. \n Questo \u00e8 il simbolo delle virgolette \". \n \"Il dado \u00e8 tratto\" disse Cesare. \n Il suo soprannome era \"Stecchino\". \n \"Vieni subito qui\" disse la mamma. \n Si dice che \"Can che abbaia non morde\". \n Il tasto delle \" \u00e8 sopra a quello del 2. \n Sul cancelletto era scritto \"Attenti al cane\". \n \"Stop\" grid\u00f2 il poliziotto, ma il ladro scapp\u00f2. \n Dimmi che cosa vuol dire, secondo te, la parola \"amicizia\". \n Fermi tutti! \n Aiuto! Il leone \u00e8 scappato dalla gabbia! \n Questo quadro \u00e8 meraviglioso! \n Ah! Che splendida gita! \n Bello! Veramente bello! Complimenti! \n Bene! Bravo! Bis! \n Evviva Natale! La festa pi\u00f9 bella che ci sia! \n Tanti auguri! Buon compleanno! \n Il segno + indica l'addizione. \n 12+4=16 \n Il termometro segnava +2 gradi. \n Se sai quanto fa 5+5, rispondi! \n 765.798 + 562.657 \u00e8 un numero troppo difficile per me! \n Calcola 1+3+7+4+9+2+5+8+6 \n Se 12+45 fa 57, anche 45+12 fa 57. \n Il segno - indica la sottrazione. \n Il segno - viene chiamato spesso \"meno\". \n calcola 100-10 \n Che freddo! Saranno -10 gradi! \n Ecco una facile sottrazione 10-5. \n La lettera J si chiama anche i lunga. \n Il jet \u00e8 un aereo molto veloce. \n Gennaro ha chiamato la figlia Jessica. \n Scrivi Jules e Jim, non Giules e Gim. \n La J \u00e8 la decima lettera dell'alfabeto. \n A pap\u00e0 piace moltissimo la musica jazz. \n Qualcuno, per favore, chiami Jacopo. \n Il carattere k si chiama cappa. \n Digita il tuo nome prima di cliccare su OK. \n Mi piacciono molto le merendine Kinder. \n La K \u00e8 l'undicesima lettera dell'alfabeto. \n Alla sera giochiamo spesso a poker. \n Quando il pugile finisce KO, ha perso l'incontro. \n La sigla \"CD\" significa \"Compact Disk\" \n Il disco fisso del computer si chiama anche Hard Disk. \n Il carattere w si chiama vu doppia. \n Il carattere W viene usato come segno di \"Evviva!\". \n Il programma \"Typing Trainer\" funziona in Windows. \n Welcome, vuol dire benvenuto. \n La W \u00e8 la ventitreesima lettera dell'alfabeto. \n A me piacciono molto i kiwi. \n Water in inglese significa acqua. \n Come merenda Walter porta spesso dei wafer. \n La lettera x si pronuncia ics. \n Tuo pap\u00e0 porta la XL o la XXL. \n Ieri ho mangiato dei pasticcini extra. \n Nel totocalcio la X indica il pareggio. \n La X \u00e8 la ventiquattresima lettera dell'alfabeto. \n Nei numeri romani X significa dieci, XX venti. \n Giacomo mi ha spedito un fax di 4 pagine. \n La lettera Y si chiama ipsilon o i greca. \n New York \u00e8 famosa per i suoi grattacieli. \n Per ascoltare il CD, premi il pulsante \"Play\". \n La Y \u00e8 la ventiquattresima lettera dell'alfabeto. \n Mary mi ha regalato un bel yo-yo. \n Il simbolo & si chiama \"e commerciale\". \n I famosi soci \"Frank & William\". \n Il supermercato A&O. \n La famosa coppia Tom & Jerry. \n Il simbolo % significa \"per cento\". \n Un prestito al 5% d'interessi. \n Sono stati promossi al 100%. \n Dire 50% \u00e8 come dire met\u00e0 \n Le vittorie sono passate dal 44% al 78%. \n Il simbolo > significa \"maggiore\". \n Sappiamo che 100 > 90. \n Il simbolo < significa \"minore\". \n Naturalmente 45 < 50. \n Tutti i numeri <0 sono negativi. \n Il segno * si chiama asterisco \n Spesso nei computer * \u00e8 il simbolo della moltiplicazione \n Mettere *** significa non volere dire il nome. \n Calcola 4*3 \n Il carattere @ si chiama \"chiocciola\" \n Il simbolo @ \u00e8 oggi molto usato negli indirizzi internet. \n Qualcuno chiama @ \"at\", ovvero \"presso\". \n Scrivimi all'indirizzo pinco.pallino@tin.it \n La mia email \u00e8: garibaldi@libero.it \n @ si ottiene con Alt Gr e il tasto \u00f2 \n Il simbolo # si chiama cancelletto. \n Il simbolo # si chiama anche diesis. \n Il simbolo # non \u00e8 molto usato nei testi normali. \n Per ottenere il # deve usare il tasto Alt Gr. \n # si ottiene con Alt Gr e il tasto \u00e0. \n Il simbolo $ indica il dollaro. \n Il simbolo $ viene usato soprattutto in campo commerciale. \n Paperon de Paperoni ha come stemma il carattere $. \n Il simbolo $ si trova in tastiera sopra al 4. \n Una banconota da 100$ \n Il simbolo \u00a3 indica la lira sterlina. \n Il simbolo \u00a3 viene anche usato per la lira italiana. \n Sopra al numero 3 si trova il carattere \u00a3. \n Un assegno da \u00a3 2.000.000 \n Nella tastiera c'\u00e8 anche il carattere \\. \n Il carattere \\ viene chiamato \"barra rovescia\" \n Le due barre, / e \\, sono tra loro simmetriche. \n Il tasto con il simbolo \\ si trova in alto a sinistra. \n Il simbolo \\ \u00e8 molto usato in DOS. \n Il carattere _ indica il trattino basso o sottolineato. \n Il carattere _ si trova sopra il trattino normale -. \n Si usa spesso _ per unire due parole. \n Il carattere _ non \u00e8 molto usato nei testi normali. \n Le parentesi quadre si indicano con []. \n [ \u00e8 la parentesi quadra aperta. \n ] \u00e8 la parentesi quadra chiusa. \n Le parentesi [ e ] si usano spesso in matematica. \n Calcola: 4-[(6+3)/3] \n Per ottenere i caratteri [] si usa il tasto Alt Gr. \n [ si ottiene con Alt Gr e il tasto \u00e8 \n ] si ottiene con Alt Gr e il tasto + \n I simboli {} rappresentano le parentesi graffe. \n I simboli {} sono molto usati in matematica. \n Per ottenere il simbolo { si usa Ctrl Alt Shift e il tasto \u00e8 \n Per ottenere il simbolo } si usa Ctrl Alt Shift e il tasto + \n { \u00e8 la parentesi graffa aperta \n } \u00e8 la parentesi graffa chiusa \n Il simbolo : \u00e8 detto \"due punti\" \n Trova l'errore: 12>10, 45<35, 41>27 \n Il simbolo ; \u00e8 detto \"punto e virgola\" \n Il simbolo | \u00e8 detto \"pipe\" \n Il simbolo ? si usa al termine delle frasi interrogative. \n Il simbolo ^ si trova sopra alla lettera \u00ec. \n Il simbolo \u00a7 si trova sopra alla lettera \u00f9. \n Il carattere \u00e7 \u00e8 molto usato in francese. \n Il simbolo \u00b0 indica i gradi.";

// KEYBOARD MAPPING DICTIONARY (Italian QWERTY 105 Keys)
const KEY_MAP = {
  // Special multi-line keys (Enter & Tab)
  "®": { id: "key_enter", finger: 10, mod: "none", name: "Invio (Return)" },
  "\n": { id: "key_enter", finger: 10, mod: "none", name: "Invio (Return)" },
  "→": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione (Tab)" },
  "\t": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione (Tab)" },
  // Row 1
  "\\": { id: "key_backslash", finger: 1, mod: "none", name: "Backslash" },
  "|": {
    id: "key_backslash",
    finger: 1,
    mod: "shiftR",
    name: "Barra Verticale",
  },
  1: { id: "key_1", finger: 1, mod: "none", name: "1" },
  "!": { id: "key_1", finger: 1, mod: "shiftR", name: "Punto Esclamativo" },
  2: { id: "key_2", finger: 1, mod: "none", name: "2" },
  '"': { id: "key_2", finger: 1, mod: "shiftR", name: "Virgolette" },
  3: { id: "key_3", finger: 2, mod: "none", name: "3" },
  "£": { id: "key_3", finger: 2, mod: "shiftR", name: "Sterlina" },
  4: { id: "key_4", finger: 3, mod: "none", name: "4" },
  $: { id: "key_4", finger: 3, mod: "shiftR", name: "Dollaro" },
  5: { id: "key_5", finger: 4, mod: "none", name: "5" },
  "%": { id: "key_5", finger: 4, mod: "shiftR", name: "Percentuale" },
  6: { id: "key_6", finger: 4, mod: "none", name: "6" },
  "&": { id: "key_6", finger: 4, mod: "shiftR", name: "E Commerciale" },
  7: { id: "key_7", finger: 7, mod: "none", name: "7" },
  "/": { id: "key_7", finger: 7, mod: "shiftL", name: "Slash" },
  8: { id: "key_8", finger: 7, mod: "none", name: "8" },
  "(": { id: "key_8", finger: 7, mod: "shiftL", name: "Tonda Aperta" },
  9: { id: "key_9", finger: 8, mod: "none", name: "9" },
  ")": { id: "key_9", finger: 8, mod: "shiftL", name: "Tonda Chiusa" },
  0: { id: "key_0", finger: 9, mod: "none", name: "0" },
  "=": { id: "key_0", finger: 9, mod: "shiftL", name: "Uguale" },
  "'": { id: "key_quote", finger: 10, mod: "none", name: "Apostrofo" },
  "?": {
    id: "key_quote",
    finger: 10,
    mod: "shiftL",
    name: "Punto Interrogativo",
  },
  "`": { id: "key_quote", finger: 10, mod: "altgr", name: "Backtick" },
  ì: { id: "key_igrave", finger: 10, mod: "none", name: "I Grave" },
  "^": { id: "key_igrave", finger: 10, mod: "shiftL", name: "Circonflesso" },
  "~": { id: "key_igrave", finger: 10, mod: "altgr", name: "Tilde" },

  // Aggiunta voce per intercettazione target visivo in caso di Errore
  Backspace: { id: "key_backspace", finger: 10, mod: "none", name: "BACK" },

  // Row 2
  q: { id: "key_q", finger: 1, mod: "none", name: "q" },
  Q: { id: "key_q", finger: 1, mod: "shiftR", name: "Q" },
  w: { id: "key_w", finger: 2, mod: "none", name: "w" },
  W: { id: "key_w", finger: 2, mod: "shiftR", name: "W" },
  e: { id: "key_e", finger: 3, mod: "none", name: "e" },
  E: { id: "key_e", finger: 3, mod: "shiftR", name: "E" },
  "€": { id: "key_e", finger: 3, mod: "altgr", name: "Euro" },
  r: { id: "key_r", finger: 4, mod: "none", name: "r" },
  R: { id: "key_r", finger: 4, mod: "shiftR", name: "R" },
  t: { id: "key_t", finger: 4, mod: "none", name: "t" },
  T: { id: "key_t", finger: 4, mod: "shiftR", name: "T" },
  y: { id: "key_y", finger: 7, mod: "none", name: "y" },
  Y: { id: "key_y", finger: 7, mod: "shiftL", name: "Y" },
  u: { id: "key_u", finger: 7, mod: "none", name: "u" },
  U: { id: "key_u", finger: 7, mod: "shiftL", name: "U" },
  i: { id: "key_i", finger: 8, mod: "none", name: "i" },
  I: { id: "key_i", finger: 8, mod: "shiftL", name: "I" },
  o: { id: "key_o", finger: 9, mod: "none", name: "o" },
  O: { id: "key_o", finger: 9, mod: "shiftL", name: "O" },
  p: { id: "key_p", finger: 10, mod: "none", name: "p" },
  P: { id: "key_p", finger: 10, mod: "shiftL", name: "P" },
  è: { id: "key_egrave", finger: 10, mod: "none", name: "e grave" },
  é: { id: "key_egrave", finger: 10, mod: "shiftL", name: "e acuta" },
  "[": { id: "key_egrave", finger: 10, mod: "altgr", name: "Quadra Aperta" },
  "{": {
    id: "key_egrave",
    finger: 10,
    mod: "shiftAltgr",
    name: "Graffa Aperta",
  },
  "+": { id: "key_plus", finger: 10, mod: "none", name: "Più" },
  "*": { id: "key_plus", finger: 10, mod: "shiftL", name: "Asterisco" },
  "]": { id: "key_plus", finger: 10, mod: "altgr", name: "Quadra Chiusa" },
  "}": { id: "key_plus", finger: 10, mod: "shiftAltgr", name: "Graffa Chiusa" },

  // Row 3
  a: { id: "key_a", finger: 1, mod: "none", name: "a" },
  A: { id: "key_a", finger: 1, mod: "shiftR", name: "A" },
  s: { id: "key_s", finger: 2, mod: "none", name: "s" },
  S: { id: "key_s", finger: 2, mod: "shiftR", name: "S" },
  d: { id: "key_d", finger: 3, mod: "none", name: "d" },
  D: { id: "key_d", finger: 3, mod: "shiftR", name: "D" },
  f: { id: "key_f", finger: 4, mod: "none", name: "f" },
  F: { id: "key_f", finger: 4, mod: "shiftR", name: "F" },
  g: { id: "key_g", finger: 4, mod: "none", name: "g" },
  G: { id: "key_g", finger: 4, mod: "shiftR", name: "G" },
  h: { id: "key_h", finger: 7, mod: "none", name: "h" },
  H: { id: "key_h", finger: 7, mod: "shiftL", name: "H" },
  j: { id: "key_j", finger: 7, mod: "none", name: "j" },
  J: { id: "key_j", finger: 7, mod: "shiftL", name: "J" },
  k: { id: "key_k", finger: 8, mod: "none", name: "k" },
  K: { id: "key_k", finger: 8, mod: "shiftL", name: "K" },
  l: { id: "key_l", finger: 9, mod: "none", name: "l" },
  L: { id: "key_l", finger: 9, mod: "shiftL", name: "L" },
  ò: { id: "key_ograve", finger: 10, mod: "none", name: "o grave" },
  ç: { id: "key_ograve", finger: 10, mod: "shiftL", name: "c cediglia" },
  "@": { id: "key_ograve", finger: 10, mod: "altgr", name: "Chiocciola" },
  à: { id: "key_agrave", finger: 10, mod: "none", name: "a grave" },
  "°": { id: "key_agrave", finger: 10, mod: "shiftL", name: "Gradi" },
  "#": { id: "key_agrave", finger: 10, mod: "altgr", name: "Cancelletto" },
  ù: { id: "key_ugrave", finger: 10, mod: "none", name: "u grave" },
  "§": { id: "key_ugrave", finger: 10, mod: "shiftL", name: "Paragrafo" },

  // Row 4
  "<": { id: "key_less", finger: 1, mod: "none", name: "Minore" },
  ">": { id: "key_less", finger: 1, mod: "shiftR", name: "Maggiore" },
  z: { id: "key_z", finger: 1, mod: "none", name: "z" },
  Z: { id: "key_z", finger: 1, mod: "shiftR", name: "Z" },
  x: { id: "key_x", finger: 2, mod: "none", name: "x" },
  X: { id: "key_x", finger: 2, mod: "shiftR", name: "X" },
  c: { id: "key_c", finger: 3, mod: "none", name: "c" },
  C: { id: "key_c", finger: 3, mod: "shiftR", name: "C" },
  v: { id: "key_v", finger: 4, mod: "none", name: "v" },
  V: { id: "key_v", finger: 4, mod: "shiftR", name: "V" },
  b: { id: "key_b", finger: 4, mod: "none", name: "b" },
  B: { id: "key_b", finger: 4, mod: "shiftR", name: "B" },
  n: { id: "key_n", finger: 7, mod: "none", name: "n" },
  N: { id: "key_n", finger: 7, mod: "shiftL", name: "N" },
  m: { id: "key_m", finger: 7, mod: "none", name: "m" },
  M: { id: "key_m", finger: 7, mod: "shiftL", name: "M" },
  ",": { id: "key_comma", finger: 8, mod: "none", name: "Virgola" },
  ";": { id: "key_comma", finger: 8, mod: "shiftL", name: "Punto e Virgola" },
  ".": { id: "key_period", finger: 9, mod: "none", name: "Punto" },
  ":": { id: "key_period", finger: 9, mod: "shiftL", name: "Due Punti" },
  "-": { id: "key_minus", finger: 10, mod: "none", name: "Trattino" },
  _: { id: "key_minus", finger: 10, mod: "shiftL", name: "Underscore" },

  // Row 5
  " ": { id: "key_space", finger: 5, mod: "none", name: "Spazio" },
};

const FINGER_NAMES = {
  1: "Mignolo Sinistro",
  2: "Anulare Sinistro",
  3: "Medio Sinistro",
  4: "Indice Sinistro",
  5: "Pollice Sinistro",
  6: "Pollice Destro",
  7: "Indice Destro",
  8: "Medio Destro",
  9: "Anulare Destro",
  10: "Mignolo Destro",
};

// RISOLUTORE ACCORDI TASTI (CHORD ENGINE v.1.4)
function resolveTargetChord(char) {
  if (!char) return null;
  const info = KEY_MAP[char];
  if (!info) return null;

  const keyIds = [info.id];
  const fingers = [];
  const allowedMods = new Set();
  const isLeftHandBase = info.finger >= 1 && info.finger <= 5;

  if (info.mod === "shiftR") {
    keyIds.push("key_shift_r");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 10, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "shiftL") {
    keyIds.push("key_shift_l");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 1, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "altgr") {
    if (!isLeftHandBase) {
      keyIds.push("key_ctrl_l", "key_alt_l");
      fingers.push({ finger: 1, label: "Ctrl" });
      fingers.push({ finger: 5, label: "Alt" });
      fingers.push({ finger: info.finger, label: char });
      allowedMods.add("Control");
      allowedMods.add("Alt");
      allowedMods.add("AltGraph");
    } else {
      keyIds.push("key_altgr");
      fingers.push({ finger: info.finger, label: char });
      fingers.push({ finger: 6, label: "AltGr" });
      allowedMods.add("AltGraph");
      allowedMods.add("Control");
      allowedMods.add("Alt");
    }
  } else if (info.mod === "shiftAltgr") {
    keyIds.push("key_ctrl_l", "key_shift_l", "key_alt_l");
    fingers.push({ finger: 1, label: "Ctrl" });
    fingers.push({ finger: 2, label: "Shift" });
    fingers.push({ finger: 5, label: "Alt" });
    fingers.push({ finger: info.finger, label: char });
    allowedMods.add("Control");
    allowedMods.add("Shift");
    allowedMods.add("Alt");
    allowedMods.add("AltGraph");
  } else {
    let lbl = char;
    if (char === " " || info.name === "Spazio") lbl = "␣";
    else if (char === "®" || char === "\n" || info.name === "Invio") lbl = "↵";
    else if (char === "→" || char === "\t" || info.name === "Tabulazione")
      lbl = "⇥";
    else if (info.name && info.name.length <= 4) lbl = info.name;
    fingers.push({ finger: info.finger, label: lbl });
  }

  return { info, keyIds, fingers, allowedMods };
}

// AUDIO SYNTHESIZER (Web Audio API)
class AudioEngine {
  constructor() {
    this.ctx = null;
    this.mode = "typewriter"; // "beep", "typewriter", "mute"
    this.volume = 0.7;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  setMode(mode) {
    this.mode = mode;
  }
  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
  }

  playKey() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    if (this.mode === "typewriter") {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(600 + Math.random() * 200, t);
      osc.frequency.exponentialRampToValueAtTime(100, t + 0.035);

      gain.gain.setValueAtTime(this.volume * 0.45, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.04);
    }
  }

  playError() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    if (this.mode === "beep") {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(440, t);
      gain.gain.setValueAtTime(this.volume * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.09);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + 0.09);
    } else {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(160, t);
      osc.frequency.exponentialRampToValueAtTime(60, t + 0.12);
      gain.gain.setValueAtTime(this.volume * 0.65, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + 0.13);
    }
  }

  playBell() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(2040, t);
    gain.gain.setValueAtTime(this.volume * 0.6, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.75);
  }
}

// PROFILE MANAGER (Multi-user isolation in LocalStorage con supporto PIN e Barriera)
class ProfileManager {
  constructor(initialDemoData, defaultCustomText) {
    this.STORAGE_KEY_USERS = "TFTT_USERS";
    this.STORAGE_KEY_ACTIVE = "TFTT_ACTIVE_USER";
    this.STORAGE_KEY_FIRST_RUN = "TFTT_FIRST_RUN_DONE";
    this.STORAGE_PREFIX = "TFTT_PROFILE_";
    this.initialDemoData = initialDemoData;
    this.defaultCustomText = defaultCustomText;
    this.activeUser = null;
    this.profile = null;
  }

  init() {
    const firstRunDone = localStorage.getItem(this.STORAGE_KEY_FIRST_RUN);
    let users = this.getUsers();

    if (!firstRunDone) {
      // Eseguito esclusivamente al primissimo avvio assoluto
      this.resetToDefaultArchive();
      localStorage.setItem(this.STORAGE_KEY_FIRST_RUN, "true");
      users = this.getUsers();
    }

    const active = localStorage.getItem(this.STORAGE_KEY_ACTIVE);
    if (active && users.includes(active)) {
      this.loadUser(active);
    } else {
      this.activeUser = null;
      this.profile = null;
      localStorage.removeItem(this.STORAGE_KEY_ACTIVE);
    }
    return users;
  }

  resetToDefaultArchive() {
    let users = this.getUsers();
    if (!users.includes("UTENTE_DEMO")) {
      users.push("UTENTE_DEMO");
      this.saveUsers(users);
    }
    localStorage.setItem(this.STORAGE_KEY_ACTIVE, "UTENTE_DEMO");

    const demoProf = {
      UserID: "UTENTE_DEMO",
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      ShowErrors: true,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      HandsTop: 120,
      HandsLeft: 956,
      HandsWidth: 460,
      HandsHeight: 286,
      HandsPinned: true,
      HandsOffsetTop: 45,
      StatTop: 95,
      StatLeft: 630,
      StatWidth: 820,
      StatHeight: 548,
      CustomText: this.defaultCustomText,
      TotaleCaratteri: this.initialDemoData?.TotaleCaratteri || 0,
      TotaleErrori: this.initialDemoData?.TotaleErrori || 0,
      Caratteri: this.initialDemoData?.Caratteri || [],
      Campioni: this.initialDemoData?.Campioni || [],
    };
    localStorage.setItem(
      this.STORAGE_PREFIX + "UTENTE_DEMO",
      JSON.stringify(demoProf),
    );
    this.activeUser = "UTENTE_DEMO";
    this.profile = demoProf;
  }

  getUsers() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY_USERS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  saveUsers(users) {
    localStorage.setItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
  }

  loadUser(userId) {
    const data = localStorage.getItem(this.STORAGE_PREFIX + userId);
    if (data) {
      try {
        this.profile = JSON.parse(data);
        this.activeUser = userId;
        localStorage.setItem(this.STORAGE_KEY_ACTIVE, userId);
        return this.profile;
      } catch (e) {
        console.error(e);
      }
    }
    return this.createUser(userId);
  }

  createUser(userId) {
    const trimmed = userId.trim();
    if (!trimmed) return null;
    const users = this.getUsers();
    if (!users.includes(trimmed)) {
      users.push(trimmed);
      this.saveUsers(users);
    }
    this.profile = {
      UserID: trimmed,
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      ShowErrors: true,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      HandsTop: 120,
      HandsLeft: 956,
      HandsWidth: 460,
      HandsHeight: 286,
      HandsPinned: true,
      HandsOffsetTop: 45,
      StatTop: 95,
      StatLeft: 630,
      StatWidth: 820,
      StatHeight: 548,
      CustomText: this.defaultCustomText,
      TotaleCaratteri: 0,
      TotaleErrori: 0,
      Caratteri: [],
      Campioni: [],
    };
    this.activeUser = trimmed;
    localStorage.setItem(this.STORAGE_KEY_ACTIVE, trimmed);
    this.saveProfile();
    return this.profile;
  }

  deleteUser(userId) {
    let users = this.getUsers();
    users = users.filter((u) => u !== userId);
    this.saveUsers(users);
    localStorage.removeItem(this.STORAGE_PREFIX + userId);
    if (this.activeUser === userId) {
      this.activeUser = null;
      this.profile = null;
      localStorage.removeItem(this.STORAGE_KEY_ACTIVE);
    }
  }

  saveProfile() {
    if (this.activeUser && this.profile) {
      localStorage.setItem(
        this.STORAGE_PREFIX + this.activeUser,
        JSON.stringify(this.profile),
      );
    }
  }

  clearUserStats() {
    if (!this.profile) return;
    this.profile.TotaleCaratteri = 0;
    this.profile.TotaleErrori = 0;
    this.profile.Caratteri = [];
    this.profile.Campioni = [];
    this.saveProfile();
  }

  exportJson() {
    return JSON.stringify(this.profile, null, 2);
  }

  // Estensione XML compatibile con persistenza di d2p1:DataOra
  exportXml() {
    let xml = '<?xml version="1.0" standalone="yes"?>\n';
    xml +=
      '<DataSetArchivio xmlns="http://Tastiera10Dita.org/DataSetArchivio.xsd">\n';
    const p = this.profile;
    xml += `  <Utenti d2p1:UserID="${p.UserID}" d2p1:Mode="${p.Mode}" d2p1:Lesson="${p.Lesson}" d2p1:Exercise="${p.Exercise}" d2p1:AutomaticCorrection="${p.AutomaticCorrection}" d2p1:ShowKeyBoard="${p.ShowKeyBoard}" d2p1:ShowHands="${p.ShowHands}" d2p1:ShowOrigin="${p.ShowOrigin}" d2p1:ShowTyped="${p.ShowTyped}" d2p1:MainTop="80" d2p1:MainLeft="180" d2p1:StatTop="${p.StatTop}" d2p1:StatLeft="${p.StatLeft}" d2p1:HandsTop="${p.HandsTop}" d2p1:HandsLeft="${p.HandsLeft}" xmlns:d2p1="http://Tastiera10Dita.org/DataSetArchivio.xsd">\n`;
    xml += `    <StatisticaUtente d2p1:TotaleCaratteri="${p.TotaleCaratteri}" d2p1:TotaleErrori="${p.TotaleErrori}">\n`;
    for (const c of p.Caratteri || []) {
      xml += `      <UnCarattere d2p1:Index="${c.Index}" d2p1:CharUnicode="${c.CharUnicode}" d2p1:Frequenza="${c.Frequenza}" d2p1:Errori="${c.Errori}" />\n`;
    }
    xml += "    </StatisticaUtente>\n";
    xml += "    <SequenzaCampioni>\n";
    for (const s of p.Campioni || []) {
      const dateAttr = s.DataOra ? ` d2p1:DataOra="${s.DataOra}"` : "";
      xml += `      <SeqCampioni d2p1:Index="${s.Index}" d2p1:BattuteMinuto="${s.BattuteMinuto}" d2p1:TipoCampione="${s.TipoCampione}" d2p1:NumCaratteri="${s.NumCaratteri}" d2p1:NumErrori="${s.NumErrori}" d2p1:Esercizio="${s.Esercizio || ""}"${dateAttr} />\n`;
    }
    xml += "    </SequenzaCampioni>\n";
    xml += "  </Utenti>\n";
    xml += "</DataSetArchivio>";
    return xml;
  }
}

// MARKOVIAN PHONEME GENERATOR
class PhonemeEngine {
  constructor(corpus) {
    this.corpus = corpus || "";
    this.ngramLength = 4;
    this.targetLength = 100;
  }

  generate() {
    if (!this.corpus || this.corpus.length < 100)
      return "fa la sala fa la salsa salda la falla";
    let result = "";

    const wordStartRegex = /\b([a-zA-Zàèéìòùç])/g;
    const starts = [];
    let match;
    while ((match = wordStartRegex.exec(this.corpus)) !== null) {
      starts.push(match[1]);
      if (starts.length > 500) break;
    }
    let currentPrefix =
      starts.length > 0
        ? starts[Math.floor(Math.random() * starts.length)]
        : "s";
    result += currentPrefix;

    let safetyCounter = 0;
    let rollbackCount = 0; // Guardia anti-starvation per prevenire loop infiniti di rollback

    while (result.length < this.targetLength && safetyCounter < 1000) {
      safetyCounter++;
      const searchPattern = currentPrefix.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&",
      );
      const regex = new RegExp(searchPattern + "([a-zA-Zàèéìòùç ])", "g");
      const nextChars = [];
      let m;
      let count = 0;
      while ((m = regex.exec(this.corpus)) !== null && count < 80) {
        nextChars.push(m[1]);
        count++;
      }

      if (nextChars.length > 0) {
        // RAMO A: Transizione valida trovata nel corpus
        let nextChar = nextChars[Math.floor(Math.random() * nextChars.length)];

        // Prevenzione spazi consecutivi
        if (nextChar === " " && result.endsWith(" ")) {
          nextChar = starts[Math.floor(Math.random() * starts.length)] || "a";
        }

        result += nextChar;
        rollbackCount = 0; // Reset contatore rollback su avanzamento positivo

        // Avanzamento e scorrimento della finestra di contesto (Sliding Window)
        currentPrefix = currentPrefix + nextChar;
        if (currentPrefix.length >= this.ngramLength) {
          currentPrefix = currentPrefix.slice(1);
        }
      } else {
        // RAMO B: Vicolo cieco (Dead-End) - Gestione deterministica senza caratteri fittizi
        const currentWord = result.slice(result.lastIndexOf(" ") + 1);
        const endsWithVowel = /[aeiouàèéìòù]$/i.test(currentWord);

        if (currentWord.length >= 2 && endsWithVowel) {
          // Caso 1: La parola parziale ha fonotassi plausibile -> Chiudi con spazio
          if (!result.endsWith(" ")) {
            result += " ";
          }
          rollbackCount = 0;
        } else if (rollbackCount < 5) {
          // Caso 2: Parola monca/deforme -> Rollback all'ultimo spazio
          rollbackCount++;
          const lastSpaceIdx = result.lastIndexOf(" ");
          if (lastSpaceIdx >= 0) {
            result = result.slice(0, lastSpaceIdx + 1);
          } else {
            result = "";
          }
        } else {
          // Caso 3 (Guardia anti-starvation): troppi rollback consecutivi -> forza spazio
          if (!result.endsWith(" ")) {
            result += " ";
          }
          rollbackCount = 0;
        }

        // Re-seed pulito da un token reale di inizio parola del corpus
        const newSeed =
          starts[Math.floor(Math.random() * starts.length)] || "s";
        result += newSeed;

        // La finestra riparte da lunghezza 1 e ricresce naturalmente fino a ngramLength
        currentPrefix = newSeed;
      }
    }

    // OPZIONE B: Normalizzazione e troncamento rigido a 100 caratteri netti
    let formatted = result.replace(/\s+/g, " ").trim();
    if (formatted.length > this.targetLength) {
      formatted = formatted.slice(0, this.targetLength);
    }

    return formatted;
  }
}

// WINDOW MANAGER (Draggable & Resizable con Viewport Boundary Guard)
class WindowManager {
  constructor() {
    this.activeDrag = null;
    this.activeResize = null;
    this.startX = 0;
    this.startY = 0;
    this.initX = 0;
    this.initY = 0;
    this.initW = 0;
    this.initH = 0;
    this.isAbsoluteDrag = false;
    this.initGlobalEvents();
  }

  // Viewport Boundary Guard: garantisce che la finestra rimanga sempre afferrabile e visibile
  clampWindowToViewport(windowElem, isAbsolute = false) {
    if (!windowElem) return;
    const w = windowElem.offsetWidth || 540;
    const h = windowElem.offsetHeight || 330;

    if (isAbsolute) {
      const docW = Math.max(
        document.documentElement.clientWidth,
        window.innerWidth || 1280,
      );
      const docH = Math.max(
        document.documentElement.scrollHeight,
        window.innerHeight || 800,
      );
      const minLeft = 10;
      const maxLeft = Math.max(minLeft, docW - w - 10);
      const minTop = 60; // Sotto la barra header principale
      const maxTop = Math.max(minTop, docH - 50);

      let curLeft = windowElem.offsetLeft;
      let curTop = windowElem.offsetTop;
      let clampedLeft = Math.max(minLeft, Math.min(maxLeft, curLeft));
      let clampedTop = Math.max(minTop, Math.min(maxTop, curTop));

      windowElem.style.left = clampedLeft + "px";
      windowElem.style.top = clampedTop + "px";
      return { left: clampedLeft, top: clampedTop };
    } else {
      const vpW = window.innerWidth || 1280;
      const vpH = window.innerHeight || 800;
      const minLeft = 10;
      const maxLeft = Math.max(minLeft, vpW - w - 10);
      const minTop = 60; // Sotto la barra header principale
      const maxTop = Math.max(minTop, vpH - 50); // Almeno 50px visibili per riafferrare l'header

      let curLeft = parseInt(windowElem.style.left, 10);
      let curTop = parseInt(windowElem.style.top, 10);
      if (isNaN(curLeft)) curLeft = windowElem.getBoundingClientRect().left;
      if (isNaN(curTop)) curTop = windowElem.getBoundingClientRect().top;

      let clampedLeft = Math.max(minLeft, Math.min(maxLeft, curLeft));
      let clampedTop = Math.max(minTop, Math.min(maxTop, curTop));

      windowElem.style.left = clampedLeft + "px";
      windowElem.style.top = clampedTop + "px";
      return { left: clampedLeft, top: clampedTop };
    }
  }

  makeDraggable(windowElem, headerElem, onPositionChanged) {
    if (!windowElem || !headerElem) return;

    headerElem.addEventListener("mousedown", (e) => {
      if (
        e.target.closest("button") ||
        windowElem.classList.contains("window-fullscreen")
      )
        return;
      this.activeDrag = windowElem;
      this.onPositionChanged = onPositionChanged;
      const isAbsolute =
        window.getComputedStyle(windowElem).position === "absolute";
      this.isAbsoluteDrag = isAbsolute;
      if (isAbsolute) {
        this.startX = e.pageX;
        this.startY = e.pageY;
        this.initX = windowElem.offsetLeft;
        this.initY = windowElem.offsetTop;
      } else {
        this.startX = e.clientX;
        this.startY = e.clientY;
        const rect = windowElem.getBoundingClientRect();
        this.initX = rect.left;
        this.initY = rect.top;
      }
      windowElem.style.zIndex = "1500";
    });
  }

  makeResizable(windowElem, onResized, minW = 520, minH = 360) {
    if (!windowElem) return;
    const handles = windowElem.querySelectorAll(".resize-handle");
    handles.forEach((h) => {
      h.addEventListener("mousedown", (e) => {
        if (windowElem.classList.contains("window-fullscreen")) return;
        e.preventDefault();
        e.stopPropagation();
        const isAbsolute =
          window.getComputedStyle(windowElem).position === "absolute";
        this.activeResize = {
          elem: windowElem,
          dir: h.getAttribute("data-dir"),
          onResized: onResized,
          minW: minW,
          minH: minH,
          isAbsolute: isAbsolute,
        };
        if (isAbsolute) {
          this.startX = e.pageX;
          this.startY = e.pageY;
          this.initX = windowElem.offsetLeft;
          this.initY = windowElem.offsetTop;
          this.initW = windowElem.offsetWidth;
          this.initH = windowElem.offsetHeight;
        } else {
          this.startX = e.clientX;
          this.startY = e.clientY;
          const rect = windowElem.getBoundingClientRect();
          this.initX = rect.left;
          this.initY = rect.top;
          this.initW = rect.width;
          this.initH = rect.height;
        }
        windowElem.style.zIndex = "1500";
      });
    });
  }

  initGlobalEvents() {
    window.addEventListener("mousemove", (e) => {
      if (this.activeDrag) {
        if (this.isAbsoluteDrag) {
          const dx = e.pageX - this.startX;
          const dy = e.pageY - this.startY;
          const docW = Math.max(
            document.documentElement.clientWidth,
            window.innerWidth || 1280,
          );
          const docH = Math.max(
            document.documentElement.scrollHeight,
            window.innerHeight || 800,
          );
          const minLeft = 10;
          const maxLeft = Math.max(
            minLeft,
            docW - this.activeDrag.offsetWidth - 10,
          );
          const minTop = 60; // Protezione barra header principale
          const maxTop = Math.max(minTop, docH - 50);

          let newX = Math.max(minLeft, Math.min(maxLeft, this.initX + dx));
          let newY = Math.max(minTop, Math.min(maxTop, this.initY + dy));
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        } else {
          const dx = e.clientX - this.startX;
          const dy = e.clientY - this.startY;
          const minLeft = 10;
          const maxLeft = Math.max(
            minLeft,
            window.innerWidth - this.activeDrag.offsetWidth - 10,
          );
          const minTop = 60; // Protezione barra header principale
          const maxTop = Math.max(minTop, window.innerHeight - 50);

          let newX = Math.max(minLeft, Math.min(maxLeft, this.initX + dx));
          let newY = Math.max(minTop, Math.min(maxTop, this.initY + dy));
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        }
      }

      if (this.activeResize) {
        const ar = this.activeResize;
        const currentX = ar.isAbsolute ? e.pageX : e.clientX;
        const currentY = ar.isAbsolute ? e.pageY : e.clientY;
        const dx = currentX - this.startX;
        const dy = currentY - this.startY;
        const dir = ar.dir;
        let newW = this.initW;
        let newH = this.initH;
        let newL = this.initX;
        let newT = this.initY;

        const maxAvailW =
          (ar.isAbsolute
            ? document.documentElement.clientWidth
            : window.innerWidth) - 20;
        const maxAvailH =
          (ar.isAbsolute
            ? document.documentElement.scrollHeight
            : window.innerHeight) - 70;

        // Ridimensionamento verso Est (destra): ancoraggio sinistro fisso
        if (dir.includes("e")) {
          newW = Math.max(
            ar.minW,
            Math.min(maxAvailW - this.initX, this.initW + dx),
          );
        }
        // Ridimensionamento verso Sud (basso): ancoraggio superiore fisso
        if (dir.includes("s")) {
          newH = Math.max(
            ar.minH,
            Math.min(maxAvailH - this.initY, this.initH + dy),
          );
        }
        // Ridimensionamento verso Ovest (sinistra): ancoraggio destro rigorosamente fisso
        if (dir.includes("w")) {
          const rightEdge = this.initX + this.initW;
          const minAllowedL = 10;
          const maxAllowedL = rightEdge - ar.minW;
          newL = Math.max(minAllowedL, Math.min(maxAllowedL, this.initX + dx));
          newW = rightEdge - newL;
        }
        // Ridimensionamento verso Nord (alto): ancoraggio inferiore rigorosamente fisso
        if (dir.includes("n")) {
          const bottomEdge = this.initY + this.initH;
          const minAllowedT = 60; // Limite superiore invalicabile
          const maxAllowedT = bottomEdge - ar.minH; // Garantisce l'altezza minima
          newT = Math.max(minAllowedT, Math.min(maxAllowedT, this.initY + dy));
          newH = bottomEdge - newT;
        }

        ar.elem.style.width = newW + "px";
        ar.elem.style.height = newH + "px";
        ar.elem.style.left = newL + "px";
        ar.elem.style.top = newT + "px";
        ar.elem.style.maxWidth = "none";
      }
    });

    window.addEventListener("mouseup", () => {
      if (this.activeDrag) {
        this.clampWindowToViewport(this.activeDrag, this.isAbsoluteDrag);
        this.activeDrag.style.zIndex = "1000";
        this.activeDrag = null;
      }
      if (this.activeResize) {
        const ar = this.activeResize;
        this.clampWindowToViewport(ar.elem, ar.isAbsolute);
        ar.elem.style.zIndex = "1000";
        if (ar.onResized) {
          ar.onResized(
            ar.elem.offsetWidth,
            ar.elem.offsetHeight,
            ar.elem.offsetLeft,
            ar.elem.offsetTop,
          );
        }
        this.activeResize = null;
      }
    });

    // Sanitizzazione al resize della finestra del browser
    window.addEventListener("resize", () => {
      document
        .querySelectorAll(".floating-window.window-visible")
        .forEach((win) => {
          if (!win.classList.contains("window-fullscreen")) {
            const isAbs = window.getComputedStyle(win).position === "absolute";
            this.clampWindowToViewport(win, isAbs);
          }
        });
    });
  }
}

// TYPING ENGINE & STATE MACHINE (con marcatura DataOra)
class TypingEngine {
  constructor(lessons, profileMgr, audio, phonemeEng) {
    this.lessons = lessons;
    this.profileMgr = profileMgr;
    this.audio = audio;
    this.phonemeEng = phonemeEng;

    this.mode = 0;
    this.currentLessonIdx = 0;
    this.currentPhraseIdx = 0;
    this.originText = "";
    this.typedText = "";

    this.startTime = null;
    this.timerInterval = null;
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;

    this.sessionErrors = []; // Registro coppie di errore per la sessione
    this.currentTargetHasError = false; // Gate: impedisce registrazioni multiple sullo stesso carattere

    this.customPhrases = [];
    this.parseCustomText(
      profileMgr.profile ? profileMgr.profile.CustomText : "",
    );
  }

  // Calcola la lunghezza del prefisso coincidente tra digitato e testo guida
  getMatchLength() {
    let i = 0;
    while (
      i < this.typedText.length &&
      i < this.originText.length &&
      this.typedText[i] === this.originText[i]
    ) {
      i++;
    }
    return i;
  }

  // Gate di cattura: l'errore è catturabile solo se NON vi sono caratteri rossi nel Testo Guida
  canCaptureError() {
    if (this.mode === 4 || this.isCompleted) return false;
    const matchLen = this.getMatchLength();
    const hasRedChars = this.typedText.length > matchLen;
    // Se vi sono già caratteri rossi nel testo guida, blocca errori a cascata
    if (hasRedChars) return false;
    // Se su questo target è già stato registrato un errore (es. in auto-correzione o modificatore), blocca
    if (this.currentTargetHasError) return false;
    return true;
  }

  parseCustomText(rawText) {
    this.customPhrases = [];
    if (!rawText) return;
    const lines = rawText.split(/\r?\n/);
    let currentTitle = "Custom";
    let curLines = [];

    const flushCurrent = () => {
      if (curLines.length > 0) {
        let phraseText = "";
        for (let i = 0; i < curLines.length; i++) {
          const seg = curLines[i];
          if (!seg) continue;
          if (phraseText.length === 0) {
            phraseText = seg;
          } else if (phraseText.endsWith(" ") || phraseText.endsWith("®")) {
            phraseText += seg;
          } else {
            phraseText += " " + seg;
          }
        }
        if (phraseText.trim().length > 0) {
          this.customPhrases.push({
            title: currentTitle,
            text: phraseText,
          });
        }
        curLines = [];
      }
    };

    for (let line of lines) {
      line = line.trimEnd();
      if (
        line.startsWith("=====") &&
        line.endsWith("=====") &&
        line.length > 10
      ) {
        flushCurrent();
        currentTitle = line.slice(5, -5).trim();
      } else if (line === "=====") {
        flushCurrent();
      } else if (line) {
        curLines.push(line.replace(/\t/g, "→").replace(/    /g, "→"));
      }
    }
    flushCurrent();
    if (this.customPhrases.length === 0) {
      this.customPhrases.push({
        title: "Custom Base",
        text: "prova digitazione custom file",
      });
    }
  }

  initSession() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.loadExercise();
  }

  startTimerIfNeeded() {
    if (!this.startTime) {
      this.startTime = new Date();
      this.lastKeystrokeTime = this.startTime;
      if (this.mode !== 4) {
        this.timerInterval = setInterval(() => this.updateMetrics(), 200);
      }
    }
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  resetSessionMetrics() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  resetTypingSession() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  loadExercise() {
    if (this.mode === 0) {
      const lesson = this.lessons[this.currentLessonIdx] || this.lessons[0];
      const phrases = lesson.phrases || ["asdfl"];
      if (this.currentPhraseIdx >= phrases.length) this.currentPhraseIdx = 0;
      if (this.currentPhraseIdx < 0) this.currentPhraseIdx = phrases.length - 1;
      // Preservazione del marcatore Invio ("®") ed interpretazione di Tab fisici (\t) o 4 spazi come "→"
      const rawPhrase = phrases[this.currentPhraseIdx] || "";
      this.originText = rawPhrase.replace(/\t/g, "→").replace(/    /g, "→");
    } else if (this.mode === 1) {
      const currentLessonKey = this.lessons[this.currentLessonIdx].name;
      let pool = "";
      for (let i = 0; i <= this.currentLessonIdx; i++) {
        pool += this.lessons[i].name;
      }
      pool = pool
        .replace(/Spazio/g, " ")
        .replace(/ShiftDestro/g, "QERTASDFGZCV")
        .replace(/ShiftSinistro/g, "UIOPHLBNM")
        .replace(/Invio/g, "®")
        .replace(/Tab/g, "→");
      if (pool.length === 0) pool = "asdf";

      let res = "";
      for (let i = 0; i < 20; i++) {
        if (
          Math.random() < 0.4 &&
          currentLessonKey.length > 0 &&
          currentLessonKey.length < 5
        ) {
          res +=
            currentLessonKey[
              Math.floor(Math.random() * currentLessonKey.length)
            ];
        } else {
          res += pool[Math.floor(Math.random() * pool.length)];
        }
      }
      this.originText = res;
    } else if (this.mode === 2) {
      this.originText = this.phonemeEng.generate();
    } else if (this.mode === 3) {
      const all =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZòùàìèé1234567890<>=+-*/()[]{}.,:;?!'^§\"|_@#ç°£$%&";
      let arr = all.split("");
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      this.originText = arr.slice(0, 50).join("");
    } else if (this.mode === 4) {
      this.originText = "";
    } else if (this.mode === 5) {
      if (this.originText) {
        let arr = this.originText.split("");
        for (let i = arr.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        this.originText = arr.join("");
      }
    } else if (this.mode === 6) {
      // MODALITÀ 6: WEAKNESSES (CARENZE) - 30 CARATTERI PONDERATI A SCALA QUADRATICA
      const p = this.profileMgr?.profile;
      let candidates = [];

      if (p && p.Caratteri && p.Caratteri.length > 0) {
        // Soglia di confidenza minima: protegge i nuovi profili escludendo errori accidentali (Frequenza >= 3)
        let filteredPool = p.Caratteri.filter(
          (c) => (c.Errori || 0) > 0 && (c.Frequenza || 0) >= 3,
        );

        // Fallback progressivo: se nessun tasto raggiunge 3 battute, accetta qualsiasi errore registrato
        if (filteredPool.length === 0) {
          filteredPool = p.Caratteri.filter(
            (c) => (c.Errori || 0) > 0 && (c.Frequenza || 0) > 0,
          );
        }

        const withErrors = filteredPool
          .map((c) => {
            const ch = String.fromCharCode(c.CharUnicode);
            const rate = (c.Errori / c.Frequenza) * 100;
            return { char: ch, rate: rate };
          })
          .filter(
            (item) =>
              item.char !== "\n" &&
              item.char !== "®" &&
              item.char !== "\t" &&
              item.char !== "→",
          )
          .sort((a, b) => b.rate - a.rate);

        // Selezione delle prime 10 carenze con Errore Relativo (%) più alto
        candidates = withErrors.slice(0, 10);
      }

      // Caso Limite A: se non vi sono errori nel profilo, fallback sui 10 tasti tipicamente più ostici
      if (candidates.length === 0) {
        const fallbackKeys = ["q", "z", "p", "ò", "à", "ù", "è", "x", "y", "-"];
        candidates = fallbackKeys.map((k) => ({ char: k, rate: 10 }));
      }

      // Precalcolo dei pesi quadratici O(N) una sola volta prima del ciclo di estrazione
      const esponente = 2;
      candidates.forEach((c) => {
        c.weight = c.rate ** esponente;
      });

      const totalWeight = candidates.reduce(
        (sum, item) => sum + item.weight,
        0,
      );

      // Estrazione stocastica ponderata (Roulette Wheel Selection) su 30 battute
      let res = "";
      for (let i = 0; i < 30; i++) {
        let r = Math.random() * totalWeight;
        let chosenChar = candidates[0].char;
        for (let c of candidates) {
          if (r < c.weight) {
            chosenChar = c.char;
            break;
          }
          r -= c.weight;
        }
        res += chosenChar;
      }
      this.originText = res;
    }
  }

  handleKeyInput(charKey, isBack) {
    if (this.isCompleted) return;

    if (this.mode === 4) {
      this.startTimerIfNeeded();
      this.lastKeystrokeTime = new Date();
      this.countTotalChars++;
      if (isBack) {
        this.countBackChars++;
        this.typedText = this.typedText.slice(0, -1);
      } else if (charKey.length === 1 || charKey === "\n" || charKey === "®") {
        this.audio.playKey();
        this.typedText += charKey === "®" ? "\n" : charKey;
      }
      this.updateMetrics();
      return { status: "typing", typed: this.typedText };
    }

    if (isBack) {
      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText = this.typedText.slice(0, -1);
        this.countBackChars++;

        // Riarmo del gate quando la cancellazione rimuove tutti i caratteri rossi
        const matchLen = this.getMatchLength();
        if (this.typedText.length <= matchLen) {
          this.currentTargetHasError = false;
        }

        this.updateMetrics();
        return { status: "back", typed: this.typedText };
      }
      return { status: "ignored" };
    }

    this.startTimerIfNeeded();
    this.countTotalChars++;
    const targetChar = this.originText[this.typedText.length];

    const isEnterTarget = targetChar === "®" || targetChar === "\n";
    const isTabTarget = targetChar === "→" || targetChar === "\t";
    const isEnterKey =
      charKey === "Enter" || charKey === "\n" || charKey === "®";
    const isTabKey = charKey === "Tab" || charKey === "\t" || charKey === "→";

    const isMatch =
      charKey === targetChar ||
      (isEnterTarget && isEnterKey) ||
      (isTabTarget && isTabKey);

    if (isMatch) {
      this.audio.playKey();
      this.typedText += charKey;
      this.recordCharStat(charKey, false);
      this.currentTargetHasError = false; // Tasto corretto digitato: reset gate per il prossimo target

      const hasErrorsToCorrect =
        this.typedText.length > 0 &&
        this.typedText !== this.originText.slice(0, this.typedText.length);
      if (
        this.typedText.length === this.originText.length &&
        !hasErrorsToCorrect
      ) {
        this.isCompleted = true;
        this.stopTimer();
        this.audio.playBell();
        this.recordCompletedSample();
        this.updateMetrics();
        return { status: "completed", typed: this.typedText };
      }
      this.updateMetrics();
      return {
        status: "correct",
        typed: this.typedText,
        nextChar: this.originText[this.typedText.length],
      };
    } else {
      this.audio.playError();

      // Cattura condizionata: solo se non vi sono caratteri rossi nel Testo Guida
      const isCapturable = this.canCaptureError();
      if (isCapturable) {
        this.countErrors++;
        if (targetChar) this.recordCharStat(targetChar, true);
        this.sessionErrors.push({
          expected: targetChar || "⌫",
          wrong: charKey,
        });
        this.currentTargetHasError = true;
      }

      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText += charKey;
        this.updateMetrics();
        return {
          status: "error",
          typed: this.typedText,
          wrongChar: charKey,
          expectedChar: targetChar || "⌫",
          captured: isCapturable,
        };
      } else {
        this.updateMetrics();
        return {
          status: "error-corrected",
          wrongChar: charKey,
          expectedChar: targetChar || "⌫",
          captured: isCapturable,
        };
      }
    }
  }

  recordCharStat(char, isError) {
    if (!char || typeof char !== "string" || char.length === 0) return;
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    p.TotaleCaratteri = (p.TotaleCaratteri || 0) + 1;
    if (isError) p.TotaleErrori = (p.TotaleErrori || 0) + 1;

    const ucode = char.charCodeAt(0);
    let item = (p.Caratteri || []).find((c) => c.CharUnicode === ucode);
    if (!item) {
      item = {
        Index: (p.Caratteri || []).length,
        CharUnicode: ucode,
        Frequenza: 0,
        Errori: 0,
      };
      if (!p.Caratteri) p.Caratteri = [];
      p.Caratteri.push(item);
    }
    item.Frequenza++;
    if (isError) item.Errori++;
    this.profileMgr.saveProfile();
  }

  // Memorizzazione di Data e Ora locale italiana (orologio PC)
  recordCompletedSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const rightChars = this.originText.length;
    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;

    let stype = 1;
    if (this.mode === 0) stype = 1;
    else if (this.mode === 1) stype = 3;
    else if (this.mode === 2) stype = 7;
    else if (this.mode === 3) stype = 6;
    else if (this.mode === 4) stype = 4;
    else if (this.mode === 5) stype = 5;
    else if (this.mode === 6) stype = 8; // Caso Limite C: TipoCampione 8 per Carenze

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: stype,
      NumCaratteri: rightChars,
      NumErrori: this.countErrors,
      Esercizio: this.getCurrentExerciseTitle(),
      DataOra: getLocalISODateTime(), // Timestamp locale del PC
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
  }

  // Memorizzazione di Data e Ora per sessioni libere di digitazione
  recordManualTypingSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const chars = this.typedText.length;
    if (chars === 0) return;
    const netBpm = minutes > 0 ? Math.round(chars / minutes) : 0;

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: 4,
      NumCaratteri: chars,
      NumErrori: this.countBackChars,
      Esercizio: "Free Typing",
      DataOra: getLocalISODateTime(), // Timestamp locale del PC
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
    this.resetTypingSession();
  }

  getCurrentExerciseTitle() {
    if (this.mode === 0)
      return `Lezione ${this.currentLessonIdx + 1}: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 1)
      return `Random: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 2) return "Fonemi Italiani";
    if (this.mode === 3) return "All Chars";
    if (this.mode === 4) return "Digitazione Libera";
    if (this.mode === 5) return "Random This Phrase";
    if (this.mode === 6) return "Weaknesses (Carenze)";
    return "";
  }

  getElapsedMinutes() {
    if (!this.startTime) return 0;
    if (this.mode === 4) {
      if (!this.lastKeystrokeTime) return 0;
      return (this.lastKeystrokeTime - this.startTime) / 60000;
    }
    return (new Date() - this.startTime) / 60000;
  }

  updateMetrics() {
    const minutes = this.getElapsedMinutes();
    const totalSecs = Math.floor(minutes * 60);
    const mm = String(Math.floor(totalSecs / 60)).padStart(2, "0");
    const ss = String(totalSecs % 60).padStart(2, "0");

    let rightChars = 0;
    if (this.mode === 4) {
      rightChars = this.typedText.length;
    } else {
      let i = 0;
      while (
        i < this.typedText.length &&
        i < this.originText.length &&
        this.typedText[i] === this.originText[i]
      ) {
        i++;
      }
      rightChars = i;
    }

    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;
    const grossBpm =
      minutes > 0 ? Math.round(this.countTotalChars / minutes) : 0;
    const errCount = this.mode === 4 ? this.countBackChars : this.countErrors;
    const errPerc =
      rightChars > 0 ? ((errCount / rightChars) * 100).toFixed(1) : "0.0";

    const elTime = document.getElementById("txtTime");
    const elRight = document.getElementById("txtRightChars");
    const elNet = document.getElementById("txtRightEverage");
    const elGross = document.getElementById("txtTotalEverage");
    const elErr = document.getElementById("txtErrors");
    const elPerc = document.getElementById("txtPercErrors");

    if (elTime) elTime.innerText = `${mm}:${ss}`;
    if (elRight) elRight.innerText = rightChars;
    if (elNet) elNet.innerText = netBpm;
    if (elGross) elGross.innerText = grossBpm;
    if (elErr) elErr.innerText = errCount;
    if (elPerc) elPerc.innerText = `${errPerc}%`;

    if (this.mode === 4) {
      const fixTime = document.getElementById("txtFixingTime");
      const fixNet = document.getElementById("txtFixingRightEverage");
      const fixGross = document.getElementById("txtFixingTotalEverage");
      if (fixTime) fixTime.innerText = `${mm}:${ss}`;
      if (fixNet) fixNet.innerText = netBpm;
      if (fixGross) fixGross.innerText = grossBpm;
    }
  }
}

// KEYBOARD & HANDS RENDERERS
class VisualRenderer {
  constructor() {
    this.currentTargetKey = null;
    this.currentModifierKey = null;
    this.activePhysicalKeys = new Map();
  }

  highlightTarget(char) {
    this.setTargetChar(char);
  }

  setTargetChar(char) {
    this.currentTargetChar = char;
    document
      .querySelectorAll(".key.active-target")
      .forEach((el) => el.classList.remove("active-target"));
    document
      .querySelectorAll(".hand-finger.finger-active")
      .forEach((el) => el.classList.remove("finger-active"));
    for (let f = 1; f <= 10; f++) {
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }

    if (!char) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = "Tastiera e Mani a riposo";
      return;
    }

    const chord = resolveTargetChord(char);
    if (!chord) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = `Carattere: "${char}"`;
      return;
    }

    chord.keyIds.forEach((id) => {
      const keyEl = document.getElementById(id);
      if (keyEl) keyEl.classList.add("active-target");
    });

    chord.fingers.forEach((fInfo) => {
      const fingerEl = document.getElementById(`hand_finger_${fInfo.finger}`);
      if (fingerEl) fingerEl.classList.add("finger-active");

      const grp = document.getElementById(
        `hand_finger_keycap_group_${fInfo.finger}`,
      );
      if (grp) grp.style.display = "inline";

      const tip = document.getElementById(`hand_finger_tip_${fInfo.finger}`);
      if (tip) tip.textContent = fInfo.label;

      const rect = document.getElementById(
        `hand_finger_keycap_rect_${fInfo.finger}`,
      );
      if (rect) {
        const textLen = (fInfo.label || "").length;
        const origCx = parseFloat(
          rect.getAttribute("data-cx") ||
            parseFloat(rect.getAttribute("x")) + 29,
        );
        const origCy = parseFloat(
          rect.getAttribute("data-cy") ||
            parseFloat(rect.getAttribute("y")) + 26,
        );
        if (textLen > 2) {
          const w = Math.max(108, Math.round(textLen * 22.5 + 39));
          rect.setAttribute("width", w);
          rect.setAttribute("x", origCx - w / 2);
        } else {
          rect.setAttribute("width", 87);
          rect.setAttribute("x", origCx - 43.5);
        }
        rect.setAttribute("height", 78);
        rect.setAttribute("y", origCy - 39);
      }
    });

    const handText = document.getElementById("handIndicatorText");
    if (handText) {
      if (chord.fingers.length > 1) {
        const desc = chord.fingers
          .map((f) => `${FINGER_NAMES[f.finger]} (${f.label})`)
          .join(" + ");
        handText.innerText = `Accordo: ${desc}`;
      } else {
        handText.innerText = `${FINGER_NAMES[chord.info.finger]} → Tasto "${chord.info.name}"`;
      }
    }
  }

  updateCapsLockLed(isActive) {
    const capsEl = document.getElementById("key_caps");
    if (capsEl) {
      if (isActive) {
        capsEl.classList.add("caps-active");
      } else {
        capsEl.classList.remove("caps-active");
      }
    }
  }

  getKeyIdForEvent(keyOrChar, eventCode = null, eventLocation = null) {
    if (keyOrChar === "Tab") return "key_tab";
    if (keyOrChar === "CapsLock") return "key_caps";
    if (keyOrChar === "Backspace") return "key_backspace";
    if (keyOrChar === "Enter") return "key_enter";
    if (keyOrChar === "ContextMenu") return "key_menu";
    if (keyOrChar === " " || eventCode === "Space") return "key_space";
    if (keyOrChar === "Shift") {
      return eventCode === "ShiftRight" || eventLocation === 2
        ? "key_shift_r"
        : "key_shift_l";
    }
    if (keyOrChar === "Control") {
      return eventCode === "ControlRight" || eventLocation === 2
        ? "key_ctrl_r"
        : "key_ctrl_l";
    }
    if (keyOrChar === "Alt") {
      return eventCode === "AltRight" || eventLocation === 2
        ? "key_altgr"
        : "key_alt_l";
    }
    if (keyOrChar === "AltGraph") return "key_altgr";
    if (keyOrChar === "Meta" || keyOrChar === "OS") {
      return eventCode === "MetaRight" || eventLocation === 2
        ? "key_win_r"
        : "key_win_l";
    }

    if (KEY_MAP[keyOrChar]) {
      return KEY_MAP[keyOrChar].id;
    }
    const lower = keyOrChar.toLowerCase();
    if (KEY_MAP[lower]) {
      return KEY_MAP[lower].id;
    }
    if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const char = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[char]) return KEY_MAP[char].id;
      }
      if (eventCode.startsWith("Digit")) {
        const digit = eventCode.slice(5);
        if (KEY_MAP[digit]) return KEY_MAP[digit].id;
      }
    }
    return null;
  }

  setKeyPressed(
    keyOrChar,
    eventCode = null,
    eventLocation = null,
    isDown = true,
  ) {
    const keyId = this.getKeyIdForEvent(keyOrChar, eventCode, eventLocation);
    if (!keyId) return;
    const el = document.getElementById(keyId);
    if (el) {
      if (isDown) {
        el.classList.add("key-pressed");
      } else {
        el.classList.remove("key-pressed");
      }
    }
  }

  flashPressedKey(keyOrChar, eventCode = null, eventLocation = null) {
    this.setKeyPressed(keyOrChar, eventCode, eventLocation, true);
    setTimeout(
      () => this.setKeyPressed(keyOrChar, eventCode, eventLocation, false),
      180,
    );
  }

  adjustHandsViewport(width, height) {
    const svg = document.getElementById("handsSvg");
    const lblL = document.getElementById("lblLeftHand");
    const lblR = document.getElementById("lblRightHand");
    if (!svg) return;

    const w = Math.max(300, width);
    const h = Math.max(180, height);

    const refScale = 1408 / 580;
    let vbW = Math.max(1060, Math.min(1408, Math.round(w * refScale)));
    let vbX = Math.round(704 - vbW / 2);

    let vbH = Math.max(460, Math.min(768, Math.round(h * refScale)));
    let vbY = 20;

    svg.setAttribute("viewBox", `${vbX} ${vbY} ${vbW} ${vbH}`);

    const labelY = Math.min(730, Math.max(480, vbY + vbH - 30));
    if (lblL) lblL.setAttribute("y", labelY);
    if (lblR) lblR.setAttribute("y", labelY);

    // Riposizionamento dinamico elementi di Errore in base all'altezza reale della finestra
    const errRect = document.getElementById("handsCentralErrorRect");
    const errText = document.getElementById("handsCentralErrorText");
    const succRect = document.getElementById("handsCentralSuccessRect");
    const succText = document.getElementById("handsCentralSuccessText");
    const errCount = document.getElementById("handsErrorCountText");

    // Scritta "Errori: #" ancorata in alto al centro
    if (errCount) {
      errCount.setAttribute("y", vbY + 45);
    }

    // Badge "ERRORE" e "FINITO" ancorati in basso al centro, alle medesime coordinate (sopra le label anatomiche)
    const badgeY = Math.min(660, Math.max(400, vbY + vbH - 90));

    if (errRect && errText) {
      errRect.setAttribute("y", badgeY);
      errText.setAttribute("y", badgeY + 31); // Offset di 31px per centrare il testo verticalmente nel rect
    }

    if (succRect && succText) {
      succRect.setAttribute("y", badgeY);
      succText.setAttribute("y", badgeY + 31);
    }
  }

  getFingersForPhysicalKey(keyOrChar, eventCode = null, eventLocation = null) {
    let fingers = [];
    if (keyOrChar === " " || eventCode === "Space") {
      fingers = [{ finger: 5, label: "SPAZIO" }];
    } else if (keyOrChar === "Enter" || eventCode === "Enter") {
      fingers = [{ finger: 10, label: "INVIO" }];
    } else if (keyOrChar === "Backspace" || eventCode === "Backspace") {
      fingers = [{ finger: 10, label: "⌫" }];
    } else if (keyOrChar === "Tab" || eventCode === "Tab") {
      fingers = [{ finger: 1, label: "TAB" }];
    } else if (keyOrChar === "Shift") {
      const f = eventCode === "ShiftRight" || eventLocation === 2 ? 10 : 1;
      fingers = [{ finger: f, label: "SHIFT" }];
    } else if (keyOrChar === "Control") {
      const f = eventCode === "ControlRight" || eventLocation === 2 ? 10 : 1;
      fingers = [{ finger: f, label: "CTRL" }];
    } else if (keyOrChar === "Alt") {
      const f = eventCode === "AltRight" || eventLocation === 2 ? 6 : 5;
      fingers = [{ finger: f, label: f === 6 ? "ALT GR" : "ALT" }];
    } else if (keyOrChar === "AltGraph") {
      fingers = [{ finger: 6, label: "ALT GR" }];
    } else if (keyOrChar === "CapsLock") {
      fingers = [{ finger: 1, label: "CAPS" }];
    } else if (keyOrChar && keyOrChar.length === 1) {
      const lower = keyOrChar.toLowerCase();
      if (KEY_MAP[lower]) {
        fingers = [
          { finger: KEY_MAP[lower].finger, label: keyOrChar.toUpperCase() },
        ];
      } else if (KEY_MAP[keyOrChar]) {
        fingers = [
          { finger: KEY_MAP[keyOrChar].finger, label: keyOrChar.toUpperCase() },
        ];
      }
    } else if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const ch = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[ch]) {
          fingers = [{ finger: KEY_MAP[ch].finger, label: ch.toUpperCase() }];
        }
      } else if (eventCode.startsWith("Digit")) {
        const d = eventCode.slice(5);
        if (KEY_MAP[d]) {
          fingers = [{ finger: KEY_MAP[d].finger, label: d }];
        }
      }
    }
    return fingers;
  }

  setPhysicalKeyDown(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (!keyId) return;

    const fingers = this.getFingersForPhysicalKey(
      keyOrChar,
      eventCode,
      eventLocation,
    );
    if (fingers.length === 0) return;

    this.activePhysicalKeys.set(keyId, fingers);
    this.renderActivePhysicalChord();
  }

  setPhysicalKeyUp(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (keyId) {
      this.activePhysicalKeys.delete(keyId);
    }
    if (keyOrChar && this.activePhysicalKeys.has(keyOrChar)) {
      this.activePhysicalKeys.delete(keyOrChar);
    }

    if (this.activePhysicalKeys.size > 0) {
      this.renderActivePhysicalChord();
    } else {
      this.clearAllPhysicalFingers();
    }
  }

  renderActivePhysicalChord() {
    const activeFingerMap = new Map();

    let hasLeftCtrl = false;
    let hasLeftShift = false;
    let hasLeftAlt = false;

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        if (
          keyId === "ControlLeft" ||
          keyId.startsWith("Control_ControlLeft") ||
          (item.finger === 1 && item.label === "CTRL")
        )
          hasLeftCtrl = true;
        if (
          keyId === "ShiftLeft" ||
          keyId.startsWith("Shift_ShiftLeft") ||
          (item.finger === 1 && item.label === "SHIFT")
        )
          hasLeftShift = true;
        if (
          keyId === "AltLeft" ||
          keyId.startsWith("Alt_AltLeft") ||
          (item.finger === 5 && item.label === "ALT")
        )
          hasLeftAlt = true;
      }
    }

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        let f = item.finger;
        let lbl = item.label;

        if (hasLeftCtrl && hasLeftShift) {
          if (
            keyId === "ShiftLeft" ||
            keyId.startsWith("Shift_ShiftLeft") ||
            (item.finger === 1 && lbl === "SHIFT")
          ) {
            f = 2; // Anulare Sinistro (Dito 2) per SHIFT quando premuto con CTRL
          } else if (
            keyId === "ControlLeft" ||
            keyId.startsWith("Control_ControlLeft") ||
            (item.finger === 1 && lbl === "CTRL")
          ) {
            f = 1; // Mignolo Sinistro (Dito 1) per CTRL
          }
        }
        if (
          hasLeftAlt &&
          (keyId === "AltLeft" ||
            keyId.startsWith("Alt_AltLeft") ||
            lbl === "ALT")
        ) {
          f = 5; // Pollice Sinistro (Dito 5) per ALT
        }
        activeFingerMap.set(f, lbl);
      }
    }

    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      const rect = document.getElementById(`hand_finger_keycap_rect_${f}`);

      if (activeFingerMap.has(f)) {
        const label = activeFingerMap.get(f);
        if (fingerEl) fingerEl.classList.add("finger-active");
        if (grp) grp.style.display = "inline";
        if (tip) tip.textContent = label;

        if (rect) {
          const textLen = (label || "").length;
          const origCx = parseFloat(rect.getAttribute("data-cx") || "215");
          const origCy = parseFloat(rect.getAttribute("data-cy") || "340");
          if (textLen > 2) {
            const w = Math.max(108, Math.round(textLen * 22.5 + 39));
            rect.setAttribute("width", w);
            rect.setAttribute("x", origCx - w / 2);
          } else {
            rect.setAttribute("width", 87);
            rect.setAttribute("x", origCx - 43.5);
          }
          rect.setAttribute("height", 78);
          rect.setAttribute("y", origCy - 39);
        }
      } else {
        if (fingerEl) fingerEl.classList.remove("finger-active");
        if (grp) grp.style.display = "none";
        if (tip) tip.textContent = "";
      }
    }
  }

  clearAllPhysicalFingers() {
    this.activePhysicalKeys.clear();
    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      if (fingerEl) fingerEl.classList.remove("finger-active");
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }
    const appInstance = window.app || window.__app;
    if (
      this.currentTargetChar &&
      appInstance &&
      appInstance.typingEng &&
      appInstance.typingEng.mode !== 4 &&
      !appInstance.typingEng.isCompleted
    ) {
      this.setTargetChar(this.currentTargetChar);
    }
  }

  // Metodi di compatibilità retroattiva
  showPressedFingers(keyOrChar, eventCode = null, eventLocation = null) {
    this.setPhysicalKeyDown(keyOrChar, eventCode, eventLocation);
  }

  clearPressedFingers() {
    this.clearAllPhysicalFingers();
  }
}
