# Motore di selezione INTERROGAZIONE — v1.2

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.24  
**Fonti:** HANDOFF TECNICO INTERROGAZIONE v1.0; Contratti Backend Interrogazione v1.4; Schema IndexedDB v1.3; Specifica PRNG Interrogazione v1.0; Decisione Quote Adattive D77–D80 v1.1; Catalogo Domande Interrogazione v1.0, seed QWERTY v1.0 e manifest candidate v1.1  
**Stato:** specifica esecutiva aggiornata; PRNG congelato; perimetro A e 225 candidate verificati; nessuna modifica ai sorgenti  
**Ambito:** selezione casuale, adattiva e manuale; pianificazione dei conteggi; priorità di consultazione; determinismo e test

---

## 1. Scopo e vincoli

Il motore produce una selezione di domande principali per una nuova sessione, senza scrivere su IndexedDB e senza aggiornare lo storico. La persistenza e l'avanzamento restano responsabilità di `InterrogationSessionManager` e `InterrogationRepository`.

Vincoli inderogabili:

- JavaScript classico, compatibile con la baseline; nessun framework, TypeScript o modulo ES.
- La selezione adattiva legge esclusivamente conoscenza della stessa tipologia richiesta.
- La selezione casuale pura non legge classificazioni, affidabilità, errori, consultazioni o scadenze.
- La selezione manuale rispetta l'ordine scelto dall'utente; i duplicati sono vietati per default e consentibili soltanto nella sessione manuale corrente.
- La selezione non registra esposizioni. Un'esposizione nasce soltanto dalla valutazione o consultazione effettiva del sotto-quesito.
- Catalogo, configurazione, statistiche e algoritmo vengono congelati nello snapshot della sessione.
- Le sessioni sospese non vengono ricalcolate.
- Il motore non inventa domande: usa esclusivamente definizioni e template attivi e validati nel catalogo versionato.

## 2. Unità di selezione e modello candidato

L'unità selezionata è una **domanda principale** (candidate), non il singolo sotto-quesito. Ogni candidate deve contenere:

- `candidateId` stabile e univoco nel catalogo;
- `questionType` (HOME_ROW, TASTO, CARATTERE, DITO);
- `categoryId` coerente con la tipologia;
- `elementSemanticIds` coinvolti;
- elenco ordinato di `questionSemanticIds` attivi che compongono la domanda;
- `promptTemplateId` e dati di presentazione risolvibili;
- `catalogVersion` e versioni delle definizioni.

La selezione di un candidate congela tutti i suoi sotto-quesiti nel `sessionItem`. I sotto-quesiti mantengono identità, valutazione e statistiche indipendenti. Una domanda principale composta da quattro sotto-quesiti HOME_ROW conta come **una domanda** ai fini della quota e del numero richiesto, ma produce quattro esiti autonomi.

Il catalogo Domande v1.0 descrive cinque template principali e 445 definizioni attive. Per la prima release è approvato il perimetro parziale di 52 tasti fisici verificati, rappresentato da 225 candidate espliciti nel manifest `Candidati_Interrogazione_v1.1.json`. Il motore accetta esclusivamente questi candidate; non deve generare combinazioni mancanti né estendere il catalogo per inferenza. I 53 elementi non coperti restano fuori ambito e non sono un blocco per la release A.

## 3. Input e output del motore

### 3.1 Input normalizzato

```js
{
  mode: "adaptive", // adaptive | random | manual
  questionType: "mixed", // mixed | HOME_ROW | TASTO | CARATTERE | DITO
  requestedCount: 10,
  categoryQuotas: {
    HOME_ROW: 25,
    TASTO: 25,
    CARATTERE: 25,
    DITO: 25
  },
  adaptiveStratumQuotas: {
    neverVerified: 30,
    weak: 40,
    review: 20,
    consolidated: 10
  },
  adaptiveQuotaParameters: {
    algorithmVersion: "1.1",
    globalBudget: 0.10,
    individualCapRate: 0.20,
    neutralDistribution: "equal"
  },
  profileId: "...",
  catalogVersion: "...",
  algorithmSeed: "000102030405060708090a0b0c0d0e0f", // 32 caratteri hex, encoding hex-128be
  candidates: [],
  knowledgeSnapshot: [],
  pendingConsultationPriorities: [],
  manualCandidateIds: [],
  allowManualDuplicates: false
}
```

Le quote di categoria sono espresse in percentuale e normalizzate sulle sole categorie disponibili. Le quote adattive interne sono percentuali e sommano al 100%. I valori sono snapshot di configurazione, non letture dinamiche durante la selezione.

`knowledgeSnapshot` contiene una proiezione coerente alla stessa data di calcolo, per profilo e tipologia. Non si mescolano record provenienti da ricalcoli differenti.

### 3.2 Output

```js
{
  algorithmVersion: "selection-1.0",
  mode: "adaptive",
  seed: "...", // seed canonico hex-128be
  catalogVersion: "...",
  requestedCount: 10,
  effectiveCount: 10,
  categoryPlan: [],
  stratumPlan: [],
  selectedCandidateIds: [],
  priorityCandidateIds: [],
  warnings: [],
  diagnostics: {}
}
```

L'output è puro e riproducibile: stessi input, stesso seed e stesse versioni producono lo stesso output. Timestamp e identificativi di sessione sono aggiunti dal chiamante e non influenzano il risultato.

## 4. Preparazione del pool

Prima di qualsiasi riparto:

1. Filtrare `status === "active"` e `catalogVersion` compatibile.
2. Escludere candidate con sotto-quesiti non attivi, risposte attese mancanti o relazioni non risolvibili.
3. Applicare il filtro di tipologia richiesto; `mixed` ammette tutte le quattro tipologie.
4. Escludere candidate non selezionabili per vincoli espliciti del catalogo.
5. Deduplicare per `candidateId`; duplicati nel catalogo sono errore di validazione, non vengono risolti silenziosamente.
6. Calcolare la disponibilità per categoria e per strato adattivo.

Un candidate non può essere selezionato due volte nella stessa sessione adattiva o casuale. Per la selezione manuale i duplicati seguono esclusivamente `allowManualDuplicates`.

Se il numero di candidate unici disponibili è inferiore a `requestedCount`, il motore restituisce `effectiveCount` pari al numero effettivo e un warning `INSUFFICIENT_CANDIDATES`. Il SessionManager deve mostrare l'avviso e chiedere procedere/annullare prima di creare la sessione. Il motore non decide autonomamente per l'utente.

## 5. Modalità casuale pura

1. Preparare il pool valido e filtrato per tipologia.
2. Ignorare completamente `knowledgeSnapshot` e `pendingConsultationPriorities`.
3. Mescolare il pool con PRNG deterministico inizializzato da `algorithmSeed`.
4. Prendere i primi `effectiveCount` candidate.
5. Conservare l'ordine prodotto nel risultato.

La modalità casuale non applica quote adattive per categoria o classificazione: per una sessione mista casuale il campionamento è uniforme sul pool di candidate valide, non proporzionale alle statistiche. Eventuali quote manuali per categoria non sono introdotte dalla modalità casuale in questa versione.

Il seed deve essere creato dal chiamante una sola volta all'avvio e salvato nello snapshot. La generazione preferita usa `crypto.getRandomValues`; il fallback `Math.random` è ammesso soltanto per il seed iniziale, con warning e marcatura non crittografica. Il generatore e tutte le estrazioni successive sono definiti da `Specifica_PRNG_Interrogazione_v1.0.md` e non usano `Math.random()` globale.

## 6. Modalità adattiva

La modalità adattiva applica due livelli di riparto:

1. quota tra le categorie (HOME_ROW, TASTO, CARATTERE, DITO);
2. quota tra gli strati di conoscenza all'interno di ciascuna categoria.

Tutti i calcoli usano esclusivamente il knowledge snapshot della tipologia corrispondente.

### 6.1 Strati di conoscenza

Ogni sotto-quesito selezionabile viene classificato in uno dei quattro strati:

- `neverVerified`: nessuna esposizione effettiva; escluso dall'indice composito e trattato con priorità dedicata;
- `weak`: classificazione Debole, indice corretto da 70 a 100;
- `review`: classificazione Da ripassare, indice corretto da 30 a meno di 70;
- `consolidated`: classificazione Consolidato, indice corretto da 0 a meno di 30.

Le soglie sono quelle consolidate nella specifica funzionale. Gli eventi annullati da correzioni non concorrono alle esposizioni effettive. Visualizzazione e mancata risposta non creano esposizioni.

Per un candidate composto da più sotto-quesiti si determina lo strato di selezione con questa regola prudenziale e deterministica:

1. se almeno un sotto-quesito è `neverVerified`, il candidate appartiene a `neverVerified`;
2. altrimenti appartiene allo strato peggiore presente tra i suoi sotto-quesiti, secondo ordine `weak`, `review`, `consolidated`.

La regola evita che una domanda composta nasconda un sotto-quesito mai verificato o debole dietro altri sotto-quesiti consolidati. Gli esiti dei sotto-quesiti restano comunque separati.

### 6.2 Quote interne per strato

Quote predefinite:

| Strato | Quota obiettivo |
|---|---:|
| Mai verificati | 30% |
| Deboli | 40% |
| Da ripassare | 20% |
| Consolidati | 10% |

Per ogni categoria, i conteggi obiettivo vengono calcolati sui candidate disponibili in ciascuno strato. Se uno strato è vuoto, la sua quota viene redistribuita tra gli strati non vuoti in proporzione alle rispettive quote originarie (30/40/20/10), poi convertita in conteggi interi con maggiori resti.

Se la categoria contiene meno candidate del conteggio obiettivo totale, il conteggio effettivo è limitato alla disponibilità; il residuo viene riassegnato agli altri strati non saturi usando le stesse proporzioni originarie e ripetendo fino a esaurimento o assenza di capacità. Nessun candidate viene duplicato per soddisfare una quota.

### 6.3 Quote tra categorie

Per sessioni miste, le quote base di categoria provengono dalla configurazione profilo; default 25% ciascuna. Le categorie prive di candidate sono escluse prima della normalizzazione. Le quote originarie delle categorie disponibili vengono rinormalizzate in modo che la somma sia 100%.

Le quote adattive di categoria sono quindi corrette applicando integralmente la Decisione Quote Adattive D77–D80 v1.1:

- budget globale `B = 0,10` (10 punti percentuali);
- tetto individuale `cap_i = 0,20 × quotaBaseNormalizzata_i`;
- deficit `d_i = 1 - affidabilitàCategoria_i`;
- distribuzione proporzionale ai deficit con redistribuzione iterativa;
- residuo non assegnabile come quota neutra, distribuita equamente tra tutte le categorie disponibili;
- in assenza totale di deficit, nessun prelievo e quote base invariate;
- prelievo proporzionale alle quote base quando esiste almeno una categoria eleggibile;
- conversione finale in conteggi interi con maggiori resti.

L'affidabilità categoria deriva dalla regola consolidata: indice medio ponderato per affidabilità, copertura separata e affidabilità categoria pari ad affidabilità media moltiplicata per copertura. Il motore di selezione non ricalcola tali metriche: le riceve dal motore `InterrogationKnowledge`.

Per sessioni mirate a una sola tipologia, la categoria selezionata è quella tipologica richiesta e riceve il 100% dei posti; non si applica il riparto tra tipologie.

### 6.4 Conversione in conteggi interi

Applicare il metodo dei maggiori resti separatamente:

- ai conteggi per categoria, partendo dalle quote finali;
- ai conteggi per strato dentro ciascuna categoria, partendo dalle quote interne normalizzate.

Per la distribuzione tra categorie, i pareggi dei resti sono risolti nell'ordine:

1. maggiore debolezza categoria;
2. minore affidabilità categoria;
3. ordine canonico `HOME_ROW`, `TASTO`, `CARATTERE`, `DITO`.

Per la distribuzione interna agli strati, i pareggi sono risolti nell'ordine:

1. strato più prioritario (`neverVerified`, `weak`, `review`, `consolidated`);
2. ordine lessicografico stabile dello strato.

Ogni passaggio deve garantire che la somma dei conteggi coincida esattamente con il numero di posti assegnato al livello superiore.

### 6.5 Selezione dei candidate dentro uno strato

Dopo aver calcolato i conteggi, i candidate vengono ordinati e campionati senza ripetizione.

Ordine di priorità adattiva:

1. candidate con consultazione pendente della stessa tipologia, generata dalla sessione adattiva precedente;
2. candidate con verifica scaduta da più tempo, se il dato `nextReviewAt` è disponibile;
3. candidate con indice di debolezza corretto più alto;
4. candidate con affidabilità minore;
5. tie-break deterministico tramite PRNG seeded.

La priorità di consultazione è temporanea e viene consumata soltanto quando il candidate è effettivamente incluso in una nuova sessione adattiva della stessa tipologia. Non crea posti aggiuntivi, non modifica le quote e non scavalca il numero di posti assegnato alla categoria/strato. Priorità non compatibili con la tipologia della sessione restano pendenti.

Quando una priorità compete con altri candidate nello stesso strato, ha precedenza nell'ordinamento; se i posti disponibili non bastano, le priorità non estratte restano pendenti per la successiva sessione ammissibile.

Dopo i criteri deterministici, il tie-break seeded garantisce varietà riproducibile. Se mancano `nextReviewAt`, indice o affidabilità per un candidate già verificato, il dato mancante non viene inventato: il candidate scende dietro quelli con metrica disponibile e viene segnalato in diagnostica.

### 6.6 Riempimento dei posti residui

Se una categoria/strato non può soddisfare il conteggio per carenza di candidate unici, i posti residui vengono riassegnati iterativamente:

1. prima ad altri strati della stessa categoria secondo quote interne originarie e capacità residua;
2. poi alle altre categorie disponibili secondo quote finali e capacità residua;
3. a parità, usare gli stessi criteri di spareggio già definiti.

Il riempimento non può violare l'unicità, il filtro di tipologia o la disponibilità del catalogo. Se il pool totale è esaurito, ridurre `effectiveCount` e restituire `INSUFFICIENT_CANDIDATES`.

## 7. Modalità manuale

- L'input è una lista ordinata di `candidateId` scelti dall'utente.
- Il motore valida che ogni candidate esista, sia attivo e appartenga alla tipologia richiesta.
- Per default, duplicati sono rifiutati con `DUPLICATE_MANUAL_CANDIDATE`.
- Se `allowManualDuplicates === true`, i duplicati sono ammessi soltanto nell'array della sessione manuale corrente; non alterano catalogo, quote o configurazione adattiva.
- Un candidate invalido non viene sostituito silenziosamente: il motore restituisce un errore di validazione con gli ID coinvolti.
- L'ordine manuale viene preservato.
- Le statistiche adattive non influenzano né riordinano la selezione manuale.

La selezione manuale non modifica la configurazione adattiva del profilo.

## 8. Priorità e registrazione delle consultazioni

Quando un sotto-quesito viene consultato (`?`), l'evento di conoscenza viene registrato come `consulted` con punteggio +1. La priorità temporanea risultante è associata a:

- `profileId`;
- `questionType`;
- `candidateId` e/o `questionSemanticId` interessato;
- `sourceSessionId`;
- timestamp e stato `pending/consumed`.

La specifica consolidata parla di priorità per la successiva sessione adattiva della stessa tipologia. Per non trasformare un singolo sotto-quesito consultato in una selezione duplicata, il motore dà priorità al candidate che lo contiene; il sotto-quesito consultato resta identificato nella priorità e viene incluso nello snapshot. Se il candidate non è più attivo o compatibile, la priorità viene marcata non applicabile con motivazione, senza trasferire conoscenza a una nuova identità.

La priorità non viene consumata da sessioni casuali o manuali, né da sessioni adattive di altra tipologia.

## 9. Errori e warning standard

| Codice | Significato | Comportamento |
|---|---|---|
| `INVALID_SELECTION_CONFIG` | Quote, numero o modalità non validi | Errore bloccante |
| `CATALOG_VERSION_MISMATCH` | Candidate non coerenti con catalogVersion | Errore bloccante |
| `INVALID_CANDIDATE` | Candidate non attivo o definizione incompleta | Escludere e segnalare; errore bloccante se manuale |
| `DUPLICATE_CANDIDATE` | Identità candidate duplicate nel catalogo/pool | Errore bloccante |
| `DUPLICATE_MANUAL_CANDIDATE` | Duplicato manuale non consentito | Errore bloccante |
| `INSUFFICIENT_CANDIDATES` | Pool inferiore al richiesto | Warning con effectiveCount |
| `MISSING_KNOWLEDGE_PROJECTION` | Proiezione conoscenza assente/incompleta | In adattiva, classificare come mai verificato solo se assenza confermata; altrimenti errore coerenza |
| `UNRESOLVED_PRIORITY` | Priorità consultazione non più compatibile | Warning; non trasferire a identità diversa |

## 10. Snapshot di riproducibilità

Ogni sessione deve salvare almeno:

- `selectionAlgorithmVersion`;
- `adaptiveQuotaAlgorithmVersion`;
- `catalogVersion`;
- `prngAlgorithmId: "xoshiro128**"` e `prngAlgorithmVersion: "1.0"`;
- `seed` canonico e `seedEncoding: "hex-128be"`;
- `seedSource` e `seedSecurity`;
- `canonicalOrderingVersion: "utf16-code-unit-v1"`;
- `candidatePoolFingerprint` e `canonicalCandidateOrder` completo;
- `prngStateAfterSelection`, `prngDrawCount` e `prngRejectionCount`;
- modalità e tipologia;
- quote configurate originali e quote normalizzate;
- affidabilità e deficit categoria usati;
- budget globale e tetti;
- conteggi categoria e strato;
- candidate selezionati e ordine;
- priorità applicate e priorità rimaste pendenti;
- versione/data del knowledge snapshot;
- warning e motivi di riduzione del numero domande.

Il fingerprint è calcolato come `sha256:` + SHA-256 di `JSON.stringify(canonicalCandidateOrder)` codificato UTF-8. Se `TextEncoder` o `crypto.subtle.digest` non sono disponibili, la creazione della sessione fallisce con `SELECTION_FINGERPRINT_UNAVAILABLE` prima di ogni scrittura.

La sessione sospesa riprende esattamente l'ordine già salvato; non richiama il motore di selezione.

## 11. Invarianti di accettazione

1. Casuale pura non legge alcun campo di conoscenza o priorità.
2. Adattiva usa solo conoscenza della tipologia corrispondente.
3. Manuale preserva l'ordine scelto e non modifica quote adattive.
4. Nessun candidate ripetuto in adattiva/casuale.
5. Duplicati manuali solo con opt-in esplicito.
6. Conteggi categoria sommano a `effectiveCount`.
7. Conteggi strato di ogni categoria sommano al conteggio assegnato alla categoria.
8. Quote adattive categoria sommano al 100% prima della conversione in conteggi.
9. Budget supplementare non supera 10 punti; tetto categoria non supera il 20% della quota base normalizzata.
10. Residuo non allocabile diventa quota neutra e non supera il budget prelevato.
11. Categorie indisponibili non ricevono quote.
12. Strati vuoti o saturi redistribuiscono i posti senza duplicati.
13. Consultazione prioritaria soltanto la successiva sessione adattiva della stessa tipologia; nessun posto extra.
14. Stesso input, seed e versioni producono stesso ordine.
15. Modifiche statistiche dopo la creazione non alterano la selezione congelata.
16. Se gli elementi sono insufficienti, il motore restituisce il numero effettivo e il SessionManager chiede conferma.
17. La selezione non registra esposizioni e non modifica knowledge state.
18. Nessun candidate deriva da elementi non certificati nel catalogo parziale.

## 12. Test da implementare

### 12.1 Test unitari

- casuale deterministico e indipendente dalle statistiche;
- casuale non applica priorità consultazione;
- adattiva per una sola tipologia;
- adattiva mista con quote default 25%;
- categoria indisponibile e rinormalizzazione;
- tutti i deficit nulli;
- un solo deficit positivo e quota neutra;
- redistribuzione con saturazione di più tetti;
- strato vuoto e redistribuzione interna;
- candidate composti con sotto-quesiti a classificazioni diverse;
- priorità consultazione compatibile/incompatibile;
- priorità eccedenti i posti disponibili;
- riempimento da pool esaurito;
- spareggi deterministici;
- manuale ordinato, duplicati vietati/consentiti;
- catalogo versione errata e candidate invalidi;
- seed identico e seed differente;
- selezione non scrive eventi né knowledge state.

### 12.2 Test di proprietà

Per configurazioni generate casualmente e seed ripetuti:

- quote finite, non negative e somma 100% entro tolleranza decimale definita;
- supplementi entro tetti individuali;
- somma supplementi + quota neutra uguale al budget effettivamente prelevato;
- conteggi interi non negativi e somma uguale a effectiveCount;
- nessun ID duplicato fuori dalla modalità manuale con opt-in;
- nessun ID fuori dal pool valido;
- determinismo completo a parità di input;
- nessuna dipendenza dalle statistiche in modalità random/manual.

### 12.3 Test d'integrazione

- snapshot di selezione scritto atomicamente con sessione e sessionItems;
- fallimento persistenza non lascia sessione parziale;
- sessione sospesa riprende ordine e snapshot senza riselezione;
- consultazione genera evento e priorità nella stessa transazione prevista dal repository;
- priorità consumata solo dopo commit della nuova sessione;
- conflitto tra schede non duplica sessioni o consumo priorità.

## 13. Dipendenze e limiti ancora aperti

1. **Copertura catalogo:** il perimetro A di 52 tasti è verificato e approvato. La copertura completa dei 105 tasti resta un'estensione futura; i 53 elementi esclusi non devono essere simulati o inferiti.
2. **Candidate:** la materializzazione esplicita è stata completata nel manifest v1.1 (225 candidate univoci). L'implementazione runtime deve caricare/risolvere esclusivamente questi candidate e verificare nuovamente template, sotto-quesiti e identità prima della selezione.
3. **Calendario:** l'ordinamento per `nextReviewAt` può essere applicato soltanto quando la policy calendario e i relativi dati sono disponibili e approvati; la policy 1/3/7/14/30/60 giorni resta proposta, non definitiva.
4. **Aggregazione del candidate:** la regola prudenziale “strato peggiore dei sotto-quesiti” resta una scelta tecnica versionata; va coperta da test e non altera gli stati individuali.
5. **Priorità consultazione:** viene applicata al candidate che contiene il sotto-quesito consultato. Se un candidate contiene altri sotto-quesiti, tutti vengono presentati secondo il template; non si crea una domanda parziale implicita.
6. **Isolamento:** il selettore non deve usare rete, telemetria, CDN o dipendenze esterne. Il seed è generato localmente tramite API native e tutte le versioni/pool sono contenuti nell'applicazione locale.
5. **PRNG:** algoritmo, versione, seed encoding, bounded integer, Fisher–Yates e vettori sono congelati in `Specifica_PRNG_Interrogazione_v1.0.md`. L'implementazione deve rispettare quella specifica senza varianti implicite.
6. **Calendario di consolidamento:** il motore usa `nextReviewAt` soltanto se prodotto da `InterrogationKnowledge`; la regola di aggiornamento del calendario resta un prerequisito separato.
7. **Quote per categoria in sessione mirata:** una singola tipologia riceve il 100% dei posti; non si applica il budget adattivo inter-categoria, poiché non esiste riparto tra categorie.

Questi limiti non impediscono la progettazione del motore, ma impediscono di dichiarare completo il catalogo di produzione o di attivare domande non validate.

## 14. Esito

Il comportamento del selettore è ora definito per le tre modalità, con riparto adattivo a due livelli, priorità temporanea di consultazione, determinismo, gestione delle indisponibilità e criteri di test. La specifica resta indipendente dalla UI e dalla persistenza.

**Nessun sorgente applicativo è stato modificato.** Il manifest candidate v1.1 e i vettori PRNG sono stati verificati; restano da implementare i componenti runtime, da confermare la policy calendario per l'adattivo e da collaudare il comportamento nei browser. La copertura completa del layout non è richiesta per la release A.


## 15. Revisione v1.1 — PRNG congelato

La v1.1 recepisce `xoshiro128**` v1.0, il seed `hex-128be`, il bounded integer con rejection sampling, l'ordinamento canonico `utf16-code-unit-v1`, Fisher–Yates discendente e i campi aggiuntivi dello snapshot. Le regole di quote, classificazione, priorità e conteggio non sono state modificate. Restano aperti i limiti di catalogo e calendario già elencati.


## 16. Revisione v1.2 — catalogo parziale validato e isolamento offline

La v1.2 recepisce l'approvazione della strategia A. Il pool di prima release è limitato a 225 candidate principali: 10 HOME_ROW, 52 TASTO, 111 CARATTERE e 52 DITO. I candidate referenziano 445 definizioni attive attraverso cinque template. Il manifest è stato validato contro `KEY_MAP`, `FINGER_NAMES` e i dati anatomici della baseline: zero ID duplicati, zero riferimenti mancanti e zero dipendenze esterne.

Il runtime deve utilizzare il manifest come inventario esplicito e immutabile della versione catalogo; può risolvere e validare i riferimenti, ma non può inventare nuovi candidate o riempire le lacune del layout.

La modalità casuale pura e la modalità manuale possono essere implementate sul perimetro A. La modalità adattiva completa resta subordinata alla conferma della policy calendario. Nessuna modalità può effettuare comunicazioni di rete o utilizzare dipendenze esterne.
