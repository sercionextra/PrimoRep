# Sicurezza e riservatezza offline — TenFingersTypingTrainer v6.24

## 1. Obiettivo

La v6.24 introduce un livello di isolamento tecnico per l'applicazione stand-alone. Il codice applicativo non deve effettuare richieste remote, inviare dati, raccogliere telemetria o dipendere da servizi online.

## 2. Controlli implementati

### Content Security Policy

Sia `index.html` sia `help.html` dichiarano una CSP con:

- `default-src 'none'`;
- script e CSS ammessi dalla stessa origine o dallo schema locale `file:` per supportare l'apertura diretta da disco;
- `connect-src 'none'`;
- immagini limitate a origine locale, schema `file:`, `data:` e `blob:`;
- font locali o da schema `file:`;
- media, frame, worker, object e manifest negati;
- `script-src-attr 'none'` e `style-src-attr 'none'`;
- nessuna deroga `unsafe-inline` o `unsafe-eval`;
- `base-uri 'none'` e `form-action 'none'`.

Gli attributi di stile HTML sono stati migrati in regole CSS locali associate a ID; anche i frammenti HTML/SVG generati da JavaScript sono privi di attributi `style`. Il CSS e il JavaScript della guida sono stati estratti in file locali. I dati dei profili e i titoli degli esercizi vengono renderizzati come testo, non interpretati come markup.

### Guard runtime

`js/security/network-isolation-guard.js` viene caricato prima dei componenti applicativi e blocca:

- fetch e XMLHttpRequest;
- WebSocket, EventSource e WebTransport;
- Worker e SharedWorker;
- WebRTC;
- sendBeacon e registrazione Service Worker;
- BroadcastChannel;
- accesso a microfono, videocamera, geolocalizzazione e dispositivi non necessari;
- lettura/scrittura clipboard via API, credenziali e condivisione di sistema;
- aperture di finestre diverse da `help.html` locale e click su anchor esterni.

Le invocazioni bloccate e gli eventi `securitypolicyviolation` sono disponibili in diagnostica locale; non vengono trasmessi né includono il testo digitato o i dati dei profili.

### Sintesi vocale

La selezione accetta soltanto voci italiane con `localService === true`. Voci remote o prive di una dichiarazione locale esplicita vengono escluse. Se non è disponibile una voce italiana locale, `speakCurrentToken()` non usa la voce predefinita del browser.

## 3. Test automatici

Comandi da eseguire dalla directory del progetto:

```bash
node tests/security-static-check.js
node tests/test-network-isolation-guard.js
node tests/test-offline-voice-selection.js
```

Le verifiche statiche controllano CSP, risorse locali, URL remoti, attributi inline, API di rete e selezione delle voci. I test runtime verificano che le primitive protette vengano bloccate e registrate.

Tutte le suite Node della baseline v6.23 devono rimanere superate. La checklist browser v6.24 richiede inoltre verifica manuale di DevTools Network, assenza di violazioni CSP durante l'uso normale e funzionamento con connettività di sistema disabilitata.

## 4. Limiti e garanzie non dichiarate

- Una CSP inserita tramite meta tag non equivale a un header HTTP e non può applicare tutte le direttive disponibili in un header. In particolare `frame-ancestors` non è applicabile tramite meta CSP.
- CSP e guard proteggono il contesto dell'applicazione, non il browser, le estensioni, il sistema operativo o altri processi.
- La completa assenza di traffico va verificata nel browser e, per un isolamento di sistema, mediante firewall o regole di rete del sistema operativo.
- `localService === true` è la dichiarazione del browser che la voce è locale; l'applicazione non può certificare il comportamento interno del sistema operativo o l'eventuale download preventivo dei pacchetti vocali da parte dell'utente.
- Lo schema `file:` consente risorse locali anche nei browser che trattano gli URL `file://` come origini opache; i riferimenti effettivi restano controllati dal test statico e devono essere relativi alla cartella applicativa. Il test browser non è stato eseguito nell'ambiente di build: rimane un gate manuale obbligatorio prima della distribuzione.

## 5. Dipendenze e distribuzione

Nessuna libreria, pacchetto, framework, CDN o servizio esterno è stato aggiunto. L'applicazione resta una cartella statica locale avviabile aprendo `index.html`; non viene introdotto un server applicativo.
