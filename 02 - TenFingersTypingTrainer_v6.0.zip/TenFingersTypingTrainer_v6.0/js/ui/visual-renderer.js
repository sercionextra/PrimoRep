/* TenFingersTypingTrainer v6.0 | visual-renderer.js | Refactoring compatibile: comportamento sorgente preservato. */
class VisualRenderer {
  constructor() {
    this.currentTargetKey = null;
    this.currentModifierKey = null;
    this.activePhysicalKeys = new Map();
    this.useCustomKeyDistances = false; // Flag per visualizzazione distanze reali su falangi/nocche
  }

  highlightTarget(char) {
    this.setTargetChar(char);
  }

  // Metodo aggiornato: Risoluzione coordinate e rendering keycap con casing reale
  setTargetChar(char) {
    this.currentTargetChar = char;
    document
      .querySelectorAll(".key.active-target")
      .forEach((el) => el.classList.remove("active-target"));
    document
      .querySelectorAll(".hand-finger.finger-active")
      .forEach((el) => el.classList.remove("finger-active"));
    for (let f = 1; f <= 10; f++) {
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }

    if (!char) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = "Tastiera e Mani a riposo";
      return;
    }

    const chord = resolveTargetChord(char);
    if (!chord) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = `Carattere: "${char}"`;
      return;
    }

    chord.keyIds.forEach((id) => {
      const keyEl = document.getElementById(id);
      if (keyEl) keyEl.classList.add("active-target");
    });

    chord.fingers.forEach((fInfo) => {
      const fingerEl = document.getElementById(`hand_finger_${fInfo.finger}`);
      if (fingerEl) {
        // L'evidenziazione del polpastrello pulsa SOLO se "Posizione Tasti" è disattivato.
        if (!this.useCustomKeyDistances) {
          fingerEl.classList.add("finger-active");
        } else {
          fingerEl.classList.remove("finger-active");
        }
      }

      const grp = document.getElementById(
        `hand_finger_keycap_group_${fInfo.finger}`,
      );
      if (grp) grp.style.display = "inline";

      const tip = document.getElementById(`hand_finger_tip_${fInfo.finger}`);
      if (tip) tip.textContent = fInfo.label; // Casing reale

      const rect = document.getElementById(
        `hand_finger_keycap_rect_${fInfo.finger}`,
      );
      if (rect) {
        const textLen = (fInfo.label || "").length;
        const origCx = parseFloat(
          rect.getAttribute("data-cx") ||
            parseFloat(rect.getAttribute("x")) + 29,
        );
        const origCy = parseFloat(
          rect.getAttribute("data-cy") ||
            parseFloat(rect.getAttribute("y")) + 26,
        );

        let targetCx = origCx;
        let targetCy = origCy;

        // Se "Posizione Tasti" è attivo, posiziona sui landmark calibrati
        if (this.useCustomKeyDistances) {
          const landmark = getAnatomicalLandmark(fInfo.finger, fInfo.label);
          if (landmark) {
            targetCx = landmark.cx;
            targetCy = landmark.cy;
          }
        }

        let w = 87;
        if (textLen > 2) {
          w = Math.max(108, Math.round(textLen * 22.5 + 39));
        }

        rect.setAttribute("width", w);
        rect.setAttribute("x", targetCx - w / 2);
        rect.setAttribute("height", 78);
        rect.setAttribute("y", targetCy - 39);

        if (tip) {
          tip.setAttribute("x", targetCx);
          tip.setAttribute("y", targetCy + 1);
        }
      }
    });

    const handText = document.getElementById("handIndicatorText");
    if (handText) {
      if (chord.fingers.length > 1) {
        const desc = chord.fingers
          .map((f) => `${FINGER_NAMES[f.finger]} (${f.label})`)
          .join(" + ");
        handText.innerText = `Accordo: ${desc}`;
      } else {
        handText.innerText = `${FINGER_NAMES[chord.info.finger]} → Tasto "${chord.info.name}"`;
      }
    }
  }

  updateCapsLockLed(isActive) {
    const capsEl = document.getElementById("key_caps");
    if (capsEl) {
      if (isActive) {
        capsEl.classList.add("caps-active");
      } else {
        capsEl.classList.remove("caps-active");
      }
    }
  }

  getKeyIdForEvent(keyOrChar, eventCode = null, eventLocation = null) {
    if (keyOrChar === "Tab") return "key_tab";
    if (keyOrChar === "CapsLock") return "key_caps";
    if (keyOrChar === "Backspace") return "key_backspace";
    if (keyOrChar === "Enter") return "key_enter";
    if (keyOrChar === "ContextMenu") return "key_menu";
    if (keyOrChar === " " || eventCode === "Space") return "key_space";
    if (keyOrChar === "Shift") {
      return eventCode === "ShiftRight" || eventLocation === 2
        ? "key_shift_r"
        : "key_shift_l";
    }
    if (keyOrChar === "Control") {
      return eventCode === "ControlRight" || eventLocation === 2
        ? "key_ctrl_r"
        : "key_ctrl_l";
    }
    if (keyOrChar === "Alt") {
      return eventCode === "AltRight" || eventLocation === 2
        ? "key_altgr"
        : "key_alt_l";
    }
    if (keyOrChar === "AltGraph") return "key_altgr";
    if (keyOrChar === "Meta" || keyOrChar === "OS") {
      return eventCode === "MetaRight" || eventLocation === 2
        ? "key_win_r"
        : "key_win_l";
    }

    if (KEY_MAP[keyOrChar]) {
      return KEY_MAP[keyOrChar].id;
    }
    const lower = keyOrChar.toLowerCase();
    if (KEY_MAP[lower]) {
      return KEY_MAP[lower].id;
    }
    if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const char = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[char]) return KEY_MAP[char].id;
      }
      if (eventCode.startsWith("Digit")) {
        const digit = eventCode.slice(5);
        if (KEY_MAP[digit]) return KEY_MAP[digit].id;
      }
    }
    return null;
  }

  setKeyPressed(
    keyOrChar,
    eventCode = null,
    eventLocation = null,
    isDown = true,
  ) {
    const keyId = this.getKeyIdForEvent(keyOrChar, eventCode, eventLocation);
    if (!keyId) return;
    const el = document.getElementById(keyId);
    if (el) {
      if (isDown) {
        el.classList.add("key-pressed");
      } else {
        el.classList.remove("key-pressed");
      }
    }
  }

  flashPressedKey(keyOrChar, eventCode = null, eventLocation = null) {
    this.setKeyPressed(keyOrChar, eventCode, eventLocation, true);
    setTimeout(
      () => this.setKeyPressed(keyOrChar, eventCode, eventLocation, false),
      180,
    );
  }

  adjustHandsViewport(width, height) {
    const svg = document.getElementById("handsSvg");
    const lblL = document.getElementById("lblLeftHand");
    const lblR = document.getElementById("lblRightHand");
    if (!svg) return;

    const w = Math.max(300, width);
    const h = Math.max(180, height);

    const refScale = 1408 / 580;
    let vbW = Math.max(1060, Math.min(1408, Math.round(w * refScale)));
    let vbX = Math.round(704 - vbW / 2);

    let vbH = Math.max(460, Math.min(768, Math.round(h * refScale)));
    let vbY = 20;

    svg.setAttribute("viewBox", `${vbX} ${vbY} ${vbW} ${vbH}`);

    const labelY = Math.min(730, Math.max(480, vbY + vbH - 30));
    if (lblL) lblL.setAttribute("y", labelY);
    if (lblR) lblR.setAttribute("y", labelY);

    const errRect = document.getElementById("handsCentralErrorRect");
    const errText = document.getElementById("handsCentralErrorText");
    const succRect = document.getElementById("handsCentralSuccessRect");
    const succText = document.getElementById("handsCentralSuccessText");
    const errCount = document.getElementById("handsErrorCountText");

    if (errCount) {
      errCount.setAttribute("y", vbY + 45);
    }

    const badgeY = Math.min(660, Math.max(400, vbY + vbH - 90));

    if (errRect && errText) {
      errRect.setAttribute("y", badgeY);
      errText.setAttribute("y", badgeY + 31);
    }

    if (succRect && succText) {
      succRect.setAttribute("y", badgeY);
      succText.setAttribute("y", badgeY + 31);
    }
  }

  // Governa la visibilità del layer SVG con la mappa dei 49 pallini guida di posizione tasti
  updatePositionDots(show) {
    document.querySelectorAll(".hands-position-dots").forEach((grp) => {
      grp.style.display = show ? "inline" : "none";
    });
  }

  // =======================================================
  // NUOVO METODO (v.3.7): Innesca lo sfarfallio ad alta velocità (90 ms)
  // sul keycap SVG del dito principale (zero alterazioni geometriche)
  // =======================================================
  triggerTargetFlicker(finger) {
    if (!finger) return;
    const grp = document.getElementById(`hand_finger_keycap_group_${finger}`);
    if (grp) {
      grp.classList.remove("target-flicker-svg");
      void grp.getBoundingClientRect(); // Flush sincrono di reflow per riavviare l'animazione
      grp.classList.add("target-flicker-svg");
    }
  }

  // Metodo aggiornato: Casing reale per i tasti fisici premuti
  getFingersForPhysicalKey(keyOrChar, eventCode = null, eventLocation = null) {
    let fingers = [];
    if (keyOrChar === " " || eventCode === "Space") {
      fingers = [{ finger: 5, label: "SPAZIO" }];
    } else if (keyOrChar === "Enter" || eventCode === "Enter") {
      fingers = [{ finger: 10, label: "INVIO" }];
    } else if (keyOrChar === "Backspace" || eventCode === "Backspace") {
      fingers = [{ finger: 10, label: "⌫" }];
    } else if (keyOrChar === "Tab" || eventCode === "Tab") {
      fingers = [{ finger: 1, label: "TAB" }];
    } else if (keyOrChar === "Shift") {
      const f = eventCode === "ShiftRight" || eventLocation === 2 ? 10 : 1;
      fingers = [{ finger: f, label: "SHIFT" }];
    } else if (keyOrChar === "Control") {
      const f = eventCode === "ControlRight" || eventLocation === 2 ? 10 : 1;
      fingers = [{ finger: f, label: "CTRL" }];
    } else if (keyOrChar === "Alt") {
      const f = eventCode === "AltRight" || eventLocation === 2 ? 6 : 5;
      fingers = [{ finger: f, label: f === 6 ? "ALT GR" : "ALT" }];
    } else if (keyOrChar === "AltGraph") {
      fingers = [{ finger: 6, label: "ALT GR" }];
    } else if (keyOrChar === "CapsLock") {
      fingers = [{ finger: 1, label: "CAPS" }];
    } else if (keyOrChar && keyOrChar.length === 1) {
      const lower = keyOrChar.toLowerCase();
      // Risoluzione con casing reale corrispondente all'accordo premuto (v.3.5)
      if (KEY_MAP[lower]) {
        fingers = [{ finger: KEY_MAP[lower].finger, label: keyOrChar }];
      } else if (KEY_MAP[keyOrChar]) {
        fingers = [{ finger: KEY_MAP[keyOrChar].finger, label: keyOrChar }];
      }
    } else if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const ch = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[ch]) {
          fingers = [{ finger: KEY_MAP[ch].finger, label: keyOrChar || ch }];
        }
      } else if (eventCode.startsWith("Digit")) {
        const d = eventCode.slice(5);
        if (KEY_MAP[d]) {
          fingers = [{ finger: KEY_MAP[d].finger, label: keyOrChar || d }];
        }
      }
    }
    return fingers;
  }

  setPhysicalKeyDown(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (!keyId) return;

    const fingers = this.getFingersForPhysicalKey(
      keyOrChar,
      eventCode,
      eventLocation,
    );
    if (fingers.length === 0) return;

    this.activePhysicalKeys.set(keyId, fingers);
    this.renderActivePhysicalChord();
  }

  setPhysicalKeyUp(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (keyId) {
      this.activePhysicalKeys.delete(keyId);
    }
    if (keyOrChar && this.activePhysicalKeys.has(keyOrChar)) {
      this.activePhysicalKeys.delete(keyOrChar);
    }

    if (this.activePhysicalKeys.size > 0) {
      this.renderActivePhysicalChord();
    } else {
      this.clearAllPhysicalFingers();
    }
  }

  renderActivePhysicalChord() {
    const activeFingerMap = new Map();

    let hasLeftCtrl = false;
    let hasLeftShift = false;
    let hasLeftAlt = false;

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        if (
          keyId === "ControlLeft" ||
          keyId.startsWith("Control_ControlLeft") ||
          (item.finger === 1 && item.label === "CTRL")
        )
          hasLeftCtrl = true;
        if (
          keyId === "ShiftLeft" ||
          keyId.startsWith("Shift_ShiftLeft") ||
          (item.finger === 1 && item.label === "SHIFT")
        )
          hasLeftShift = true;
        if (
          keyId === "AltLeft" ||
          keyId.startsWith("Alt_AltLeft") ||
          (item.finger === 5 && item.label === "ALT")
        )
          hasLeftAlt = true;
      }
    }

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        let f = item.finger;
        let lbl = item.label;

        if (hasLeftCtrl && hasLeftShift) {
          if (
            keyId === "ShiftLeft" ||
            keyId.startsWith("Shift_ShiftLeft") ||
            (item.finger === 1 && lbl === "SHIFT")
          ) {
            f = 2;
          } else if (
            keyId === "ControlLeft" ||
            keyId.startsWith("Control_ControlLeft") ||
            (item.finger === 1 && lbl === "CTRL")
          ) {
            f = 1;
          }
        }
        if (
          hasLeftAlt &&
          (keyId === "AltLeft" ||
            keyId.startsWith("Alt_AltLeft") ||
            lbl === "ALT")
        ) {
          f = 5;
        }
        activeFingerMap.set(f, lbl);
      }
    }

    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      const rect = document.getElementById(`hand_finger_keycap_rect_${f}`);

      if (activeFingerMap.has(f)) {
        const label = activeFingerMap.get(f);

        // Evidenziazione fisica del polpastrello condizionata al toggle
        if (fingerEl) {
          if (!this.useCustomKeyDistances) {
            fingerEl.classList.add("finger-active");
          } else {
            fingerEl.classList.remove("finger-active");
          }
        }

        if (grp) grp.style.display = "inline";
        if (tip) tip.textContent = label;

        if (rect) {
          const textLen = (label || "").length;
          const origCx = parseFloat(rect.getAttribute("data-cx") || "215");
          const origCy = parseFloat(rect.getAttribute("data-cy") || "340");
          let targetCx = origCx;
          let targetCy = origCy;

          if (this.useCustomKeyDistances) {
            const landmark = getAnatomicalLandmark(f, label);
            if (landmark) {
              targetCx = landmark.cx;
              targetCy = landmark.cy;
            }
          }

          let w = 87;
          if (textLen > 2) {
            w = Math.max(108, Math.round(textLen * 22.5 + 39));
          }

          rect.setAttribute("width", w);
          rect.setAttribute("x", targetCx - w / 2);
          rect.setAttribute("height", 78);
          rect.setAttribute("y", targetCy - 39);

          if (tip) {
            tip.setAttribute("x", targetCx);
            tip.setAttribute("y", targetCy + 1);
          }
        }
      } else {
        if (fingerEl) fingerEl.classList.remove("finger-active");
        if (grp) grp.style.display = "none";
        if (tip) tip.textContent = "";
      }
    }

    // FEEDBACK DINAMICO ETICHETTA ANATOMICA IN MODALITÀ 4 (Opzione A)
    const appInstance = window.app || window.__app;
    if (appInstance?.typingEng?.mode === 4) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) {
        if (activeFingerMap.size > 0) {
          const desc = Array.from(activeFingerMap.entries())
            .map(([f, lbl]) => `${FINGER_NAMES[f]} → Tasto "${lbl}"`)
            .join(" + ");
          handText.innerText = desc;
        } else {
          handText.innerText = "Digitazione libera (nessuna guida)";
        }
      }
    }
  }

  clearAllPhysicalFingers() {
    this.activePhysicalKeys.clear();
    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      if (fingerEl) fingerEl.classList.remove("finger-active");
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }

    const appInstance = window.app || window.__app;

    // Ripristino etichetta anatomica neutra al rilascio di tutti i tasti in Modalità 4
    if (appInstance?.typingEng?.mode === 4) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) {
        handText.innerText = "Digitazione libera (nessuna guida)";
      }
      return;
    }

    if (
      this.currentTargetChar &&
      appInstance &&
      appInstance.typingEng &&
      appInstance.typingEng.mode !== 4 &&
      !appInstance.typingEng.isCompleted
    ) {
      this.setTargetChar(this.currentTargetChar);
    }
  }

  // Metodi di compatibilità retroattiva
  showPressedFingers(keyOrChar, eventCode = null, eventLocation = null) {
    this.setPhysicalKeyDown(keyOrChar, eventCode, eventLocation);
  }

  clearPressedFingers() {
    this.clearAllPhysicalFingers();
  }
}

// =======================================================
// DICTATION ENGINE (Text-to-Speech Adattivo v.3.8 / v.3.9)
// =======================================================
