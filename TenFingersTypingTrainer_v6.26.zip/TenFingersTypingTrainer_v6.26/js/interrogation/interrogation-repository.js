/* TenFingersTypingTrainer v6.25 | interrogation-repository.js | Repository IndexedDB conforme a Schema_IndexedDB_Interrogazione_v1.3.md (14 store, indici, idempotenza, recovery). */
(function (global) {
  "use strict";

  const DB_NAME = "TenFingersInterrogationDB";
  const DB_VERSION = 1;

  const STORE_NAMES = Object.freeze([
    "catalogVersions",
    "catalogElements",
    "catalogRelations",
    "questionDefinitions",
    "questionTemplates",
    "profileSettings",
    "sessions",
    "sessionItems",
    "exposureEvents",
    "eventCorrections",
    "consultationPriorities",
    "knowledgeStates",
    "catalogAudit",
    "operationReceipts",
  ]);

  function upgradeSchema(db) {
    if (!db.objectStoreNames.contains("catalogVersions")) {
      const s = db.createObjectStore("catalogVersions", { keyPath: "catalogVersion" });
      s.createIndex("byCreatedAt", "createdAt", { unique: false });
    }
    if (!db.objectStoreNames.contains("catalogElements")) {
      const s = db.createObjectStore("catalogElements", { keyPath: ["semanticId", "contentVersion"] });
      s.createIndex("byTypeLayoutStatus", ["type", "layoutId", "status"], { unique: false });
      s.createIndex("byCategoryStatus", ["categoryId", "status"], { unique: false });
      s.createIndex("bySemanticId", "semanticId", { unique: false });
      s.createIndex("byRecordId", "recordId", { unique: true });
    }
    if (!db.objectStoreNames.contains("catalogRelations")) {
      const s = db.createObjectStore("catalogRelations", { keyPath: "relationId" });
      s.createIndex("byCatalogFrom", ["catalogVersion", "fromSemanticId"], { unique: false });
      s.createIndex("byCatalogTo", ["catalogVersion", "toSemanticId"], { unique: false });
      s.createIndex("byCatalogType", ["catalogVersion", "relationType"], { unique: false });
    }
    if (!db.objectStoreNames.contains("questionDefinitions")) {
      const s = db.createObjectStore("questionDefinitions", { keyPath: ["questionSemanticId", "contentVersion"] });
      s.createIndex("byQuestionSemanticId", "questionSemanticId", { unique: false });
      s.createIndex("byElementStatus", ["elementSemanticId", "status"], { unique: false });
    }
    if (!db.objectStoreNames.contains("questionTemplates")) {
      const s = db.createObjectStore("questionTemplates", { keyPath: ["templateSemanticId", "contentVersion"] });
      s.createIndex("byTemplateSemanticId", "templateSemanticId", { unique: false });
      s.createIndex("byCatalogTypeLayoutStatus", ["catalogVersion", "questionType", "layoutId", "status"], { unique: false });
    }
    if (!db.objectStoreNames.contains("profileSettings")) {
      const s = db.createObjectStore("profileSettings", { keyPath: "profileId" });
      s.createIndex("byUpdatedAt", "updatedAt", { unique: false });
    }
    if (!db.objectStoreNames.contains("sessions")) {
      const s = db.createObjectStore("sessions", { keyPath: ["profileId", "sessionId"] });
      s.createIndex("byProfileStatus", ["profileId", "status"], { unique: false });
      s.createIndex("byProfileCreatedAt", ["profileId", "createdAt"], { unique: false });
      s.createIndex("oneSuspendedPerProfile", "suspendedProfileId", { unique: true });
    }
    if (!db.objectStoreNames.contains("sessionItems")) {
      const s = db.createObjectStore("sessionItems", { keyPath: ["profileId", "sessionId", "itemId"] });
      s.createIndex("bySessionOrder", ["profileId", "sessionId", "order"], { unique: true });
      s.createIndex("byMainElement", ["profileId", "mainElementSemanticId"], { unique: false });
    }
    if (!db.objectStoreNames.contains("exposureEvents")) {
      const s = db.createObjectStore("exposureEvents", { keyPath: ["profileId", "eventId"] });
      s.createIndex("byQuestionTime", ["profileId", "questionSemanticId", "occurredAt"], { unique: false });
      s.createIndex("bySession", ["profileId", "sessionId"], { unique: false });
      s.createIndex("byOperationId", "operationId", { unique: true });
      s.createIndex("byEventSequence", ["profileId", "sessionId", "eventSequence"], { unique: true });
    }
    if (!db.objectStoreNames.contains("eventCorrections")) {
      const s = db.createObjectStore("eventCorrections", { keyPath: ["profileId", "correctionId"] });
      s.createIndex("byEvent", ["profileId", "eventId"], { unique: false });
      s.createIndex("byOperationId", "operationId", { unique: true });
      s.createIndex("byCreatedAt", ["profileId", "createdAt"], { unique: false });
    }
    if (!db.objectStoreNames.contains("consultationPriorities")) {
      const s = db.createObjectStore("consultationPriorities", { keyPath: ["profileId", "priorityId"] });
      s.createIndex("byProfileStatusType", ["profileId", "status", "questionType"], { unique: false });
      s.createIndex("byProfileQuestion", ["profileId", "questionSemanticId"], { unique: false });
      s.createIndex("bySourceEvent", ["profileId", "sourceEventId"], { unique: false });
      s.createIndex("byConsumedSession", ["profileId", "consumedBySessionId"], { unique: false });
      s.createIndex("bySourceEventType", ["profileId", "sourceEventId", "questionType"], { unique: true });
    }
    if (!db.objectStoreNames.contains("knowledgeStates")) {
      const s = db.createObjectStore("knowledgeStates", { keyPath: ["profileId", "questionSemanticId"] });
      s.createIndex("byClassification", ["profileId", "classification"], { unique: false });
      s.createIndex("byNextReview", ["profileId", "nextReviewAt"], { unique: false });
    }
    if (!db.objectStoreNames.contains("catalogAudit")) {
      const s = db.createObjectStore("catalogAudit", { keyPath: "auditId" });
      s.createIndex("byEntityTime", ["entitySemanticId", "createdAt"], { unique: false });
      s.createIndex("byOperationId", "operationId", { unique: true });
      s.createIndex("byCatalogVersion", "catalogVersion", { unique: false });
    }
    if (!db.objectStoreNames.contains("operationReceipts")) {
      const s = db.createObjectStore("operationReceipts", { keyPath: ["scope", "operationId"] });
      s.createIndex("byCreatedAt", "createdAt", { unique: false });
    }
  }

  function createMemoryBackend() {
    const stores = {};
    STORE_NAMES.forEach((name) => {
      stores[name] = new Map();
    });

    const keyFromRecord = (storeName, record) => {
      switch (storeName) {
        case "catalogVersions": return String(record.catalogVersion);
        case "catalogElements": return `${record.semanticId}::${record.contentVersion}`;
        case "catalogRelations": return String(record.relationId);
        case "questionDefinitions": return `${record.questionSemanticId}::${record.contentVersion}`;
        case "questionTemplates": return `${record.templateSemanticId}::${record.contentVersion}`;
        case "profileSettings": return String(record.profileId);
        case "sessions": return `${record.profileId}::${record.sessionId}`;
        case "sessionItems": return `${record.profileId}::${record.sessionId}::${record.itemId}`;
        case "exposureEvents": return `${record.profileId}::${record.eventId}`;
        case "eventCorrections": return `${record.profileId}::${record.correctionId}`;
        case "consultationPriorities": return `${record.profileId}::${record.priorityId}`;
        case "knowledgeStates": return `${record.profileId}::${record.questionSemanticId}`;
        case "catalogAudit": return String(record.auditId);
        case "operationReceipts": return `${record.scope}::${record.operationId}`;
        default: return JSON.stringify(record);
      }
    };

    return {
      isMemory: true,
      async getAll(storeName) {
        return Array.from(stores[storeName].values()).map((r) => JSON.parse(JSON.stringify(r)));
      },
      async get(storeName, key) {
        const k = Array.isArray(key) ? key.join("::") : String(key);
        const found = stores[storeName].get(k);
        return found ? JSON.parse(JSON.stringify(found)) : null;
      },
      async put(storeName, record) {
        const copy = JSON.parse(JSON.stringify(record));
        if (storeName === "sessions" && copy.status === "suspended") {
          for (const existing of stores.sessions.values()) {
            if (
              existing.suspendedProfileId &&
              existing.suspendedProfileId === copy.suspendedProfileId &&
              existing.sessionId !== copy.sessionId
            ) {
              const err = new Error("Esiste già una sessione sospesa per questo profilo.");
              err.name = "ConstraintError";
              throw err;
            }
          }
        }
        stores[storeName].set(keyFromRecord(storeName, copy), copy);
        return copy;
      },
      async runTransaction(storeNames, fn) {
        const snapshots = {};
        storeNames.forEach((n) => {
          snapshots[n] = new Map(
            Array.from(stores[n].entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
          );
        });
        try {
          return await fn(this);
        } catch (err) {
          storeNames.forEach((n) => {
            stores[n] = snapshots[n];
          });
          throw err;
        }
      },
    };
  }

  class InterrogationRepository {
    constructor(options) {
      const opts = options || {};
      this.dbName = opts.dbName || DB_NAME;
      this.dbVersion = opts.dbVersion || DB_VERSION;
      this.forceMemory = !!opts.forceMemory || typeof global.indexedDB === "undefined";
      this._db = null;
      this._mem = this.forceMemory ? createMemoryBackend() : null;
    }

    async open() {
      if (this._mem) return this._mem;
      if (this._db) return this._db;

      return new Promise((resolve, reject) => {
        const req = global.indexedDB.open(this.dbName, this.dbVersion);
        req.onupgradeneeded = (event) => {
          upgradeSchema(event.target.result);
        };
        req.onblocked = () => {
          reject(new Error("IndexedDB bloccato da un'altra scheda aperta."));
        };
        req.onsuccess = (event) => {
          const db = event.target.result;
          db.onversionchange = () => {
            db.close();
            this._db = null;
          };
          this._db = db;
          resolve(db);
        };
        req.onerror = () => {
          reject(req.error || new Error("Errore apertura IndexedDB Interrogazione."));
        };
      });
    }

    async _idbReq(req) {
      return new Promise((resolve, reject) => {
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    async getReceipt(scope, operationId) {
      if (this._mem) return this._mem.get("operationReceipts", [scope, operationId]);
      const db = await this.open();
      const tx = db.transaction(["operationReceipts"], "readonly");
      return (await this._idbReq(tx.objectStore("operationReceipts").get([scope, operationId]))) || null;
    }

    async getSession(profileId, sessionId) {
      if (this._mem) return this._mem.get("sessions", [profileId, sessionId]);
      const db = await this.open();
      const tx = db.transaction(["sessions"], "readonly");
      return (await this._idbReq(tx.objectStore("sessions").get([profileId, sessionId]))) || null;
    }

    async getSessionsByProfile(profileId) {
      if (this._mem) {
        const all = await this._mem.getAll("sessions");
        return all.filter((s) => s.profileId === profileId).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      }
      const db = await this.open();
      const tx = db.transaction(["sessions"], "readonly");
      const all = await this._idbReq(tx.objectStore("sessions").getAll());
      return (all || []).filter((s) => s.profileId === profileId).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }

    async getSuspendedSession(profileId) {
      const sessions = await this.getSessionsByProfile(profileId);
      return sessions.find((s) => s.status === "suspended") || null;
    }

    async getSessionItems(profileId, sessionId) {
      if (this._mem) {
        const all = await this._mem.getAll("sessionItems");
        return all
          .filter((it) => it.profileId === profileId && it.sessionId === sessionId)
          .sort((a, b) => (a.order || 0) - (b.order || 0));
      }
      const db = await this.open();
      const tx = db.transaction(["sessionItems"], "readonly");
      const all = await this._idbReq(tx.objectStore("sessionItems").getAll());
      return (all || [])
        .filter((it) => it.profileId === profileId && it.sessionId === sessionId)
        .sort((a, b) => (a.order || 0) - (b.order || 0));
    }

    async getExposureEvents(profileId) {
      if (this._mem) {
        const all = await this._mem.getAll("exposureEvents");
        return all.filter((e) => e.profileId === profileId);
      }
      const db = await this.open();
      const tx = db.transaction(["exposureEvents"], "readonly");
      const all = await this._idbReq(tx.objectStore("exposureEvents").getAll());
      return (all || []).filter((e) => e.profileId === profileId);
    }

    async getEventCorrections(profileId) {
      if (this._mem) {
        const all = await this._mem.getAll("eventCorrections");
        return all.filter((c) => c.profileId === profileId);
      }
      const db = await this.open();
      const tx = db.transaction(["eventCorrections"], "readonly");
      const all = await this._idbReq(tx.objectStore("eventCorrections").getAll());
      return (all || []).filter((c) => c.profileId === profileId);
    }

    async getKnowledgeStates(profileId) {
      if (this._mem) {
        const all = await this._mem.getAll("knowledgeStates");
        return all.filter((k) => k.profileId === profileId);
      }
      const db = await this.open();
      const tx = db.transaction(["knowledgeStates"], "readonly");
      const all = await this._idbReq(tx.objectStore("knowledgeStates").getAll());
      return (all || []).filter((k) => k.profileId === profileId);
    }

    async getConsultationPriorities(profileId, status) {
      const list = this._mem
        ? await this._mem.getAll("consultationPriorities")
        : await (async () => {
            const db = await this.open();
            const tx = db.transaction(["consultationPriorities"], "readonly");
            return (await this._idbReq(tx.objectStore("consultationPriorities").getAll())) || [];
          })();
      return list.filter((p) => p.profileId === profileId && (!status || p.status === status));
    }

    async saveSessionAtomic(sessionRecord, items, operationId, consumedPriorities) {
      const scope = `session:${sessionRecord.profileId}`;
      const existing = await this.getReceipt(scope, operationId);
      if (existing) return existing.result;

      const sanitizedSession = Object.assign({}, sessionRecord);
      if (sanitizedSession.status === "suspended") {
        sanitizedSession.suspendedProfileId = sanitizedSession.profileId;
      } else {
        delete sanitizedSession.suspendedProfileId;
      }

      if (this._mem) {
        return this._mem.runTransaction(
          ["sessions", "sessionItems", "consultationPriorities", "operationReceipts"],
          async (mem) => {
            await mem.put("sessions", sanitizedSession);
            for (let i = 0; i < (items || []).length; i++) {
              await mem.put("sessionItems", items[i]);
            }
            for (let i = 0; i < (consumedPriorities || []).length; i++) {
              await mem.put("consultationPriorities", consumedPriorities[i]);
            }
            const result = { sessionId: sanitizedSession.sessionId, status: sanitizedSession.status };
            await mem.put("operationReceipts", {
              scope,
              operationId,
              createdAt: Date.now(),
              result,
            });
            return result;
          },
        );
      }

      const db = await this.open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(
          ["sessions", "sessionItems", "consultationPriorities", "operationReceipts"],
          "readwrite",
        );
        tx.objectStore("sessions").put(sanitizedSession);
        const itemStore = tx.objectStore("sessionItems");
        for (let i = 0; i < (items || []).length; i++) {
          itemStore.put(items[i]);
        }
        const prioStore = tx.objectStore("consultationPriorities");
        for (let i = 0; i < (consumedPriorities || []).length; i++) {
          prioStore.put(consumedPriorities[i]);
        }
        const result = { sessionId: sanitizedSession.sessionId, status: sanitizedSession.status };
        tx.objectStore("operationReceipts").put({
          scope,
          operationId,
          createdAt: Date.now(),
          result,
        });
        tx.oncomplete = () => resolve(result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error("Transazione sessione annullata."));
      });
    }

    async saveOutcomeAtomic(payload) {
      const {
        sessionRecord,
        sessionItem,
        exposureEvent,
        knowledgeState,
        consultationPriority,
        operationId,
      } = payload;
      const scope = `outcome:${sessionRecord.profileId}`;
      const existing = await this.getReceipt(scope, operationId);
      if (existing) return existing.result;

      const sanitizedSession = Object.assign({}, sessionRecord);
      if (sanitizedSession.status === "suspended") {
        sanitizedSession.suspendedProfileId = sanitizedSession.profileId;
      } else {
        delete sanitizedSession.suspendedProfileId;
      }

      const storesNeeded = ["sessions", "sessionItems", "operationReceipts"];
      if (exposureEvent) storesNeeded.push("exposureEvents");
      if (knowledgeState) storesNeeded.push("knowledgeStates");
      if (consultationPriority) storesNeeded.push("consultationPriorities");

      if (this._mem) {
        return this._mem.runTransaction(storesNeeded, async (mem) => {
          await mem.put("sessions", sanitizedSession);
          await mem.put("sessionItems", sessionItem);
          if (exposureEvent) await mem.put("exposureEvents", exposureEvent);
          if (knowledgeState) await mem.put("knowledgeStates", knowledgeState);
          if (consultationPriority) await mem.put("consultationPriorities", consultationPriority);
          const result = {
            sessionId: sanitizedSession.sessionId,
            itemId: sessionItem.itemId,
            score: sanitizedSession.score,
          };
          await mem.put("operationReceipts", {
            scope,
            operationId,
            createdAt: Date.now(),
            result,
          });
          return result;
        });
      }

      const db = await this.open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(storesNeeded, "readwrite");
        tx.objectStore("sessions").put(sanitizedSession);
        tx.objectStore("sessionItems").put(sessionItem);
        if (exposureEvent) tx.objectStore("exposureEvents").put(exposureEvent);
        if (knowledgeState) tx.objectStore("knowledgeStates").put(knowledgeState);
        if (consultationPriority) tx.objectStore("consultationPriorities").put(consultationPriority);
        const result = {
          sessionId: sanitizedSession.sessionId,
          itemId: sessionItem.itemId,
          score: sanitizedSession.score,
        };
        tx.objectStore("operationReceipts").put({
          scope,
          operationId,
          createdAt: Date.now(),
          result,
        });
        tx.oncomplete = () => resolve(result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error("Transazione esito annullata."));
      });
    }
  }

  global.InterrogationRepository = InterrogationRepository;
})(typeof window !== "undefined" ? window : globalThis);
