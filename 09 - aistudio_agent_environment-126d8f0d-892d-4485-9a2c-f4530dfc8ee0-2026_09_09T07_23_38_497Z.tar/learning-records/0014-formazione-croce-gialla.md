# Formazione della Croce Gialla e transizione all'allineamento degli spigoli

L'utente ha completato con successo la formazione della Croce Gialla sul tetto tramite la sequenza `F (R U R' U') F'`.
Ha inoltre osservato autonomamente la proprietà fondamentale del Passo 5: la croce gialla è orientata, ma i colori laterali degli spigoli non coincidono ancora con i centri laterali (due combaciano, due no).
Si procede con la permutazione degli spigoli dell'ultimo strato tramite l'algoritmo Sune (`R U R' U R U2 R' U`).
