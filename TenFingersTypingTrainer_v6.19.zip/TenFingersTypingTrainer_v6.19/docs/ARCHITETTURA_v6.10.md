# Architettura — TenFingersTypingTrainer v6.10

## Obiettivo

La release v6.10 perfeziona la gestione del dimensionamento visivo dell'applicazione introducendo l'approccio architetturale **"Informativo/Guida"**, basato sulla delega totale dello zoom al motore nativo del browser web.

Nelle versioni precedenti (v6.9), la manipolazione programmatica della proprietà CSS software `document.body.style.zoom` e l'intercettazione artificiale degli eventi da tastiera e rotellina del mouse causavano distorsioni nel calcolo delle geometrie assolute (`getBoundingClientRect`), anomalie nel trascinamento/ridimensionamento delle finestre flottanti e conflitti con i comandi nativi del browser.

La release v6.10 elimina qualsiasi interferenza CSS software invasiva:
1. **Delega nativa al 100%:** il browser gestisce autonomamente lo scaling vettoriale, le proporzioni e il rendering a livello di viewport senza distorsioni o disallineamenti nelle coordinate di drag & drop.
2. **Pulsante dedicato "🔍 Zoom-in e Zoom-out":** collocato nell'header principale (`#btnZoomInfo`), consente con un semplice click di aprire una finestra modale focalizzata che riassume visivamente le tre scorciatoie native universali del browser:
   - `CTRL+RotellinaMouse` (Zoom continuo)
   - `CTRL+SHIFT++` (Zoom-in / Ingrandimento)
   - `CTRL+SHIFT+-` (Zoom-out / Riduzione)
3. **Feedback visivo immediato (Mini-Toast):** i pulsanti "🔍+ Zoom-in" e "🔍- Zoom-out" forniscono all'utente un messaggio a comparsa non bloccante con l'indicazione della combinazione nativa da premere.
4. **Rimozione del blocco eventi:** le scorciatoie `CTRL+SHIFT++` e `CTRL+SHIFT+-` non sono più intercettate con `preventDefault()`, consentendo al browser di eseguire all'istante il comando nativo.

---

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo con impostazioni di ancoraggio |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico di default |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente (AppVersion v6.10) |
| `domain/phoneme-engine.js` | Generazione e gestione degli esercizi fonemici (supporto fonte di default e custom) |
| `ui/window-manager.js` | Finestre flottanti, drag & drop, z-index e vincoli al viewport |
| `engines/typing-engine.js` | Motore di digitazione, buffer tachimetrico e ricalcolo Media Mobile |
| `ui/visual-renderer.js` | Tastiera virtuale, rendering grafico mani e feedback |
| `engines/dictation-engine.js` | Dettatura vocale e sintesi vocale continua |
| `shared/export-utils.js` | Timestamp e utility di esportazione profili |
| `analytics/statistics-manager.js` | Metriche, grafici di velocità e istogrammi |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.10) |
| `app/controller/metodi-finestre-layout.js` | Gestione layout finestre, apertura/chiusura modale `#zoomHelpModal`, notifica toast e reset pulito dello stile di zoom |
| `app/controller/metodi-scorciatoie-editor-custom.js` | Gestione scorciatoie senza sequestro degli eventi di zoom del browser |
| `app/controller/metodi-profili-modali.js` | Ripristino layout profili e reset pulito dello stile di zoom |
| `app/controller/metodi-avvio-temi-audio.js` | Ciclo di vita applicativo, binding `setupZoomControls()` al bootstrap |
| `app/bootstrap.js` | Bootstrap e registrazione eventi DOM |

---

## Modello di Delega Nativa dello Zoom (Release v6.10)

L'architettura dello zoom si fonda su quattro direttive:

1. **Assenza di Manipolazione CSS Software:**
   - La proprietà `document.body.style.zoom` non viene mai alterata a runtime. Durante il reset dei layout (`resetAllWindowLayouts`) e il caricamento del profilo (`loginUser`), viene garantita la rimozione di eventuali stili residui (`document.body.style.zoom = ""`).
   - Questo garantisce che tutte le chiamate a `getBoundingClientRect()` per il posizionamento, l'ancoraggio (Pin) e il drag delle finestre flottanti riflettano coordinate viewport perfette, senza moltiplicatori o sfasamenti.

2. **Finestra Modale di Riferimento (`#zoomHelpModal`):**
   - Creata direttamente nel DOM in `index.html` con z-index elevato (4000).
   - Espone all'utente le tre scorciatoie essenziali in blocchi evidenziati:
     - `CTRL+RotellinaMouse`
     - `CTRL+SHIFT++`
     - `CTRL+SHIFT+-`
     - Nota pratica per il ripristino istantaneo al 100% con `CTRL+0`.
   - Chiusura flessibile tramite pulsante `&times;`, pulsante `OK`, click sullo sfondo oscurato o tasto `Escape`. Al termine della chiusura, il focus viene restituito automaticamente al campo di battitura.

3. **Sistema di Notifica Mini-Toast Non Invasivo (`showNotificationToast`):**
   - Quando l'utente fa click su "🔍+ Zoom-in" o "🔍- Zoom-out", il controller non tenta un'operazione CSS forzata, ma invoca `showNotificationToast(...)`.
   - Il toast appare nell'angolo inferiore destro con animazione fluida in dissolvenza (fade/translate), rimane visibile per 2500 millisecondi con `pointer-events: none` (per non ostacolare il click su altri elementi) e si chiude automaticamente.

4. **Trasparenza degli Accordi da Tastiera:**
   - In `metodi-scorciatoie-editor-custom.js`, i tasti `+` e `-` con combinazione `CTRL+SHIFT` non sono bloccati con `e.preventDefault()`. L'evento di tastiera prosegue la sua naturale propagazione al browser host, che attiva la funzione nativa di ingrandimento/riduzione.
