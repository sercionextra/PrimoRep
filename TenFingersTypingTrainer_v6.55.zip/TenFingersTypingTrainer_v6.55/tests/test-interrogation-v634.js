#!/usr/bin/env node
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const wmCode = fs.readFileSync(path.join(root, "js/ui/window-manager.js"), "utf8");
const keyMapCode = fs.readFileSync(path.join(root, "js/domain/keyboard-map.js"), "utf8");
const metaCode = fs.readFileSync(path.join(root, "js/interrogation/interrogation-layout-metadata.js"), "utf8");
const interrUiCode = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

// 1. Verifica HTML/CSS v6.34
assert(/\(v6\.\d+\)/.test(html), "Badge versione (v6.x) mancante in index.html");
assert(
  html.includes('id="interrogationDialog" class="modal-dialog interrogation-dialog interrogation-dialog-wide" data-allow-full-viewport="1"'),
  "#interrogationDialog deve avere data-allow-full-viewport='1'",
);
const interrCssMatch = css.match(/\.interrogation-dialog-wide\s*\{[\s\S]*?\}/);
assert(interrCssMatch && interrCssMatch[0].includes("max-height: 100vh;"), ".interrogation-dialog-wide deve avere max-height: 100vh;");

// 2. Verifica rimozione ~ e ` da key_igrave e key_quote (HTML SVG, KEY_MAP, Metadata, Catalogo)
const keyQuoteBlock = html.match(/<g[\s\S]*?id="key_quote"[\s\S]*?<\/g>/);
assert(keyQuoteBlock && !keyQuoteBlock[0].includes("label-altgr"), "key_quote SVG non deve avere label-altgr");
const keyIgraveBlock = html.match(/<g[\s\S]*?id="key_igrave"[\s\S]*?<\/g>/);
assert(keyIgraveBlock && !keyIgraveBlock[0].includes("label-altgr"), "key_igrave SVG non deve avere label-altgr");

const kmSandbox = {};
vm.runInNewContext(keyMapCode + "; this.KEY_MAP = KEY_MAP;", kmSandbox);
assert.strictEqual(kmSandbox.KEY_MAP["~"], undefined, "KEY_MAP non deve contenere '~'");
assert.strictEqual(kmSandbox.KEY_MAP["`"], undefined, "KEY_MAP non deve contenere '`'");

const metaSandbox = { window: {} };
metaSandbox.globalThis = metaSandbox;
vm.runInNewContext(metaCode, metaSandbox);
const meta = metaSandbox.window.InterrogationLayoutMetadata || metaSandbox.InterrogationLayoutMetadata;
assert(meta, "InterrogationLayoutMetadata non caricato");
assert.strictEqual(meta.KEY_SLOTS.key_igrave.altgr, null, "key_igrave.altgr deve essere null");
assert.strictEqual(meta.KEY_SLOTS.key_quote.altgr, null, "key_quote.altgr deve essere null");
assert(meta.ASCII_CHARACTERS.includes("~") && meta.ASCII_CHARACTERS.includes("`"), "ASCII_CHARACTERS deve mantenere ~ e ` come distrattori");

// 3. Verifica WindowManager full-viewport per #interrogationDialog e minTop=60 per altre finestre
function createMockWin(id, allowFull) {
  const classes = new Set();
  const listeners = {};
  const el = {
    id,
    dataset: allowFull ? { allowFullViewport: "1" } : {},
    style: { left: "100px", top: "80px", width: "900px", height: "600px" },
    classList: {
      add: (c) => classes.add(c),
      remove: (c) => classes.delete(c),
      contains: (c) => classes.has(c),
    },
    addEventListener: (ev, fn) => {
      listeners[ev] = listeners[ev] || [];
      listeners[ev].push(fn);
    },
    dispatchEvent: (ev, payload = {}) => {
      (listeners[ev] || []).forEach((fn) => fn(payload));
    },
    querySelectorAll: () => [],
    getBoundingClientRect: () => ({
      left: parseInt(el.style.left, 10),
      top: parseInt(el.style.top, 10),
      width: parseInt(el.style.width, 10),
      height: parseInt(el.style.height, 10),
    }),
    get offsetWidth() { return parseInt(el.style.width, 10); },
    get offsetHeight() { return parseInt(el.style.height, 10); },
    get offsetLeft() { return parseInt(el.style.left, 10); },
    get offsetTop() { return parseInt(el.style.top, 10); },
  };
  return el;
}

const winListeners = {};
const wmSandbox = {
  console,
  Math,
  parseInt,
  isNaN,
  window: {
    innerWidth: 1440,
    innerHeight: 900,
    addEventListener: (ev, fn) => {
      winListeners[ev] = winListeners[ev] || [];
      winListeners[ev].push(fn);
    },
    getComputedStyle: () => ({ position: "fixed" }),
  },
  document: {
    documentElement: { clientWidth: 1440, scrollHeight: 900 },
  },
};
vm.runInNewContext(wmCode + "; this.WindowManager = WindowManager;", wmSandbox);
const wm = new wmSandbox.WindowManager();

const interrDlg = createMockWin("interrogationDialog", true);
const interrHdr = createMockWin("interrogationWindowHeader", false);
interrHdr.closest = () => null;
wm.makeDraggable(interrDlg, interrHdr);

// Drag verso l'alto oltre top=0: deve fermarsi a top=0px (non 60px)
interrHdr.dispatchEvent("mousedown", { clientX: 200, clientY: 100, target: interrHdr });
winListeners.mousemove.forEach((fn) => fn({ clientX: 200, clientY: -50 }));
winListeners.mouseup.forEach((fn) => fn({}));
assert.strictEqual(interrDlg.style.top, "0px", "interrogationDialog deve poter essere trascinata fino a top: 0px");

// Finestra normale deve fermarsi a minTop=60px
const statsWin = createMockWin("statsFloatingWindow", false);
const statsHdr = createMockWin("statsHeader", false);
statsHdr.closest = () => null;
wm.makeDraggable(statsWin, statsHdr);
statsHdr.dispatchEvent("mousedown", { clientX: 200, clientY: 100, target: statsHdr });
winListeners.mousemove.forEach((fn) => fn({ clientX: 200, clientY: -50 }));
winListeners.mouseup.forEach((fn) => fn({}));
assert.strictEqual(statsWin.style.top, "60px", "statsFloatingWindow deve mantenere minTop = 60px");

// Resize verso sud di interrogationDialog a top=0: deve poter raggiungere 100vh (900px)
const handleS = createMockWin("rhS", false);
handleS.getAttribute = () => "s";
interrDlg.querySelectorAll = () => [handleS];
wm.makeResizable(interrDlg, null, 620, 440);
handleS.dispatchEvent("mousedown", { clientX: 500, clientY: 600, preventDefault: () => {}, stopPropagation: () => {} });
winListeners.mousemove.forEach((fn) => fn({ clientX: 500, clientY: 950 }));
winListeners.mouseup.forEach((fn) => fn({}));
assert.strictEqual(interrDlg.style.height, "900px", "interrogationDialog deve poter essere ridimensionata fino a 100vh (900px)");
assert.strictEqual(interrDlg.style.maxHeight, "none", "maxHeight deve essere 'none' durante il resize");

// 4. Verifica posizionamento orizzontale _openAsciiPopover
const popEl = {
  style: {},
  classList: {
    _set: new Set(["is-hidden"]),
    add(c) { this._set.add(c); },
    remove(c) { this._set.delete(c); },
    contains(c) { return this._set.has(c); },
  },
  getBoundingClientRect: () => ({ width: 400, height: 300 }),
};
const popBody = { innerHTML: "", appendChild: () => {} };
const uiSandbox = {
  console,
  Math,
  window: { innerWidth: 1280, innerHeight: 800 },
  document: {
    getElementById: (id) => {
      if (id === "interrAsciiPopover") return popEl;
      if (id === "interrAsciiPopoverBody") return popBody;
      if (id === "interrogationDialog") return interrDlg;
      return null;
    },
    createElement: () => ({
      className: "",
      textContent: "",
      type: "",
      title: "",
      addEventListener: () => {},
      appendChild: () => {},
    }),
  },
  InterrogationLayoutMetadata: meta,
};
uiSandbox.globalThis = uiSandbox;
vm.runInNewContext(interrUiCode, uiSandbox);
const InterrogationUI = uiSandbox.window.InterrogationUI || uiSandbox.InterrogationUI;
const ui = new InterrogationUI({});

const anchorRight = { getBoundingClientRect: () => ({ left: 950, top: 200, width: 120, height: 32, bottom: 232 }) };
ui._openAsciiPopover(anchorRight, {}, () => {});
assert.strictEqual(popEl.style.right, "auto");
assert.strictEqual(popEl.style.bottom, "auto");
const leftPosRight = parseInt(popEl.style.left, 10);
assert(leftPosRight > 700 && leftPosRight <= 1280 - 400 - 12, `leftPosRight fuori range atteso: ${leftPosRight}`);

const anchorLeft = { getBoundingClientRect: () => ({ left: 40, top: 200, width: 80, height: 32, bottom: 232 }) };
ui._openAsciiPopover(anchorLeft, {}, () => {});
const leftPosLeft = parseInt(popEl.style.left, 10);
assert.strictEqual(leftPosLeft, 12, "Popover vicino al bordo sinistro deve clampare a margin=12");

console.log("PASS: Tutte le verifiche v6.34 (full-viewport drag/resize, fix key_igrave/key_quote, posizionamento orizzontale popover ASCII) superate.");
