/* TenFingersTypingTrainer v6.24 — Help UI behavior extracted for strict CSP. */
// Theme switcher
      const themeToggle = document.getElementById("themeToggle");
      themeToggle.addEventListener("change", (e) => {
        document.body.className = e.target.value;
      });

      // Real-time search filter
      const searchInput = document.getElementById("helpSearch");
      searchInput.addEventListener("input", (e) => {
        const q = e.target.value.toLowerCase().trim();
        const sections = document.querySelectorAll("section.section-card");
        sections.forEach((sec) => {
          if (!q) {
            sec.style.display = "";
            return;
          }
          const text = sec.textContent.toLowerCase();
          sec.style.display = text.includes(q) ? "" : "none";
        });
      });
