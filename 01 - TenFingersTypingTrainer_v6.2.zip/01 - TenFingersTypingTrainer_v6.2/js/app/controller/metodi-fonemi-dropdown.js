/* TenFingersTypingTrainer v6.0 — AppController: phonemes. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// Sincronizza l'etichetta del pulsante dropdown con tutte le opzioni selezionate
  updateFonemiDropdownSummary() {
    const btnText = document.getElementById("lblFonemiSelectedText");
    const p = this.profileMgr?.profile;
    if (!btnText || !p || !p.FonemiOptions) return;

    const opt = p.FonemiOptions;
    const selected = [];
    if (opt.customFile) selected.push("Custom File");
    if (opt.maiuscole) selected.push("Maiuscole");
    if (opt.punteggiatura) selected.push("Punteggiatura");
    if (opt.parentesi) selected.push("Parentesi");
    if (opt.numeri) selected.push("Numeri");
    if (opt.matematici) selected.push("Matematici");
    if (opt.simboli) selected.push("Simboli");
    if (opt.layout) selected.push("Layout");

    if (selected.length === 0) {
      btnText.textContent = "Fonemi Base (nessun filtro)";
    } else {
      btnText.textContent = selected.join(", ");
    }
  },

setupFonemiDropdown() {
    const container = document.getElementById("fonemiMultiselectContainer");
    const btn = document.getElementById("btnFonemiDropdown");
    const list = document.getElementById("fonemiCheckboxesList");
    if (!container || !btn || !list) return;

    // Apertura/Chiusura menu a tendina
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = list.classList.contains("show");
      if (isOpen) {
        list.classList.remove("show");
        container.classList.remove("open");
        this.returnFocusToTyping();
      } else {
        list.classList.add("show");
        container.classList.add("open");
      }
    });

    // Chiusura automatica al click esterno con restituzione focus
    document.addEventListener("click", (e) => {
      if (!container.contains(e.target)) {
        if (list.classList.contains("show")) {
          list.classList.remove("show");
          container.classList.remove("open");
          this.returnFocusToTyping();
        }
      }
    });

    // Mappatura delle 8 checkbox
    const chkMap = {
      chkFonemiCustomFile: "customFile",
      chkFonemiMaiuscole: "maiuscole",
      chkFonemiPunteggiatura: "punteggiatura",
      chkFonemiParentesi: "parentesi",
      chkFonemiNumeri: "numeri",
      chkFonemiMatematici: "matematici",
      chkFonemiSimboli: "simboli",
      chkFonemiLayout: "layout",
    };

    Object.keys(chkMap).forEach((elemId) => {
      const chk = document.getElementById(elemId);
      const propKey = chkMap[elemId];
      if (chk) {
        chk.addEventListener("change", () => {
          const p = this.profileMgr?.profile;
          if (!p) return;
          if (!p.FonemiOptions) p.FonemiOptions = {};

          // Gestione guardia: Custom File senza testo caricato
          if (propKey === "customFile" && chk.checked) {
            const hasCustomText =
              p.FonemiCustomText && p.FonemiCustomText.trim().length >= 20;
            if (!hasCustomText) {
              chk.checked = false;
              p.FonemiOptions.customFile = false;
              this.notifyShortcutDisabled(
                "Nessun file custom per Fonemi. Utilizza 'Editor Custom' per caricarlo.",
              );
              this.updateFonemiDropdownSummary();
              this.profileMgr.saveProfile();
              return;
            }
          }

          p.FonemiOptions[propKey] = chk.checked;
          this.profileMgr.saveProfile();
          this.updateFonemiDropdownSummary();

          // Rigenera immediatamente l'esercizio se in Modalità 2
          if (this.typingEng.mode === 2) {
            this.startExercise(false);
          }
          this.returnFocusToTyping();
        });
      }
    });
  },

setupFonemiEditorButtons() {
    const btnInput = document.getElementById("btnFonemiInput");
    const btnOutput = document.getElementById("btnFonemiOutput");
    const btnConfig = document.getElementById("btnFonemiConfig");
    const fileInput = document.getElementById("fonemiFileInput");

    // 1. INPUT FONEMI CON ROLLBACK TRANSAZIONALE (v.4.7)
    btnInput?.addEventListener("click", () => {
      fileInput?.click();
    });

    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const textVal = ev.target?.result || "";
        if (textVal.trim().length >= 20) {
          if (this.profileMgr?.profile) {
            const prevFonemiText =
              this.profileMgr.profile.FonemiCustomText || "";
            this.profileMgr.profile.FonemiCustomText = textVal;
            const saved = this.profileMgr.saveProfile();

            if (saved) {
              this.showAppAlert(
                `Corpus Fonemi caricato con successo (${textVal.length} caratteri)! Ora puoi attivare la voce "Custom File" nella modalità Fonemi.`,
                "📂 Input Fonemi",
              );
            } else {
              // Rollback: memoria satura, ripristina il corpus precedente
              this.profileMgr.profile.FonemiCustomText = prevFonemiText;
              this.showAppAlert(
                `Impossibile importare il corpus fonemico: spazio di memoria del browser esaurito (Local Storage).\n\nL'operazione è stata annullata (rollback). Libera spazio eliminando profili o campioni prima di importare.`,
                "⚠ Importazione Fallita (Memoria Esaurita)",
              );
            }
          }
        } else {
          this.showAppAlert(
            "Il file selezionato è troppo breve per essere utilizzato come corpus fonemico.",
            "⚠ File Non Valido",
          );
        }
        fileInput.value = "";
      };
      reader.readAsText(file);
    });

    // 2. OUTPUT FONEMI
    btnOutput?.addEventListener("click", () => {
      const p = this.profileMgr?.profile;
      const textVal = p?.FonemiCustomText;
      if (textVal && textVal.trim().length > 0) {
        const blob = new Blob([textVal], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `FonemiCorpus_${p.UserID || "custom"}.txt`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        this.showAppAlert(
          "Attualmente l'unica fonte è quella di default (EMBEDDED_FONEMI_CORPUS)",
          "ℹ Output Fonemi",
        );
      }
      this.returnFocusToTyping();
    });

    // 3. CONFIGURAZIONE FONEMI (v.4.4)
    btnConfig?.addEventListener("click", () => {
      this.openFonemiConfigModal();
    });
  },

openFonemiConfigModal() {
    const modal = document.getElementById("fonemiConfigModal");
    const p = this.profileMgr?.profile;
    if (!modal || !p) return;

    // Caricamento parametro N (v.4.4)
    const txtNgram = document.getElementById("txtFonemiNgram");
    if (txtNgram) {
      txtNgram.value = String(p.FonemiNgramLength || 4);
    }

    const probs = p.FonemiProbabilities || {};
    const toPct = (val) => Math.round((val !== undefined ? val : 0.3) * 100);

    const txtMaiusc = document.getElementById("txtProbMaiuscole");
    const txtAllMaiusc = document.getElementById("txtProbAllMaiuscole");
    const txtPunt = document.getElementById("txtProbPunteggiatura");
    const txtPar = document.getElementById("txtProbParentesi");
    const txtNum = document.getElementById("txtProbNumeri");
    const txtMat = document.getElementById("txtProbMatematici");
    const txtSim = document.getElementById("txtProbSimboli");
    const txtLay = document.getElementById("txtProbLayout");

    if (txtMaiusc) txtMaiusc.value = toPct(probs.maiuscole);
    if (txtAllMaiusc) txtAllMaiusc.value = toPct(probs.allMaiuscole);
    if (txtPunt) txtPunt.value = toPct(probs.punteggiatura);
    if (txtPar) txtPar.value = toPct(probs.parentesi);
    if (txtNum) txtNum.value = toPct(probs.numeri);
    if (txtMat) txtMat.value = toPct(probs.matematici);
    if (txtSim) txtSim.value = toPct(probs.simboli);
    if (txtLay) txtLay.value = toPct(probs.layout);

    modal.classList.add("active");
  },

setupFonemiConfigModal() {
    const modal = document.getElementById("fonemiConfigModal");
    const btnConfirm = document.getElementById("btnConfirmFonemiConfig");
    const btnCancel = document.getElementById("btnCancelFonemiConfig");
    const btnClose = document.getElementById("btnCloseFonemiConfigModal");
    const btnResetDef = document.getElementById("btnFonemiConfigResetDefault");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      this.returnFocusToTyping();
    };

    btnCancel?.addEventListener("click", closeModal);
    btnClose?.addEventListener("click", closeModal);

    // Chiusura da tastiera con tasto Escape
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal?.classList.contains("active")) {
        closeModal();
      }
    });

    // Ripristino valori di default completi: N=4 e probabilità al 30%
    btnResetDef?.addEventListener("click", () => {
      const txtNgram = document.getElementById("txtFonemiNgram");
      if (txtNgram) txtNgram.value = "4";

      [
        "txtProbMaiuscole",
        "txtProbAllMaiuscole",
        "txtProbPunteggiatura",
        "txtProbParentesi",
        "txtProbNumeri",
        "txtProbMatematici",
        "txtProbSimboli",
        "txtProbLayout",
      ].forEach((id) => {
        const inp = document.getElementById(id);
        if (inp) inp.value = "30";
      });
    });

    btnConfirm?.addEventListener("click", () => {
      const p = this.profileMgr?.profile;
      if (!p) return;

      // Validazione parametro N tra 2 e 15 (v.4.5)
      const txtNgram = document.getElementById("txtFonemiNgram");
      let nVal = txtNgram ? parseInt(txtNgram.value, 10) : 4;
      if (isNaN(nVal) || nVal < 2) nVal = 2;
      if (nVal > 15) nVal = 15;
      p.FonemiNgramLength = nVal;

      const fromPct = (id) => {
        const el = document.getElementById(id);
        const val = el ? parseInt(el.value, 10) : 30;
        return Math.max(0, Math.min(100, isNaN(val) ? 30 : val)) / 100;
      };

      p.FonemiProbabilities = {
        maiuscole: fromPct("txtProbMaiuscole"),
        allMaiuscole: fromPct("txtProbAllMaiuscole"),
        punteggiatura: fromPct("txtProbPunteggiatura"),
        parentesi: fromPct("txtProbParentesi"),
        numeri: fromPct("txtProbNumeri"),
        matematici: fromPct("txtProbMatematici"),
        simboli: fromPct("txtProbSimboli"),
        layout: fromPct("txtProbLayout"),
      };

      this.profileMgr.saveProfile();
      closeModal();

      if (this.typingEng.mode === 2) {
        this.startExercise(false);
      }
    });
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
