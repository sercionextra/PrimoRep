#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const metodiInterr = fs.readFileSync(path.join(root, "js/app/controller/metodi-interrogazione.js"), "utf8");
const uiJs = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

// 1. Verifica statica: metodi-interrogazione.js non deve chiamare this.profileMgr.save() senza controllo su saveProfile()
assert(metodiInterr.includes('typeof this.profileMgr.saveProfile === "function"'), "onSessionComplete deve usare saveProfile()");
assert(uiJs.includes("currentSess.profileId || this.getProfileId()"), "handleComplete/Suspend/Abandon devono usare currentSess.profileId");

// 2. Verifica runtime: anche se onSessionComplete lancia un errore, handleComplete chiude e mostra il riepilogo
const ctx = {
  document: { getElementById: () => null },
  crypto: require("crypto").webcrypto,
  TextEncoder,
  Uint8Array,
  console,
  Math,
  Date,
  JSON,
  Set,
  Map,
};
ctx.window = ctx;
ctx.window.addEventListener = () => {};
ctx.globalThis = ctx;
vm.createContext(ctx);
[
  "js/data/interrogation-catalog-data.js",
  "js/interrogation/interrogation-layout-metadata.js",
  "js/interrogation/interrogation-catalog.js",
  "js/interrogation/interrogation-prng.js",
  "js/interrogation/interrogation-repository.js",
  "js/interrogation/interrogation-selector.js",
  "js/interrogation/interrogation-session-manager.js",
  "js/ui/interrogation-ui.js",
].forEach((rel) => {
  vm.runInContext(fs.readFileSync(path.join(root, rel), "utf8"), ctx, { filename: rel });
});

(async () => {
  const catalog = new ctx.InterrogationCatalog();
  const repo = new ctx.InterrogationRepository({ useMemory: true });
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository: repo });

  let closed = 0;
  const alerts = [];
  const ui = new ctx.InterrogationUI({
    sessionManager: mgr,
    catalog,
    onSessionComplete: () => {
      throw new Error("Simulated callback failure");
    },
    showAlert: (msg, title) => alerts.push({ msg, title }),
  });
  ui.close = () => { closed++; };

  const created = await mgr.createSession({
    profileId: "default",
    mode: "random",
    questionTypes: ["CARATTERE"],
    requestedCount: 1,
  });
  ui.activeSession = created.session;
  ui.activeItems = created.items;

  await ui.handleComplete();
  assert.strictEqual(closed, 1, "La finestra deve chiudersi nonostante errori in onSessionComplete");
  assert.strictEqual(ui.activeSession, null, "activeSession deve essere azzerata");
  assert.strictEqual(alerts.length, 1, "Deve essere mostrato l'alert conclusivo");
  assert.strictEqual(alerts[0].title, "🎓 Sessione Conclusa");
  console.log("PASS: Tutte le verifiche v6.36 superate.");
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
