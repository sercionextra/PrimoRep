# Ten Fingers Typing Trainer v5.1
## Specifica comportamentale di riferimento per il refactoring v6.0

> **Stato del documento:** specifica di riferimento ereditata dall’archivio sorgente. Descrive la baseline v5.1 e i requisiti di equivalenza; non è una generazione automatica dell’architettura v6.0. Per la struttura effettiva della nuova build, fare riferimento a `../ARCHITETTURA_v6.0.md`.


**Versione analizzata:** 6.0  
**Data indicata nei sorgenti:** 26/10/2026  
**Artefatto analizzato:** ZIP con 4 file applicativi  
**Obiettivo:** definire una specifica comportamentale, architetturale e visuale sufficientemente completa da consentire la ricostruzione indipendente dell'applicazione mediante vibe coding, preservando funzionalità e obiettivi e migliorando manutenibilità ed efficienza.

> **Nota metodologica.** Questo documento descrive il comportamento, i contratti funzionali, i dati, gli stati e l'architettura osservabili nei sorgenti analizzati. Per un'implementazione clean-room si raccomanda di usare questo documento come specifica di comportamento e di non riutilizzare codice, nomi interni o porzioni dell'implementazione originale salvo ciò che è necessario per interoperabilità con dati già persistiti.

---

# 1. Executive summary

Ten Fingers Typing Trainer è una web app client-side per l'addestramento alla dattilografia a dieci dita. L'applicazione è autosufficiente: non dipende da un backend applicativo, non usa framework JavaScript esterni e conserva profili, statistiche e impostazioni nel `localStorage` del browser.

Il prodotto combina:

1. percorso didattico progressivo basato su lezioni/frasi;
2. sette modalità di esercizio;
3. motore di digitazione con controllo carattere-per-carattere;
4. tastiera virtuale interattiva;
5. mani anatomiche vettoriali SVG con guida del dito;
6. feedback visivo, sonoro e vocale;
7. dettatura vocale adattiva tramite Web Speech API;
8. registro degli errori della sessione;
9. statistiche per carattere e storico delle sessioni;
10. grafici SVG interattivi;
11. filtri temporali e selezione di campioni;
12. editor di esercizi personalizzati;
13. archivio multiutente;
14. import/export dei profili;
15. quattro temi visuali;
16. ampia gestione di scorciatoie da tastiera;
17. finestre flottanti trascinabili/ridimensionabili;
18. gestione difensiva dell'esaurimento del `localStorage`.

Il repository originale è volutamente semplice: due HTML e due JavaScript. La complessità risiede soprattutto nei due file JavaScript monolitici, che contengono sia motori applicativi sia controller UI.

---

# 2. Inventario del repository

```text
/
├── index_(v.5.1).html
├── help_(v.5.1).html
├── main_A_(v.5.1).js
└── main_B_(v.5.1).js
```

## 2.1 `index_(v.5.1).html`

Responsabilità:

- shell completa dell'applicazione;
- markup della toolbar e della dashboard;
- controlli form;
- contenitore dell'area di digitazione;
- tastiera virtuale SVG;
- mani anatomiche SVG;
- finestre flottanti;
- statistiche;
- editor Custom;
- modali;
- CSS completo inline;
- collegamento ai due script JavaScript.

Il file non carica librerie esterne.

## 2.2 `help_(v.5.1).html`

Manuale utente incorporato nell'applicazione. Documenta:

- finalità didattiche;
- interfaccia;
- modalità;
- tastiera e mani;
- errori;
- statistiche;
- editor Custom;
- profili;
- hotkey;
- FAQ.

Nella ricostruzione conviene trattarlo come documentazione funzionale e come riferimento per acceptance test.

## 2.3 `main_A_(v.5.1).js`

Contiene il nucleo applicativo:

- utility;
- parser Custom;
- dataset embedded;
- `AudioEngine`;
- `ProfileManager`;
- `PhonemeEngine`;
- `WindowManager`;
- `TypingEngine`;
- `VisualRenderer`;
- `DictationEngine`.

È il principale layer di dominio/runtime.

## 2.4 `main_B_(v.5.1).js`

Contiene:

- `StatisticsManager`;
- `AppController`;
- wiring degli eventi UI;
- gestione delle toolbar;
- modali;
- editor Custom;
- statistiche;
- hotkey;
- bootstrap dell'app.

`AppController` agisce di fatto come composition root e orchestratore globale.

---

# 3. Caratteristiche architetturali osservate

## 3.1 Modello di esecuzione

L'app è una SPA client-side senza routing.

Flusso:

```text
DOMContentLoaded
    ↓
AppController
    ↓
inizializzazione dei manager
    ↓
ProfileManager.init()
    ↓
caricamento profilo attivo
    ↓
inizializzazione UI
    ↓
caricamento esercizio
    ↓
attesa input tastiera
    ↓
TypingEngine
    ├── AudioEngine
    ├── VisualRenderer
    ├── DictationEngine
    └── ProfileManager
             ↓
        localStorage
```

## 3.2 Dipendenze esterne

Non risultano dipendenze npm/runtime necessarie.

API browser principali:

- DOM;
- `localStorage`;
- `FileReader`;
- `Blob` / `URL.createObjectURL`;
- SVG DOM;
- timer;
- `SpeechSynthesis` / `SpeechSynthesisUtterance`;
- eventi tastiera;
- `requestAnimationFrame`.

Questo è un punto importante per la ricostruzione: l'app deve rimanere eseguibile anche aprendo il progetto come semplice sito statico.

## 3.3 Architettura consigliata per la nuova versione

La funzionalità deve restare equivalente, ma la nuova implementazione dovrebbe separare chiaramente:

```text
src/
├── app/
│   ├── App.ts
│   └── shortcuts.ts
├── domain/
│   ├── typing/
│   ├── lessons/
│   ├── phonemes/
│   ├── statistics/
│   ├── profiles/
│   └── dictation/
├── infrastructure/
│   ├── storage/
│   ├── speech/
│   ├── audio/
│   └── files/
├── ui/
│   ├── typing/
│   ├── keyboard/
│   ├── hands/
│   ├── statistics/
│   ├── editor/
│   ├── modals/
│   └── windows/
├── data/
│   ├── lessons.json
│   ├── phoneme-corpus.txt
│   └── default-profile.json
└── styles/
    ├── tokens.css
    ├── themes.css
    ├── layout.css
    └── components.css
```

La versione ricostruita dovrebbe preferibilmente usare TypeScript e moduli ES, pur mantenendo la possibilità di generare una build statica.

---

# 4. Dataset didattico

L'analisi eseguita sul dataset embedded rileva:

- **71 lezioni**;
- **996 frasi** complessive;
- corpus fonemico di circa **29 KB**;
- testo Custom predefinito separato.

Esempi di punti significativi:

- Lezione 1: `asdfl`, 21 frasi;
- Lezione 28: `Invio`, 14 frasi;
- Lezione 71: `Tab`, 14 frasi.

Questi dati devono essere trattati come dataset funzionale da preservare nella migrazione.

Il testo Custom utilizza un formato testuale strutturato con separatori:

```text
=====Titolo esercizio=====
frase uno
frase due
=====
altra frase
=====Altro esercizio=====
...
```

Regole osservate:

- `=====Titolo=====` apre una nuova tipologia/esercizio;
- `=====` chiude il blocco corrente;
- le righe consecutive appartenenti allo stesso blocco formano una frase;
- una normale interruzione di riga fisica viene trattata come separazione, non come `Enter` digitabile;
- il token interno `®` rappresenta il ritorno a capo digitabile;
- tabulazioni fisiche e gruppi di quattro spazi vengono normalizzati nel token `→`;
- gli esercizi privi di frasi vengono scartati.

La ricostruzione deve mantenere piena compatibilità semantica con questo formato.

---

# 5. Modello funzionale

## 5.1 Stati globali

L'app mantiene almeno questi concetti:

- utente attivo;
- sorgente lezioni: Standard / Custom;
- modalità corrente;
- indice lezione;
- indice frase;
- testo guida;
- testo digitato;
- stato esercizio completato;
- cronometro;
- errori correnti;
- metriche della sessione;
- impostazioni visuali;
- stato tastiera/mano;
- stato dettatura;
- stato finestra statistiche;
- stato editor Custom.

## 5.2 Stati della digitazione

Il motore deve distinguere almeno:

```text
IDLE
  ↓ primo input
RUNNING
  ├── CORRECT
  ├── ERROR_PENDING
  ├── CORRECTION
  └── COMPLETED
```

Un errore non deve essere interpretato semplicemente come carattere sbagliato e poi ignorato. L'app conserva la distanza tra:

- lunghezza del testo digitato;
- lunghezza del prefisso corretto.

Definizione concettuale:

```text
matchLength = lunghezza del massimo prefisso di typedText
              coincidente con originText
```

Gli errori pendenti sono riconducibili a:

```text
pendingErrors = max(0, typedLength - matchLength)
```

Questa distinzione è fondamentale per:

- Auto-Correction;
- Backspace;
- dettatura;
- badge errore;
- guida al Backspace;
- conteggio errori;
- registro dinamico.

---

# 6. Le sette modalità

## 6.1 Mode 0 — PHRASES

Scopo: percorso principale di touch typing.

Caratteristiche:

- usa la lezione corrente;
- usa le frasi native;
- il testo è didatticamente progressivo;
- navigazione lezioni abilitata;
- navigazione frasi abilitata;
- il comando Riavvia mantiene lo stesso esercizio;
- completamento registra il campione statistico.

Shortcut: `CTRL+SHIFT+1`.

## 6.2 Mode 1 — RANDOM

Genera sequenze di caratteri sulla base dei tasti appresi fino alla lezione corrente.

Vincolo importante: modalità pensata per la sorgente Standard.

- Riavvia: mantiene la sequenza corrente;
- Avanti: genera una nuova sequenza;
- navigazione lezioni non deve essere confusa con navigazione di sequenza.

Shortcut: `CTRL+SHIFT+2`.

## 6.3 Mode 2 — FONEMI

Generatore fonotattico italiano basato su catena di Markov.

Parametro principale:

```text
N-gram length: 2..15
default: 4
```

Filtri disponibili:

1. Custom File;
2. Maiuscole;
3. Punteggiatura;
4. Parentesi;
5. Numeri;
6. Matematici;
7. Simboli;
8. Layout.

Il corpus deve essere conservato e il generatore deve produrre una sequenza di lunghezza target comparabile all'originale.

Shortcut: `CTRL+SHIFT+3`.

## 6.4 Mode 3 — ALL CHARS

Sessione globale sull'inventario completo dei tasti.

Include:

- lettere;
- maiuscole;
- numeri;
- caratteri accentati;
- simboli;
- caratteri di layout.

Riavvia conserva l'esercizio; Avanti genera una nuova combinazione.

Shortcut:

- `CTRL+SHIFT+4`;
- `CTRL+SHIFT+G`.

## 6.5 Mode 4 — TYPING

Modalità libera.

Caratteristiche:

- niente testo guida;
- l'utente scrive liberamente;
- metriche in tempo reale;
- nessuna navigazione di lezione/frase;
- al termine è possibile salvare manualmente la sessione.

Shortcut: `CTRL+SHIFT+5`.

## 6.6 Mode 5 — RANDOM THIS PHRASE

Prende la frase corrente e ne rimescola i caratteri.

- Riavvia conserva la sequenza;
- Avanti produce un nuovo rimescolamento;
- navigazione lezioni/frasi disabilitata.

Shortcut: `CTRL+SHIFT+Z`.

## 6.7 Mode 6 — WEAKNESSES

Modalità adattiva.

Scopo: generare esercizi pesati sui caratteri sui quali l'utente commette più errori.

Richiede:

- statistiche per carattere;
- conteggio frequenza;
- conteggio errori;
- associazione carattere → dito.

Shortcut: `CTRL+SHIFT+6`.

---

# 7. Gestione input da tastiera

Il comportamento della tastiera è uno degli aspetti più delicati del prodotto.

## 7.1 Principio

L'app non deve basarsi soltanto su `input.value`.

La digitazione deve essere intercettata a livello `keydown`/`keyup` e normalizzata.

Devono essere gestiti esplicitamente:

- lettere;
- numeri;
- simboli;
- Shift;
- AltGr;
- Ctrl;
- Enter;
- Tab;
- Backspace;
- Caps Lock;
- combinazioni di modificatori;
- shortcut dell'app.

## 7.2 Modificatori

L'app distingue:

- modificatori necessari per produrre il carattere target;
- modificatori puramente appartenenti a una shortcut;
- modificatori non previsti dal target.

Il comportamento deve evitare di registrare come errore un `Shift` premuto correttamente in preparazione a una maiuscola.

Per le combinazioni incrociate:

- carattere della mano sinistra → Shift destro;
- carattere della mano destra → Shift sinistro.

La rappresentazione visuale deve mantenere il modificatore fisicamente premuto evidenziato fino al rilascio.

## 7.3 Backspace

Il Backspace ha una semantica specifica:

1. non viene trattato come semplice carattere;
2. rimuove il carattere più recente dal testo digitato;
3. aggiorna gli errori pendenti;
4. può produrre feedback vocale scalare;
5. può riportare la sessione da errore a stato corretto;
6. non deve introdurre un falso avanzamento del testo guida.

Quando gli errori pendenti scendono a zero, la dettatura può riprendere immediatamente.

## 7.4 Enter e Tab

Nel modello interno:

```text
® = Enter
→ = Tab
```

La UI deve poter visualizzare i token come simboli leggibili, ma l'input reale deve provenire dai tasti fisici Enter e Tab.

---

# 8. Testo guida e allineamento visivo

La zona di digitazione ha due livelli:

1. testo guida;
2. testo digitato.

Il carattere target corrente deve essere chiaramente distinguibile.

Gli spazi sono speciali: l'app visualizza un indicatore dedicato e tenta di mantenere l'allineamento orizzontale fra guida e input.

È presente un auto-scroll che porta il carattere bersaglio in una zona visibile del contenitore.

La ricostruzione dovrebbe ottenere questo risultato tramite un renderer incrementale o virtualizzato, evitando di ricostruire inutilmente tutto l'HTML a ogni tasto.

---

# 9. Registro degli errori

Il registro è dinamico e session-scoped.

Ogni errore è una coppia:

```text
{
  expected: carattere atteso,
  wrong: carattere digitato
}
```

La UI mostra:

- contatore;
- tessere per coppia;
- carattere atteso;
- carattere errato;
- auto-scroll verso l'ultimo errore;
- placeholder quando non esistono errori.

È presente anche un contatore sincronizzato nella finestra Mani.

Il registro della sessione deve essere distinto dalle statistiche storiche permanenti.

---

# 10. Metriche della sessione

Metriche osservate:

- tempo;
- caratteri corretti;
- velocità netta;
- velocità lorda;
- errori;
- percentuale errori.

Per il campione storico viene utilizzata principalmente la velocità netta in battute/minuto.

Per una sessione completata:

```text
netBpm = caratteri corretti / minuti trascorsi
```

con arrotondamento intero.

Per la modalità libera:

```text
chars = lunghezza testo digitato
netBpm = chars / minuti trascorsi
```

e il campione viene salvato manualmente.

---

# 11. Persistenza e modello dati

## 11.1 Storage

Chiavi globali osservate:

```text
TFTT_USERS
TFTT_ACTIVE_USER
TFTT_FIRST_RUN_DONE
TFTT_PROFILE_<UserID>
```

## 11.2 Profilo

Il profilo contiene almeno:

```text
UserID
Mode
Lesson
Exercise
AutomaticCorrection
ShowKeyBoard
ShowHands
ShowOrigin
ShowTyped
ShowErrors
UseKeyPositions
UseCustomKeyDistances
Theme
AudioMode
AudioVolume
DictationEnabled
DictationSpeed
DictationCaps
DictationApostrophe
DictationSpelling
DictationSpace
HandsTop
HandsLeft
HandsWidth
HandsHeight
HandsPinned
HandsOffsetTop
StatTop
StatLeft
StatWidth
StatHeight
CustomText
FonemiCustomText
FonemiNgramLength
FonemiOptions
FonemiProbabilities
TotaleCaratteri
TotaleErrori
Caratteri
Campioni
```

La ricostruzione deve prevedere migrazioni di schema versionate.

## 11.3 Statistica per carattere

Schema concettuale:

```json
{
  "Index": 0,
  "CharUnicode": 97,
  "Frequenza": 100,
  "Errori": 4
}
```

## 11.4 Campione storico

Schema:

```json
{
  "Index": 0,
  "BattuteMinuto": 180,
  "TipoCampione": 1,
  "NumCaratteri": 250,
  "NumErrori": 3,
  "Esercizio": "Lezione 1: asdfl",
  "DataOra": "YYYY-MM-DDTHH:mm:ss"
}
```

Mappatura osservata:

```text
1 = Phrases
3 = Random
7 = Fonemi
6 = All Chars
4 = Typing
5 = Random This Phrase
8 = Weaknesses
```

## 11.5 Data/ora

Il timestamp è locale e nel formato:

```text
YYYY-MM-DDTHH:mm:ss
```

Non usare UTC se l'obiettivo è mantenere esattamente la semantica dell'originale.

---

# 12. Gestione quota Local Storage

La versione originale implementa una protezione specifica contro l'esaurimento dello storage.

La nuova versione deve mantenere:

- intercettazione di `QuotaExceededError`;
- stato globale `storageFull`;
- callback UI;
- avviso una sola volta per esercizio;
- possibilità di rilevare il successivo ripristino dello spazio;
- mancato crash dell'applicazione.

Per una versione più efficiente è consigliabile aggiungere:

- serializzazione debounced;
- coda di persistenza;
- eventuale `IndexedDB` come storage primario;
- `localStorage` come compatibilità/backup.

Se si introduce IndexedDB, deve comunque essere preservato l'obiettivo di non perdere dati.

---

# 13. Profili multiutente

Funzionalità:

- elenco utenti;
- caricamento profilo;
- creazione;
- eliminazione;
- cambio utente;
- salvataggio;
- reset dell'archivio demo;
- import/export JSON.

Al primo avvio:

- viene creato l'utente demo;
- vengono inizializzati dati e impostazioni;
- l'utente attivo viene impostato sul demo.

L'identificatore dell'utente è utilizzato anche per la chiave di storage.

La nuova implementazione dovrebbe separare:

```text
UserRepository
ProfileRepository
ProfileMigrationService
ProfileImportExportService
```

---

# 14. Audio

`AudioEngine` supporta almeno tre modalità:

```text
typewriter
beep
mute
```

Volume predefinito osservato:

```text
0.7
```

Il motore deve evitare di creare inutilmente nuovi contesti audio a ogni pressione. La soluzione ottimale è un singolo `AudioContext` lazy-initialized.

Eventi sonori:

- battuta;
- errore;
- completamento/bell.

---

# 15. Dettatura vocale

La dettatura usa `window.speechSynthesis`.

Stato principale:

```text
enabled
speed
announceCaps
announceApostrophe
announceSpace
forceSpelling
tokens
currentIndex
isSpeaking
hasPendingError
stallTimer
hasFiredAutoReplay
isSpeakingReplay
isRecoveringFromCorrection
```

## 15.1 Velocità

Range funzionale documentato:

```text
0.6x → 1.4x
default = 0.9x
```

## 15.2 Tokenizzazione

Il testo viene segmentato in unità pronunciate.

La segmentazione deve considerare:

- parole;
- spazi;
- apostrofi;
- punteggiatura;
- parentesi;
- numeri;
- simboli;
- Enter;
- Tab;
- maiuscole.

## 15.3 Dizionario fonetico

Il comportamento include nomi italiani per:

- lettere;
- accenti;
- simboli;
- punteggiatura;
- parentesi;
- layout.

Esempi funzionali:

```text
. → punto
, → virgola
: → due punti
' → apostrofo
® → invio
→ → tàb
@ → chiocciola
& → e commerciale
```

## 15.4 Voce

Il motore cerca una voce italiana adeguata e conserva un fallback locale.

Deve inoltre gestire i problemi di Safari/WebKit mantenendo riferimenti alle utterance.

## 15.5 Error feedback

Quando la dettatura è attiva:

- errore → pronuncia immediata di “errore”;
- Backspace con errori residui → indicazione scalare;
- eliminazione dell'ultimo errore → ripresa della guida;
- pausa prolungata → replay assistito.

## 15.6 Watchdog

È presente una logica di auto-healing:

- timeout base circa 3,5 s;
- tolleranza fino a circa 5 s quando l'audio è ancora occupato;
- se l'audio resta bloccato, viene forzato lo stop;
- viene eseguito un replay una sola volta per pausa.

Questo comportamento deve essere testato specificamente su Chrome, Edge e Safari.

---

# 16. Tastiera virtuale

La tastiera è una rappresentazione SVG di una tastiera italiana estesa.

Gli ID dei keycap rappresentano fisicamente tasti quali:

- lettere;
- numeri;
- accenti;
- Backspace;
- Tab;
- Enter;
- Caps;
- Shift sinistro/destra;
- Ctrl;
- Win;
- Alt;
- AltGr;
- Menu;
- Space.

Il renderer deve poter:

1. individuare il keycap del carattere target;
2. evidenziarlo;
3. mostrare la pressione fisica;
4. mostrare i modificatori;
5. guidare il Backspace;
6. gestire Caps Lock;
7. supportare flash temporanei.

---

# 17. Mani anatomiche

La finestra Mani è una componente SVG indipendente.

Elementi concettuali:

```text
leftHandGroup
rightHandGroup
10 dita
punti guida
keycap virtuali
indicatori centrali
badge errore
badge completamento
contatore errori
```

## 17.1 Codifica dita

```text
1  mignolo sinistro
2  anulare sinistro
3  medio sinistro
4  indice sinistro
5  pollice sinistro
6  pollice destro
7  indice destro
8  medio destro
9  anulare destro
10 mignolo destro
```

## 17.2 Codifica cromatica

- mignoli: rosso;
- anulari: arancio;
- medi: verde;
- indici: blu;
- pollici: viola.

## 17.3 Keycap sui polpastrelli

I keycap proiettati sui polpastrelli sono grandi e ad alta leggibilità.

Devono adattarsi a label lunghe come:

- SPAZIO;
- SHIFT;
- INVIO.

## 17.4 Posizione tasti

La modalità anatomica mostra punti di riferimento per le posizioni dei tasti.

La visualizzazione deve poter essere attivata/disattivata senza distruggere lo stato della guida normale.

---

# 18. Finestre flottanti

Sono presenti almeno:

- finestra Mani;
- finestra Statistiche;
- finestra Editor Custom.

Funzionalità comuni:

- drag dalla header;
- resize;
- clamp ai bordi viewport;
- close;
- reset posizione/dimensione quando previsto.

La finestra Mani ha anche:

- pin/unpin;
- default position;
- modalità Posizione Tasti.

La finestra Statistiche ha:

- navigazione grafici;
- reset layout;
- maximize;
- close.

La nuova implementazione dovrebbe centralizzare il comportamento in un `FloatingWindowController` generico invece di duplicare la logica.

---

# 19. Temi grafici

Sono presenti quattro temi:

1. Dark Mode;
2. Light Mode;
3. Retro 2003;
4. Matrix High-Contrast.

Il tema è implementato tramite CSS custom properties.

La nuova versione deve conservare:

- palette;
- gerarchia visiva;
- contrasto;
- feedback errore/successo;
- identità Retro;
- font monospace nel tema Matrix.

La soluzione consigliata è una tokenizzazione CSS:

```css
:root { ... }
[data-theme="dark"] { ... }
[data-theme="light"] { ... }
[data-theme="retro"] { ... }
[data-theme="matrix"] { ... }
```

---

# 20. Header e toolbar

## Header

Contiene:

- titolo applicazione/versione;
- utente attivo;
- cambio utente;
- Help;
- tema;
- audio;
- volume;
- dettatura;
- velocità;
- opzioni dettatura;
- replay;
- editor;
- statistiche.

## Toolbar 1

Contiene:

- modalità;
- precedente/successiva lezione;
- combo lezione;
- sorgente;
- range frasi;
- titolo esercizio.

## Toolbar 2

Contiene:

- frase precedente;
- frase successiva;
- vai a frase;
- casuale;
- riavvia;
- tutti i tasti;
- visibilità guida;
- visibilità input;
- visibilità errori;
- tastiera;
- mani;
- auto-correzione.

I controlli devono abilitarsi/disabilitarsi in funzione della modalità corrente.

---

# 21. Modali

Sono presenti almeno:

- conferma cambio lezione;
- alert applicativi;
- selezione frase;
- titolo esercizio Custom;
- eventuali dialoghi di cancellazione statistiche.

Requisiti:

- ESC chiude il modale;
- focus gestito in modo prevedibile;
- click sui pulsanti non deve lasciare listener duplicati;
- il focus deve ritornare all'area di digitazione quando appropriato.

La nuova versione dovrebbe usare un solo `ModalService`.

---

# 22. Statistiche

`StatisticsManager` gestisce due viste principali.

## 22.1 Istogramma

Rappresenta statistiche per carattere.

Ordinamenti osservati:

- frequenza relativa;
- frequenza assoluta;
- errori relativi;
- errori assoluti;
- dito relativo;
- dito assoluto.

I dati sono arricchiti con la relazione carattere → dito.

## 22.2 Grafico velocità

Metrica selezionabile:

- BPM;
- caratteri;
- errori relativi;
- errori assoluti.

## 22.3 Filtri tipo sessione

Il filtro supporta gli otto tipi di campione disponibili nell'archivio.

## 22.4 Filtri data/ora

Quattro campi:

- data inizio;
- ora inizio;
- data fine;
- ora fine.

Devono essere supportati:

- modifica live;
- validazione intervallo;
- cancellazione singolo campo;
- reset completo.

## 22.5 Selezione campioni

Il grafico storico consente selezione di punti.

Operazioni:

- cancella selezionati;
- cancella non selezionati;
- cancella selezione.

Le operazioni distruttive richiedono conferma.

## 22.6 Performance consigliata

Il rendering SVG può diventare costoso con molti campioni.

Per la nuova versione:

- normalizzare i dati prima del rendering;
- evitare `innerHTML` completo se non necessario;
- usare canvas per dataset molto grandi oppure SVG con virtualizzazione;
- debouncare i filtri;
- calcolare statistiche una sola volta per stato.

---

# 23. Editor Custom

L'editor è una textarea con toolbar.

Azioni:

- inserisci titolo;
- inserisci separatore;
- inserisci Tab;
- inserisci Enter;
- upload;
- download;
- salva;
- chiudi.

La modifica del Custom Text deve essere validata prima del salvataggio.

Pattern consigliato:

```text
textarea
  ↓
parse
  ↓
validate
  ↓
commit atomico
```

In caso di errore:

```text
mantieni profilo precedente
non sovrascrivere CustomText
mostra errore
```

Il download genera un file locale tramite `Blob`.

---

# 24. Import/export

Devono essere supportati:

- export profilo JSON;
- import profilo JSON;
- export testo Custom;
- import testo Custom.

I dati importati devono essere validati e migrati.

Non fidarsi ciecamente del JSON importato: il browser è il boundary di sicurezza.

---

# 25. Shortcut matrix

| Funzione | Shortcut |
|---|---|
| PHRASES | Ctrl+Shift+1 |
| RANDOM | Ctrl+Shift+2 |
| FONEMI | Ctrl+Shift+3 |
| ALL CHARS | Ctrl+Shift+4 / G |
| TYPING | Ctrl+Shift+5 |
| WEAKNESSES | Ctrl+Shift+6 |
| Stats view | Ctrl+Shift+7 |
| Spelling | Ctrl+Shift+8 / P |
| Dictation | Ctrl+Shift+9 / V |
| Add statistic | Ctrl+Shift+0 / Enter |
| Lesson previous/next | Ctrl+Shift+↑ / ↓ |
| Phrase previous/next | Ctrl+Shift+← / → |
| Select phrase | Ctrl+Shift+E |
| Restart | Ctrl+Shift+X |
| Random this phrase | Ctrl+Shift+Z |
| Origin | Ctrl+Shift+O |
| Typed | Ctrl+Shift+Y |
| Errors | Ctrl+Shift+L / F |
| Keyboard | Ctrl+Shift+K |
| Hands | Ctrl+Shift+M |
| Auto-correction | Ctrl+Shift+B |
| Dictation replay | Ctrl+Shift+Space |
| Source Standard/Custom | Ctrl+Shift+D |

Nota: la nuova implementazione deve centralizzare la mappa shortcut e impedire che una shortcut interferisca con la digitazione normale.

---

# 26. Accessibilità e UX

La ricostruzione deve migliorare l'accessibilità senza alterare la UX.

Requisiti:

- controlli con `aria-label`;
- stato `aria-pressed` per toggle;
- stato `aria-expanded` per dropdown;
- focus visibile;
- contrasto adeguato;
- non affidarsi esclusivamente al colore;
- riduzione animazioni con `prefers-reduced-motion`;
- supporto tastiera completo;
- annunci vocali non devono sostituire il feedback visivo.

---

# 27. Sicurezza

Il rischio principale è l'iniezione di HTML attraverso contenuti Custom o dati importati.

Regole:

- non inserire direttamente testo utente in `innerHTML`;
- usare `textContent` quando possibile;
- se HTML è inevitabile, usare un sanitizzatore;
- non eseguire codice contenuto nei file importati;
- non interpretare Custom Text come JavaScript;
- validare JSON importato;
- non consentire URL esterni non necessari.

Il renderer degli errori deve mantenere l'escaping dei caratteri.

---

# 28. Piano di refactoring per una ricostruzione più efficiente

## Fase 1 — Core domain

Implementare prima:

1. modelli;
2. parser Custom;
3. lesson repository;
4. typing state machine;
5. statistiche;
6. profilo.

Questa fase non deve dipendere dal DOM.

## Fase 2 — Adapters browser

Implementare:

- LocalStorage adapter;
- audio adapter;
- speech adapter;
- file adapter;
- keyboard adapter.

## Fase 3 — UI

Componenti:

- Header;
- Toolbar;
- TypingArea;
- ErrorRegister;
- MetricsDashboard;
- VirtualKeyboard;
- HandsPanel;
- StatsWindow;
- CustomEditor;
- Modals.

## Fase 4 — orchestrazione

Un controller sottile coordina:

```text
User Action
 → Command
 → Domain State
 → State Change
 → UI Render
 → Persistence
```

## Fase 5 — performance

Applicare:

- event delegation;
- rendering incrementale;
- debounce;
- memoization;
- un solo timer per funzione;
- eliminazione dei reflow forzati;
- persistenza debounced;
- cleanup sistematico degli event listener.

---

# 29. Contratto di comportamento per il Vibe Coding

Il prompt di implementazione deve esplicitare che:

1. tutte le sette modalità sono obbligatorie;
2. il comportamento del Backspace è parte del dominio, non un dettaglio UI;
3. Enter e Tab sono caratteri didattici reali;
4. la dettatura deve sincronizzarsi con il prefisso corretto;
5. le mani e la tastiera devono reagire alla stessa sorgente di stato;
6. le statistiche non devono dipendere dalla struttura HTML;
7. il profilo deve essere persistente;
8. cambio utente non deve contaminare i dati;
9. import/export deve essere reversibile;
10. le finestre flottanti devono essere indipendenti;
11. i controlli non applicabili devono essere disabilitati;
12. le shortcut non devono rubare input quando non pertinenti;
13. il completamento deve produrre feedback visivo e, se attiva, vocale;
14. il dataset Standard deve rimanere invariato;
15. il Custom parser deve essere compatibile;
16. i quattro temi devono essere preservati;
17. la versione ricostruita deve poter funzionare senza server applicativo.

---

# 30. Acceptance test funzionali

## AT-01 Primo avvio

**Dato:** browser senza dati.  
**Quando:** si apre l'app.  
**Atteso:** profilo demo creato e caricato.

## AT-02 Persistenza

**Dato:** modifiche alle impostazioni.  
**Quando:** reload.  
**Atteso:** impostazioni conservate.

## AT-03 Correzione errore

**Dato:** target `a`, input `x`.  
**Atteso:** errore registrato, target resta coerente, guida al Backspace.

## AT-04 Backspace progressivo

**Dato:** più errori pendenti.  
**Quando:** Backspace ripetuto.  
**Atteso:** gli errori pendenti diminuiscono uno per volta.

## AT-05 Auto-correction

**Dato:** errore e auto-correction attiva.  
**Atteso:** stato torna immediatamente al prefisso corretto secondo le regole della modalità.

## AT-06 Enter

**Dato:** target `®`.  
**Quando:** pressione Enter.  
**Atteso:** carattere accettato.

## AT-07 Tab

**Dato:** target `→`.  
**Quando:** pressione Tab.  
**Atteso:** carattere accettato senza perdere il controllo applicativo.

## AT-08 Dettatura

**Dato:** dettatura attiva.  
**Atteso:** testo pronunciato in anticipo controllato.

## AT-09 Dettatura + errore

**Atteso:** feedback “errore”, sospensione/soft hold e ripresa dopo correzione.

## AT-10 Replay inattività

**Dato:** nessun input per oltre la soglia.  
**Atteso:** un solo replay assistito.

## AT-11 Random

**Atteso:** Riavvia conserva la sequenza, Avanti ne genera una nuova.

## AT-12 Fonemi

**Atteso:** generazione coerente con N-gram configurato e filtri.

## AT-13 Weaknesses

**Dato:** statistiche con caratteri deboli.  
**Atteso:** generazione pesata verso tali caratteri.

## AT-14 Statistiche

**Atteso:** campione completato appare nello storico.

## AT-15 Selezione grafico

**Atteso:** selezione di punti e cancellazione confermata.

## AT-16 Custom

**Atteso:** testo valido → esercizi caricati; testo invalido → rollback.

## AT-17 Multiutente

**Atteso:** cambio utente isola completamente le statistiche.

## AT-18 Import/export

**Atteso:** export → import produce dati equivalenti.

## AT-19 Tema

**Atteso:** tutti i quattro temi mantengono leggibilità e layout.

## AT-20 Quota storage

**Atteso:** errore di quota non causa crash e mostra stato di salvataggio non attivo.

---

# 31. Test di regressione consigliati

La suite minima dovrebbe comprendere:

### Unit test

- parser Custom;
- `matchLength`;
- calcolo errori;
- mapping char → key;
- mapping key → finger;
- generatore Random;
- Markov generator;
- Weakness weighting;
- metriche BPM;
- schema migration;
- statistiche per carattere.

### Integration test

- TypingEngine + ProfileRepository;
- TypingEngine + Dictation;
- TypingEngine + Keyboard;
- StatsManager + Profile;
- CustomEditor + parser.

### E2E

- primo avvio;
- percorso completo lezione;
- error correction;
- shortcut;
- dettatura;
- statistiche;
- cambio profilo;
- import/export.

---

# 32. Miglioramenti architetturali raccomandati

## 32.1 Separare dominio e DOM

L'attuale `AppController` contiene una quantità elevata di logica UI.

Target:

```text
Domain state
    ↓
Selectors
    ↓
View model
    ↓
UI renderer
```

## 32.2 Stato centralizzato

Un piccolo store reattivo evita di avere proprietà sparse fra controller.

## 32.3 Persistenza debounced

Non eseguire `localStorage.setItem()` a ogni singola battuta.

Strategia:

```text
keypress
  ↓
update memory state
  ↓
render
  ↓
schedule persistence 250–500 ms
```

con flush immediato su:

- cambio utente;
- chiusura pagina;
- completamento;
- export;
- cambio profilo.

## 32.4 Dataset fuori dal JS

Per manutenibilità:

```text
lessons.json
phoneme-corpus.txt
default-profile.json
```

con build che li incorpora, se si vuole conservare l'esecuzione offline.

## 32.5 TypeScript

È fortemente consigliato per:

- profili;
- modalità;
- campioni;
- mapping tastiera;
- eventi;
- token vocali;
- configurazione.

## 32.6 Event bus tipizzato

Eventi suggeriti:

```text
EXERCISE_LOADED
KEY_ACCEPTED
KEY_REJECTED
ERROR_ADDED
ERROR_CORRECTED
EXERCISE_COMPLETED
PROFILE_CHANGED
THEME_CHANGED
DICTATION_STATE_CHANGED
STATS_UPDATED
WINDOW_MOVED
WINDOW_RESIZED
```

## 32.7 Render scheduling

Tutti gli aggiornamenti visuali dovrebbero essere aggregati per frame:

```text
multiple state changes
        ↓
requestAnimationFrame
        ↓
single render pass
```

---

# 33. Specifica per una ricostruzione clean-room

La nuova implementazione dovrebbe essere organizzata in tre livelli.

## Livello A — Behavioral specification

Definisce:

- cosa può fare l'utente;
- cosa vede;
- cosa sente;
- come reagisce ogni input;
- cosa viene persistito.

## Livello B — Domain specification

Definisce:

- entità;
- stati;
- transizioni;
- algoritmi;
- invarianti.

## Livello C — Presentation specification

Definisce:

- layout;
- controlli;
- dimensioni relative;
- colori;
- animazioni;
- SVG;
- finestre.

L'implementatore deve poter sostituire completamente:

- nomi delle classi;
- nomi delle funzioni;
- struttura dei file;
- framework;
- tecnologia di rendering;

senza cambiare il comportamento previsto.

---

# 34. Invarianti fondamentali

1. Il testo guida non deve avanzare su una battuta errata salvo regola esplicita della modalità.
2. Il carattere target è sempre determinabile dal primo carattere non correttamente risolto.
3. Backspace modifica lo stato di input ma non equivale a una nuova battuta valida.
4. La statistica storica non deve essere aggiornata accidentalmente da un semplice reload.
5. Ogni utente possiede un archivio isolato.
6. Il completamento è un evento idempotente.
7. Il replay automatico non deve ripetersi indefinitamente.
8. Il cambio modalità deve fermare timer/audio/dettatura appartenenti all'esercizio precedente.
9. Il cambio esercizio deve eliminare i listener temporanei.
10. Le finestre non possono diventare irraggiungibili fuori viewport.
11. I dati Custom non devono essere interpretati come HTML o JavaScript.
12. L'import non deve corrompere il profilo esistente se fallisce.
13. La UI non deve diventare inutilizzabile se Speech Synthesis non è disponibile.
14. L'app deve rimanere utilizzabile anche con audio disabilitato.
15. La modalità libera non deve richiedere un testo guida.

---

# 35. Priorità di implementazione

### P0 — indispensabile

- typing engine;
- sette modalità;
- dataset;
- profili;
- persistenza;
- tastiera;
- mani;
- metriche;
- errori;
- Custom;
- statistiche;
- shortcut;
- temi.

### P1 — fondamentale per equivalenza UX

- dettatura;
- replay;
- finestre flottanti;
- selezione grafici;
- gestione quota;
- import/export;
- posizione tasti.

### P2 — miglioramenti

- TypeScript;
- IndexedDB;
- PWA;
- test automatici;
- accessibilità avanzata;
- rendering ottimizzato;
- telemetry locale opzionale.

---

# 36. Conclusione

L'applicazione è concettualmente un trainer di digitazione con un dominio abbastanza ricco da meritare una ricostruzione come prodotto software strutturato, non come semplice pagina HTML.

Il punto più importante per una reimplementazione fedele non è replicare la struttura dei quattro file originali, ma preservare questi contratti:

```text
INPUT
  ↓
Typing State Machine
  ↓
┌──────────────┬──────────────┬──────────────┐
│ Visual       │ Audio        │ Dictation    │
│ feedback     │ feedback     │ feedback     │
└──────────────┴──────────────┴──────────────┘
  ↓
Metrics + Errors
  ↓
Profile Persistence
  ↓
Statistics History
```

Una nuova implementazione può quindi essere molto più modulare, testabile e performante pur mantenendo la stessa esperienza d'uso.

La strategia consigliata è ricostruire prima il **domain core**, poi gli adapter browser, quindi la UI e infine gli aspetti avanzati di dettatura e grafici. Il dataset didattico e la semantica dei sette modi devono essere trattati come contratti di compatibilità, mentre la struttura interna del nuovo software può essere completamente riprogettata.

---

## Appendice A — Checklist di equivalenza

- [ ] 71 lezioni presenti
- [ ] 996 frasi presenti
- [ ] corpus fonemico preservato
- [ ] Custom parser compatibile
- [ ] sette modalità
- [ ] navigazione lezioni
- [ ] navigazione frasi
- [ ] random
- [ ] random phrase
- [ ] weaknesses
- [ ] typing libero
- [ ] error register
- [ ] auto-correction
- [ ] Backspace guidato
- [ ] Enter
- [ ] Tab
- [ ] tastiera SVG
- [ ] mani SVG
- [ ] posizione tasti
- [ ] quattro temi
- [ ] tre modalità audio
- [ ] dettatura
- [ ] spelling
- [ ] apostrofo
- [ ] spazio
- [ ] maiuscole
- [ ] replay
- [ ] watchdog vocale
- [ ] statistiche caratteri
- [ ] storico sessioni
- [ ] grafico velocità
- [ ] filtri tipo
- [ ] filtri data/ora
- [ ] selezione campioni
- [ ] editor Custom
- [ ] import/export
- [ ] multiutente
- [ ] quota storage
- [ ] shortcut
- [ ] finestre drag/resize
- [ ] modali
- [ ] focus management

