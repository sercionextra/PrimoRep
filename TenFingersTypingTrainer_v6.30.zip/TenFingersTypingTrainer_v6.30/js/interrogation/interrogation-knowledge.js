/* TenFingersTypingTrainer v6.25 | interrogation-knowledge.js | Motore puro della conoscenza Interrogazione e calendario adattivo 1/3/7/14/30/60 giorni. */
(function (global) {
  "use strict";

  const HALF_LIFE_DAYS = 60;
  const MS_PER_DAY = 86400000;
  const REVIEW_INTERVALS_DAYS = Object.freeze([1, 3, 7, 14, 30, 60]);
  const CALENDAR_POLICY_VERSION = 1;

  const WEIGHTS = Object.freeze({
    error: 0.4,
    consultation: 0.25,
    delay: 0.2,
    consolidation: 0.15,
  });

  function computeTemporalWeight(ageDays) {
    const safeAge = Math.max(0, Number(ageDays) || 0);
    return Math.pow(0.5, safeAge / HALF_LIFE_DAYS);
  }

  function computeReliability(equivalentExposures) {
    const eq = Math.max(0, Number(equivalentExposures) || 0);
    if (eq === 0) return 0;
    return eq / (eq + 5);
  }

  function computeDelayFactor(overdueDays) {
    if (overdueDays === null || overdueDays === undefined) return null;
    const d = Number(overdueDays);
    if (isNaN(d)) return null;
    return Math.min(100, Math.max(0, (d / 30) * 100));
  }

  function computeEventMetrics(events, calculationAt) {
    const refTime = calculationAt !== undefined ? calculationAt : Date.now();
    let effectiveExposureCount = 0;
    let equivalentExposures = 0;
    let weightedErrors = 0;
    let weightedConsultations = 0;

    for (let i = 0; i < (events || []).length; i++) {
      const ev = events[i];
      if (!ev || ev.superseded) continue;
      if (ev.outcome !== "correct" && ev.outcome !== "incorrect" && ev.outcome !== "consulted") {
        continue;
      }

      const ageDays =
        ev.ageDays !== undefined
          ? Math.max(0, Number(ev.ageDays) || 0)
          : Math.max(0, (refTime - (ev.occurredAt || refTime)) / MS_PER_DAY);
      const w = computeTemporalWeight(ageDays);

      effectiveExposureCount += 1;
      equivalentExposures += w;
      if (ev.outcome === "incorrect") {
        weightedErrors += w;
      } else if (ev.outcome === "consulted") {
        weightedConsultations += 0.5 * w;
      }
    }

    const errorFactor =
      equivalentExposures > 0 ? (weightedErrors / equivalentExposures) * 100 : null;
    const consultationFactor =
      equivalentExposures > 0 ? (weightedConsultations / equivalentExposures) * 100 : null;

    return {
      effectiveExposureCount,
      equivalentExposures,
      reliability: computeReliability(equivalentExposures),
      errorFactor,
      consultationFactor,
    };
  }

  function computeCompositeWeakness(factors) {
    const f = factors || {};
    const entries = [
      { key: "error", val: f.errorFactor, w: WEIGHTS.error },
      { key: "consultation", val: f.consultationFactor, w: WEIGHTS.consultation },
      { key: "delay", val: f.delayFactor, w: WEIGHTS.delay },
      { key: "consolidation", val: f.consolidationFactor, w: WEIGHTS.consolidation },
    ];

    let availableWeight = 0;
    let weightedSum = 0;
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      if (e.val !== null && e.val !== undefined && !isNaN(Number(e.val))) {
        availableWeight += e.w;
        weightedSum += e.w * Number(e.val);
      }
    }

    if (availableWeight <= 0) return null;
    return weightedSum / availableWeight;
  }

  function correctWeaknessTowardNeutral(rawWeaknessIndex, reliability) {
    if (rawWeaknessIndex === null || rawWeaknessIndex === undefined) return null;
    const r = Math.max(0, Math.min(1, Number(reliability) || 0));
    return r * Number(rawWeaknessIndex) + (1 - r) * 50;
  }

  function classifyKnowledge(effectiveExposureCount, correctedWeaknessIndex) {
    if (!effectiveExposureCount || effectiveExposureCount <= 0) {
      return "neverVerified";
    }
    if (effectiveExposureCount < 3 || correctedWeaknessIndex === null || correctedWeaknessIndex === undefined) {
      return "insufficientData";
    }
    if (correctedWeaknessIndex >= 60) return "weak";
    if (correctedWeaknessIndex >= 35) return "review";
    return "consolidated";
  }

  function advanceReviewSchedule(currentLevel, outcome, occurredAt) {
    const level = Math.max(0, Math.min(5, Number.isInteger(currentLevel) ? currentLevel : 0));
    const ts = Number(occurredAt) || Date.now();

    if (outcome !== "correct" && outcome !== "incorrect" && outcome !== "consulted") {
      return {
        reviewLevel: level,
        reviewIntervalDays: REVIEW_INTERVALS_DAYS[level],
        nextReviewAt: null,
        changed: false,
      };
    }

    let nextLevel = level;
    if (outcome === "correct") {
      nextLevel = Math.min(5, level + 1);
    } else if (outcome === "incorrect") {
      nextLevel = 0;
    } else if (outcome === "consulted") {
      nextLevel = Math.max(0, level - 1);
    }

    const intervalDays = REVIEW_INTERVALS_DAYS[nextLevel];
    return {
      reviewLevel: nextLevel,
      reviewIntervalDays: intervalDays,
      nextReviewAt: ts + intervalDays * MS_PER_DAY,
      changed: true,
    };
  }

  function applyCorrectionsToEvents(events, corrections) {
    const corrMap = new Map();
    for (let i = 0; i < (corrections || []).length; i++) {
      const c = corrections[i];
      if (c && c.eventId) {
        corrMap.set(c.eventId, c);
      }
    }

    const effective = [];
    for (let i = 0; i < (events || []).length; i++) {
      const ev = events[i];
      if (!ev) continue;
      const corr = corrMap.get(ev.eventId);
      if (!corr) {
        effective.push(ev);
      } else if (corr.action === "void") {
        continue;
      } else if (corr.action === "replace" && corr.newOutcome) {
        effective.push(Object.assign({}, ev, { outcome: corr.newOutcome }));
      } else {
        effective.push(ev);
      }
    }
    return effective;
  }

  function projectQuestionState(questionSemanticId, events, corrections, calculationAt) {
    const refTime = calculationAt !== undefined ? calculationAt : Date.now();
    const effectiveEvents = applyCorrectionsToEvents(events, corrections)
      .filter((e) => e.questionSemanticId === questionSemanticId)
      .sort((a, b) => (a.occurredAt || 0) - (b.occurredAt || 0));

    let reviewLevel = 0;
    let nextReviewAt = null;
    let reviewIntervalDays = REVIEW_INTERVALS_DAYS[0];
    for (let i = 0; i < effectiveEvents.length; i++) {
      const ev = effectiveEvents[i];
      const sched = advanceReviewSchedule(reviewLevel, ev.outcome, ev.occurredAt || refTime);
      if (sched.changed) {
        reviewLevel = sched.reviewLevel;
        reviewIntervalDays = sched.reviewIntervalDays;
        nextReviewAt = sched.nextReviewAt;
      }
    }

    const metrics = computeEventMetrics(effectiveEvents, refTime);
    let delayFactor = null;
    if (nextReviewAt !== null) {
      const overdueDays = Math.max(0, (refTime - nextReviewAt) / MS_PER_DAY);
      delayFactor = computeDelayFactor(overdueDays);
    }

    const consolidationFactor =
      metrics.effectiveExposureCount > 0
        ? Math.max(0, Math.min(100, ((5 - reviewLevel) / 5) * 100))
        : null;

    const rawWeaknessIndex = computeCompositeWeakness({
      errorFactor: metrics.errorFactor,
      consultationFactor: metrics.consultationFactor,
      delayFactor,
      consolidationFactor,
    });

    const correctedWeaknessIndex = correctWeaknessTowardNeutral(
      rawWeaknessIndex,
      metrics.reliability,
    );

    const classification = classifyKnowledge(
      metrics.effectiveExposureCount,
      correctedWeaknessIndex,
    );

    return {
      questionSemanticId,
      effectiveExposureCount: metrics.effectiveExposureCount,
      equivalentExposures: metrics.equivalentExposures,
      reliability: metrics.reliability,
      errorFactor: metrics.errorFactor,
      consultationFactor: metrics.consultationFactor,
      delayFactor,
      consolidationFactor,
      rawWeaknessIndex,
      correctedWeaknessIndex,
      classification,
      reviewLevel,
      reviewIntervalDays,
      nextReviewAt,
      calendarPolicyVersion: CALENDAR_POLICY_VERSION,
    };
  }

  global.InterrogationKnowledge = Object.freeze({
    HALF_LIFE_DAYS,
    MS_PER_DAY,
    REVIEW_INTERVALS_DAYS,
    CALENDAR_POLICY_VERSION,
    WEIGHTS,
    computeTemporalWeight,
    computeReliability,
    computeDelayFactor,
    computeEventMetrics,
    computeCompositeWeakness,
    correctWeaknessTowardNeutral,
    classifyKnowledge,
    advanceReviewSchedule,
    applyCorrectionsToEvents,
    projectQuestionState,
  });
})(typeof window !== "undefined" ? window : globalThis);
