#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function loadScript(relPath, sandbox) {
  const code = fs.readFileSync(path.join(root, relPath), "utf8");
  vm.runInContext(code, sandbox, { filename: relPath });
}

const sandbox = vm.createContext({
  console,
  Date,
  Math,
  Set,
  Map,
  Array,
  Object,
  Number,
  String,
  Boolean,
  JSON,
  Error,
  Promise,
  Uint32Array,
  crypto: require("crypto").webcrypto,
});
sandbox.window = sandbox;
sandbox.globalThis = sandbox;

loadScript("js/data/interrogation-catalog-data.js", sandbox);
loadScript("js/interrogation/interrogation-layout-metadata.js", sandbox);
loadScript("js/interrogation/interrogation-catalog.js", sandbox);
loadScript("js/interrogation/interrogation-knowledge.js", sandbox);

const Knowledge = sandbox.InterrogationKnowledge;
const Catalog = new sandbox.InterrogationCatalog(
  sandbox.INTERROGATION_CATALOG_DATA,
  sandbox.InterrogationLayoutMetadata,
);

// 1. Verifica pesi ufficiali 40 / 25 / 20 / 15 + 25
assert.strictEqual(Knowledge.URGENCY_WEIGHTS.error, 0.4);
assert.strictEqual(Knowledge.URGENCY_WEIGHTS.consultation, 0.25);
assert.strictEqual(Knowledge.URGENCY_WEIGHTS.delay, 0.2);
assert.strictEqual(Knowledge.URGENCY_WEIGHTS.consolidation, 0.15);
assert.strictEqual(Knowledge.URGENCY_WEIGHTS.underinvestigated, 0.25);

const candidates = Catalog.getCandidates({});
const now = Date.now();

// 2. Verifica ranking a zero eventi: tutti i tasti e le 10 dita presenti con 25 pt di scarsa indagine
const emptyRanking = Knowledge.computeUrgencyRanking({
  candidates,
  events: [],
  corrections: [],
  catalog: Catalog,
  calculationAt: now,
});

assert.strictEqual(emptyRanking.maxPossibleScore, 125);
const fingerItems = emptyRanking.items.filter((i) => i.entityType === "finger");
const keyItems = emptyRanking.items.filter((i) => i.entityType === "key");
assert.strictEqual(fingerItems.length, 9, "Devono essere presenti tutte le dita interrogabili del catalogo (9)");
assert(keyItems.length >= 40, "Devono essere presenti tutti i tasti/caratteri del catalogo");
assert.strictEqual(emptyRanking.items[0].totalScore, 25);
assert.strictEqual(emptyRanking.items[0].contributions.underinvestigated, 25);
assert.strictEqual(emptyRanking.items[0].contributions.error, 0);

// 3. Verifica ordinamento con errori vs mai verificato vs consolidato
const keyACand = candidates.find((c) => c.questionType === "CARATTERE" && c.keyId === "key_a");
const keyBCand = candidates.find((c) => c.questionType === "CARATTERE" && c.keyId === "key_b");
assert(keyACand && keyBCand, "Canditati key_a e key_b devono esistere");

const events = [
  // key_a: 2 errori recenti -> urgenza alta (> 25)
  {
    eventId: "ev1",
    questionSemanticId: keyACand.questionSemanticIds[0],
    outcome: "incorrect",
    occurredAt: now - 3600 * 1000,
  },
  {
    eventId: "ev2",
    questionSemanticId: keyACand.questionSemanticIds[0],
    outcome: "incorrect",
    occurredAt: now - 1800 * 1000,
  },
];

// key_b: 12 risposte corrette -> consolidato, bassa urgenza (< 25)
for (let i = 0; i < 12; i++) {
  events.push({
    eventId: `ev_b_${i}`,
    questionSemanticId: keyBCand.questionSemanticIds[0],
    outcome: "correct",
    occurredAt: now - (12 - i) * 3600 * 1000,
  });
}

const ranked = Knowledge.computeUrgencyRanking({
  candidates,
  events,
  corrections: [],
  catalog: Catalog,
  calculationAt: now,
});

const itemA = ranked.items.find((i) => i.keyId === "key_a");
const itemB = ranked.items.find((i) => i.keyId === "key_b");
const itemNever = ranked.items.find((i) => i.effectiveExposureCount === 0);
assert(itemA.totalScore > itemNever.totalScore, "Tasto con errori deve precedere tasto mai verificato");
assert(itemNever.totalScore > itemB.totalScore, "Tasto mai verificato deve precedere tasto consolidato");
assert.strictEqual(ranked.items[0].entityId, itemA.entityId, "Il primo in classifica deve essere key_a");

// 4. Verifica esclusione motivi tramite checkbox
const noErrorRanked = Knowledge.computeUrgencyRanking({
  candidates,
  events,
  corrections: [],
  catalog: Catalog,
  activeReasons: {
    error: false,
    consultation: true,
    delay: true,
    consolidation: true,
    underinvestigated: true,
  },
  calculationAt: now,
});
const itemANoErr = noErrorRanked.items.find((i) => i.keyId === "key_a");
assert.strictEqual(itemANoErr.contributions.error, 0, "Con motivo error disattivato il contributo error deve essere 0");
assert(itemANoErr.totalScore < itemA.totalScore, "Escludendo error il punteggio totale deve diminuire");

// 5. Verifica filtro entità (Solo Tasti / Solo Dita)
const onlyFingers = Knowledge.computeUrgencyRanking({
  candidates,
  events,
  corrections: [],
  catalog: Catalog,
  entityFilter: "fingers",
  calculationAt: now,
});
assert.strictEqual(onlyFingers.items.length, 9);
assert(onlyFingers.items.every((i) => i.entityType === "finger"));

const onlyKeys = Knowledge.computeUrgencyRanking({
  candidates,
  events,
  corrections: [],
  catalog: Catalog,
  entityFilter: "keys",
  calculationAt: now,
});
assert(onlyKeys.items.every((i) => i.entityType === "key"));

// 6. Verifiche strutturali HTML, CSS e UI
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const uiJs = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

assert(html.includes('id="interrHistoryNavGroup"'), "Switcher #interrHistoryNavGroup mancante in index.html");
assert(html.includes('id="btnInterrHistNavChrono"'), "Pulsante #btnInterrHistNavChrono mancante in index.html");
assert(html.includes('id="btnInterrHistNavUrgency"'), "Pulsante #btnInterrHistNavUrgency mancante in index.html");
assert(html.includes('id="interrHistorySection1"'), "Sezione #interrHistorySection1 mancante in index.html");
assert(html.includes('id="interrHistorySection2"'), "Sezione #interrHistorySection2 mancante in index.html");
assert(html.includes('id="interrUrgencyChartHost"'), "Host grafico #interrUrgencyChartHost mancante in index.html");
assert(html.includes('id="interrUrgencyDetailBox"'), "Box dettaglio #interrUrgencyDetailBox mancante in index.html");
assert.strictEqual((html.match(/class="interr-urgency-reason-chk"/g) || []).length, 5, "Devono esserci 5 checkbox motivi");

assert(css.includes(".interr-history-section"), "Classe CSS .interr-history-section mancante");
assert(css.includes(".interr-urgency-chart-host"), "Classe CSS .interr-urgency-chart-host mancante");

assert(uiJs.includes("function createSvgEl("), "Helper createSvgEl mancante in interrogation-ui.js");
assert(uiJs.includes("repo.getExposureEvents(profileId)"), "Chiamata a repo.getExposureEvents mancante in _loadUrgencyData");
assert(uiJs.includes("_scrollToHistorySection("), "Metodo _scrollToHistorySection mancante in interrogation-ui.js");
assert(uiJs.includes("_renderUrgencyChart("), "Metodo _renderUrgencyChart mancante in interrogation-ui.js");
assert(uiJs.includes("_promptStartUrgencySession("), "Metodo _promptStartUrgencySession mancante in interrogation-ui.js");

// 7. Regressione v6.42: eventi recordBlockEvaluation (${candidateId}.${blockId}) su key_d
const keyDCands = candidates.filter((c) => (c.questionType === "CARATTERE" || c.questionType === "TASTO") && c.keyId === "key_d");
assert(keyDCands.length >= 3, "Devono esistere almeno 3 candidati per key_d");
const blockEvents = [];
keyDCands.forEach((cand, idx) => {
  ["accord", "chars", "neighbors"].forEach((blk, bIdx) => {
    blockEvents.push({
      eventId: `evt_blk_d_${idx}_${bIdx}`,
      questionSemanticId: `${cand.candidateId}.${blk}`,
      outcome: "correct",
      occurredAt: now - 1000,
    });
  });
});
const rankedD = Knowledge.computeUrgencyRanking({
  candidates,
  events: blockEvents,
  corrections: [],
  catalog: Catalog,
  calculationAt: now,
});
const itemD = rankedD.items.find((i) => i.keyId === "key_d");
assert.strictEqual(itemD.effectiveExposureCount, 9, "Tutti i 9 eventi a blocchi di key_d devono essere conteggiati");
assert(itemD.contributions.underinvestigated < 25, "Scarsa indagine di key_d deve scendere sotto 25 dopo risposte corrette");
assert(itemD.totalScore < 25, "Il punteggio totale di key_d dopo 9 blocchi corretti deve scendere sotto i tasti mai verificati (25)");

console.log("PASS: Tutte le verifiche v6.40/v6.42 superate.");
