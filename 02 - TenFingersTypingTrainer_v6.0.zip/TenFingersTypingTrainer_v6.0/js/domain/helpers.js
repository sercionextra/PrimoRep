/* TenFingersTypingTrainer v6.0 — Helpers di dominio e parser Custom; contenuto estratto senza cambiare le regole del dominio. */
// =======================================================
// File: /workspace/main_A_(v6.0).js
// Versione: 5.1
// Data rilascio: 26/10/2026
// Note di rilascio v6.0:
//   1. DETTATURA VOCALE INTERATTIVA: implementazione di notifyError() (pronuncia istantanea di "errore") e notifyErrorCorrection() (guida scalare con Backspace "ancora N errori" e completamento immediato a zero errori).
//   2. Allineamento globale della versione e dei riferimenti a Release v6.0.
// =======================================================

// Helper canonico: restituisce data e ora locale italiana di sistema (YYYY-MM-DDTHH:mm:ss)
function getLocalISODateTime(d = new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  const year = d.getFullYear();
  const month = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  const hours = pad(d.getHours());
  const minutes = pad(d.getMinutes());
  const seconds = pad(d.getSeconds());
  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}

// =========================================================================
// PUNTO DI INSERIMENTO: normalizeItalianAccents(text)
// =========================================================================
// Helper canonico: normalizza tutte le vocali maiuscole accentate in vocale maiuscola + apostrofo (Release v.4.9)
function normalizeItalianAccents(text) {
  if (!text || typeof text !== "string") return "";
  return text
    .replace(/È/g, "E'")
    .replace(/É/g, "E'")
    .replace(/À/g, "A'")
    .replace(/Ò/g, "O'")
    .replace(/Ù/g, "U'")
    .replace(/Ì/g, "I'");
}
window.normalizeItalianAccents = normalizeItalianAccents;

// PARSER ESERCIZI PERSONALIZZATI (Formato C# ===== Titolo ===== con Invio e Tab)
function parseCustomExercises(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/);
  const lessons = [];
  let curLesson = null;
  let curLines = [];

  const flushPhrase = () => {
    if (!curLesson) return;
    if (curLines.length > 0) {
      // Unione delle righe fisiche con spazio separatore (ignorando il normale ritorno a capo).
      // Solo il token "®" genera un effettivo Invio da digitare.
      let phraseText = "";
      for (let i = 0; i < curLines.length; i++) {
        const seg = curLines[i];
        if (!seg) continue;
        if (phraseText.length === 0) {
          phraseText = seg;
        } else if (phraseText.endsWith(" ") || phraseText.endsWith("®")) {
          phraseText += seg;
        } else {
          phraseText += " " + seg;
        }
      }
      if (phraseText.trim().length > 0) {
        curLesson.phrases.push(phraseText);
      }
      curLines = [];
    }
  };

  for (let line of lines) {
    line = line.trimEnd();
    const titleMatch = line.match(/^=====(.*?)=====$/);
    if (titleMatch) {
      flushPhrase();
      const title = titleMatch[1].trim();
      curLesson = { name: title || "Esercizio Custom", phrases: [] };
      lessons.push(curLesson);
    } else if (line === "=====") {
      flushPhrase();
    } else if (curLesson) {
      // Conversione automatica di 4 spazi o tabulazioni fisiche nel token canonico "→"
      let proc = line.replace(/\t/g, "→").replace(/    /g, "→");
      curLines.push(proc);
    }
  }
  flushPhrase();
  return lessons.filter((l) => l.phrases.length > 0);
}

function htmlEscape(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Embedded Datasets (Invariati e preservati al 100%)
