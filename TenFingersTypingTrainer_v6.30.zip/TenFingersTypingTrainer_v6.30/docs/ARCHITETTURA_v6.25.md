# Architettura Applicativa — TenFingersTypingTrainer v6.25

**Versione:** 6.25
**Baseline precedente:** v6.24
**Stack:** JavaScript classico (`defer`), HTML5, CSS3, LocalStorage (`ProfileManager`), IndexedDB (`InterrogationRepository`), Web Speech API (`DictationEngine`). Zero dipendenze esterne.

## 1. Novità architetturali della v6.25

### 1.1 Consenso per profilo per le voci di sintesi vocale (TTS)
- La CSP restrittiva (`connect-src 'none'`, nessuna deroga `unsafe-inline`/`unsafe-eval`) e `js/security/network-isolation-guard.js` rimangono attivi per impedire al codice JavaScript applicativo qualsiasi richiesta di rete diretta (`fetch`, `XMLHttpRequest`, `WebSocket`, `sendBeacon`, ecc.).
- `ProfileManager` persiste il campo `AllowRemoteTtsVoices` (valore predefinito `true`) per ciascun profilo utente.
- `DictationEngine` legge `allowRemoteTtsVoices`:
  - Quando `true`: applica lo scoring pesato cross-platform della v6.23 (`scoreVoice`), selezionando le migliori voci italiane disponibili (incluse voci neurali/online del browser/OS) e mantenendo `fallbackLocalVoice` (`localService === true`) come riserva locale.
  - Quando `false`: applica il filtro rigoroso della v6.24 (`localService === true`), escludendo qualsiasi voce remota o priva di garanzia locale esplicita.

### 1.2 Sottosistema INTERROGAZIONE sul layout della tastiera italiana
Implementato in moduli JavaScript classici isolati e caricati con `defer` prima del bootstrap:

1. `js/data/interrogation-catalog-data.js`: dataset statico locale (senza `fetch`) generato da `Catalogo_QWERTY_Italiano_seed_v1.0.json`, `Catalogo_Domande_Interrogazione_v1.0.json` e `Candidati_Interrogazione_v1.1.json` (52 tasti fisici verificati, 111 mapping carattere, 445 definizioni attive, 5 template, 225 candidate).
2. `js/interrogation/interrogation-prng.js`: generatore deterministico `xoshiro128**` v1.0 con seed `hex-128be`, rejection sampling senza bias da modulo, ordinamento canonico `utf16-code-unit-v1`, Fisher-Yates discendente e fingerprint SHA-256 del pool.
3. `js/interrogation/interrogation-catalog.js`: validazione e indicizzazione del catalogo parziale approvato.
4. `js/interrogation/interrogation-knowledge.js`: proiezione eventi e correzioni append-only, decadimento esponenziale (emivita 60 giorni), affidabilità prudenziale, indice di debolezza composito con rinormalizzazione dei pesi disponibili, classificazione (`neverVerified`, `weak`, `review`, `consolidated`, `insufficientData`) e **calendario adattivo confermato 1 / 3 / 7 / 14 / 30 / 60 giorni** (livelli da 0 a 5).
5. `js/interrogation/interrogation-selector.js`: selezione `random`, `adaptive` (quote adattive D77-D80 Alternativa B: budget globale 10 punti percentuali, tetto individuale 20% della quota base normalizzata, redistribuzione iterativa, quota neutra, allocazione intera ai maggiori resti) e `manual`.
6. `js/interrogation/interrogation-repository.js`: persistenza IndexedDB conforme allo schema v1.3 (14 object store, indici esatti, vincolo `oneSuspendedPerProfile`, idempotenza tramite `operationReceipts`), con backend in-memory opzionale per i test Node.
7. `js/interrogation/interrogation-session-manager.js`: orchestrazione ciclo di vita sessioni (`in-progress`, `suspended`, `abandoned`, `completed`), valutazione sotto-quesiti (`correct` = 3 pt, `consulted` = 1 pt, `incorrect` = 0 pt, `unanswered` = 0 pt senza evento).
8. `js/ui/interrogation-ui.js` e `js/app/controller/metodi-interrogazione.js`: vista modale dedicata attivabile dal pulsante `🎓 Interrogazione` nella toolbar (Opzione A, completamente isolata dal flusso di digitazione).
