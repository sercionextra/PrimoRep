# Manuale Utente TenFingersTypingTrainer v6.57

Questa guida integra il manuale della versione 6.56 con gli aggiornamenti introdotti nella versione 6.57.

## 1. Contrasto visivo dei riquadri a riposo nei temi scuri
- **Temi Dark e Matrix:** i due riquadri arrotondati che evidenziano le posizioni a riposo sulla Tastiera Virtuale (`a, s, d, f` e `j, k, l, ò`) vengono ora mostrati con un bordo chiaro ad alto contrasto nei temi **Dark** e **Matrix**, così da risultare subito distinguibili dallo sfondo e dai colori delle singole dita.
