# Architettura — TenFingersTypingTrainer v6.24

## Obiettivo della release

La v6.24 introduce il primo livello di isolamento tecnico offline senza modificare il metodo didattico o i flussi di digitazione già esistenti.

## Sicurezza e riservatezza

- La Content Security Policy è dichiarata nei documenti HTML locali e non contiene `unsafe-inline` né `unsafe-eval`.
- `default-src` è negata; script e fogli di stile sono ammessi soltanto dalla stessa origine locale.
- `connect-src 'none'` impedisce l'uso delle primitive di connessione governate dalla CSP.
- Le direttive per immagini, font, media, frame, worker, oggetti, manifest e moduli sono limitate al minimo necessario.
- Tutti gli attributi `style` e gli script inline sono stati trasferiti in file locali o regole CSS associate a ID stabili, così da applicare `style-src-attr 'none'` e `script-src-attr 'none'`.
- `js/security/network-isolation-guard.js`, caricato prima del codice applicativo, blocca le API di rete, i canali di comunicazione tra contesti, le richieste di accesso a dispositivi non necessarie e le navigazioni esterne via anchor/window.open. L'unica apertura di finestra ammessa è la guida locale `help.html`.
- I frammenti HTML/SVG creati dinamicamente non usano attributi `style`; i nomi profilo e i titoli degli esercizi vengono inseriti nel DOM come testo, evitando interpretazione HTML dei dati utente.
- Un listener registra le violazioni CSP e le invocazioni bloccate senza registrare contenuti digitati o dati dei profili.
- La sintesi vocale seleziona esclusivamente voci italiane con `localService === true`. In assenza di una voce locale, non viene utilizzata la voce predefinita del browser.

## Limiti del modello di distribuzione

La CSP inserita tramite meta tag protegge il documento e le risorse subordinate, ma non sostituisce un firewall del sistema operativo e non governa il traffico generato dal browser, dalle estensioni o da altri processi. La direttiva `frame-ancestors` richiede un header HTTP e non è applicabile tramite meta CSP. L'applicazione resta una cartella statica locale e non introduce un server applicativo.

## Compatibilità

- Nessuna dipendenza esterna, libreria, CDN o pacchetto aggiunto.
- JavaScript classico con script locali `defer` e ordine di caricamento esplicito.
- Profili e preferenze preesistenti continuano a usare LocalStorage.
- Nessuna migrazione o cancellazione dei dati della v6.23.
- Il dominio Interrogazione non è ancora incluso in questa release di hardening: verrà integrato nella successiva release dopo la chiusura dei gate di catalogo, conoscenza, selezione, sessione e persistenza.

## Verifiche

La release include controlli statici anti-risorse remote, test runtime del guard di isolamento e test dedicati alla selezione delle sole voci locali. Le suite Node della baseline devono restare verdi. Il collaudo visuale e di rete nei browser supportati rimane un gate manuale obbligatorio prima della distribuzione.
