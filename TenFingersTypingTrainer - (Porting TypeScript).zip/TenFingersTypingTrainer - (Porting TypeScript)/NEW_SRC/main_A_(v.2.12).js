// main_A_(v.2.12).js

// PARSER ESERCIZI PERSONALIZZATI (Formato C# ===== Titolo ===== con Invio e Tab)
function parseCustomExercises(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/);
  const lessons = [];
  let curLesson = null;
  let curLines = [];

  const flushPhrase = () => {
    if (!curLesson) return;
    if (curLines.length > 0) {
      const phraseText = curLines.join('®');
      if (phraseText.trim().length > 0) {
        curLesson.phrases.push(phraseText);
      }
      curLines = [];
    }
  };

  for (let line of lines) {
    line = line.trimEnd();
    const titleMatch = line.match(/^=====(.*?)=====$/);
    if (titleMatch) {
      flushPhrase();
      const title = titleMatch[1].trim();
      curLesson = { name: title || "Esercizio Custom", phrases: [] };
      lessons.push(curLesson);
    } else if (line === "=====") {
      flushPhrase();
    } else if (curLesson) {
      let proc = line.replace(/\t/g, '→').replace(/    /g, '→');
      curLines.push(proc);
    }
  }
  flushPhrase();
  return lessons.filter(l => l.phrases.length > 0);
}

function htmlEscape(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

    // Embedded Datasets
    const EMBEDDED_LESSONS = [{"name": "asdfl", "phrases": ["sala falsa", "dalla sala", "falsa falla", "salda la falla", "la falla salda", "fa la sala", "la fa dalla sala", "la salsa falsa", "fa la salsa", "la salsa salda", "falla salda la salsa", "la falda salsa", "sala da salsa", "salda salda", "sa da salsa", "falla la salsa", "sala la salsa", "ala salda", "afa falsa", "falsa afa", "fa la falsa"]}, {"name": "g", "phrases": ["ala a galla", "afa a galla", "fa la glassa", "allaga la sala", "la daga a galla", "la daga falsa", "falsa la glassa", "la glassa falsa", "a galla", "salga la falda", "falla la daga", "salga a galla", "la falsa daga", "falla la glassa", "la falsa falla", "salsa alla glassa", "alla sala falsa", "alga a galla", "alga salga a galla", "alga salga la falda", "alga allaga la sala", "falsa alga", "falsa saga", "la saga glassa", "la saga fa la glassa"]}, {"name": "h", "phrases": ["ha la salsa", "ah la glassa", "ha la daga", "ha la falla", "ha la daga falsa", "ha la sala"]}, {"name": "i", "phrases": ["i dadi lisi", "fili di giada", "salsa gialla", "figlia saggia", "falsi saggi", "dadi di ghisa", "fila di gigli gialli", "fila di laghi", "la giada falsa", "i fidi asili", "i gigli gialli", "fila di ghiaia", "ha dadi fissi", "i fili fissi", "i falsi affissi", "falsi figli", "falsi assilli", "figli di faggi", "figli di ghisa", "gli dissi", "i fili gialli", "ghiaia gialla", "faggi di laghi", "la dalia gialla", "hai falsi fili di giada"]}, {"name": "o", "phrases": ["soldi falsi", "la glassa fa gola", "loda la folla", "filo di olio", "falso saggio", "foglia di faggio", "dado di ghisa", "odio il giglio", "salgo da solo", "odia i fagioli", "loda la folla", "la sfoglia fa gola", "il figlio fa gola", "il figlio soffia", "odio i dadi", "oggi ha lodato", "saggia follia", "assaggia i fagioli", "ha solo lodi", "aglio o olio", "i soldi gialli", "soldi falsi", "lodi di figlia", "il figlio sloggia", "il foglio giallo", "la foglia di faggio", "filo giallo", "salsa di olio", "oggi ha solo fagioli"]}, {"name": "e", "phrases": ["le foglie dei faggi", "sedie di faggio", "la sedia di ghisa", "le figlie fedeli", "le sedie delle figlie", "egli ha fede", "leghe di ghisa", "le sedi delle leghe", "idea fedele", "seggio fisso", "le folli daghe", "egli fa follie", "giogo folle", "ha delle false lodi", "le foglie folli", "il sole e la foglia", "ella si siede", "se si sedesse", "egli fa fallo", "sei sedie gialle", "le foglie al gelo", "aghi e fili", "file di foglie", "offesa dalle figlie", "laghi al gelo", "egli ha sei figlie", "le foglie gialle"]}, {"name": "p", "phrases": ["palla di ghisa", "olio e seppie", "pelle di pollo", "il pollo passa", "gli passo la palla", "si posa la foglia", "seppie e pollo", "i passi folli", "olio a galla", "le spalle della sposa", "la palla galleggia", "la sedia di paglia", "il piede del figlio", "la sposa fedele", "egli ha la pialla", "egli ha la pila", "il poggiolo fisso", "il figlio pallido", "giallo pallido", "la palla gialla", "pila di fogli", "polpa di pollo", "la foglia di pioppo", "pioppi e faggi", "doppio fallo", "osso di seppia", "salsa di pollo", "la pillola gialla"]}, {"name": "r", "phrases": ["olio e lardo per friggere", "perdere la palla per il fallo", "le farfalle sopra i gigli", "fiori gialli tra le rose", "saper perdere la gara", "il paggio del re", "era il regalo del re", "orrore per il freddo", "freddo e gelo alla sera", "il grosso pioppo", "era pallido e fragile", "dire delle frasi assai serie", "sorridere ai fiori", "sei di fiori", "le farfalle gialle", "presi dal desiderio", "farsi pregare", "perdere a dadi", "fare dei progressi", "progredire e salire", "il golf grigio perla", "freddo polare", "pregare di sera", "preferire fiori rari", "sedie di pregio", "sopra le pere", "aria fresca", "ferro e ghisa"]}, {"name": "t", "phrases": ["troppi grappoli nel piatto", "le proteste dei tifosi", "le trote del lago", "la grotta dei pipistrelli", "trippe e fagioli", "lo sparo della pistola", "egli le apre la porta", "il pregio del posto", "la serata era gelida", "fare delle ripide salite", "petrolio greggio", "trasportare dei grossi sassi", "il fragile trasporto", "ripido tratto di salita", "tradire per i soldi", "essere triste e poi lieto", "in attesa della paga", "la talpa sta sotto terra", "essere di fretta", "la trappola per i topi", "il tetto di paglia", "il posto di ristoro", "il gelato alla fragola", "la torta alle fragole", "lo stato estero", "era la stessa storia", "errore di tiro", "il test era errato", "fuggire di sera", "il passato e il futuro", "il gusto di leggere", "autore del furto", "la lunga giostra", "il fusto del pioppo", "la foglia sulla strada"]}, {"name": "u", "phrases": ["auto proprio lurida", "sei fedeli segugi", "luogo di preghiera", "era proprio tutta sudata", "era ladro e truffatore", "opera di autore russo", "perdere tutto ai dadi", "i trulli pugliesi", "sul fiore o sulla foglia", "il tratto superiore", "freddo da lupi", "odio e furore", "arresto per truffa", "profugo dalla russia", "gruppo di pugili", "il luogo dei giusti", "resti di frustate alle spalle", "luoghi luridi e fetidi", "il prete e la suora", "le spalle sussultavano dal ridere", "il gufo sopra il tetto", "pare che legga il futuro"]}, {"name": "n", "phrases": ["tanti panni stesi", "un pugnale affilato", "funghi saporiti", "lunghe file alle poste", "il ponte non regge", "polenta e funghi", "un lungo ponte", "lontano dalla gente", "una nonna proprio generosa", "una figlia gentile", "una gustosa frittella", "dare in prestito", "un piede ingessato", "un testo assai interessante", "una idea geniale", "un ingenuo figliolo", "un trucco infantile", "prendere tutto sul serio", "un pasto frugale", "una pioggia assai fastidiosa", "non aspettare in piedi", "pantaloni tutti infangati", "una alunna interessata", "lei non sta attenta", "un passerotto infreddolito", "insoddisfatto del suo postino", "non sentire niente"]}, {"name": "c", "phrases": ["uno spettatore incredulo", "giocare tutti a calcio", "una ciocca di capelli", "accendere un cero in chiesa", "non le piace accendere il fuoco", "leccare con gusto il gelato", "una coppa di gelato al cacao", "cocciuto e ostinato", "chi prima rideva adesso piange", "un chiodo arrugginito", "un pericoloso incidente stradale", "far cessare ogni eccesso", "un sincero confidente", "tu non sai cosa mi ha detto", "ci piacciono le coscie di pollo", "un frastuono incessante", "il cappotto era fradicio per la pioggia", "un esercito di galline", "pulisciti le orecchie", "farsi una doccia calda", "stare con le orecchie tese", "non nasconderti con la maschera", "chiedi le chiavi di casa", "chi ha un cruccio si sfoga", "andare a caccia di cinghiali", "il cagnolino sta nella cuccia", "sta a casa con gli orecchioni", "dei sacchi di ceci"]}, {"name": "m", "phrases": ["una macchia di inchiostro", "mi manda la mamma", "un mostro immondo", "ama molto la mamma", "immagina che giunga un mago", "una camera da letto molto ampia", "meglio imparare la matematica", "se hai male chiama il medico", "non mi piace la medicina amara", "se ha miagolato non era una mucca", "se ha muggito non era un gatto", "di studiare non le importa molto", "amo molto la montagna", "un campo di mais e uno di frumento", "stare immersa nel mare", "scimmie ammaestrate al circo", "la scimitarra del sultano", "impara a suonare il mandolino", "era partita con molti rimpianti", "occorre mettere ancora molto sale", "immagina di stare meglio", "molto rumore per nulla", "mille moscerini sulla macchina", "mangia maccheroni al sugo", "una matita affilatissima", "la maschera di ferro", "mai dire mai", "mi tocca mangiare la minestra"]}, {"name": "z", "phrases": ["porta fuori le immondizie", "mi piace molto la pizza", "gioca con pazienza e furbizia", "in piazza ci sono molte persone", "un fazzoletto con il pizzo", "dei mercanti in cerca di spezie", "era mezzo morto di paura", "non era una piazza molto spaziosa", "dei pezzi di pesce molto puzzolenti", "gli si rizzavano i capelli in testa", "spezzava i rami con ogni mezzo", "un tizzone acceso nel caminetto", "era molto amato dalle zie", "meglio la prudenza che la pazzia", "si sente una puzza pazzesca", "la tazza si ruppe in mille pezzi", "si azzuffano in mezzo alla piazza", "il mercato si fa in piazza", "la mazza da golf di mio zio", "andiamo pazzi per la pizza", "una stanza spaziosa", "un mazzo di azalee", "una pizza non mi sazia", "con un colpo di mazza si spezza", "attenti al precipizio", "non sempre il giusto sta nel mezzo"]}, {"name": "q", "phrases": ["in questa scuola si studia molto", "acqua inquinata in molti fiumi", "un giocatore squalificato", "non era questo il quaderno da portare", "salire le scale quatto quatto", "erano quattro o cinque amici", "era proprio una questione da chiarire", "mi piacciono tutti i quiz", "ricopiare tutto tale e quale", "un quintale di queste mele", "chiede solo acqua minerale frizzante", "esco dopo questo acquazzone", "una questione di interesse", "si era quasi addormentata", "un gesto inqualificabile", "tutto era quieto e silenzioso", "uscire per fare acquisti", "quindici persone qualsiasi", "il quattordici di luglio", "quarantaquattro gatti", "quando saremo in quattro", "un posto proprio tranquillo", "quattro quaderni a quadri", "una questione di quiz", "quasi quasi mangio qui", "preferisco questa acqua", "costa millecinquecento lire", "quasi un quintale di questi quaderni"]}, {"name": "v", "phrases": ["un veloce avvio di gara", "con la violenza si fa poca giustizia", "la tigre zoppica ma va a zonzo lo stesso", "mi serve un pezzo di legno", "sperava molto di vincere", "gli avvoltoi volano molto in alto", "pensava spesso ai suoi vecchi amici", "stava sempre vicina al tavolo", "mettiti davanti al tavolino", "non avvicinarti troppo al vetro", "raccontava delle storie avvincenti", "viveva da sola in una vecchia casa", "sapeva inventare storie stupende", "aveva un cagnolino vivacissimo", "sperava di vincere alla lotteria", "era avvilita per non aver vinto nulla", "nevicava da vari giorni", "la vasca del parco era sempre vuota", "un velivolo velocissimo", "una voce cavernosa", "rividi volentieri quel villaggio", "devi diventare veloce nelle divisioni", "sul prato verde fiorivano le viole", "un avvenimento davvero unico", "non avvicinarti al vulcano", "invece di viola lo vorrei verde", "vendere vestiti vecchi", "un vasetto vuoto", "voleva vincere almeno una volta", "cadeva spesso dal tavolo"]}, {"name": "b", "phrases": ["devi sviluppare bene questa vicenda", "bevi questa buona bibita", "era una brutta avventura", "basta stare attenti alle buche", "un bravo burattino", "la bilancia era sbilenca", "non buttare via i barattoli", "ha imbucato il biglietto di auguri", "era molto abile con le biglie", "devi sbucciare bene la banana", "non mi piace il brodo bollente", "deve andare ad abitare lontano", "la baracca era tutta bruciata", "attento alla buca vicino al burrone", "bere una bella tazza di latte", "ottimi i biscotti con il burro", "un breve giro nel bosco", "un barattolo di colore blu", "sembra una bella idea cambiare aula", "un dolce di ribes e albicocche", "non disturbare il babbo", "ai bufali piace brucare erba fresca", "un brutto scambio", "era un imbianchino molto bravo", "brontolava e borbottava sempre", "un albero di albicocche", "non mi faccio imbrogliare", "era arrabbiata per quel brutto voto", "bianco rosso e blu"]}, {"name": "ò", "phrases": ["andò via di corsa", "non si può continuare a discutere", "saltò dal treno in corsa", "arrivò primo assoluto", "frenò in ritardo", "non si può correre", "togliti pure il paltò", "accese un bel falò", "si salvi chi può", "si fermò e si girò", "andò a piedi fino a scuola", "tre civette sul comò", "gli tirò un sasso addosso", "un albero crollò di colpo", "il ramo si spezzò", "non si può continuare", "quanto prima finirò", "il campione saltò e vinse", "solo un giorno lo sopportò", "la barca salpò ma non tornò", "dopo il naufragio non navigò per due anni", "saltò al volo dal bus", "la nave aveva cento oblò", "non parlò con nessuno", "salirò fino al terzo piano", "non si può accendere qui un falò", "arrivò un poliziotto e lo arrestò"]}, {"name": "à", "phrases": ["chissà quando arriverà", "correva di qua e di là", "se frena si fermerà", "cercò sempre la libertà", "pietà per i vinti", "chi vivrà vedrà", "suonerà tutta la notte", "la felicità prima di tutto", "non disprezzò mai la povertà", "la libertà non si vende mai", "andrà in cerca della felicità", "se non ti muovi nessuno ti aiuterà", "se vai là nessuno ti troverà", "non mi dà mai retta", "riderà bene chi riderà ultimo", "entrò nella cavità del tronco", "quando lo saprà si pentirà", "una enorme quantità di terra", "aiutatemi per pietà", "arriverà in fine la felicità", "una penna di prima qualità", "questo letto ha poca elasticità", "non vincerà mai la sua golosità", "chi andrà di qua chi di là", "alla fine un eroe li salverà", "hai già avuto due possibilità", "era appeso alle estremità", "una macchina di grande utilità"]}, {"name": "ù", "phrases": ["non ne posso più", "lassù fa più freddo", "le vere virtù si notano poco", "più saliva e più aveva paura", "cadde a testa in giù", "chi più ne ha più ne metta", "erano andati tutti laggiù", "la virtù della carità", "lodò le vere virtù", "una poltrona di bambù", "non abita più qui", "saltò più in alto di te", "facciamo una corsa fino a laggiù", "una servitù pesante", "errori di gioventù", "pescava con una canna di bambù", "persona di grandi virtù", "più di qua che di là", "il menù del ristorante", "diritto di servitù", "quassù non si vede nulla", "viaggiare in treno mi piace di più", "non credo che mentire sia una virtù", "la gioventù non torna più", "vai giù e prendimi una bottiglia", "mi piace la musica indù", "per fortuna la schiavitù non esiste più", "stando giù si sentiva qualcosa di più"]}, {"name": "èé", "phrases": ["è veramente adatto a te", "è un buon caffè", "erano ventitrè amici", "non dirmi ma o cioè", "trentatrè trentini", "perché faceva tutto da sè?", "chi fa da sè fa per tre", "non è bello stare a testa in giù", "è andato tutto bene", "si è fermato subito", "benché lo sapesse, non lo aiutò mai", "questo libro non è per te", "chi è stanco si fermi", "ahimè che disgrazia", "mi piacciono i bignè", "olè olè gridavano al torero", "preparava un panino con il pan carrè", "ci vediamo alle ore ventitrè in punto", "è ora di andare in casa", "beviamo un buon caffè", "è nato nel novantatrè", "è meglio finire qui", "parlava tra sé e sé", "il treno non è in orario", "una torta di bignè", "è ora della pausa per il caffè", "gli piace fare tutto da sé", "non è il momento di dire sciocchezze", "è un caffè speciale"]}, {"name": "ì", "phrases": ["partì di corsa", "salì le scale", "non finì mai il dipinto", "lavorava notte e dì", "egli diceva sempre sì", "non stare lì impalato", "ci vediamo domani a mezzodì", "vieni via di lì", "la maestra punì tre scolari", "non era lì che dovevi andare", "salì in casa a mezzodì", "non riuscì a finire per mezzodì", "non si sa come finì la partita", "ottima la lepre in salmì", "se spingi ancora non si sposta da lì", "il volo del colibrì", "dopo il lunedì viene il martedì", "finì alle nove o giù di lì", "stai attento se passi di lì", "finì tutto in due minuti", "sta fermo così per qualche minuto", "arrivò giovedì a mezzodì", "di sicuro non riuscì a farlo così", "salì sulla torre e da lì lo vide partire", "partì giovedì con la nave", "corri a vedere cosa fanno quelli lì", "aspettò lì da solo tutto il dì", "rispondimi sì o no"]}, {"name": ",", "phrases": ["la condì con olio, aceto e sale", "non si può perdere, bisogna vincere", "era, sembra, un vero artista", "sentiva, di sera, i grilli cantare", "chi rompe, dice il proverbio, paga", "era, a detta di molti, un vero affare", "sono partiti tutti, anche gli ammalati", "se piove, purtroppo, si bagna tutto", "non è vero, sono tutte bugie", "vai piano, la strada è scivolosa", "se perdi, non arrabbiarti", "fiorirono rose, gigli e garofani", "studio italiano, matematica e storia", "la notte, dicono, porta consiglio", "mi piace, in particolare, il suono del violini", "io preferisco venerdì, sabato e domenica", "a scuola, lo sai, si viene per imparare", "è bello, quando piove, starsene in casa", "tuoni, lampi, fulmini e saette", "coraggio, mi dissi, devo farcela", "a colazione mangio latte, biscotti e miele"]}, {"name": ".", "phrases": ["salta sul carro.", "attenti al lupo.", "la forza delle braccia.", "non si può sempre correre.", "attenti alle curve.", "la frutta fa bene.", "spegni la televisione.", "suona bene il piano.", "era contento della sua maestra.", "un bel prato pieno di fiori.", "quando piove si sta bene in casa.", "non posso più uscire di sera.", "mi piace sentire la musica.", "è finito il temporale.", "quel treno è sempre in ritardo.", "vorrei invitare tutti per il mio compleanno."]}, {"name": "'", "phrases": ["c'erano mele, pere, mandarini e pesche", "suona bene l'armonica", "l'albergo era tutto esaurito", "era un'estate caldissima", "l'incontro è andato bene", "sorpassò l'avversario ed arrivò primo", "l'aspetto era ottimo", "l'ospite è ben gradito", "versare l'olio e l'aceto", "è un'incredibile avventura", "era l'unica a stare attenta", "è l'ideale dei giovani d'oggi", "non c'è spazio per l'inganno", "c'era molta fiducia in lui.", "la figlia l'amava moltissimo.", "aveva un po' di fame.", "ce l'aveva un po' con lei.", "c'è dell'aranciata o dell'acqua fresca"]}, {"name": "ShiftDestro", "phrases": ["Devi fare gli auguri a Sandra.", "Arriveremo presto a Roma.", "Aiuta Elena a fare i compiti.", "Questo treno non va a Como.", "A Roma c'è il Vaticano.", "Era il famoso colpo di Zorro.", "Giulio Cesare sconfìsse i Galli.", "Vicenza è una città del Veneto.", "Tutte le strade portano a Roma.", "Firenze si trova in Toscana.", "Giuseppe Verdi era un musicista.", "Franco abita a Enna, in Sicilia.", "La Francia è uno dei più grandi stati d'Europa.", "Giorgio, Ernesto, Simone e Andrea verranno qui a dormire."]}, {"name": "ShiftSinistro", "phrases": ["Il Milione di Marco Polo.", "Un bel viaggio in India.", "Lascia entrare prima Paola.", "Livorno è vicina a Pisa.", "Tra Verona e Padova c'è Vicenza.", "Un amico di Luigi.", "Grosso incidente a Milano.", "Un nuovo palazzo a Napoli.", "Oggi è il compleanno di Laura.", "Freddo polare in Norvegia.", "L'autostrada è interrotta a Udine.", "La pietà di Michelangelo.", "La capitale della Francia è Parigi.", "Un lungo viaggio in Libia e in Marocco"]}, {"name": "Invio", "phrases": ["Troppa gente in questa festa.", "Il giardino, lo sai, è ben curato.", "Non è venuto a sentire il concerto.", "Spesso chi si lamenta sta bene.", "Chiudi la finestra, ho freddo.", "Oggi è una bella giornata di sole.", "Non amo l'inverno, voglio il sole.", "Oggi ho mangiato un buon pollo.", "Domenica andremo a trovare i nonni.", "Spero arrivi presto Natale.", "Mi piace scrivere con il computer.", "Alla mattina ho sempre molto sonno.", "La sera non voglio andare a letto.", "Suona il campanello, vai ad aprire."]}, {"name": "7", "phrases": ["Il 7 aprile vengo a trovarti.", "Alla corsa partecipano 77 concorrenti.", "Qualcuno considera il 7 un numero perfetto.", "Rivera giocava con la maglia numero 7.", "Alle superiori 7 era un bel voto.", "Con sole 7 note si possono fare tante musiche.", "Alla mattina mi alzo alle 7 per andare a scuola.", "Prende il treno delle 7 e un quarto.", "Per gli antichi 7 volte 7 era un'enormità.", "Abita a 7 chilometri di distanza.", "Una frittata con 7 uova.", "Un numero di telefono facile da ricordare è 777777.", "Roma è costruita su 7 colli.", "Alle 7 di sera ormai è già buio."]}, {"name": "8", "phrases": ["Dopo il 7 viene il numero 8.", "La tavola era preparata per 8 invitati.", "Abito in via Roma al numero 88.", "Alle 8 il traffico è terribile.", "Sembra piccolissimo ma ha 8 anni.", "Non so quanto valgano questi 8 dollari.", "Questa canzone dura 8 minuti.", "Un libro di 78 pagine.", "Sono le 7 e 8 minuti.", "Mio papà è alto un metro e 87 centimetri.", "Io dico che non può tenere in casa 8 gatti.", "Alla fine della corsa sono arrivati solo in 8.", "Devo prendere l'autobus numero 88.", "Ha preso 8 in storia e 7 in scienze."]}, {"name": "9", "phrases": ["Dopo il numero 8 c'è il 9.", "Ripeti il numero 789.", "Da 9 anni non facevamo una festa così.", "Domani è il 9 ottobre.", "Un palazzo di 9 piani.", "Domani alle 9 ti vengo a trovare.", "Il numero 89 è maggiore di 79.", "Ma 999999 non è un milione.", "Se siamo solo in 9 non si gioca a calcio.", "Un cesto con 9 mele.", "Un pranzo con 9 portate.", "Ricordati di telefonare al 799989", "Dicono che un cane di 9 anni sia molto vecchio.", "Ho 9 cugini e 8 zii."]}, {"name": "0", "phrases": ["Il numero zero si scrive 0.", "Questa maglia costa 70.000 lire.", "Il famoso agente 007.", "Dopo il numero 799 c'è l'800.", "Anche questa partita è finita 0 a 0.", "Il termometro è sceso sotto 0.", "Mi servono subito 900.000 lire.", "Il tavolo è alto 90 centimetri.", "Non vendo a meno di 808.000 lire.", "C'erano 800 posti in quel teatro.", "Il Monte Everest è alto più di 8.000 metri.", "Una metropoli di 7.000.000 di abitanti.", "Anche se aveva 800 pagine l'ho letto tutto d'un fiato.", "Questa rivista costa 8.700 lire."]}, {"name": "/", "phrases": ["Sette noni ovvero 7/9.", "La mia data di nascita è 09/07/99.", "Dimmi se 8/9 è maggiore di 7/8.", "La barra è sopra al numero 7.", "Il carattere barra si chiama anche segno di frazione.", "7/8, 77/88 e 777/888 sono tra loro equivalenti.", "Il carattere / viene usato anche come segno di divisione."]}, {"name": "()", "phrases": ["( è il segno di aperta parentesi.", ") è il segno di chiusa parentesi.", "Il Marco (moneta tedesca) vale circa 998 lire.", "Vieri (Inter) ieri non ha segnato.", "Ho un PC (Personal Computer) è un po' vecchiotto.", "Dalla mia casa (settimo piano) vedo tanti tetti.", "Era Marco (non Luigi) quello che hai incontrato ieri.", "Marcello (il maestro) oggi era molto contento.", "Il nonno compie gli anni (87) e faremo una bella festa.", "La sua auto (una vecchia Fiat) non va più bene.", "Vieste (sul Gargano) ha un mare stupendo."]}, {"name": "=", "phrases": ["Il simbolo di uguale è =", "8=8 e 9=9", "Il tasto = è sopra quello dello 0.", "7/8 = 77/88", "Il simbolo = significa uguale.", "Naturalmente 978=978 e 80=80.", "A volte si usa = anche per la divisione in sillabe."]}, {"name": "6", "phrases": ["Eravamo in 6 amici.", "La squadra di pallavolo è composta di 6 giocatori.", "Abita al numero 66 di via Verdi.", "Mi servono 6.000 lire.", "Aprire il libro a pagina 86.", "Ha vinto il giocatore con la maglia numero 6.", "In maggio, il giorno 6, compie 6 anni.", "Il 6 gennaio arriva la Befana.", "Domenica il nonno compie 68 anni.", "Questi spaghetti cuociono in 6 minuti.", "Gli telefona 6 volte al giorno.", "Telefonami al numero 06 7866866.", "Ci vorrebbe un 6 al SuperEnalotto.", "Ha preso 6 e mezzo ma lui si aspettava almeno un 7."]}, {"name": "5", "phrases": ["Una moneta da 500 lire.", "Una banconota da 5.000 lire.", "Domani è il 5 ottobre.", "Pesa solo 55 chili.", "Se compi 5 anni ci vogliono 5 candeline.", "Ogni 5 minuti suonava la sirena.", "Se siamo in 6, 5 sedie non bastano.", "Chi indovina 5 numeri fa cinquina.", "Hanno vinto 5 a 0, un vero trionfo.", "Devo cambiare questa banconota da 50.000 lire.", "Canale5 mi piace ma c'è troppa pubblicità.", "Ogni giorno per allenarsi fa 5 chilometri di corsa.", "Domani mi alzo alle 5 per andare a pescare.", "Abita in via Roma al numero 5"]}, {"name": "4", "phrases": ["44 gatti in fila per 6 con il resto di due.", "40 cani in fila per 4 con il resto di 0.", "A carte si gioca bene in 4.", "Un'automobile da 4 posti.", "Nel vaso c'erano 4 rose rosse.", "444.444 è un numero di telefono facile da ricordare.", "8 per 8 fa 64.", "Mi servono 4 quaderni nuovi.", "Le 4 gambe del tavolo", "Mio papà ha 44 anni.", "Si chiamano quadrupedi gli animali con 4 zampe.", "Un libro di 400 pagine.", "Le automobili hanno 4 ruote.", "Un paese di 540 abitanti."]}, {"name": "3", "phrases": ["I 3 moschettieri veramente erano 4.", "Mi hanno regalato 3 dischi nuovi.", "Coi suoi piedoni usa scarpe numero 43.", "33 trentini trottavano verso Trento.", "Il 3 è un numero importante.", "Molti mesi hanno 30 giorni.", "il 3 è un numero dispari.", "L'autobus numero 3 è appena passato.", "Una casetta con solo 3 finestre.", "Il triciclo ha 3 ruote.", "Qui una bibita costa 3.000 lire.", "In classe siamo quasi in 30.", "Viene a casa mia oggi alle 3 e mezza.", "Ha preso un pesce di oltre 3 chili."]}, {"name": "2", "phrases": ["Il 2 è il primo numero pari.", "Il 25 dicembre si festeggia il Natale.", "Una moneta da 2.000 lire.", "Marco ha 2 fratelli e una sorella.", "Mi servirebbero 200.000 lire.", "Se ve ne andate anche voi rimaniamo in 2.", "C'erano due passerotti sul ramo.", "Un cesto con 3 mele e 2 pere.", "Abbiamo 2 mani e 2 piedi.", "Abbiamo 2 occhi e 2 orecchie.", "Aveva un'auto sportiva con soli 2 posti.", "42 gradi all'ombra, proprio un caldo insopportabile.", "Il viaggio in treno durava circa 2 ore e 20 minuti.", "Il tandem è una bicicletta a 2 posti."]}, {"name": "1", "phrases": ["Il numero 1", "Per chiamare la polizia usa il 113.", "Un mezzo si può scrivere anche 1/2.", "Sappiamo che 7/7=1, 8/8=1 e 9/9=1.", "Oggi è il 12/10/1999.", "Il 10/06/1940 l'Italia entrò in guerra.", "Per chiamare i carabinieri usa il 112.", "L'anno 1199 è l'ultimo del secolo.", "Garibaldi e i suoi 1.000 garibaldini.", "Una moneta da 100 lire.", "A calcio si gioca in 11 per squadra.", "Persero la partita per 4 a 1", "Ci vediamo alle 11 in punto.", "La montagna era alta esattamente 3111 metri.", "Nel 1918 finì la prima guerra mondiale.", "Mario è nato 10/11/1991.", "Arrivò primo tra 191 concorrenti.", "Aprite il libro a pagina 151."]}, {"name": "\"", "phrases": ["Questo è il simbolo delle virgolette \".", "\"Il dado è tratto\" disse Cesare.", "Il suo soprannome era \"Stecchino\".", "\"Vieni subito qui\" disse la mamma.", "Si dice che \"Can che abbaia non morde\".", "Il tasto delle \" è sopra a quello del 2.", "Sul cancelletto era scritto \"Attenti al cane\".", "\"Stop\" gridò il poliziotto, ma il ladro scappò.", "Dimmi che cosa vuol dire, secondo te, la parola \"amicizia\"."]}, {"name": "!", "phrases": ["Fermi tutti!", "Aiuto! Il leone è scappato dalla gabbia!", "Questo quadro è meraviglioso!", "Ah! Che splendida gita!", "Bello! Veramente bello! Complimenti!", "Bene! Bravo! Bis!", "Evviva Natale! La festa più bella che ci sia!", "Tanti auguri! Buon compleanno!"]}, {"name": "+", "phrases": ["Il segno + indica l'addizione.", "12+4=16", "Il termometro segnava +2 gradi.", "Se sai quanto fa 5+5, rispondi!", "765.798 + 562.657 è un numero troppo difficile per me!", "Calcola 1+3+7+4+9+2+5+8+6", "Se 12+45 fa 57, anche 45+12 fa 57."]}, {"name": "-", "phrases": ["Il segno - indica la sottrazione.", "Il segno - viene chiamato spesso \"meno\".", "calcola 100-10", "Che freddo! Saranno -10 gradi!", "Ecco una facile sottrazione 10-5."]}, {"name": "jJ", "phrases": ["La lettera J si chiama anche i lunga.", "Il jet è un aereo molto veloce.", "Gennaro ha chiamato la figlia Jessica.", "Scrivi Jules e Jim, non Giules e Gim.", "La J è la decima lettera dell'alfabeto.", "A papà piace moltissimo la musica jazz.", "Qualcuno, per favore, chiami Jacopo."]}, {"name": "kK", "phrases": ["Il carattere k si chiama cappa.", "Digita il tuo nome prima di cliccare su OK.", "Mi piacciono molto le merendine Kinder.", "La K è l'undicesima lettera dell'alfabeto.", "Alla sera giochiamo spesso a poker.", "Quando il pugile finisce KO, ha perso l'incontro.", "La sigla \"CD\" significa \"Compact Disk\"", "Il disco fisso del computer si chiama anche Hard Disk."]}, {"name": "wW", "phrases": ["Il carattere w si chiama vu doppia.", "Il carattere W viene usato come segno di \"Evviva!\".", "Il programma \"Typing Trainer\" funziona in Windows.", "Welcome, vuol dire benvenuto.", "La W è la ventitreesima lettera dell'alfabeto.", "A me piacciono molto i kiwi.", "Water in inglese significa acqua.", "Come merenda Walter porta spesso dei wafer."]}, {"name": "xX", "phrases": ["La lettera x si pronuncia ics.", "Tuo papà porta la XL o la XXL.", "Ieri ho mangiato dei pasticcini extra.", "Nel totocalcio la X indica il pareggio.", "La X è la ventiquattresima lettera dell'alfabeto.", "Nei numeri romani X significa dieci, XX venti.", "Giacomo mi ha spedito un fax di 4 pagine."]}, {"name": "yY", "phrases": ["La lettera Y si chiama ipsilon o i greca.", "New York è famosa per i suoi grattacieli.", "Per ascoltare il CD, premi il pulsante \"Play\".", "La Y è la ventiquattresima lettera dell'alfabeto.", "Mary mi ha regalato un bel yo-yo."]}, {"name": "&", "phrases": ["Il simbolo & si chiama \"e commerciale\".", "I famosi soci \"Frank & William\".", "Il supermercato A&O.", "La famosa coppia Tom & Jerry."]}, {"name": "%", "phrases": ["Il simbolo % significa \"per cento\".", "Un prestito al 5% d'interessi.", "Sono stati promossi al 100%.", "Dire 50% è come dire metà", "Le vittorie sono passate dal 44% al 78%."]}, {"name": "<>", "phrases": ["Il simbolo > significa \"maggiore\".", "Sappiamo che 100 > 90.", "Il simbolo < significa \"minore\".", "Naturalmente 45 < 50.", "Tutti i numeri <0 sono negativi."]}, {"name": "*", "phrases": ["Il segno * si chiama asterisco", "Spesso nei computer * è il simbolo della moltiplicazione", "Mettere *** significa non volere dire il nome.", "Calcola 4*3"]}, {"name": "@", "phrases": ["Il carattere @ si chiama \"chiocciola\"", "Il simbolo @ è oggi molto usato negli indirizzi internet.", "Qualcuno chiama @ \"at\", ovvero \"presso\".", "Scrivimi all'indirizzo pinco.pallino@tin.it", "La mia email è: garibaldi@libero.it", "@ si ottiene con Alt Gr e il tasto ò"]}, {"name": "#", "phrases": ["Il simbolo # si chiama cancelletto.", "Il simbolo # si chiama anche diesis.", "Il simbolo # non è molto usato nei testi normali.", "Per ottenere il # deve usare il tasto Alt Gr.", "# si ottiene con Alt Gr e il tasto à."]}, {"name": "$", "phrases": ["Il simbolo $ indica il dollaro.", "Il simbolo $ viene usato soprattutto in campo commerciale.", "Paperon de Paperoni ha come stemma il carattere $.", "Il simbolo $ si trova in tastiera sopra al 4.", "Una banconota da 100$"]}, {"name": "£", "phrases": ["Il simbolo £ indica la lira sterlina.", "Il simbolo £ viene anche usato per la lira italiana.", "Sopra al numero 3 si trova il carattere £.", "Un assegno da £ 2.000.000"]}, {"name": "\\", "phrases": ["Nella tastiera c'è anche il carattere \\.", "Il carattere \\ viene chiamato \"barra rovescia\"", "Le due barre, / e \\, sono tra loro simmetriche.", "Il tasto con il simbolo \\ si trova in alto a sinistra.", "Il simbolo \\ è molto usato in DOS."]}, {"name": "_", "phrases": ["Il carattere _ indica il trattino basso o sottolineato.", "Il carattere _ si trova sopra il trattino normale -.", "Si usa spesso _ per unire due parole.", "Il carattere _ non è molto usato nei testi normali."]}, {"name": "[]", "phrases": ["Le parentesi quadre si indicano con [].", "[ è la parentesi quadra aperta.", "] è la parentesi quadra chiusa.", "Le parentesi [ e ] si usano spesso in matematica.", "Calcola: 4-[(6+3)/3]", "Per ottenere i caratteri [] si usa il tasto Alt Gr.", "[ si ottiene con Alt Gr e il tasto è", "] si ottiene con Alt Gr e il tasto +"]}, {"name": "{}", "phrases": ["I simboli {} rappresentano le parentesi graffe.", "I simboli {} sono molto usati in matematica.", "Per ottenere il simbolo { si usa Ctrl Alt Shift e il tasto è", "Per ottenere il simbolo } si usa Ctrl Alt Shift e il tasto +", "{ è la parentesi graffa aperta", "} è la parentesi graffa chiusa"]}, {"name": ":", "phrases": ["Il simbolo : è detto \"due punti\"", "Trova l'errore: 12>10, 45<35, 41>27"]}, {"name": ";", "phrases": ["Il simbolo ; è detto \"punto e virgola\""]}, {"name": "|", "phrases": ["Il simbolo | è detto \"pipe\""]}, {"name": "?", "phrases": ["Il simbolo ? si usa al termine delle frasi interrogative."]}, {"name": "^", "phrases": ["Il simbolo ^ si trova sopra alla lettera ì."]}, {"name": "§", "phrases": ["Il simbolo § si trova sopra alla lettera ù."]}, {"name": "ç", "phrases": ["Il carattere ç è molto usato in francese."]}, {"name": "°", "phrases": ["Il simbolo ° indica i gradi."]}];
    const EMBEDDED_ALBERTO_PROFILE = {"UserID": "ALBERTO", "Mode": "1", "Lesson": "1", "Exercise": "-1", "AutomaticCorrection": "false", "ShowKeyBoard": "true", "ShowHands": "true", "ShowOrigin": "true", "ShowTyped": "true", "MainTop": "83", "MainLeft": "184", "StatTop": "93", "StatLeft": "206", "StatWidth": "863", "StatHeight": "712", "HandsTop": "780", "HandsLeft": "290", "StatRbGraficoErrorFreq": "false", "StatRbGraficoVelocita": "true", "StatRbOrdFrequenzaRel": "false", "StatRbOrdErroriRelativi": "true", "StatRbOrdErroriAssoluti": "false", "StatRbOrdDitoRel": "false", "StatChkDatiPhrasesAllLetters": "false", "StatChkDatiPhrasesCustomFile": "false", "StatChkDatiRandom": "true", "StatChkDatiTyping": "false", "StatChkDatiRandomThisPhrase": "false", "StatChkDatiRandomAllChars": "true", "StatChkDatiFonemi": "true", "StatRbOrdFrequenzaAss": "false", "StatRbOrdDitoAss": "false", "StatRbGrafBattute": "true", "StatRbGrafErroriRel": "false", "StatRbGrafErroriAss": "false", "StatRbGrafCaratteri": "false", "TotaleCaratteri": 41700, "TotaleErrori": 2712, "Caratteri": [{"Index": 101, "CharUnicode": 64, "Frequenza": 276, "Errori": 45}, {"Index": 83, "CharUnicode": 232, "Frequenza": 317, "Errori": 47}, {"Index": 8, "CharUnicode": 33, "Frequenza": 284, "Errori": 41}, {"Index": 99, "CharUnicode": 167, "Frequenza": 268, "Errori": 38}, {"Index": 87, "CharUnicode": 249, "Frequenza": 293, "Errori": 41}, {"Index": 95, "CharUnicode": 233, "Frequenza": 278, "Errori": 37}, {"Index": 105, "CharUnicode": 125, "Frequenza": 272, "Errori": 34}, {"Index": 55, "CharUnicode": 89, "Frequenza": 280, "Errori": 33}, {"Index": 20, "CharUnicode": 90, "Frequenza": 268, "Errori": 31}, {"Index": 80, "CharUnicode": 242, "Frequenza": 288, "Errori": 32}, {"Index": 96, "CharUnicode": 176, "Frequenza": 270, "Errori": 30}, {"Index": 104, "CharUnicode": 123, "Frequenza": 281, "Errori": 31}, {"Index": 19, "CharUnicode": 83, "Frequenza": 290, "Errori": 31}, {"Index": 64, "CharUnicode": 107, "Frequenza": 274, "Errori": 29}, {"Index": 102, "CharUnicode": 93, "Frequenza": 269, "Errori": 28}, {"Index": 10, "CharUnicode": 81, "Frequenza": 283, "Errori": 29}, {"Index": 103, "CharUnicode": 35, "Frequenza": 276, "Errori": 28}, {"Index": 100, "CharUnicode": 91, "Frequenza": 280, "Errori": 28}, {"Index": 12, "CharUnicode": 62, "Frequenza": 273, "Errori": 27}, {"Index": 86, "CharUnicode": 43, "Frequenza": 275, "Errori": 27}, {"Index": 70, "CharUnicode": 48, "Frequenza": 312, "Errori": 30}, {"Index": 28, "CharUnicode": 88, "Frequenza": 283, "Errori": 27}, {"Index": 41, "CharUnicode": 38, "Frequenza": 275, "Errori": 26}, {"Index": 94, "CharUnicode": 94, "Frequenza": 275, "Errori": 26}, {"Index": 40, "CharUnicode": 67, "Frequenza": 286, "Errori": 27}, {"Index": 16, "CharUnicode": 122, "Frequenza": 339, "Errori": 32}, {"Index": 3, "CharUnicode": 50, "Frequenza": 276, "Errori": 26}, {"Index": 66, "CharUnicode": 41, "Frequenza": 276, "Errori": 26}, {"Index": 47, "CharUnicode": 121, "Frequenza": 268, "Errori": 25}, {"Index": 68, "CharUnicode": 75, "Frequenza": 279, "Errori": 26}, {"Index": 92, "CharUnicode": 231, "Frequenza": 272, "Errori": 25}, {"Index": 98, "CharUnicode": 42, "Frequenza": 284, "Errori": 26}, {"Index": 13, "CharUnicode": 51, "Frequenza": 279, "Errori": 25}, {"Index": 81, "CharUnicode": 46, "Frequenza": 393, "Errori": 35}, {"Index": 17, "CharUnicode": 163, "Frequenza": 271, "Errori": 24}, {"Index": 84, "CharUnicode": 224, "Frequenza": 286, "Errori": 25}, {"Index": 69, "CharUnicode": 77, "Frequenza": 277, "Errori": 24}, {"Index": 62, "CharUnicode": 57, "Frequenza": 289, "Errori": 25}, {"Index": 76, "CharUnicode": 76, "Frequenza": 291, "Errori": 25}, {"Index": 24, "CharUnicode": 120, "Frequenza": 280, "Errori": 24}, {"Index": 52, "CharUnicode": 106, "Frequenza": 271, "Errori": 23}, {"Index": 78, "CharUnicode": 39, "Frequenza": 299, "Errori": 25}, {"Index": 14, "CharUnicode": 119, "Frequenza": 276, "Errori": 23}, {"Index": 85, "CharUnicode": 45, "Frequenza": 276, "Errori": 23}, {"Index": 73, "CharUnicode": 44, "Frequenza": 317, "Errori": 26}, {"Index": 90, "CharUnicode": 63, "Frequenza": 270, "Errori": 22}, {"Index": 7, "CharUnicode": 124, "Frequenza": 273, "Errori": 22}, {"Index": 33, "CharUnicode": 54, "Frequenza": 282, "Errori": 22}, {"Index": 18, "CharUnicode": 87, "Frequenza": 283, "Errori": 22}, {"Index": 82, "CharUnicode": 236, "Frequenza": 297, "Errori": 23}, {"Index": 60, "CharUnicode": 74, "Frequenza": 272, "Errori": 21}, {"Index": 93, "CharUnicode": 58, "Frequenza": 286, "Errori": 22}, {"Index": 97, "CharUnicode": 95, "Frequenza": 276, "Errori": 21}, {"Index": 26, "CharUnicode": 69, "Frequenza": 276, "Errori": 21}, {"Index": 6, "CharUnicode": 60, "Frequenza": 280, "Errori": 21}, {"Index": 27, "CharUnicode": 68, "Frequenza": 281, "Errori": 21}, {"Index": 39, "CharUnicode": 70, "Frequenza": 268, "Errori": 20}, {"Index": 0, "CharUnicode": 92, "Frequenza": 269, "Errori": 20}, {"Index": 50, "CharUnicode": 56, "Frequenza": 302, "Errori": 22}, {"Index": 49, "CharUnicode": 98, "Frequenza": 362, "Errori": 26}, {"Index": 61, "CharUnicode": 78, "Frequenza": 283, "Errori": 20}, {"Index": 77, "CharUnicode": 59, "Frequenza": 270, "Errori": 19}, {"Index": 59, "CharUnicode": 85, "Frequenza": 285, "Errori": 20}, {"Index": 4, "CharUnicode": 113, "Frequenza": 305, "Errori": 21}, {"Index": 42, "CharUnicode": 84, "Frequenza": 277, "Errori": 19}, {"Index": 1, "CharUnicode": 49, "Frequenza": 280, "Errori": 19}, {"Index": 56, "CharUnicode": 72, "Frequenza": 266, "Errori": 18}, {"Index": 79, "CharUnicode": 112, "Frequenza": 494, "Errori": 33}, {"Index": 67, "CharUnicode": 73, "Frequenza": 305, "Errori": 20}, {"Index": 91, "CharUnicode": 80, "Frequenza": 278, "Errori": 18}, {"Index": 36, "CharUnicode": 118, "Frequenza": 408, "Errori": 26}, {"Index": 37, "CharUnicode": 37, "Frequenza": 273, "Errori": 17}, {"Index": 25, "CharUnicode": 36, "Frequenza": 275, "Errori": 17}, {"Index": 75, "CharUnicode": 79, "Frequenza": 280, "Errori": 17}, {"Index": 44, "CharUnicode": 86, "Frequenza": 286, "Errori": 17}, {"Index": 38, "CharUnicode": 82, "Frequenza": 276, "Errori": 16}, {"Index": 54, "CharUnicode": 47, "Frequenza": 278, "Errori": 16}, {"Index": 43, "CharUnicode": 71, "Frequenza": 281, "Errori": 16}, {"Index": 9, "CharUnicode": 34, "Frequenza": 293, "Errori": 16}, {"Index": 30, "CharUnicode": 114, "Frequenza": 793, "Errori": 43}, {"Index": 15, "CharUnicode": 115, "Frequenza": 703, "Errori": 38}, {"Index": 31, "CharUnicode": 102, "Frequenza": 398, "Errori": 21}, {"Index": 11, "CharUnicode": 65, "Frequenza": 289, "Errori": 15}, {"Index": 21, "CharUnicode": 52, "Frequenza": 292, "Errori": 15}, {"Index": 23, "CharUnicode": 100, "Frequenza": 511, "Errori": 26}, {"Index": 46, "CharUnicode": 55, "Frequenza": 375, "Errori": 19}, {"Index": 63, "CharUnicode": 105, "Frequenza": 1184, "Errori": 59}, {"Index": 74, "CharUnicode": 61, "Frequenza": 281, "Errori": 14}, {"Index": 71, "CharUnicode": 111, "Frequenza": 996, "Errori": 49}, {"Index": 48, "CharUnicode": 104, "Frequenza": 357, "Errori": 17}, {"Index": 35, "CharUnicode": 103, "Frequenza": 465, "Errori": 22}, {"Index": 2, "CharUnicode": 8594, "Frequenza": 1049, "Errori": 49}, {"Index": 65, "CharUnicode": 109, "Frequenza": 471, "Errori": 22}, {"Index": 29, "CharUnicode": 53, "Frequenza": 285, "Errori": 13}, {"Index": 57, "CharUnicode": 66, "Frequenza": 275, "Errori": 12}, {"Index": 22, "CharUnicode": 101, "Frequenza": 1068, "Errori": 45}, {"Index": 34, "CharUnicode": 116, "Frequenza": 759, "Errori": 31}, {"Index": 5, "CharUnicode": 97, "Frequenza": 1328, "Errori": 45}, {"Index": 58, "CharUnicode": 40, "Frequenza": 278, "Errori": 9}, {"Index": 72, "CharUnicode": 108, "Frequenza": 859, "Errori": 27}, {"Index": 51, "CharUnicode": 117, "Frequenza": 514, "Errori": 15}, {"Index": 32, "CharUnicode": 99, "Frequenza": 556, "Errori": 16}, {"Index": 53, "CharUnicode": 110, "Frequenza": 808, "Errori": 17}, {"Index": 89, "CharUnicode": 174, "Frequenza": 2194, "Errori": 42}, {"Index": 45, "CharUnicode": 32, "Frequenza": 1817, "Errori": 24}, {"Index": 88, "CharUnicode": 8592, "Frequenza": 0, "Errori": 0}], "Campioni": [{"Index": 0, "BattuteMinuto": 66, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 16, "Esercizio": ""}, {"Index": 1, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 2, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 3, "BattuteMinuto": 72, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 4, "BattuteMinuto": 66, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 5, "BattuteMinuto": 52, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 19, "Esercizio": ""}, {"Index": 6, "BattuteMinuto": 69, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 7, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 8, "BattuteMinuto": 78, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 9, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 10, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 11, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 12, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 13, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 14, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 15, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 16, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 17, "BattuteMinuto": 59, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 15, "Esercizio": ""}, {"Index": 18, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 19, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 20, "BattuteMinuto": 59, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 15, "Esercizio": ""}, {"Index": 21, "BattuteMinuto": 68, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 22, "BattuteMinuto": 55, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 17, "Esercizio": ""}, {"Index": 23, "BattuteMinuto": 70, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 24, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 25, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 26, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 27, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 28, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 29, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 30, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 31, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 32, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 33, "BattuteMinuto": 66, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 34, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 35, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 36, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 37, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 38, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 39, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 40, "BattuteMinuto": 68, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 41, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 1, "Esercizio": ""}, {"Index": 42, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 43, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 44, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 45, "BattuteMinuto": 94, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 1, "Esercizio": ""}, {"Index": 46, "BattuteMinuto": 89, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 47, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 48, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 49, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 50, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 51, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 52, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 53, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 54, "BattuteMinuto": 94, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 55, "BattuteMinuto": 89, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 56, "BattuteMinuto": 94, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 57, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 58, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 59, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 60, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 61, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 62, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 63, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 64, "BattuteMinuto": 92, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 65, "BattuteMinuto": 89, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 66, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 67, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 68, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 69, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 70, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 71, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 72, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 73, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 74, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 75, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 76, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 77, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 78, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 79, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 80, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 81, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 82, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 83, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 84, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 85, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 86, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 87, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 88, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 89, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 90, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 91, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 92, "BattuteMinuto": 102, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 93, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 94, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 95, "BattuteMinuto": 66, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 96, "BattuteMinuto": 58, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 97, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 98, "BattuteMinuto": 62, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 15, "Esercizio": ""}, {"Index": 99, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 15, "Esercizio": ""}, {"Index": 100, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 101, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 102, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 103, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 104, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 105, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 106, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 107, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 108, "BattuteMinuto": 94, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 109, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 110, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 111, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 112, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 113, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 114, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 115, "BattuteMinuto": 89, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 116, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 117, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 16, "Esercizio": ""}, {"Index": 118, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 23, "Esercizio": ""}, {"Index": 119, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 120, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 121, "BattuteMinuto": 72, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 122, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 123, "BattuteMinuto": 78, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 124, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 125, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 126, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 16, "Esercizio": ""}, {"Index": 127, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 128, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 129, "BattuteMinuto": 226, "TipoCampione": 1, "NumCaratteri": 30, "NumErrori": 4, "Esercizio": "Invio"}, {"Index": 130, "BattuteMinuto": 200, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 4, "Esercizio": "Invio"}, {"Index": 131, "BattuteMinuto": 275, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 2, "Esercizio": "Invio"}, {"Index": 132, "BattuteMinuto": 159, "TipoCampione": 1, "NumCaratteri": 36, "NumErrori": 9, "Esercizio": "Invio"}, {"Index": 133, "BattuteMinuto": 190, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 5, "Esercizio": "Invio"}, {"Index": 134, "BattuteMinuto": 292, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 0, "Esercizio": "Invio"}, {"Index": 135, "BattuteMinuto": 157, "TipoCampione": 1, "NumCaratteri": 36, "NumErrori": 8, "Esercizio": "Invio"}, {"Index": 136, "BattuteMinuto": 154, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 9, "Esercizio": "Invio"}, {"Index": 137, "BattuteMinuto": 262, "TipoCampione": 1, "NumCaratteri": 31, "NumErrori": 1, "Esercizio": "Invio"}, {"Index": 138, "BattuteMinuto": 173, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 6, "Esercizio": "Invio"}, {"Index": 139, "BattuteMinuto": 186, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 5, "Esercizio": "Invio"}, {"Index": 140, "BattuteMinuto": 108, "TipoCampione": 1, "NumCaratteri": 20, "NumErrori": 7, "Esercizio": "p"}, {"Index": 141, "BattuteMinuto": 221, "TipoCampione": 1, "NumCaratteri": 23, "NumErrori": 0, "Esercizio": "8"}, {"Index": 142, "BattuteMinuto": 212, "TipoCampione": 1, "NumCaratteri": 31, "NumErrori": 3, "Esercizio": "b"}, {"Index": 143, "BattuteMinuto": 317, "TipoCampione": 1, "NumCaratteri": 15, "NumErrori": 0, "Esercizio": "o"}, {"Index": 144, "BattuteMinuto": 272, "TipoCampione": 1, "NumCaratteri": 18, "NumErrori": 0, "Esercizio": "ò"}, {"Index": 145, "BattuteMinuto": 255, "TipoCampione": 1, "NumCaratteri": 29, "NumErrori": 1, "Esercizio": "'"}, {"Index": 146, "BattuteMinuto": 160, "TipoCampione": 1, "NumCaratteri": 12, "NumErrori": 1, "Esercizio": "r"}, {"Index": 147, "BattuteMinuto": 184, "TipoCampione": 1, "NumCaratteri": 43, "NumErrori": 4, "Esercizio": "kK"}, {"Index": 148, "BattuteMinuto": 340, "TipoCampione": 1, "NumCaratteri": 14, "NumErrori": 0, "Esercizio": "r"}, {"Index": 149, "BattuteMinuto": 180, "TipoCampione": 1, "NumCaratteri": 28, "NumErrori": 3, "Esercizio": "ò"}, {"Index": 150, "BattuteMinuto": 166, "TipoCampione": 1, "NumCaratteri": 27, "NumErrori": 4, "Esercizio": "ù"}, {"Index": 151, "BattuteMinuto": 276, "TipoCampione": 1, "NumCaratteri": 48, "NumErrori": 1, "Esercizio": "9"}, {"Index": 152, "BattuteMinuto": 284, "TipoCampione": 1, "NumCaratteri": 35, "NumErrori": 0, "Esercizio": "ù"}, {"Index": 153, "BattuteMinuto": 342, "TipoCampione": 1, "NumCaratteri": 13, "NumErrori": 0, "Esercizio": "o"}, {"Index": 154, "BattuteMinuto": 264, "TipoCampione": 1, "NumCaratteri": 16, "NumErrori": 1, "Esercizio": "e"}, {"Index": 155, "BattuteMinuto": 209, "TipoCampione": 1, "NumCaratteri": 34, "NumErrori": 1, "Esercizio": "6"}, {"Index": 156, "BattuteMinuto": 197, "TipoCampione": 1, "NumCaratteri": 39, "NumErrori": 3, "Esercizio": "3"}, {"Index": 157, "BattuteMinuto": 221, "TipoCampione": 1, "NumCaratteri": 34, "NumErrori": 1, "Esercizio": "3"}, {"Index": 158, "BattuteMinuto": 277, "TipoCampione": 1, "NumCaratteri": 31, "NumErrori": 1, "Esercizio": "m"}, {"Index": 159, "BattuteMinuto": 261, "TipoCampione": 1, "NumCaratteri": 27, "NumErrori": 0, "Esercizio": "v"}, {"Index": 160, "BattuteMinuto": 191, "TipoCampione": 1, "NumCaratteri": 44, "NumErrori": 2, "Esercizio": "0"}, {"Index": 161, "BattuteMinuto": 173, "TipoCampione": 1, "NumCaratteri": 21, "NumErrori": 7, "Esercizio": "u"}, {"Index": 162, "BattuteMinuto": 154, "TipoCampione": 1, "NumCaratteri": 29, "NumErrori": 7, "Esercizio": "6"}, {"Index": 163, "BattuteMinuto": 228, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 3, "Esercizio": ""}, {"Index": 164, "BattuteMinuto": 159, "TipoCampione": 7, "NumCaratteri": 108, "NumErrori": 17, "Esercizio": ""}, {"Index": 165, "BattuteMinuto": 228, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 166, "BattuteMinuto": 218, "TipoCampione": 7, "NumCaratteri": 103, "NumErrori": 3, "Esercizio": ""}, {"Index": 167, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 105, "NumErrori": 4, "Esercizio": ""}, {"Index": 168, "BattuteMinuto": 201, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 169, "BattuteMinuto": 204, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 8, "Esercizio": ""}, {"Index": 170, "BattuteMinuto": 229, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 2, "Esercizio": ""}, {"Index": 171, "BattuteMinuto": 207, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 6, "Esercizio": ""}, {"Index": 172, "BattuteMinuto": 170, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 12, "Esercizio": ""}, {"Index": 173, "BattuteMinuto": 252, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 1, "Esercizio": ""}, {"Index": 174, "BattuteMinuto": 156, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 8, "Esercizio": ""}, {"Index": 175, "BattuteMinuto": 150, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 8, "Esercizio": ""}, {"Index": 176, "BattuteMinuto": 171, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 9, "Esercizio": ""}, {"Index": 177, "BattuteMinuto": 173, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 178, "BattuteMinuto": 170, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 3, "Esercizio": ""}, {"Index": 179, "BattuteMinuto": 169, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 10, "Esercizio": ""}, {"Index": 180, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 4, "Esercizio": ""}, {"Index": 181, "BattuteMinuto": 145, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 12, "Esercizio": ""}, {"Index": 182, "BattuteMinuto": 175, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 7, "Esercizio": ""}, {"Index": 183, "BattuteMinuto": 151, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 10, "Esercizio": ""}, {"Index": 184, "BattuteMinuto": 194, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 1, "Esercizio": ""}, {"Index": 185, "BattuteMinuto": 163, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 10, "Esercizio": ""}, {"Index": 186, "BattuteMinuto": 185, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 2, "Esercizio": ""}, {"Index": 187, "BattuteMinuto": 209, "TipoCampione": 7, "NumCaratteri": 103, "NumErrori": 2, "Esercizio": ""}, {"Index": 188, "BattuteMinuto": 214, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 4, "Esercizio": ""}, {"Index": 189, "BattuteMinuto": 200, "TipoCampione": 7, "NumCaratteri": 106, "NumErrori": 2, "Esercizio": ""}, {"Index": 190, "BattuteMinuto": 181, "TipoCampione": 7, "NumCaratteri": 105, "NumErrori": 8, "Esercizio": ""}, {"Index": 191, "BattuteMinuto": 201, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 4, "Esercizio": ""}, {"Index": 192, "BattuteMinuto": 162, "TipoCampione": 7, "NumCaratteri": 103, "NumErrori": 6, "Esercizio": ""}, {"Index": 193, "BattuteMinuto": 170, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 13, "Esercizio": ""}, {"Index": 194, "BattuteMinuto": 163, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 8, "Esercizio": ""}, {"Index": 195, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 5, "Esercizio": ""}, {"Index": 196, "BattuteMinuto": 182, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 6, "Esercizio": ""}, {"Index": 197, "BattuteMinuto": 229, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 2, "Esercizio": ""}, {"Index": 198, "BattuteMinuto": 188, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 4, "Esercizio": ""}, {"Index": 199, "BattuteMinuto": 168, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 11, "Esercizio": ""}, {"Index": 200, "BattuteMinuto": 185, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 5, "Esercizio": ""}, {"Index": 201, "BattuteMinuto": 183, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 7, "Esercizio": ""}, {"Index": 202, "BattuteMinuto": 192, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 3, "Esercizio": ""}, {"Index": 203, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 7, "Esercizio": ""}, {"Index": 204, "BattuteMinuto": 232, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 3, "Esercizio": ""}, {"Index": 205, "BattuteMinuto": 173, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 10, "Esercizio": ""}, {"Index": 206, "BattuteMinuto": 151, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 10, "Esercizio": ""}, {"Index": 207, "BattuteMinuto": 207, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 2, "Esercizio": ""}, {"Index": 208, "BattuteMinuto": 214, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 1, "Esercizio": ""}, {"Index": 209, "BattuteMinuto": 166, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 5, "Esercizio": ""}, {"Index": 210, "BattuteMinuto": 194, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 211, "BattuteMinuto": 216, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 3, "Esercizio": ""}, {"Index": 212, "BattuteMinuto": 187, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 6, "Esercizio": ""}, {"Index": 213, "BattuteMinuto": 186, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 10, "Esercizio": ""}, {"Index": 214, "BattuteMinuto": 161, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 4, "Esercizio": ""}, {"Index": 215, "BattuteMinuto": 198, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 216, "BattuteMinuto": 209, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 3, "Esercizio": ""}, {"Index": 217, "BattuteMinuto": 170, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 4, "Esercizio": ""}, {"Index": 218, "BattuteMinuto": 192, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 4, "Esercizio": ""}, {"Index": 219, "BattuteMinuto": 172, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 10, "Esercizio": ""}, {"Index": 220, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 221, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 222, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 223, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 224, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 225, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 226, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 227, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 228, "BattuteMinuto": 70, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 24, "Esercizio": ""}, {"Index": 229, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 230, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 23, "Esercizio": ""}, {"Index": 231, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 232, "BattuteMinuto": 64, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 21, "Esercizio": ""}, {"Index": 233, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 24, "Esercizio": ""}, {"Index": 234, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 235, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 236, "BattuteMinuto": 95, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 237, "BattuteMinuto": 70, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 238, "BattuteMinuto": 69, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 22, "Esercizio": ""}, {"Index": 239, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 240, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 241, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 242, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 243, "BattuteMinuto": 72, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 244, "BattuteMinuto": 64, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 17, "Esercizio": ""}, {"Index": 245, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 17, "Esercizio": ""}, {"Index": 246, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 247, "BattuteMinuto": 59, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 22, "Esercizio": ""}, {"Index": 248, "BattuteMinuto": 60, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 249, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 250, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 251, "BattuteMinuto": 58, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 16, "Esercizio": ""}, {"Index": 252, "BattuteMinuto": 57, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 253, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 254, "BattuteMinuto": 79, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 255, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 256, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 257, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 258, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 259, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 260, "BattuteMinuto": 64, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 20, "Esercizio": ""}, {"Index": 261, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 262, "BattuteMinuto": 72, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 263, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 264, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 265, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 266, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 267, "BattuteMinuto": 90, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 268, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 21, "Esercizio": ""}, {"Index": 269, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 270, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 21, "Esercizio": ""}, {"Index": 271, "BattuteMinuto": 70, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 272, "BattuteMinuto": 70, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 273, "BattuteMinuto": 59, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 34, "Esercizio": ""}, {"Index": 274, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 275, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 276, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 277, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 278, "BattuteMinuto": 92, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 279, "BattuteMinuto": 97, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 1, "Esercizio": ""}, {"Index": 280, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 281, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 282, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 283, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 284, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 285, "BattuteMinuto": 85, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 286, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 287, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 288, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 289, "BattuteMinuto": 95, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 290, "BattuteMinuto": 92, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 291, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 292, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 293, "BattuteMinuto": 78, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 294, "BattuteMinuto": 92, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 3, "Esercizio": ""}, {"Index": 295, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 296, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 297, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 298, "BattuteMinuto": 74, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 299, "BattuteMinuto": 54, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 300, "BattuteMinuto": 64, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 19, "Esercizio": ""}, {"Index": 301, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 302, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 303, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 304, "BattuteMinuto": 61, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 18, "Esercizio": ""}, {"Index": 305, "BattuteMinuto": 77, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 306, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 307, "BattuteMinuto": 87, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 308, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 309, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 310, "BattuteMinuto": 88, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 311, "BattuteMinuto": 72, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 312, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 313, "BattuteMinuto": 86, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 314, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 315, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 316, "BattuteMinuto": 78, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 317, "BattuteMinuto": 89, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 4, "Esercizio": ""}, {"Index": 318, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 319, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 20, "Esercizio": ""}, {"Index": 320, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 321, "BattuteMinuto": 80, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 11, "Esercizio": ""}, {"Index": 322, "BattuteMinuto": 65, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 27, "Esercizio": ""}, {"Index": 323, "BattuteMinuto": 84, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 324, "BattuteMinuto": 78, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 325, "BattuteMinuto": 75, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 5, "Esercizio": ""}, {"Index": 326, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 327, "BattuteMinuto": 93, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 2, "Esercizio": ""}, {"Index": 328, "BattuteMinuto": 76, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 10, "Esercizio": ""}, {"Index": 329, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 9, "Esercizio": ""}, {"Index": 330, "BattuteMinuto": 91, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 6, "Esercizio": ""}, {"Index": 331, "BattuteMinuto": 83, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 15, "Esercizio": ""}, {"Index": 332, "BattuteMinuto": 82, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 333, "BattuteMinuto": 68, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 19, "Esercizio": ""}, {"Index": 334, "BattuteMinuto": 73, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 14, "Esercizio": ""}, {"Index": 335, "BattuteMinuto": 58, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 13, "Esercizio": ""}, {"Index": 336, "BattuteMinuto": 71, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 8, "Esercizio": ""}, {"Index": 337, "BattuteMinuto": 81, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 7, "Esercizio": ""}, {"Index": 338, "BattuteMinuto": 57, "TipoCampione": 6, "NumCaratteri": 114, "NumErrori": 12, "Esercizio": ""}, {"Index": 339, "BattuteMinuto": 209, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 7, "Esercizio": ""}, {"Index": 340, "BattuteMinuto": 250, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 1, "Esercizio": ""}, {"Index": 341, "BattuteMinuto": 195, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 6, "Esercizio": ""}, {"Index": 342, "BattuteMinuto": 159, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 17, "Esercizio": ""}, {"Index": 343, "BattuteMinuto": 226, "TipoCampione": 7, "NumCaratteri": 104, "NumErrori": 5, "Esercizio": ""}, {"Index": 344, "BattuteMinuto": 208, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 345, "BattuteMinuto": 201, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 5, "Esercizio": ""}, {"Index": 346, "BattuteMinuto": 200, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 5, "Esercizio": ""}, {"Index": 347, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 10, "Esercizio": ""}, {"Index": 348, "BattuteMinuto": 213, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 8, "Esercizio": ""}, {"Index": 349, "BattuteMinuto": 150, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 19, "Esercizio": ""}, {"Index": 350, "BattuteMinuto": 201, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 5, "Esercizio": ""}, {"Index": 351, "BattuteMinuto": 187, "TipoCampione": 7, "NumCaratteri": 108, "NumErrori": 4, "Esercizio": ""}, {"Index": 352, "BattuteMinuto": 149, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 7, "Esercizio": ""}, {"Index": 353, "BattuteMinuto": 166, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 7, "Esercizio": ""}, {"Index": 354, "BattuteMinuto": 184, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 9, "Esercizio": ""}, {"Index": 355, "BattuteMinuto": 148, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 7, "Esercizio": ""}, {"Index": 356, "BattuteMinuto": 208, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 2, "Esercizio": ""}, {"Index": 357, "BattuteMinuto": 213, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 4, "Esercizio": ""}, {"Index": 358, "BattuteMinuto": 172, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 8, "Esercizio": ""}, {"Index": 359, "BattuteMinuto": 219, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 5, "Esercizio": ""}, {"Index": 360, "BattuteMinuto": 224, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 0, "Esercizio": ""}, {"Index": 361, "BattuteMinuto": 217, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 2, "Esercizio": ""}, {"Index": 363, "BattuteMinuto": 172, "TipoCampione": 7, "NumCaratteri": 102, "NumErrori": 9, "Esercizio": ""}, {"Index": 363, "BattuteMinuto": 171, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 14, "Esercizio": ""}, {"Index": 364, "BattuteMinuto": 254, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 2, "Esercizio": ""}, {"Index": 365, "BattuteMinuto": 213, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 6, "Esercizio": ""}, {"Index": 366, "BattuteMinuto": 179, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 8, "Esercizio": ""}, {"Index": 367, "BattuteMinuto": 202, "TipoCampione": 7, "NumCaratteri": 103, "NumErrori": 6, "Esercizio": ""}, {"Index": 368, "BattuteMinuto": 161, "TipoCampione": 7, "NumCaratteri": 100, "NumErrori": 11, "Esercizio": ""}, {"Index": 369, "BattuteMinuto": 208, "TipoCampione": 7, "NumCaratteri": 103, "NumErrori": 4, "Esercizio": ""}, {"Index": 370, "BattuteMinuto": 206, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 4, "Esercizio": ""}, {"Index": 371, "BattuteMinuto": 178, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 7, "Esercizio": ""}, {"Index": 372, "BattuteMinuto": 162, "TipoCampione": 7, "NumCaratteri": 101, "NumErrori": 10, "Esercizio": ""}, {"Index": 373, "BattuteMinuto": 79, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 374, "BattuteMinuto": 92, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 375, "BattuteMinuto": 95, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 376, "BattuteMinuto": 83, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 377, "BattuteMinuto": 106, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 378, "BattuteMinuto": 94, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 379, "BattuteMinuto": 82, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 4, "Esercizio": "All Letters"}, {"Index": 380, "BattuteMinuto": 71, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 381, "BattuteMinuto": 113, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 382, "BattuteMinuto": 98, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 383, "BattuteMinuto": 106, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 384, "BattuteMinuto": 100, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 385, "BattuteMinuto": 97, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 386, "BattuteMinuto": 103, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 387, "BattuteMinuto": 87, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 388, "BattuteMinuto": 121, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 389, "BattuteMinuto": 74, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 6, "Esercizio": "All Letters"}, {"Index": 390, "BattuteMinuto": 90, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 391, "BattuteMinuto": 106, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 392, "BattuteMinuto": 114, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 393, "BattuteMinuto": 96, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 394, "BattuteMinuto": 95, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 395, "BattuteMinuto": 91, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 396, "BattuteMinuto": 99, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 397, "BattuteMinuto": 92, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 398, "BattuteMinuto": 84, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 399, "BattuteMinuto": 81, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 400, "BattuteMinuto": 102, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 401, "BattuteMinuto": 96, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 4, "Esercizio": "All Letters"}, {"Index": 402, "BattuteMinuto": 61, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 403, "BattuteMinuto": 70, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 404, "BattuteMinuto": 94, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 405, "BattuteMinuto": 77, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 5, "Esercizio": "All Letters"}, {"Index": 406, "BattuteMinuto": 102, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 407, "BattuteMinuto": 96, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 408, "BattuteMinuto": 79, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 409, "BattuteMinuto": 100, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 410, "BattuteMinuto": 101, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 411, "BattuteMinuto": 78, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 412, "BattuteMinuto": 65, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 6, "Esercizio": "All Letters"}, {"Index": 413, "BattuteMinuto": 75, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 414, "BattuteMinuto": 102, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 415, "BattuteMinuto": 101, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 416, "BattuteMinuto": 87, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 417, "BattuteMinuto": 76, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 4, "Esercizio": "All Letters"}, {"Index": 418, "BattuteMinuto": 85, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 419, "BattuteMinuto": 87, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 420, "BattuteMinuto": 69, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 4, "Esercizio": "All Letters"}, {"Index": 421, "BattuteMinuto": 95, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 422, "BattuteMinuto": 99, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 423, "BattuteMinuto": 75, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 424, "BattuteMinuto": 82, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 425, "BattuteMinuto": 83, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 426, "BattuteMinuto": 85, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 427, "BattuteMinuto": 85, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 428, "BattuteMinuto": 92, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 429, "BattuteMinuto": 82, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 430, "BattuteMinuto": 78, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 431, "BattuteMinuto": 56, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 6, "Esercizio": "All Letters"}, {"Index": 432, "BattuteMinuto": 80, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 3, "Esercizio": "All Letters"}, {"Index": 433, "BattuteMinuto": 123, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}, {"Index": 434, "BattuteMinuto": 80, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 435, "BattuteMinuto": 83, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 2, "Esercizio": "All Letters"}, {"Index": 436, "BattuteMinuto": 93, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 1, "Esercizio": "All Letters"}, {"Index": 437, "BattuteMinuto": 77, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 4, "Esercizio": "All Letters"}, {"Index": 438, "BattuteMinuto": 95, "TipoCampione": 3, "NumCaratteri": 20, "NumErrori": 0, "Esercizio": "All Letters"}]};
    const EMBEDDED_CUSTOM_DEFAULT = "=====Intero Alfabeto=====\nabcdefghijklmnopqrstuvwxyz\nABCDEFGHIJKLMNOPQRSTUVWXYZ\n\u00f2\u00f9\u00e0\u00ec\u00e8\u00e9\n1234567890\n<>=    +-*/()[]{}\n.,:    ;?!\n'^\u00a7\"\\    |_@ #\u00e7\u00b0\u00a3$%&\n=====Mignolo Destro=====\n\u00a7}_\u00ec\u00a7{^]+*\u00b0\u00e8\n*#\u00e0-\u00e8\n+*\u00e8]\u00e9{\u00b0?\u00f2\u00e7\n\u00e0\u00e8*\u00f9]#@{\u00e0\u00e8*\n\u00ec\u00a7{^\u00e9[+\u00e8\n\u00f9]\u00a7{^]{^[+\u00e8]\u00b0\n\u00e9{{[\u00a7}\u00e8{['+_\u00ec\u00e9[+\u00e8\n\u00f9]\u00a7{^\u00b0]\u00a7{^]+*\u00e8\n\u00e9{['+*\u00e8{?\u00f2\u00e7\n\u00e0\u00e8*\u00b0\u00f9]#\u00e0-\u00e8\n+*\u00e8#@{\u00e0\u00e8*\n\u00ec\u00a7{^\u00b0]^[+\u00e8]\n\u00e9{[\u00b0\n=====Mignolo Sinistro=====\n\\q!2    \"Qa<|1A>\n\"    \\<2Q|Aq!a>1\n><2A|\"Q!\\a1    q\n|!2Q    1A<\">\\qa\n=====Mignoli=====\n?\u00e0    \u00f9Z.\u00b0+\u00e9^{1\\z#2:@q]>|\u00e8*x[A'\u00f2\"\u00a7}\u00a3\u00eca\u00e7<-!_\n\u00b0*    \u00e9a[-!x\u00f2_\u00a3}<:^{#'1zA?\u00ec@2\u00a7]+Z\u00e7\u00e0\".q>\\\u00e8|\n>-q\\\u00e9@\"*x    |\u00e8}_<.\u00f2[!^{2\u00e7:#\u00a3\u00ec]Z\u00e0?\u00b0Az\u00f9+1\u00a7'a\n=====Mignolo e Anulare Destro=====\n]'p0P;*_^\u00a7\u00f2\u00b0\u00e7\u00ec\u00e8=+l[\u00e0,#.\u00f9-{o@}?L\u00e9O:\n#.\u00f9-\u00b0\u00e7?L;*_^\u00a7]'\u00f20{o@p\u00ec\u00e8+\u00e9O:}=Pl[\u00e0,\n\u00e8+l]'\u00f20{o@p[\u00e0,\u00f9-}=P#\u00a7\u00b0\u00e7?L\u00e9O:\u00ec.;*_^\n=====Mignolo Anulare Sinistro=====\n\\qs!2w\"QZza    <|W1A>3\u00a3S\n\"3\\W<2    1zSswQ|A\u00a3q!a>Z\n><\u00a32sZAq3w|a1\"SzQ    !\\W\n|q!    2w\u00a3QZ1A<WS\"3sz>\\a";
    const EMBEDDED_FONEMI_CORPUS = "asdfl \nsala falsa\n \ndalla sala\n \nfalsa falla\n \nsalda la falla\n \nla falla salda\n \nfa la sala\n \nla fa dalla sala\n \nla salsa falsa\n \nfa la salsa\n \nla salsa salda\n \nfalla salda la salsa\n \nla falda salsa\n \nsala da salsa\n \nsalda salda\n \nsa da salsa\n \nfalla la salsa\n \nsala la salsa\n \nala salda\n \nafa falsa\n \nfalsa afa\n \nfa la falsa\n g \nala a galla\n \nafa a galla\n \nfa la glassa\n \nallaga la sala\n \nla daga a galla\n \nla daga falsa\n \nfalsa la glassa\n \nla glassa falsa\n \na galla\n \nsalga la falda\n \nfalla la daga\n \nsalga a galla\n \nla falsa daga\n \nfalla la glassa\n \nla falsa falla\n \nsalsa alla glassa\n \nalla sala falsa\n \nalga a galla\n \nalga salga a galla\n \nalga salga la falda\n \nalga allaga la sala\n \nfalsa alga\n \nfalsa saga\n \nla saga glassa\n \nla saga fa la glassa\n h \nha la salsa\n \nah la glassa\n \nha la daga\n \nha la falla\n \nha la daga falsa\n \nha la sala\n i \ni dadi lisi\n \nfili di giada\n \nsalsa gialla\n \nfiglia saggia\n \nfalsi saggi\n \ndadi di ghisa\n \nfila di gigli gialli\n \nfila di laghi\n \nla giada falsa\n \ni fidi asili\n \ni gigli gialli\n \nfila di ghiaia\n \nha dadi fissi\n \ni fili fissi\n \ni falsi affissi\n \nfalsi figli\n \nfalsi assilli\n \nfigli di faggi\n \nfigli di ghisa\n \ngli dissi\n \ni fili gialli\n \nghiaia gialla\n \nfaggi di laghi\n \nla dalia gialla\n \nhai falsi fili di giada\n o \nsoldi falsi\n \nla glassa fa gola\n \nloda la folla\n \nfilo di olio\n \nfalso saggio\n \nfoglia di faggio\n \ndado di ghisa\n \nodio il giglio\n \nsalgo da solo\n \nodia i fagioli\n \nloda la folla\n \nla sfoglia fa gola\n \nil figlio fa gola\n \nil figlio soffia\n \nodio i dadi\n \noggi ha lodato\n \nsaggia follia\n \nassaggia i fagioli\n \nha solo lodi\n \naglio o olio\n \ni soldi gialli\n \nsoldi falsi\n \nlodi di figlia\n \nil figlio sloggia\n \nil foglio giallo\n \nla foglia di faggio\n \nfilo giallo\n \nsalsa di olio\n \noggi ha solo fagioli\n e \nle foglie dei faggi\n \nsedie di faggio\n \nla sedia di ghisa\n \nle figlie fedeli\n \nle sedie delle figlie\n \negli ha fede\n \nleghe di ghisa\n \nle sedi delle leghe\n \nidea fedele\n \nseggio fisso\n \nle folli daghe\n \negli fa follie\n \ngiogo folle\n \nha delle false lodi\n \nle foglie folli\n \nil sole e la foglia\n \nella si siede\n \nse si sedesse\n \negli fa fallo\n \nsei sedie gialle\n \nle foglie al gelo\n \naghi e fili\n \nfile di foglie\n \noffesa dalle figlie\n \nlaghi al gelo\n \negli ha sei figlie\n \nle foglie gialle\n p \npalla di ghisa\n \nolio e seppie\n \npelle di pollo\n \nil pollo passa\n \ngli passo la palla\n \nsi posa la foglia\n \nseppie e pollo\n \ni passi folli\n \nolio a galla\n \nle spalle della sposa\n \nla palla galleggia\n \nla sedia di paglia\n \nil piede del figlio\n \nla sposa fedele\n \negli ha la pialla\n \negli ha la pila\n \nil poggiolo fisso\n \nil figlio pallido\n \ngiallo pallido\n \nla palla gialla\n \npila di fogli\n \npolpa di pollo\n \nla foglia di pioppo\n \npioppi e faggi\n \ndoppio fallo\n \nosso di seppia\n \nsalsa di pollo\n \nla pillola gialla\n r \nolio e lardo per friggere\n \nperdere la palla per il fallo\n \nle farfalle sopra i gigli\n \nfiori gialli tra le rose\n \nsaper perdere la gara\n \nil paggio del re\n \nera il regalo del re\n \norrore per il freddo\n \nfreddo e gelo alla sera\n \nil grosso pioppo\n \nera pallido e fragile\n \ndire delle frasi assai serie\n \nsorridere ai fiori\n \nsei di fiori\n \nle farfalle gialle\n \npresi dal desiderio\n \nfarsi pregare\n \nperdere a dadi\n \nfare dei progressi\n \nprogredire e salire\n \nil golf grigio perla\n \nfreddo polare\n \npregare di sera\n \npreferire fiori rari\n \nsedie di pregio\n \nsopra le pere\n \naria fresca\n \nferro e ghisa\n t \ntroppi grappoli nel piatto\n \nle proteste dei tifosi\n \nle trote del lago\n \nla grotta dei pipistrelli\n \ntrippe e fagioli\n \nlo sparo della pistola\n \negli le apre la porta\n \nil pregio del posto\n \nla serata era gelida\n \nfare delle ripide salite\n \npetrolio greggio\n \ntrasportare dei grossi sassi\n \nil fragile trasporto\n \nripido tratto di salita\n \ntradire per i soldi\n \nessere triste e poi lieto\n \nin attesa della paga\n \nla talpa sta sotto terra\n \nessere di fretta\n \nla trappola per i topi\n \nil tetto di paglia\n \nil posto di ristoro\n \nil gelato alla fragola\n \nla torta alle fragole\n \nlo stato estero\n \nera la stessa storia\n \nerrore di tiro\n \nil test era errato\n \nfuggire di sera\n \nil passato e il futuro\n \nil gusto di leggere\n \nautore del furto\n \nla lunga giostra\n \nil fusto del pioppo\n \nla foglia sulla strada\n u \nauto proprio lurida\n \nsei fedeli segugi\n \nluogo di preghiera\n \nera proprio tutta sudata\n \nera ladro e truffatore\n \nopera di autore russo\n \nperdere tutto ai dadi\n \ni trulli pugliesi\n \nsul fiore o sulla foglia\n \nil tratto superiore\n \nfreddo da lupi\n \nodio e furore\n \narresto per truffa\n \nprofugo dalla russia\n \ngruppo di pugili\n \nil luogo dei giusti\n \nresti di frustate alle spalle\n \nluoghi luridi e fetidi\n \nil prete e la suora\n \nle spalle sussultavano dal ridere\n \nil gufo sopra il tetto\n \npare che legga il futuro\n n \ntanti panni stesi\n \nun pugnale affilato\n \nfunghi saporiti\n \nlunghe file alle poste\n \nil ponte non regge\n \npolenta e funghi\n \nun lungo ponte\n \nlontano dalla gente\n \nuna nonna proprio generosa\n \nuna figlia gentile\n \nuna gustosa frittella\n \ndare in prestito\n \nun piede ingessato\n \nun testo assai interessante\n \nuna idea geniale\n \nun ingenuo figliolo\n \nun trucco infantile\n \nprendere tutto sul serio\n \nun pasto frugale\n \nuna pioggia assai fastidiosa\n \nnon aspettare in piedi\n \npantaloni tutti infangati\n \nuna alunna interessata\n \nlei non sta attenta\n \nun passerotto infreddolito\n \ninsoddisfatto del suo postino\n \nnon sentire niente\n c \nuno spettatore incredulo\n \ngiocare tutti a calcio\n \nuna ciocca di capelli\n \naccendere un cero in chiesa\n \nnon le piace accendere il fuoco\n \nleccare con gusto il gelato\n \nuna coppa di gelato al cacao\n \ncocciuto e ostinato\n \nchi prima rideva adesso piange\n \nun chiodo arrugginito\n \nun pericoloso incidente stradale\n \nfar cessare ogni eccesso\n \nun sincero confidente\n \ntu non sai cosa mi ha detto\n \nci piacciono le coscie di pollo\n \nun frastuono incessante\n \nil cappotto era fradicio per la pioggia\n \nun esercito di galline\n \npulisciti le orecchie\n \nfarsi una doccia calda\n \nstare con le orecchie tese\n \nnon nasconderti con la maschera\n \nchiedi le chiavi di casa\n \nchi ha un cruccio si sfoga\n \nandare a caccia di cinghiali\n \nil cagnolino sta nella cuccia\n \nsta a casa con gli orecchioni\n \ndei sacchi di ceci\n m \nuna macchia di inchiostro\n \nmi manda la mamma\n \nun mostro immondo\n \nama molto la mamma\n \nimmagina che giunga un mago\n \nuna camera da letto molto ampia\n \nmeglio imparare la matematica\n \nse hai male chiama il medico\n \nnon mi piace la medicina amara\n \nse ha miagolato non era una mucca\n \nse ha muggito non era un gatto\n \ndi studiare non le importa molto\n \namo molto la montagna\n \nun campo di mais e uno di frumento\n \nstare immersa nel mare\n \nscimmie ammaestrate al circo\n \nla scimitarra del sultano\n \nimpara a suonare il mandolino\n \nera partita con molti rimpianti\n \noccorre mettere ancora molto sale\n \nimmagina di stare meglio\n \nmolto rumore per nulla\n \nmille moscerini sulla macchina\n \nmangia maccheroni al sugo\n \nuna matita affilatissima\n \nla maschera di ferro\n \nmai dire mai\n \nmi tocca mangiare la minestra\n z \nporta fuori le immondizie\n \nmi piace molto la pizza\n \ngioca con pazienza e furbizia\n \nin piazza ci sono molte persone\n \nun fazzoletto con il pizzo\n \ndei mercanti in cerca di spezie\n \nera mezzo morto di paura\n \nnon era una piazza molto spaziosa\n \ndei pezzi di pesce molto puzzolenti\n \ngli si rizzavano i capelli in testa\n \nspezzava i rami con ogni mezzo\n \nun tizzone acceso nel caminetto\n \nera molto amato dalle zie\n \nmeglio la prudenza che la pazzia\n \nsi sente una puzza pazzesca\n \nla tazza si ruppe in mille pezzi\n \nsi azzuffano in mezzo alla piazza\n \nil mercato si fa in piazza\n \nla mazza da golf di mio zio\n \nandiamo pazzi per la pizza\n \nuna stanza spaziosa\n \nun mazzo di azalee\n \nuna pizza non mi sazia\n \ncon un colpo di mazza si spezza\n \nattenti al precipizio\n \nnon sempre il giusto sta nel mezzo\n q \nin questa scuola si studia molto\n \nacqua inquinata in molti fiumi\n \nun giocatore squalificato\n \nnon era questo il quaderno da portare\n \nsalire le scale quatto quatto\n \nerano quattro o cinque amici\n \nera proprio una questione da chiarire\n \nmi piacciono tutti i quiz\n \nricopiare tutto tale e quale\n \nun quintale di queste mele\n \nchiede solo acqua minerale frizzante\n \nesco dopo questo acquazzone\n \nuna questione di interesse\n \nsi era quasi addormentata\n \nun gesto inqualificabile\n \ntutto era quieto e silenzioso\n \nuscire per fare acquisti\n \nquindici persone qualsiasi\n \nil quattordici di luglio\n \nquarantaquattro gatti\n \nquando saremo in quattro\n \nun posto proprio tranquillo\n \nquattro quaderni a quadri\n \nuna questione di quiz\n \nquasi quasi mangio qui\n \npreferisco questa acqua\n \ncosta millecinquecento lire\n \nquasi un quintale di questi quaderni\n v \nun veloce avvio di gara\n \ncon la violenza si fa poca giustizia\n \nla tigre zoppica ma va a zonzo lo stesso\n \nmi serve un pezzo di legno\n \nsperava molto di vincere\n \ngli avvoltoi volano molto in alto\n \npensava spesso ai suoi vecchi amici\n \nstava sempre vicina al tavolo\n \nmettiti davanti al tavolino\n \nnon avvicinarti troppo al vetro\n \nraccontava delle storie avvincenti\n \nviveva da sola in una vecchia casa\n \nsapeva inventare storie stupende\n \naveva un cagnolino vivacissimo\n \nsperava di vincere alla lotteria\n \nera avvilita per non aver vinto nulla\n \nnevicava da vari giorni\n \nla vasca del parco era sempre vuota\n \nun velivolo velocissimo\n \nuna voce cavernosa\n \nrividi volentieri quel villaggio\n \ndevi diventare veloce nelle divisioni\n \nsul prato verde fiorivano le viole\n \nun avvenimento davvero unico\n \nnon avvicinarti al vulcano\n \ninvece di viola lo vorrei verde\n \nvendere vestiti vecchi\n \nun vasetto vuoto\n \nvoleva vincere almeno una volta\n \ncadeva spesso dal tavolo\n b \ndevi sviluppare bene questa vicenda\n \nbevi questa buona bibita\n \nera una brutta avventura\n \nbasta stare attenti alle buche\n \nun bravo burattino\n \nla bilancia era sbilenca\n \nnon buttare via i barattoli\n \nha imbucato il biglietto di auguri\n \nera molto abile con le biglie\n \ndevi sbucciare bene la banana\n \nnon mi piace il brodo bollente\n \ndeve andare ad abitare lontano\n \nla baracca era tutta bruciata\n \nattento alla buca vicino al burrone\n \nbere una bella tazza di latte\n \nottimi i biscotti con il burro\n \nun breve giro nel bosco\n \nun barattolo di colore blu\n \nsembra una bella idea cambiare aula\n \nun dolce di ribes e albicocche\n \nnon disturbare il babbo\n \nai bufali piace brucare erba fresca\n \nun brutto scambio\n \nera un imbianchino molto bravo\n \nbrontolava e borbottava sempre\n \nun albero di albicocche\n \nnon mi faccio imbrogliare\n \nera arrabbiata per quel brutto voto\n \nbianco rosso e blu\n \u00f2 \nand\u00f2 via di corsa\n \nnon si pu\u00f2 continuare a discutere\n \nsalt\u00f2 dal treno in corsa\n \narriv\u00f2 primo assoluto\n \nfren\u00f2 in ritardo\n \nnon si pu\u00f2 correre\n \ntogliti pure il palt\u00f2\n \naccese un bel fal\u00f2\n \nsi salvi chi pu\u00f2\n \nsi ferm\u00f2 e si gir\u00f2\n \nand\u00f2 a piedi fino a scuola\n \ntre civette sul com\u00f2\n \ngli tir\u00f2 un sasso addosso\n \nun albero croll\u00f2 di colpo\n \nil ramo si spezz\u00f2\n \nnon si pu\u00f2 continuare\n \nquanto prima finir\u00f2\n \nil campione salt\u00f2 e vinse\n \nsolo un giorno lo sopport\u00f2\n \nla barca salp\u00f2 ma non torn\u00f2\n \ndopo il naufragio non navig\u00f2 per due anni\n \nsalt\u00f2 al volo dal bus\n \nla nave aveva cento obl\u00f2\n \nnon parl\u00f2 con nessuno\n \nsalir\u00f2 fino al terzo piano\n \nnon si pu\u00f2 accendere qui un fal\u00f2\n \narriv\u00f2 un poliziotto e lo arrest\u00f2\n \u00e0 \nchiss\u00e0 quando arriver\u00e0\n \ncorreva di qua e di l\u00e0\n \nse frena si fermer\u00e0\n \ncerc\u00f2 sempre la libert\u00e0\n \npiet\u00e0 per i vinti\n \nchi vivr\u00e0 vedr\u00e0\n \nsuoner\u00e0 tutta la notte\n \nla felicit\u00e0 prima di tutto\n \nnon disprezz\u00f2 mai la povert\u00e0\n \nla libert\u00e0 non si vende mai\n \nandr\u00e0 in cerca della felicit\u00e0\n \nse non ti muovi nessuno ti aiuter\u00e0\n \nse vai l\u00e0 nessuno ti trover\u00e0\n \nnon mi d\u00e0 mai retta\n \nrider\u00e0 bene chi rider\u00e0 ultimo\n \nentr\u00f2 nella cavit\u00e0 del tronco\n \nquando lo sapr\u00e0 si pentir\u00e0\n \nuna enorme quantit\u00e0 di terra\n \naiutatemi per piet\u00e0\n \narriver\u00e0 in fine la felicit\u00e0\n \nuna penna di prima qualit\u00e0\n \nquesto letto ha poca elasticit\u00e0\n \nnon vincer\u00e0 mai la sua golosit\u00e0\n \nchi andr\u00e0 di qua chi di l\u00e0\n \nalla fine un eroe li salver\u00e0\n \nhai gi\u00e0 avuto due possibilit\u00e0\n \nera appeso alle estremit\u00e0\n \nuna macchina di grande utilit\u00e0\n \u00f9 \nnon ne posso pi\u00f9\n \nlass\u00f9 fa pi\u00f9 freddo\n \nle vere virt\u00f9 si notano poco\n \npi\u00f9 saliva e pi\u00f9 aveva paura\n \ncadde a testa in gi\u00f9\n \nchi pi\u00f9 ne ha pi\u00f9 ne metta\n \nerano andati tutti laggi\u00f9\n \nla virt\u00f9 della carit\u00e0\n \nlod\u00f2 le vere virt\u00f9\n \nuna poltrona di bamb\u00f9\n \nnon abita pi\u00f9 qui\n \nsalt\u00f2 pi\u00f9 in alto di te\n \nfacciamo una corsa fino a laggi\u00f9\n \nuna servit\u00f9 pesante\n \nerrori di giovent\u00f9\n \npescava con una canna di bamb\u00f9\n \npersona di grandi virt\u00f9\n \npi\u00f9 di qua che di l\u00e0\n \nil men\u00f9 del ristorante\n \ndiritto di servit\u00f9\n \nquass\u00f9 non si vede nulla\n \nviaggiare in treno mi piace di pi\u00f9\n \nnon credo che mentire sia una virt\u00f9\n \nla giovent\u00f9 non torna pi\u00f9\n \nvai gi\u00f9 e prendimi una bottiglia\n \nmi piace la musica ind\u00f9\n \nper fortuna la schiavit\u00f9 non esiste pi\u00f9\n \nstando gi\u00f9 si sentiva qualcosa di pi\u00f9\n \u00e8\u00e9 \n\u00e8 veramente adatto a te\n \n\u00e8 un buon caff\u00e8\n \nerano ventitr\u00e8 amici\n \nnon dirmi ma o cio\u00e8\n \ntrentatr\u00e8 trentini\n \nperch\u00e9 faceva tutto da s\u00e8?\n \nchi fa da s\u00e8 fa per tre\n \nnon \u00e8 bello stare a testa in gi\u00f9\n \n\u00e8 andato tutto bene\n \nsi \u00e8 fermato subito\n \nbench\u00e9 lo sapesse, non lo aiut\u00f2 mai\n \nquesto libro non \u00e8 per te\n \nchi \u00e8 stanco si fermi\n \nahim\u00e8 che disgrazia\n \nmi piacciono i bign\u00e8\n \nol\u00e8 ol\u00e8 gridavano al torero\n \npreparava un panino con il pan carr\u00e8\n \nci vediamo alle ore ventitr\u00e8 in punto\n \n\u00e8 ora di andare in casa\n \nbeviamo un buon caff\u00e8\n \n\u00e8 nato nel novantatr\u00e8\n \n\u00e8 meglio finire qui\n \nparlava tra s\u00e9 e s\u00e9\n \nil treno non \u00e8 in orario\n \nuna torta di bign\u00e8\n \n\u00e8 ora della pausa per il caff\u00e8\n \ngli piace fare tutto da s\u00e9\n \nnon \u00e8 il momento di dire sciocchezze\n \n\u00e8 un caff\u00e8 speciale\n \u00ec \npart\u00ec di corsa\n \nsal\u00ec le scale\n \nnon fin\u00ec mai il dipinto\n \nlavorava notte e d\u00ec\n \negli diceva sempre s\u00ec\n \nnon stare l\u00ec impalato\n \nci vediamo domani a mezzod\u00ec\n \nvieni via di l\u00ec\n \nla maestra pun\u00ec tre scolari\n \nnon era l\u00ec che dovevi andare\n \nsal\u00ec in casa a mezzod\u00ec\n \nnon riusc\u00ec a finire per mezzod\u00ec\n \nnon si sa come fin\u00ec la partita\n \nottima la lepre in salm\u00ec\n \nse spingi ancora non si sposta da l\u00ec\n \nil volo del colibr\u00ec\n \ndopo il luned\u00ec viene il marted\u00ec\n \nfin\u00ec alle nove o gi\u00f9 di l\u00ec\n \nstai attento se passi di l\u00ec\n \nfin\u00ec tutto in due minuti\n \nsta fermo cos\u00ec per qualche minuto\n \narriv\u00f2 gioved\u00ec a mezzod\u00ec\n \ndi sicuro non riusc\u00ec a farlo cos\u00ec\n \nsal\u00ec sulla torre e da l\u00ec lo vide partire\n \npart\u00ec gioved\u00ec con la nave\n \ncorri a vedere cosa fanno quelli l\u00ec\n \naspett\u00f2 l\u00ec da solo tutto il d\u00ec\n \nrispondimi s\u00ec o no\n , \nla cond\u00ec con olio, aceto e sale\n \nnon si pu\u00f2 perdere, bisogna vincere\n \nera, sembra, un vero artista\n \nsentiva, di sera, i grilli cantare\n \nchi rompe, dice il proverbio, paga\n \nera, a detta di molti, un vero affare\n \nsono partiti tutti, anche gli ammalati\n \nse piove, purtroppo, si bagna tutto\n \nnon \u00e8 vero, sono tutte bugie\n \nvai piano, la strada \u00e8 scivolosa\n \nse perdi, non arrabbiarti\n \nfiorirono rose, gigli e garofani\n \nstudio italiano, matematica e storia\n \nla notte, dicono, porta consiglio\n \nmi piace, in particolare, il suono del violini\n \nio preferisco venerd\u00ec, sabato e domenica\n \na scuola, lo sai, si viene per imparare\n \n\u00e8 bello, quando piove, starsene in casa\n \ntuoni, lampi, fulmini e saette\n \ncoraggio, mi dissi, devo farcela\n \na colazione mangio latte, biscotti e miele\n . \nsalta sul carro.\n \nattenti al lupo.\n \nla forza delle braccia.\n \nnon si pu\u00f2 sempre correre.\n \nattenti alle curve.\n \nla frutta fa bene.\n \nspegni la televisione.\n \nsuona bene il piano.\n \nera contento della sua maestra.\n \nun bel prato pieno di fiori.\n \nquando piove si sta bene in casa.\n \nnon posso pi\u00f9 uscire di sera.\n \nmi piace sentire la musica.\n \n\u00e8 finito il temporale.\n \nquel treno \u00e8 sempre in ritardo.\n \nvorrei invitare tutti per il mio compleanno.\n ' \nc'erano mele, pere, mandarini e pesche\n \nsuona bene l'armonica\n \nl'albergo era tutto esaurito\n \nera un'estate caldissima\n \nl'incontro \u00e8 andato bene\n \nsorpass\u00f2 l'avversario ed arriv\u00f2 primo\n \nl'aspetto era ottimo\n \nl'ospite \u00e8 ben gradito\n \nversare l'olio e l'aceto\n \n\u00e8 un'incredibile avventura\n \nera l'unica a stare attenta\n \n\u00e8 l'ideale dei giovani d'oggi\n \nnon c'\u00e8 spazio per l'inganno\n \nc'era molta fiducia in lui.\n \nla figlia l'amava moltissimo.\n \naveva un po' di fame.\n \nce l'aveva un po' con lei.\n \nc'\u00e8 dell'aranciata o dell'acqua fresca\n ShiftDestro \nDevi fare gli auguri a Sandra.\n \nArriveremo presto a Roma.\n \nAiuta Elena a fare i compiti.\n \nQuesto treno non va a Como.\n \nA Roma c'\u00e8 il Vaticano.\n \nEra il famoso colpo di Zorro.\n \nGiulio Cesare sconf\u00ecsse i Galli.\n \nVicenza \u00e8 una citt\u00e0 del Veneto.\n \nTutte le strade portano a Roma.\n \nFirenze si trova in Toscana.\n \nGiuseppe Verdi era un musicista.\n \nFranco abita a Enna, in Sicilia.\n \nLa Francia \u00e8 uno dei pi\u00f9 grandi stati d'Europa.\n \nGiorgio, Ernesto, Simone e Andrea verranno qui a dormire.\n ShiftSinistro \nIl Milione di Marco Polo.\n \nUn bel viaggio in India.\n \nLascia entrare prima Paola.\n \nLivorno \u00e8 vicina a Pisa.\n \nTra Verona e Padova c'\u00e8 Vicenza.\n \nUn amico di Luigi.\n \nGrosso incidente a Milano.\n \nUn nuovo palazzo a Napoli.\n \nOggi \u00e8 il compleanno di Laura.\n \nFreddo polare in Norvegia.\n \nL'autostrada \u00e8 interrotta a Udine.\n \nLa piet\u00e0 di Michelangelo.\n \nLa capitale della Francia \u00e8 Parigi.\n \nUn lungo viaggio in Libia e in Marocco\n Invio \nTroppa gente in questa festa.\n \nIl giardino, lo sai, \u00e8 ben curato.\n \nNon \u00e8 venuto a sentire il concerto.\n \nSpesso chi si lamenta sta bene.\n \nChiudi la finestra, ho freddo.\n \nOggi \u00e8 una bella giornata di sole.\n \nNon amo l'inverno, voglio il sole.\n \nOggi ho mangiato un buon pollo.\n \nDomenica andremo a trovare i nonni.\n \nSpero arrivi presto Natale.\n \nMi piace scrivere con il computer.\n \nAlla mattina ho sempre molto sonno.\n \nLa sera non voglio andare a letto.\n \nSuona il campanello, vai ad aprire.\n 7 \nIl 7 aprile vengo a trovarti.\n \nAlla corsa partecipano 77 concorrenti.\n \nQualcuno considera il 7 un numero perfetto.\n \nRivera giocava con la maglia numero 7.\n \nAlle superiori 7 era un bel voto.\n \nCon sole 7 note si possono fare tante musiche.\n \nAlla mattina mi alzo alle 7 per andare a scuola.\n \nPrende il treno delle 7 e un quarto.\n \nPer gli antichi 7 volte 7 era un'enormit\u00e0.\n \nAbita a 7 chilometri di distanza.\n \nUna frittata con 7 uova.\n \nUn numero di telefono facile da ricordare \u00e8 777777.\n \nRoma \u00e8 costruita su 7 colli.\n \nAlle 7 di sera ormai \u00e8 gi\u00e0 buio.\n 8 \nDopo il 7 viene il numero 8.\n \nLa tavola era preparata per 8 invitati.\n \nAbito in via Roma al numero 88.\n \nAlle 8 il traffico \u00e8 terribile.\n \nSembra piccolissimo ma ha 8 anni.\n \nNon so quanto valgano questi 8 dollari.\n \nQuesta canzone dura 8 minuti.\n \nUn libro di 78 pagine.\n \nSono le 7 e 8 minuti.\n \nMio pap\u00e0 \u00e8 alto un metro e 87 centimetri.\n \nIo dico che non pu\u00f2 tenere in casa 8 gatti.\n \nAlla fine della corsa sono arrivati solo in 8.\n \nDevo prendere l'autobus numero 88.\n \nHa preso 8 in storia e 7 in scienze.\n 9 \nDopo il numero 8 c'\u00e8 il 9.\n \nRipeti il numero 789.\n \nDa 9 anni non facevamo una festa cos\u00ec.\n \nDomani \u00e8 il 9 ottobre.\n \nUn palazzo di 9 piani.\n \nDomani alle 9 ti vengo a trovare.\n \nIl numero 89 \u00e8 maggiore di 79.\n \nMa 999999 non \u00e8 un milione.\n \nSe siamo solo in 9 non si gioca a calcio.\n \nUn cesto con 9 mele.\n \nUn pranzo con 9 portate.\n \nRicordati di telefonare al 799989\n \nDicono che un cane di 9 anni sia molto vecchio.\n \nHo 9 cugini e 8 zii.\n 0 \nIl numero zero si scrive 0.\n \nQuesta maglia costa 70.000 lire.\n \nIl famoso agente 007.\n \nDopo il numero 799 c'\u00e8 l'800.\n \nAnche questa partita \u00e8 finita 0 a 0.\n \nIl termometro \u00e8 sceso sotto 0.\n \nMi servono subito 900.000 lire.\n \nIl tavolo \u00e8 alto 90 centimetri.\n \nNon vendo a meno di 808.000 lire.\n \nC'erano 800 posti in quel teatro.\n \nIl Monte Everest \u00e8 alto pi\u00f9 di 8.000 metri.\n \nUna metropoli di 7.000.000 di abitanti.\n \nAnche se aveva 800 pagine l'ho letto tutto d'un fiato.\n \nQuesta rivista costa 8.700 lire.\n / \nSette noni ovvero 7/9.\n \nLa mia data di nascita \u00e8 09/07/99.\n \nDimmi se 8/9 \u00e8 maggiore di 7/8.\n \nLa barra \u00e8 sopra al numero 7.\n \nIl carattere barra si chiama anche segno di frazione.\n \n7/8, 77/88 e 777/888 sono tra loro equivalenti.\n \nIl carattere / viene usato anche come segno di divisione.\n () \n( \u00e8 il segno di aperta parentesi.\n \n) \u00e8 il segno di chiusa parentesi.\n \nIl Marco (moneta tedesca) vale circa 998 lire.\n \nVieri (Inter) ieri non ha segnato.\n \nHo un PC (Personal Computer) \u00e8 un po' vecchiotto.\n \nDalla mia casa (settimo piano) vedo tanti tetti.\n \nEra Marco (non Luigi) quello che hai incontrato ieri.\n \nMarcello (il maestro) oggi era molto contento.\n \nIl nonno compie gli anni (87) e faremo una bella festa.\n \nLa sua auto (una vecchia Fiat) non va pi\u00f9 bene.\n \nVieste (sul Gargano) ha un mare stupendo.\n  =\nIl simbolo di uguale \u00e8 =\n \n8=8 e 9=9\n \nIl tasto = \u00e8 sopra quello dello 0.\n \n7/8 = 77/88\n \nIl simbolo = significa uguale.\n \nNaturalmente 978=978 e 80=80.\n \nA volte si usa = anche per la divisione in sillabe.\n 6 \nEravamo in 6 amici.\n \nLa squadra di pallavolo \u00e8 composta di 6 giocatori.\n \nAbita al numero 66 di via Verdi.\n \nMi servono 6.000 lire.\n \nAprire il libro a pagina 86.\n \nHa vinto il giocatore con la maglia numero 6.\n \nIn maggio, il giorno 6, compie 6 anni.\n \nIl 6 gennaio arriva la Befana.\n \nDomenica il nonno compie 68 anni.\n \nQuesti spaghetti cuociono in 6 minuti.\n \nGli telefona 6 volte al giorno.\n \nTelefonami al numero 06 7866866.\n \nCi vorrebbe un 6 al SuperEnalotto.\n \nHa preso 6 e mezzo ma lui si aspettava almeno un 7.\n 5 \nUna moneta da 500 lire.\n \nUna banconota da 5.000 lire.\n \nDomani \u00e8 il 5 ottobre.\n \nPesa solo 55 chili.\n \nSe compi 5 anni ci vogliono 5 candeline.\n \nOgni 5 minuti suonava la sirena.\n \nSe siamo in 6, 5 sedie non bastano.\n \nChi indovina 5 numeri fa cinquina.\n \nHanno vinto 5 a 0, un vero trionfo.\n \nDevo cambiare questa banconota da 50.000 lire.\n \nCanale5 mi piace ma c'\u00e8 troppa pubblicit\u00e0.\n \nOgni giorno per allenarsi fa 5 chilometri di corsa.\n \nDomani mi alzo alle 5 per andare a pescare.\n \nAbita in via Roma al numero 5\n 4 \n44 gatti in fila per 6 con il resto di due.\n \n40 cani in fila per 4 con il resto di 0.\n \nA carte si gioca bene in 4.\n \nUn'automobile da 4 posti.\n \nNel vaso c'erano 4 rose rosse.\n \n444.444 \u00e8 un numero di telefono facile da ricordare.\n \n8 per 8 fa 64.\n \nMi servono 4 quaderni nuovi.\n \nLe 4 gambe del tavolo\n \nMio pap\u00e0 ha 44 anni.\n \nSi chiamano quadrupedi gli animali con 4 zampe.\n \nUn libro di 400 pagine.\n \nLe automobili hanno 4 ruote.\n \nUn paese di 540 abitanti.\n 3 \nI 3 moschettieri veramente erano 4.\n \nMi hanno regalato 3 dischi nuovi.\n \nCoi suoi piedoni usa scarpe numero 43.\n \n33 trentini trottavano verso Trento.\n \nIl 3 \u00e8 un numero importante.\n \nMolti mesi hanno 30 giorni.\n \nil 3 \u00e8 un numero dispari.\n \nL'autobus numero 3 \u00e8 appena passato.\n \nUna casetta con solo 3 finestre.\n \nIl triciclo ha 3 ruote.\n \nQui una bibita costa 3.000 lire.\n \nIn classe siamo quasi in 30.\n \nViene a casa mia oggi alle 3 e mezza.\n \nHa preso un pesce di oltre 3 chili.\n 2 \nIl 2 \u00e8 il primo numero pari.\n \nIl 25 dicembre si festeggia il Natale.\n \nUna moneta da 2.000 lire.\n \nMarco ha 2 fratelli e una sorella.\n \nMi servirebbero 200.000 lire.\n \nSe ve ne andate anche voi rimaniamo in 2.\n \nC'erano due passerotti sul ramo.\n \nUn cesto con 3 mele e 2 pere.\n \nAbbiamo 2 mani e 2 piedi.\n \nAbbiamo 2 occhi e 2 orecchie.\n \nAveva un'auto sportiva con soli 2 posti.\n \n42 gradi all'ombra, proprio un caldo insopportabile.\n \nIl viaggio in treno durava circa 2 ore e 20 minuti.\n \nIl tandem \u00e8 una bicicletta a 2 posti.\n 1 \nIl numero 1\n \nPer chiamare la polizia usa il 113.\n \nUn mezzo si pu\u00f2 scrivere anche 1/2.\n \nSappiamo che 7/7=1, 8/8=1 e 9/9=1.\n \nOggi \u00e8 il 12/10/1999.\n \nIl 10/06/1940 l'Italia entr\u00f2 in guerra.\n \nPer chiamare i carabinieri usa il 112.\n \nL'anno 1199 \u00e8 l'ultimo del secolo.\n \nGaribaldi e i suoi 1.000 garibaldini.\n \nUna moneta da 100 lire.\n \nA calcio si gioca in 11 per squadra.\n \nPersero la partita per 4 a 1\n \nCi vediamo alle 11 in punto.\n \nLa montagna era alta esattamente 3111 metri.\n \nNel 1918 fin\u00ec la prima guerra mondiale.\n \nMario \u00e8 nato 10/11/1991.\n \nArriv\u00f2 primo tra 191 concorrenti.\n \nAprite il libro a pagina 151.\n \" \nQuesto \u00e8 il simbolo delle virgolette \".\n \n\"Il dado \u00e8 tratto\" disse Cesare.\n \nIl suo soprannome era \"Stecchino\".\n \n\"Vieni subito qui\" disse la mamma.\n \nSi dice che \"Can che abbaia non morde\".\n \nIl tasto delle \" \u00e8 sopra a quello del 2.\n \nSul cancelletto era scritto \"Attenti al cane\".\n \n\"Stop\" grid\u00f2 il poliziotto, ma il ladro scapp\u00f2.\n \nDimmi che cosa vuol dire, secondo te, la parola \"amicizia\".\n ! \nFermi tutti!\n \nAiuto! Il leone \u00e8 scappato dalla gabbia!\n \nQuesto quadro \u00e8 meraviglioso!\n \nAh! Che splendida gita!\n \nBello! Veramente bello! Complimenti!\n \nBene! Bravo! Bis!\n \nEvviva Natale! La festa pi\u00f9 bella che ci sia!\n \nTanti auguri! Buon compleanno!\n + \nIl segno + indica l'addizione.\n \n12+4=16\n \nIl termometro segnava +2 gradi.\n \nSe sai quanto fa 5+5, rispondi!\n \n765.798 + 562.657 \u00e8 un numero troppo difficile per me!\n \nCalcola 1+3+7+4+9+2+5+8+6\n \nSe 12+45 fa 57, anche 45+12 fa 57.\n - \nIl segno - indica la sottrazione.\n \nIl segno - viene chiamato spesso \"meno\".\n \ncalcola 100-10\n \nChe freddo! Saranno -10 gradi!\n \nEcco una facile sottrazione 10-5.\n jJ \nLa lettera J si chiama anche i lunga.\n \nIl jet \u00e8 un aereo molto veloce.\n \nGennaro ha chiamato la figlia Jessica.\n \nScrivi Jules e Jim, non Giules e Gim.\n \nLa J \u00e8 la decima lettera dell'alfabeto.\n \nA pap\u00e0 piace moltissimo la musica jazz.\n \nQualcuno, per favore, chiami Jacopo.\n kK \nIl carattere k si chiama cappa.\n \nDigita il tuo nome prima di cliccare su OK.\n \nMi piacciono molto le merendine Kinder.\n \nLa K \u00e8 l'undicesima lettera dell'alfabeto.\n \nAlla sera giochiamo spesso a poker.\n \nQuando il pugile finisce KO, ha perso l'incontro.\n \nLa sigla \"CD\" significa \"Compact Disk\"\n \nIl disco fisso del computer si chiama anche Hard Disk.\n wW \nIl carattere w si chiama vu doppia.\n \nIl carattere W viene usato come segno di \"Evviva!\".\n \nIl programma \"Typing Trainer\" funziona in Windows.\n \nWelcome, vuol dire benvenuto.\n \nLa W \u00e8 la ventitreesima lettera dell'alfabeto.\n \nA me piacciono molto i kiwi.\n \nWater in inglese significa acqua.\n \nCome merenda Walter porta spesso dei wafer.\n xX \nLa lettera x si pronuncia ics.\n \nTuo pap\u00e0 porta la XL o la XXL.\n \nIeri ho mangiato dei pasticcini extra.\n \nNel totocalcio la X indica il pareggio.\n \nLa X \u00e8 la ventiquattresima lettera dell'alfabeto.\n \nNei numeri romani X significa dieci, XX venti.\n \nGiacomo mi ha spedito un fax di 4 pagine.\n yY \nLa lettera Y si chiama ipsilon o i greca.\n \nNew York \u00e8 famosa per i suoi grattacieli.\n \nPer ascoltare il CD, premi il pulsante \"Play\".\n \nLa Y \u00e8 la ventiquattresima lettera dell'alfabeto.\n \nMary mi ha regalato un bel yo-yo.\n & \nIl simbolo & si chiama \"e commerciale\".\n \nI famosi soci \"Frank & William\".\n \nIl supermercato A&O.\n \nLa famosa coppia Tom & Jerry.\n % \nIl simbolo % significa \"per cento\".\n \nUn prestito al 5% d'interessi.\n \nSono stati promossi al 100%.\n \nDire 50% \u00e8 come dire met\u00e0\n \nLe vittorie sono passate dal 44% al 78%.\n <> \nIl simbolo > significa \"maggiore\".\n \nSappiamo che 100 > 90.\n \nIl simbolo < significa \"minore\".\n \nNaturalmente 45 < 50.\n \nTutti i numeri <0 sono negativi.\n * \nIl segno * si chiama asterisco\n \nSpesso nei computer * \u00e8 il simbolo della moltiplicazione\n \nMettere *** significa non volere dire il nome.\n \nCalcola 4*3\n @ \nIl carattere @ si chiama \"chiocciola\"\n \nIl simbolo @ \u00e8 oggi molto usato negli indirizzi internet.\n \nQualcuno chiama @ \"at\", ovvero \"presso\".\n \nScrivimi all'indirizzo pinco.pallino@tin.it\n \nLa mia email \u00e8: garibaldi@libero.it\n \n@ si ottiene con Alt Gr e il tasto \u00f2\n # \nIl simbolo # si chiama cancelletto.\n \nIl simbolo # si chiama anche diesis.\n \nIl simbolo # non \u00e8 molto usato nei testi normali.\n \nPer ottenere il # deve usare il tasto Alt Gr.\n \n# si ottiene con Alt Gr e il tasto \u00e0.\n $ \nIl simbolo $ indica il dollaro.\n \nIl simbolo $ viene usato soprattutto in campo commerciale.\n \nPaperon de Paperoni ha come stemma il carattere $.\n \nIl simbolo $ si trova in tastiera sopra al 4.\n \nUna banconota da 100$\n \u00a3 \nIl simbolo \u00a3 indica la lira sterlina.\n \nIl simbolo \u00a3 viene anche usato per la lira italiana.\n \nSopra al numero 3 si trova il carattere \u00a3.\n \nUn assegno da \u00a3 2.000.000\n \\ \nNella tastiera c'\u00e8 anche il carattere \\.\n \nIl carattere \\ viene chiamato \"barra rovescia\"\n \nLe due barre, / e \\, sono tra loro simmetriche.\n \nIl tasto con il simbolo \\ si trova in alto a sinistra.\n \nIl simbolo \\ \u00e8 molto usato in DOS.\n _ \nIl carattere _ indica il trattino basso o sottolineato.\n \nIl carattere _ si trova sopra il trattino normale -.\n \nSi usa spesso _ per unire due parole.\n \nIl carattere _ non \u00e8 molto usato nei testi normali.\n [] \nLe parentesi quadre si indicano con [].\n \n[ \u00e8 la parentesi quadra aperta.\n \n] \u00e8 la parentesi quadra chiusa.\n \nLe parentesi [ e ] si usano spesso in matematica.\n \nCalcola: 4-[(6+3)/3]\n \nPer ottenere i caratteri [] si usa il tasto Alt Gr.\n \n[ si ottiene con Alt Gr e il tasto \u00e8\n \n] si ottiene con Alt Gr e il tasto +\n {} \nI simboli {} rappresentano le parentesi graffe.\n \nI simboli {} sono molto usati in matematica.\n \nPer ottenere il simbolo { si usa Ctrl Alt Shift e il tasto \u00e8\n \nPer ottenere il simbolo } si usa Ctrl Alt Shift e il tasto +\n \n{ \u00e8 la parentesi graffa aperta\n \n} \u00e8 la parentesi graffa chiusa\n : \nIl simbolo : \u00e8 detto \"due punti\"\n \nTrova l'errore: 12>10, 45<35, 41>27\n ; \nIl simbolo ; \u00e8 detto \"punto e virgola\"\n | \nIl simbolo | \u00e8 detto \"pipe\"\n ? \nIl simbolo ? si usa al termine delle frasi interrogative.\n ^ \nIl simbolo ^ si trova sopra alla lettera \u00ec.\n \u00a7 \nIl simbolo \u00a7 si trova sopra alla lettera \u00f9.\n \u00e7 \nIl carattere \u00e7 \u00e8 molto usato in francese.\n \u00b0 \nIl simbolo \u00b0 indica i gradi.";


// KEYBOARD MAPPING DICTIONARY (Italian QWERTY 105 Keys)
const KEY_MAP = {
  // Special multi-line keys (Enter & Tab)
  "®": { id: "key_enter", finger: 10, mod: "none", name: "Invio (Return)" },
  "\n": { id: "key_enter", finger: 10, mod: "none", name: "Invio (Return)" },
  "→": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione (Tab)" },
  "\t": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione (Tab)" },
  // Row 1
  "\\": { id: "key_backslash", finger: 1, mod: "none", name: "Backslash" },
  "|": { id: "key_backslash", finger: 1, mod: "shiftR", name: "Barra Verticale" },
  "1": { id: "key_1", finger: 1, mod: "none", name: "1" },
  "!": { id: "key_1", finger: 1, mod: "shiftR", name: "Punto Esclamativo" },
  "2": { id: "key_2", finger: 1, mod: "none", name: "2" },
  "\"": { id: "key_2", finger: 1, mod: "shiftR", name: "Virgolette" },
  "3": { id: "key_3", finger: 2, mod: "none", name: "3" },
  "£": { id: "key_3", finger: 2, mod: "shiftR", name: "Sterlina" },
  "4": { id: "key_4", finger: 3, mod: "none", name: "4" },
  "$": { id: "key_4", finger: 3, mod: "shiftR", name: "Dollaro" },
  "5": { id: "key_5", finger: 4, mod: "none", name: "5" },
  "%": { id: "key_5", finger: 4, mod: "shiftR", name: "Percentuale" },
  "6": { id: "key_6", finger: 4, mod: "none", name: "6" },
  "&": { id: "key_6", finger: 4, mod: "shiftR", name: "E Commerciale" },
  "7": { id: "key_7", finger: 7, mod: "none", name: "7" },
  "/": { id: "key_7", finger: 7, mod: "shiftL", name: "Slash" },
  "8": { id: "key_8", finger: 7, mod: "none", name: "8" },
  "(": { id: "key_8", finger: 7, mod: "shiftL", name: "Tonda Aperta" },
  "9": { id: "key_9", finger: 8, mod: "none", name: "9" },
  ")": { id: "key_9", finger: 8, mod: "shiftL", name: "Tonda Chiusa" },
  "0": { id: "key_0", finger: 9, mod: "none", name: "0" },
  "=": { id: "key_0", finger: 9, mod: "shiftL", name: "Uguale" },
  "'": { id: "key_quote", finger: 10, mod: "none", name: "Apostrofo" },
  "?": { id: "key_quote", finger: 10, mod: "shiftL", name: "Punto Interrogativo" },
  "`": { id: "key_quote", finger: 10, mod: "altgr", name: "Backtick" },
  "ì": { id: "key_igrave", finger: 10, mod: "none", name: "I Grave" },
  "^": { id: "key_igrave", finger: 10, mod: "shiftL", name: "Circonflesso" },
  "~": { id: "key_igrave", finger: 10, mod: "altgr", name: "Tilde" },

  // Row 2
  "q": { id: "key_q", finger: 1, mod: "none", name: "q" },
  "Q": { id: "key_q", finger: 1, mod: "shiftR", name: "Q" },
  "w": { id: "key_w", finger: 2, mod: "none", name: "w" },
  "W": { id: "key_w", finger: 2, mod: "shiftR", name: "W" },
  "e": { id: "key_e", finger: 3, mod: "none", name: "e" },
  "E": { id: "key_e", finger: 3, mod: "shiftR", name: "E" },
  "€": { id: "key_e", finger: 3, mod: "altgr", name: "Euro" },
  "r": { id: "key_r", finger: 4, mod: "none", name: "r" },
  "R": { id: "key_r", finger: 4, mod: "shiftR", name: "R" },
  "t": { id: "key_t", finger: 4, mod: "none", name: "t" },
  "T": { id: "key_t", finger: 4, mod: "shiftR", name: "T" },
  "y": { id: "key_y", finger: 7, mod: "none", name: "y" },
  "Y": { id: "key_y", finger: 7, mod: "shiftL", name: "Y" },
  "u": { id: "key_u", finger: 7, mod: "none", name: "u" },
  "U": { id: "key_u", finger: 7, mod: "shiftL", name: "U" },
  "i": { id: "key_i", finger: 8, mod: "none", name: "i" },
  "I": { id: "key_i", finger: 8, mod: "shiftL", name: "I" },
  "o": { id: "key_o", finger: 9, mod: "none", name: "o" },
  "O": { id: "key_o", finger: 9, mod: "shiftL", name: "O" },
  "p": { id: "key_p", finger: 10, mod: "none", name: "p" },
  "P": { id: "key_p", finger: 10, mod: "shiftL", name: "P" },
  "è": { id: "key_egrave", finger: 10, mod: "none", name: "e grave" },
  "é": { id: "key_egrave", finger: 10, mod: "shiftL", name: "e acuta" },
  "[": { id: "key_egrave", finger: 10, mod: "altgr", name: "Quadra Aperta" },
  "{": { id: "key_egrave", finger: 10, mod: "shiftAltgr", name: "Graffa Aperta" },
  "+": { id: "key_plus", finger: 10, mod: "none", name: "Più" },
  "*": { id: "key_plus", finger: 10, mod: "shiftL", name: "Asterisco" },
  "]": { id: "key_plus", finger: 10, mod: "altgr", name: "Quadra Chiusa" },
  "}": { id: "key_plus", finger: 10, mod: "shiftAltgr", name: "Graffa Chiusa" },
  "®": { id: "key_enter", finger: 10, mod: "none", name: "Invio" },
  "\n": { id: "key_enter", finger: 10, mod: "none", name: "Invio" },
  "→": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione" },
  "\t": { id: "key_tab", finger: 1, mod: "none", name: "Tabulazione" },

  // Row 3
  "a": { id: "key_a", finger: 1, mod: "none", name: "a" },
  "A": { id: "key_a", finger: 1, mod: "shiftR", name: "A" },
  "s": { id: "key_s", finger: 2, mod: "none", name: "s" },
  "S": { id: "key_s", finger: 2, mod: "shiftR", name: "S" },
  "d": { id: "key_d", finger: 3, mod: "none", name: "d" },
  "D": { id: "key_d", finger: 3, mod: "shiftR", name: "D" },
  "f": { id: "key_f", finger: 4, mod: "none", name: "f" },
  "F": { id: "key_f", finger: 4, mod: "shiftR", name: "F" },
  "g": { id: "key_g", finger: 4, mod: "none", name: "g" },
  "G": { id: "key_g", finger: 4, mod: "shiftR", name: "G" },
  "h": { id: "key_h", finger: 7, mod: "none", name: "h" },
  "H": { id: "key_h", finger: 7, mod: "shiftL", name: "H" },
  "j": { id: "key_j", finger: 7, mod: "none", name: "j" },
  "J": { id: "key_j", finger: 7, mod: "shiftL", name: "J" },
  "k": { id: "key_k", finger: 8, mod: "none", name: "k" },
  "K": { id: "key_k", finger: 8, mod: "shiftL", name: "K" },
  "l": { id: "key_l", finger: 9, mod: "none", name: "l" },
  "L": { id: "key_l", finger: 9, mod: "shiftL", name: "L" },
  "ò": { id: "key_ograve", finger: 10, mod: "none", name: "o grave" },
  "ç": { id: "key_ograve", finger: 10, mod: "shiftL", name: "c cediglia" },
  "@": { id: "key_ograve", finger: 10, mod: "altgr", name: "Chiocciola" },
  "à": { id: "key_agrave", finger: 10, mod: "none", name: "a grave" },
  "°": { id: "key_agrave", finger: 10, mod: "shiftL", name: "Gradi" },
  "#": { id: "key_agrave", finger: 10, mod: "altgr", name: "Cancelletto" },
  "ù": { id: "key_ugrave", finger: 10, mod: "none", name: "u grave" },
  "§": { id: "key_ugrave", finger: 10, mod: "shiftL", name: "Paragrafo" },

  // Row 4
  "<": { id: "key_less", finger: 1, mod: "none", name: "Minore" },
  ">": { id: "key_less", finger: 1, mod: "shiftR", name: "Maggiore" },
  "z": { id: "key_z", finger: 1, mod: "none", name: "z" },
  "Z": { id: "key_z", finger: 1, mod: "shiftR", name: "Z" },
  "x": { id: "key_x", finger: 2, mod: "none", name: "x" },
  "X": { id: "key_x", finger: 2, mod: "shiftR", name: "X" },
  "c": { id: "key_c", finger: 3, mod: "none", name: "c" },
  "C": { id: "key_c", finger: 3, mod: "shiftR", name: "C" },
  "v": { id: "key_v", finger: 4, mod: "none", name: "v" },
  "V": { id: "key_v", finger: 4, mod: "shiftR", name: "V" },
  "b": { id: "key_b", finger: 4, mod: "none", name: "b" },
  "B": { id: "key_b", finger: 4, mod: "shiftR", name: "B" },
  "n": { id: "key_n", finger: 7, mod: "none", name: "n" },
  "N": { id: "key_n", finger: 7, mod: "shiftL", name: "N" },
  "m": { id: "key_m", finger: 7, mod: "none", name: "m" },
  "M": { id: "key_m", finger: 7, mod: "shiftL", name: "M" },
  ",": { id: "key_comma", finger: 8, mod: "none", name: "Virgola" },
  ";": { id: "key_comma", finger: 8, mod: "shiftL", name: "Punto e Virgola" },
  ".": { id: "key_period", finger: 9, mod: "none", name: "Punto" },
  ":": { id: "key_period", finger: 9, mod: "shiftL", name: "Due Punti" },
  "-": { id: "key_minus", finger: 10, mod: "none", name: "Trattino" },
  "_": { id: "key_minus", finger: 10, mod: "shiftL", name: "Underscore" },

  // Row 5
  " ": { id: "key_space", finger: 5, mod: "none", name: "Spazio" }
};

const FINGER_NAMES = {
  1: "Mignolo Sinistro",
  2: "Anulare Sinistro",
  3: "Medio Sinistro",
  4: "Indice Sinistro",
  5: "Pollice Sinistro",
  6: "Pollice Destro",
  7: "Indice Destro",
  8: "Medio Destro",
  9: "Anulare Destro",
  10: "Mignolo Destro"
};

// RISOLUTORE ACCORDI TASTI (CHORD ENGINE v.1.4)
// Determina tasti bersaglio, modificatori e dita della mano libera da impegnare
function resolveTargetChord(char) {
  if (!char) return null;
  const info = KEY_MAP[char];
  if (!info) return null;

  const keyIds = [info.id];
  const fingers = [];
  const allowedMods = new Set();
  const isLeftHandBase = (info.finger >= 1 && info.finger <= 5);

  if (info.mod === "shiftR") {
    // Base su mano sinistra -> Shift destro (mano destra, Dito 10)
    keyIds.push("key_shift_r");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 10, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "shiftL") {
    // Base su mano destra -> Shift sinistro (mano sinistra, Dito 1)
    keyIds.push("key_shift_l");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 1, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "altgr") {
    if (!isLeftHandBase) {
      // Caratteri AltGr su mano destra (es. @, #, [, ], `, ~):
      // Didattica con mano libera (sinistra): Ctrl (dito 1) + Alt (dito 5)
      keyIds.push("key_ctrl_l", "key_alt_l");
      fingers.push({ finger: 1, label: "Ctrl" });
      fingers.push({ finger: 5, label: "Alt" });
      fingers.push({ finger: info.finger, label: char });
      // Sono ammesse sia la combinazione mano sinistra (Ctrl+Alt) sia AltGr (mano destra)
      allowedMods.add("Control");
      allowedMods.add("Alt");
      allowedMods.add("AltGraph");
    } else {
      // Carattere base su mano sinistra (es. € su 'e') -> AltGr (mano destra, dito 6)
      keyIds.push("key_altgr");
      fingers.push({ finger: info.finger, label: char });
      fingers.push({ finger: 6, label: "AltGr" });
      allowedMods.add("AltGraph");
      allowedMods.add("Control");
      allowedMods.add("Alt");
    }
  } else if (info.mod === "shiftAltgr") {
    // Accordi { e } (tasti è e + su mano destra):
    // Didattica con mano libera (sinistra): Ctrl (dito 1) + Shift (dito 2) + Alt (dito 5)
    keyIds.push("key_ctrl_l", "key_shift_l", "key_alt_l");
    fingers.push({ finger: 1, label: "Ctrl" });
    fingers.push({ finger: 2, label: "Shift" });
    fingers.push({ finger: 5, label: "Alt" });
    fingers.push({ finger: info.finger, label: char });
    // Sono ammesse sia mano sinistra (Ctrl+Alt+Shift) sia mano destra (AltGr+Shift)
    allowedMods.add("Control");
    allowedMods.add("Shift");
    allowedMods.add("Alt");
    allowedMods.add("AltGraph");
  } else {
    // mod === "none"
    let lbl = char;
    if (char === " " || info.name === "Spazio") lbl = "␣";
    else if (char === "®" || char === "\n" || info.name === "Invio") lbl = "↵";
    else if (char === "→" || char === "\t" || info.name === "Tabulazione") lbl = "⇥";
    else if (info.name && info.name.length <= 4) lbl = info.name;
    fingers.push({ finger: info.finger, label: lbl });
  }

  return { info, keyIds, fingers, allowedMods };
}



// AUDIO SYNTHESIZER (Web Audio API)
class AudioEngine {
  constructor() {
    this.ctx = null;
    this.mode = "typewriter"; // "beep", "typewriter", "mute"
    this.volume = 0.7;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  setMode(mode) { this.mode = mode; }
  setVolume(vol) { this.volume = Math.max(0, Math.min(1, vol)); }

  playKey() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    if (this.mode === "typewriter") {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(600 + Math.random() * 200, t);
      osc.frequency.exponentialRampToValueAtTime(100, t + 0.035);

      gain.gain.setValueAtTime(this.volume * 0.45, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.04);
    }
  }

  playError() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    if (this.mode === "beep") {
      // Classic electronic beep
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(440, t);
      gain.gain.setValueAtTime(this.volume * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.09);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + 0.09);
    } else {
      // Typewriter heavy mechanical error thud
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(160, t);
      osc.frequency.exponentialRampToValueAtTime(60, t + 0.12);
      gain.gain.setValueAtTime(this.volume * 0.65, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t);
      osc.stop(t + 0.13);
    }
  }

  playBell() {
    if (this.mode === "mute") return;
    this.init();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(2040, t);
    gain.gain.setValueAtTime(this.volume * 0.6, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.75);
  }
}

// PROFILE MANAGER (Multi-user isolation in LocalStorage)
class ProfileManager {
  constructor(initialAlbertoData, defaultCustomText) {
    this.STORAGE_KEY_USERS = "TFTT_USERS";
    this.STORAGE_KEY_ACTIVE = "TFTT_ACTIVE_USER";
    this.STORAGE_PREFIX = "TFTT_PROFILE_";
    this.initialAlbertoData = initialAlbertoData;
    this.defaultCustomText = defaultCustomText;
    this.activeUser = null;
    this.profile = null;
  }

  init() {
    let users = this.getUsers();
    if (!users || users.length === 0) {
      this.resetToDefaultArchive();
      users = this.getUsers();
    }
    return users;
  }

  resetToDefaultArchive() {
    const users = ["ALBERTO"];
    localStorage.setItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
    localStorage.setItem(this.STORAGE_KEY_ACTIVE, "ALBERTO");
    
    // Store Alberto's profile
    const albertoProf = {
      UserID: "ALBERTO",
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      HandsTop: 160,
      HandsLeft: 340,
      HandsWidth: 580,
      HandsHeight: 330,
      StatTop: 80,
      StatLeft: 180,
      CustomText: this.defaultCustomText,
      TotaleCaratteri: this.initialAlbertoData.TotaleCaratteri || 0,
      TotaleErrori: this.initialAlbertoData.TotaleErrori || 0,
      Caratteri: this.initialAlbertoData.Caratteri || [],
      Campioni: this.initialAlbertoData.Campioni || []
    };
    localStorage.setItem(this.STORAGE_PREFIX + "ALBERTO", JSON.stringify(albertoProf));
  }

  getUsers() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY_USERS);
      return data ? JSON.parse(data) : [];
    } catch(e) {
      return [];
    }
  }

  saveUsers(users) {
    localStorage.setItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
  }

  loadUser(userId) {
    const data = localStorage.getItem(this.STORAGE_PREFIX + userId);
    if (data) {
      try {
        this.profile = JSON.parse(data);
        this.activeUser = userId;
        localStorage.setItem(this.STORAGE_KEY_ACTIVE, userId);
        return this.profile;
      } catch(e) {
        console.error(e);
      }
    }
    return this.createUser(userId);
  }

  createUser(userId) {
    const trimmed = userId.trim();
    if (!trimmed) return null;
    const users = this.getUsers();
    if (!users.includes(trimmed)) {
      users.push(trimmed);
      this.saveUsers(users);
    }
    // New users start completely clean (isolated)
    this.profile = {
      UserID: trimmed,
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      HandsTop: 160,
      HandsLeft: 340,
      HandsWidth: 580,
      HandsHeight: 330,
      StatTop: 80,
      StatLeft: 180,
      CustomText: this.defaultCustomText,
      TotaleCaratteri: 0,
      TotaleErrori: 0,
      Caratteri: [],
      Campioni: []
    };
    this.activeUser = trimmed;
    localStorage.setItem(this.STORAGE_KEY_ACTIVE, trimmed);
    this.saveProfile();
    return this.profile;
  }

  deleteUser(userId) {
    let users = this.getUsers();
    users = users.filter(u => u !== userId);
    this.saveUsers(users);
    localStorage.removeItem(this.STORAGE_PREFIX + userId);
    if (this.activeUser === userId) {
      this.activeUser = null;
      this.profile = null;
      localStorage.removeItem(this.STORAGE_KEY_ACTIVE);
    }
  }

  saveProfile() {
    if (this.activeUser && this.profile) {
      localStorage.setItem(this.STORAGE_PREFIX + this.activeUser, JSON.stringify(this.profile));
    }
  }

  clearUserStats() {
    if (!this.profile) return;
    this.profile.TotaleCaratteri = 0;
    this.profile.TotaleErrori = 0;
    this.profile.Caratteri = [];
    this.profile.Campioni = [];
    this.saveProfile();
  }

  exportJson() {
    return JSON.stringify(this.profile, null, 2);
  }

  exportXml() {
    // Generate valid XML matching DataSetArchivio.xsd schema
    let xml = '<?xml version="1.0" standalone="yes"?>\n';
    xml += '<DataSetArchivio xmlns="http://Tastiera10Dita.org/DataSetArchivio.xsd">\n';
    const p = this.profile;
    xml += `  <Utenti d2p1:UserID="${p.UserID}" d2p1:Mode="${p.Mode}" d2p1:Lesson="${p.Lesson}" d2p1:Exercise="${p.Exercise}" d2p1:AutomaticCorrection="${p.AutomaticCorrection}" d2p1:ShowKeyBoard="${p.ShowKeyBoard}" d2p1:ShowHands="${p.ShowHands}" d2p1:ShowOrigin="${p.ShowOrigin}" d2p1:ShowTyped="${p.ShowTyped}" d2p1:MainTop="80" d2p1:MainLeft="180" d2p1:StatTop="${p.StatTop}" d2p1:StatLeft="${p.StatLeft}" d2p1:HandsTop="${p.HandsTop}" d2p1:HandsLeft="${p.HandsLeft}" xmlns:d2p1="http://Tastiera10Dita.org/DataSetArchivio.xsd">\n`;
    xml += `    <StatisticaUtente d2p1:TotaleCaratteri="${p.TotaleCaratteri}" d2p1:TotaleErrori="${p.TotaleErrori}">\n`;
    for (const c of p.Caratteri || []) {
      xml += `      <UnCarattere d2p1:Index="${c.Index}" d2p1:CharUnicode="${c.CharUnicode}" d2p1:Frequenza="${c.Frequenza}" d2p1:Errori="${c.Errori}" />\n`;
    }
    xml += '    </StatisticaUtente>\n';
    xml += '    <SequenzaCampioni>\n';
    for (const s of p.Campioni || []) {
      xml += `      <SeqCampioni d2p1:Index="${s.Index}" d2p1:BattuteMinuto="${s.BattuteMinuto}" d2p1:TipoCampione="${s.TipoCampione}" d2p1:NumCaratteri="${s.NumCaratteri}" d2p1:NumErrori="${s.NumErrori}" d2p1:Esercizio="${s.Esercizio || ''}" />\n`;
    }
    xml += '    </SequenzaCampioni>\n';
    xml += '  </Utenti>\n';
    xml += '</DataSetArchivio>';
    return xml;
  }
}

// MARKOVIAN PHONEME GENERATOR
class PhonemeEngine {
  constructor(corpus) {
    this.corpus = corpus || "";
    this.ngramLength = 4;
    this.targetLength = 100;
  }

  generate() {
    if (!this.corpus || this.corpus.length < 100) return "fa la sala fa la salsa salda la falla";
    let result = "";
    
    // 1. Pick a random word start
    const wordStartRegex = /\b([a-zA-Zàèéìòùç])/g;
    const starts = [];
    let match;
    while ((match = wordStartRegex.exec(this.corpus)) !== null) {
      starts.push(match[1]);
      if (starts.length > 500) break;
    }
    let currentPrefix = starts.length > 0 ? starts[Math.floor(Math.random() * starts.length)] : "s";
    result += currentPrefix;

    // 2. Walk Markov chain
    let safetyCounter = 0;
    while (result.length < this.targetLength && safetyCounter < 1000) {
      safetyCounter++;
      // Search occurrences of currentPrefix in corpus
      const searchPattern = currentPrefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(searchPattern + "([a-zA-Zàèéìòùç ])", "g");
      const nextChars = [];
      let m;
      let count = 0;
      while ((m = regex.exec(this.corpus)) !== null && count < 80) {
        nextChars.push(m[1]);
        count++;
      }
      
      let nextChar = " ";
      if (nextChars.length > 0) {
        nextChar = nextChars[Math.floor(Math.random() * nextChars.length)];
      } else {
        nextChar = starts[Math.floor(Math.random() * starts.length)] || " ";
      }

      // Avoid double space
      if (nextChar === " " && result.endsWith(" ")) {
        nextChar = starts[Math.floor(Math.random() * starts.length)] || "a";
      }

      result += nextChar;
      currentPrefix = (currentPrefix + nextChar);
      if (currentPrefix.length >= this.ngramLength) {
        currentPrefix = currentPrefix.slice(1);
      }
    }

    return result.trim().replace(/\s+/g, ' ');
  }
}


// WINDOW MANAGER (Draggable floating windows)
class WindowManager {
  constructor() {
    this.activeDrag = null;
    this.activeResize = null;
    this.startX = 0;
    this.startY = 0;
    this.initX = 0;
    this.initY = 0;
    this.initW = 0;
    this.initH = 0;
    this.isAbsoluteDrag = false;
    this.initGlobalEvents();
  }

  makeDraggable(windowElem, headerElem, onPositionChanged) {
    if (!windowElem || !headerElem) return;
    
    headerElem.addEventListener("mousedown", (e) => {
      if (e.target.closest("button") || windowElem.classList.contains("window-fullscreen")) return;
      this.activeDrag = windowElem;
      this.onPositionChanged = onPositionChanged;
      const isAbsolute = window.getComputedStyle(windowElem).position === "absolute";
      this.isAbsoluteDrag = isAbsolute;
      if (isAbsolute) {
        this.startX = e.pageX;
        this.startY = e.pageY;
        this.initX = windowElem.offsetLeft;
        this.initY = windowElem.offsetTop;
      } else {
        this.startX = e.clientX;
        this.startY = e.clientY;
        const rect = windowElem.getBoundingClientRect();
        this.initX = rect.left;
        this.initY = rect.top;
      }
      windowElem.style.zIndex = "1500";
    });
  }

  makeResizable(windowElem, onResized, minW = 520, minH = 360) {
    if (!windowElem) return;
    const handles = windowElem.querySelectorAll(".resize-handle");
    handles.forEach(h => {
      h.addEventListener("mousedown", (e) => {
        if (windowElem.classList.contains("window-fullscreen")) return;
        e.preventDefault();
        e.stopPropagation();
        const isAbsolute = window.getComputedStyle(windowElem).position === "absolute";
        this.activeResize = {
          elem: windowElem,
          dir: h.getAttribute("data-dir"),
          onResized: onResized,
          minW: minW,
          minH: minH,
          isAbsolute: isAbsolute
        };
        if (isAbsolute) {
          this.startX = e.pageX;
          this.startY = e.pageY;
          this.initX = windowElem.offsetLeft;
          this.initY = windowElem.offsetTop;
          this.initW = windowElem.offsetWidth;
          this.initH = windowElem.offsetHeight;
        } else {
          this.startX = e.clientX;
          this.startY = e.clientY;
          const rect = windowElem.getBoundingClientRect();
          this.initX = rect.left;
          this.initY = rect.top;
          this.initW = rect.width;
          this.initH = rect.height;
        }
        windowElem.style.zIndex = "1500";
      });
    });
  }

  initGlobalEvents() {
    window.addEventListener("mousemove", (e) => {
      // DRAG
      if (this.activeDrag) {
        if (this.isAbsoluteDrag) {
          const dx = e.pageX - this.startX;
          const dy = e.pageY - this.startY;
          let newX = Math.max(0, this.initX + dx);
          let newY = Math.max(0, this.initY + dy);
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        } else {
          const dx = e.clientX - this.startX;
          const dy = e.clientY - this.startY;
          let newX = Math.max(10, Math.min(window.innerWidth - this.activeDrag.offsetWidth - 10, this.initX + dx));
          let newY = Math.max(10, Math.min(window.innerHeight - this.activeDrag.offsetHeight - 10, this.initY + dy));
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        }
      }

      // RESIZE (8 Direzioni)
      if (this.activeResize) {
        const ar = this.activeResize;
        const currentX = ar.isAbsolute ? e.pageX : e.clientX;
        const currentY = ar.isAbsolute ? e.pageY : e.clientY;
        const dx = currentX - this.startX;
        const dy = currentY - this.startY;
        const dir = ar.dir;
        let newW = this.initW;
        let newH = this.initH;
        let newL = this.initX;
        let newT = this.initY;

        if (dir.includes("e")) {
          newW = Math.max(ar.minW, this.initW + dx);
        }
        if (dir.includes("s")) {
          newH = Math.max(ar.minH, this.initH + dy);
        }
        if (dir.includes("w")) {
          const maxLeftShift = this.initW - ar.minW;
          const shift = Math.min(maxLeftShift, dx);
          newW = this.initW - shift;
          newL = this.initX + shift;
        }
        if (dir.includes("n")) {
          const maxTopShift = this.initH - ar.minH;
          const shift = Math.min(maxTopShift, dy);
          newH = this.initH - shift;
          newT = this.initY + shift;
        }

        ar.elem.style.width = newW + "px";
        ar.elem.style.height = newH + "px";
        ar.elem.style.left = newL + "px";
        ar.elem.style.top = newT + "px";
        ar.elem.style.maxWidth = "none";
      }
    });

    window.addEventListener("mouseup", () => {
      if (this.activeDrag) {
        this.activeDrag.style.zIndex = "1000";
        this.activeDrag = null;
      }
      if (this.activeResize) {
        const ar = this.activeResize;
        ar.elem.style.zIndex = "1000";
        if (ar.onResized) {
          ar.onResized(ar.elem.offsetWidth, ar.elem.offsetHeight, ar.elem.offsetLeft, ar.elem.offsetTop);
        }
        this.activeResize = null;
      }
    });
  }
}

// TYPING ENGINE & STATE MACHINE
class TypingEngine {
  constructor(lessons, profileMgr, audio, phonemeEng) {
    this.lessons = lessons;
    this.profileMgr = profileMgr;
    this.audio = audio;
    this.phonemeEng = phonemeEng;

    // State
    this.mode = 0; // 0: Phrases, 1: Random, 2: Fonemi, 3: AllChars, 4: Typing, 5: RandomThisPhrase
    this.currentLessonIdx = 0;
    this.currentPhraseIdx = 0;
    this.originText = "";
    this.typedText = "";
    
    // Performance
    this.startTime = null;
    this.timerInterval = null;
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;

    // Cache Custom Phrases
    this.customPhrases = [];
    this.parseCustomText(profileMgr.profile ? profileMgr.profile.CustomText : "");
  }

  parseCustomText(rawText) {
    this.customPhrases = [];
    if (!rawText) return;
    const lines = rawText.split("\n");
    let currentTitle = "Custom";
    let currentPhrases = [];
    for (let line of lines) {
      line = line.trim();
      if (line.startsWith("=====") && line.endsWith("=====") && line.length > 10) {
        if (currentPhrases.length > 0) {
          this.customPhrases.push({ title: currentTitle, text: currentPhrases.join(" ") });
          currentPhrases = [];
        }
        currentTitle = line.slice(5, -5).trim();
      } else if (line === "=====") {
        if (currentPhrases.length > 0) {
          this.customPhrases.push({ title: currentTitle, text: currentPhrases.join(" ") });
          currentPhrases = [];
        }
      } else if (line) {
        currentPhrases.push(line.replace(/    /g, ' '));
      }
    }
    if (currentPhrases.length > 0) {
      this.customPhrases.push({ title: currentTitle, text: currentPhrases.join(" ") });
    }
    if (this.customPhrases.length === 0) {
      this.customPhrases.push({ title: "Custom Base", text: "prova digitazione custom file" });
    }
  }

  initSession() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.loadExercise();
  }

  startTimerIfNeeded() {
    if (!this.startTime) {
      this.startTime = new Date();
      this.lastKeystrokeTime = this.startTime;
      if (this.mode !== 4) {
        this.timerInterval = setInterval(() => this.updateMetrics(), 200);
      }
    }
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  resetSessionMetrics() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  resetTypingSession() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  loadExercise() {
    // Determine origin text based on mode
    if (this.mode === 0) {
      // Phrases Mode
      const lesson = this.lessons[this.currentLessonIdx] || this.lessons[0];
      const phrases = lesson.phrases || ["asdfl"];
      if (this.currentPhraseIdx >= phrases.length) this.currentPhraseIdx = 0;
      if (this.currentPhraseIdx < 0) this.currentPhraseIdx = phrases.length - 1;
      this.originText = phrases[this.currentPhraseIdx].replace(/®/g, ' ');
    } else if (this.mode === 1) {
      // Random Mode (20 chars, weighted on current lesson key)
      const currentLessonKey = this.lessons[this.currentLessonIdx].name;
      // Gather pool of all chars learned up to this lesson
      let pool = "";
      for (let i = 0; i <= this.currentLessonIdx; i++) {
        pool += this.lessons[i].name;
      }
      pool = pool.replace(/Spazio/g, ' ').replace(/ShiftDestro/g, 'QERTASDFGZCV').replace(/ShiftSinistro/g, 'UIOPHLBNM');
      if (pool.length === 0) pool = "asdf";
      
      let res = "";
      for (let i = 0; i < 20; i++) {
        // High probability of the new character
        if (Math.random() < 0.4 && currentLessonKey.length > 0 && currentLessonKey.length < 5) {
          res += currentLessonKey[Math.floor(Math.random() * currentLessonKey.length)];
        } else {
          res += pool[Math.floor(Math.random() * pool.length)];
        }
      }
      this.originText = res;
    } else if (this.mode === 2) {
      // Fonemi Mode
      this.originText = this.phonemeEng.generate();
    } else if (this.mode === 3) {
      // All Chars Mode
      const all = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZòùàìèé1234567890<>=+-*/()[]{}.,:;?!'^§\"|_@#ç°£$%&";
      let arr = all.split('');
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      this.originText = arr.slice(0, 50).join('');
    } else if (this.mode === 4) {
      // Typing Mode
      this.originText = "";
    } else if (this.mode === 5) {
      // Random This Phrase Mode
      if (this.originText) {
        let arr = this.originText.split('');
        for (let i = arr.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        this.originText = arr.join('');
      }
    }
  }

  handleKeyInput(charKey, isBack) {
    if (this.isCompleted) return;

    // TYPING MODE (Aggiornamento rigoroso alla battuta del tasto)
    if (this.mode === 4) {
      this.startTimerIfNeeded();
      this.lastKeystrokeTime = new Date();
      this.countTotalChars++;
      if (isBack) {
        this.countBackChars++;
        this.typedText = this.typedText.slice(0, -1);
      } else if (charKey.length === 1 || charKey === "\n" || charKey === "®") {
        this.audio.playKey();
        this.typedText += (charKey === "®" ? "\n" : charKey);
      }
      this.updateMetrics();
      return { status: "typing", typed: this.typedText };
    }

    // NORMAL EXERCISE MODES
    if (isBack) {
      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText = this.typedText.slice(0, -1);
        this.countBackChars++;
        this.updateMetrics();
        return { status: "back", typed: this.typedText };
      }
      return { status: "ignored" };
    }

    this.startTimerIfNeeded();
    this.countTotalChars++;
    const targetChar = this.originText[this.typedText.length];

    const isEnterTarget = (targetChar === "®" || targetChar === "\n");
    const isTabTarget = (targetChar === "→" || targetChar === "\t");
    const isEnterKey = (charKey === "Enter" || charKey === "\n" || charKey === "®");
    const isTabKey = (charKey === "Tab" || charKey === "\t" || charKey === "→");

    const isMatch = (charKey === targetChar) || (isEnterTarget && isEnterKey) || (isTabTarget && isTabKey);

    if (isMatch) {
      // RIGHT CHARACTER
      this.audio.playKey();
      this.typedText += charKey;
      this.recordCharStat(charKey, false);

      // Check completion (Punto 1: l'esercizio termina SOLO se tutti i caratteri corrispondono e non vi sono errori residui)
      const hasErrorsToCorrect = (this.typedText.length > 0 && this.typedText !== this.originText.slice(0, this.typedText.length));
      if (this.typedText.length === this.originText.length && !hasErrorsToCorrect) {
        this.isCompleted = true;
        this.stopTimer();
        this.audio.playBell();
        this.recordCompletedSample();
        this.updateMetrics();
        return { status: "completed", typed: this.typedText };
      }
      this.updateMetrics();
      return { status: "correct", typed: this.typedText, nextChar: this.originText[this.typedText.length] };
    } else {
      // WRONG CHARACTER
      this.audio.playError();
      this.countErrors++;
      if (targetChar) this.recordCharStat(targetChar, true);

      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText += charKey;
        this.updateMetrics();
        return { status: "error", typed: this.typedText, wrongChar: charKey, expectedChar: (targetChar || "⌫") };
      } else {
        // Auto correction: do not insert
        this.updateMetrics();
        return { status: "error-corrected", wrongChar: charKey, expectedChar: (targetChar || "⌫") };
      }
    }
  }

  recordCharStat(char, isError) {
    if (!char || typeof char !== "string" || char.length === 0) return;
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    p.TotaleCaratteri = (p.TotaleCaratteri || 0) + 1;
    if (isError) p.TotaleErrori = (p.TotaleErrori || 0) + 1;

    const ucode = char.charCodeAt(0);
    let item = (p.Caratteri || []).find(c => c.CharUnicode === ucode);
    if (!item) {
      item = { Index: (p.Caratteri || []).length, CharUnicode: ucode, Frequenza: 0, Errori: 0 };
      if (!p.Caratteri) p.Caratteri = [];
      p.Caratteri.push(item);
    }
    item.Frequenza++;
    if (isError) item.Errori++;
    this.profileMgr.saveProfile();
  }

  recordCompletedSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const rightChars = this.originText.length;
    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;
    
    // Sample types: 1: Phrases All, 2: Custom File, 3: Random, 4: Typing, 5: RandomThisPhrase, 6: All Chars, 7: Fonemi
    let stype = 1;
    if (this.mode === 0) stype = 1;
    else if (this.mode === 1) stype = 3;
    else if (this.mode === 2) stype = 7;
    else if (this.mode === 3) stype = 6;
    else if (this.mode === 4) stype = 4;
    else if (this.mode === 5) stype = 5;

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: stype,
      NumCaratteri: rightChars,
      NumErrori: this.countErrors,
      Esercizio: this.getCurrentExerciseTitle()
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
  }

  recordManualTypingSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const chars = this.typedText.length;
    if (chars === 0) return;
    const netBpm = minutes > 0 ? Math.round(chars / minutes) : 0;

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: 4, // Typing
      NumCaratteri: chars,
      NumErrori: this.countBackChars,
      Esercizio: "Free Typing"
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
    this.resetTypingSession();
  }

  getCurrentExerciseTitle() {
    if (this.mode === 0) return `Lezione ${this.currentLessonIdx + 1}: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 1) return `Random: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 2) return "Fonemi Italiani";
    if (this.mode === 3) return "All Chars";
    if (this.mode === 4) return "Digitazione Libera";
    if (this.mode === 5) return "Random This Phrase";
    return "";
  }

  getElapsedMinutes() {
    if (!this.startTime) return 0;
    if (this.mode === 4) {
      if (!this.lastKeystrokeTime) return 0;
      return (this.lastKeystrokeTime - this.startTime) / 60000;
    }
    return (new Date() - this.startTime) / 60000;
  }

  updateMetrics() {
    const minutes = this.getElapsedMinutes();
    const totalSecs = Math.floor(minutes * 60);
    const mm = String(Math.floor(totalSecs / 60)).padStart(2, '0');
    const ss = String(totalSecs % 60).padStart(2, '0');
    
    let rightChars = 0;
    if (this.mode === 4) {
      rightChars = this.typedText.length;
    } else {
      let i = 0;
      while (i < this.typedText.length && i < this.originText.length && this.typedText[i] === this.originText[i]) {
        i++;
      }
      rightChars = i;
    }

    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;
    const grossBpm = minutes > 0 ? Math.round(this.countTotalChars / minutes) : 0;
    const errCount = this.mode === 4 ? this.countBackChars : this.countErrors;
    const errPerc = rightChars > 0 ? ((errCount / rightChars) * 100).toFixed(1) : "0.0";

    const elTime = document.getElementById("txtTime");
    const elRight = document.getElementById("txtRightChars");
    const elNet = document.getElementById("txtRightEverage");
    const elGross = document.getElementById("txtTotalEverage");
    const elErr = document.getElementById("txtErrors");
    const elPerc = document.getElementById("txtPercErrors");

    if (elTime) elTime.innerText = `${mm}:${ss}`;
    if (elRight) elRight.innerText = rightChars;
    if (elNet) elNet.innerText = netBpm;
    if (elGross) elGross.innerText = grossBpm;
    if (elErr) elErr.innerText = errCount;
    if (elPerc) elPerc.innerText = `${errPerc}%`;

    // Fixing panel in Typing mode
    if (this.mode === 4) {
      const fixTime = document.getElementById("txtFixingTime");
      const fixNet = document.getElementById("txtFixingRightEverage");
      const fixGross = document.getElementById("txtFixingTotalEverage");
      if (fixTime) fixTime.innerText = `${mm}:${ss}`;
      if (fixNet) fixNet.innerText = netBpm;
      if (fixGross) fixGross.innerText = grossBpm;
    }
  }
}


// KEYBOARD & HANDS RENDERERS
class VisualRenderer {
  constructor() {
    this.currentTargetKey = null;
    this.currentModifierKey = null;
    this.activePhysicalKeys = new Map(); // keyId -> Array<{ finger: number, label: string }>
  }

  highlightTarget(char) {
    this.setTargetChar(char);
  }

  setTargetChar(char) {
    this.currentTargetChar = char;
    // Clear previous highlights
    document.querySelectorAll(".key.active-target").forEach(el => el.classList.remove("active-target"));
    document.querySelectorAll(".hand-finger.finger-active").forEach(el => el.classList.remove("finger-active"));
    for (let f = 1; f <= 10; f++) {
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }

    if (!char) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = "Tastiera e Mani a riposo";
      return;
    }

    const chord = resolveTargetChord(char);
    if (!chord) {
      const handText = document.getElementById("handIndicatorText");
      if (handText) handText.innerText = `Carattere: "${char}"`;
      return;
    }

    // Highlight all target keys on Keyboard
    chord.keyIds.forEach(id => {
      const keyEl = document.getElementById(id);
      if (keyEl) keyEl.classList.add("active-target");
    });

    // Highlight all target fingers on Hands SVG and set keycaps
    chord.fingers.forEach(fInfo => {
      const fingerEl = document.getElementById(`hand_finger_${fInfo.finger}`);
      if (fingerEl) fingerEl.classList.add("finger-active");
      
      const grp = document.getElementById(`hand_finger_keycap_group_${fInfo.finger}`);
      if (grp) grp.style.display = "inline";

      const tip = document.getElementById(`hand_finger_tip_${fInfo.finger}`);
      if (tip) tip.textContent = fInfo.label;

      const rect = document.getElementById(`hand_finger_keycap_rect_${fInfo.finger}`);
      if (rect) {
        const textLen = (fInfo.label || "").length;
        const origCx = parseFloat(rect.getAttribute("data-cx") || (parseFloat(rect.getAttribute("x")) + 29));
        const origCy = parseFloat(rect.getAttribute("data-cy") || (parseFloat(rect.getAttribute("y")) + 26));
        if (textLen > 2) {
          const w = Math.max(108, Math.round(textLen * 22.5 + 39));
          rect.setAttribute("width", w);
          rect.setAttribute("x", origCx - w / 2);
        } else {
          rect.setAttribute("width", 87);
          rect.setAttribute("x", origCx - 43.5);
        }
        rect.setAttribute("height", 78);
        rect.setAttribute("y", origCy - 39);
      }
    });

    const handText = document.getElementById("handIndicatorText");
    if (handText) {
      if (chord.fingers.length > 1) {
        const desc = chord.fingers.map(f => `${FINGER_NAMES[f.finger]} (${f.label})`).join(" + ");
        handText.innerText = `Accordo: ${desc}`;
      } else {
        handText.innerText = `${FINGER_NAMES[chord.info.finger]} → Tasto "${chord.info.name}"`;
      }
    }
  }

  updateCapsLockLed(isActive) {
    const capsEl = document.getElementById("key_caps");
    if (capsEl) {
      if (isActive) {
        capsEl.classList.add("caps-active");
      } else {
        capsEl.classList.remove("caps-active");
      }
    }
  }

  getKeyIdForEvent(keyOrChar, eventCode = null, eventLocation = null) {
    if (keyOrChar === "Tab") return "key_tab";
    if (keyOrChar === "CapsLock") return "key_caps";
    if (keyOrChar === "Backspace") return "key_backspace";
    if (keyOrChar === "Enter") return "key_enter";
    if (keyOrChar === "ContextMenu") return "key_menu";
    if (keyOrChar === " " || eventCode === "Space") return "key_space";
    if (keyOrChar === "Shift") {
      return (eventCode === "ShiftRight" || eventLocation === 2) ? "key_shift_r" : "key_shift_l";
    }
    if (keyOrChar === "Control") {
      return (eventCode === "ControlRight" || eventLocation === 2) ? "key_ctrl_r" : "key_ctrl_l";
    }
    if (keyOrChar === "Alt") {
      return (eventCode === "AltRight" || eventLocation === 2) ? "key_altgr" : "key_alt_l";
    }
    if (keyOrChar === "AltGraph") return "key_altgr";
    if (keyOrChar === "Meta" || keyOrChar === "OS") {
      return (eventCode === "MetaRight" || eventLocation === 2) ? "key_win_r" : "key_win_l";
    }

    if (KEY_MAP[keyOrChar]) {
      return KEY_MAP[keyOrChar].id;
    }
    const lower = keyOrChar.toLowerCase();
    if (KEY_MAP[lower]) {
      return KEY_MAP[lower].id;
    }
    if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const char = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[char]) return KEY_MAP[char].id;
      }
      if (eventCode.startsWith("Digit")) {
        const digit = eventCode.slice(5);
        if (KEY_MAP[digit]) return KEY_MAP[digit].id;
      }
    }
    return null;
  }

  setKeyPressed(keyOrChar, eventCode = null, eventLocation = null, isDown = true) {
    const keyId = this.getKeyIdForEvent(keyOrChar, eventCode, eventLocation);
    if (!keyId) return;
    const el = document.getElementById(keyId);
    if (el) {
      if (isDown) {
        el.classList.add("key-pressed");
      } else {
        el.classList.remove("key-pressed");
      }
    }
  }

  flashPressedKey(keyOrChar, eventCode = null, eventLocation = null) {
    this.setKeyPressed(keyOrChar, eventCode, eventLocation, true);
    setTimeout(() => this.setKeyPressed(keyOrChar, eventCode, eventLocation, false), 180);
  }

  adjustHandsViewport(width, height) {
    const svg = document.getElementById("handsSvg");
    const lblL = document.getElementById("lblLeftHand");
    const lblR = document.getElementById("lblRightHand");
    if (!svg) return;

    const w = Math.max(300, width);
    const h = Math.max(180, height);

    // Scala di riferimento per mantenere le mani invarianti senza scalarle
    const refScale = 1408 / 580; // ~2.428
    let vbW = Math.max(1060, Math.min(1408, Math.round(w * refScale)));
    let vbX = Math.round(704 - (vbW / 2));

    let vbH = Math.max(460, Math.min(768, Math.round(h * refScale)));
    let vbY = 20; // allineamento alla parte alta delle mani e dei tasti

    svg.setAttribute("viewBox", `${vbX} ${vbY} ${vbW} ${vbH}`);

    // Alza dinamicamente le scritte 'MANO SINISTRA' e 'MANO DESTRA' quando si riduce l'altezza per preservarle visibili
    const labelY = Math.min(730, Math.max(480, vbY + vbH - 30));
    if (lblL) lblL.setAttribute("y", labelY);
    if (lblR) lblR.setAttribute("y", labelY);
  }

  getFingersForPhysicalKey(keyOrChar, eventCode = null, eventLocation = null) {
    let fingers = [];
    if (keyOrChar === " " || eventCode === "Space") {
      fingers = [{ finger: 5, label: "SPAZIO" }];
    } else if (keyOrChar === "Enter" || eventCode === "Enter") {
      fingers = [{ finger: 10, label: "INVIO" }];
    } else if (keyOrChar === "Backspace" || eventCode === "Backspace") {
      fingers = [{ finger: 10, label: "⌫" }];
    } else if (keyOrChar === "Tab" || eventCode === "Tab") {
      fingers = [{ finger: 1, label: "TAB" }];
    } else if (keyOrChar === "Shift") {
      const f = (eventCode === "ShiftRight" || eventLocation === 2) ? 10 : 1;
      fingers = [{ finger: f, label: "SHIFT" }];
    } else if (keyOrChar === "Control") {
      const f = (eventCode === "ControlRight" || eventLocation === 2) ? 10 : 1;
      fingers = [{ finger: f, label: "CTRL" }];
    } else if (keyOrChar === "Alt") {
      const f = (eventCode === "AltRight" || eventLocation === 2) ? 6 : 5;
      fingers = [{ finger: f, label: (f === 6 ? "ALT GR" : "ALT") }];
    } else if (keyOrChar === "AltGraph") {
      fingers = [{ finger: 6, label: "ALT GR" }];
    } else if (keyOrChar === "CapsLock") {
      fingers = [{ finger: 1, label: "CAPS" }];
    } else if (keyOrChar && keyOrChar.length === 1) {
      // Punto 5: per i tasti fisici reali, assegna solo il dito reale del tasto premuto,
      // senza sintetizzare modificatori teorici (i modificatori fisici sono tracciati separatamente dai loro eventi)
      const lower = keyOrChar.toLowerCase();
      if (KEY_MAP[lower]) {
        fingers = [{ finger: KEY_MAP[lower].finger, label: keyOrChar.toUpperCase() }];
      } else if (KEY_MAP[keyOrChar]) {
        fingers = [{ finger: KEY_MAP[keyOrChar].finger, label: keyOrChar.toUpperCase() }];
      }
    } else if (eventCode) {
      if (eventCode.startsWith("Key")) {
        const ch = eventCode.slice(3).toLowerCase();
        if (KEY_MAP[ch]) {
          fingers = [{ finger: KEY_MAP[ch].finger, label: ch.toUpperCase() }];
        }
      } else if (eventCode.startsWith("Digit")) {
        const d = eventCode.slice(5);
        if (KEY_MAP[d]) {
          fingers = [{ finger: KEY_MAP[d].finger, label: d }];
        }
      }
    }
    return fingers;
  }

  setPhysicalKeyDown(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (!keyId) return;

    const fingers = this.getFingersForPhysicalKey(keyOrChar, eventCode, eventLocation);
    if (fingers.length === 0) return;

    this.activePhysicalKeys.set(keyId, fingers);
    this.renderActivePhysicalChord();
  }

  setPhysicalKeyUp(keyOrChar, eventCode = null, eventLocation = null) {
    const keyId = eventCode || keyOrChar;
    if (keyId) {
      this.activePhysicalKeys.delete(keyId);
    }
    if (keyOrChar && this.activePhysicalKeys.has(keyOrChar)) {
      this.activePhysicalKeys.delete(keyOrChar);
    }

    if (this.activePhysicalKeys.size > 0) {
      // Persistono ancora altri tasti dell'accordo: aggiorna visualizzazione
      this.renderActivePhysicalChord();
    } else {
      // Tutti i tasti dell'accordo sono stati rilasciati: disattiva le mani
      this.clearAllPhysicalFingers();
    }
  }

  renderActivePhysicalChord() {
    // Unione di tutte le dita coinvolte nell'accordo attualmente premuto
    const activeFingerMap = new Map(); // finger -> label

    // Punti 8 & 9: Rilevazione accordi mano sinistra
    let hasLeftCtrl = false;
    let hasLeftShift = false;
    let hasLeftAlt = false;

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        if (keyId === "ControlLeft" || keyId.startsWith("Control_ControlLeft") || (item.finger === 1 && item.label === "CTRL")) hasLeftCtrl = true;
        if (keyId === "ShiftLeft" || keyId.startsWith("Shift_ShiftLeft") || (item.finger === 1 && item.label === "SHIFT")) hasLeftShift = true;
        if (keyId === "AltLeft" || keyId.startsWith("Alt_AltLeft") || (item.finger === 5 && item.label === "ALT")) hasLeftAlt = true;
      }
    }

    for (const [keyId, fingerList] of this.activePhysicalKeys.entries()) {
      for (const item of fingerList) {
        let f = item.finger;
        let lbl = item.label;

        if (hasLeftCtrl && hasLeftShift) {
          if (keyId === "ShiftLeft" || keyId.startsWith("Shift_ShiftLeft") || (item.finger === 1 && lbl === "SHIFT")) {
            f = 2; // Punti 8 & 9: Anulare Sinistro (Dito 2) per SHIFT quando premuto con CTRL
          } else if (keyId === "ControlLeft" || keyId.startsWith("Control_ControlLeft") || (item.finger === 1 && lbl === "CTRL")) {
            f = 1; // Punti 8 & 9: Mignolo Sinistro (Dito 1) per CTRL
          }
        }
        if (hasLeftAlt && (keyId === "AltLeft" || keyId.startsWith("Alt_AltLeft") || lbl === "ALT")) {
          f = 5; // Punto 9: Pollice Sinistro (Dito 5) per ALT
        }
        activeFingerMap.set(f, lbl);
      }
    }

    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      const rect = document.getElementById(`hand_finger_keycap_rect_${f}`);

      if (activeFingerMap.has(f)) {
        const label = activeFingerMap.get(f);
        if (fingerEl) fingerEl.classList.add("finger-active");
        if (grp) grp.style.display = "inline";
        if (tip) tip.textContent = label;

        if (rect) {
          const textLen = (label || "").length;
          const origCx = parseFloat(rect.getAttribute("data-cx") || "215");
          const origCy = parseFloat(rect.getAttribute("data-cy") || "340");
          if (textLen > 2) {
            const w = Math.max(108, Math.round(textLen * 22.5 + 39));
            rect.setAttribute("width", w);
            rect.setAttribute("x", origCx - w / 2);
          } else {
            rect.setAttribute("width", 87);
            rect.setAttribute("x", origCx - 43.5);
          }
          rect.setAttribute("height", 78);
          rect.setAttribute("y", origCy - 39);
        }
      } else {
        if (fingerEl) fingerEl.classList.remove("finger-active");
        if (grp) grp.style.display = "none";
        if (tip) tip.textContent = "";
      }
    }
  }

  clearAllPhysicalFingers() {
    this.activePhysicalKeys.clear();
    for (let f = 1; f <= 10; f++) {
      const fingerEl = document.getElementById(`hand_finger_${f}`);
      if (fingerEl) fingerEl.classList.remove("finger-active");
      const grp = document.getElementById(`hand_finger_keycap_group_${f}`);
      if (grp) grp.style.display = "none";
      const tip = document.getElementById(`hand_finger_tip_${f}`);
      if (tip) tip.textContent = "";
    }
    // Punto 10: Se e in corso un esercizio guidato, ripristina all'istante l'accordo target corrente
    if (this.currentTargetChar && window.app && window.app.typingEng && window.app.typingEng.mode !== 4 && !window.app.typingEng.isCompleted) {
      this.setTargetChar(this.currentTargetChar);
    }
  }

  // Metodi di compatibilità retroattiva
  showPressedFingers(keyOrChar, eventCode = null, eventLocation = null) {
    this.setPhysicalKeyDown(keyOrChar, eventCode, eventLocation);
  }

  clearPressedFingers() {
    this.clearAllPhysicalFingers();
  }
}

