# Architettura — TenFingersTypingTrainer v6.23

## Obiettivo

La release v6.23 introduce interventi architetturali mirati a ripristinare la robustezza strutturale del Document Object Model (DOM) e a perfezionare l'ergonomia visiva e interattiva della finestra di dialogo di configurazione della dettatura vocale (`#dictationConfigModal`):
1. **Risoluzione della rottura dell'albero DOM e isolamento delle finestre modali**: eliminazione della nidificazione spuria tra la finestra di configurazione dettatura e la finestra di gestione utenti (`#loginModal`), ripristinando l'indipendenza e l'immediata reattività di entrambi i controlli;
2. **Architettura a 3 fasce con TitleBar fissa e Footer ancorato**: ristrutturazione del layout dialog in un contenitore flex verticale con testata fissa, barra dei comandi di chiusura e conferma stabilmente ancorata in calce e area centrale dei parametri dotata di scrollbar indipendente;
3. **Ridimensionamento verticale flessibile e vincolato (Altezza da 420px a 92vh)**: implementazione di maniglie di trascinamento bidirezionali sui bordi superiore (`.rh-n`) e inferiore (`.rh-s`), garantendo che il dialog mantenga il perfetto allineamento centrato nel viewport durante l'estensione o contrazione;
4. **Flusso di conferma esplicito e protezione contro modifiche accidentali**: netta separazione logica tra il ripristino visivo dei valori consigliati (`↺ Default`) e la loro effettiva persistenza nel profilo (`Salva`), con scarto immediato di ogni dato non confermato tramite `Annulla`, `Esc` o pulsante di chiusura `x`.

---

## Dettaglio dei Requisiti e Soluzioni Architetturali

### 1. Risoluzione della Rottura Strutturale DOM e Isolamento Modale

#### Analisi della Causa Radice
Nelle release precedenti, all'interno del blocco `#dictationConfigModal`:
* La sezione `<div id="dictationAdaptiveSettingsGroup">` (riga 3724 di `index.html`) conteneva il blocco di impostazione della velocità massima (`<div>`, riga 3768), privo del rispettivo tag di chiusura `</div>`.
* Anche il contenitore `dictationAdaptiveSettingsGroup` risultava privo del rispettivo tag di chiusura prima della successiva sezione sui tempi di inattività (`dictationTimingSettingsGroup`).
* Di conseguenza, i tag di chiusura `</div>` posizionati in fondo alla modale andavano a chiudere prematuramente questi blocchi interni non terminati, lasciando aperti nel DOM sia `.modal-dialog` che l'overlay radice `#dictationConfigModal`.
* Il browser interpretava quindi tutte le modali successive — in particolare `<div id="loginModal" class="modal-overlay">` e `<div id="zoomHelpModal" class="modal-overlay">` — come **nodi figli nidificati all'interno di `#dictationConfigModal`**.

#### Effetto Anomalo a Runtime
1. Cliccando su *"Utenti"*, il controller aggiungeva la classe `.active` a `#loginModal` (`display: flex`). Tuttavia, poiché il suo contenitore genitore `#dictationConfigModal` era nascosto (`display: none`), il browser non renderizzava alcun pixel.
2. Cliccando successivamente su *"Config."*, `#dictationConfigModal` riceveva la classe `.active` (`display: flex`). Rendendosi visibile il genitore, si rendeva visibile anche il figlio `#loginModal` già precedentemente attivato: con `position: fixed; inset: 0; backdrop-filter: blur(2px)`, quest'ultimo oscurava e sfuocava la finestra di configurazione dettatura, mostrandosi in primo piano in modo inatteso.

#### Correzione Production-Ready
* Inseriti i tag di chiusura `</div>` mancanti al termine della Sezione 2;
* Chiusi regolarmente il corpo scrollabile, il footer, il dialog e la modale `#dictationConfigModal` prima della dichiarazione di `#loginModal`;
* Ripristinata la topologia ad elementi fratelli indipendenti di primo livello nel DOM per tutte le modali di sistema.

---

### 2. Architettura a 3 Fasce (Sticky Header / Sticky Footer / Scrollable Body)

Per risolvere il difetto in cui la barra di scorrimento coinvolgeva l'intero dialog facendo scomparire la TitleBar e occultando il pulsante "Salva", il contenitore `#dictationConfigDialog` è stato riprogettato secondo il pattern a tre fasce flexbox:

1. **TitleBar Fissa (`#dictationConfigHeader`)**:
   - `flex: 0 0 auto;`
   - Bordo inferiore separatore e sfondo opaco superficiale coerente con il tema (`--surface-color`);
   - Titolo formale ed ergonomico a sinistra e pulsante di chiusura a 26 pixel ("x") a destra.
2. **Body Centrale Scrollabile (`#dictationConfigBody`)**:
   - `flex: 1 1 auto; overflow-y: auto;`
   - Racchiude tutte le sezioni di configurazione: Attivazione Dettatura Adattiva Dinamica, Soglie CPM, Tempi di Inattività e Prevenzione Troncamento Vocale, Box Formule Didattico;
   - All'apertura della modale viene garantito l'azzeramento della posizione di scorrimento (`scrollTop = 0`).
3. **Footer Fisso Ancorato (`.modal-footer`)**:
   - `flex: 0 0 auto;`
   - Bordo superiore separatore e sfondo superficiale opaco;
   - Pulsanti sempre visibili senza necessità di scorrimento:
     - `↺ Default (100 CPM, 200 CPM, 1,5s)` a sinistra;
     - `Annulla` e `Salva` raggruppati a destra.

---

### 3. Ridimensionamento Verticale Bidirezionale e Vincolato

In accordo con i vincoli espressi:
* La finestra **non è traslabile** e si mantiene sempre ancorata al centro del viewport (`.modal-overlay` con `display: flex; align-items: center; justify-content: center;`);
* Sono integrate due maniglie di ridimensionamento verticale:
  * Maniglia bordo superiore: `<div class="resize-handle rh-n" data-dir="n"></div>` (cursore `n-resize`);
  * Maniglia bordo inferiore: `<div class="resize-handle rh-s" data-dir="s"></div>` (cursore `s-resize`).
* **Formula geometrica di tracciamento proporzionale**:
  Poiché il dialog è mantenuto centrato dal flexbox lungo l'asse verticale (`Y_centro = Finestra_Altezza / 2`), quando il cursore si sposta di una distanza `dy`, per mantenere il bordo afferrato esattamente coincidente con il cursore del mouse, l'altezza complessiva viene modulata con la formula:
  `NuovaAltezza = AltezzaIniziale + (activeDir == "s" ? dy : -dy) * 2`
* **Limiti di sicurezza invalicabili**:
  - Altezza minima: 420 pixel (garantisce visibilità di TitleBar, Footer e almeno una sezione operativa centrale senza compressione eccessiva);
  - Altezza massima: 92% dell'altezza del viewport (`92vh`), prevenendo qualunque overflow oltre i bordi dello schermo.
* L'espansione e la contrazione agiscono unicamente sull'altezza del body scrollabile centrale (`flex: 1 1 auto`), lasciando TitleBar e Footer perfettamente ancorati.

---

### 4. Flusso di Conferma e Persistenza

* **Pulsante `↺ Default`**: reimposta i valori raccomandati (`100 CPM`, `200 CPM`, `1,5 secondi` base, `3,5 secondi` esteso, `1,0` fattore modulazione, dettatura adattiva attiva) esclusivamente all'interno dei campi di input e range della finestra. **Nessun salvataggio viene effettuato nel profilo utente** né applicato al motore di dettatura fino alla pressione esplicita di Salva.
* **Pulsante `Salva` (`#btnConfirmDictationConfig`)**: valida i campi, applica le nuove soglie all'istanza runtime di `DictationEngine` e le persiste in modo permanente nel profilo attivo via `ProfileManager.saveProfile()`.
* **Annullamento (`Annulla`, `Esc`, pulsante `x`)**: chiude immediatamente la modale senza salvare. Alla successiva riapertura, il metodo `openDictationConfigModal()` ricarica fedelmente i valori salvati nel profilo corrente, scartando qualsiasi modifica non confermata.
