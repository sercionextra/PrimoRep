# Architettura TenFingersTypingTrainer v6.55

Documento di aggiornamento architetturale rispetto alla v6.54.

## 1. Obiettivo della Release v6.55
1. Risolvere la perdita dei colori di modalità dei campioni nel grafico delle velocità alla de-selezione (o durante la sostituzione di una selezione precedente).
2. Aggiungere il pulsante contestuale **"Filtra Periodo Selezione"** (`#btnFilterToSelection`) per impostare automaticamente il range Data/Ora sui campioni selezionati.

## 2. Interventi Architetturali
1. **Ripristino cromatico in `clearSelection()` e `applySelection()` (`js/analytics/statistics-manager.js`):**
   - Sostituito il `fill` fisso `#3b82f6` con `this.getSampleTypeColor(parseInt(dot.getAttribute("data-type"), 10))`.
   - Ripristinati `stroke="none"` e `stroke-width="0"` sui punti non selezionati e de-selezionati, mantenendo `stroke="#ffffff"` e `stroke-width="1.5"` sui punti selezionati.
2. **Filtro temporale da selezione (`js/analytics/statistics-manager.js`, `js/app/controller/metodi-statistiche.js`, `index.html`, `assets/styles/app.css`):**
   - Aggiunto `applySelectionDateTimeRange()` in `StatisticsManager`: calcola `minTs` e `maxTs` tra i `DataOra` validi dei campioni in `selectedSampleIndices`, valorizza `#filterStartDate`, `#filterStartTime` (`HH:mm`), `#filterEndDate` e `#filterEndTime` (`HH:mm`), invoca `clearSelection()` e `renderSpeedChart()`.
   - Aggiunto `#btnFilterToSelection` in `.stats-selection-actions-slot` (`visibility: hidden` a riposo, `visibility: visible` quando `selPts.length > 0`).
