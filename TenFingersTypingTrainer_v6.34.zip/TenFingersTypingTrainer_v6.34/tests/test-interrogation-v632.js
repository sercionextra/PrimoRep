/* Test unitari v6.32: verifica getKeyExtension su landmark click, ordine controlli Blocco 1 e chiusura con showAlert su Concludi/Sospendi/Abbandona. */
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

function loadScript(ctx, relPath) {
  const full = path.join(__dirname, "..", relPath);
  const code = fs.readFileSync(full, "utf8");
  vm.runInContext(code, ctx, { filename: full });
}

async function runTests() {
  const alerts = [];
  let closedCount = 0;

  const domElements = new Map();
  const makeMockEl = (tag, id = "") => ({
    tagName: tag.toUpperCase(),
    id,
    value: "",
    type: "",
    disabled: false,
    checked: false,
    innerHTML: "",
    textContent: "",
    className: "",
    classList: {
      _set: new Set(),
      add(c) { this._set.add(c); },
      remove(c) { this._set.delete(c); },
      toggle(c, force) {
        if (force === undefined) {
          if (this._set.has(c)) this._set.delete(c);
          else this._set.add(c);
        } else if (force) this._set.add(c);
        else this._set.delete(c);
      },
      contains(c) { return this._set.has(c); },
    },
    children: [],
    appendChild(ch) { this.children.push(ch); },
    addEventListener() {},
    querySelectorAll() { return []; },
  });

  const ctx = vm.createContext({
    console,
    Date,
    Math,
    Set,
    Map,
    Array,
    Object,
    String,
    Number,
    JSON,
    Promise,
    Error,
    parseInt,
    parseFloat,
    isNaN,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    crypto: require("crypto").webcrypto,
    document: {
      getElementById: (id) => domElements.get(id) || null,
      createElement: (tag) => makeMockEl(tag),
      querySelectorAll: () => [],
    },
  });
  ctx.window = ctx;
  ctx.globalThis = ctx;

  loadScript(ctx, "js/data/interrogation-catalog-data.js");
  loadScript(ctx, "js/interrogation/interrogation-prng.js");
  loadScript(ctx, "js/interrogation/interrogation-layout-metadata.js");
  loadScript(ctx, "js/interrogation/interrogation-catalog.js");
  loadScript(ctx, "js/interrogation/interrogation-knowledge.js");
  loadScript(ctx, "js/interrogation/interrogation-selector.js");
  loadScript(ctx, "js/interrogation/interrogation-repository.js");
  loadScript(ctx, "js/interrogation/interrogation-session-manager.js");
  loadScript(ctx, "js/ui/interrogation-ui.js");

  const catalog = new ctx.InterrogationCatalog();
  const repository = new ctx.InterrogationRepository({ forceMemory: true });
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository });

  const ui = new ctx.InterrogationUI({
    sessionManager: mgr,
    catalog,
    showAlert: (msg, title) => alerts.push({ msg, title }),
  });
  ui.close = () => { closedCount++; };
  ui.runSvg = {
    highlightFingerOnHands() {},
    renderKeycapPreview() {},
    highlightTargetLandmark() {},
    revealKey() {},
  };

  // 1. Verifica ordine controlli Blocco 1 e landmark click con getKeyExtension
  const panelEl = makeMockEl("div", "interrInteractivePanel");
  ui._renderCharacterQuestionPanel(panelEl, { questionType: "CARATTERE", fingerId: "4" }, "q", "key_q");

  const grid = panelEl.children[0];
  const blk1 = grid.children[0];
  const form1 = blk1.children[1];
  const leftCol = form1.children[0];
  const rightCol = form1.children[1];

  const leftLabels = leftCol.children.map((r) => r.children[0].textContent);
  assert.deepStrictEqual(leftLabels, [
    "Mano:",
    "Dito:",
    "Direzione sovraccarico:",
    "Estensione laterale:",
  ]);
  assert.strictEqual(rightCol.children[0].children[0].textContent, "Estensione longitudinale:");

  // Simula click su landmark (tasto 't' -> indice sx, lat 1 dx, long +1)
  ui._activeRunLandmarkClickHandler({ keyId: "key_t", fingerId: "4", keyLabel: "t" });
  const selHand = leftCol.children[0].children[1];
  const selFinger = leftCol.children[1].children[1];
  const selLatDir = leftCol.children[2].children[1];
  const selLatExt = leftCol.children[3].children[1];
  const selLongExt = rightCol.children[0].children[1];

  assert.strictEqual(selHand.value, "left");
  assert.strictEqual(selFinger.value, "indice");
  assert.strictEqual(selLatDir.value, "dx");
  assert.strictEqual(selLatExt.value, "1");
  assert.strictEqual(selLongExt.value, "1");

  // 2. Verifica chiusura + showAlert su Sospendi, Abbandona e Concludi
  const s1 = await mgr.createSession({ profileId: "default", mode: "random", questionTypes: ["CARATTERE"], requestedCount: 1 });
  ui.activeSession = s1.session;
  ui.activeItems = s1.items;
  await ui.handleSuspend();
  assert.strictEqual(closedCount, 1);
  assert.strictEqual(alerts[0].title, "⏸ Sessione Sospesa");
  assert.ok(alerts[0].msg.includes("Punteggio:"));

  const s2 = await mgr.createSession({ profileId: "default", mode: "random", questionTypes: ["CARATTERE"], requestedCount: 1 });
  ui.activeSession = s2.session;
  ui.activeItems = s2.items;
  await ui.handleAbandonActive();
  assert.strictEqual(closedCount, 2);
  assert.strictEqual(alerts[1].title, "✖ Sessione Abbandonata");

  const s3 = await mgr.createSession({ profileId: "default", mode: "random", questionTypes: ["DITO"], requestedCount: 1 });
  ui.activeSession = s3.session;
  ui.activeItems = s3.items;
  await mgr.recordBlockEvaluation({ profileId: "default", sessionId: s3.session.sessionId, itemId: s3.items[0].itemId, blockId: "fingerKeys", outcome: "correct" });
  await ui.handleComplete();
  assert.strictEqual(closedCount, 3);
  assert.strictEqual(alerts[2].title, "🎓 Sessione Conclusa");
  assert.ok(alerts[2].msg.includes("3 / 3 pt (100%)"));
  assert.ok(alerts[2].msg.includes("Corrette: 1"));

  console.log("PASS: test-interrogation-v632 (landmark getKeyExtension, ordine Blocco 1, chiusura+alert su Concludi/Sospendi/Abbandona).");
}

runTests().catch((err) => {
  console.error(err);
  process.exit(1);
});
