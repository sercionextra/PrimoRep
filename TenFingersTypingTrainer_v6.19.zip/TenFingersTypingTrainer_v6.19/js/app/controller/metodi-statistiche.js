/* TenFingersTypingTrainer v6.2 — AppController: statistics. Eliminazione circoscritta dei campioni non selezionati visibili nel grafico. */
(() => {
  const controllerMethods = {
// Configurazione Listener UI Statistiche e Filtri Temporali
  setupStatsUI() {
    // 1. Radio Ordinamento Istogramma (Restituzione focus post-selezione)
    document.querySelectorAll('input[name="statsSort"]').forEach((radio) => {
      const handleSort = (e) => {
        document.querySelectorAll('input[name="statsSort"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.sortMode = e.target.value;
        this.statsMgr.renderHistogram();
        this.returnFocusToTyping();
      };
      radio.addEventListener("change", handleSort);
      radio.addEventListener("click", () => this.returnFocusToTyping());
    });

    // 2. Radio Metrica Velocità BPM (Restituzione focus post-selezione)
    document.querySelectorAll('input[name="speedMetric"]').forEach((radio) => {
      const handleMetric = (e) => {
        document.querySelectorAll('input[name="speedMetric"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.speedMetric = e.target.value;
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      };
      radio.addEventListener("change", handleMetric);
      radio.addEventListener("click", () => this.returnFocusToTyping());
    });

    // 3. Filtri Checkbox Tipi di Sessione (Restituzione focus post-toggle)
    document.querySelectorAll(".speed-filter-chk").forEach((chk) => {
      chk.addEventListener("change", () => {
        const types = [];
        document.querySelectorAll(".speed-filter-chk:checked").forEach((c) => {
          types.push(parseInt(c.value, 10));
        });
        this.statsMgr.filterTypes = types;
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      });
    });

    // 4. Listener per i campi Range Data-Ora (Input, Change e Tasti Invio/Esc)
    const onDateFilterChange = () => {
      this.statsMgr.renderSpeedChart();
    };

    [
      "filterStartDate",
      "filterStartTime",
      "filterEndDate",
      "filterEndTime",
    ].forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", onDateFilterChange);
        el.addEventListener("change", () => {
          onDateFilterChange();
          this.returnFocusToTyping();
        });
        el.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === "Escape") {
            e.preventDefault();
            this.returnFocusToTyping();
          }
        });
      }
    });

    // 5. Listener cancellazione singola per ciascun campo del range data/ora
    const clearSingleField = (inputId) => {
      const input = document.getElementById(inputId);
      if (input) {
        input.value = "";
        input.classList.remove("input-field-error");
        input.classList.remove("filter-active");
        // Ricalcola immediatamente la validità del range e aggiorna il grafico
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      }
    };

    document
      .getElementById("btnClearStartDate")
      ?.addEventListener("click", () => clearSingleField("filterStartDate"));
    document
      .getElementById("btnClearStartTime")
      ?.addEventListener("click", () => clearSingleField("filterStartTime"));
    document
      .getElementById("btnClearEndDate")
      ?.addEventListener("click", () => clearSingleField("filterEndDate"));
    document
      .getElementById("btnClearEndTime")
      ?.addEventListener("click", () => clearSingleField("filterEndTime"));

    // 6. Tasto Reset Periodo per azzerare tutti i controlli temporali
    document
      .getElementById("btnResetDateFilter")
      ?.addEventListener("click", () => {
        const elA = document.getElementById("filterStartDate");
        const elB = document.getElementById("filterStartTime");
        const elC = document.getElementById("filterEndDate");
        const elD = document.getElementById("filterEndTime");
        const msgEl = document.getElementById("lblDateRangeValidationMessage");

        if (elA) elA.value = "";
        if (elB) elB.value = "";
        if (elC) elC.value = "";
        if (elD) elD.value = "";

        [elA, elB, elC, elD].forEach((inp) => {
          if (inp) {
            inp.classList.remove("input-field-error");
            inp.classList.remove("filter-active");
          }
        });
        if (msgEl) {
          msgEl.style.display = "none";
          msgEl.textContent = "";
        }

        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      });

    // 7. Pulsante Azzera Statistiche (con dialogo modale)
    document.getElementById("btnClearStats")?.addEventListener("click", () => {
      this.showAppConfirm(
        "Azzerare definitivamente tutte le statistiche e i campioni dell'utente loggato?",
        "⚠ Azzeramento Statistiche",
        () => {
          this.profileMgr.clearUserStats();
          this.statsMgr.clearSelection();
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
          this.returnFocusToTyping();
        },
        () => {
          this.returnFocusToTyping();
        },
      );
    });

    // 8. Pulsante Elimina Selezionati (con dialogo modale)
    document
      .getElementById("btnClearSelection")
      ?.addEventListener("click", () => {
        const count = this.statsMgr.selectedSampleIndices.size;
        if (count === 0) return;
        const msg = `Sei sicuro di voler eliminare definitivamente i ${count} campioni selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}"?\n\nQuesta operazione cancellerà solo i campioni evidenziati nel grafico e non potrà essere annullata.`;
        this.showAppConfirm(
          msg,
          "🗑 Elimina Selezionati",
          () => {
            const p = this.profileMgr.profile;
            if (p && p.Campioni) {
              p.Campioni = p.Campioni.filter(
                (s) => !this.statsMgr.selectedSampleIndices.has(s.Index),
              );
              p.Campioni.forEach((s, idx) => (s.Index = idx));
              this.profileMgr.saveProfile();
            }
            this.statsMgr.clearSelection();
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
            this.showAppAlert(
              `Eliminati con successo ${count} campioni selezionati.`,
              "📊 Statistiche",
              () => this.returnFocusToTyping(),
            );
          },
          () => this.returnFocusToTyping(),
        );
      });

    // 9. Pulsante Elimina Non Selezionati (con dialogo modale) - Release v6.2
    document
      .getElementById("btnClearNotSelected")
      ?.addEventListener("click", () => {
        const countSel = this.statsMgr.selectedSampleIndices.size;
        const totalFiltered = this.statsMgr.currentFilteredSamples.length;
        const countNot = totalFiltered - countSel;
        if (countSel === 0 || countNot <= 0) return;
        const msg = `ATTENZIONE: Stai per eliminare i ${countNot} campioni non selezionati attualmente visibili nel grafico (in base ai filtri applicati).\n\nVerranno conservati i ${countSel} campioni selezionati e tutti gli altri campioni storici esclusi dai filtri attivi.\n\nSei sicuro di voler procedere? L'operazione non può essere annullata.`;
        this.showAppConfirm(
          msg,
          "✂ Elimina Non Selezionati",
          () => {
            const p = this.profileMgr.profile;
            if (p && p.Campioni) {
              const filteredIndicesToDelete = new Set(
                this.statsMgr.currentFilteredSamples
                  .filter(
                    (s) => !this.statsMgr.selectedSampleIndices.has(s.Index),
                  )
                  .map((s) => s.Index),
              );
              p.Campioni = p.Campioni.filter(
                (s) => !filteredIndicesToDelete.has(s.Index),
              );
              p.Campioni.forEach((s, idx) => (s.Index = idx));
              this.profileMgr.saveProfile();
            }
            this.statsMgr.clearSelection();
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
            this.showAppAlert(
              `Eliminati con successo ${countNot} campioni non selezionati visibili nel grafico.`,
              "📊 Statistiche",
              () => this.returnFocusToTyping(),
            );
          },
          () => this.returnFocusToTyping(),
        );
      });

    // 10. Clic generico nella finestra Statistiche (grafici, etichette e sfondo)
    const statsWin = document.getElementById("statsFloatingWindow");
    statsWin?.addEventListener("click", (e) => {
      const t = e.target;
      if (
        t.tagName === "INPUT" &&
        (t.type === "date" || t.type === "time" || t.type === "text")
      ) {
        return;
      }
      this.returnFocusToTyping();
    });
  },

// Garantisce il collasso istantaneo dell'altezza della scheda
  // e ricolloca la finestra Mani senza lasciare gap o spazi vuoti.
  toggleErrorsVis(show) {
    const box = document.getElementById("errorsBoxContainer");
    const typingCard = document.getElementById("typingCardContainer");

    if (box) {
      box.style.display = show ? "flex" : "none";
      // 1. Forza il ricalcolo sincrono del reflow nel DOM (Layout Flush)
      void box.offsetHeight;
      if (typingCard) {
        void typingCard.offsetHeight;
      }
    }

    const chk = document.getElementById("chkShowErrors");
    if (chk && chk.checked !== !!show) {
      chk.checked = !!show;
    }

    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowErrors = !!show;
      this.profileMgr.saveProfile();
    }

    // 2. Ricalcolo immediato sincrono della quota della scheda
    this.updateHandsWindowPosition();
    this.updateInstantSpeedWindowPosition?.();

    // 3. Secondo passaggio a frame stabilizzato per eliminare qualsiasi residuo di scrollbar
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
      this.updateInstantSpeedWindowPosition?.();
    });

    // 4. Timer di sicurezza a 30ms per garantire la perfetta aderenza su tutti i browser
    setTimeout(() => {
      this.updateHandsWindowPosition();
      this.updateInstantSpeedWindowPosition?.();
    }, 30);
    },
  
  // =======================================================
  // CLASSE: AppController (metodi-statistiche.js)
  // METODO: renderInstantSpeedChart() - Release v6.4
  // CONTESTO: Rendering tachimetrico SVG con formule esatte per Media Netta e Lorda,
  // font maggiorati e ancoraggio dinamico delle etichette alla viewport visibile.
  // =======================================================
  renderInstantSpeedChart() {
    const win = document.getElementById("instantSpeedFloatingWindow");
    if (!win || !win.classList.contains("window-visible")) return;

    const container = document.getElementById("instantSpeedSvgBox");
    if (!container) return;

    const pts = this.typingEng.instantSpeedPoints || [];
    if (pts.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);font-size:0.95rem;font-weight:600;">Inizia a digitare per visualizzare la velocità istantanea</div>';
      return;
    }

    const containerW = container.clientWidth || 800;
    const containerH = container.clientHeight || 240;
    const height = Math.max(180, containerH);

    const padL = 60;
    const padR = 30;
    const padT = 32;
    // Margine inferiore maggiorato a 112px per accogliere i font ingranditi e i tempi verticali
    const padB = 112;
    const plotH = Math.max(30, height - padT - padB);

    const pitch = 30;
    const width = Math.max(containerW, padL + padR + pts.length * pitch);

    // =========================================================================
    // CALCOLO ESATTO MEDIE CUMULATIVE (Release v6.4)
    // Media Netta = (N. caratteri corretti * 60) / tempo_trascorso_secondi
    // Media Lorda = (N. caratteri totali * 60) / tempo_trascorso_secondi
    // =========================================================================
    const lastPt = pts[pts.length - 1];
    const elapsedSeconds = lastPt && lastPt.elapsedMs > 0 ? lastPt.elapsedMs / 1000 : 0;
    const correctCount = pts.filter((p) => p.type === "correct").length;
    const totalCount = pts.length;

    const avgCorrectBpm = elapsedSeconds > 0 ? Math.round((correctCount * 60) / elapsedSeconds) : 0;
    const avgAllBpm = elapsedSeconds > 0 ? Math.round((totalCount * 60) / elapsedSeconds) : 0;

    const maxBpmSample = Math.max(...pts.map((p) => p.movingAvgBpm || 0));
    const maxVal = Math.max(120, Math.ceil(Math.max(maxBpmSample, avgAllBpm, avgCorrectBpm) * 1.25));

    const coords = pts.map((pt, idx) => {
      const cx = padL + idx * pitch;
      const cy = padT + plotH - Math.round(((pt.movingAvgBpm || 0) / maxVal) * plotH);
      return { cx, cy, pt, idx };
    });

    let pathD = "";
    coords.forEach((c, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${c.cx},${c.cy} `;
    });

    let svg = `<svg id="instantSpeedSvgPlot" viewBox="0 0 ${width} ${height}" style="width:${width}px;min-width:${width}px;height:${height}px;display:block;cursor:crosshair;user-select:none;">`;

    // Griglia orizzontale e quote numeriche asse Y
    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${width - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="11" font-weight="700" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    // Linea orizzontale media cumulativa lorda (Arancione) con font maggiorato a 15px
    if (avgAllBpm > 0) {
      const yAvgAll = padT + plotH - (avgAllBpm / maxVal) * plotH;
      svg += `<line id="instantLineAvgAll" x1="${padL}" y1="${yAvgAll}" x2="${width - padR}" y2="${yAvgAll}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6 3" />`;
      svg += `<text id="instantTextAvgAll" x="${width - padR}" y="${yAvgAll - 6}" font-size="15" font-weight="900" text-anchor="end" fill="#f59e0b" style="paint-order: stroke fill; stroke: var(--surface-color); stroke-width: 4px;">Media Lorda: ${avgAllBpm} BPM</text>`;
    }

    // Linea orizzontale media cumulativa netta (Verde) con font maggiorato a 15px
    if (avgCorrectBpm > 0) {
      const yAvgCorrect = padT + plotH - (avgCorrectBpm / maxVal) * plotH;
      svg += `<line id="instantLineAvgCorrect" x1="${padL}" y1="${yAvgCorrect}" x2="${width - padR}" y2="${yAvgCorrect}" stroke="#10b981" stroke-width="2" stroke-dasharray="6 3" />`;
      svg += `<text id="instantTextAvgCorrect" x="${padL + 8}" y="${yAvgCorrect - 6}" font-size="15" font-weight="900" text-anchor="start" fill="#10b981" style="paint-order: stroke fill; stroke: var(--surface-color); stroke-width: 4px;">Media Netta: ${avgCorrectBpm} BPM</text>`;
    }

    // Curva continua di connessione dei campioni
    if (coords.length > 1) {
      svg += `<path d="${pathD}" fill="none" stroke="#38bdf8" stroke-width="2.5" stroke-linejoin="round" />`;
    }

    // Elementi interattivi crosshair con font maggiorati e contorno ad alto risalto
    svg += `<line id="instantCrossH" stroke="#ef4444" stroke-width="1.8" stroke-dasharray="4 2" style="display:none;pointer-events:none;" />`;
    svg += `<text id="instantCrossYLabel" fill="#ef4444" font-size="18" font-weight="900" text-anchor="start" dominant-baseline="central" style="display:none;pointer-events:none;paint-order: stroke fill; stroke: var(--surface-color); stroke-width: 5px;"></text>`;
    svg += `<line id="instantCrossV" stroke="#38bdf8" stroke-width="1.8" stroke-dasharray="3 3" style="display:none;pointer-events:none;" />`;
    svg += `<text id="instantCrossXLabel" fill="#38bdf8" font-size="16" font-weight="900" text-anchor="middle" style="display:none;pointer-events:none;paint-order: stroke fill; stroke: var(--surface-color); stroke-width: 5px;"></text>`;

    // Punti, Glifi tasto (18px) e Timestamp verticali sss.mmm (13px)
    const chartBaseline = padT + plotH;
    coords.forEach((c) => {
      let dotColor = "#10b981"; // Verde se corretto
      if (c.pt.type === "error") dotColor = "#ef4444"; // Rosso se errato
      if (c.pt.type === "back") dotColor = "#f59e0b"; // Arancione se Backspace

      svg += `<circle class="instant-speed-dot" cx="${c.cx}" cy="${c.cy}" r="5" fill="${dotColor}" stroke="#ffffff" stroke-width="1.8" data-char="${htmlEscape(c.pt.char)}" data-bpm="${c.pt.movingAvgBpm}" data-time="${(c.pt.elapsedMs / 1000).toFixed(3)}" />`;

      // Singolo glifo del tasto in ascissa ingrandito a 18px bold
      svg += `<text x="${c.cx}" y="${chartBaseline + 20}" font-size="18" font-weight="900" text-anchor="middle" fill="var(--text-main)">${htmlEscape(c.pt.char)}</text>`;

      // Timestamp sss.mmm verticale ruotato di 90° antiorari ingrandito a 13px bold
      const timeFmt = (c.pt.elapsedMs / 1000).toFixed(3);
      const textX = c.cx;
      const textY = chartBaseline + 34;
      svg += `<text x="${textX}" y="${textY}" font-family="var(--font-mono)" font-size="13" font-weight="700" fill="var(--text-muted)" text-anchor="end" transform="rotate(-90, ${textX}, ${textY})">${timeFmt}</text>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    // Auto-scroll automatico verso destra per inquadrare la battuta più recente
    container.scrollLeft = container.scrollWidth;

    const svgEl = document.getElementById("instantSpeedSvgPlot");
    if (!svgEl) return;

    // Helper per mantenere le etichette delle medie sempre visibili nella porzione di finestra visualizzata
    const updateStickyLabels = () => {
      const scrollX = container.scrollLeft;
      const visibleW = container.clientWidth;
      const textNet = document.getElementById("instantTextAvgCorrect");
      const textGross = document.getElementById("instantTextAvgAll");

      if (textNet) {
        textNet.setAttribute("x", scrollX + padL + 8);
      }
      if (textGross) {
        textGross.setAttribute("x", Math.min(width - padR, scrollX + visibleW - 16));
      }
    };

    updateStickyLabels();
    container.onscroll = updateStickyLabels;

    // Crosshair interattivo vincolato alla porzione visibile della finestra
    svgEl.addEventListener("mousemove", (e) => {
      const rect = svgEl.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const crossH = document.getElementById("instantCrossH");
      const crossY = document.getElementById("instantCrossYLabel");
      const crossV = document.getElementById("instantCrossV");
      const crossX = document.getElementById("instantCrossXLabel");

      const scrollX = container.scrollLeft;
      const visibleW = container.clientWidth;

      if (crossH && crossY) {
        const boundedY = Math.max(padT, Math.min(padT + plotH, mouseY));
        const bpmVal = Math.round(maxVal - ((boundedY - padT) / plotH) * maxVal);

        // La linea orizzontale attraversa l'intera porzione attualmente visibile
        crossH.setAttribute("x1", scrollX);
        crossH.setAttribute("y1", boundedY);
        crossH.setAttribute("x2", scrollX + visibleW);
        crossH.setAttribute("y2", boundedY);
        crossH.style.display = "block";

        // Il testo del valore BPM rimane sempre agganciato al bordo sinistro visibile
        crossY.setAttribute("x", scrollX + 8);
        crossY.setAttribute("y", boundedY);
        crossY.textContent = `${bpmVal} BPM`;
        crossY.style.display = "block";
      }

      if (crossV && crossX && coords.length > 0) {
        let closest = coords[0];
        let minDist = Math.abs(coords[0].cx - mouseX);
        for (let i = 1; i < coords.length; i++) {
          const d = Math.abs(coords[i].cx - mouseX);
          if (d < minDist) {
            minDist = d;
            closest = coords[i];
          }
        }

        crossV.setAttribute("x1", closest.cx);
        crossV.setAttribute("y1", padT);
        crossV.setAttribute("x2", closest.cx);
        crossV.setAttribute("y2", chartBaseline);
        crossV.style.display = "block";

        // Il testo in alto viene mantenuto all'interno dei limiti orizzontali visibili
        const minTextX = scrollX + 90;
        const maxTextX = scrollX + visibleW - 90;
        const clampedX = Math.max(minTextX, Math.min(maxTextX, closest.cx));

        crossX.setAttribute("x", clampedX);
        crossX.setAttribute("y", padT - 10);
        crossX.textContent = `T: ${(closest.pt.elapsedMs / 1000).toFixed(3)} s | ${closest.pt.movingAvgBpm} BPM`;
        crossX.style.display = "block";
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("instantCrossH");
      const crossY = document.getElementById("instantCrossYLabel");
      const crossV = document.getElementById("instantCrossV");
      const crossX = document.getElementById("instantCrossXLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      if (crossV) crossV.style.display = "none";
      if (crossX) crossX.style.display = "none";
    });
  },

// Rendering dinamico delle coppie di errori commessi
  renderErrorsList() {
    const listCont = document.getElementById("errorsListContent");
    const countBadge = document.getElementById("lblErrorsCountBadge");
    const emptyPlaceholder = document.getElementById(
      "lblErrorsEmptyPlaceholder",
    );
    const handsCounter = document.getElementById("handsErrorCountText");

    if (!listCont) return;

    const errors = this.typingEng.sessionErrors || [];
    if (countBadge) countBadge.innerText = errors.length;

    // Sincronizzazione e visibilità condizionata contatore in alto al centro nella finestra Mani
    if (handsCounter) {
      handsCounter.textContent = `Errori: ${errors.length}`;
      handsCounter.style.display = errors.length > 0 ? "inline" : "none";
    }

    // Reset Immediato a cursore zero o inizio sessione
    if (errors.length === 0) {
      listCont.innerHTML = "";
      listCont.scrollTop = 0;
      if (emptyPlaceholder) emptyPlaceholder.style.display = "inline";
      return;
    }

    if (emptyPlaceholder) emptyPlaceholder.style.display = "none";

    let html = "";
    errors.forEach((err) => {
      const expFmt = this.formatGuideChar(err.expected);
      const wrgFmt = this.formatGuideChar(err.wrong);
      html +=
        `<span class="error-pair" title="Atteso: '${htmlEscape(err.expected)}' | Digitato: '${htmlEscape(err.wrong)}'">` +
        `<span class="char-expected">${htmlEscape(expFmt)}</span>` +
        `<span class="char-wrong">${htmlEscape(wrgFmt)}</span>` +
        `</span>`;
    });

    listCont.innerHTML = html;
    // Auto-scroll verticale verso il basso per inquadrare l'ultimo errore aggiunto
    listCont.scrollTop = listCont.scrollHeight;
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
