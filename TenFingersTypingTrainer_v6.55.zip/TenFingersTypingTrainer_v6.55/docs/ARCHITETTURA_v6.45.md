# Architettura TenFingersTypingTrainer v6.45

Documento di aggiornamento architetturale rispetto alla v6.44.

## 1. Obiettivo della Release v6.45
Ripristinare il contratto dati tra `AppController`, `TypingEngine` e `StatisticsManager` affinché le sessioni completate in modalità **Phrases - Custom** popolino correttamente la categoria statistica **Custom** (`TipoCampione: 2`) invece di confluire in **Phrases** (`TipoCampione: 1`).

## 2. Sincronizzazione della sorgente lezioni (`js/engines/typing-engine.js`, `js/app/controller/metodi-profili-modali.js`)
- `TypingEngine` espone la proprietà esplicita `this.lessonsSource` (inizializzata a `"standard"`).
- `AppController.setLessonsSource(source, { skipStart = false } = {})` calcola `effectiveSource` (`"custom"` solo se `customLessons` contiene almeno una lezione, altrimenti `"standard"`), allinea `this.activeLessonsSource` e `this.typingEng.lessonsSource`, aggiorna l'interfaccia e avvia l'esercizio solo se `skipStart` è `false`.
- In `TypingEngine.recordCompletedSample()`, per `mode === 0`, `TipoCampione` viene impostato a `2` quando `this.lessonsSource === "custom"` e a `1` quando `this.lessonsSource === "standard"`.
- In `TypingEngine.getCurrentExerciseTitle()`, per `mode === 0`, il titolo salvato nel campione usa il prefisso `"Custom"` quando `this.lessonsSource === "custom"`, rendendo distinguibili i punti custom nel tooltip del grafico velocità.

## 3. Simmetria di transizione tra modalità (`js/app/controller/metodi-toolbar-modalita.js`)
- In `AppController.updateModeUI()`, il ripristino della sorgente a `"standard"` viene applicato per qualsiasi `mode !== 0` quando `this.activeLessonsSource === "custom"`, utilizzando `{ skipStart: true }` per evitare una doppia invocazione di `startExercise()` durante i cambi modalità.
- Questo mantiene il modello dati pienamente coerente con il blocco del selettore `#btnToggleLessonSource` nelle modalità da 1 a 6.
