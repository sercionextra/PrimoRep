/* TenFingersTypingTrainer v6.5 | typing-engine.js | Buffer tachimetrico, Media Mobile continua (Metodo B) e ricalcolo retroattivo. */ class TypingEngine {
  constructor(lessons, profileMgr, audio, phonemeEng) {
    this.lessons = lessons;
    this.profileMgr = profileMgr;
    this.audio = audio;
    this.phonemeEng = phonemeEng;

    this.mode = 0;
    this.currentLessonIdx = 0;
    this.currentPhraseIdx = 0;
    this.originText = "";
    this.typedText = "";

    this.startTime = null;
    this.timerInterval = null;
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;

    this.sessionErrors = []; // Registro coppie di errore per la sessione
    this.currentTargetHasError = false; // Gate: impedisce registrazioni multiple sullo stesso carattere

    // Campionamento Velocità Istantanea (Release v6.3)
    this.instantSpeedPoints = [];
    this.lastKeystrokeTimestamp = null;

    this.customPhrases = [];
    this.parseCustomText(
      profileMgr.profile ? profileMgr.profile.CustomText : "",
    );
  }

  // =======================================================
  // CLASSE: TypingEngine (typing-engine.js)
  // METODO: recalculateInstantSpeedMovingAverages() - Release v6.5
  // CONTESTO: Ricalcolo immediato della Media Mobile su tutta la serie
  // cronologica dei punti quando l'utente modifica il parametro N nel modale.
  // =======================================================
  recalculateInstantSpeedMovingAverages() {
    if (!this.instantSpeedPoints || this.instantSpeedPoints.length === 0)
      return;

    const rawN = this.profileMgr?.profile?.InstantSpeedMovingAvgWindow;
    const N = Math.max(1, Math.min(10, parseInt(rawN, 10) || 3));

    for (let idx = 0; idx < this.instantSpeedPoints.length; idx++) {
      if (idx === 0) {
        this.instantSpeedPoints[0].movingAvgBpm = 0; // Il punto iniziale rimane a velocità convenzionale zero
        continue;
      }

      // Raccoglie a ritroso fino a N intervalli validi (deltaMs > 0)
      const intervals = [];
      for (let i = idx; i >= 0 && intervals.length < N; i--) {
        if (this.instantSpeedPoints[i].deltaMs > 0) {
          intervals.push(this.instantSpeedPoints[i].deltaMs);
        }
      }

      const k = intervals.length;
      if (k === 0) {
        this.instantSpeedPoints[idx].movingAvgBpm = 0;
      } else {
        const sumDelta = intervals.reduce((acc, d) => acc + d, 0);
        const effectiveSum = Math.max(20 * k, sumDelta);
        this.instantSpeedPoints[idx].movingAvgBpm = Math.min(
          1500,
          Math.round((k * 60000) / effectiveSum),
        );
      }
    }
  }

  // Restituisce la velocità istantanea / Media Mobile corrente in CPM (Battute al Minuto) (Release v6.13)
  getCurrentMovingAvgBpm() {
    if (!this.instantSpeedPoints || this.instantSpeedPoints.length === 0) return 0;
    const last = this.instantSpeedPoints[this.instantSpeedPoints.length - 1];
    return last ? (last.movingAvgBpm || 0) : 0;
  }
  
  // Calcola la lunghezza del prefisso coincidente tra digitato e testo guida
  getMatchLength() {
    let i = 0;
    while (
      i < this.typedText.length &&
      i < this.originText.length
    ) {
      const t = this.typedText[i];
      const o = this.originText[i];
      const isMatch =
        t === o ||
        ((t === "®" || t === "\n") && (o === "®" || o === "\n")) ||
        ((t === "→" || t === "\t") && (o === "→" || o === "\t"));
      if (!isMatch) break;
      i++;
    }
    return i;
  }

  // Gate di cattura: l'errore è catturabile solo se NON vi sono caratteri rossi nel Testo Guida
  canCaptureError() {
    if (this.mode === 4 || this.isCompleted) return false;
    const matchLen = this.getMatchLength();
    const hasRedChars = this.typedText.length > matchLen;
    // Se vi sono già caratteri rossi nel testo guida, blocca errori a cascata
    if (hasRedChars) return false;
    // Se su questo target è già stato registrato un errore (es. in auto-correzione o modificatore), blocca
    if (this.currentTargetHasError) return false;
    return true;
  }

  parseCustomText(rawText) {
    this.customPhrases = [];
    if (!rawText) return;
    const lines = rawText.split(/\r?\n/);
    let currentTitle = "Custom";
    let curLines = [];

    const flushCurrent = () => {
      if (curLines.length > 0) {
        let phraseText = "";
        for (let i = 0; i < curLines.length; i++) {
          const seg = curLines[i];
          if (!seg) continue;
          if (phraseText.length === 0) {
            phraseText = seg;
          } else if (phraseText.endsWith(" ") || phraseText.endsWith("®")) {
            phraseText += seg;
          } else {
            phraseText += " " + seg;
          }
        }
        if (phraseText.trim().length > 0) {
          this.customPhrases.push({
            title: currentTitle,
            text: phraseText,
          });
        }
        curLines = [];
      }
    };

    for (let line of lines) {
      line = line.trimEnd();
      if (
        line.startsWith("=====") &&
        line.endsWith("=====") &&
        line.length > 10
      ) {
        flushCurrent();
        currentTitle = line.slice(5, -5).trim();
      } else if (line === "=====") {
        flushCurrent();
      } else if (line) {
        curLines.push(line.replace(/\t/g, "→").replace(/    /g, "→"));
      }
    }
    flushCurrent();
    if (this.customPhrases.length === 0) {
      this.customPhrases.push({
        title: "Custom Base",
        text: "prova digitazione custom file",
      });
    }
  }

  initSession(keepExercise = false) {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.instantSpeedPoints = [];
    this.lastKeystrokeTimestamp = null;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    if (!keepExercise || !this.originText) {
      this.loadExercise();
    }
  }

  startTimerIfNeeded() {
    if (!this.startTime) {
      this.startTime = new Date();
      this.lastKeystrokeTime = this.startTime;
      if (this.mode !== 4) {
        this.timerInterval = setInterval(() => this.updateMetrics(), 200);
      }
    }
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  resetSessionMetrics() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.instantSpeedPoints = [];
    this.lastKeystrokeTimestamp = null;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  resetTypingSession() {
    this.typedText = "";
    this.countTotalChars = 0;
    this.countBackChars = 0;
    this.countErrors = 0;
    this.isCompleted = false;
    this.sessionErrors = [];
    this.currentTargetHasError = false;
    this.instantSpeedPoints = [];
    this.lastKeystrokeTimestamp = null;
    this.stopTimer();
    this.startTime = null;
    this.lastKeystrokeTime = null;
    this.updateMetrics();
  }

  loadExercise() {
    if (this.mode === 0) {
      const lesson = this.lessons[this.currentLessonIdx] || this.lessons[0];
      const phrases = lesson.phrases || ["asdfl"];
      if (this.currentPhraseIdx >= phrases.length) this.currentPhraseIdx = 0;
      if (this.currentPhraseIdx < 0) this.currentPhraseIdx = phrases.length - 1;
      // Preservazione del marcatore Invio ("®") ed interpretazione di Tab fisici (\t) o 4 spazi come "→"
      const rawPhrase = phrases[this.currentPhraseIdx] || "";
      this.originText = rawPhrase.replace(/\t/g, "→").replace(/    /g, "→");
    } else if (this.mode === 1) {
      const currentLessonKey = this.lessons[this.currentLessonIdx].name;
      let pool = "";
      for (let i = 0; i <= this.currentLessonIdx; i++) {
        pool += this.lessons[i].name;
      }
      pool = pool
        .replace(/Spazio/g, " ")
        .replace(/ShiftDestro/g, "QERTASDFGZCV")
        .replace(/ShiftSinistro/g, "UIOPHLBNM")
        .replace(/Invio/g, "®")
        .replace(/Tab/g, "→");
      if (pool.length === 0) pool = "asdf";

      let res = "";
      for (let i = 0; i < 20; i++) {
        if (
          Math.random() < 0.4 &&
          currentLessonKey.length > 0 &&
          currentLessonKey.length < 5
        ) {
          res +=
            currentLessonKey[
              Math.floor(Math.random() * currentLessonKey.length)
            ];
        } else {
          res += pool[Math.floor(Math.random() * pool.length)];
        }
      }
      this.originText = res;
    } else if (this.mode === 2) {
      const p = this.profileMgr?.profile;
      const fonemiOpts = p?.FonemiOptions || {};
      const fonemiProbs = p?.FonemiProbabilities || {};
      const customCorpus = p?.FonemiCustomText || "";
      const nGramLen = p?.FonemiNgramLength || 4; // Parametro N dinamico (v.4.4)
      const targetLength = p?.FonemiTargetLength || 100; // Parametro Lunghezza Esercizio (v6.11)
      this.phonemeEng.targetLength = targetLength;
      this.originText = this.phonemeEng.generate(
        fonemiOpts,
        fonemiProbs,
        customCorpus,
        nGramLen,
        targetLength,
      );
    } else if (this.mode === 3) {
      const all =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZòùàìèé1234567890<>=+-*/()[]{}.,:;?!'^§\"|_@#ç°£$%&";
      let arr = all.split("");
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      this.originText = arr.slice(0, 50).join("");
    } else if (this.mode === 4) {
      this.originText = "";
    } else if (this.mode === 5) {
      const lesson = this.lessons[this.currentLessonIdx] || this.lessons[0];
      const phrases = lesson.phrases || ["asdfl"];
      const basePhrase = (
        phrases[this.currentPhraseIdx] ||
        this.originText ||
        "asdfl"
      )
        .replace(/\t/g, "→")
        .replace(/    /g, "→");
      if (basePhrase) {
        let arr = basePhrase.split("");
        for (let i = arr.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        this.originText = arr.join("");
      }
    } else if (this.mode === 6) {
      // MODALITÀ 6: WEAKNESSES (CARENZE) - 30 CARATTERI PONDERATI A SCALA QUADRATICA
      const p = this.profileMgr?.profile;
      let candidates = [];

      if (p && p.Caratteri && p.Caratteri.length > 0) {
        // Soglia di confidenza minima: protegge i nuovi profili escludendo errori accidentali (Frequenza >= 3)
        let filteredPool = p.Caratteri.filter(
          (c) => (c.Errori || 0) > 0 && (c.Frequenza || 0) >= 3,
        );

        // Fallback progressivo: se nessun tasto raggiunge 3 battute, accetta qualsiasi errore registrato
        if (filteredPool.length === 0) {
          filteredPool = p.Caratteri.filter(
            (c) => (c.Errori || 0) > 0 && (c.Frequenza || 0) > 0,
          );
        }

        const withErrors = filteredPool
          .map((c) => {
            const ch = String.fromCharCode(c.CharUnicode);
            const rate = (c.Errori / c.Frequenza) * 100;
            return { char: ch, rate: rate };
          })
          .filter(
            (item) =>
              item.char !== "\n" &&
              item.char !== "®" &&
              item.char !== "\t" &&
              item.char !== "→",
          )
          .sort((a, b) => b.rate - a.rate);

        // Selezione delle prime 10 carenze con Errore Relativo (%) più alto
        candidates = withErrors.slice(0, 10);
      }

      // Caso Limite A: se non vi sono errori nel profilo, fallback sui 10 tasti tipicamente più ostici
      if (candidates.length === 0) {
        const fallbackKeys = ["q", "z", "p", "ò", "à", "ù", "è", "x", "y", "-"];
        candidates = fallbackKeys.map((k) => ({ char: k, rate: 10 }));
      }

      // Precalcolo dei pesi quadratici O(N) una sola volta prima del ciclo di estrazione
      const esponente = 2;
      candidates.forEach((c) => {
        c.weight = c.rate ** esponente;
      });

      const totalWeight = candidates.reduce(
        (sum, item) => sum + item.weight,
        0,
      );

      // Estrazione stocastica ponderata (Roulette Wheel Selection) su 30 battute
      let res = "";
      for (let i = 0; i < 30; i++) {
        let r = Math.random() * totalWeight;
        let chosenChar = candidates[0].char;
        for (let c of candidates) {
          if (r < c.weight) {
            chosenChar = c.char;
            break;
          }
          r -= c.weight;
        }
        res += chosenChar;
      }
      this.originText = res;
    }
  }

  handleKeyInput(charKey, isBack) {
    if (this.isCompleted) return;

    if (this.mode === 4) {
      this.startTimerIfNeeded();
      this.lastKeystrokeTime = new Date();
      this.countTotalChars++;
      if (isBack) {
        this.countBackChars++;
        this.typedText = this.typedText.slice(0, -1);
        this.recordInstantSpeedPoint("", true, false);
      } else if (charKey.length === 1 || charKey === "\n" || charKey === "®") {
        this.audio.playKey();
        this.typedText += charKey === "®" ? "\n" : charKey;
        this.recordInstantSpeedPoint(
          charKey === "®" ? "↵" : charKey,
          false,
          true,
        );
      }
      this.updateMetrics();
      return { status: "typing", typed: this.typedText };
    }

    if (isBack) {
      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText = this.typedText.slice(0, -1);
        this.countBackChars++;

        // Riarmo del gate quando la cancellazione rimuove tutti i caratteri rossi
        const matchLen = this.getMatchLength();
        if (this.typedText.length <= matchLen) {
          this.currentTargetHasError = false;
        }

        this.recordInstantSpeedPoint("", true, false);
        this.updateMetrics();
        return { status: "back", typed: this.typedText };
      }
      return { status: "ignored" };
    }

    this.startTimerIfNeeded();
    this.countTotalChars++;
    const targetChar = this.originText[this.typedText.length];

    const isEnterTarget = targetChar === "®" || targetChar === "\n";
    const isTabTarget = targetChar === "→" || targetChar === "\t";
    const isEnterKey =
      charKey === "Enter" || charKey === "\n" || charKey === "®";
    const isTabKey = charKey === "Tab" || charKey === "\t" || charKey === "→";

    const isMatch =
      charKey === targetChar ||
      (isEnterTarget && isEnterKey) ||
      (isTabTarget && isTabKey);

    if (isMatch) {
      this.audio.playKey();
      const effectiveChar = (isEnterTarget && isEnterKey)
        ? targetChar
        : ((isTabTarget && isTabKey) ? targetChar : charKey);
      this.typedText += effectiveChar;
      this.recordCharStat(charKey, false);
      this.currentTargetHasError = false; // Tasto corretto digitato: reset gate per il prossimo target
      this.recordInstantSpeedPoint(charKey, false, true);

      const matchLen = this.getMatchLength();
      const hasErrorsToCorrect =
        this.typedText.length > 0 &&
        this.typedText.length > matchLen;
      if (
        this.typedText.length === this.originText.length &&
        !hasErrorsToCorrect
      ) {
        this.isCompleted = true;
        this.stopTimer();
        this.audio.playBell();
        this.recordCompletedSample();
        this.updateMetrics();
        return { status: "completed", typed: this.typedText };
      }
      this.updateMetrics();
      return {
        status: "correct",
        typed: this.typedText,
        nextChar: this.originText[this.typedText.length],
      };
    } else {
      this.audio.playError();

      // Cattura condizionata: solo se non vi sono caratteri rossi nel Testo Guida
      const isCapturable = this.canCaptureError();
      if (isCapturable) {
        this.countErrors++;
        if (targetChar) this.recordCharStat(targetChar, true);
        this.sessionErrors.push({
          expected: targetChar || "⌫",
          wrong: charKey,
        });
        this.currentTargetHasError = true;
      }

      this.recordInstantSpeedPoint(charKey, false, false);

      if (!this.profileMgr.profile.AutomaticCorrection) {
        this.typedText += charKey;
        this.updateMetrics();
        return {
          status: "error",
          typed: this.typedText,
          wrongChar: charKey,
          expectedChar: targetChar || "⌫",
          captured: isCapturable,
        };
      } else {
        this.updateMetrics();
        return {
          status: "error-corrected",
          wrongChar: charKey,
          expectedChar: targetChar || "⌫",
          captured: isCapturable,
        };
      }
    }
  }

  recordCharStat(char, isError) {
    if (!char || typeof char !== "string" || char.length === 0) return;
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    p.TotaleCaratteri = (p.TotaleCaratteri || 0) + 1;
    if (isError) p.TotaleErrori = (p.TotaleErrori || 0) + 1;

    const ucode = char.charCodeAt(0);
    let item = (p.Caratteri || []).find((c) => c.CharUnicode === ucode);
    if (!item) {
      item = {
        Index: (p.Caratteri || []).length,
        CharUnicode: ucode,
        Frequenza: 0,
        Errori: 0,
      };
      if (!p.Caratteri) p.Caratteri = [];
      p.Caratteri.push(item);
    }
    item.Frequenza++;
    if (isError) item.Errori++;
    this.profileMgr.saveProfile();
  }

  // Memorizzazione di Data e Ora locale italiana (orologio PC)
  recordCompletedSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const rightChars = this.originText.length;
    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;

    let stype = 1;
    if (this.mode === 0) stype = 1;
    else if (this.mode === 1) stype = 3;
    else if (this.mode === 2) stype = 7;
    else if (this.mode === 3) stype = 6;
    else if (this.mode === 4) stype = 4;
    else if (this.mode === 5) stype = 5;
    else if (this.mode === 6) stype = 8; // Caso Limite C: TipoCampione 8 per Carenze

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: stype,
      NumCaratteri: rightChars,
      NumErrori: this.countErrors,
      Esercizio: this.getCurrentExerciseTitle(),
      DataOra: getLocalISODateTime(), // Timestamp locale del PC
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
  }

  // Memorizzazione di Data e Ora per sessioni libere di digitazione
  recordManualTypingSample() {
    if (!this.profileMgr.profile) return;
    const p = this.profileMgr.profile;
    const minutes = this.getElapsedMinutes();
    const chars = this.typedText.length;
    if (chars === 0) return;
    const netBpm = minutes > 0 ? Math.round(chars / minutes) : 0;

    const sample = {
      Index: (p.Campioni || []).length,
      BattuteMinuto: netBpm,
      TipoCampione: 4,
      NumCaratteri: chars,
      NumErrori: this.countBackChars,
      Esercizio: "Free Typing",
      DataOra: getLocalISODateTime(), // Timestamp locale del PC
    };
    if (!p.Campioni) p.Campioni = [];
    p.Campioni.push(sample);
    this.profileMgr.saveProfile();
    this.resetTypingSession();
  }

  getCurrentExerciseTitle() {
    if (this.mode === 0)
      return `Lezione ${this.currentLessonIdx + 1}: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 1)
      return `Random: ${this.lessons[this.currentLessonIdx].name}`;
    if (this.mode === 2) return "Fonemi Italiani";
    if (this.mode === 3) return "All Chars";
    if (this.mode === 4) return "Digitazione Libera";
    if (this.mode === 5) return "Random This Phrase";
    if (this.mode === 6) return "Weaknesses (Carenze)";
    return "";
  }

  getElapsedMinutes() {
    if (!this.startTime) return 0;
    if (this.mode === 4) {
      if (!this.lastKeystrokeTime) return 0;
      return (this.lastKeystrokeTime - this.startTime) / 60000;
    }
    return (new Date() - this.startTime) / 60000;
  }

  // =======================================================
  // METODO AGGIORNATO: Calcolo e rendering metriche in tempo reale.
  // =======================================================
  updateMetrics() {
    const minutes = this.getElapsedMinutes();
    const totalSecs = Math.floor(minutes * 60);
    const mm = String(Math.floor(totalSecs / 60)).padStart(2, "0");
    const ss = String(totalSecs % 60).padStart(2, "0");

    let rightChars = 0;
    if (this.mode === 4) {
      rightChars = this.typedText.length;
    } else {
      rightChars = this.getMatchLength();
    }

    const netBpm = minutes > 0 ? Math.round(rightChars / minutes) : 0;
    const grossBpm =
      minutes > 0 ? Math.round(this.countTotalChars / minutes) : 0;
    const errCount = this.mode === 4 ? this.countBackChars : this.countErrors;
    const errPerc =
      rightChars > 0 ? ((errCount / rightChars) * 100).toFixed(1) : "0.0";

    const elTime = document.getElementById("txtTime");
    const elRight = document.getElementById("txtRightChars");
    const elNet = document.getElementById("txtRightEverage");
    const elGross = document.getElementById("txtTotalEverage");
    const elErr = document.getElementById("txtErrors");
    const elPerc = document.getElementById("txtPercErrors");

    if (elTime) elTime.innerText = `${mm}:${ss}`;
    if (elRight) elRight.innerText = rightChars;
    if (elNet) elNet.innerText = netBpm;
    if (elGross) elGross.innerText = grossBpm;
    if (elErr) elErr.innerText = errCount;
    if (elPerc) elPerc.innerText = `${errPerc}%`;
  }

  recordInstantSpeedPoint(charKey, isBack, isMatch) {
    if (!this.startTime) return;
    const now = Date.now();
    const elapsedMs = Math.max(0, now - this.startTime.getTime());

    let deltaMs = 0;
    if (this.instantSpeedPoints.length === 0) {
      deltaMs = 0; // Punto zero
    } else {
      deltaMs = this.lastKeystrokeTimestamp
        ? Math.max(0, now - this.lastKeystrokeTimestamp)
        : 0;
    }
    this.lastKeystrokeTimestamp = now;

    // Normalizzazione glifo singolo W3C conforme
    let glyph = charKey;
    let type = "correct";
    if (isBack) {
      glyph = "⌫";
      type = "back";
    } else if (isMatch) {
      if (charKey === " ") glyph = "␣";
      else if (charKey === "®" || charKey === "\n") glyph = "↵";
      else if (charKey === "→" || charKey === "\t") glyph = "⇥";
      type = "correct";
    } else {
      if (charKey === " ") glyph = "␣";
      else if (charKey === "®" || charKey === "\n") glyph = "↵";
      else if (charKey === "→" || charKey === "\t") glyph = "⇥";
      type = "error";
    }

    // Calcolo Media Mobile (Metodo B: tempo cumulato degli ultimi N intervalli)
    const rawN = this.profileMgr?.profile?.InstantSpeedMovingAvgWindow;
    const N = Math.max(1, Math.min(10, parseInt(rawN, 10) || 3));
    let movingAvgBpm = 0;

    if (this.instantSpeedPoints.length === 0) {
      movingAvgBpm = 0;
    } else {
      const prevDeltas = [];
      for (
        let i = this.instantSpeedPoints.length - 1;
        i >= 0 && prevDeltas.length < N - 1;
        i--
      ) {
        if (this.instantSpeedPoints[i].deltaMs > 0) {
          prevDeltas.push(this.instantSpeedPoints[i].deltaMs);
        }
      }
      const intervals = [deltaMs, ...prevDeltas];
      const k = intervals.length;
      const sumDelta = intervals.reduce((acc, d) => acc + d, 0);
      const effectiveSum = Math.max(20 * k, sumDelta);
      movingAvgBpm = Math.min(1500, Math.round((k * 60000) / effectiveSum));
    }

    this.instantSpeedPoints.push({
      char: glyph,
      type: type, // "correct", "error", "back"
      elapsedMs: elapsedMs,
      deltaMs: deltaMs,
      movingAvgBpm: movingAvgBpm,
    });
  }
}

// KEYBOARD & HANDS RENDERERS (v.3.7 con Supporto Sfarfallio Keycaps)
