# HANDOFF TECNICO — TenFingersTypingTrainer

**Versione documento:** 1.0  
**Data:** 9 novembre 2026  
**Scopo della prossima chat:** riprendere la progettazione del backend della funzionalità *Interrogazione*, chiudendo il gate tecnico del generatore pseudo-casuale deterministico (PRNG) prima di qualsiasi implementazione.

---

## 1. Istruzioni per l'agente subentrante

Assumi il ruolo di **Principal/Senior Software Architect** e prosegui con autonomia, rigore e attenzione alla compatibilità. L'obiettivo immediato è completare la specifica progettuale del PRNG e i relativi test vectors, non implementare il codice applicativo.

Prima di proporre modifiche, esamina gli artefatti indicati nella sezione 3 e verifica le dipendenze reali nella baseline. Non chiedere nuovamente decisioni già consolidate. Se emerge una decisione sostanziale non determinabile dagli artefatti, formula una sola domanda mirata; per i dettagli tecnici ordinari scegli una soluzione motivata e documentala.

**Vincolo autorizzativo:** non modificare sorgenti, documentazione esistente o baseline senza autorizzazione esplicita. La progettazione e la produzione di nuovi documenti tecnici sono invece il lavoro previsto per la prossima fase.

## 2. Stato sintetico

Il progetto è **TenFingersTypingTrainer**, applicazione JavaScript classica. La baseline di riferimento è `TenFingersTypingTrainer_v6.23(2).zip`. Non convertire lo stack a .NET, TypeScript o framework non presenti nella baseline; preservare architettura, convenzioni e ordine di caricamento esistenti.

È stata progettata una nuova funzionalità di interrogazione con motori separati per catalogo, selezione, conoscenza, sessione/valutazione e persistenza IndexedDB. Le specifiche e i contratti sono già stati elaborati in più artefatti versionati. Non è stata ancora eseguita alcuna modifica alla baseline o ai sorgenti per questa funzionalità.

Il prossimo gate aperto è la definizione completa del **PRNG deterministico** usato dal motore di selezione. Senza algoritmo, seed, serializzazione, versionamento e vettori verificabili, la riproducibilità delle sessioni non è sufficientemente specificata per passare all'implementazione.

## 3. Artefatti da consultare

Gli artefatti sono stati creati in `/workspace` e, per la distribuzione, copiati in `/mnt/data`. Consultare le versioni più recenti disponibili; non duplicarne il contenuto in questo handoff.

### Fonti normative e baseline

- `HANDOFF TECNICO INTERROGAZIONE v1.0` — fonte operativa di passaggio.
- `SPECIFICA TECNICA INTERROGAZIONE v1.0` — specifica funzionale consolidata.
- `Specifiche_Tecniche_Interrogazione_v1.0(1).md` — copia/versione presente tra gli artefatti.
- `TenFingersTypingTrainer_v6.23(2).zip` — baseline applicativa.
- Il vecchio handoff antecedente alla v1.0 è storico e non prevale sulle fonti v1.0.

### Contratti e progettazione backend

- `Contratti_Backend_Interrogazione_v1.2.md` — contratti logici, API, record, transazioni, errori e test di accettazione. È il riferimento più recente per i contratti.
- `Schema_IndexedDB_Interrogazione_v1.2.md` — schema dati e store IndexedDB.
- `Matrice_Tracciabilita_Interrogazione_v1.0.md` — tracciabilità requisiti/decisioni.
- `Motore_Selezione_Interrogazione_v1.0.md` e `Motore_Selezione_Interrogazione_test_vectors_v1.0.json` — specifica del selettore e casi di prova.
- `Motore_Conoscenza_Interrogazione_v1.0.md` e `Motore_Conoscenza_Interrogazione_test_vectors_v1.0.json`.
- `Motore_Sessione_Interrogazione_v1.0.md` e `Motore_Sessione_Interrogazione_test_vectors_v1.0.json`.
- `Piano_Integrazione_Backend_Interrogazione_v1.0.md`.
- `Decisione_Quote_Adattive_D77-D80_v1.1.md` e `Verifica_Matematica_Quote_Adattive_D77-D80_v1.0.md`.
- `Catalogo_Domande_Interrogazione_v1.0.md` e `.json`.
- `Catalogo_QWERTY_Italiano_v1.0.md` e `Catalogo_QWERTY_Italiano_seed_v1.0.json`.
- `Contratti_Backend_Interrogazione_v1.0.md` e `v1.1.md`, `Schema_IndexedDB_Interrogazione_v1.0.md` e `v1.1.md` sono versioni precedenti: utili per la storia delle decisioni, ma non sostituiscono le versioni più recenti.

L'ultimo documento contratti v1.2 era stato salvato in `/workspace/Contratti_Backend_Interrogazione_v1.2.md` e `/mnt/data/Contratti_Backend_Interrogazione_v1.2.md`. SHA-256 verificato: `e6c6e64524106fb92087fee802888681b02d2a4979a378c523e77cb1807d75db`.

## 4. Prossimo lavoro: specifica PRNG

Produrre almeno:

1. `Specifica_PRNG_Interrogazione_v1.0.md`
2. `Specifica_PRNG_Interrogazione_test_vectors_v1.0.json`

Salvare i nuovi file in `/workspace` e copiarli in `/mnt/data`; verificare che le copie siano identiche e calcolare SHA-256. Fornire link di download alle copie in `/mnt/data`.

### Requisiti da coprire

- Scegliere un algoritmo PRNG deterministico, robusto e implementabile in JavaScript classico senza dipendenze esterne.
- Motivare la scelta e definire identificatore e versione dell'algoritmo.
- Definire generazione del seed per sessione, formato, encoding, normalizzazione e serializzazione persistente.
- Definire stato interno del PRNG e regole di avanzamento; una sessione deve poter essere riprodotta in modo identico.
- Valutare `crypto.getRandomValues` per generare il seed iniziale, con feature detection. Un eventuale fallback deve essere esplicitamente classificato come non crittograficamente sicuro e accompagnato da diagnostica; non presentarlo come equivalente a CSPRNG.
- Evitare di usare una nuova sorgente casuale esterna a ogni estrazione: la sequenza deve derivare dal seed persistito.
- Definire estrazione di interi senza bias da modulo tramite rejection sampling.
- Definire Fisher–Yates e l'ordine preciso di iterazione/indici.
- Ordinare canonicamente gli elementi prima della randomizzazione, con regole esplicite per stringhe, identificativi, duplicati e confronti.
- Modalità casuale: nessuna lettura di statistiche/conoscenza; la selezione deve essere indipendente dai dati adattivi.
- Modalità adattiva: PRNG solo per randomizzare all'interno dei pool/quote già determinati; non deve modificare quote, priorità o punteggi.
- Snapshot sufficiente a riprodurre la selezione: almeno algoritmo/versione, seed e encoding, fingerprint del pool, ordinamento canonico o sua versione, stato/posizione PRNG e informazioni ulteriori necessarie secondo il modello scelto.
- Definire compatibilità futura: non cambiare silenziosamente algoritmo o semantica per una versione già persistita; introdurre una nuova versione e mantenere la capacità di riprodurre le sessioni storiche.
- Produrre test vectors con input e output attesi per seed parsing, inizializzazione, sequenza di valori, bounded integers/rejection sampling, shuffle, casi limite e riproducibilità. I vettori devono essere verificati con un'implementazione di riferimento indipendente o con un secondo calcolo indipendente, non generati e accettati ciecamente dallo stesso codice.

### Pista tecnica da valutare, non decisione già approvata

È stata considerata come possibile soluzione una famiglia xoshiro a 32 bit (ad esempio xoshiro128**), implementabile con operazioni bitwise JavaScript. È una pista, non una decisione congelata. Valutare con attenzione:

- comportamento a 32 bit delle operazioni bitwise JavaScript;
- seed expansion e gestione degli stati vietati/degeneri;
- robustezza della serializzazione e portabilità;
- costo e chiarezza dell'implementazione;
- disponibilità di vettori ufficiali verificabili;
- necessità di un algoritmo alternativo più semplice/standard se garantisce meglio interoperabilità e verificabilità.

Non adottare un LCG semplice senza una motivazione tecnica forte. Non confondere qualità statistica, riproducibilità e sicurezza crittografica: per la selezione didattica è richiesta riproducibilità, non generazione di segreti.

## 5. Contesto funzionale e decisioni da preservare

Le specifiche v1.0 consolidano le decisioni D56–D83. In particolare:

- Punteggio: risposta corretta +3, consultata +1, errata 0, non risposta 0. Il punteggio non coincide con la conoscenza.
- Sessione: default 10 domande configurabile per profilo; snapshot configurazione all'avvio; gestione esplicita di sessione sospesa, ripresa, abbandono e completamento.
- Storico eventi immutabile; correzioni come nuove entità collegate all'evento, mai sovrascritture. Audit catalogo immutabile e rettificabile solo con nuove registrazioni.
- Operazioni persistenti atomiche e idempotenti tramite `operationId`; stesso ID con dati diversi è conflitto. Concorrenza tra schede con controllo ottimistico per entità.
- Elementi già usati nello storico si dismettono (`retired`) invece di eliminarli; sostituzioni mantengono la catena e non trasferiscono automaticamente conoscenza o storico.
- Sessioni sospese mantengono lo snapshot originale anche dopo sostituzioni catalografiche.
- Statistiche storiche non si cancellano con il decadimento; decadimento esponenziale con emivita di 60 giorni usato solo nei calcoli adattivi.
- Pesi compositi, affidabilità, classi, quote adattive, budget supplementare e cap individuale sono definiti nei documenti di decisione e nei contratti: non ricalcolarli o reinterpretarli autonomamente.
- Budget supplementare globale: 10 punti percentuali; tetto individuale: 20% della quota base normalizzata della categoria. Sono concetti distinti.
- Consultazione crea priorità temporanea nella sessione adattiva successiva della stessa tipologia, senza modificare quote o totale.
- Calendario intervalli configurabili 1, 3, 7, 14, 30, 60 giorni; verificare la logica esistente prima dell'implementazione.

Per ogni ambiguità, prevalgono i documenti normativi v1.0 e gli artefatti tecnici più recenti coerenti con essi. Non riaprire decisioni già consolidate senza una contraddizione concreta e documentata.

## 6. Baseline: risultati già verificati

Analisi statica già svolta sulla baseline v6.23:

- `KEY_MAP`: 111 voci.
- `KEY_ID_TO_LANDMARK_KEY`: 62 associazioni.
- SVG tastiera in `index.html`: 62 ID `key_*`, corrispondenti alla mappa.
- Catalogo anatomico: 60 coordinate.
- `FINGER_NAMES`: 10 dita.
- Tre tasti (`key_win_r`, `key_menu`, `key_ctrl_r`) risultano associati a `CTRL-dx`, landmark mappato al dito 6, mentre SVG li associa al dito 10: il risolutore non trova il landmark per l'associazione incongruente. Verificare e correggere solo con autorizzazione.
- Non è stato trovato un algoritmo di selezione landmark basato sulla distanza del puntatore con tolleranza 3 px.
- `StatisticsManager` gestisce statistiche di digitazione (`Caratteri`, `Campioni`): non riutilizzarlo per la conoscenza didattica.
- `ProfileManager` usa LocalStorage; non esiste IndexedDB per il dominio Interrogazione nella baseline.
- `importProfileData()` esegue rollback se fallisce il salvataggio della lista utenti, ma la successiva scrittura dell'utente attivo non è verificata: anomalia da affrontare solo nell'implementazione autorizzata.
- SVG inline in `index.html`; viewBox tastiera 870x305, mani 1408x768.
- Script `defer` sequenziali: preservare l'ordine.
- Nove test JavaScript risultavano superati: runtime-smoke, static-check, test-dictation-adaptive, test-dictation-config-dialog, test-fonemi-delete, test-fonemi-length, test-instant-speed-pin, test-window-stacking, test-zoom-buttons. Non sostituiscono i test browser.

Questi rilievi sono contesto, non autorizzazione a modificare la baseline.

## 7. Regole di lavoro e consegna

- Modifiche puntuali; non riscrivere codice funzionante o architetture esistenti senza necessità dimostrata.
- Conservare commenti pertinenti.
- Ogni nuovo file deve avere un numero di versione; non sovrascrivere versioni precedenti.
- Nuovi documenti in `/workspace` e copia scaricabile in `/mnt/data`.
- Verificare coerenza tra documenti, sorgenti e HELP quando si passerà all'implementazione.
- Documentazione utente e HELP devono contenere informazioni utili all'utente, non dettagli interni superflui.
- Fornire sorgenti completi dei soli metodi impattati quando si presenterà una modifica di codice; contestualizzarli rispetto al sorgente precedente.
- Nessuna regressione: eseguire i test esistenti e aggiungere test mirati; effettuare anche verifiche browser.
- Non usare LaTeX.
- Risposte in italiano, concise ma tecnicamente complete. Evitare domande ripetitive e richieste di conferma su dettagli ordinari.

## 8. Criteri di completamento della prossima sessione

La fase PRNG è conclusa quando:

1. La specifica descrive senza ambiguità algoritmo, versione, seed, stato, serializzazione e riproducibilità.
2. Sono definite le procedure di bounded integer senza bias, shuffle e ordinamento canonico.
3. È esplicito il confine tra casualità pura e selezione adattiva.
4. Lo snapshot della sessione contiene tutto ciò che serve a riprodurre il risultato anche dopo aggiornamenti futuri.
5. I test vectors coprono casi normali e limiti e sono verificati indipendentemente.
6. La specifica è coerente con `Motore_Selezione_Interrogazione_v1.0.md`, `Schema_IndexedDB_Interrogazione_v1.2.md` e `Contratti_Backend_Interrogazione_v1.2.md`; eventuali adeguamenti documentali sono proposti come nuove versioni, senza sovrascrivere gli artefatti.
7. I file sono presenti in `/workspace` e `/mnt/data`, con SHA-256 verificato e link di download.
8. Nessun sorgente applicativo è stato modificato.

Dopo il PRNG, riprendere il piano d'integrazione backend e chiudere gli altri gate tecnici rimasti aperti (catalogo/identità, KEY_MAP e SVG, migrazioni e compatibilità IndexedDB, import/export, recovery e concorrenza, test browser), sempre nell'ordine indicato dagli artefatti progettuali.

## 9. Suggested skills

L'agente subentrante dovrebbe invocare, se disponibili, skill pertinenti a:

- **Software architecture / system design:** contratti, confini tra componenti, versionamento e compatibilità.
- **JavaScript runtime and bitwise arithmetic:** semantica a 32 bit, overflow, shift e portabilità browser.
- **Deterministic random number generation:** PRNG, seed expansion, rejection sampling e Fisher–Yates.
- **Property-based and golden-vector testing:** test vectors, invarianti, riproducibilità e verifica indipendente.
- **IndexedDB and transaction design:** snapshot, atomicità, migrazioni e persistenza dello stato PRNG.
- **Technical documentation / ADR:** specifiche versionate, tracciabilità e decisioni motivate.

Prima di invocare skill o strumenti aggiuntivi, verificare quali siano effettivamente disponibili nell'ambiente della nuova chat. Non assumere che plugin o connessioni esterne siano installati.

---

**Punto esatto di ripartenza:** leggere `Motore_Selezione_Interrogazione_v1.0.md`, i relativi test vectors, `Schema_IndexedDB_Interrogazione_v1.2.md`, `Contratti_Backend_Interrogazione_v1.2.md` e verificare nella baseline eventuali vincoli browser. Poi definire e verificare `Specifica_PRNG_Interrogazione_v1.0.md` e `Specifica_PRNG_Interrogazione_test_vectors_v1.0.json`. Nessuna implementazione dei sorgenti senza autorizzazione esplicita.
