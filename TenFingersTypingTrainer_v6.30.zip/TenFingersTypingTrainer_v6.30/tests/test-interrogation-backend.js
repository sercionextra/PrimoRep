#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const assert = require("assert");
const crypto = require("crypto");

// Polyfill WebCrypto in globalThis for Node VM/require
if (!globalThis.crypto) {
  globalThis.crypto = crypto.webcrypto;
}

const root = path.resolve(__dirname, "..");
require(path.join(root, "js/data/interrogation-catalog-data.js"));
require(path.join(root, "js/interrogation/interrogation-prng.js"));
require(path.join(root, "js/interrogation/interrogation-catalog.js"));
require(path.join(root, "js/interrogation/interrogation-knowledge.js"));
require(path.join(root, "js/interrogation/interrogation-selector.js"));
require(path.join(root, "js/interrogation/interrogation-repository.js"));
require(path.join(root, "js/interrogation/interrogation-session-manager.js"));

const {
  InterrogationPRNG,
  InterrogationCatalog,
  InterrogationKnowledge,
  InterrogationSelector,
  InterrogationRepository,
  InterrogationSessionManager,
} = globalThis;

function approxEqual(a, b, eps = 1e-4) {
  assert(Math.abs(a - b) <= eps, `Atteso ${b}, ottenuto ${a}`);
}

async function run() {
  // 1. Catalogo
  const catalog = new InterrogationCatalog();
  const cov = catalog.getCoverageSummary();
  assert.strictEqual(cov.verifiedPhysicalKeys, 52);
  assert.strictEqual(cov.verifiedCharacterMappings, 111);
  assert.strictEqual(cov.activeDefinitions, 445);
  assert.strictEqual(cov.activeTemplates, 5);
  assert.strictEqual(cov.totalCandidates, 225);
  assert.strictEqual(
    catalog.getReadableCandidateLabel(catalog.getCandidateById("candidate.home-row.1")),
    "[HOME_ROW] mignolo - (sn)",
  );
  assert.strictEqual(
    catalog.getReadableCandidateLabel(catalog.getCandidateById("candidate.finger.key_minus")),
    "[DITO] mignolo - (dx) - {meno}",
  );
  assert.strictEqual(
    catalog.getReadableCandidateLabel(catalog.getCandidateById("candidate.char.20ac")),
    "[CARATTERE] Euro",
  );
  assert.strictEqual(
    catalog.getReadablePromptTitle(catalog.getCandidateById("candidate.finger.key_minus")),
    "Assegnazione Dito & Mano — Tasto {meno}",
  );
  console.log("PASS: InterrogationCatalog (52 tasti, 111 mapping, 445 definizioni, 225 candidate, etichette leggibili v6.26).");

  // 2. PRNG xoshiro128** determinismo & zero-state guard
  assert.throws(() => new InterrogationPRNG.Xoshiro128StarStar("00000000000000000000000000000000"), /PRNG_ZERO_STATE|all-zero/);
  const p1 = new InterrogationPRNG.Xoshiro128StarStar("000102030405060708090a0b0c0d0e0f");
  const p2 = new InterrogationPRNG.Xoshiro128StarStar("000102030405060708090a0b0c0d0e0f");
  for (let i = 0; i < 10; i++) {
    assert.strictEqual(p1.nextUint32(), p2.nextUint32());
  }
  console.log("PASS: InterrogationPRNG deterministico e zero-state protetto.");

  // 3. Test vectors Motore Conoscenza
  const kVectorsPath = path.resolve(root, "../FASE-3 - (C)/Motore_Conoscenza_Interrogazione_test_vectors_v1.0.json");
  if (fs.existsSync(kVectorsPath)) {
    const kData = JSON.parse(fs.readFileSync(kVectorsPath, "utf8"));
    for (const v of kData.vectors) {
      if (v.id.startsWith("DECAY-")) {
        approxEqual(InterrogationKnowledge.computeTemporalWeight(v.input.ageDays), v.expected.temporalWeight);
      } else if (v.id.startsWith("REL-")) {
        approxEqual(InterrogationKnowledge.computeReliability(v.input.equivalentExposures), v.expected.reliability);
      } else if (v.id.startsWith("EVENT-")) {
        const res = InterrogationKnowledge.computeEventMetrics(v.input.events, Date.now());
        if (v.expected.effectiveExposureCount !== undefined) {
          assert.strictEqual(res.effectiveExposureCount, v.expected.effectiveExposureCount);
        }
        if (v.expected.equivalentExposures !== undefined) {
          approxEqual(res.equivalentExposures, v.expected.equivalentExposures);
        }
        if (v.expected.errorFactor !== undefined) {
          approxEqual(res.errorFactor, v.expected.errorFactor);
        }
        if (v.expected.consultationFactor !== undefined) {
          approxEqual(res.consultationFactor, v.expected.consultationFactor);
        }
      }
    }
    console.log("PASS: Vettori Motore Conoscenza verificati.");
  }

  // 4. Calendario 1 / 3 / 7 / 14 / 30 / 60 giorni
  const t0 = 1700000000000;
  let sched = InterrogationKnowledge.advanceReviewSchedule(0, "correct", t0);
  assert.strictEqual(sched.reviewLevel, 1);
  assert.strictEqual(sched.reviewIntervalDays, 3);
  sched = InterrogationKnowledge.advanceReviewSchedule(5, "correct", t0);
  assert.strictEqual(sched.reviewLevel, 5);
  assert.strictEqual(sched.reviewIntervalDays, 60);
  sched = InterrogationKnowledge.advanceReviewSchedule(4, "consulted", t0);
  assert.strictEqual(sched.reviewLevel, 3);
  assert.strictEqual(sched.reviewIntervalDays, 14);
  sched = InterrogationKnowledge.advanceReviewSchedule(4, "incorrect", t0);
  assert.strictEqual(sched.reviewLevel, 0);
  assert.strictEqual(sched.reviewIntervalDays, 1);
  sched = InterrogationKnowledge.advanceReviewSchedule(3, "unanswered", t0);
  assert.strictEqual(sched.changed, false);
  assert.strictEqual(sched.reviewLevel, 3);
  console.log("PASS: Calendario adattivo 1/3/7/14/30/60 giorni verificato.");

  // 5. Quote Adattive D77-D80 (Alternativa B)
  const selVectorsPath = path.resolve(root, "../FASE-3 - (C)/Motore_Selezione_Interrogazione_test_vectors_v1.0.json");
  if (fs.existsSync(selVectorsPath)) {
    const selData = JSON.parse(fs.readFileSync(selVectorsPath, "utf8"));
    for (const c of selData.cases) {
      if (c.baseShares && c.reliability && c.expectedFinalShares) {
        const res = InterrogationSelector.computeAdaptiveCategoryShares(c.baseShares, c.reliability);
        for (const cat of Object.keys(c.expectedFinalShares)) {
          approxEqual(res.finalSharesPercent[cat], c.expectedFinalShares[cat], 1e-3);
        }
        if (c.expectedSupplementPoints) {
          for (const cat of Object.keys(c.expectedSupplementPoints)) {
            approxEqual(res.supplementPoints[cat], c.expectedSupplementPoints[cat], 1e-3);
          }
        }
      }
    }
    console.log("PASS: Quote adattive D77-D80 (Alternativa B) verificate contro test vectors.");
  }

  // 6. Ciclo completo SessionManager (create -> outcome -> suspend -> resume -> complete)
  const repo = new InterrogationRepository({ forceMemory: true });
  const mgr = new InterrogationSessionManager({ catalog, repository: repo });

  const created = await mgr.createSession({
    profileId: "user_test_1",
    mode: "adaptive",
    questionTypes: ["TASTO", "DITO"],
    requestedCount: 5,
    seed: "000102030405060708090a0b0c0d0e0f",
  });
  assert.strictEqual(created.items.length, 5);
  assert.strictEqual(created.session.status, "in-progress");

  const firstItem = created.items[0];
  const firstSq = firstItem.subQuestions[0];
  const answerVal =
    firstSq.answerType === "PHYSICAL_KEY_ID"
      ? firstSq.answerDefinition.acceptedKeyId
      : firstSq.answerType === "FINGER_ID"
        ? firstSq.answerDefinition.acceptedFingerId
        : firstSq.answerDefinition.acceptedHandId || "x";

  const outRes = await mgr.recordSubQuestionOutcome({
    profileId: "user_test_1",
    sessionId: created.session.sessionId,
    itemId: firstItem.itemId,
    subQuestionId: firstSq.subQuestionId,
    action: "answer",
    userAnswer: answerVal,
  });
  assert.strictEqual(outRes.outcome, "correct");
  assert.strictEqual(outRes.score, 3);

  await mgr.suspendSession("user_test_1", created.session.sessionId);
  const suspended = await repo.getSuspendedSession("user_test_1");
  assert.strictEqual(suspended.sessionId, created.session.sessionId);

  const resumed = await mgr.resumeSession("user_test_1", created.session.sessionId);
  assert.strictEqual(resumed.session.status, "in-progress");

  const completed = await mgr.completeSession("user_test_1", created.session.sessionId);
  assert.strictEqual(completed.session.status, "completed");

  const progress = await mgr.getProfileProgress("user_test_1");
  assert.strictEqual(progress.sessionsCount, 1);
  assert.strictEqual(progress.insufficientData, 1);
  console.log("PASS: Ciclo completo SessionManager (create/outcome/suspend/resume/complete/progress) superato.");
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
