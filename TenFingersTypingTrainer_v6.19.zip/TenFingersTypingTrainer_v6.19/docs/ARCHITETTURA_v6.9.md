# Architettura — TenFingersTypingTrainer v6.9

## Obiettivo

La release v6.9 introduce il sistema di ingrandimento e riduzione dinamica dell'applicazione (Zoom-in e Zoom-out), integrando due pulsanti dedicati nella barra del titolo dell'applicazione (header principale) ed esponendo il controllo tramite tre canali d'interazione coordinati:
1. Click sui pulsanti dedicati "🔍+ Zoom-in" e "🔍- Zoom-out" nella toolbar della testata;
2. Scorciatoie da tastiera globali `CTRL+SHIFT++` (ingrandimento) e `CTRL+SHIFT+-` (riduzione);
3. Interazione fluida tramite rotellina del mouse con tasto CTRL premuto (`CTRL+RotellinaMouse`).

L'architettura garantisce la scalabilità visiva proporzionale di tutti i componenti della Single Page Application (scheda di battitura, tastiera virtuale, finestre fluttuanti, pannelli di controllo), preservando la persistenza del livello di zoom all'interno del profilo utente e coordinando in tempo reale il reflow e il riposizionamento delle finestre con ancoraggio intelligente (Pin/Pinned).

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo con impostazioni di ancoraggio e ZoomLevel predefinito (1.0) |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente con supporto `ZoomLevel` (normalizzazione e persistenza) |
| `domain/phoneme-engine.js` | Generazione/gestione degli esercizi fonemici |
| `ui/window-manager.js` | Finestre flottanti, drag & drop e vincoli al viewport |
| `engines/typing-engine.js` | Motore di digitazione, buffer tachimetrico e ricalcolo Media Mobile |
| `ui/visual-renderer.js` | Tastiera virtuale, rendering grafico mani e feedback |
| `engines/dictation-engine.js` | Dettatura vocale e sintesi vocale continua |
| `shared/export-utils.js` | Timestamp e utility di esportazione profili |
| `analytics/statistics-manager.js` | Metriche, grafici di velocità e istogrammi |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.9, `currentZoom`) |
| `app/controller/metodi-finestre-layout.js` | Gestione layout, ancoraggio intelligente e metodi Zoom (`setupZoomControls`, `zoomIn`, `zoomOut`, `applyZoom`) |
| `app/controller/metodi-scorciatoie-editor-custom.js` | Gestione scorciatoie globali da tastiera per Zoom-in e Zoom-out |
| `app/controller/metodi-profili-modali.js` | Ripristino del livello di zoom salvato nel profilo al login |
| `app/controller/metodi-avvio-temi-audio.js` | Ciclo di vita dell'applicazione, binding `setupZoomControls()` al bootstrap |
| `app/bootstrap.js` | Bootstrap e registrazione eventi DOM |

## Modello Architetturale dello Zoom Applicativo

Il sottosistema di Zoom introdotto nella v6.9 si articola in quattro pilastri:

1. **Gestione dello Stato e Persistenza:**
   - La proprietà `this.currentZoom` in `AppController` memorizza il fattore di scala corrente (valore base 1.0, corrispondente al 100%).
   - Range di sicurezza: il fattore di scala è vincolato tra 0.5 (riduzione 50%) e 2.5 (ingrandimento 250%) con incremento/decremento discreto di passo 0.1 (10%), prevenendo sovrascalature anomale o perdita di visibilità.
   - Ogni variazione viene memorizzata in `profileMgr.profile.ZoomLevel` e persistita atomicamente nel Local Storage dell'utente attivo.
   - All'accesso utente (`loginUser`), il fattore memorizzato viene ripristinato automaticamente; durante il reset globale dei layout (`resetAllWindowLayouts`), lo zoom viene ripristinato al valore standard di 1.0.

2. **Meccanismo di Rendering e Scaling DOM:**
   - L'applicazione applica il fattore di scala tramite `document.body.style.zoom`, garantendo una scalatura vettoriale nativa e coerente su tutti gli elementi dell'interfaccia (tipografia, input, pulsanti, card, grafici SVG, maniglie di ridimensionamento).

3. **Reattività Geometrica e Coordinamento dell'Ancoraggio:**
   - Ogni variazione di zoom scatena la ricalibrazione immediata della geometria delle finestre flottanti:
     - `updateHandsWindowPosition()`: la finestra "10 Fingers (Mani)" adegua le proprie coordinate relative.
     - `updateInstantSpeedWindowPosition()`: la finestra "Velocità Istantanea" mantiene il proprio aggancio solidale alla base della scheda di digitazione (`cardBottom`).
     - `syncLayoutArrangement()` e dispatch dell'evento `resize`: gli observer e i grafici responsive (SVG tachimetrico e istogrammi) vengono informati del reflow per ricalibrare viewBox e canvas.

4. **Interfacce d'Input Coordinate (Pulsanti, Scorciatoie e Mouse Wheel):**
   - **Pulsanti Header:**
     - `#btnZoomIn`: testo "🔍+ Zoom-in", tooltip esplicativo `"Ingrandimento (CTRL+RotellinaMouse oppure CTRL+SHIFT++)"`.
     - `#btnZoomOut`: testo "🔍- Zoom-out", tooltip esplicativo `"Riduzione (CTRL+RotellinaMouse oppure CTRL+SHIFT+-)"`.
   - **Keyboard Shortcuts:** intercettazione delle combinazioni `CTRL+SHIFT++` (anche via codici Equal, NumpadAdd o Plus) e `CTRL+SHIFT+-` (anche via codici Minus o NumpadSubtract) nella macchina a stati di `setupShortcuts()`.
   - **Wheel Listener:** intercettazione degli eventi `wheel` con tasto modificatore `e.ctrlKey === true`, mappando lo scorrimento verso l'alto (delta negativo) all'ingrandimento e verso il basso (delta positivo) alla riduzione, preservando al termine il focus sulla casella di digitazione.
