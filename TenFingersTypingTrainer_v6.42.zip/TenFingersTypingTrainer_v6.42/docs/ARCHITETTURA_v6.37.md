# Architettura & Note Tecniche — Release v6.37

## 1. Vincolo di sessione sospesa unica prima di nuovi avvii
- **`js/interrogation/interrogation-session-manager.js`**: in `createSession(input)` aggiunta la verifica `await this.repository.getSuspendedSession(profileId)` per impedire la creazione di una nuova sessione finché esiste una sessione nello stato `"suspended"`.
- **`js/ui/interrogation-ui.js`**:
  - In `showSetupView()`: `#btnStartInterrogation` viene disabilitato (`disabled = true`) se `suspended` è presente e riabilitato al ripristino/abbandono.
  - In `handleStartSession()` e `_startRepeatSession()`: verifica preventiva su `getSuspendedSession(profileId)` con messaggio di errore esplicito.

## 2. Larghezza finestra "Seleziona carattere / tasto" e grassetto `#target`
- **`assets/styles/app.css`**:
  - `.interr-ascii-popover` ampliato da `min(760px, 95vw)` a `min(880px, 96vw)` per contenere tutte le 26 lettere su un'unica riga.
  - `#target` aggiornato con `font-weight: bold;`.
- **`js/ui/interrogation-ui.js`**: in `_openAsciiPopover()` aggiornato il fallback `popW` a `Math.min(880, Math.round(vpW * 0.96))`.
