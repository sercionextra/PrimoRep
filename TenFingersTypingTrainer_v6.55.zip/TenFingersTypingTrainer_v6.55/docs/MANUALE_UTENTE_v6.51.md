# Manuale Utente TenFingersTypingTrainer v6.51

Questa guida integra il manuale della versione 6.50 con gli aggiornamenti introdotti nella versione 6.51.

## 1. Salvataggio automatico degli esercizi Custom
- **Ripristino alla riapertura del browser:** se stai svolgendo un esercizio in modalità **Phrases - Custom** (ad esempio **Custom 9**) e chiudi il browser, alla riapertura il programma riparte esattamente dalla modalità **Phrases - Custom**, dalla lezione e dalla frase personalizzata a cui eri arrivato.
- **Avanzamento separato tra Standard e Custom:** la posizione raggiunta nelle lezioni **Standard** e quella raggiunta nelle lezioni **Custom** vengono memorizzate separatamente nel tuo profilo. Puoi passare liberamente da Standard a Custom (e viceversa) senza perdere il punto in cui eri rimasto in nessuna delle due modalità.
- **Cambio temporaneo di modalità:** se da **Phrases - Custom** passi temporaneamente a un'altra modalità (come **Random**, **Fonemi** o **Dettatura**) e poi torni a **Phrases**, il programma ripristina automaticamente **Phrases - Custom** all'ultima lezione e frase personalizzata selezionata.
