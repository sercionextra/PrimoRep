# HANDOFF TECNICO — TenFingersTypingTrainer / Interrogazione

**Handoff:** v1.1  
**Data:** 09/11/2026  
**Baseline ricevuta:** `TenFingersTypingTrainer_v6.23.zip`  
**Baseline di lavoro:** `/workspace/TenFingersTypingTrainer_v6.24`  
**Documentazione di progetto:** `FASE-3 - (B).zip`

## 1. Decisioni utente vincolanti

1. Prima release di INTERROGAZIONE limitata ai **52 tasti fisici verificati**.
2. Il catalogo deve restare dichiaratamente parziale rispetto ai 105 elementi dichiarati. Nessuna posizione mancante può essere dedotta o inventata.
3. Nessuna dipendenza esterna: niente pacchetti, framework, librerie, CDN, servizi o risorse remote.
4. Isolamento rigoroso B: CSP restrittiva, test statici e runtime, blocco delle API di rete e verifica del traffico reale.
5. L'applicazione è stand-alone e non deve inviare dati o connettersi al Web.
6. Versionare ogni file modificato; salvare ogni nuovo file in `/workspace`; preservare la baseline v6.23.
7. Modifiche puntuali, conservazione delle funzionalità esistenti e coerenza tra sorgenti, Manuale Utente e Help.
8. Numeri, metriche e formule in notazione naturale, senza formattazione LaTeX.
9. Nell'output del codice fornire i metodi completi impattati, con percorso e contesto della baseline precedente.

## 2. Stato della baseline e hardening offline

La v6.23 originale è stata lasciata immutata. È stata creata la cartella di lavoro v6.24, che contiene il primo hardening offline:

- CSP restrittiva in `index.html` e `help.html`, senza `unsafe-inline` e `unsafe-eval`;
- `connect-src 'none'`, risorse locali e schema `file:` per l'apertura diretta da disco;
- stili HTML inline estratti in CSS locale; CSS e JavaScript della guida estratti in file dedicati;
- nessun attributo `style` nei frammenti HTML/SVG generati da JavaScript;
- `js/security/network-isolation-guard.js` caricato prima del codice applicativo;
- blocco runtime delle API di rete, dei canali tra contesti, di accessi a dispositivi non necessari, di anchor esterni e di `window.open` diverso da `help.html` locale;
- sintesi vocale limitata a voci italiane dichiarate locali (`localService === true`); nessun fallback alla voce predefinita del browser;
- nomi profilo e titoli degli esercizi renderizzati come testo, senza interpolazione HTML non necessaria.

La v6.24 è una **baseline di sicurezza intermedia**, non la release finale di INTERROGAZIONE. Il collaudo browser effettivo è ancora aperto.

## 3. Test eseguiti sulla v6.24

Tutte le 14 suite Node presenti in `tests/` sono state eseguite con esito positivo:

- 9 suite preesistenti della v6.23;
- 5 nuove suite: security static check, network isolation guard, offline voice selection, DOM injection safety, build manifest SHA-256.

Sono inoltre stati verificati:

- 16 vettori PRNG indipendenti in Python e JavaScript;
- manifest catalogo: 52 tasti, 111 mapping, 445 definizioni, 5 template e 225 candidate;
- tutti i 225 candidateId univoci;
- tutti i riferimenti a template, sotto-quesiti ed elementi risolti;
- tutte le 445 definizioni attive referenziate;
- zero dipendenze esterne.

## 4. Catalogo approvato per la prima release

`Candidati_Interrogazione_v1.1.json` è il manifest esplicito e validato:

| Tipo | Candidate |
|---|---:|
| HOME_ROW | 10 |
| TASTO | 52 |
| CARATTERE | 111 |
| DITO | 52 |
| **Totale** | **225** |

Le 445 definizioni di sotto-quesito sono: 8 HOME_ROW, 52 TASTO, 333 CARATTERE e 52 DITO. Non sono 445 domande principali indipendenti.

I 53 elementi fuori perimetro comprendono 43 posizioni non rappresentate negli ID SVG verificati e 10 modificatori SVG esclusi dal catalogo interrogabile.

Validazione ripetibile con:

```bash
node "/workspace/FASE-3 - (B)/validate_interrogation_catalog_v1.1.js"
```

## 5. Documenti progettuali aggiornati

- `Contratti_Backend_Interrogazione_v1.4.md`
- `Motore_Selezione_Interrogazione_v1.2.md`
- `Matrice_Tracciabilita_Interrogazione_v1.2.md`
- `Piano_Integrazione_Backend_Interrogazione_v1.2.md`
- `Verifica_Catalogo_Interrogazione_v1.0.md`
- `Candidati_Interrogazione_v1.1.json`
- `Piano_Verifiche_Sicurezza_Offline_v1.0.md`

Nella v1.4 dei contratti sono stati corretti i riferimenti residui allo schema IndexedDB v1.2; il riferimento corrente è schema v1.3.

## 6. Gate ancora aperti

### Bloccante per la modalità adattiva

La policy calendario 1/3/7/14/30/60 giorni è ancora una proposta documentale, non una decisione utente confermata. Le regole proposte sono: risposta corretta avanza di uno stadio; errore azzera lo stadio; consultazione arretra di uno stadio; mancata risposta non modifica lo stadio. Non implementare il calendario come comportamento definitivo prima della conferma.

### Da collaudare

- CSP e caricamento risorse in Edge/Chrome con apertura diretta `file://`;
- assenza di violazioni CSP durante il normale uso;
- assenza di richieste remote in DevTools Network durante tutte le operazioni;
- funzionamento di `element.style` e delle finestre dinamiche con `style-src-attr 'none'`;
- persistenza IndexedDB reale, upgrade, quota, recovery e concorrenza;
- integrazione PRNG nel selettore e snapshot deterministici;
- recovery/rollback tra LocalStorage del `ProfileManager` e IndexedDB;
- regressione manuale completa.

## 7. Prossima sequenza di lavoro

1. Chiudere il collaudo browser della baseline offline v6.24.
2. Integrare i dati del catalogo parziale come risorse JavaScript locali, senza `fetch`.
3. Implementare validatori puri e `InterrogationCatalog` usando il manifest v1.1.
4. Implementare xoshiro128** e selezione casuale/manuale sul pool dei 225 candidate.
5. Implementare repository IndexedDB conforme allo schema v1.3.
6. Implementare knowledge state e sessioni; la modalità adattiva resta disabilitata fino alla conferma del calendario.
7. Integrare la UI con interventi circoscritti e aggiornare Manuale Utente/Help solo con informazioni utili all'utente.
8. Eseguire tutte le suite, i test browser, i controlli anti-network e il test di recovery.

**Versione finale con INTERROGAZIONE:** da assegnare alla prossima release incrementale dopo la baseline v6.24. La v6.23 originale resta intatta.
