# Architettura & Note Tecniche — Release v6.34

## 1. Full-Viewport Drag & Resize per `#interrogationDialog`
- **`index.html`**: aggiunto attributo `data-allow-full-viewport="1"` su `#interrogationDialog`.
- **`assets/styles/app.css`**: aggiornato `.interrogation-dialog-wide` da `max-height: 94vh;` a `max-height: 100vh;`.
- **`js/ui/window-manager.js`**:
  - Introdotto `isFullViewportAllowed(windowElem)` che verifica `windowElem.dataset?.allowFullViewport === "1"`.
  - Aggiornati `clampWindowToViewport`, `initGlobalEvents` (drag e resize) per usare `minTop = 0`, `marginX = 0`, `maxAvailH = innerHeight`, `maxAvailW = innerWidth` quando `fullVp` è `true`, mantenendo `minTop = 60` e `marginX = 10` per tutte le altre finestre fluttuanti.
  - Durante il resize, oltre a `style.maxWidth = "none"`, viene impostato anche `style.maxHeight = "none"`.
- **`js/app/controller/metodi-interrogazione.js`**:
  - In `resetInterrogationWindowLayout` e `openInterrogationModal` (ramo ripristino dimensioni salvate da profilo) viene impostato `dialog.style.maxHeight = "none"` così da preservare altezze fino a `100vh` anche alla riapertura.

## 2. Allineamento Layout Italiano QWERTY (`key_igrave`, `key_quote`)
- **`index.html`**: rimossi i nodi SVG `<text class="label-altgr">` da `#key_quote` (`` ` ``) e `#key_igrave` (`~`).
- **`js/domain/keyboard-map.js`**: rimosse le chiavi `` "`" `` e `"~"` da `KEY_MAP`.
- **`js/interrogation/interrogation-layout-metadata.js`**: impostato `altgr: null` su `KEY_OUTPUT_MAP.key_igrave` e `KEY_OUTPUT_MAP.key_quote`. `ASCII_CHARACTERS` mantiene entrambi i simboli come distrattori della palette.
- **`js/data/interrogation-catalog-data.js`**: aggiornate le `labelVariants` di `key.key_igrave` (`["ì", "^"]`) e `key.key_quote` (`["'", "?"]`), rimossi i mapping `char.60` e `char.7e` (109 mapping, 439 definizioni, 223 candidate).

## 3. Posizionamento dinamico `#interrAsciiPopover` (CSP-safe)
- **`js/ui/interrogation-ui.js`**: in `_openAsciiPopover(anchorEl, options, onSelect)`, calcolata la posizione orizzontale centrata su `anchorEl.getBoundingClientRect()` con clamp entro `[12, vpW - popW - 12]` e posizionamento verticale sotto o sopra il pulsante con clamp nella viewport, applicando le coordinate via proprietà CSSOM (`pop.style.left`, `pop.style.top`, `pop.style.right = "auto"`, `pop.style.bottom = "auto"`) nel pieno rispetto della CSP `style-src-attr 'none'`.
