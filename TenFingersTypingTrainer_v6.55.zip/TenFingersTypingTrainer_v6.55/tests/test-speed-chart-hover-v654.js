const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");

const match = css.match(
  /#speedSvgPlot\.hover-type-1\s+\.speed-point\[data-type="1"\][\s\S]*?\{([\s\S]*?)\}/,
);
assert.ok(match, "Regola hover-type-1..8 non trovata in app.css");
const body = match[1];

assert.ok(body.includes("opacity: 1 !important;"), "Manca opacity: 1 !important;");
assert.ok(body.includes("r: 5 !important;"), "Il raggio in hover deve essere 5px");
assert.ok(!body.includes("r: 8"), "Il raggio in hover non deve più essere 8px");
assert.ok(!body.includes("stroke:"), "Non deve esserci bordino bianco in hover");

console.log("PASS test-speed-chart-hover-v654");
