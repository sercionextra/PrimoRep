/* TenFingersTypingTrainer v6.26 | interrogation-ui.js | Vista modale dedicata Interrogazione (Opzione A, isolata dal flusso di digitazione). */
(function (global) {
  "use strict";

  const FINGER_OPTIONS = [
    { id: "1", label: "mignolo - (sn)" },
    { id: "2", label: "anulare - (sn)" },
    { id: "3", label: "medio - (sn)" },
    { id: "4", label: "indice - (sn)" },
    { id: "5", label: "pollice - (sn)" },
    { id: "6", label: "pollice - (dx)" },
    { id: "7", label: "indice - (dx)" },
    { id: "8", label: "medio - (dx)" },
    { id: "9", label: "anulare - (dx)" },
    { id: "10", label: "mignolo - (dx)" },
  ];

  class InterrogationUI {
    constructor(deps) {
      this.sessionMgr = deps.sessionManager;
      this.catalog = deps.catalog;
      this.getProfileId = deps.getProfileId || (() => "default");
      this.onClose = deps.onClose || (() => {});

      this.activeSession = null;
      this.activeItems = [];
      this.currentItemIdx = 0;
      this.bound = false;
    }

    init() {
      if (this.bound) return;
      this.bound = true;

      const btnClose = document.getElementById("btnCloseInterrogationModal");
      const btnCancel = document.getElementById("btnInterrogationCloseFooter");
      const selMode = document.getElementById("interrogationModeSelect");
      const btnStart = document.getElementById("btnStartInterrogation");
      const btnResume = document.getElementById("btnResumeSuspendedInterrogation");
      const btnAbandonSuspended = document.getElementById("btnAbandonSuspendedInterrogation");
      const btnFinishMain = document.getElementById("btnInterrogationFinishItem");
      const btnSuspend = document.getElementById("btnInterrogationSuspend");
      const btnAbandon = document.getElementById("btnInterrogationAbandon");
      const btnComplete = document.getElementById("btnInterrogationComplete");
      const btnNew = document.getElementById("btnInterrogationNewSession");

      btnClose?.addEventListener("click", () => this.close());
      btnCancel?.addEventListener("click", () => this.close());

      selMode?.addEventListener("change", () => {
        const manualBox = document.getElementById("interrogationManualBox");
        if (manualBox) {
          manualBox.classList.toggle("is-hidden", selMode.value !== "manual");
        }
      });

      btnStart?.addEventListener("click", () => this.handleStartSession());
      btnResume?.addEventListener("click", () => this.handleResumeSuspended());
      btnAbandonSuspended?.addEventListener("click", () => this.handleAbandonSuspended());
      btnFinishMain?.addEventListener("click", () => this.handleFinishMainQuestion());
      btnSuspend?.addEventListener("click", () => this.handleSuspend());
      btnAbandon?.addEventListener("click", () => this.handleAbandonActive());
      btnComplete?.addEventListener("click", () => this.handleComplete());
      btnNew?.addEventListener("click", () => this.showSetupView());
    }

    async open() {
      this.init();
      const modal = document.getElementById("interrogationModal");
      if (!modal) return;
      modal.classList.add("active");
      await this.showSetupView();
    }

    close() {
      const modal = document.getElementById("interrogationModal");
      if (modal) modal.classList.remove("active");
      this.onClose();
    }

    _switchView(viewName) {
      const views = ["setup", "run", "summary"];
      views.forEach((v) => {
        const el = document.getElementById(`interrogationView_${v}`);
        if (el) el.classList.toggle("is-hidden", v !== viewName);
      });
    }

    async showSetupView() {
      this._switchView("setup");
      const profileId = this.getProfileId();

      const progress = await this.sessionMgr.getProfileProgress(profileId);
      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt("interrStatTotal", progress.totalDefinitions);
      setTxt("interrStatNever", progress.neverVerified);
      setTxt("interrStatWeak", progress.weak);
      setTxt("interrStatReview", progress.review);
      setTxt("interrStatConsolidated", progress.consolidated);
      setTxt("interrStatDue", progress.dueNow);

      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      const suspBanner = document.getElementById("interrogationSuspendedBanner");
      if (suspBanner) {
        suspBanner.classList.toggle("is-hidden", !suspended);
        if (suspended) {
          setTxt(
            "interrogationSuspendedInfo",
            `Sessione sospesa (${suspended.mode}, domanda ${(suspended.currentItemIndex || 0) + 1} di ${suspended.effectiveCount}, punteggio ${suspended.score})`,
          );
        }
      }

      const manualSelect = document.getElementById("interrogationManualList");
      if (manualSelect && manualSelect.options.length === 0) {
        const cands = this.catalog.getCandidates({});
        cands.forEach((c) => {
          const opt = document.createElement("option");
          opt.value = c.candidateId;
          opt.textContent =
            typeof this.catalog.getReadableCandidateLabel === "function"
              ? this.catalog.getReadableCandidateLabel(c)
              : `[${c.questionType}] ${c.mainElementSemanticId || c.candidateId}`;
          manualSelect.appendChild(opt);
        });
      }
    }

    async handleStartSession() {
      const profileId = this.getProfileId();
      const mode = document.getElementById("interrogationModeSelect")?.value || "random";
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "MIXED";
      const countVal = parseInt(
        document.getElementById("interrogationCountSelect")?.value || "10",
        10,
      );

      let manualIds = [];
      if (mode === "manual") {
        const manualSelect = document.getElementById("interrogationManualList");
        if (manualSelect) {
          manualIds = Array.from(manualSelect.selectedOptions).map((o) => o.value);
        }
        if (manualIds.length === 0) {
          this._setFeedback("Seleziona almeno una domanda per la modalità manuale.", "error");
          return;
        }
      }

      const created = await this.sessionMgr.createSession({
        profileId,
        mode,
        questionTypes: typeVal === "MIXED" ? ["HOME_ROW", "TASTO", "CARATTERE", "DITO"] : [typeVal],
        requestedCount: mode === "manual" ? manualIds.length : countVal,
        manualCandidateIds: manualIds,
      });

      this.activeSession = created.session;
      this.activeItems = created.items;
      this.currentItemIdx = 0;
      this._setFeedback("", "");
      this._renderRunView();
    }

    async handleResumeSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      const resumed = await this.sessionMgr.resumeSession(profileId, suspended.sessionId);
      this.activeSession = resumed.session;
      this.activeItems = resumed.items;
      this.currentItemIdx = resumed.session.currentItemIndex || 0;
      this._renderRunView();
    }

    async handleAbandonSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      await this.sessionMgr.abandonSession(profileId, suspended.sessionId);
      await this.showSetupView();
    }

    _setFeedback(msg, kind) {
      const el = document.getElementById("interrogationFeedback");
      if (!el) return;
      el.textContent = msg || "";
      el.className = "interrogation-feedback" + (kind ? ` is-${kind}` : "");
    }

    _formatPromptTitle(item) {
      if (this.catalog && typeof this.catalog.getReadablePromptTitle === "function") {
        return this.catalog.getReadablePromptTitle(item);
      }
      return item.mainElementSemanticId || item.candidateId;
    }

    _formatSubQuestionLabel(sq) {
      switch (sq.aspectId) {
        case "identifyPhysicalKey":
          return "Quale tasto fisico corrisponde a questo elemento? (es. key_a oppure lettera)";
        case "identifyFinger":
          return "Quale dito è assegnato?";
        case "identifyHand":
          return "A quale mano appartiene?";
        case "isHomeRow":
          return "Appartiene alla riga base (Home Row)?";
        case "identifyModifierMode":
          return "Quale modificatore è richiesto?";
        case "produceCharacter":
          return "Quale carattere viene prodotto?";
        default:
          return `${sq.aspectId} (${sq.questionSemanticId})`;
      }
    }

    _buildAnswerControl(sq) {
      if (sq.answerType === "FINGER_ID") {
        const sel = document.createElement("select");
        sel.className = "interr-input";
        FINGER_OPTIONS.forEach((f) => {
          const opt = document.createElement("option");
          opt.value = f.id;
          opt.textContent = f.label;
          sel.appendChild(opt);
        });
        return sel;
      }
      if (sq.answerType === "HAND_ID") {
        const sel = document.createElement("select");
        sel.className = "interr-input";
        [
          { id: "left", label: "Mano Sinistra" },
          { id: "right", label: "Mano Destra" },
        ].forEach((h) => {
          const opt = document.createElement("option");
          opt.value = h.id;
          opt.textContent = h.label;
          sel.appendChild(opt);
        });
        return sel;
      }
      if (sq.answerType === "HOME_ROW_STATUS") {
        const sel = document.createElement("select");
        sel.className = "interr-input";
        [
          { id: "true", label: "Sì (riga base)" },
          { id: "false", label: "No" },
        ].forEach((h) => {
          const opt = document.createElement("option");
          opt.value = h.id;
          opt.textContent = h.label;
          sel.appendChild(opt);
        });
        return sel;
      }
      if (sq.answerType === "MODIFIER_MODE") {
        const sel = document.createElement("select");
        sel.className = "interr-input";
        [
          { id: "none", label: "Nessun modificatore" },
          { id: "shift", label: "Shift" },
          { id: "altgr", label: "AltGr" },
        ].forEach((m) => {
          const opt = document.createElement("option");
          opt.value = m.id;
          opt.textContent = m.label;
          sel.appendChild(opt);
        });
        return sel;
      }
      const inp = document.createElement("input");
      inp.type = "text";
      inp.className = "interr-input";
      inp.placeholder = sq.answerType === "PHYSICAL_KEY_ID" ? "Es. a oppure key_a" : "Inserisci risposta";
      return inp;
    }

    _formatSolutionText(sq) {
      const d = sq.answerDefinition || {};
      if (d.acceptedKeyId) {
        const keyName =
          this.catalog && typeof this.catalog.getReadableKeyName === "function"
            ? `{${this.catalog.getReadableKeyName(d.acceptedKeyId)}}`
            : d.acceptedKeyId;
        const labels = Array.isArray(d.acceptedLabels) ? ` (${d.acceptedLabels.join(" / ")})` : "";
        return `${keyName}${labels}`;
      }
      if (d.acceptedFingerId) {
        return this.catalog && typeof this.catalog.getReadableFingerName === "function"
          ? this.catalog.getReadableFingerName(d.acceptedFingerId)
          : `Dito ${d.acceptedFingerId}`;
      }
      if (d.acceptedHandId) return d.acceptedHandId === "left" ? "Mano Sinistra" : "Mano Destra";
      if (d.isHomeRow !== undefined) return d.isHomeRow ? "Sì (riga base)" : "No";
      if (d.acceptedModifierMode) return d.acceptedModifierMode;
      if (d.acceptedCharacter !== undefined) return String(d.acceptedCharacter);
      return JSON.stringify(d);
    }

    _renderRunView() {
      this._switchView("run");
      const item = this.activeItems[this.currentItemIdx];
      if (!item) {
        this.handleComplete();
        return;
      }

      const progressEl = document.getElementById("interrogationRunProgress");
      const scoreEl = document.getElementById("interrogationRunScore");
      const titleEl = document.getElementById("interrogationQuestionTitle");
      const listEl = document.getElementById("interrogationSubQuestionsList");
      const btnFinish = document.getElementById("btnInterrogationFinishItem");
      const btnComplete = document.getElementById("btnInterrogationComplete");

      if (progressEl) {
        progressEl.textContent = `Domanda ${this.currentItemIdx + 1} di ${this.activeItems.length} (${item.questionType})`;
      }
      if (scoreEl) {
        scoreEl.textContent = `Punteggio: ${this.activeSession.score} / ${this.activeSession.maxScore}`;
      }
      if (titleEl) {
        titleEl.textContent = this._formatPromptTitle(item);
      }

      const isLast = this.currentItemIdx >= this.activeItems.length - 1;
      if (btnFinish) btnFinish.classList.toggle("is-hidden", isLast);
      if (btnComplete) btnComplete.classList.toggle("is-hidden", !isLast);

      if (!listEl) return;
      listEl.textContent = "";

      item.subQuestions.forEach((sq) => {
        const card = document.createElement("div");
        card.className = `interr-sq-card is-${sq.status}`;

        const qLabel = document.createElement("div");
        qLabel.className = "interr-sq-label";
        qLabel.textContent = this._formatSubQuestionLabel(sq);
        card.appendChild(qLabel);

        if (sq.status === "pending") {
          const row = document.createElement("div");
          row.className = "interr-sq-controls";

          const control = this._buildAnswerControl(sq);
          row.appendChild(control);

          const btnConfirm = document.createElement("button");
          btnConfirm.type = "button";
          btnConfirm.className = "btn btn-primary btn-sm";
          btnConfirm.textContent = "Conferma";
          btnConfirm.addEventListener("click", async () => {
            const res = await this.sessionMgr.recordSubQuestionOutcome({
              profileId: this.activeSession.profileId,
              sessionId: this.activeSession.sessionId,
              itemId: item.itemId,
              subQuestionId: sq.subQuestionId,
              action: "answer",
              userAnswer: control.value,
            });
            sq.status = res.status;
            sq.outcome = res.outcome;
            sq.score = res.score;
            this.activeSession.score = res.sessionScore;
            this._setFeedback(
              res.outcome === "correct"
                ? "Risposta corretta (+3 punti)."
                : `Risposta errata. Soluzione: ${this._formatSolutionText(sq)}`,
              res.outcome === "correct" ? "success" : "error",
            );
            this._renderRunView();
          });
          row.appendChild(btnConfirm);

          const btnConsult = document.createElement("button");
          btnConsult.type = "button";
          btnConsult.className = "btn btn-sm";
          btnConsult.textContent = "Consulta";
          btnConsult.addEventListener("click", async () => {
            const res = await this.sessionMgr.recordSubQuestionOutcome({
              profileId: this.activeSession.profileId,
              sessionId: this.activeSession.sessionId,
              itemId: item.itemId,
              subQuestionId: sq.subQuestionId,
              action: "consult",
            });
            sq.status = res.status;
            sq.outcome = res.outcome;
            sq.score = res.score;
            this.activeSession.score = res.sessionScore;
            this._setFeedback(
              `Soluzione consultata (+1 punto): ${this._formatSolutionText(sq)}`,
              "info",
            );
            this._renderRunView();
          });
          row.appendChild(btnConsult);
          card.appendChild(row);
        } else {
          const badge = document.createElement("div");
          badge.className = "interr-sq-result";
          const outcomeLabel =
            sq.outcome === "correct"
              ? "Corretta (+3 pt)"
              : sq.outcome === "consulted"
                ? "Consultata (+1 pt)"
                : sq.outcome === "incorrect"
                  ? "Errata (0 pt)"
                  : "Non risposta (0 pt)";
          badge.textContent = `${outcomeLabel} — Soluzione: ${this._formatSolutionText(sq)}`;
          card.appendChild(badge);
        }

        listEl.appendChild(card);
      });
    }

    async handleFinishMainQuestion() {
      const item = this.activeItems[this.currentItemIdx];
      if (!item || !this.activeSession) return;
      await this.sessionMgr.finishMainQuestion({
        profileId: this.activeSession.profileId,
        sessionId: this.activeSession.sessionId,
        itemId: item.itemId,
      });
      if (this.currentItemIdx < this.activeItems.length - 1) {
        this.currentItemIdx += 1;
        this._setFeedback("", "");
        this._renderRunView();
      } else {
        await this.handleComplete();
      }
    }

    async handleSuspend() {
      if (!this.activeSession) return;
      this.activeSession.currentItemIndex = this.currentItemIdx;
      await this.sessionMgr.suspendSession(
        this.activeSession.profileId,
        this.activeSession.sessionId,
      );
      this.activeSession = null;
      await this.showSetupView();
    }

    async handleAbandonActive() {
      if (!this.activeSession) return;
      await this.sessionMgr.abandonSession(
        this.activeSession.profileId,
        this.activeSession.sessionId,
      );
      this.activeSession = null;
      await this.showSetupView();
    }

    async handleComplete() {
      if (!this.activeSession) return;
      const res = await this.sessionMgr.completeSession(
        this.activeSession.profileId,
        this.activeSession.sessionId,
      );
      this.activeSession = res.session;
      this.activeItems = res.items;
      this._renderSummaryView();
    }

    _renderSummaryView() {
      this._switchView("summary");
      let correct = 0;
      let incorrect = 0;
      let consulted = 0;
      let unanswered = 0;
      this.activeItems.forEach((it) => {
        it.subQuestions.forEach((sq) => {
          if (sq.outcome === "correct") correct += 1;
          else if (sq.outcome === "incorrect") incorrect += 1;
          else if (sq.outcome === "consulted") consulted += 1;
          else unanswered += 1;
        });
      });

      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt(
        "interrogationSummaryScore",
        `Punteggio finale: ${this.activeSession.score} / ${this.activeSession.maxScore}`,
      );
      setTxt("interrSumCorrect", correct);
      setTxt("interrSumIncorrect", incorrect);
      setTxt("interrSumConsulted", consulted);
      setTxt("interrSumUnanswered", unanswered);
    }
  }

  global.InterrogationUI = InterrogationUI;
})(typeof window !== "undefined" ? window : globalThis);
