# Documento di Avanzamento Tecnico e Specifica Funzionale (Versione 1.2)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Versione rilasciata**: **1.2**  
**Data**: 30/03/2026  
**File sorgente correlati**:
- `index_(v.1.2).html`
- `help_(v.1.2).html`

---

## 1. Sommario Esecutivo

Il rilascio della **Versione 1.2** introduce importanti rifiniture di ergonomia visiva e strumenti avanzati di analisi statistica e gestione della finestra, rispondendo a tutte le richieste emerse dal collaudo della versione 1.1:

1. **Unificazione della riga di scrittura guida**: Risolto il problema dell'andata a capo parassita tra le porzioni di testo verde (corretto), blu (bersaglio) e grigio (rimanente), ripristinando un flusso di scrittura a riga continua e naturale.
2. **Puntamento verticale del badge rosso d'errore**: Posizionamento dinamico e millimetrico del badge direttamente sulla verticale del carattere bersaglio blu, appena sopra di esso con freccetta di mira, garantendo la totale leggibilità contemporanea di bersaglio ed errore.
3. **Scorciatoie Guida Universali (`CTRL+SHIFT+H` ed `F1`)**: Bypassa i blocchi popup dei browser attivando l'evento click nativo sull'ancora di navigazione.
4. **Finestra Statistiche Ridimensionabile a 8 Vie con Persistenza e Schermo Intero**:
   - Maniglie di ridimensionamento per tutti gli 8 bordi e angoli (N, S, E, W, NE, NW, SE, SW).
   - Pulsante **⛶ Ingrandisci** per commutare a schermo intero (fullscreen) e ripristinare le dimensioni precedenti.
   - Pulsante **↺ Ripristina** per riportare la finestra alle dimensioni e posizione predefinite (840×620 px).
   - Memorizzazione automatica e persistente su `localStorage` di larghezza, altezza, coordinata X e coordinata Y.
5. **Selezione ad Area con il Mouse sul Grafico di Velocità (Drag-to-Select)**:
   - Evidenziazione interattiva tramite rettangolo semitrasparente trascinando il mouse sui campioni.
   - Calcolo istantaneo della velocità media parziale limitatamente ai campioni compresi nell'area.
   - Pulsante **`🗑 Elimina Selezionati`** (`btnClearSelection`) per rimuovere definitivamente solo i campioni evidenziati, previa conferma dettagliata.
   - Pulsante **`✂ Elimina Non Selezionati`** (`btnClearNotSelected`) per eliminare tutti i campioni esclusi dalla selezione conservando unicamente quelli evidenziati, previa conferma di sicurezza.

---

## 2. Dettaglio Tecnico delle Modifiche Applicate

### 2.1 Unica Riga Continua nel Testo Guida (`updateOriginDisplay`)
Nella versione 1.1 il contenitore `#originTextWrapper` adottava `white-space: pre-wrap;`, causando l'interpretazione dei ritorni a capo presenti nel template literal JavaScript come veri salti di riga. Nella v.1.2 la concatenazione avviene in stringa pura priva di caratteri parassiti, con applicazione della regola CSS `display: inline !important;` e `box-decoration-break: clone;`. Il testo scorre ora compatto e si adatta alla larghezza disponibile.

### 2.2 Posizionamento Dinamico del Badge Rosso d'Errore
Nel metodo `showWrongLetterPopup(wrongChar)` vengono ricavate le coordinate video del carattere bersaglio tramite `targetSpan.getBoundingClientRect()` rispetto al contenitore padre `.typing-box-container`. Il badge viene collocato a `left = centerX` con `transform: translateX(-50%)` e `top = topY - 34px`. La freccia inferiore CSS (`::after`) punta direttamente sul tasto bersaglio blu.

### 2.3 Gestione della Finestra Statistiche (`WindowManager`)
La classe `WindowManager` è stata estesa con il metodo `makeResizable(windowElem, onResized, minW, minH)`:
- Inserite 8 maniglie dedicate (`.rh-n`, `.rh-s`, `.rh-e`, `.rh-w`, `.rh-ne`, `.rh-nw`, `.rh-se`, `.rh-sw`).
- Gestione differenziata dei delta di movimento del mouse per calcolare larghezza, altezza e riposizionamento dei bordi superiore e sinistro.
- Al termine del ridimensionamento viene invocata la callback di persistenza che aggiorna `StatWidth`, `StatHeight`, `StatLeft` e `StatTop` nell'oggetto del profilo utente su `localStorage`.
- I grafici SVG (istogrammi e cartesiano di velocità) si adattano automaticamente alla larghezza del contenitore.

### 2.4 Selezione ad Area e Comandi di Cancellazione nel Grafico
Nella classe `StatisticsManager`:
- Aggiunto rettangolo SVG `#chartSelectionRect` con contorno tratteggiato.
- All'evento `mousedown` e `mousemove` sull'SVG viene tracciata la regione orizzontale e filtrato l'insieme dei punti campionati.
- I punti selezionati ricevono la classe `.selected` (ingranditi a raggio 6px con colore ambra `#f59e0b`).
- La label `lblMediaValori` calcola in tempo reale la media del segmento.
- I pulsanti `btnClearSelection` ed `btnClearNotSelected` compaiono dinamicamente indicando il conteggio esatto dei campioni coinvolti.
- Prima di eseguire la cancellazione, compare una finestra modale nativa di conferma (`confirm`) che descrive chiaramente l'impatto dell'operazione.

---

## 3. Report del Collaudo Automatizzato E2E (Google Chrome CDP)

| Test Eseguito | Esito | Dettaglio Riscontro |
|---|:---:|---|
| **Inizializzazione e Profilo Utente** | **PASS** | Auto-login Alberto verificato, badge valorizzato e lezione 1 attiva. |
| **Flusso Testo Guida a Riga Continua** | **PASS** | Spans con `display: inline`, nessun ritorno a capo parassita. |
| **Posizionamento Badge d'Errore** | **PASS** | Coordinate centrate sull'asse X della lettera bersaglio e `top: -17px`. |
| **Collegamento e Scorciatoia Help** | **PASS** | `href: help_(v.1.2).html`, bypass popup-blocker verificato con evento nativo. |
| **Maniglie Ridimensionamento Finestra** | **PASS** | 8 maniglie attive, ingrandimento fullscreen e ripristino verificati. |
| **Selezione Drag sul Grafico Cartesiano** | **PASS** | 207 campioni selezionati, media parziale calcolata a 133 bpm, pulsanti `btnClearSelection` e `btnClearNotSelected` visibili e funzionanti. |

---

## 4. Riepilogo Deliverable in `/workspace`

- `/workspace/index_(v.1.2).html`: SPA monolitica completa aggiornata.
- `/workspace/help_(v.1.2).html`: Manuale utente aggiornato con le note di rilascio v.1.2.
- `/workspace/06 - App TypeScript - Selezione Grafico, Finestra Ridimensionabile e Rifiniture UI (v.1.2).md`: Questo documento di specifica e collaudo.
