#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const listeners = {};
const elements = {};

function makeElement(id, tagName = 'div') {
  return {
    id,
    tagName: tagName.toUpperCase(),
    style: {},
    classList: {
      _classes: new Set(),
      add(c){ this._classes.add(c); },
      remove(c){ this._classes.delete(c); },
      toggle(c, force){
        if (force === undefined) {
          if (this._classes.has(c)) this._classes.delete(c); else this._classes.add(c);
        } else if (force) this._classes.add(c); else this._classes.delete(c);
      },
      contains(c){ return this._classes.has(c); }
    },
    checked: false,
    value: '',
    innerText: '',
    title: '',
    appendChild(child){ this._children = this._children || []; this._children.push(child); },
    setAttribute(){},
    getAttribute(){ return ''; },
    querySelectorAll(){ return []; },
    querySelector(){ return null; },
    addEventListener(evt, fn) {
      listeners[`${id}:${evt}`] = fn;
    },
    click() {
      if (listeners[`${id}:click`]) listeners[`${id}:click`]({ target: this });
    },
    focus() {}
  };
}

const sandbox = {
  console,
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: (sel) => null,
    querySelectorAll: () => [],
    addEventListener: (name, cb) => { (listeners['document:' + name] ||= []).push(cb); },
    createElement: (tag) => makeElement('anon_' + Math.random(), tag),
    body: { appendChild(){}, classList: { add(){}, remove(){}, toggle(){} }, style: {} },
    documentElement: { style: { setProperty(){} }, classList: { add(){}, remove(){}, toggle(){} }, clientWidth: 1920, scrollHeight: 1080 }
  },
  localStorage: {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    key(i) { return Object.keys(this._data)[i] || null; },
    get length() { return Object.keys(this._data).length; }
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  requestAnimationFrame: (cb) => { cb(); return 0; },
  cancelAnimationFrame: () => {},
  performance: { now: () => 0 },
  Blob: function(){},
  URL: { createObjectURL: () => '', revokeObjectURL(){} },
  navigator: {},
  alert(){}, confirm(){ return false; }, prompt(){ return null; }
};
sandbox.window = sandbox;
sandbox.window.addEventListener = (name, cb) => { (listeners['window:' + name] ||= []).push(cb); };
sandbox.window.localStorage = sandbox.localStorage;
sandbox.window.navigator = sandbox.navigator;
sandbox.listeners = listeners;

vm.createContext(sandbox);

const files = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];

for (const f of files) {
  const code = fs.readFileSync(path.join(root, f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
}

// 1. Verifica statica in index.html
const indexHtml = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
assert.ok(indexHtml.includes('id="txtFonemiTargetLength"'), 'index.html deve contenere id="txtFonemiTargetLength"');
assert.ok(indexHtml.includes('id="btnFonemiTargetLengthDefault"'), 'index.html deve contenere id="btnFonemiTargetLengthDefault"');
assert.ok(indexHtml.includes('Numero Caratteri per Esercizio:'), 'index.html deve contenere etichetta Numero Caratteri per Esercizio');

// 2. Test funzionale e comportamentale
const testScript = `
(() => {
  const ctrl = new AppController(EMBEDDED_LESSONS, EMBEDDED_DEMO_PROFILE, EMBEDDED_CUSTOM_DEFAULT, EMBEDDED_FONEMI_CORPUS);
  ctrl.profileMgr.init();
  ctrl.setupFonemiConfigModal();

  ctrl.returnFocusToTyping = () => {};
  let startedExercise = false;
  ctrl.startExercise = () => { startedExercise = true; };

  const txtTargetLen = document.getElementById("txtFonemiTargetLength");
  const btnLenDef = document.getElementById("btnFonemiTargetLengthDefault");
  const btnResetGlobal = document.getElementById("btnFonemiConfigResetDefault");
  const btnConfirm = document.getElementById("btnConfirmFonemiConfig");

  // TEST 1: Valore di default nel profilo
  if (ctrl.profileMgr.profile.FonemiTargetLength !== 100) {
    throw new Error("FonemiTargetLength nel profilo deve essere 100, trovato: " + ctrl.profileMgr.profile.FonemiTargetLength);
  }

  // TEST 2: openFonemiConfigModal carica il valore nel campo input
  ctrl.openFonemiConfigModal();
  if (txtTargetLen.value !== "100") {
    throw new Error("openFonemiConfigModal deve impostare txtFonemiTargetLength a '100', trovato: " + txtTargetLen.value);
  }

  // TEST 3: Modifica del campo e click su btnFonemiTargetLengthDefault
  txtTargetLen.value = "250";
  btnLenDef.click();
  if (txtTargetLen.value !== "100") {
    throw new Error("btnFonemiTargetLengthDefault deve ripristinare txtFonemiTargetLength a '100', trovato: " + txtTargetLen.value);
  }

  // TEST 4: Modifica e click su btnFonemiConfigResetDefault (reset globale)
  txtTargetLen.value = "300";
  btnResetGlobal.click();
  if (txtTargetLen.value !== "100") {
    throw new Error("btnFonemiConfigResetDefault deve ripristinare txtFonemiTargetLength a '100', trovato: " + txtTargetLen.value);
  }

  // TEST 5: Salvataggio con valore valido (es. 150)
  txtTargetLen.value = "150";
  btnConfirm.click();
  if (ctrl.profileMgr.profile.FonemiTargetLength !== 150) {
    throw new Error("btnConfirm deve salvare 150 in FonemiTargetLength, trovato: " + ctrl.profileMgr.profile.FonemiTargetLength);
  }

  // TEST 6: Clamping inferiore (valore < 20 deve diventare 20)
  txtTargetLen.value = "10";
  btnConfirm.click();
  if (ctrl.profileMgr.profile.FonemiTargetLength !== 20) {
    throw new Error("Clamping inferiore deve impostare 20 per valori < 20, trovato: " + ctrl.profileMgr.profile.FonemiTargetLength);
  }

  // TEST 7: Clamping superiore (valore > 500 deve diventare 500)
  txtTargetLen.value = "999";
  btnConfirm.click();
  if (ctrl.profileMgr.profile.FonemiTargetLength !== 500) {
    throw new Error("Clamping superiore deve impostare 500 per valori > 500, trovato: " + ctrl.profileMgr.profile.FonemiTargetLength);
  }

  // TEST 8: Valore non numerico / NaN (deve fallback a 100)
  txtTargetLen.value = "invalid_string";
  btnConfirm.click();
  if (ctrl.profileMgr.profile.FonemiTargetLength !== 100) {
    throw new Error("Valore non numerico deve fallback a 100, trovato: " + ctrl.profileMgr.profile.FonemiTargetLength);
  }

  // TEST 9: Generazione PhonemeEngine con lunghezze differenti
  const shortText = ctrl.phonemeEng.generate({}, {}, "", 4, 30);
  const longText = ctrl.phonemeEng.generate({}, {}, "", 4, 300);

  if (shortText.length < 20 || shortText.length > 70) {
    throw new Error("shortText con target 30 deve avere lunghezza plausibile (~30-50), trovato: " + shortText.length);
  }
  if (longText.length < 250) {
    throw new Error("longText con target 300 deve avere lunghezza >= 250, trovato: " + longText.length);
  }

  // TEST 10: TypingEngine loadExercise in Modalità 2 (Fonemi) usa FonemiTargetLength
  ctrl.typingEng.mode = 2;
  ctrl.profileMgr.profile.FonemiTargetLength = 200;
  ctrl.typingEng.loadExercise();
  if (ctrl.phonemeEng.targetLength !== 200) {
    throw new Error("TypingEngine loadExercise deve impostare targetLength a 200 su phonemeEng, trovato: " + ctrl.phonemeEng.targetLength);
  }
  if (ctrl.typingEng.originText.length < 180) {
    throw new Error("TypingEngine originText deve essere circa 200 caratteri, trovato: " + ctrl.typingEng.originText.length);
  }

  // TEST 11 (v6.12): Robustezza stallo Markoviano a 500 caratteri su N da 2 a 15
  for (let n = 2; n <= 15; n++) {
    for (let run = 0; run < 10; run++) {
      const generated = ctrl.phonemeEng.generate({}, {}, "", n, 500);
      if (generated.length < 400) {
        throw new Error("Generazione a targetLength 500 con N=" + n + " ha restituito una frase troppo corta (" + generated.length + " caratteri): " + generated);
      }
    }
  }

  return "TUTTI I TEST SUPERATI CON SUCCESSO!";
})()
`;

const res = vm.runInContext(testScript, sandbox);
console.log("TEST RESULT:", res);
