# Architettura — TenFingersTypingTrainer v6.7

## Obiettivo

La v6.7 introduce nella barra inferiore dell'Editor Custom il pulsante "🗑 Elimina" per la rimozione controllata della fonte Fonemi personalizzata (`FonemiCustomText`) precedentemente importata nel profilo utente attivo. L'operazione esegue una transazione atomica che azzera il corpus salvato, disattiva automaticamente l'opzione "Custom File", sincronizza l'interfaccia utente, persiste il profilo su LocalStorage e ripristina la fonte fonemica predefinita di sistema se la modalità corrente è Fonemi.

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente e persistenza in Local Storage |
| `domain/phoneme-engine.js` | Generazione/gestione degli esercizi fonemici |
| `ui/window-manager.js` | Finestre flottanti e loro geometria |
| `engines/typing-engine.js` | Stato e regole della digitazione (equivalenza semantica ® <=> \n e → <=> \t) |
| `ui/visual-renderer.js` | Tastiera virtuale, mani e feedback visivo |
| `engines/dictation-engine.js` | Dettatura vocale, sintesi e watchdog |
| `shared/export-utils.js` | Nome file per backup |
| `analytics/statistics-manager.js` | Istogrammi, metriche, filtri e grafici |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.7) |
| `app/controller/metodi-*.js` | Metodi del controller suddivisi per fonemi (incluso pulsante Elimina), finestre, profili, input, statistiche e dettatura |
| `app/bootstrap.js` | Avvio dell'applicazione dopo il caricamento dei componenti |

## Confini architetturali attuali

I file sono componentizzati ma usano script classici in ordine deterministico. La decisione è intenzionale: i sorgenti storici si basano su binding top-level condivise, quindi convertirli tutti insieme in moduli ES cambierebbe la risoluzione degli identificatori e potrebbe introdurre regressioni. La separazione fisica è il primo passaggio verificabile, non una pretesa che tutte le dipendenze siano già state convertite in import/export espliciti.

## Principi per l'evoluzione

1. Dominio e metodo didattico indipendenti dalla presentazione.
2. Funzioni pure per normalizzazione, parsing, calcolo delle metriche e trasformazioni dati quando possibile.
3. Classi per componenti con stato e ciclo di vita chiari (motori, profili, renderer, controller).
4. Effetti collaterali confinati agli adapter browser: DOM, Local Storage, audio, speech synthesis, timer e file.
5. Migrazioni dello storage esplicite, versionate e non distruttive.
6. Nessuna modifica al dataset o alle regole didattiche senza test e documentazione dedicati.
7. Ogni ulteriore estrazione verso moduli ES/TypeScript deve includere test di equivalenza e mantenere il caricamento statico della build finale.

## Storage e Gestione Corpus Fonemi Custom

Le chiavi osservate includono `TFTT_USERS`, `TFTT_ACTIVE_USER`, `TFTT_FIRST_RUN_DONE` e `TFTT_PROFILE_<UserID>`. Nel profilo utente, il campo `FonemiCustomText` contiene il testo sorgente custom se importato.
In v6.7:
- L'eliminazione tramite il pulsante `btnFonemiDelete` verifica preliminarmente la presenza del testo custom nel profilo.
- Se presente, previa conferma modale dell'utente (`showAppConfirm`), resetta la stringa a vuota, imposta `profile.FonemiOptions.customFile = false`, deseleziona il checkbox `chkFonemiCustomFile`, salva il profilo e aggiorna la sintesi nel dropdown.
- Se l'utente si trova in Modalità 2 (Fonemi), viene invocato `startExercise(false)` per rigenerare immediatamente l'esercizio attingendo al corpus predefinito di sistema.

## Metodo di studio invariato

- Precisione e postura prima della velocità.
- Ritorno alla posizione di riposo dopo la pressione del tasto.
- Percorso progressivo e criteri di avanzamento originali.
- Conservazione delle sette modalità: PHRASES, RANDOM, FONEMI, ALL CHARS, TYPING, RANDOM THIS PHRASE e WEAKNESSES.
- Conservazione del significato dei token didattici speciali, incluso `®` per Invio e `→` per Tab.
- Conservazione di dettatura, replay, auto-correction, Backspace e feedback errori secondo il comportamento implementato.

## Limiti delle verifiche

La build include controlli statici e una checklist di test browser. In assenza di un'esecuzione browser automatizzata completa nel processo di confezionamento, non si deve confondere il superamento del controllo sintattico con la certificazione di ogni interazione UI. La checklist deve essere eseguita in browser prima della distribuzione finale.
