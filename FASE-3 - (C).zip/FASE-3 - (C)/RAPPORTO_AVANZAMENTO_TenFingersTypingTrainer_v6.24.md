# Rapporto di avanzamento — TenFingersTypingTrainer v6.24

**Data:** 09/11/2026  
**Baseline originale:** v6.23  
**Perimetro Interrogazione approvato:** 52 tasti fisici verificati  
**Dipendenze esterne introdotte:** 0

## 1. Risultato del lavoro

È stata creata una nuova copia di lavoro v6.24, mantenendo intatta la directory v6.23. La v6.24 costituisce la prima baseline di hardening offline e privacy-by-design. Non è ancora la release finale che integra la funzionalità Interrogazione.

## 2. Sicurezza offline v6.24

- CSP restrittiva in `index.html` e `help.html`, senza `unsafe-inline` e `unsafe-eval`.
- `connect-src 'none'`, risorse locali, blocco di frame, worker, media e oggetti remoti.
- Stili inline statici migrati in CSS locale; CSS e JavaScript della guida estratti in file locali.
- Attributi `style` rimossi anche dai frammenti HTML/SVG creati dinamicamente.
- Guard runtime che blocca API di rete, canali tra contesti, accessi a dispositivi non necessari, anchor esterni e aperture di finestre esterne.
- Sintesi vocale limitata a voci italiane dichiarate locali; nessun fallback a una voce remota o non verificata.
- Nomi profilo e titoli degli esercizi inseriti nel DOM come testo.
- Test statici, runtime, DOM injection e integrità SHA-256 del manifest.

## 3. Verifiche

| Verifica | Esito |
|---|---:|
| Suite Node | 14/14 superate |
| Test PRNG indipendenti | 16/16 superati in Python e JavaScript |
| Tasti fisici verificati | 52/52 |
| Mapping carattere verificati | 111/111 |
| Definizioni attive referenziate | 445/445 |
| Candidate espliciti | 225, tutti univoci |
| Riferimenti mancanti | 0 |
| Dipendenze esterne aggiunte | 0 |
| Manifest file/hash | 98 file verificati |

## 4. Catalogo Interrogazione — strategia A

Il manifest `Candidati_Interrogazione_v1.1.json` contiene 225 candidate: 10 HOME_ROW, 52 TASTO, 111 CARATTERE e 52 DITO. Le 445 definizioni sono sotto-quesiti collegati ai candidate e non 445 domande principali autonome.

Il catalogo rimane parziale rispetto ai 105 elementi dichiarati. I 53 elementi esclusi (43 posizioni non rappresentate negli ID SVG verificati e 10 modificatori SVG) non vengono inventati né mostrati come interrogabili.

## 5. Documentazione aggiornata

- Contratti Backend v1.4;
- Motore Selezione v1.2;
- Matrice Tracciabilità v1.2;
- Piano Integrazione Backend v1.2;
- Manifest candidate v1.1 e report di verifica;
- Piano sicurezza offline v1.1;
- Handoff Interrogazione v1.1;
- Manuale Utente e Help v6.24;
- elenco dei metodi completi impattati v6.24.

## 6. Limiti ancora aperti

1. Il collaudo effettivo in Edge/Chrome non è stato eseguito nell'ambiente di build. Devono essere verificati caricamento `file://`, stili dinamici con `style-src-attr 'none'`, assenza di violazioni CSP e traffico effettivo nullo.
2. Il calendario adattivo 1/3/7/14/30/60 giorni è ancora una proposta e non va attivato senza conferma.
3. Repository IndexedDB, motore di conoscenza, selettore, session manager e UI Interrogazione non sono ancora integrati nella v6.24.

## 7. Prossima release

La prossima versione incrementale, prevista come v6.25, integrerà INTERROGAZIONE sul catalogo parziale approvato, senza dipendenze esterne e mantenendo l'isolamento offline della v6.24. La modalità casuale/manuale può procedere indipendentemente dal calendario; la modalità adattiva completa resta subordinata alla conferma della policy calendario.
