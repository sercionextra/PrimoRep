# Documento di Avanzamento Tecnico e Specifica Funzionale (Versione 1.4)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Versione rilasciata**: **1.4**  
**Data**: 30/03/2026  
**File sorgente correlati**:
- `index_(v.1.4).html`
- `help_(v.1.4).html`

---

## 1. Sommario Esecutivo

Il rilascio della **Versione 1.4** risolve puntualmente e in modo esaustivo le 11 criticità e richieste evolutive emerse durante la revisione architetturale approfondita (/Grill-me), perfezionando l'ergonomia didattica della digitazione cieca, la gestione dei tasti modificatori, il sistema statistico e la modalità di digitazione libera:

1. **Disabilitazione dell'Auto-Repeat dei Tasti da Tastiera Fisica**:
   - Intercettata ed eliminata la ripetizione continua dei tasti fisici (`e.repeat === true`) per tutti i caratteri e tasti funzione, consentendola unicamente per il tasto **Backspace**.
   - I tasti fisici premuti rimangono evidenziati sulla tastiera virtuale con la classe `.key-pressed` (sfondo azzurro con alone luminoso) per l'intera durata della pressione, venendo rilasciati solo all'evento `keyup`.
2. **Chord Engine Ergonomico & Regola della Mano Libera**:
   - Implementato il risolutore di accordi `resolveTargetChord(char)`: quando un simbolo richiede tasti modificatori (`Shift`, `AltGr`, `Ctrl`, `Alt`), la tastiera virtuale evidenzia contemporaneamente tutti i tasti che compongono l'accordo.
   - Per i simboli posizionati sul lato destro della tastiera (es. `@` su `ò`, `#` su `à`, `[` su `è`, `]` su `+`, `{` su `è`, `}` su `+`), la guida didattica propone l'accordo da realizzare con la **Mano Sinistra** (`Ctrl Sinistro` [Dito 1] + `Alt Sinistro` [Dito 5], più eventuale `Shift Sinistro` [Dito 2]), lasciando la mano destra libera di raggiungere il tasto base con il mignolo (Dito 10).
   - È supportata la totale flessibilità dell'utente: se l'utente preferisce eseguire l'accordo con la mano destra tramite `AltGr` (Dito 6) o `AltGr + Shift`, l'immissione viene accettata come valida al 100% senza generare penalità o errori.
3. **Etichette Dinamiche sulle Punte delle Dita (SVG Hands)**:
   - Sulla punta di ciascun dito attivo nel visualizzatore vettoriale delle 10 dita compare l'etichetta del tasto assegnato (es. `Ctrl` su Dito 1, `Shift` su Dito 2, `Alt` su Dito 5, `}` su Dito 10).
   - A riposo, le etichette vengono completamente azzerate, mantenendo la visualizzazione ergonomica pulita.
4. **Validazione Intelligente dei Tasti Modificatori**:
   - La pressione singola o preparatoria di `Shift`, `Alt`, `Ctrl`, `AltGr` o `CapsLock` non viene conteggiata come errore se coerente o necessaria per generare il tasto bersaglio successivo.
   - Se invece viene premuto un modificatore non richiesto o fuori luogo, il sistema segnala l'errore acustico, incrementa gli errori totali e proietta il badge fluttuante di avviso.
5. **Persistenza Visiva di CapsLock ed Equivalenza con Shift per le Maiuscole**:
   - Riconoscimento continuo dello stato del tasto CapsLock fisico (`e.getModifierState("CapsLock")`): finché il blocco maiuscole è attivo, il tasto virtuale `key_caps` rimane evidenziato con classe `.caps-active` (sfondo blu acceso).
   - Per le lettere maiuscole (`A`..`Z`), l'uso di CapsLock e quello di Shift sono considerati didatticamente equivalenti; se la lettera bersaglio è minuscola, l'attivazione indebita di CapsLock o Shift viene segnalata come errore.
6. **Centratura Grafica dei Simboli `@` e `#` sulla Tastiera SVG**:
   - Le etichette secondarie dei caratteri `@` (su `key_ograve`) e `#` (su `key_agrave`) sono state traslate a sinistra (ascissa `x="34"` invece di `42`), inserendole perfettamente all'interno del perimetro del tasto da 52px.
7. **Grafico Statistiche: Selezione a Due Click**:
   - Sostituita la precedente interazione di trascinamento (drag) con una precisa modalità a **due click**:
     - *1° Click*: Fissa l'inizio dell'intervallo (`startSvgX`).
     - *Movimento*: Visualizza l'anteprima dell'intervallo evidenziato e calcola in tempo reale la velocità media parziale.
     - *2° Click*: Conferma la selezione definitiva.
   - Se i due click vengono effettuati sullo stesso punto (distanza <= 14px), il sistema seleziona con precisione anche un **singolo campione isolato**.
8. **Invarianza delle Coordinate Statistiche al Ridimensionamento**:
   - Risolto il difetto di disallineamento geometrico dopo il resize o lo schermo intero tramite la matrice affine nativa SVG:  
     `pt.matrixTransform(svgEl.getScreenCTM().inverse())`.  
     Le coordinate risultano matematicamente stabili indipendentemente da zoom, proporzioni o dimensioni della finestra.
9. **Visualizzazione del Numero di Versione nell'Header**:
   - Inserito il badge di versione accanto al titolo principale in alto a sinistra:  
     `Ten Fingers Typing Trainer (v.1.4)`.
10. **Modalità "Typing (Libera)": Timer su Battuta e Reset Sessione**:
    - Disattivato il timer a scorrimento continuo in background: il tempo trascorso mostrato e le velocità BPM si aggiornano rigorosamente alla battuta di ciascun tasto (`lastKeystrokeTime`), consentendo pause deliberate senza far decadere la velocità media.
    - Il salvataggio nelle statistiche registra i valori congelati all'ultimo tasto battuto, ripulendo l'area di testo e azzerando i contatori.
    - Aggiunto il pulsante **"↺ Cancella / Azzera"** per azzerare testo, timer e metriche in qualsiasi momento senza effettuare il salvataggio nelle statistiche.
11. **Visualizzazione Multilinea Effettiva & Textarea Flessibile**:
    - Nel testo guida, i ritorni a capo (`®` o `\n`) vanno effettivamente a capo (`↵\n`), rendendo la lettura dei testi multilinea immediata e naturale.
    - Il campo di digitazione `#txtTypedInput` è stato convertito in un elemento `<textarea>` multilinea con altezza controllata e barre di scorrimento automatiche.

---

## 2. Dettaglio Tecnico delle Modifiche Applicate

### 2.1 Chord Engine e Mappatura Ergonomica (`resolveTargetChord`)
All'interno della SPA è stata introdotta la funzione pura `resolveTargetChord(char)` che interroga `KEY_MAP[char]` e genera una struttura normalizzata:
```javascript
{
  info: KEY_MAP[char],
  keyIds: ["key_plus", "key_ctrl_l", "key_shift_l", "key_alt_l"], // Tasti da illuminare
  fingers: [
    { finger: 1, label: "Ctrl" },
    { finger: 2, label: "Shift" },
    { finger: 5, label: "Alt" },
    { finger: 10, label: "}" }
  ],
  allowedMods: Set(["Control", "Shift", "Alt", "AltGraph"])
}
```
In `VisualRenderer.setTargetChar(char)`:
- Tutti i `keyIds` ricevono la classe `.active-target`.
- Tutte le dita coinvolte ricevono `.finger-active`.
- Su ciascun `<text id="hand_finger_tip_X">` viene proiettata l'etichetta del tasto.

### 2.2 Gestione Tastiera Fisica e Auto-Repeat (`AppController.setupTypingListeners`)
Nel listener `keydown`:
```javascript
if (e.repeat && e.key !== "Backspace") {
  e.preventDefault();
  return;
}
```
L'evidenziazione fisica è separata tra pressione e rilascio:
- `keydown` -> `this.visual.setKeyPressed(e.key, e.code, e.location, true)` (aggiunge `.key-pressed`)
- `keyup` -> `this.visual.setKeyPressed(e.key, e.code, e.location, false)` (rimuove `.key-pressed`)
- `blur` -> ripulisce preventivamente tutti i tasti rimasti attivi.

### 2.3 Matrice Affine SVG nelle Statistiche (`StatisticsManager.renderSpeedChart`)
Il calcolo delle ascisse campionarie nel grafico di velocità sfrutta le API geometriche del DOM SVG:
```javascript
const getSvgCoords = (e) => {
  const pt = svgEl.createSVGPoint();
  pt.x = e.clientX;
  pt.y = e.clientY;
  const svgPoint = pt.matrixTransform(svgEl.getScreenCTM().inverse());
  return svgPoint.x;
};
```
Questo elimina qualsiasi dipendenza dal fattore di scala o dall'aspect ratio del container, garantendo coerenza sia a 840px che in visualizzazione a pieno schermo.

---

## 3. Matrice di Test e Validazione Funzionale

| N° | Funzionalità Collaudata | Esito Atteso | Risultato |
|---|---|---|---|
| 1 | Auto-Repeat da Tastiera | Tasti alfanumerici non si ripetono se tenuti premuti; Backspace continua a cancellare | **PASS** |
| 2 | Persistenza Pressione Visiva | Il tasto rimane azzurro finché non viene rilasciato fisicamente (`keyup`) | **PASS** |
| 3 | Accordo Tasti a Mano Libera (`}`, `{`, `@`, `#`, `[`, `]`) | Tastiera evidenzia tasto base e modificatori; dita mostrano label corrette (Ctrl, Alt, Shift) | **PASS** |
| 4 | Flessibilità Utente su AltGr | Pressione di AltGr fisico o combinazione Ctrl+Alt accettate entrambe senza errore | **PASS** |
| 5 | Stato Permanente CapsLock | Tasto virtuale CapsLock rimane blu stabile se CapsLock è attivo sulla tastiera fisica | **PASS** |
| 6 | Equivalenza Shift / CapsLock | Lettera maiuscola digitata sia con Shift sia con CapsLock senza alcun errore | **PASS** |
| 7 | Riposizionamento `@` e `#` | Simboli visibili all'interno del contorno del tasto senza sbavature | **PASS** |
| 8 | Selezione Statistiche a 2 Click | Click 1 avvia, movimento mostra anteprima, Click 2 conferma. Possibile selezionare 1 solo campione | **PASS** |
| 9 | Invarianza Coordinate dopo Resize | Selezione precisa anche dopo aver ridimensionato la finestra o commutato a schermo intero | **PASS** |
| 10 | Header Versioning | Intestazione riporta chiaramente "Ten Fingers Typing Trainer (v.1.4)" | **PASS** |
| 11 | Modalità Typing Libera | Tempo e BPM si aggiornano solo alla battuta; tasto Reset sessione funzionante | **PASS** |
| 12 | Supporto Multilinea Effettivo | Testo con ritorno a capo va visivamente a capo; textarea utente multilinea operativa | **PASS** |

---

## 4. Riepilogo File e Deliverable Rilasciati in `/workspace`

```text
/workspace/
├── index_(v.1.4).html                                                                     # Versione SPA 1.4 Production-Ready
├── help_(v.1.4).html                                                                      # Manuale Utente Versione 1.4
├── 10 - App TypeScript - Accordi con Mano Libera, Disabilitazione Auto-Repeat... (v.1.4).md  # Specifica tecnica Versione 1.4
└── TenFingersTypingTrainer - (Porting TypeScript)/
    ├── DOCS/
    │   └── 10 - App TypeScript - Accordi con Mano Libera... (v.1.4).md
    └── SRC/
        ├── index_(v.1.4).html
        └── help_(v.1.4).html
```
