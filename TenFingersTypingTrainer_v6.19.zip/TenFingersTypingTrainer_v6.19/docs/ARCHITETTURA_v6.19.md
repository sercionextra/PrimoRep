# Architettura — TenFingersTypingTrainer v6.19

## Obiettivo

La release v6.19 risolve l'anomalia di ripetizione acustica della lettera appena digitata durante la dettatura a singoli caratteri (Modalità 1, 3, 5, 6 e modalità con flag Spelling attivo) implementando l'**Ipotesi A** (annullamento atomico del Replay sovrapposto), la protezione sull'inattività reale da tastiera per il timer di stallo a 1 secondo, e l'estensione del layout a 1610px per garantire che i comandi della Dettatura vocale restino su un'unica riga orizzontale.

---

## Analisi Architetturale del Problema

### 1. Dinamica del Token Singolo (`tokenSpan = 1`)
Nella dettatura di parole intere (`tokenSpan > 1`), la voce ha una durata prolungata e l'allievo dispone di finestre ampie per anticipare le battute.
Nella compitazione lettera per lettera o nello Spelling, ogni token ha estensione 1 (`startIndex = i`, `endIndex = i + 1`) e durata fonetica ridotta (150-250 ms).

### 2. Le Tre Cause Concorrenti del Raddoppio Vocale
1. **Collisione Asincrona con il Replay di Stallo a 1 Secondo:**
   Al termine dell'emissione vocale di una lettera, si avvia il timer di stallo (1000 ms). Se l'allievo esita 1 secondo e preme il tasto proprio mentre il Replay automatico parte (o è appena partito per la medesima lettera), il vecchio Replay proseguiva fino al termine. L'allievo udiva quindi la lettera appena digitata pronunciata una seconda volta prima della lettera successiva.
2. **Fallthrough nello Scarico del Lookahead in `updateProgress`:**
   Nello scarico del buffer `pendingLookahead`, l'invocazione di `speakCurrentToken()` impostava `this.isSpeaking = true`. Senza un'interruzione mirata, l'esecuzione scivolava nel blocco sottostante di valutazione del token, ricollocando lo stesso carattere nel buffer `pendingLookahead` e provocandone una seconda pronuncia su `utter.onend`.
3. **Mancata Invalidazione di `pendingLookahead` su Comandi Diretti:**
   Nelle chiamate dirette con `isDirect = true` (come i Replay), un eventuale buffer di lookahead pregresso non veniva azzerato, venendo drenato alla fine del replay e riproducendo una lettera già superata.

---

## Soluzione Architetturale Implementata nella Release v6.19

### 1. Adozione dell'Ipotesi A (Annullamento Atomico del Replay di Stallo)
In `updateProgress()`, all'arrivo di una battuta corretta (`hasError = false`):
Se il motore stava riproducendo un Replay di stallo (`this.isSpeakingReplay === true`), la pronuncia della lettera appena digitata viene interrotta istantaneamente via `this.stopAudioOnly()`.
La lettera appena battuta cessa immediatamente di risuonare, lasciando campo libero alla pronuncia immediata della lettera successiva con latenza zero.

### 2. Keystroke Inactivity Guard per il Timer di Stallo
In `_handleStallTimeout()`:
Il sistema calcola `Date.now() - this.lastKeystrokeTime`. Se l'allievo ha premuto un tasto meno di 950 ms fa, il timer di stallo si riarma per la frazione rimanente e non fa partire alcun replay.
In questo modo il promemoria vocale di 1 secondo scatta unicamente in caso di reale esitazione e non si sovrappone mai a una digitazione ritmata.

### 3. Scarico Controllato del Buffer Lookahead
In `updateProgress()`:
Se `!this.isSpeaking && this.pendingLookahead`:
- Se il token salvato nel buffer è già stato superato (`tokenIndex < activeTokenIdx`), viene scartato per prevenire echi vocali obsoleti;
- Se coincide con `activeTokenIdx`, viene pronunciato e il metodo termina senza ri-accodare duplicati.

### 4. Protezione su `isDirect = true`
In `speakCurrentToken()`:
L'attivazione di un comando diretto invalida preventivamente `this.pendingLookahead = null`, garantendo che al termine dell'emissione non rimangano accodamenti spuri.

### 5. Ottimizzazione Layout Orizzontale a 1610px
In `assets/styles/app.css` e nel controller layout:
- `max-width` per `.header-inner` e `main` esteso da 1600px a 1610px;
- Il limite di trascinamento del widget tachimetro (`relLeft`) elevato a 1610px.
Questo impedisce che la riga superiore dei comandi di Dettatura (pulsanti Replay, Ingranaggio impostazioni, ecc.) vada a capo sui display standard, preservando lo spazio verticale dell'area di digitazione.

---

## Mappa dei Componenti Modificati (Release v6.19)

| Componente | Responsabilità v6.19 |
|---|---|
| `engines/dictation-engine.js` | Ipotesi A (stop del replay su tasto corretto), guard di inattività su battuta, scarico lookahead controllato |
| `assets/styles/app.css` | Allargamento max-width del contenitore principale a 1610px |
| `app/controller/metodi-finestre-layout.js` | Riallineamento del vincolo di posizionamento orizzontale a 1610px |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.19 (`window.APP_VERSION = "6.19"`) |
| `profiles/profile-manager.js` | Profilo utente e persistenza aggiornati ad `AppVersion = "6.19"` |
| `index.html` | Titolo, badge di versione e commenti allineati a v6.19 |
| `help.html` | Note di rilascio v6.19 e riferimenti didattici allineati |
| `docs/MANUALE_UTENTE_v6.19.md` | Manuale didattico per l'utente allineato alla release v6.19 (notazione naturale) |
| `docs/ARCHITETTURA_v6.19.md` | Documento architetturale della release v6.19 |
| `BUILD_MANIFEST.json` | Manifest di integrità aggiornato alla release v6.19 |
