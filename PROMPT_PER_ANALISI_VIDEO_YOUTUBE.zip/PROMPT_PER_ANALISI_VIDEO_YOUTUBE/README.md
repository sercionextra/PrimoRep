# Pipeline di Analisi Video YouTube con Sequenza di Prompt

Questo repository contiene la suite completa di prompt per l'analisi avanzata, la sincronizzazione temporale e la verifica tecnica e visiva di video YouTube e delle relative trascrizioni.

## Struttura dei Prompt e Flusso delle Variabili

| File | Titolo / Funzione | Input | Output / Variabile Prodotta | Note |
|---|---|---|---|---|
| `Prompt_N_1.md` | Protocollo Omni-Verifier (Revisione Tecnica) | `{{TESTO_ORIGINALE}}` | `{{OUTPUT_PROMPT_1}}` | Verifica data live, fact-checking tool |
| `Prompt_N_2.md` | Traduzione in Italiano con Timestamps | `{{OUTPUT_PROMPT_1}}` | `{{OUTPUT_PROMPT_2}}` | **Condizionale**: si salta se l'audio è già in italiano |
| `Prompt_N_3.md` | Riformattazione Strutturata e Paragrafi | `{{INPUT_TESTO_PROMPT_3}}` | `{{OUTPUT_PROMPT_3}}` | Orari tra quadre, grassetti, paragrafi titolati |
| `Prompt_N_4.md` | Sfoltimento Timestamp e Revisione Dettagliata | `{{TESTO_INPUT_PROMPT_4}}` | `{{TESTO_REVISIONATO_P4}}` | **Punto cardine**: produce il testo per Prompt 5 e 6 |
| `Prompt_N_5.md` | Protocollo Chronos & Tech (Analisi Avanzata) | `{{TESTO_REVISIONATO_P4}}` | `{{OUTPUT_PROMPT_5}}` | Rielaborazione ad alta granularità |
| `Prompt_N_6.md` | Protocollo Chronos & Vision (Multimodale) | `{{URL}}` + `{{TESTO_REVISIONATO_P4}}` | `{{OUTPUT_PROMPT_6}}` | Analisi visiva OCR frame-by-frame (2 FPS) e audio |

## Gestione File di Output

Tutte le risposte generate dai prompt vengono visualizzate a video e contestualmente accodate nel file:
`ANALISI_VIDEO.md`

## Istruzioni di Installazione / Decompressione

Per scompattare l'archivio nel path operativo:
```bash
unzip "/new_repository/PROMPT_PER_ANALISI_VIDEO_YOUTUBE.zip" -d /workspace
```
I file saranno immediatamente disponibili in:
`/workspace/PROMPT_PER_ANALISI_VIDEO_YOUTUBE/`
