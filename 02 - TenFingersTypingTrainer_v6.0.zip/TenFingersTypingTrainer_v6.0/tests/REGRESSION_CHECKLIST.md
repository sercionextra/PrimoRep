# Checklist di regressione — v6.0

Eseguire in un browser aggiornato e verificare sia il comportamento UI sia la persistenza.

## Avvio e dati
- [ ] L'app si apre direttamente da `index.html` senza errori JavaScript.
- [ ] Il titolo e i riferimenti di versione mostrano v6.0.
- [ ] Sono presenti le 71 lezioni previste dalla specifica.
- [ ] La prima esecuzione, il profilo demo e il profilo attivo si comportano come in v5.1.
- [ ] Profili esistenti caricati dal Local Storage restano accessibili.

## Metodo e input
- [ ] Verificare le sette modalità: PHRASES, RANDOM, FONEMI, ALL CHARS, TYPING, RANDOM THIS PHRASE, WEAKNESSES.
- [ ] Verificare mappatura dita, posizione di riposo e indicazioni visive.
- [ ] Verificare caratteri accentati, Shift, modificatori e combinazioni.
- [ ] Verificare spazi, Invio (`®`), Tab (`→`), Backspace e correzione progressiva.
- [ ] Verificare auto-correction attiva e disattivata.
- [ ] Verificare avanzamento, ripetizione e completamento frase.

## Voce e feedback
- [ ] Verificare audio feedback e relative opzioni.
- [ ] Verificare dettatura, velocità, voci italiane, maiuscole, apostrofi e spazi.
- [ ] Verificare replay e recupero dopo un errore.
- [ ] Verificare che il watchdog non lasci la dettatura bloccata.

## Finestre e visualizzazione
- [ ] Verificare finestra Mani, Statistiche ed Editor: apertura, chiusura, spostamento e ridimensionamento.
- [ ] Verificare temi e opzioni di visibilità.
- [ ] Verificare tastiera virtuale, keycaps e indicazioni anatomiche.

## Statistiche e profili
- [ ] Verificare metriche di sessione, statistiche per carattere e grafico della velocità.
- [ ] Verificare filtri per modalità e intervallo temporale.
- [ ] Verificare selezione e cancellazione dei campioni.
- [ ] Verificare creazione, rinomina, cambio ed eliminazione profili.
- [ ] Verificare backup, esportazione e importazione.
- [ ] Verificare Editor Custom, formato titoli/separatori e token `®`/`→`.

## Accettazione finale
- [ ] Nessuna perdita di dati osservata.
- [ ] Nessuna funzione della v5.1 risulta rimossa o alterata.
- [ ] Manuale, guida HTML e applicazione sono coerenti.
