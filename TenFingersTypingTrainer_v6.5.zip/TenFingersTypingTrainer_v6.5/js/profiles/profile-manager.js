/* TenFingersTypingTrainer v6.0 | profile-manager.js | Refactoring compatibile: comportamento sorgente preservato. */
class ProfileManager {
  constructor(initialDemoData, defaultCustomText) {
    this.STORAGE_KEY_USERS = "TFTT_USERS";
    this.STORAGE_KEY_ACTIVE = "TFTT_ACTIVE_USER";
    this.STORAGE_KEY_FIRST_RUN = "TFTT_FIRST_RUN_DONE";
    this.STORAGE_PREFIX = "TFTT_PROFILE_";
    this.initialDemoData = initialDemoData;
    this.defaultCustomText = defaultCustomText;
    this.activeUser = null;
    this.profile = null;

    // Gestione combinata quota Local Storage (v.4.7: Politica B + C)
    this.isStorageFull = false; // Stato globale permanente di memoria satura (Badge Header)
    this.quotaExceededNotified = false; // Flag di esercizio per sopprimere avvisi ripetuti durante la digitazione
    this.onQuotaExceeded = null; // Callback verso la UI (apertura modale + comparsa badge)
    this.onQuotaRestored = null; // Callback verso la UI (scomparsa badge al ripristino dello spazio)
  }

  // Registrazione handler per esaurimento memoria (v.4.7)
  setQuotaExceededHandler(callback) {
    this.onQuotaExceeded = typeof callback === "function" ? callback : null;
  }

  // Registrazione handler per ripristino memoria disponibile (v.4.7)
  setQuotaRestoredHandler(callback) {
    this.onQuotaRestored = typeof callback === "function" ? callback : null;
  }

  // Verifica multi-browser per QuotaExceededError (v.4.7)
  _isQuotaExceededError(e) {
    return (
      e &&
      (e.name === "QuotaExceededError" ||
        e.name === "NS_ERROR_DOM_QUOTA_REACHED" ||
        e.code === 22 ||
        e.code === 1014 ||
        e.number === -2147024882)
    );
  }

  // Scrittura protetta centralizzata in LocalStorage con Circuit-Breaker (v.4.7)
  _safeSetItem(key, value) {
    try {
      localStorage.setItem(key, value);
      // Se la scrittura ha successo e prima lo storage risultava saturo, notifica il ripristino
      if (this.isStorageFull) {
        this.isStorageFull = false;
        this.quotaExceededNotified = false;
        if (this.onQuotaRestored) {
          this.onQuotaRestored();
        }
      }
      return true;
    } catch (e) {
      if (this._isQuotaExceededError(e)) {
        this.isStorageFull = true;
        // Notifica visiva scatenata una sola volta per ciascun esercizio (Politica B)
        if (!this.quotaExceededNotified) {
          this.quotaExceededNotified = true;
          if (this.onQuotaExceeded) {
            this.onQuotaExceeded(e);
          }
        }
      } else {
        console.error("Errore di accesso al Local Storage:", e);
      }
      return false;
    }
  }

  init() {
    const firstRunDone = localStorage.getItem(this.STORAGE_KEY_FIRST_RUN);
    let users = this.getUsers();

    if (!firstRunDone) {
      // Eseguito esclusivamente al primissimo avvio assoluto
      this.resetToDefaultArchive();
      this._safeSetItem(this.STORAGE_KEY_FIRST_RUN, "true");
      users = this.getUsers();
    }

    const active = localStorage.getItem(this.STORAGE_KEY_ACTIVE);
    if (active && users.includes(active)) {
      this.loadUser(active);
    } else {
      this.activeUser = null;
      this.profile = null;
      localStorage.removeItem(this.STORAGE_KEY_ACTIVE);
    }
    return users;
  }

  resetToDefaultArchive() {
    let users = this.getUsers();
    if (!users.includes("UTENTE_DEMO")) {
      users.push("UTENTE_DEMO");
      this.saveUsers(users);
    }
    this._safeSetItem(this.STORAGE_KEY_ACTIVE, "UTENTE_DEMO");

    const demoProf = {
      UserID: "UTENTE_DEMO",
      AppVersion: "6.5", // Versione del profilo aggiornata a v6.5
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      ShowErrors: true,
      ShowInstantSpeed: false,
      UseKeyPositions: false,
      UseCustomKeyDistances: false,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      DictationEnabled: false,
      DictationSpeed: 0.9,
      DictationCaps: false,
      DictationApostrophe: false,
      DictationSpelling: false,
      DictationSpace: false,
      HandsTop: 120,
      HandsLeft: 956,
      HandsWidth: 460,
      HandsHeight: 286,
      HandsPinned: true,
      HandsOffsetTop: 45,
      StatTop: 95,
      StatLeft: 630,
      StatWidth: 820,
      StatHeight: 548,
      InstantSpeedTop: 360,
      InstantSpeedLeft: 180,
      InstantSpeedWidth: 920,
      InstantSpeedHeight: 340,
      InstantSpeedMovingAvgWindow: 3,
      CustomText: this.defaultCustomText,
      FonemiCustomText: "",
      FonemiNgramLength: 4,
      FonemiOptions: {
        customFile: false,
        maiuscole: false,
        punteggiatura: false,
        parentesi: false,
        numeri: false,
        matematici: false,
        simboli: false,
        layout: false,
      },
      FonemiProbabilities: {
        maiuscole: 0.3,
        allMaiuscole: 0.3,
        punteggiatura: 0.3,
        parentesi: 0.3,
        numeri: 0.3,
        matematici: 0.3,
        simboli: 0.3,
        layout: 0.3,
      },
      TotaleCaratteri: this.initialDemoData?.TotaleCaratteri || 0,
      TotaleErrori: this.initialDemoData?.TotaleErrori || 0,
      Caratteri: this.initialDemoData?.Caratteri || [],
      Campioni: this.initialDemoData?.Campioni || [],
    };
    this._safeSetItem(
      this.STORAGE_PREFIX + "UTENTE_DEMO",
      JSON.stringify(demoProf),
    );
    this.activeUser = "UTENTE_DEMO";
    this.profile = demoProf;
  }

  getUsers() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY_USERS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  saveUsers(users) {
    return this._safeSetItem(this.STORAGE_KEY_USERS, JSON.stringify(users));
  }

  loadUser(userId) {
    const data = localStorage.getItem(this.STORAGE_PREFIX + userId);
    if (data) {
      try {
        this.profile = JSON.parse(data);
        const activePos =
          this.profile.UseKeyPositions !== undefined
            ? !!this.profile.UseKeyPositions
            : !!this.profile.UseCustomKeyDistances;
        this.profile.UseKeyPositions = activePos;
        this.profile.UseCustomKeyDistances = activePos;

        if (this.profile.FonemiCustomText === undefined) {
          this.profile.FonemiCustomText = "";
        }
        // Inizializzazione difensiva FonemiNgramLength (v.4.4)
        if (this.profile.FonemiNgramLength === undefined) {
          this.profile.FonemiNgramLength = 4;
        }
        // Inizializzazione difensiva DictationSpace (v.5.0)
        if (this.profile.DictationSpace === undefined) {
          this.profile.DictationSpace = false;
        }
        // Inizializzazione difensiva Velocità Istantanea (v6.3)
        if (this.profile.ShowInstantSpeed === undefined) {
          this.profile.ShowInstantSpeed = false;
        }
        if (this.profile.InstantSpeedMovingAvgWindow === undefined) {
          this.profile.InstantSpeedMovingAvgWindow = 3;
        }
        if (!this.profile.FonemiOptions) {
          this.profile.FonemiOptions = {
            customFile: false,
            maiuscole: false,
            punteggiatura: false,
            parentesi: false,
            numeri: false,
            matematici: false,
            simboli: false,
            layout: false,
          };
        }
        if (!this.profile.FonemiProbabilities) {
          this.profile.FonemiProbabilities = {
            maiuscole: 0.3,
            allMaiuscole: 0.3,
            punteggiatura: 0.3,
            parentesi: 0.3,
            numeri: 0.3,
            matematici: 0.3,
            simboli: 0.3,
            layout: 0.3,
          };
        }

        this.activeUser = userId;
        this._safeSetItem(this.STORAGE_KEY_ACTIVE, userId);
        return this.profile;
      } catch (e) {
        console.error(e);
      }
    }
    return this.createUser(userId);
  }

  createUser(userId) {
    const trimmed = userId.trim();
    if (!trimmed) return null;
    const users = this.getUsers();
    if (!users.includes(trimmed)) {
      users.push(trimmed);
      this.saveUsers(users);
    }
    this.profile = {
      UserID: trimmed,
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      ShowErrors: true,
      ShowInstantSpeed: false,
      UseKeyPositions: false,
      UseCustomKeyDistances: false,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      DictationEnabled: false,
      DictationSpeed: 0.9,
      DictationCaps: false,
      DictationApostrophe: false,
      DictationSpelling: false,
      DictationSpace: false,
      HandsTop: 120,
      HandsLeft: 956,
      HandsWidth: 460,
      HandsHeight: 286,
      HandsPinned: true,
      HandsOffsetTop: 45,
      StatTop: 95,
      StatLeft: 630,
      StatWidth: 820,
      StatHeight: 548,
      InstantSpeedTop: 360,
      InstantSpeedLeft: 180,
      InstantSpeedWidth: 920,
      InstantSpeedHeight: 340,
      InstantSpeedMovingAvgWindow: 3,
      CustomText: this.defaultCustomText,
      FonemiCustomText: "",
      FonemiNgramLength: 4, // Default N=4 (Release v.4.4)
      FonemiOptions: {
        customFile: false,
        maiuscole: false,
        punteggiatura: false,
        parentesi: false,
        numeri: false,
        matematici: false,
        simboli: false,
        layout: false,
      },
      FonemiProbabilities: {
        maiuscole: 0.3,
        allMaiuscole: 0.3,
        punteggiatura: 0.3,
        parentesi: 0.3,
        numeri: 0.3,
        matematici: 0.3,
        simboli: 0.3,
        layout: 0.3,
      },
      TotaleCaratteri: 0,
      TotaleErrori: 0,
      Caratteri: [],
      Campioni: [],
    };
    this.activeUser = trimmed;
    this._safeSetItem(this.STORAGE_KEY_ACTIVE, trimmed);
    this.saveProfile();
    return this.profile;
  }

  deleteUser(userId) {
    // 1. Rimuove PRIMA la chiave pesante del profilo per liberare immediatamente memoria fisica nel browser
    try {
      localStorage.removeItem(this.STORAGE_PREFIX + userId);
    } catch (e) {
      console.warn(
        "Impossibile rimuovere la chiave profilo da Local Storage:",
        e,
      );
    }

    if (this.activeUser === userId) {
      this.activeUser = null;
      this.profile = null;
      try {
        localStorage.removeItem(this.STORAGE_KEY_ACTIVE);
      } catch (e) {
        console.warn("Impossibile rimuovere la chiave utente attivo:", e);
      }
    }

    // 2. Aggiorna e persiste la lista utenti rimanente nello spazio appena liberato
    let users = this.getUsers();
    users = users.filter((u) => u !== userId);
    this.saveUsers(users);
  }

  saveProfile() {
    if (this.activeUser && this.profile) {
      this.profile.AppVersion = "6.5";
      return this._safeSetItem(
        this.STORAGE_PREFIX + this.activeUser,
        JSON.stringify(this.profile),
      );
    }
    return false;
  }

  clearUserStats() {
    if (!this.profile) return;
    this.profile.TotaleCaratteri = 0;
    this.profile.TotaleErrori = 0;
    this.profile.Caratteri = [];
    this.profile.Campioni = [];
    this.saveProfile();
  }

  // Inietta e persiste in modo transazionale il profilo importato (con Rollback atomico in caso di memoria piena - v.4.7)
  importProfileData(data, targetUserId) {
    const uId = targetUserId.trim();
    if (!uId) return null;

    // Clona il profilo da importare impostando il nome target
    const profileToSave = JSON.parse(JSON.stringify(data));
    profileToSave.UserID = uId;

    // 1. Tenta prima la persistenza fisica del profilo su disco
    const profileSaved = this._safeSetItem(
      this.STORAGE_PREFIX + uId,
      JSON.stringify(profileToSave),
    );

    if (!profileSaved) {
      // Rollback: la scrittura è fallita, nessuna alterazione dello stato in memoria RAM
      return null;
    }

    // 2. Prepara e tenta la persistenza della lista utenti aggiornata
    const existingUsers = this.getUsers();
    let usersToSave = [...existingUsers];
    if (!usersToSave.includes(uId)) {
      usersToSave.push(uId);
    }

    const usersSaved = this._safeSetItem(
      this.STORAGE_KEY_USERS,
      JSON.stringify(usersToSave),
    );

    if (!usersSaved) {
      // Rollback transazionale: rimuove il profilo appena scritto su disco per evitare dati orfani
      try {
        localStorage.removeItem(this.STORAGE_PREFIX + uId);
      } catch (e) {
        console.warn("Impossibile eseguire il rollback del profilo:", e);
      }
      return null;
    }

    // 3. Commit in memoria RAM solo a persistenza fisica confermata al 100% su disco
    this.profile = profileToSave;
    this.activeUser = uId;
    this._safeSetItem(this.STORAGE_KEY_ACTIVE, uId);
    return uId;
  }

  // Esportazione del profilo dell'utente specificato (o dell'utente attivo)
  exportUserJson(userId = null) {
    const targetId = userId ? userId.trim() : this.activeUser;
    if (!targetId) return null;

    // Se è l'utente attivo in memoria, serializza lo stato runtime aggiornato
    if (targetId === this.activeUser && this.profile) {
      return JSON.stringify(this.profile, null, 2);
    }

    // Se è un altro utente dell'archivio, carica dal localStorage
    const raw = localStorage.getItem(this.STORAGE_PREFIX + targetId);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      return JSON.stringify(parsed, null, 2);
    } catch (e) {
      return null;
    }
  }

  // Esportazione diretta del profilo attivo in formato JSON integrale
  exportJson() {
    return this.exportUserJson(this.activeUser);
  }
}

// =======================================================
// MARKOVIAN PHONEME GENERATOR AVANZATO (Release v.4.3)
// =======================================================
