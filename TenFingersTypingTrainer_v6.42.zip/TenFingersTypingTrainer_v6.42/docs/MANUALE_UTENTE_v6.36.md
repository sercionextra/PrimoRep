# Manuale Utente — Aggiornamento v6.36

## Novità della versione v6.36

1. **Chiusura e riepilogo finale dell'Interrogazione:**
   - Risolto il problema che impediva la chiusura della finestra dell'Interrogazione e la visualizzazione del messaggio riepilogativo finale al termine del set di domande premendo **Concludi sessione**, **Sospendi** o **Abbandona**.
