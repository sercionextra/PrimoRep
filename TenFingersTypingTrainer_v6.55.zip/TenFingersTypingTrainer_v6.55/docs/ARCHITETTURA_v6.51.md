# Architettura TenFingersTypingTrainer v6.51

Documento di aggiornamento architetturale rispetto alla v6.50.

## 1. Obiettivo della Release v6.51
Risolvere il mancato mantenimento dello stato in modalità **Phrases - Custom** alla chiusura e riapertura del browser (e al cambio temporaneo verso altre modalità di esercizio), preservando in modo indipendente l'avanzamento del corso Standard e quello degli esercizi Custom.

## 2. Interventi Architetturali
1. **Estensione schema profilo (`js/profiles/profile-manager.js`):**
   - Aggiunti i campi `LessonsSource` (`"standard"` | `"custom"`), `CustomLesson` (indice 0-based) e `CustomExercise` (indice 0-based) in `initDemoProfile()`, `createUser()` e con inizializzazione difensiva in `loadUser()`.
   - I campi `Lesson`, `MaxLessonReached` ed `Exercise` restano dedicati esclusivamente al corso Standard.
2. **Ripristino e commutazione sorgente (`js/app/controller/metodi-profili-modali.js`):**
   - `setLessonsSource(source, { skipStart = false, persist = true } = {})` ripristina gli indici salvati della sorgente richiesta (`CustomLesson`/`CustomExercise` per `"custom"`, `Lesson`/`Exercise` per `"standard"`) con clamp sugli estremi dell'array e salva `LessonsSource` sul profilo quando `persist` è `true`.
   - `loginUser(userId)` ri-parsa `this.customLessons` da `prof.CustomText` (o `defaultCustomText`) e seleziona `"custom"` quando `Mode === 0` e `prof.LessonsSource === "custom"` (con almeno una lezione custom disponibile), evitando il reset forzato a `"standard"`.
   - `confirmSelectPhrase()` salva la coppia lezione/frase nella sezione corrispondente alla sorgente attiva (`CustomLesson`/`CustomExercise` oppure `Lesson`/`Exercise`).
3. **Navigazione e modalità (`js/app/controller/metodi-toolbar-modalita.js`, `js/app/controller/metodi-navigazione-dialoghi.js`):**
   - `cboLessons`, `navLesson()`, `navPhrase()` e `randomPhrase()` aggiornano e salvano `CustomLesson`/`CustomExercise` quando `activeLessonsSource === "custom"`.
   - `updateModeUI()` attua la commutazione non distruttiva (Opzione B): nelle modalità diverse da `0` (`Phrases`) imposta temporaneamente `"standard"` con `{ skipStart: true, persist: false }` senza alterare `prof.LessonsSource`, ripristinando `"custom"` al ritorno su `Mode === 0`.
