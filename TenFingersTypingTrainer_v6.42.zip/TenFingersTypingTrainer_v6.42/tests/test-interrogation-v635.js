#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const svgRenderer = fs.readFileSync(path.join(root, "js/ui/interrogation-svg-renderer.js"), "utf8");
const uiJs = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

// 1. Tastiera B/N senza punti azzurri e trattini f/j
assert(css.includes(".interr-keyboard-bn .key .base-dot") && css.includes(".interr-keyboard-bn .key .key-bump"), "CSS deve nascondere .base-dot e .key-bump in .interr-keyboard-bn");
assert(svgRenderer.includes('clone.querySelectorAll(".key .base-dot, .key .key-bump").forEach((el) => el.remove())'), "SVG renderer deve rimuovere .base-dot e .key-bump dal clone");

// 2. Titoli domanda e regole CSS #interrogationQuestionTitle / #target
assert(css.includes("#interrogationQuestionTitle") && css.includes("color: yellow;") && css.includes("font-size: x-large;"), "Regola CSS #interrogationQuestionTitle mancante");
assert(css.includes("#target") && css.includes("background-color: yellow;") && css.includes("color: black;"), "Regola CSS #target mancante");
assert(uiJs.includes('setQuestionTitle(\'CARATTERE da analizzare: "\', target.char, \'"\')'), "Titolo CARATTERE non aggiornato");
assert(uiJs.includes('setQuestionTitle(\'TASTO selezionato (CARATTERE estratto): "\', target.char, \'"\')'), "Titolo TASTO non aggiornato");
assert(uiJs.includes('setQuestionTitle("Individua i TASTI/CARATTERI per il dito: ", fLabel)'), "Titolo DITO non aggiornato");
assert(uiJs.includes('setQuestionTitle("Tasti in POSIZIONE di RIPOSO — ", handLabel)'), "Titolo HOME_ROW non aggiornato");

// 3. Posizione di Riposo: ordine bottoni, 4 colori distinti, nessun indizio tra parentesi
assert(css.includes(".interr-homerow-pick-0") && css.includes(".interr-homerow-pick-3"), "Classi colore bottoni Posizione di Riposo mancanti");
assert(css.includes(".interr-keyboard-bn .key.interr-key-row-0 .key-bg") && css.includes(".interr-keyboard-bn .key.interr-key-row-3 .key-bg"), "Classi colore tasti SVG Posizione di Riposo mancanti");
assert(uiJs.includes("Tasto #${ent.idx + 1} selezionato"), "Testo pulsante tasto selezionato senza indizio mancante");
assert(!uiJs.includes('ent.keyId.replace("key_", "")'), "Il pulsante non deve mostrare il nome del tasto tra parentesi");

// 4. Finestra Seleziona carattere / tasto: NESSUNO sopra/sotto e righe ordinate
assert(html.includes('id="interrAsciiPopoverTitle"'), "Span #interrAsciiPopoverTitle mancante in index.html");
assert(uiJs.includes("makeNoneButton()") && uiJs.includes("body.appendChild(makeNoneButton())"), "Pulsante NESSUNO sopra/sotto mancante");
assert(uiJs.includes('["à", "è", "é", "ì", "ò", "ù", "ç"]') && uiJs.includes('["WIN-sn", "WIN-dx", "ALT", "ALTGR", "MENU", "SPAZIO", "INVIO", "BACK"]'), "Righe ordinate caratteri/tasti speciali mancanti");

// 5. Selezione sequenziale con singolo pulsante per Coppia sopra / Coppia sotto
assert(uiJs.includes("if (grp.slots.length === 2)") && uiJs.includes("keepOpen: true"), "Logica singolo pulsante sequenziale per Coppia sopra/sotto mancante");

console.log("PASS: Tutte le verifiche v6.35 superate.");
