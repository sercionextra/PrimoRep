/* TenFingersTypingTrainer v6.43 | lesson-curriculum-scope.js | Mappa dichiarativa del piano di studio (71 lezioni) per Interrogazione. */
(function (global) {
  "use strict";

  const SHIFT_FIRST_LESSON_IDX = 25; // Lezione 26: ShiftDestro
  const ALTGR_FIRST_LESSON_IDX = 54; // Lezione 55: "@" (primo carattere AltGr nel corso)

  // Correzioni puntuali per caratteri spuri presenti in frasi di lezioni precedenti al loro modulo dedicato
  const EXPLICIT_CHAR_FIRST_LESSON = {
    ",": 22, // Lezione 23: ","
    ".": 23, // Lezione 24: "."
    "'": 24, // Lezione 25: "'"
    "\n": 27, // Lezione 28: "Invio"
    "?": 65, // Lezione 66: "?"
    "\t": 70, // Lezione 71: "Tab"
  };

  const EXPLICIT_KEY_FIRST_LESSON = {
    key_shift_r: 25, // Lezione 26: ShiftDestro
    key_shift_l: 26, // Lezione 27: ShiftSinistro
    key_enter: 27, // Lezione 28: Invio
    key_tab: 70, // Lezione 71: Tab
  };

  function getEmbeddedLessons() {
    if (typeof EMBEDDED_LESSONS !== "undefined" && Array.isArray(EMBEDDED_LESSONS)) {
      return EMBEDDED_LESSONS;
    }
    if (global && Array.isArray(global.EMBEDDED_LESSONS)) {
      return global.EMBEDDED_LESSONS;
    }
    return [];
  }

  function getCatalogData() {
    if (global && global.INTERROGATION_CATALOG_DATA) {
      return global.INTERROGATION_CATALOG_DATA;
    }
    return null;
  }

  function buildIndex() {
    const lessons = getEmbeddedLessons();
    const catData = getCatalogData();

    const firstLessonByChar = new Map();
    Object.entries(EXPLICIT_CHAR_FIRST_LESSON).forEach(([ch, idx]) => {
      firstLessonByChar.set(ch, idx);
    });

    for (let idx = 0; idx < lessons.length; idx++) {
      const phrases = Array.isArray(lessons[idx].phrases) ? lessons[idx].phrases : [];
      for (let p = 0; p < phrases.length; p++) {
        const str = String(phrases[p] || "");
        for (let c = 0; c < str.length; c++) {
          const ch = str[c];
          if (!firstLessonByChar.has(ch)) {
            firstLessonByChar.set(ch, idx);
          }
        }
      }
    }

    const firstLessonByKey = new Map();
    Object.entries(EXPLICIT_KEY_FIRST_LESSON).forEach(([kId, idx]) => {
      firstLessonByKey.set(kId, idx);
    });

    const firstLessonByFinger = new Map();

    if (catData && catData.seed) {
      const mappings = Array.isArray(catData.seed.characterMappings) ? catData.seed.characterMappings : [];
      for (let i = 0; i < mappings.length; i++) {
        const m = mappings[i];
        const lIdx = firstLessonByChar.get(m.value);
        if (lIdx !== undefined && m.physicalKeySemanticId) {
          const kId = String(m.physicalKeySemanticId).replace(/^key\./, "");
          if (!firstLessonByKey.has(kId) || lIdx < firstLessonByKey.get(kId)) {
            firstLessonByKey.set(kId, lIdx);
          }
        }
      }

      const pKeys = Array.isArray(catData.seed.physicalKeys) ? catData.seed.physicalKeys : [];
      for (let i = 0; i < pKeys.length; i++) {
        const pk = pKeys[i];
        const lIdx = firstLessonByKey.get(pk.keyId);
        if (lIdx !== undefined && pk.assignedFinger !== undefined && pk.assignedFinger !== null) {
          const fId = String(pk.assignedFinger);
          if (!firstLessonByFinger.has(fId) || lIdx < firstLessonByFinger.get(fId)) {
            firstLessonByFinger.set(fId, lIdx);
          }
        }
      }
    }

    return {
      lessons,
      firstLessonByChar,
      firstLessonByKey,
      firstLessonByFinger,
    };
  }

  let _cachedIndex = null;
  function getIndex() {
    const lessons = getEmbeddedLessons();
    const catData = getCatalogData();
    if (
      !_cachedIndex ||
      (_cachedIndex.lessons.length === 0 && lessons.length > 0) ||
      (_cachedIndex.firstLessonByKey.size <= Object.keys(EXPLICIT_KEY_FIRST_LESSON).length && catData)
    ) {
      _cachedIndex = buildIndex();
    }
    return _cachedIndex;
  }

  function getLessonCount() {
    return getIndex().lessons.length;
  }

  function getLessonName(lessonIdx) {
    const lessons = getIndex().lessons;
    const item = lessons[lessonIdx];
    return item ? String(item.name || "") : "";
  }

  function getFirstLessonForChar(ch) {
    const val = getIndex().firstLessonByChar.get(String(ch));
    return val !== undefined ? val : null;
  }

  function getFirstLessonForModifier(modName) {
    if (modName === "normal" || modName === "none") return 0;
    if (modName === "shift") return SHIFT_FIRST_LESSON_IDX;
    if (modName === "altgr") return ALTGR_FIRST_LESSON_IDX;
    return null; // shiftAltgr non coperto nelle 71 lezioni standard
  }

  function getFirstLessonForKey(keyId) {
    const clean = String(keyId || "").replace(/^key\./, "");
    const val = getIndex().firstLessonByKey.get(clean);
    return val !== undefined ? val : null;
  }

  function getFirstLessonForFinger(fingerId) {
    const clean = String(fingerId || "").replace(/^finger\./, "");
    const val = getIndex().firstLessonByFinger.get(clean);
    return val !== undefined ? val : null;
  }

  function getScopeUpToLesson(maxLessonIndex) {
    const idx = getIndex();
    const maxIdx = Math.max(0, Math.min(Math.max(0, idx.lessons.length - 1), parseInt(maxLessonIndex, 10) || 0));

    const unlockedChars = new Set();
    idx.firstLessonByChar.forEach((lIdx, ch) => {
      if (lIdx <= maxIdx) unlockedChars.add(ch);
    });

    const unlockedKeyIds = new Set();
    idx.firstLessonByKey.forEach((lIdx, kId) => {
      if (lIdx <= maxIdx) unlockedKeyIds.add(kId);
    });

    const unlockedFingerIds = new Set();
    idx.firstLessonByFinger.forEach((lIdx, fId) => {
      if (lIdx <= maxIdx) unlockedFingerIds.add(fId);
    });

    const unlockedModifiers = new Set(["normal", "none"]);
    if (maxIdx >= SHIFT_FIRST_LESSON_IDX) unlockedModifiers.add("shift");
    if (maxIdx >= ALTGR_FIRST_LESSON_IDX) unlockedModifiers.add("altgr");

    return {
      maxLessonIndex: maxIdx,
      unlockedChars,
      unlockedKeyIds,
      unlockedFingerIds,
      unlockedModifiers,
    };
  }

  function getSlotConstraint(slotName, slotChar, maxLessonIndex) {
    if (maxLessonIndex === null || maxLessonIndex === undefined) {
      return { allowed: true, requiredLesson1Based: null };
    }
    const maxIdx = Math.max(0, parseInt(maxLessonIndex, 10) || 0);
    if (slotChar && slotChar !== "NONE") {
      const req = getFirstLessonForChar(slotChar);
      if (req === null) {
        return { allowed: false, requiredLesson1Based: null };
      }
      return {
        allowed: req <= maxIdx,
        requiredLesson1Based: req + 1,
      };
    }
    const reqMod = getFirstLessonForModifier(slotName);
    if (reqMod === null) {
      return { allowed: false, requiredLesson1Based: null };
    }
    return {
      allowed: reqMod <= maxIdx,
      requiredLesson1Based: reqMod + 1,
    };
  }

  function getKeyConstraint(keyId, maxLessonIndex) {
    if (maxLessonIndex === null || maxLessonIndex === undefined) {
      return { allowed: true, requiredLesson1Based: null };
    }
    if (!keyId) {
      // Bordo tastiera (NONE): sempre in programma
      return { allowed: true, requiredLesson1Based: null };
    }
    const maxIdx = Math.max(0, parseInt(maxLessonIndex, 10) || 0);
    const req = getFirstLessonForKey(keyId);
    if (req === null) {
      return { allowed: false, requiredLesson1Based: null };
    }
    return {
      allowed: req <= maxIdx,
      requiredLesson1Based: req + 1,
    };
  }

  function getActiveNeighborGroupCount(keyId, maxLessonIndex, layoutMeta) {
    if (maxLessonIndex === null || maxLessonIndex === undefined) return 4;
    const meta = layoutMeta || (global && global.InterrogationLayoutMetadata);
    if (!meta || typeof meta.getNeighbors !== "function") return 4;
    const neighbors = meta.getNeighbors(keyId) || {};
    const groups = [
      { id: "top", slots: ["topLeft", "topRight"] },
      { id: "left", slots: ["left"] },
      { id: "right", slots: ["right"] },
      { id: "bottom", slots: ["bottomLeft", "bottomRight"] },
    ];
    let activeCount = 0;
    for (let i = 0; i < groups.length; i++) {
      const grp = groups[i];
      if (keyId === "key_enter" && grp.id === "left") {
        const cPlus = getKeyConstraint("key_plus", maxLessonIndex);
        const cUgrave = getKeyConstraint("key_ugrave", maxLessonIndex);
        if (cPlus.allowed || cUgrave.allowed) activeCount += 1;
        continue;
      }
      const hasAllowedSlot = grp.slots.some((sName) => getKeyConstraint(neighbors[sName], maxLessonIndex).allowed);
      if (hasAllowedSlot) activeCount += 1;
    }
    return activeCount;
  }

  global.LessonCurriculumScope = Object.freeze({
    getLessonCount,
    getLessonName,
    getFirstLessonForChar,
    getFirstLessonForModifier,
    getFirstLessonForKey,
    getFirstLessonForFinger,
    getScopeUpToLesson,
    getSlotConstraint,
    getKeyConstraint,
    getActiveNeighborGroupCount,
    resetCacheForTest: () => {
      _cachedIndex = null;
    },
  });
})(typeof window !== "undefined" ? window : globalThis);
