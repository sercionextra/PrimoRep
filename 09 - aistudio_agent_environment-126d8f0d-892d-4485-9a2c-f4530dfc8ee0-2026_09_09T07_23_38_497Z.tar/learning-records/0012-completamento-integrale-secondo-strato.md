# Completamento integrale del secondo strato (F2L)

L'utente ha completato con successo l'intero secondo strato (tutti e 4 gli spigoli della fascia centrale sono posizionati e orientati correttamente, con base bianca intatta).
La difficoltà di disallineamento è stata superata e la padronanza delle combinazioni di inserimento è consolidata.
Si passa all'Ultimo Strato (Last Layer), partendo dall'orientamento degli spigoli superiori (Croce Gialla).
