# Architettura — TenFingersTypingTrainer v6.17

## Obiettivo

La release v6.17 perfeziona l'architettura del motore vocale `DictationEngine`, introducendo il **disaccoppiamento dello stato logico applicativo dall'hardware asincrono del browser** e lo **scarico proattivo del buffer vocale lookahead**. L'intervento risolve in radice il fenomeno dell'arresto silente della voce durante la digitazione ordinaria, eliminando il vicolo cieco in cui parole in attesa venivano intrappolate in coda senza venire annunciate e garantendo l'attivazione immediata del timer di inattività a 1 secondo al fermarsi dell'allievo.

---

## Analisi Architetturale: Cause dell'Arresto Silente e Mancata Attivazione del Timer

### 1. La Trappola del Ghost-Lock Hardware in `speakCurrentToken()`
Nel codice delle versioni precedenti:
* Il metodo `speakCurrentToken()` verificava la condizione:
  `if (!isDirect && (this.isSpeaking || (this.synth && (this.synth.speaking || this.synth.pending))))`
* Se la voce dell'applicazione era libera (`this.isSpeaking === false`), ma il browser manteneva attiva la flag hardware `speechSynthesis.speaking` (noto difetto di Chromium che lascia tale proprietà a `true` anche ad audio terminato o azzerato), la richiesta veniva interpretata erroneamente come "voce in riproduzione".
* Il token corrente veniva quindi salvato in `this.pendingLookahead` e il metodo usciva immediatamente senza invocare `synth.speak()`.
* Poiché in realtà nessun enunciato stava suonando nel componente JavaScript, l'evento `utter.onend` non si sarebbe mai verificato. Il buffer `pendingLookahead` rimaneva congelato per sempre, e tutte le chiamate successive durante la digitazione ordinaria ricadevano nella medesima trappola.
* La voce taceva completamente, costringendo l'allievo a proseguire leggendo solo il testo guida a schermo.

### 2. Perché Solo Backspace, CTRL+SHIFT+SPAZIO o l'Errore Risolvevano il Blocco?
Durante la normale digitazione corretta, l'invocazione di `speakCurrentToken()` avviene con parametro `isDirect = false` e senza invocare `stopAudioOnly()`.
Al contrario:
* La pressione del tasto Backspace (`notifyErrorCorrection`);
* La combinazione da tastiera `CTRL+SHIFT+SPAZIO` (`replay`);
* La digitazione di un tasto errato (`notifyError`);
eseguono tre operazioni risolutive:
1. Chiamano `stopAudioOnly()`, che esegue `synth.cancel()` e forza `this.isSpeaking = false`;
2. Riallineano l'indice `currentIndex` all'esatta posizione del cursore fisico (`matchLen`);
3. Invocano `speakCurrentToken(..., isDirect = true)`, che scavalca completamente il controllo sul sintetizzatore ed emette direttamente la voce.

### 3. Perché il Timer di 1 Secondo Non Si Attivava Durante la Scrittura?
La mancata attivazione del timer di 1 secondo durante la scrittura silente è dovuta a due fattori concorrenti:
1. **Debounce Continuo su Digitazione**: all'interno di `updateProgress()`, ogni singola battuta corretta invoca `this.resetStallTimer()`, il quale cancella immediatamente il timer attivo (`clearStallTimer()`). Finché l'allievo digita tasti (a un ritmo tipico di una battuta ogni 150-500 ms), il contatore viene costantemente azzerato e rischedulato, impedendo al timeout di 1000 ms di giungere a compimento durante il moto di digitazione. Il timer di stallo per definizione misura la fermata dell'utente.
2. **Loop di Rinvio in Presenza di Ghost Hardware**: se l'allievo smetteva di digitare, `resetStallTimer()` rilevava `isHardwareSpeaking = true` (dovuto al bug del browser). Invece di far partire il timer di replay a 1000 ms, schedulava una chiamata ricorsiva a `resetStallTimer` per verificare se la voce terminasse. Se il browser manteneva lo stato congelato, la funzione continuava a rinviare se stessa senza mai invocare `_handleStallTimeout()`.

---

## Soluzione Architetturale Implementata nella Release v6.17

### 1. Disaccoppiamento dello Stato Logico Applicativo dall'Hardware
* L'automa a stati dell'applicazione riconosce la proprietà `this.isSpeaking` come unico indicatore affidabile dell'effettiva riproduzione audio generata dal trainer.
* In `speakCurrentToken()`:
  - Se l'applicazione sta parlando (`this.isSpeaking === true`), il nuovo token viene memorizzato nel buffer lookahead a profondità 1 (`pendingLookahead`);
  - Se l'applicazione NON sta parlando (`this.isSpeaking === false`), ma l'hardware del browser segnala ancora `speaking: true`, si tratta con certezza di uno stato orfano. Il sistema esegue preventivamente `synth.cancel()` e procede immediatamente all'emissione audio con `synth.speak(utter)`.

### 2. Scarico Proattivo di `pendingLookahead` in `updateProgress()`
* A ogni avanzamento di battuta in `updateProgress()`, se `this.isSpeaking === false` e nel buffer è presente un token lookahead in attesa, questo viene prelevato e riprodotto istantaneamente.

### 3. Riarmo Diretto del Timer di Inattività in `resetStallTimer()`
* In `resetStallTimer()` e in `_handleStallTimeout()`:
  - Se `this.isSpeaking === false` e l'hardware segnala anomalie (`isHardwareSpeaking === true`), il sistema azzera il ghost hardware con `synth.cancel()` e avvia direttamente il timer di 1 secondo (1000 ms) per il Replay cadenzato;
  - Non avviene alcun rinvio ricorsivo a vuoto quando l'applicazione è in silenzio.

### 4. Ripristino Deterministico in `stopAudioOnly()`
* Azzeramento esplicito di `this.lastSpeechStartTime = 0` all'arresto vocale, impedendo calcoli residui errati della durata dell'enunciato.

---

## Mappa dei Componenti Aggiornata (Release v6.17)

| Componente | Responsabilità v6.17 |
|---|---|
| `engines/dictation-engine.js` | Disaccoppiamento dello stato logico applicativo dall'hardware; eliminazione del blocco in `pendingLookahead` quando `isSpeaking === false`; scarico proattivo del lookahead in `updateProgress`; disaccoppiamento del timer di inattività (1 secondo) in `resetStallTimer` da ghost hardware; reset di `lastSpeechStartTime = 0` in `stopAudioOnly` |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.17 (`window.APP_VERSION = "6.17"`) |
| `profiles/profile-manager.js` | Profilo utente e serializzazione persistente aggiornati ad `AppVersion = "6.17"` |
| `index.html` | Intestazione, badge di versione e commenti allineati a v6.17 |
| `help.html` | Note di rilascio v6.17, documentazione didattica aggiornata, badge e riferimenti a v6.17 |
| `docs/MANUALE_UTENTE_v6.17.md` | Manuale didattico per l'utente allineato alla release v6.17 (esposto in chiaro senza formule LaTeX) |
| `tests/test-dictation-adaptive.js` | Suite estesa con TEST 12 dedicato alla validazione del disaccoppiamento hardware e protezione Ghost-Lock orfano |
| `tests/runtime-smoke.js` | Verifica runtime aggiornata alla versione 6.17 |
| `tests/static-check.js` | Validazione statica aggiornata alla versione 6.17 |
| `tests/REGRESSION_CHECKLIST.md` | Protocollo di regressione aggiornato alla versione 6.17 con sezione specifica |
| `BUILD_MANIFEST.json` | Manifest di integrità e tracciamento allineato alla release v6.17 |
