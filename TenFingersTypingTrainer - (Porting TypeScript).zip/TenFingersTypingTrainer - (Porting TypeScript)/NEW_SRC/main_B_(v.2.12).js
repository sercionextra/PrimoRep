// main_A_(v.2.12).js

// STATISTICS MANAGER (Histogram & Speed Chart)
class StatisticsManager {
  constructor(profileMgr) {
    this.profileMgr = profileMgr;
    this.sortMode = "freqRel"; // freqRel, freqAss, errRel, errAss, ditoRel, ditoAss
    this.speedMetric = "bpm"; // bpm, chars, errRel, errAss
    this.filterTypes = [1, 2, 3, 4, 5, 6, 7];
    this.selectedSampleIndices = new Set();
    this.currentFilteredSamples = [];
  }

  renderHistogram() {
    const container = document.getElementById("statsHistogramSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Caratteri || p.Caratteri.length === 0) {
      container.innerHTML = '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun dato statistico disponibile</div>';
      return;
    }

    // Process data
    let list = p.Caratteri.map(c => ({
      char: String.fromCharCode(c.CharUnicode),
      freq: c.Frequenza || 0,
      err: c.Errori || 0,
      errRate: c.Frequenza > 0 ? (c.Errori / c.Frequenza) * 100 : 0,
      finger: (KEY_MAP[String.fromCharCode(c.CharUnicode)] || {}).finger || 0
    }));

    // Sorting
    const isPerDito = (this.sortMode === "ditoRel" || this.sortMode === "ditoAss");
    if (this.sortMode === "freqRel" || this.sortMode === "freqAss") {
      list.sort((a, b) => b.freq - a.freq);
    } else if (this.sortMode === "errRel") {
      list.sort((a, b) => b.errRate - a.errRate);
    } else if (this.sortMode === "errAss") {
      list.sort((a, b) => b.err - a.err);
    } else if (this.sortMode === "ditoRel") {
      list.sort((a, b) => (a.finger || 99) - (b.finger || 99) || b.errRate - a.errRate);
    } else if (this.sortMode === "ditoAss") {
      list.sort((a, b) => (a.finger || 99) - (b.finger || 99) || b.err - a.err);
    }

    // Punto 1 & 2: Ottimizzazione dello spazio verticale per sfruttare tutta l'altezza utile
    // Riduciamo al minimo assoluto le aree vuote sopra e sotto il grafico
    const maxFreq = Math.max(1, ...list.map(x => x.freq));
    const maxErr = Math.max(1, ...list.map(x => x.err));
    const maxErrRate = Math.max(0.1, ...list.map(x => x.errRate));

    const isErrRelMode = (this.sortMode === "errRel" || this.sortMode === "ditoRel");
    const isErrAssMode = (this.sortMode === "errAss" || this.sortMode === "ditoAss");

    const activeMax = isErrRelMode ? maxErrRate : (isErrAssMode ? maxErr : maxFreq);

    // Altezza dinamica adattata all'altezza del container (default 320px)
    const containerH = container.clientHeight || 320;
    const height = Math.max(280, containerH);

    // Riduzione al minimo dei margini verticali:
    // - Linea di base a soli 26px dal fondo (spazio minimo per la sola etichetta del carattere a y = chartBaseline + 17)
    // - Spazio superiore ridotto a 24px se c'è l'intestazione dito, o a 14px se non c'è
    const chartBaseline = height - 26;
    const topLimit = isPerDito ? 24 : 14;
    const maxBarH = chartBaseline - topLimit - 6;

    const fingerMeta = {
      1: { name: "Mignolo Sx", color: "#ef4444", fill: "rgba(239, 68, 68, 0.08)", stroke: "rgba(239, 68, 68, 0.6)" },
      2: { name: "Anulare Sx", color: "#f59e0b", fill: "rgba(245, 158, 11, 0.08)", stroke: "rgba(245, 158, 11, 0.6)" },
      3: { name: "Medio Sx", color: "#10b981", fill: "rgba(16, 185, 129, 0.08)", stroke: "rgba(16, 185, 129, 0.6)" },
      4: { name: "Indice Sx", color: "#3b82f6", fill: "rgba(59, 130, 246, 0.08)", stroke: "rgba(59, 130, 246, 0.6)" },
      5: { name: "Pollice Sx", color: "#a855f7", fill: "rgba(168, 85, 247, 0.08)", stroke: "rgba(168, 85, 247, 0.6)" },
      6: { name: "Pollice Dx", color: "#a855f7", fill: "rgba(168, 85, 247, 0.08)", stroke: "rgba(168, 85, 247, 0.6)" },
      7: { name: "Indice Dx", color: "#3b82f6", fill: "rgba(59, 130, 246, 0.08)", stroke: "rgba(59, 130, 246, 0.6)" },
      8: { name: "Medio Dx", color: "#10b981", fill: "rgba(16, 185, 129, 0.08)", stroke: "rgba(16, 185, 129, 0.6)" },
      9: { name: "Anulare Dx", color: "#f59e0b", fill: "rgba(245, 158, 11, 0.08)", stroke: "rgba(245, 158, 11, 0.6)" },
      10: { name: "Mignolo Dx", color: "#ef4444", fill: "rgba(239, 68, 68, 0.08)", stroke: "rgba(239, 68, 68, 0.6)" }
    };

    const barPitch = 36;
    const barWidth = 24;
    const startX = 20;
    const width = Math.max(760, list.length * barPitch + 40);

    let svg = `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" style="width:${width}px;min-width:${width}px;height:${height}px;display:block;">`;

    // Se ordinamento PER DITO, disegna i riquadri colorati per raggruppamento
    if (isPerDito) {
      let currentFinger = null;
      let groupStartIndex = 0;
      let groups = [];

      list.forEach((item, idx) => {
        if (item.finger !== currentFinger) {
          if (currentFinger !== null) {
            groups.push({ finger: currentFinger, start: groupStartIndex, count: idx - groupStartIndex });
          }
          currentFinger = item.finger;
          groupStartIndex = idx;
        }
      });
      if (currentFinger !== null) {
        groups.push({ finger: currentFinger, start: groupStartIndex, count: list.length - groupStartIndex });
      }

      groups.forEach(grp => {
        const meta = fingerMeta[grp.finger] || { name: `Dito ${grp.finger}`, color: "#64748b", fill: "rgba(100, 116, 139, 0.08)", stroke: "rgba(100, 116, 139, 0.5)" };
        const gx = startX + grp.start * barPitch - 5;
        const gw = grp.count * barPitch;
        const gy = 4;
        const gh = chartBaseline - gy + 22;

        // Riquadro perimetrale con colore coerente del dito
        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" rx="6" fill="${meta.fill}" stroke="${meta.stroke}" stroke-width="1.6" />`;
        // Badge di intestazione del dito
        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="17" rx="5" fill="${meta.color}" opacity="0.9" />`;
        svg += `<text x="${gx + gw / 2}" y="${gy + 12.5}" font-size="10" font-weight="700" fill="#ffffff" text-anchor="middle">${meta.name}</text>`;
      });
    }

    // Baseline dell'asse X
    svg += `<line x1="6" y1="${chartBaseline}" x2="${width - 6}" y2="${chartBaseline}" stroke="var(--border-color)" stroke-width="1.5" />`;

    list.forEach((item, idx) => {
      const x = startX + idx * barPitch;
      const meta = fingerMeta[item.finger] || { color: "#3b82f6" };
      let primaryVal = item.freq;
      let displayVal = `${item.freq}`;

      if (isErrRelMode) {
        primaryVal = item.errRate;
        displayVal = `${item.errRate.toFixed(1)}%`;
      } else if (isErrAssMode) {
        primaryVal = item.err;
        displayVal = `${item.err}`;
      }

      // Normalizzazione proporzionale al massimo presente
      const barH = activeMax > 0 ? (primaryVal / activeMax) * maxBarH : 0;
      const y = chartBaseline - barH;

      // Colore della barra principale: colore del dito in modalità per dito, altrimenti blu/rosso
      const barColor = isPerDito ? meta.color : (isErrRelMode || isErrAssMode ? "#ef4444" : "#3b82f6");

      svg += `<g class="hist-bar" data-char="${htmlEscape(item.char)}" data-freq="${item.freq}" data-err="${item.err}" data-rate="${item.errRate.toFixed(1)}" data-finger="${meta.name || ''}">`;
      
      // Barra principale
      if (barH > 0) {
        svg += `<rect x="${x}" y="${y}" width="${barWidth}" height="${barH}" rx="3" fill="${barColor}" opacity="0.85" />`;
      }

      // Sovrapposizione errori se in modalità frequenza
      if (!isErrRelMode && !isErrAssMode && item.err > 0) {
        const errH = (item.err / maxFreq) * maxBarH;
        const errY = chartBaseline - errH;
        svg += `<rect x="${x}" y="${errY}" width="${barWidth}" height="${errH}" rx="3" fill="#ef4444" opacity="0.9" />`;
      }

      // Etichetta carattere sotto la barra
      svg += `<text x="${x + barWidth / 2}" y="${chartBaseline + 17}" font-size="12.5" font-weight="700" text-anchor="middle" fill="var(--text-main)">${htmlEscape(item.char === ' ' ? '␣' : item.char)}</text>`;
      
      // Valore numerico sopra la barra
      const labelY = Math.max(isPerDito ? 31 : 13, y - 4);
      svg += `<text x="${x + barWidth / 2}" y="${labelY}" font-size="9.5" font-weight="600" text-anchor="middle" fill="var(--text-muted)">${displayVal}</text>`;
      svg += `</g>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    container.querySelectorAll(".hist-bar").forEach(bar => {
      bar.addEventListener("mouseenter", () => {
        const c = bar.getAttribute("data-char");
        const f = bar.getAttribute("data-freq");
        const er = bar.getAttribute("data-err");
        const rt = bar.getAttribute("data-rate");
        const d = bar.getAttribute("data-finger");
        const dStr = d ? ` | Dito: ${d}` : '';
        document.getElementById("histTooltipText").innerText = `Tasto: "${c}" | Frequenza: ${f} | Errori: ${er} (${rt}%)${dStr}`;
      });
    });
  }

  getSampleVal(s) {
    if (this.speedMetric === "bpm") return s.BattuteMinuto || 0;
    if (this.speedMetric === "chars") return s.NumCaratteri || 0;
    if (this.speedMetric === "errRel") return s.NumCaratteri > 0 ? (s.NumErrori / s.NumCaratteri) * 100 : 0;
    if (this.speedMetric === "errAss") return s.NumErrori || 0;
    return s.BattuteMinuto || 0;
  }

  clearSelection() {
    this.selectedSampleIndices.clear();
    this.selectionState = 0;
    const selRect = document.getElementById("chartSelectionRect");
    if (selRect) selRect.style.display = "none";
    document.querySelectorAll(".speed-point").forEach(dot => {
      dot.classList.remove("selected");
      dot.setAttribute("fill", "#3b82f6");
      dot.setAttribute("r", "4");
    });

    const btnClearSel = document.getElementById("btnClearSelection");
    const btnClearNotSel = document.getElementById("btnClearNotSelected");
    if (btnClearSel) btnClearSel.style.visibility = "hidden";
    if (btnClearNotSel) btnClearNotSel.style.visibility = "hidden";

    // Restore global average
    if (this.currentFilteredSamples.length > 0) {
      const vals = this.currentFilteredSamples.map(s => this.getSampleVal(s));
      const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
      document.getElementById("lblMediaValori").innerHTML = `${avg} (globale su ${this.currentFilteredSamples.length} campioni)`;
    }
  }

  renderSpeedChart() {
    const container = document.getElementById("statsSpeedSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Campioni || p.Campioni.length === 0) {
      container.innerHTML = '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione di velocità registrato</div>';
      this.clearSelection();
      return;
    }

    const filtered = p.Campioni.filter(s => this.filterTypes.includes(s.TipoCampione));
    this.currentFilteredSamples = filtered;
    if (filtered.length === 0) {
      container.innerHTML = '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione corrisponde ai filtri selezionati</div>';
      this.clearSelection();
      return;
    }

    // Responsive dimensions: exploit entire window area available
    const W = Math.max(760, container.clientWidth || 760);
    const H = Math.max(260, (container.clientHeight - 35) || 260);
    const padL = 48;
    const padR = 25;
    const padT = 20;
    const padB = 35;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;

    const values = filtered.map(s => this.getSampleVal(s));
    const maxVal = Math.max(10, Math.ceil(Math.max(...values) * 1.15));

    // Points calculation
    const pts = filtered.map((s, idx) => {
      const x = padL + (idx / Math.max(1, filtered.length - 1)) * plotW;
      const y = padT + plotH - (this.getSampleVal(s) / maxVal) * plotH;
      return { x, y, sample: s, val: this.getSampleVal(s), idx };
    });

    let pathD = "";
    pts.forEach((pt, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${pt.x},${pt.y} `;
    });

    let svg = `<svg id="speedSvgPlot" viewBox="0 0 ${W} ${H}" style="width:100%;height:100%;cursor:crosshair;user-select:none;">`;
    
    // Grid lines & Y Axis labels
    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="10" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    // Line Path
    svg += `<path d="${pathD}" fill="none" stroke="#3b82f6" stroke-width="2.5" />`;

    // Selection overlay rectangle
    svg += `<rect id="chartSelectionRect" x="0" y="${padT}" width="0" height="${plotH}" fill="rgba(59, 130, 246, 0.22)" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4 3" style="display:none;pointer-events:none;" />`;

    // Crosshair H line & Y value indicator badge
    svg += `<line id="chartCrosshairH" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2" style="display:none;pointer-events:none;" />`;
    svg += `<text id="chartCrosshairYLabel" fill="#ef4444" font-size="11" font-weight="800" text-anchor="end" style="display:none;pointer-events:none;"></text>`;

    // Pre-selection Vertical Guide Line
    svg += `<line id="chartPreviewVLine" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3" style="display:none;pointer-events:none;" />`;

    // Dots
    pts.forEach(pt => {
      const isSel = this.selectedSampleIndices.has(pt.sample.Index);
      const dotCls = isSel ? "speed-point selected" : "speed-point";
      svg += `<circle class="${dotCls}" cx="${pt.x}" cy="${pt.y}" r="${isSel ? 6 : 4}" fill="${isSel ? '#f59e0b' : '#3b82f6'}" stroke="#ffffff" stroke-width="1.5" data-idx="${pt.sample.Index}" data-val="${Math.round(pt.val)}" data-err="${pt.sample.NumErrori}" data-len="${pt.sample.NumCaratteri}" data-title="${htmlEscape(pt.sample.Esercizio || '')}" />`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    const svgEl = document.getElementById("speedSvgPlot");
    if (!svgEl) return;

    // Hover inspector with % Errori format NN.N%
    svgEl.querySelectorAll(".speed-point").forEach(dot => {
      dot.addEventListener("mouseenter", () => {
        const idx = dot.getAttribute("data-idx");
        const val = dot.getAttribute("data-val");
        const err = parseInt(dot.getAttribute("data-err") || "0", 10);
        const len = parseInt(dot.getAttribute("data-len") || "0", 10);
        const title = dot.getAttribute("data-title");
        const errPct = len > 0 ? ((err / len) * 100).toFixed(1) + "%" : "0.0%";
        document.getElementById("speedInspectText").innerText = `Campione #${idx} | Valore: ${val} | Errori: ${err} (${errPct}) | Caratteri: ${len} | Esercizio: "${title}"`;
      });
    });

    // SELEZIONE AD AREA A 3 FASI (v.2.0)
    // Fase 0 (Nessun click): linea verticale segue cursore
    // Fase 1 (1° click): inizio selezione
    // Fase 2 (2° click): fine selezione e ricalcolo metriche sul subset
    // Fase 3 (3° click): annullamento selezione e ripristino metriche su tutti i campioni
    this.selectionState = 0;
    let startSvgX = 0;

    const getSvgCoords = (e) => {
      const pt = svgEl.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      return pt.matrixTransform(svgEl.getScreenCTM().inverse());
    };

    const applySelection = (selPts) => {
      this.selectedSampleIndices = new Set(selPts.map(p => p.sample.Index));
      svgEl.querySelectorAll(".speed-point").forEach(dot => {
        const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
        if (this.selectedSampleIndices.has(sIdx)) {
          dot.classList.add("selected");
          dot.setAttribute("fill", "#f59e0b");
          dot.setAttribute("r", "6");
        } else {
          dot.classList.remove("selected");
          dot.setAttribute("fill", "#3b82f6");
          dot.setAttribute("r", "4");
        }
      });

      if (selPts.length > 0) {
        const selVals = selPts.map(p => p.val);
        const avg = Math.round(selVals.reduce((a, b) => a + b, 0) / selVals.length);
        const countTxt = selPts.length === 1 ? "1 campione selezionato" : `${selPts.length} campioni selezionati`;
        document.getElementById("lblMediaValori").innerHTML = `<span style="color:#f59e0b;font-weight:800;">${avg}</span> (su ${countTxt})`;

        const btnClearSel = document.getElementById("btnClearSelection");
        const btnClearNotSel = document.getElementById("btnClearNotSelected");
        const countNot = filtered.length - selPts.length;

        if (btnClearSel) {
          btnClearSel.style.visibility = "visible";
          document.getElementById("lblSelectedCount").innerText = selPts.length;
        }
        if (btnClearNotSel) {
          btnClearNotSel.style.visibility = countNot > 0 ? "visible" : "hidden";
          document.getElementById("lblNotSelectedCount").innerText = countNot;
        }
      } else {
        this.clearSelection();
      }
    };

    svgEl.addEventListener("mousemove", (e) => {
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const curY = Math.max(padT, Math.min(padT + plotH, svgPt.y));

      // 1. Crosshair Orizzontale ROSSO con valore esatto in ordinata
      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH && crossY) {
        const yVal = Math.round(maxVal - ((curY - padT) / plotH) * maxVal);
        crossH.setAttribute("x1", padL);
        crossH.setAttribute("y1", curY);
        crossH.setAttribute("x2", W - padR);
        crossH.setAttribute("y2", curY);
        crossH.style.display = "block";

        crossY.setAttribute("x", padL - 8);
        crossY.setAttribute("y", curY + 4);
        crossY.textContent = yVal;
        crossY.style.display = "block";
      }

      // 2. Linea Verticale di Pre-selezione o Rettangolo di Selezione
      const vLine = document.getElementById("chartPreviewVLine");
      const selRect = document.getElementById("chartSelectionRect");

      if (this.selectionState === 0) {
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      } else if (this.selectionState === 1) {
        if (vLine) vLine.style.display = "none";
        const minX = Math.max(padL, Math.min(startSvgX, curX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, curX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(2, selW));
          selRect.style.display = "block";
        }

        // Anteprima interattiva punti selezionati
        let previewPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          previewPts = [closest];
        } else {
          previewPts = pts.filter(p => p.x >= minX && p.x <= maxX);
        }

        svgEl.querySelectorAll(".speed-point").forEach(dot => {
          const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
          if (previewPts.some(p => p.sample.Index === sIdx)) {
            dot.setAttribute("fill", "#f59e0b");
            dot.setAttribute("r", "6");
          } else {
            dot.setAttribute("fill", "#3b82f6");
            dot.setAttribute("r", "4");
          }
        });
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      const vLine = document.getElementById("chartPreviewVLine");
      if (vLine && this.selectionState === 0) vLine.style.display = "none";
    });

    svgEl.addEventListener("click", (e) => {
      if (e.button !== 0) return;
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const selRect = document.getElementById("chartSelectionRect");
      const vLine = document.getElementById("chartPreviewVLine");

      if (this.selectionState === 0) {
        // PRIMO CLICK: Inizio selezione
        this.selectionState = 1;
        startSvgX = curX;
        if (vLine) vLine.style.display = "none";
        if (selRect) {
          selRect.setAttribute("x", startSvgX);
          selRect.setAttribute("width", 2);
          selRect.style.display = "block";
        }
        document.getElementById("lblMediaValori").innerHTML = `<span style="color:#3b82f6;font-style:italic;">Seleziona il secondo punto...</span>`;
      } else if (this.selectionState === 1) {
        // SECONDO CLICK: Fine selezione > Calcolo metriche
        this.selectionState = 2;
        const endSvgX = curX;
        const minX = Math.max(padL, Math.min(startSvgX, endSvgX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, endSvgX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(4, selW));
          selRect.style.display = "block";
        }

        let selPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          selPts = [closest];
          if (selRect) {
            selRect.setAttribute("x", closest.x - 8);
            selRect.setAttribute("width", 16);
          }
        } else {
          selPts = pts.filter(p => p.x >= minX && p.x <= maxX);
        }

        applySelection(selPts);
      } else if (this.selectionState === 2) {
        // TERZO CLICK: Annullamento selezione > Calcolo su tutti i campioni
        this.selectionState = 0;
        this.clearSelection();
        if (selRect) selRect.style.display = "none";
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      }
    });

    // Initial label calculation
    if (this.selectedSampleIndices.size === 0) {
      const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
      document.getElementById("lblMediaValori").innerText = `${avg} (globale su ${values.length} campioni)`;
    }
  }
}

class AppController {
  constructor(lessons, albertoProfile, customDefault, fonemiCorpus) {
    this.standardLessons = lessons || [];
    this.customLessons = [];
    this.activeLessonsSource = "standard"; // "standard" or "custom"
    this.lessons = this.standardLessons;
    this.profileMgr = new ProfileManager(albertoProfile, customDefault);
    this.audio = new AudioEngine();
    this.phonemeEng = new PhonemeEngine(fonemiCorpus);
    this.typingEng = new TypingEngine(this.lessons, this.profileMgr, this.audio, this.phonemeEng);
    this.visual = new VisualRenderer();
    this.windowMgr = new WindowManager();
    this.statsMgr = new StatisticsManager(this.profileMgr);
    this.prevStatsRect = null;
    this._wrongBadgeTimer = null;
  }

  start() {
    this.profileMgr.init();
    
    // Inizializza gli esercizi personalizzati dal testo salvato nel profilo
    const savedCustomText = this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    this.customLessons = parseCustomExercises(savedCustomText);

    this.setupTheme();
    this.setupAudio();
    this.setupFloatingWindows();
    this.setupLoginModal();
    this.setupSelectPhraseModal();
    this.setupToolbar();
    this.setupCheckboxes();
    this.setupCustomEditor();
    this.setupStatsUI();
    this.setupTypingListeners();
    this.setupShortcuts();

    // Auto-login non bloccante al profilo attivo (default: ALBERTO)
    const active = this.profileMgr.activeUser || "ALBERTO";
    this.loginUser(active);

    // Focus sull'input di battitura
    setTimeout(() => {
      const inp = document.getElementById("txtTypedInput");
      if (inp) inp.focus();
    }, 150);

    // Punto 1 v.2.10: Mantiene la finestra Mani ancorata all'applicazione durante resize e zoom
    window.addEventListener("resize", () => {
      this.updateHandsWindowPosition();
      this.syncLayoutArrangement();
    });
  }

  setupTheme() {
    const sel = document.getElementById("themeSelect");
    if (!sel) return;
    sel.addEventListener("change", (e) => {
      const theme = e.target.value;
      document.body.classList.remove("theme-dark", "theme-light", "theme-retro", "theme-matrix");
      document.body.classList.add(theme);
      if (this.profileMgr.profile) {
        this.profileMgr.profile.Theme = theme;
        this.profileMgr.saveProfile();
      }
    });
  }

  setupAudio() {
    const modeSel = document.getElementById("audioModeSelect");
    const volSlider = document.getElementById("audioVolumeSlider");
    if (modeSel) {
      modeSel.addEventListener("change", (e) => {
        this.audio.setMode(e.target.value);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioMode = e.target.value;
          this.profileMgr.saveProfile();
        }
      });
    }
    if (volSlider) {
      volSlider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value) / 100;
        this.audio.setVolume(val);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioVolume = val;
          this.profileMgr.saveProfile();
        }
      });
    }
  }

  getAppOrigin() {
    const main = document.querySelector("main");
    if (main) {
      const rect = main.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY
      };
    }
    return { left: 0, top: 0 };
  }

  updateHandsWindowPosition() {
    const handsWin = document.getElementById("handsFloatingWindow");
    if (!handsWin || !this.profileMgr?.profile) return;
    const origin = this.getAppOrigin();
    const prof = this.profileMgr.profile;
    let relLeft = (prof.HandsLeft !== undefined) ? prof.HandsLeft : 660;
    let relTop = (prof.HandsTop !== undefined) ? prof.HandsTop : 120;

    // Se un vecchio profilo ha coordinate assolute globali schermo (es. > 1300), converti a relativo app
    if (relLeft > 1300) {
      relLeft = 660;
      prof.HandsLeft = relLeft;
    }

    handsWin.style.left = Math.round(origin.left + relLeft) + "px";
    handsWin.style.top = Math.round(origin.top + relTop) + "px";
  }

  setupFloatingWindows() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const handsHeader = document.getElementById("handsWindowHeader");
    const statsWin = document.getElementById("statsFloatingWindow");
    const statsHeader = document.getElementById("statsWindowHeader");
    const customWin = document.getElementById("customEditorWindow");
    const customHeader = document.getElementById("customEditorHeader");

    if (handsWin && handsHeader) {
      // Punto 1 v.2.10: Posizione ancorata all'angolo superiore sinistro dell'applicazione (non della finestra del browser)
      this.windowMgr.makeDraggable(handsWin, handsHeader, (x, y) => {
        if (this.profileMgr.profile) {
          const origin = this.getAppOrigin();
          const relX = Math.round(x - origin.left);
          const relY = Math.round(y - origin.top);
          this.profileMgr.profile.HandsLeft = relX;
          this.profileMgr.profile.HandsTop = relY;
          this.profileMgr.saveProfile();
        }
      });

      // Punto 4 & Punto 1 v.2.10: Finestra Mani Resizable con coordinate relative all'app
      this.windowMgr.makeResizable(handsWin, (w, h, x, y) => {
        if (this.profileMgr.profile) {
          const origin = this.getAppOrigin();
          const relX = Math.round(x - origin.left);
          const relY = Math.round(y - origin.top);
          this.profileMgr.profile.HandsWidth = Math.round(w);
          this.profileMgr.profile.HandsHeight = Math.round(h);
          this.profileMgr.profile.HandsLeft = relX;
          this.profileMgr.profile.HandsTop = relY;
          this.profileMgr.saveProfile();
        }
        this.visual.adjustHandsViewport(w, h);
      }, 340, 200);
    }

    const btnHandsDef = document.getElementById("btnHandsDefaultPos");
    if (btnHandsDef) {
      btnHandsDef.addEventListener("click", () => this.resetHandsDefaultPosition());
    }

    if (statsWin && statsHeader) {
      this.windowMgr.makeDraggable(statsWin, statsHeader, (x, y) => {
        if (this.profileMgr.profile) {
          this.profileMgr.profile.StatLeft = x;
          this.profileMgr.profile.StatTop = y;
          this.profileMgr.saveProfile();
        }
      });

      // Ridimensionamento su tutti gli 8 bordi e angoli
      this.windowMgr.makeResizable(statsWin, (w, h, x, y) => {
        if (this.profileMgr.profile) {
          this.profileMgr.profile.StatWidth = w;
          this.profileMgr.profile.StatHeight = h;
          this.profileMgr.profile.StatLeft = x;
          this.profileMgr.profile.StatTop = y;
          this.profileMgr.saveProfile();
        }
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      }, 540, 380);
    }

    if (customWin && customHeader) {
      this.windowMgr.makeDraggable(customWin, customHeader, null);
    }

    // Controlli Finestra Statistiche: Massimizza / Schermo Intero
    const btnMax = document.getElementById("btnStatsMaximize");
    if (btnMax && statsWin) {
      btnMax.addEventListener("click", () => {
        if (!statsWin.classList.contains("window-fullscreen")) {
          this.prevStatsRect = {
            left: statsWin.style.left || "180px",
            top: statsWin.style.top || "80px",
            width: statsWin.style.width || "840px",
            height: statsWin.style.height || "620px"
          };
          statsWin.classList.add("window-fullscreen");
          btnMax.innerText = "🗗 Riduci";
          btnMax.title = "Ripristina dimensioni precedenti";
        } else {
          statsWin.classList.remove("window-fullscreen");
          if (this.prevStatsRect) {
            statsWin.style.left = this.prevStatsRect.left;
            statsWin.style.top = this.prevStatsRect.top;
            statsWin.style.width = this.prevStatsRect.width;
            statsWin.style.height = this.prevStatsRect.height;
          }
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero";
          if (this.profileMgr.profile) {
            this.profileMgr.profile.StatLeft = parseInt(statsWin.style.left, 10);
            this.profileMgr.profile.StatTop = parseInt(statsWin.style.top, 10);
            this.profileMgr.profile.StatWidth = parseInt(statsWin.style.width, 10);
            this.profileMgr.profile.StatHeight = parseInt(statsWin.style.height, 10);
            this.profileMgr.saveProfile();
          }
        }
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      });
    }

    // Responsive ResizeObserver per ridisegno dinamico a tutto schermo dei grafici
    if (window.ResizeObserver) {
      let resizeTimer = null;
      const ro = new ResizeObserver(() => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          const statsWin = document.getElementById("statsFloatingWindow");
          if (statsWin && statsWin.classList.contains("window-visible")) {
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
          }
        }, 80);
      });
      const speedBox = document.getElementById("statsSpeedSvgBox");
      const histBox = document.getElementById("statsHistogramSvgBox");
      if (speedBox) ro.observe(speedBox);
      if (histBox) ro.observe(histBox);
    }

    // Controlli Finestra Statistiche: Ripristina Layout Predefinito
    const btnResetLayout = document.getElementById("btnStatsResetLayout");
    if (btnResetLayout && statsWin) {
      btnResetLayout.addEventListener("click", () => {
        statsWin.classList.remove("window-fullscreen");
        statsWin.style.left = "180px";
        statsWin.style.top = "80px";
        statsWin.style.width = "840px";
        statsWin.style.height = "620px";
        statsWin.style.maxWidth = "95vw";
        if (btnMax) {
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero";
        }
        if (this.profileMgr.profile) {
          this.profileMgr.profile.StatLeft = 180;
          this.profileMgr.profile.StatTop = 80;
          this.profileMgr.profile.StatWidth = 840;
          this.profileMgr.profile.StatHeight = 620;
          this.profileMgr.saveProfile();
        }
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      });
    }

    // Responsive ResizeObserver per ridisegno dinamico a tutto schermo dei grafici
    if (window.ResizeObserver) {
      let resizeTimer = null;
      const ro = new ResizeObserver(() => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          const statsWin = document.getElementById("statsFloatingWindow");
          if (statsWin && statsWin.classList.contains("window-visible")) {
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
          }
        }, 80);
      });
      const speedBox = document.getElementById("statsSpeedSvgBox");
      const histBox = document.getElementById("statsHistogramSvgBox");
      if (speedBox) ro.observe(speedBox);
      if (histBox) ro.observe(histBox);
    }

    // Eventi di chiusura finestre fluttuanti (pulsanti "x")
    document.getElementById("btnHandsClose")?.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      this.toggleHandsVis(false);
    });

    document.getElementById("btnStatsClose")?.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      this.toggleStatsWindow(false);
    });

    document.getElementById("btnCustomClose")?.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      if (customWin) {
        customWin.classList.remove("window-visible");
        customWin.style.display = "none";
      }
    });
  }

  resetHandsDefaultPosition() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const kbCont = document.querySelector(".keyboard-container");
    const kbSvg = document.getElementById("keyboardSvg");
    if (!handsWin) return;

    const origin = this.getAppOrigin();
    let relLeft = 660;
    let relTop = 120;

    if (kbSvg && kbCont) {
      const kbRect = kbSvg.getBoundingClientRect();
      const mainRect = document.querySelector("main")?.getBoundingClientRect();
      if (mainRect) {
        relLeft = Math.round(kbRect.right - mainRect.left + 16);
        relTop = Math.max(10, Math.round(kbRect.top - mainRect.top));
      }
    }

    handsWin.style.left = `${Math.round(origin.left + relLeft)}px`;
    handsWin.style.top = `${Math.round(origin.top + relTop)}px`;
    handsWin.style.width = "580px";
    handsWin.style.height = "330px";

    if (this.profileMgr?.profile) {
      this.profileMgr.profile.HandsLeft = relLeft;
      this.profileMgr.profile.HandsTop = relTop;
      this.profileMgr.profile.HandsWidth = 580;
      this.profileMgr.profile.HandsHeight = 330;
      this.profileMgr.saveProfile();
    }
    this.visual.adjustHandsViewport(580, 330);
  }

  syncLayoutArrangement() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const kbCont = document.querySelector(".keyboard-container");
    const handsVisible = handsWin && handsWin.classList.contains("window-visible");
    const chkKb = document.getElementById("chkShowKeyBoard");
    const kbVisible = chkKb ? chkKb.checked : true;

    // Punto 8: Se Mani e Tastiera sono visibili insieme, sposta la tastiera a sinistra
    if (kbCont) {
      if (handsVisible && kbVisible) {
        kbCont.classList.add("align-left");
      } else {
        kbCont.classList.remove("align-left");
      }
    }
  }

  toggleHandsVis(show) {
    const hw = document.getElementById("handsFloatingWindow");
    if (hw) {
      if (show) {
        hw.classList.add("window-visible");
        hw.style.display = "flex";
        this.updateHandsWindowPosition();
      } else {
        hw.classList.remove("window-visible");
        hw.style.display = "none";
      }
    }
    const chk = document.getElementById("chkShowHands");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr && this.profileMgr.profile) {
      this.profileMgr.profile.ShowHands = !!show;
      this.profileMgr.saveProfile();
    }
    this.syncLayoutArrangement();
  }

  toggleKeyboardVis(show) {
    const kb = document.getElementById("keyboardCardContainer");
    if (kb) kb.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowKeyBoard");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowKeyBoard = !!show;
      this.profileMgr.saveProfile();
    }
    this.syncLayoutArrangement();
  }

  toggleOriginVis(show) {
    const orig = document.getElementById("originTextWrapper");
    if (orig) orig.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowOrigin");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowOrigin = !!show;
      this.profileMgr.saveProfile();
    }
  }

  toggleTypedVis(show) {
    const inp = document.getElementById("txtTypedInput");
    if (inp) inp.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowTyped");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowTyped = !!show;
      this.profileMgr.saveProfile();
    }
  }

  toggleStatsWindow(forceState) {
    const win = document.getElementById("statsFloatingWindow");
    if (!win) return;
    const shouldShow = (typeof forceState === "boolean") ? forceState : !win.classList.contains("window-visible");
    if (shouldShow) {
      win.classList.add("window-visible");
      win.style.display = "flex";
      this.statsMgr.renderHistogram();
      this.statsMgr.renderSpeedChart();
    } else {
      win.classList.remove("window-visible");
      win.style.display = "none";
    }
    const btn = document.getElementById("btnOpenStats");
    if (btn) btn.classList.toggle("active", shouldShow);
  }

  showLoginModal() {
    const modal = document.getElementById("loginModal");
    const select = document.getElementById("loginUserSelect");
    const input = document.getElementById("loginNewUserInput");
    if (!modal || !select || !input) return;

    const users = this.profileMgr.getUsers();
    select.innerHTML = '<option value="">-- Seleziona Utente Esistente --</option>';
    users.forEach(u => {
      select.innerHTML += `<option value="${htmlEscape(u)}">${htmlEscape(u)}</option>`;
    });

    if (this.profileMgr.activeUser) {
      select.value = this.profileMgr.activeUser;
    }
    input.value = "";
    modal.classList.add("active");
  }

  showSelectPhraseModal() {
    const modal = document.getElementById("selectPhraseModal");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const numInput = document.getElementById("txtSelectPhraseNum");
    const rangeLabel = document.getElementById("lblSelectPhraseRange");
    if (!modal || !lessonSelect || !numInput) return;

    const lessons = this.typingEng.lessons || [];
    if (lessons.length === 0) return;

    // Popola il menu delle lezioni
    lessonSelect.innerHTML = "";
    lessons.forEach((les, idx) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      opt.textContent = `${idx + 1}. ${les.name || les.title || ('Lezione ' + (idx + 1))}`;
      lessonSelect.appendChild(opt);
    });

    // Seleziona di default la lezione corrente
    const currentLessonIdx = this.typingEng.currentLessonIdx || 0;
    lessonSelect.value = String(currentLessonIdx);

    const updateRange = () => {
      const lesIdx = parseInt(lessonSelect.value, 10);
      const chosenLesson = lessons[lesIdx] || lessons[0];
      const phrases = chosenLesson?.phrases || [];
      const totalPhrases = Math.max(1, phrases.length);

      if (rangeLabel) {
        rangeLabel.innerText = `Numero Frase consentito (da 1 a ${totalPhrases}):`;
      }
      numInput.min = "1";
      numInput.max = String(totalPhrases);

      if (lesIdx === currentLessonIdx) {
        numInput.value = String((this.typingEng.currentPhraseIdx || 0) + 1);
      } else {
        numInput.value = "1";
      }
    };

    lessonSelect.onchange = updateRange;
    updateRange();

    modal.classList.add("active");
    setTimeout(() => {
      numInput.focus();
      numInput.select();
    }, 50);
  }

  confirmSelectPhrase() {
    const modal = document.getElementById("selectPhraseModal");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const numInput = document.getElementById("txtSelectPhraseNum");
    if (!modal || !numInput) return;

    const lessons = this.typingEng.lessons || [];
    const lesIdx = lessonSelect ? parseInt(lessonSelect.value, 10) : this.typingEng.currentLessonIdx;
    const chosenLesson = lessons[lesIdx] || lessons[0];
    const phrases = chosenLesson?.phrases || [];
    const totalPhrases = phrases.length;
    const val = parseInt(numInput.value, 10);

    if (!isNaN(val) && val >= 1 && val <= totalPhrases) {
      this.typingEng.currentLessonIdx = lesIdx;
      this.typingEng.currentPhraseIdx = val - 1;

      // Aggiorna anche il selettore delle lezioni nella toolbar principale
      const toolbarLesson = document.getElementById("cboLessons") || document.getElementById("selLesson");
      if (toolbarLesson) {
        toolbarLesson.value = String(lesIdx);
      }

      this.startExercise();
      modal.classList.remove("active");
      setTimeout(() => {
        const inp = document.getElementById("txtTypedInput");
        if (inp) inp.focus();
      }, 50);
    } else {
      numInput.classList.add("error-active");
      setTimeout(() => numInput.classList.remove("error-active"), 300);
    }
  }

  setupSelectPhraseModal() {
    const modal = document.getElementById("selectPhraseModal");
    const numInput = document.getElementById("txtSelectPhraseNum");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const btnConfirm = document.getElementById("btnConfirmSelectPhrase");
    const btnCancel = document.getElementById("btnCancelSelectPhrase");
    const btnClose = document.getElementById("btnCloseSelectPhraseModal");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      setTimeout(() => {
        const inp = document.getElementById("txtTypedInput");
        if (inp) inp.focus();
      }, 50);
    };

    btnConfirm?.addEventListener("click", () => this.confirmSelectPhrase());
    btnCancel?.addEventListener("click", closeModal);
    btnClose?.addEventListener("click", closeModal);

    numInput?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        this.confirmSelectPhrase();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    lessonSelect?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        this.confirmSelectPhrase();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    modal?.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });
    document.getElementById("btnSelectPhraseModal")?.addEventListener("click", () => this.showSelectPhraseModal());
    document.getElementById("lblPhraseRange")?.addEventListener("click", () => this.showSelectPhraseModal());
  }

  setupLoginModal() {
    const modal = document.getElementById("loginModal");
    const select = document.getElementById("loginUserSelect");
    const input = document.getElementById("loginNewUserInput");
    const btnEnter = document.getElementById("btnLoginEnter");
    const btnDelete = document.getElementById("btnLoginDelete");
    const btnResetArchive = document.getElementById("btnResetDefaultArchive");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      setTimeout(() => {
        const inp = document.getElementById("txtTypedInput");
        if (inp) inp.focus();
      }, 50);
    };

    const doEnter = () => {
      let chosen = input.value.trim() || select.value || "ALBERTO";
      if (!chosen) {
        alert("Selezionare un utente o inserire un nuovo nome.");
        return;
      }
      this.loginUser(chosen);
      closeModal();
    };

    btnEnter?.addEventListener("click", doEnter);
    modal?.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });

    input?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); doEnter(); }
      else if (e.key === "Escape") { e.preventDefault(); closeModal(); }
    });

    select?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); doEnter(); }
      else if (e.key === "Escape") { e.preventDefault(); closeModal(); }
    });

    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal?.classList.contains("active")) closeModal();
    });

    btnDelete?.addEventListener("click", () => {
      const chosen = select.value;
      if (!chosen) { alert("Selezionare un utente da eliminare."); return; }
      if (confirm(`Eliminare definitivamente tutti i dati dell'utente "${chosen}"?`)) {
        this.profileMgr.deleteUser(chosen);
        this.showLoginModal();
      }
    });

    btnResetArchive?.addEventListener("click", () => {
      if (confirm("Ripristinare l'archivio demo originale di Alberto?")) {
        this.profileMgr.resetToDefaultArchive();
        this.showLoginModal();
      }
    });

    document.getElementById("btnHeaderSwitchUser")?.addEventListener("click", () => {
      this.showLoginModal();
    });
  }

  // GESTIONE SORGENTE LEZIONI: STANDARD VS CUSTOM
  setLessonsSource(source) {
    this.activeLessonsSource = source;
    const isCustom = (source === "custom" && this.customLessons && this.customLessons.length > 0);
    this.lessons = isCustom ? this.customLessons : this.standardLessons;
    this.typingEng.lessons = this.lessons;
    this.typingEng.currentLessonIdx = 0;
    this.typingEng.currentPhraseIdx = 0;

    const lbl = document.getElementById("lblLessonSource");
    if (lbl) lbl.innerText = isCustom ? "Custom" : "Standard";

    const cboLessons = document.getElementById("cboLessons");
    if (cboLessons) {
      cboLessons.innerHTML = "";
      this.lessons.forEach((l, idx) => {
        const prefix = isCustom ? "Custom " : "Lezione ";
        cboLessons.innerHTML += `<option value="${idx}">${prefix}${idx + 1}: ${htmlEscape(l.name)}</option>`;
      });
      cboLessons.value = "0";
    }

    this.startExercise();
  }

  loginUser(userId) {
    const prof = this.profileMgr.loadUser(userId);
    const badge = document.getElementById("loggedUserBadge");
    if (badge) badge.innerText = `Utente: ${userId}`;

    // Applica tema utente
    const theme = prof.Theme || "theme-dark";
    document.body.classList.remove("theme-dark", "theme-light", "theme-retro", "theme-matrix");
    document.body.classList.add(theme);
    const themeSel = document.getElementById("themeSelect");
    if (themeSel) themeSel.value = theme;

    // Applica audio utente
    const audioMode = prof.AudioMode || "typewriter";
    this.audio.setMode(audioMode);
    const audioSel = document.getElementById("audioModeSelect");
    if (audioSel) audioSel.value = audioMode;

    const audioVol = (prof.AudioVolume !== undefined) ? prof.AudioVolume : 0.7;
    this.audio.setVolume(audioVol);
    const volSlider = document.getElementById("audioVolumeSlider");
    if (volSlider) volSlider.value = String(Math.round(audioVol * 100));

    // Posizioni e Dimensioni finestre memorizzate
    this.toggleHandsVis(prof.ShowHands !== false);
    const handsWin = document.getElementById("handsFloatingWindow");
    if (handsWin) {
      this.updateHandsWindowPosition();
      if (prof.HandsWidth && prof.HandsHeight) {
        handsWin.style.width = prof.HandsWidth + "px";
        handsWin.style.height = prof.HandsHeight + "px";
        this.visual.adjustHandsViewport(prof.HandsWidth, prof.HandsHeight);
      } else {
        handsWin.style.width = "580px";
        handsWin.style.height = "330px";
        this.visual.adjustHandsViewport(580, 330);
      }
    }

    const statsWin = document.getElementById("statsFloatingWindow");
    if (statsWin) {
      if (prof.StatLeft && prof.StatTop) {
        statsWin.style.left = prof.StatLeft + "px";
        statsWin.style.top = prof.StatTop + "px";
      }
      if (prof.StatWidth && prof.StatHeight) {
        statsWin.style.width = prof.StatWidth + "px";
        statsWin.style.height = prof.StatHeight + "px";
        statsWin.style.maxWidth = "none";
      }
    }

    // Checkboxes visibilità
    this.toggleKeyboardVis(prof.ShowKeyBoard !== false);
    this.toggleOriginVis(prof.ShowOrigin !== false);
    this.toggleTypedVis(prof.ShowTyped !== false);
    const chkAuto = document.getElementById("chkAutomaticCorrection");
    if (chkAuto) chkAuto.checked = !!prof.AutomaticCorrection;

    // Modalità e Lezione
    this.typingEng.mode = prof.Mode || 0;
    const cboMode = document.getElementById("cboMode");
    if (cboMode) cboMode.value = String(this.typingEng.mode);

    this.setLessonsSource("standard");
    this.typingEng.currentLessonIdx = Math.max(0, Math.min(prof.Lesson || 0, this.lessons.length - 1));
    this.typingEng.currentPhraseIdx = prof.Exercise || 0;
    const cboLessons = document.getElementById("cboLessons");
    if (cboLessons) cboLessons.value = String(this.typingEng.currentLessonIdx);

    this.updateModeUI();
    this.startExercise();
  }

  setupToolbar() {
    const cboLessons = document.getElementById("cboLessons");
    const cboMode = document.getElementById("cboMode");
    const btnToggleSource = document.getElementById("btnToggleLessonSource");

    if (cboLessons) {
      cboLessons.addEventListener("change", (e) => {
        this.typingEng.currentLessonIdx = parseInt(e.target.value, 10);
        this.typingEng.currentPhraseIdx = 0;
        if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
          this.profileMgr.profile.Lesson = this.typingEng.currentLessonIdx;
          this.profileMgr.profile.Exercise = 0;
          this.profileMgr.saveProfile();
        }
        this.startExercise();
      });
    }

    if (btnToggleSource) {
      btnToggleSource.addEventListener("click", () => {
        if (this.activeLessonsSource === "standard") {
          if (!this.customLessons || this.customLessons.length === 0) {
            const txt = this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
            this.customLessons = parseCustomExercises(txt);
          }
          if (this.customLessons.length > 0) {
            this.setLessonsSource("custom");
          } else {
            alert("Nessun esercizio custom trovato. Apri l'Editor Custom per inserire o caricare un file.");
          }
        } else {
          this.setLessonsSource("standard");
        }
      });
    }

    if (cboMode) {
      cboMode.addEventListener("change", (e) => {
        this.typingEng.mode = parseInt(e.target.value, 10);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.Mode = this.typingEng.mode;
          this.profileMgr.saveProfile();
        }
        this.updateModeUI();
        this.startExercise();
      });
    }

    document.getElementById("btnPrevLesson")?.addEventListener("click", () => this.navLesson(-1));
    document.getElementById("btnNextLesson")?.addEventListener("click", () => this.navLesson(1));
    document.getElementById("btnPrevPhrase")?.addEventListener("click", () => this.navPhrase(-1));
    document.getElementById("btnNextPhrase")?.addEventListener("click", () => this.navPhrase(1));
    document.getElementById("btnRestartPhrase")?.addEventListener("click", () => this.startExercise());
    document.getElementById("btnRandomPhrase")?.addEventListener("click", () => this.randomPhrase());
    document.getElementById("btnRandomThisPhrase")?.addEventListener("click", () => {
      this.typingEng.mode = 5;
      if (cboMode) cboMode.value = "5";
      this.updateModeUI();
      this.startExercise();
    });
    document.getElementById("btnRandomAllChars")?.addEventListener("click", () => {
      this.typingEng.mode = 3;
      if (cboMode) cboMode.value = "3";
      this.updateModeUI();
      this.startExercise();
    });

    document.getElementById("btnOpenStats")?.addEventListener("click", () => this.toggleStatsWindow());
    document.getElementById("btnOpenCustomEditor")?.addEventListener("click", () => this.openCustomEditor());

    // Pulsante Aggiungi Statistica in modalità Libera (Typing)
    document.getElementById("btnAddStatistic")?.addEventListener("click", () => {
      if (this.typingEng.mode === 4) {
        this.typingEng.recordManualTypingSample();
        alert("Sessione di digitazione libera registrata con successo!");
        this.typingEng.initSession();
        const inp = document.getElementById("txtTypedInput");
        if (inp) { inp.value = ""; inp.focus(); }
        this.typingEng.updateMetrics();
      }
    });
  }

  setupCheckboxes() {
    document.getElementById("chkShowKeyBoard")?.addEventListener("change", (e) => {
      this.toggleKeyboardVis(e.target.checked);
    });
    document.getElementById("chkShowHands")?.addEventListener("change", (e) => {
      this.toggleHandsVis(e.target.checked);
    });
    document.getElementById("chkShowOrigin")?.addEventListener("change", (e) => {
      this.toggleOriginVis(e.target.checked);
    });
    document.getElementById("chkShowTyped")?.addEventListener("change", (e) => {
      this.toggleTypedVis(e.target.checked);
    });
    document.getElementById("chkAutomaticCorrection")?.addEventListener("change", (e) => {
      if (this.profileMgr.profile) {
        this.profileMgr.profile.AutomaticCorrection = e.target.checked;
        this.profileMgr.saveProfile();
      }
    });
  }

  updateModeUI() {
    const fixing = document.getElementById("fixingDataPanel");
    const input = document.getElementById("txtTypedInput");
    if (this.typingEng.mode === 4) {
      if (fixing) fixing.style.display = "flex";
      if (input) input.placeholder = "Digitazione libera: scrivi qualsiasi testo qui...";
    } else {
      if (fixing) fixing.style.display = "none";
      if (input) input.placeholder = "Inizia a digitare qui...";
    }
  }

  navLesson(delta) {
    let next = this.typingEng.currentLessonIdx + delta;
    if (next < 0) next = 0;
    if (next >= this.lessons.length) next = this.lessons.length - 1;
    this.typingEng.currentLessonIdx = next;
    this.typingEng.currentPhraseIdx = 0;
    const cbo = document.getElementById("cboLessons");
    if (cbo) cbo.value = String(next);
    if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
      this.profileMgr.profile.Lesson = next;
      this.profileMgr.profile.Exercise = 0;
      this.profileMgr.saveProfile();
    }
    this.startExercise();
  }

  showLessonNavConfirm(aaaa, bbbb, onConfirm) {
    const modal = document.getElementById("lessonNavModal");
    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!modal || !body || !btnYes || !btnNo) return;

    const msg = `E' stato raggiunto ${aaaa} esercizio della lezione corrente.\nSi desidera abbandonarla\ne passare ad un esercizio della lezione ${bbbb}?`;
    body.textContent = msg;
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      document.getElementById("txtTypedInput")?.focus();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  navPhrase(delta) {
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    let next = this.typingEng.currentPhraseIdx + delta;
    if (next < 0 || next >= total) {
      // Punto 1 v.2.9: Messaggio formattato in modale con AAAA e BBBB corretti
      const aaaa = delta < 0 ? "il primo" : "l'ultimo";
      const bbbb = delta < 0 ? "precedente" : "successiva";
      this.showLessonNavConfirm(aaaa, bbbb, () => {
        if (delta < 0) {
          // Passa alla lezione precedente, posizionandosi sull'ultimo esercizio
          let prevLessonIdx = this.typingEng.currentLessonIdx - 1;
          if (prevLessonIdx < 0) prevLessonIdx = 0;
          this.typingEng.currentLessonIdx = prevLessonIdx;
          const prevLesson = this.lessons[prevLessonIdx];
          const prevTotal = (prevLesson?.phrases || []).length;
          this.typingEng.currentPhraseIdx = Math.max(0, prevTotal - 1);
          const cbo = document.getElementById("cboLessons");
          if (cbo) cbo.value = String(prevLessonIdx);
          if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
            this.profileMgr.profile.Lesson = prevLessonIdx;
            this.profileMgr.profile.Exercise = this.typingEng.currentPhraseIdx;
            this.profileMgr.saveProfile();
          }
          this.startExercise();
        } else {
          // Passa alla lezione successiva, posizionandosi sul primo esercizio (0)
          this.navLesson(1);
        }
      });
      return;
    }
    this.typingEng.currentPhraseIdx = next;
    if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
      this.profileMgr.profile.Exercise = next;
      this.profileMgr.saveProfile();
    }
    this.startExercise();
  }

  randomPhrase() {
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    if (total > 1) {
      let r = Math.floor(Math.random() * total);
      if (r === this.typingEng.currentPhraseIdx) r = (r + 1) % total;
      this.typingEng.currentPhraseIdx = r;
      if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
        this.profileMgr.profile.Exercise = r;
        this.profileMgr.saveProfile();
      }
    }
    this.startExercise();
  }

  startExercise() {
    this.typingEng.initSession();
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    const titleEl = document.getElementById("lblExerciseTitle");
    const rangeEl = document.getElementById("lblPhraseRange");
    const prefix = (this.activeLessonsSource === "custom") ? "Custom " : "Lezione ";

    if (this.typingEng.mode === 0) {
      if (titleEl) titleEl.innerText = `${prefix}${this.typingEng.currentLessonIdx + 1}: ${lesson?.name || ""}`;
      if (rangeEl) rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} di ${total}`;
    } else if (this.typingEng.mode === 1) {
      if (titleEl) titleEl.innerText = `Random Caratteri: ${prefix}${this.typingEng.currentLessonIdx + 1}`;
      if (rangeEl) rangeEl.innerText = "50 caratteri casuali";
    } else if (this.typingEng.mode === 2) {
      if (titleEl) titleEl.innerText = "Modalità Fonemi (Sillabico IT)";
      if (rangeEl) rangeEl.innerText = "Testo generato con Markov";
    } else if (this.typingEng.mode === 3) {
      if (titleEl) titleEl.innerText = "Modalità Tutti i Caratteri";
      if (rangeEl) rangeEl.innerText = "50 caratteri QWERTY IT";
    } else if (this.typingEng.mode === 4) {
      if (titleEl) titleEl.innerText = "Modalità Digitazione Libera (Typing)";
      if (rangeEl) rangeEl.innerText = "Digitazione libera senza guida";
    } else if (this.typingEng.mode === 5) {
      if (titleEl) titleEl.innerText = "Modalità Rimescola Frase Corrente";
      if (rangeEl) rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} rimescolata`;
    }

    const input = document.getElementById("txtTypedInput");
    if (input) {
      input.value = "";
      input.classList.remove("error-active");
      input.focus();
    }
    this.updateOriginDisplay();
    this.updateTargetKey();
    this.typingEng.updateMetrics();
  }

  // FORMATTAZIONE VISIVA GUIDA CON SUPPORTO SPECIALE INVIO (↵ / ®) E TAB (⇥ / →)
  formatGuideChar(ch) {
    if (ch === ' ') return '␣';
    if (ch === '®' || ch === '\n') return '↵\n';
    if (ch === '→' || ch === '\t') return '⇥';
    return ch;
  }

  updateOriginDisplay() {
    const container = document.getElementById("originTextWrapper");
    const badge = document.getElementById("charTargetBadge");
    if (!container) return;

    if (this.typingEng.mode === 4) {
      container.innerHTML = '<span style="color:var(--text-muted);font-style:italic;">Digitazione libera in corso...</span>';
      if (badge) {
        badge.innerText = "LIBERA";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
      return;
    }

    const origin = this.typingEng.originText;
    const typed = this.typingEng.typedText;

    let matchLen = 0;
    while (matchLen < typed.length && matchLen < origin.length && typed[matchLen] === origin[matchLen]) {
      matchLen++;
    }

    const partOk = origin.slice(0, matchLen);
    const numErrors = typed.length - matchLen;

    let guideHtml = "";
    if (partOk) {
      const formattedOk = Array.from(partOk).map(c => this.formatGuideChar(c)).join('');
      guideHtml += `<span class="char-typed-ok">${htmlEscape(formattedOk)}</span>`;
    }

    if (numErrors === 0) {
      // Nessun errore: il carattere corrente da digitare ha sfondo BLU
      if (matchLen < origin.length) {
        const targetChar = origin[matchLen];
        const formattedTarget = this.formatGuideChar(targetChar);
        guideHtml += `<span class="char-current-target" id="currentTargetCharSpan">${htmlEscape(formattedTarget)}</span>`;
        const partRest = origin.slice(matchLen + 1);
        if (partRest) {
          const formattedRest = Array.from(partRest).map(c => this.formatGuideChar(c)).join('');
          guideHtml += `<span class="char-remaining">${htmlEscape(formattedRest)}</span>`;
        }
      }
    } else {
      // Presenza di uno o più errori: sfondo ROSSO esteso a tante lettere quanti gli errori introdotti
      // Se numErrors eccede i caratteri rimanenti della frase originale, aggiunge spazi fittizi rossi
      const remainingChars = origin.slice(matchLen);
      let errorSubstring = "";
      let remainingAfterErrors = "";

      if (numErrors <= remainingChars.length) {
        errorSubstring = remainingChars.slice(0, numErrors);
        remainingAfterErrors = remainingChars.slice(numErrors);
      } else {
        const excess = numErrors - remainingChars.length;
        errorSubstring = remainingChars + "␣".repeat(excess);
        remainingAfterErrors = "";
      }

      const formattedErrors = Array.from(errorSubstring).map(c => this.formatGuideChar(c)).join('');
      guideHtml += `<span class="char-error-target" id="currentTargetCharSpan">${htmlEscape(formattedErrors)}</span>`;

      if (remainingAfterErrors) {
        const formattedRest = Array.from(remainingAfterErrors).map(c => this.formatGuideChar(c)).join('');
        guideHtml += `<span class="char-remaining">${htmlEscape(formattedRest)}</span>`;
      }
    }

    container.innerHTML = guideHtml;

    // Aggiorna il badge del prossimo tasto bersaglio
    const targetChar = origin[matchLen] || "";
    if (badge) {
      if (this.typingEng.isCompleted) {
        badge.innerText = "FINITO";
        badge.style.background = "var(--success-bg)";
        badge.style.color = "var(--success-color)";
      } else if (numErrors > 0) {
        badge.innerText = "CORREGGI ⌫";
        badge.style.background = "#ef4444";
        badge.style.color = "#ffffff";
      } else if (targetChar === "®" || targetChar === "\n") {
        badge.innerText = "INVIO ↵";
        badge.style.background = "#059669";
        badge.style.color = "#ffffff";
      } else if (targetChar === "→" || targetChar === "\t") {
        badge.innerText = "TAB ⇥";
        badge.style.background = "#2563eb";
        badge.style.color = "#ffffff";
      } else if (targetChar === " ") {
        badge.innerText = "SPAZIO";
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else if (targetChar) {
        badge.innerText = targetChar;
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else {
        badge.innerText = "—";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
    }
  }

  updateTargetKey() {
    if (this.typingEng.mode === 4) {
      // Punto 9: In modalità Libera (TYPING) NON azzerare i polpastrelli fisici!
      // La visualizzazione è gestita direttamente da setPhysicalKeyDown / setPhysicalKeyUp
      return;
    }
    if (this.typingEng.isCompleted) {
      this.visual.setTargetChar(null);
      this.visual.clearAllPhysicalFingers();
      return;
    }
    const targetChar = this.typingEng.originText[this.typingEng.typedText.length];
    this.visual.setTargetChar(targetChar);
  }

  showWrongLetterPopup(wrongChar) {
    const badge = document.getElementById("wrongCharFloatingBadge");
    if (!badge) return;
    badge.innerText = wrongChar === " " ? "SPAZIO" : wrongChar;

    const targetSpan = document.getElementById("currentTargetCharSpan") || document.querySelector(".char-current-target");
    const container = document.querySelector(".typing-box-container") || document.getElementById("originTextWrapper")?.parentElement;

    if (targetSpan && container) {
      const spanRect = targetSpan.getBoundingClientRect();
      const contRect = container.getBoundingClientRect();
      const centerX = (spanRect.left - contRect.left) + (spanRect.width / 2);
      const topY = (spanRect.top - contRect.top) - 34;
      badge.style.left = `${Math.round(centerX)}px`;
      badge.style.top = `${Math.round(topY)}px`;
      badge.style.transform = "translateX(-50%)";
    }

    badge.classList.add("visible");
    if (this._wrongBadgeTimer) clearTimeout(this._wrongBadgeTimer);
    this._wrongBadgeTimer = setTimeout(() => badge.classList.remove("visible"), 550);
  }

  setupTypingListeners() {
    const input = document.getElementById("txtTypedInput");
    if (!input) return;

    // Disabilita auto-repeat (ammesso solo per Backspace)
    // Tasti premuti evidenziati fino al rilascio (keydown aggiunge, keyup rimuove)
    const handleKeyDown = (e) => {
      if (document.querySelector(".modal-overlay.active")) return;
      if (e.target && e.target !== input && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA" || e.target.tagName === "SELECT")) return;
      // Scorciatoie globali con Ctrl+Shift (non devono intercettare caratteri stampabili come { o })
      const isAppShortcutKey = ["Digit1","Digit2","Digit3","Digit4","Digit5","KeyZ","KeyG","KeyX","KeyA","KeyE","KeyM","KeyS","KeyU","KeyK","KeyO","KeyY","KeyB","KeyH"].includes(e.code) ||
                               ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key);
      const isAltGrActive = (e.key === "AltGraph" || e.code === "AltRight" || (typeof e.getModifierState === "function" && e.getModifierState("AltGraph")));
      if (e.ctrlKey && e.shiftKey && isAppShortcutKey && !isAltGrActive && !e.altKey) return;
      if (e._handledByApp) return;
      e._handledByApp = true;

      // 1. DISABILITAZIONE AUTO-REPEAT (consentito unicamente per Backspace)
      if (e.repeat && e.key !== "Backspace") {
        e.preventDefault();
        return;
      }

      // 2. STATO CAPS LOCK FISICO
      const isCapsOn = (typeof e.getModifierState === "function") && e.getModifierState("CapsLock");
      this.visual.updateCapsLockLed(isCapsOn);

      // Punto 4 & 6: Gestione dedicata del tasto AltGr per eliminare l'attivazione spuria di CTRL sinistro
      // Sopprime il falso ControlLeft SOLO quando il tasto premuto è effettivamente AltRight (AltGr) e non quando l'utente tiene premuto AltLeft
      const isAltGrKey = (e.key === "AltGraph" || e.code === "AltRight");
      if (isAltGrKey && !this.activePhysicalKeys.has("AltLeft") && !this.activePhysicalKeys.has("Alt_AltLeft_1")) {
        this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
        this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
      }
      if (e.key === "Control" && e.code === "ControlLeft") {
        if (typeof e.getModifierState === "function" && e.getModifierState("AltGraph") && !this.activePhysicalKeys.has("ControlLeft") && !this.activePhysicalKeys.has("Control_ControlLeft_1")) {
          return;
        }
      }

      // 3. EVIDENZIAZIONE FISICA DEL TASTO PREMUTO
      this.visual.setKeyPressed(e.key, e.code, e.location, true);

      // In modalità libera (TYPING) o ad esercizio completato, i tasti dell'accordo persistono sui polpastrelli fino al rilascio fisico
      if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
        this.visual.setPhysicalKeyDown(e.key, e.code, e.location);
      }

      const targetChar = (this.typingEng.mode === 4 || this.typingEng.isCompleted)
        ? null
        : this.typingEng.originText[this.typingEng.typedText.length];

      // 4. GESTIONE DEI TASTI MODIFICATORI PREMUTI DA SOLI (Shift, Control, Alt, AltGraph, CapsLock)
      if (e.key === "Shift" || e.key === "Control" || e.key === "Alt" || e.key === "AltGraph" || e.key === "CapsLock") {
        if (this.typingEng.mode === 4 || this.typingEng.isCompleted || !targetChar) {
          return;
        }

        const chord = resolveTargetChord(targetChar);
        const isExpectedMod = chord && chord.allowedMods.has(e.key);

        if (!isExpectedMod) {
          e.preventDefault();
          this.audio.playError();
          this.typingEng.countErrors++;
          if (targetChar) this.typingEng.recordCharStat(targetChar, true);
          this.typingEng.updateMetrics();
          const bName = e.key === "CapsLock" ? "CAPS LOCK" : e.key.toUpperCase();
          this.showWrongLetterPopup(bName);
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      // Tasti di sistema sempre considerati errore durante la digitazione guidata
      if (e.key === "Meta" || e.key === "OS" || e.key === "ContextMenu") {
        e.preventDefault();
        this.audio.playError();
        this.typingEng.countErrors++;
        if (targetChar) this.typingEng.recordCharStat(targetChar, true);
        this.typingEng.updateMetrics();
        this.showWrongLetterPopup(e.key === "ContextMenu" ? "MENU" : "WIN");
        input.classList.add("error-active");
        setTimeout(() => input.classList.remove("error-active"), 250);
        return;
      }

      // 5. BACKSPACE
      if (e.key === "Backspace") {
        e.preventDefault();
        if (this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("", true);
          input.value = this.typingEng.typedText;
          if (this.typingEng.typedText.length === 0) {
            this.typingEng.resetSessionMetrics();
          }
          return;
        }

        if (this.profileMgr.profile?.AutomaticCorrection) {
          this.audio.playError();
          this.showWrongLetterPopup("BACKSPACE");
          return;
        }

        if (this.typingEng.typedText.length === 0) {
          this.audio.playError();
          this.showWrongLetterPopup("BACKSPACE");
          return;
        }

        const res = this.typingEng.handleKeyInput("", true);
        input.value = this.typingEng.typedText;
        input.classList.remove("error-active");
        if (this.typingEng.typedText.length === 0) {
          this.typingEng.resetSessionMetrics();
        }
        this.updateOriginDisplay();
        this.updateTargetKey();
        return;
      }

      // 6. ENTER (Return)
      if (e.key === "Enter") {
        e.preventDefault();
        const isExpected = (targetChar === "®" || targetChar === "\n");
        if (isExpected || this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("®", false);
          this.processTypingResult(res, "↵");
        } else {
          // Pressione fuori luogo
          this.audio.playError();
          this.typingEng.countErrors++;
          if (targetChar) this.typingEng.recordCharStat(targetChar, true);
          this.typingEng.updateMetrics();
          this.showWrongLetterPopup("INVIO");
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      // 7. TAB
      if (e.key === "Tab") {
        e.preventDefault();
        const isExpected = (targetChar === "→" || targetChar === "\t");
        if (isExpected || this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("→", false);
          this.processTypingResult(res, "⇥");
        } else {
          // Pressione fuori luogo
          this.audio.playError();
          this.typingEng.countErrors++;
          if (targetChar) this.typingEng.recordCharStat(targetChar, true);
          this.typingEng.updateMetrics();
          this.showWrongLetterPopup("TAB");
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      // 8. CARATTERI ALFANUMERICI E SIMBOLI
      // Consente la digitazione anche con AltGr (che su Windows invia ctrlKey=true) o combinazioni Alt
      const isAltGrChar = (e.key === "AltGraph" || e.code === "AltRight" || (typeof e.getModifierState === "function" && e.getModifierState("AltGraph")) || (e.ctrlKey && e.altKey));
      if (e.key.length === 1 && (!e.ctrlKey || isAltGrChar) && !e.metaKey) {
        e.preventDefault();
        const res = this.typingEng.handleKeyInput(e.key, false);
        this.processTypingResult(res, e.key);
      }
    };

    const handleKeyUp = (e) => {
      // Punto 4 & 6: Al rilascio di AltGr, elimina il falso ControlLeft SOLO se si sta rilasciando fisicamente AltRight
      // NON toccare MAI ControlLeft se è stato premuto o rilasciato un altro tasto (come [ ] { }) o se l'utente tiene premuto AltLeft
      const isAltGrKeyRelease = (e.key === "AltGraph" || e.code === "AltRight");
      if (isAltGrKeyRelease && !this.activePhysicalKeys.has("AltLeft") && !this.activePhysicalKeys.has("Alt_AltLeft_1")) {
        this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
        if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
          this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
        }
      }
      if (e.key === "Control" && e.code === "ControlLeft") {
        if (typeof e.getModifierState === "function" && e.getModifierState("AltGraph") && !this.activePhysicalKeys.has("ControlLeft") && !this.activePhysicalKeys.has("Control_ControlLeft_1")) {
          return;
        }
      }
      const isCapsOn = (typeof e.getModifierState === "function") && e.getModifierState("CapsLock");
      this.visual.updateCapsLockLed(isCapsOn);
      this.visual.setKeyPressed(e.key, e.code, e.location, false);
      if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
        this.visual.setPhysicalKeyUp(e.key, e.code, e.location);
      }
    };

    input.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keydown", handleKeyDown);
    input.addEventListener("keyup", handleKeyUp);
    window.addEventListener("keyup", handleKeyUp);

    window.addEventListener("blur", () => {
      document.querySelectorAll(".key.key-pressed").forEach(el => el.classList.remove("key-pressed"));
      this.visual.clearAllPhysicalFingers();
    });

    document.addEventListener("click", (e) => {
      if (document.querySelector(".modal-overlay.active")) return;
      const t = e.target;
      if (t.closest(".floating-window") || t.closest("button") || t.closest("select") || t.closest("input") || t.closest("textarea") || t.closest("a") || t.closest("label")) return;
      input.focus();
    });

    // Reset sessione libera
    document.getElementById("btnClearTypingSession")?.addEventListener("click", () => {
      this.typingEng.resetTypingSession();
      if (input) {
        input.value = "";
        input.focus();
      }
    });
  }

  processTypingResult(res, charTyped) {
    const input = document.getElementById("txtTypedInput");
    if (!res || !input) return;

    if (res.status === "correct" || res.status === "typing") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.remove("error-active");
      this.updateOriginDisplay();
      this.updateTargetKey();
    } else if (res.status === "error") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.add("error-active");
      this.showWrongLetterPopup(charTyped);
      this.updateOriginDisplay();
    } else if (res.status === "error-corrected") {
      input.classList.add("error-active");
      this.showWrongLetterPopup(charTyped);
      setTimeout(() => input.classList.remove("error-active"), 200);
      this.updateOriginDisplay();
    } else if (res.status === "completed") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.remove("error-active");
      // Punto 2: Pulizia sincrona immediata di tutti i tasti e polpastrelli della finestra Mani
      this.visual.clearAllPhysicalFingers();
      this.visual.setTargetChar(null);
      this.updateOriginDisplay();
      this.updateTargetKey();
    }
  }

  setupShortcuts() {
    window.addEventListener("keydown", (e) => {
      if (e.key === "F1") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) helpBtn.click();
        return;
      }

      if (!e.ctrlKey || !e.shiftKey) return;
      const k = e.key.toUpperCase();

      if (e.key === "ArrowLeft") { e.preventDefault(); this.navPhrase(-1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); this.navPhrase(1); }
      else if (e.key === "ArrowUp") { e.preventDefault(); this.navLesson(-1); }
      else if (e.key === "ArrowDown") { e.preventDefault(); this.navLesson(1); }

      else if (e.code === "Digit1" || e.code === "Numpad1" || e.key === "1" || e.key === "!") { e.preventDefault(); this.typingEng.mode = 0; document.getElementById("cboMode").value = "0"; this.updateModeUI(); this.startExercise(); }
      else if (e.code === "Digit2" || e.code === "Numpad2" || e.key === "2" || e.key === '"' || e.key === "@") { e.preventDefault(); this.typingEng.mode = 1; document.getElementById("cboMode").value = "1"; this.updateModeUI(); this.startExercise(); }
      else if (e.code === "Digit3" || e.code === "Numpad3" || e.key === "3" || e.key === "£" || e.key === "#") { e.preventDefault(); this.typingEng.mode = 2; document.getElementById("cboMode").value = "2"; this.updateModeUI(); this.startExercise(); }
      else if (e.code === "Digit4" || e.code === "Numpad4" || e.key === "4" || e.key === "$") { e.preventDefault(); this.typingEng.mode = 3; document.getElementById("cboMode").value = "3"; this.updateModeUI(); this.startExercise(); }
      else if (e.code === "Digit5" || e.code === "Numpad5" || e.key === "5" || e.key === "%") { e.preventDefault(); this.typingEng.mode = 4; document.getElementById("cboMode").value = "4"; this.updateModeUI(); this.startExercise(); }

      else if (k === "X") { e.preventDefault(); this.startExercise(); }
      else if (k === "A") { e.preventDefault(); this.randomPhrase(); }
      else if (k === "E") { e.preventDefault(); this.showSelectPhraseModal(); }
      else if (k === "Z") { e.preventDefault(); this.typingEng.mode = 5; document.getElementById("cboMode").value = "5"; this.updateModeUI(); this.startExercise(); }
      else if (k === "G") { e.preventDefault(); this.typingEng.mode = 3; document.getElementById("cboMode").value = "3"; this.updateModeUI(); this.startExercise(); }

      else if (k === "M") { e.preventDefault(); this.toggleHandsVis(!document.getElementById("handsFloatingWindow")?.classList.contains("window-visible")); }
      else if (k === "S") { e.preventDefault(); this.toggleStatsWindow(); }
      else if (k === "U") { e.preventDefault(); this.showLoginModal(); }
      else if (k === "K") {
        e.preventDefault();
        const chk = document.getElementById("chkShowKeyBoard");
        if (chk) { chk.checked = !chk.checked; this.toggleKeyboardVis(chk.checked); }
      }
      else if (k === "O") {
        e.preventDefault();
        const chk = document.getElementById("chkShowOrigin");
        if (chk) { chk.checked = !chk.checked; this.toggleOriginVis(chk.checked); }
      }
      else if (k === "Y") {
        e.preventDefault();
        const chk = document.getElementById("chkShowTyped");
        if (chk) { chk.checked = !chk.checked; this.toggleTypedVis(chk.checked); }
      }
      else if (k === "B") {
        e.preventDefault();
        const chk = document.getElementById("chkAutomaticCorrection");
        if (chk) {
          chk.checked = !chk.checked;
          if (this.profileMgr.profile) {
            this.profileMgr.profile.AutomaticCorrection = chk.checked;
            this.profileMgr.saveProfile();
          }
        }
      }
      else if (k === "H" || e.code === "KeyH") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) {
          helpBtn.click();
        } else {
          window.open("help_(v.2.12).html", "_blank");
        }
      }
    });
  }

  openCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    if (!win || !textarea) return;
    textarea.value = this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    win.classList.add("window-visible");
    win.style.display = "flex";
  }

  setupCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    const btnSave = document.getElementById("btnCustomSave");
    const btnUpload = document.getElementById("btnCustomUpload");
    const btnDownload = document.getElementById("btnCustomDownload");
    const fileInput = document.getElementById("customFileInput");

    btnSave?.addEventListener("click", () => {
      if (this.profileMgr.profile && textarea) {
        const textVal = textarea.value;
        this.profileMgr.profile.CustomText = textVal;
        this.profileMgr.saveProfile();
        
        // Estrai lezioni custom e popola il menu a tendina
        const parsed = parseCustomExercises(textVal);
        if (parsed.length > 0) {
          this.customLessons = parsed;
          this.setLessonsSource("custom");
          alert(`Esercizi personalizzati salvati! Caricate ${parsed.length} lezioni custom nel menu.`);
        } else {
          alert("Esercizi salvati nel profilo.");
        }
        win?.classList.remove("window-visible");
        if (win) win.style.display = "none";
      }
    });

    btnDownload?.addEventListener("click", () => {
      if (!textarea) return;
      const blob = new Blob([textarea.value], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "TypingTrainerCustom.txt";
      a.click();
      URL.revokeObjectURL(url);
    });

    btnUpload?.addEventListener("click", () => {
      fileInput?.click();
    });

    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const textVal = ev.target?.result || "";
        if (textarea) textarea.value = textVal;
        if (this.profileMgr.profile) {
          this.profileMgr.profile.CustomText = textVal;
          this.profileMgr.saveProfile();
        }
        const parsed = parseCustomExercises(textVal);
        if (parsed.length > 0) {
          this.customLessons = parsed;
          this.setLessonsSource("custom");
          alert(`File "${file.name}" caricato con successo! ${parsed.length} lezioni personalizzate caricate nel menu.`);
        }
      };
      reader.readAsText(file);
    });
  }

  setupStatsUI() {
    document.querySelectorAll('input[name="statsSort"]').forEach(radio => {
      radio.addEventListener("change", (e) => {
        this.statsMgr.sortMode = e.target.value;
        this.statsMgr.renderHistogram();
      });
    });

    document.querySelectorAll('input[name="speedMetric"]').forEach(radio => {
      radio.addEventListener("change", (e) => {
        this.statsMgr.speedMetric = e.target.value;
        this.statsMgr.renderSpeedChart();
      });
    });

    document.querySelectorAll(".speed-filter-chk").forEach(chk => {
      chk.addEventListener("change", () => {
        const types = [];
        document.querySelectorAll(".speed-filter-chk:checked").forEach(c => {
          types.push(parseInt(c.value, 10));
        });
        this.statsMgr.filterTypes = types;
        this.statsMgr.renderSpeedChart();
      });
    });

    document.getElementById("btnClearStats")?.addEventListener("click", () => {
      if (confirm("Azzerare definitivamente tutte le statistiche e i campioni dell'utente loggato?")) {
        this.profileMgr.clearUserStats();
        this.statsMgr.clearSelection();
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      }
    });

    document.getElementById("btnClearSelection")?.addEventListener("click", () => {
      const count = this.statsMgr.selectedSampleIndices.size;
      if (count === 0) return;
      const msg = `Sei sicuro di voler eliminare definitivamente i ${count} campioni selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}"?\n\nQuesta operazione cancellerà solo i campioni evidenziati nel grafico e non potrà essere annullata.`;
      if (confirm(msg)) {
        const p = this.profileMgr.profile;
        if (p && p.Campioni) {
          p.Campioni = p.Campioni.filter(s => !this.statsMgr.selectedSampleIndices.has(s.Index));
          p.Campioni.forEach((s, idx) => s.Index = idx);
          this.profileMgr.saveProfile();
        }
        this.statsMgr.clearSelection();
        this.statsMgr.renderSpeedChart();
        this.statsMgr.renderHistogram();
        alert(`Eliminati con successo ${count} campioni selezionati.`);
      }
    });

    document.getElementById("btnClearNotSelected")?.addEventListener("click", () => {
      const countSel = this.statsMgr.selectedSampleIndices.size;
      const totalFiltered = this.statsMgr.currentFilteredSamples.length;
      const countNot = totalFiltered - countSel;
      if (countSel === 0 || countNot <= 0) return;
      const msg = `ATTENZIONE: Stai per eliminare TUTTI i ${countNot} campioni NON selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}".\n\nVerranno conservati ESCLUSIVAMENTE i ${countSel} campioni attualmente selezionati nel grafico.\n\nSei sicuro di voler procedere? L'operazione non può essere annullata.`;
      if (confirm(msg)) {
        const p = this.profileMgr.profile;
        if (p && p.Campioni) {
          p.Campioni = p.Campioni.filter(s => this.statsMgr.selectedSampleIndices.has(s.Index));
          p.Campioni.forEach((s, idx) => s.Index = idx);
          this.profileMgr.saveProfile();
        }
        this.statsMgr.clearSelection();
        this.statsMgr.renderSpeedChart();
        this.statsMgr.renderHistogram();
        alert(`Eliminati con successo ${countNot} campioni non selezionati.`);
      }
    });

    document.getElementById("btnExportJson")?.addEventListener("click", () => {
      const jsonStr = this.profileMgr.exportJson();
      const blob = new Blob([jsonStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `TFTT_${this.profileMgr.activeUser || 'profile'}.json`;
      a.click();
      URL.revokeObjectURL(url);
    });

    document.getElementById("btnExportXml")?.addEventListener("click", () => {
      const xmlStr = this.profileMgr.exportXml();
      const blob = new Blob([xmlStr], { type: "application/xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `TFTT_${this.profileMgr.activeUser || 'profile'}.xml`;
      a.click();
      URL.revokeObjectURL(url);
    });

    const importInput = document.getElementById("statsImportInput");
    document.getElementById("btnImportProfile")?.addEventListener("click", () => {
      importInput?.click();
    });

    importInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const text = ev.target?.result || "";
        try {
          if (file.name.endsWith(".json") || text.trim().startsWith("{")) {
            const data = JSON.parse(text);
            if (data.UserID) {
              const uId = data.UserID;
              this.profileMgr.profile = data;
              this.profileMgr.activeUser = uId;
              const users = this.profileMgr.getUsers();
              if (!users.includes(uId)) { users.push(uId); this.profileMgr.saveUsers(users); }
              this.profileMgr.saveProfile();
              alert(`Profilo utente "${uId}" importato con successo!`);
              this.loginUser(uId);
              this.statsMgr.renderHistogram();
              this.statsMgr.renderSpeedChart();
            }
          } else {
            alert("File XML rilevato. Per il backup completo utilizzare preferibilmente il formato JSON.");
          }
        } catch(err) {
          alert("Errore durante l'importazione del file: " + err.message);
        }
      };
      reader.readAsText(file);
    });
  }
}

    window.addEventListener("DOMContentLoaded", () => {
      const app = new AppController(
        EMBEDDED_LESSONS,
        EMBEDDED_ALBERTO_PROFILE,
        EMBEDDED_CUSTOM_DEFAULT,
        EMBEDDED_FONEMI_CORPUS
      );
      app.start();
      window.__app = app;
    });