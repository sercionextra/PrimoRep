# Architettura — TenFingersTypingTrainer v6.16

## Obiettivo

La release v6.16 introduce un'architettura di resilienza a doppio binario denominata **Auto-Healing Anti-Ghost-Lock** per il motore vocale `DictationEngine`. L'intervento risolve in modo deterministico una nota vulnerabilità dei browser basati sul motore Chromium/WebKit (Chromium bug #679437 / #339239), in cui l'evento di conclusione della pronuncia vocale (`utter.onend`) può essere perso o ritardato indefinitamente. Questo fenomeno bloccava in precedenza la dettatura in uno stato silente permanente, impedendo sia l'anticipo vocale che l'attivazione del timer di inattività (1 secondo), costringendo l'utente a premere Backspace, a commettere un errore o a forzare il replay manuale (CTRL+SHIFT+SPAZIO).

---

## Modello Architetturale dell'Auto-Healing Vocale (Release v6.16)

### 1. Radice del Problema: Il "Ghost-Lock" della Web Speech API
Nel modello asincrono della Web Speech API nei browser moderni:
* Quando un'istanza di `SpeechSynthesisUtterance` viene inoltrata al sintetizzatore hardware (`synth.speak`), la proprietà `synth.speaking` passa a `true`.
* Al termine effettivo dell'audio, il runtime del browser dovrebbe scatenare l'evento `onend` (o `onerror`), nel quale l'applicazione reimposta `this.isSpeaking = false` e riavvia il timer di stallo (`resetStallTimer`).
* In scenari di digitazione fluida o rapida con pronunce multiple in sequenza, il motore vocale di Chromium può omettere la notifica di `onend`. Di conseguenza:
  1. `this.isSpeaking` restava bloccato a `true`;
  2. Tutte le parole successive venivano accodate in `this.pendingLookahead` in attesa infinita dell'evento fantasma;
  3. Il timer di inattività `resetStallTimer()` intercettava `if (this.isSpeaking || isHardwareSpeaking) return;` e usciva immediatamente senza schedulare alcun timeout;
  4. L'utente si ritrovava a digitare molteplici caratteri senza ricevere alcuna voce e senza l'intervento dell'Auto-Replay, a meno di premere Backspace o commettere un errore (operazioni che invocavano `stopAudioOnly()`).

### 2. Canale di Protezione 1: Utterance Watchdog a Tempo Stimato
Per ogni emissione audio gestita da `speakCurrentToken()`:
* Viene calcolata la durata temporale massima fisiologica dell'enunciato:
  `expectedDurationMs = Math.max(1500, Math.floor((textLength * 90 + 600) / voiceRate))`
* Viene attivato un timer dedicato (`_startUtteranceWatchdog`), memorizzato in `this.utteranceWatchdogTimer`.
* Se la pronuncia si conclude regolarmente, l'evento `utter.onend` provvede a cancellare il watchdog (`_clearUtteranceWatchdog`) e a rilasciare le risorse.
* Se invece l'evento `onend` non perviene entro la finestra temporale di sicurezza, il watchdog interviene forzatamente:
  - Invoca `stopAudioOnly()` per azzerare lo stato bloccato del sintetizzatore;
  - Se è presente un token in attesa (`this.pendingLookahead`), ne avvia la pronuncia immediata;
  - Se non vi sono token pendenti, riarma il timer di inattività (`this.resetStallTimer()`), ripristinando il normale ciclo operativo.

### 3. Canale di Protezione 2: Auto-Healing Proattivo in `resetStallTimer()`
Per garantire l'innesco garantito del timer di 1 secondo anche durante la digitazione ordinaria:
* Viene tracciata la marca temporale di avvio dell'ultima emissione vocale (`this.lastSpeechStartTime`).
* All'interno di `resetStallTimer()`, se l'engine o il sintetizzatore risultano occupati (`this.isSpeaking || isHardwareSpeaking`):
  - Viene calcolata la durata trascorsa: `speechDuration = Date.now() - this.lastSpeechStartTime`.
  - **Se la durata supera 2200 ms**: viene rilevato con certezza uno stato di stallo fantasma (ghost-lock). Il sistema esegue l'auto-guarigione istantanea invocando `this.stopAudioOnly()` per liberare il bus audio, e procede senza interruzione alla schedulazione del timer cadenzato (1000 ms).
  - **Se la durata è inferiore a 2200 ms**: la voce sta legittimamente leggendo. Invece di abbandonare l'esecuzione come avveniva in v6.15, il metodo programma un controllo di verifica al termine stimato (`remainingCheck`), assicurando che alla fine della parola il timer di inattività entri in funzione senza rimanere non schedulato.

### 4. Risveglio Continuo del Bus Audio (`synth.resume()`)
* Nei browser basati su Chromium, lunghi flussi o brevi pause possono indurre la Web Speech API in uno stato di sospensione dormiente (audio context pause).
* All'interno di `updateProgress()`, a ogni battuta valida viene emesso un richiamo preventivo e non bloccante a `this.synth.resume()`, garantendo la massima reattività hardware.

---

## Mappa dei componenti aggiornata

| Componente | Responsabilità v6.16 |
|---|---|
| `engines/dictation-engine.js` | Architettura Auto-Healing a doppio binario: Utterance Watchdog temporizzato, rilevamento ghost-lock in `resetStallTimer()` su soglia temporale (2200 ms), sblocco forzato di `isSpeaking` e `synth.speaking`, e risveglio del bus audio via `resume()` |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.16 (`window.APP_VERSION = "6.16"`) |
| `profiles/profile-manager.js` | Profilo utente e serializzazione persistente aggiornati ad `AppVersion = "6.16"` |
| `index.html` | Intestazione, badge di versione e commenti allineati a v6.16 |
| `help.html` | Note di rilascio v6.16, documentazione dell'Auto-Healing e della resilienza vocale, badge e riferimenti aggiornati |
| `docs/MANUALE_UTENTE_v6.16.md` | Manuale didattico per l'utente allineato alla release v6.16 (senza formule o sintassi LaTeX) |
| `tests/test-dictation-adaptive.js` | Test suite con TEST 11 dedicato alla validazione dell'Auto-Healing contro i blocchi fantasma (ghost-lock) e al riarmo del timer |
| `tests/runtime-smoke.js` | Verifica fumo runtime allineata alla versione 6.16 |
| `tests/static-check.js` | Validazione statica allineata alla versione 6.16 |
| `tests/REGRESSION_CHECKLIST.md` | Protocollo di regressione aggiornato alla versione 6.16 con sezione specifica per l'Auto-Healing |
| `BUILD_MANIFEST.json` | Manifest di compilazione e integrità allineato alla release v6.16 |
