/* TenFingersTypingTrainer v6.0 — AppController: dictation. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// Configurazione dei controlli interattivi della Dettatura Vocale (v.3.8 / v.3.9 / v.5.0)
  setupDictationControls() {
    const chkDict = document.getElementById("chkDictation");
    const rngSpeed = document.getElementById("rngDictationSpeed");
    const chkSpelling = document.getElementById("chkDictationSpelling");
    const chkCaps = document.getElementById("chkDictationCaps");
    const btnReplay = document.getElementById("btnDictationReplay");
    const chkApos = document.getElementById("chkDictationApostrophe");
    const chkSpace = document.getElementById("chkDictationSpace");

    if (chkSpelling) {
      chkSpelling.addEventListener("change", (e) => {
        const isSpell = e.target.checked;
        this.dictation.setSpelling(isSpell);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpelling = isSpell;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la modalità spelling attiva
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
          // Allinea immediatamente la voce al punto in cui si trova il cursore
          const matchLen = this.typingEng.getMatchLength();
          const typedLen = this.typingEng.typedText.length;
          this.dictation.updateProgress(typedLen, matchLen);
        }
        this.returnFocusToTyping();
      });
    }

    if (chkApos) {
      chkApos.addEventListener("change", (e) => {
        const isApos = e.target.checked;
        this.dictation.setAnnounceApostrophe(isApos);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationApostrophe = isApos;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la nuova modalità apostrofo
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (chkSpace) {
      chkSpace.addEventListener("change", (e) => {
        const isSpace = e.target.checked;
        this.dictation.setAnnounceSpace(isSpace);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpace = isSpace;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la nuova modalità spazio
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (chkDict) {
      chkDict.addEventListener("change", (e) => {
        const isEn = e.target.checked;
        this.dictation.setEnabled(isEn);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationEnabled = isEn;
          this.profileMgr.saveProfile();
        }
        if (isEn && !this.typingEng.isCompleted && this.typingEng.originText) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (rngSpeed) {
      rngSpeed.addEventListener("input", (e) => {
        const rate = parseFloat(e.target.value) / 100;
        this.dictation.setSpeed(rate);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpeed = rate;
          this.profileMgr.saveProfile();
        }
      });
      rngSpeed.addEventListener("change", () => {
        this.returnFocusToTyping();
      });
    }

    if (chkCaps) {
      chkCaps.addEventListener("change", (e) => {
        const isCaps = e.target.checked;
        this.dictation.setAnnounceCaps(isCaps);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationCaps = isCaps;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione con la nuova regola maiuscole
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (btnReplay) {
      btnReplay.addEventListener("click", () => {
        this.replayDictation();
        this.returnFocusToTyping();
      });
    }

    const btnConfig = document.getElementById("btnDictationConfig");
    if (btnConfig) {
      btnConfig.addEventListener("click", () => {
        this.openDictationConfigModal();
      });
    }

    this.setupDictationConfigModal();
  },

  // Apertura e popolamento della modale di Configurazione Dettatura Vocale (Release v6.13)
  openDictationConfigModal() {
    const modal = document.getElementById("dictationConfigModal");
    const p = this.profileMgr?.profile;
    if (!modal) return;

    const chkAdaptive = document.getElementById("chkDictationAdaptive");
    const txtMin = document.getElementById("txtDictationMinCpm");
    const rngMin = document.getElementById("rngDictationMinCpm");
    const txtMax = document.getElementById("txtDictationMaxCpm");
    const rngMax = document.getElementById("rngDictationMaxCpm");

    const isAdaptive = !!p?.DictationAdaptive;
    const minVal = p?.DictationMinCpm !== undefined ? p.DictationMinCpm : 100;
    const maxVal = p?.DictationMaxCpm !== undefined ? p.DictationMaxCpm : 200;

    if (chkAdaptive) chkAdaptive.checked = isAdaptive;
    if (txtMin) txtMin.value = String(minVal);
    if (rngMin) rngMin.value = String(minVal);
    if (txtMax) txtMax.value = String(maxVal);
    if (rngMax) rngMax.value = String(maxVal);

    modal.classList.add("active");
  },

  // Configurazione dei listener per la modale Dettatura Adattiva Dinamica (Release v6.13)
  setupDictationConfigModal() {
    const modal = document.getElementById("dictationConfigModal");
    const btnClose = document.getElementById("btnCloseDictationConfigModal");
    const btnCancel = document.getElementById("btnCancelDictationConfig");
    const btnConfirm = document.getElementById("btnConfirmDictationConfig");
    const btnReset = document.getElementById("btnDictationConfigResetDefault");

    const chkAdaptive = document.getElementById("chkDictationAdaptive");
    const txtMin = document.getElementById("txtDictationMinCpm");
    const rngMin = document.getElementById("rngDictationMinCpm");
    const txtMax = document.getElementById("txtDictationMaxCpm");
    const rngMax = document.getElementById("rngDictationMaxCpm");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      this.returnFocusToTyping();
    };

    btnClose?.addEventListener("click", closeModal);
    btnCancel?.addEventListener("click", closeModal);

    // Chiusura da tastiera con tasto Escape
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal?.classList.contains("active")) {
        closeModal();
      }
    });

    // Chiusura al click sull'overlay scuro
    modal?.addEventListener("click", (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });

    // Sincronizzazione bidirezionale Min CPM
    txtMin?.addEventListener("input", (e) => {
      if (rngMin) rngMin.value = e.target.value;
    });
    rngMin?.addEventListener("input", (e) => {
      if (txtMin) txtMin.value = e.target.value;
    });

    // Sincronizzazione bidirezionale Max CPM
    txtMax?.addEventListener("input", (e) => {
      if (rngMax) rngMax.value = e.target.value;
    });
    rngMax?.addEventListener("input", (e) => {
      if (txtMax) txtMax.value = e.target.value;
    });

    // Ripristino valori di default (100 CPM, 200 CPM, Adattiva attiva)
    btnReset?.addEventListener("click", () => {
      if (chkAdaptive) chkAdaptive.checked = true;
      if (txtMin) txtMin.value = "100";
      if (rngMin) rngMin.value = "100";
      if (txtMax) txtMax.value = "200";
      if (rngMax) rngMax.value = "200";
    });

    // Salvataggio impostazioni nel profilo e nell'engine
    btnConfirm?.addEventListener("click", () => {
      const isAdaptive = !!chkAdaptive?.checked;
      let minCpm = txtMin ? parseInt(txtMin.value, 10) : 100;
      let maxCpm = txtMax ? parseInt(txtMax.value, 10) : 200;

      if (isNaN(minCpm) || minCpm < 40) minCpm = 40;
      if (minCpm > 300) minCpm = 300;

      if (isNaN(maxCpm) || maxCpm < minCpm) maxCpm = minCpm;
      if (maxCpm > 500) maxCpm = 500;

      this.dictation.setAdaptiveMode(isAdaptive);
      this.dictation.setAdaptiveCpmThresholds(minCpm, maxCpm);

      if (this.profileMgr?.profile) {
        this.profileMgr.profile.DictationAdaptive = isAdaptive;
        this.profileMgr.profile.DictationMinCpm = minCpm;
        this.profileMgr.profile.DictationMaxCpm = maxCpm;
        this.profileMgr.saveProfile();
      }

      closeModal();
    });
  },

// Riascolto della dettatura con invio di typedLen, matchLen e originText (v.4.2)
  replayDictation() {
    if (!this.dictation.enabled) {
      const chkDict = document.getElementById("chkDictation");
      if (chkDict) {
        chkDict.checked = true;
        this.dictation.setEnabled(true);
      }
    }
    const matchLen = this.typingEng.getMatchLength();
    const typedLen = this.typingEng.typedText.length;
    const originText = this.typingEng.originText;
    this.dictation.replay(typedLen, matchLen, originText);
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
