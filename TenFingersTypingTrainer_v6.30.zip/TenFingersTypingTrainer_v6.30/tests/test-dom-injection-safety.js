#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const helpers = fs.readFileSync(path.join(root, "js/domain/helpers.js"), "utf8");
const sandbox = {};
sandbox.window = sandbox;
vm.createContext(sandbox);
vm.runInContext(`${helpers}\nglobalThis.__htmlEscape = htmlEscape;`, sandbox);

const payload = `"><img src=x onerror="fetch('https://example.invalid')"> & 'test'`;
const escaped = sandbox.__htmlEscape(payload);
if (escaped.includes("<img")) {
  throw new Error("htmlEscape non ha neutralizzato il payload HTML.");
}
if (!escaped.includes("&lt;img") || !escaped.includes("&quot;") || !escaped.includes("&#039;")) {
  throw new Error("htmlEscape non ha codificato tutti i caratteri HTML speciali.");
}

const profileController = fs.readFileSync(
  path.join(root, "js/app/controller/metodi-profili-modali.js"),
  "utf8",
);
const loginMethod = profileController.match(/showLoginModal\(\)\s*\{([\s\S]*?)\n\s{4}\},/);
if (!loginMethod || !loginMethod[1].includes("option.textContent = userName") || loginMethod[1].includes("select.innerHTML")) {
  throw new Error("showLoginModal deve creare option con textContent, non interpolare HTML.");
}

const statistics = fs.readFileSync(path.join(root, "js/analytics/statistics-manager.js"), "utf8");
if (!statistics.includes('data-title="${htmlEscape(pt.sample.Esercizio || "")}"')) {
  throw new Error("Il titolo dell'esercizio non è escaped nell'attributo SVG data-title.");
}
if (!statistics.includes("inspectText.replaceChildren(") || !statistics.includes("document.createTextNode(` | Errori:")) {
  throw new Error("Il testo di ispezione deve essere composto con nodi DOM e textContent.");
}

const guide = fs.readFileSync(path.join(root, "js/app/controller/metodi-rendering-guida.js"), "utf8");
if (!guide.includes("htmlEscape(ch)")) {
  throw new Error("I caratteri del testo guida non vengono escaped prima del rendering HTML.");
}

console.log("PASS: htmlEscape neutralizza payload HTML e attributi evento.");
console.log("PASS: nomi profilo inseriti nelle option tramite textContent.");
console.log("PASS: titoli esercizio e testo statistiche non vengono interpretati come HTML.");
console.log("PASS: caratteri del testo guida sono escaped prima del rendering.");
