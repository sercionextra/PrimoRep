# Architettura TenFingersTypingTrainer v6.52

Documento di aggiornamento architetturale rispetto alla v6.51.

## 1. Obiettivo della Release v6.52
Rendere immediatamente distinguibile a colpo d'occhio la modalità di ciascun campione (`TipoCampione` 1..8) nel grafico SVG delle velocità, senza interferire con gli stati visivi esistenti (verde per il campione evidenziato `.speed-point.inspected` e arancione per i campioni selezionati `.speed-point.selected`).

## 2. Interventi Architetturali
1. **Mappa colori centralizzata (`js/analytics/statistics-manager.js`):**
   - Aggiunto `StatisticsManager.prototype.getSampleTypeColor(tipoCampione)` per associare alle 8 tipologie di sessione (`1` Phrases `#3b82f6`, `2` Custom `#a855f7`, `3` Random `#06b6d4`, `4` Typing `#ec4899`, `5` Random Phrase `#6366f1`, `6` All Chars `#ef4444`, `7` Fonemi `#38bdf8`, `8` Carenze `#d946ef`) colori distinti e privi di tonalità verdi o arancioni, con fallback neutro `#94a3b8`.
   - In `renderSpeedChart()`, la polilinea di collegamento utilizza `rgba(148, 163, 184, 0.55)` (`stroke-width="2"`) per non competere con i punti blu della modalità `Phrases`; ciascun `<circle>` mantiene `r="4"` (o `6` se selezionato) e riceve `fill` dalla mappa di modalità (sovrascritto da `.speed-point.selected` e `.speed-point.inspected` con `!important` in `app.css`).
2. **Legenda compatta CSP-compliant (`index.html`, `assets/styles/app.css`):**
   - Le 8 `<label>` di `#csp-inline-index-035` utilizzano le classi `.speed-filter-label` e `.speed-filter-type-1..8` con `border-bottom: 4px solid <colore>`, evitando stili inline in conformità con `style-src-attr 'none'`.
