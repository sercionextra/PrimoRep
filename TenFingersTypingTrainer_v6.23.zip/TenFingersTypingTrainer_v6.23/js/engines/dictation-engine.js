/* TenFingersTypingTrainer v6.21 | dictation-engine.js | Gestione avanzata episodi di errore (Error Burst) per attivazione mirata dello spelling, ceiling dinamico anti-troncamento e tempi configurabili. */
class DictationEngine {
  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: constructor()
  // =======================================================
  constructor() {
    this.synth = window.speechSynthesis || null;
    this.enabled = false;
    this.speed = 0.9;
    this.announceCaps = false;
    this.announceApostrophe = false; // Opzione A (Esplicita Didattica) vs Opzione B (Naturale)
    this.announceSpace = false; // Dettatura esplicita dello spazio agganciato alla parola seguente (Release v.5.0)
    this.forceSpelling = false; // Forza la dettatura lettera per lettera (v.4.2)
    this.quoteCount = 0; // Tracciamento alternanza virgolette (dispari: aperte, pari: chiuse)
    this.mode = 0;
    this.tokens = [];
    this.currentIndex = 0;
    this.isSpeaking = false;
    this.hasPendingError = false;
    this.stallTimer = null;
    this.hasFiredAutoReplay = false; // Flag di emissione promemoria/replay per pausa corrente
    this.stallRepetitionCount = 0; // Contatore ripetizioni consecutive di inattività (Release v6.15)
    this.isSpeakingReplay = false; // Flag di emissione attiva di un messaggio di Replay/supporto (Release v6.0)
    this.isRecoveringFromCorrection = false; // Flag di avvenuta correzione degli errori in attesa di ripresa digitazione (Release v6.0)

    // Tracciamento metriche correnti per Replay automatico su inattività (Release v.4.9)
    this.lastTypedLen = 0;
    this.lastMatchLen = 0;
    this.stateProvider = null; // Provider dinamico dello stato di battitura live (Release v.4.9)

    // Dettatura Adattiva Dinamica (Release v6.13 / v6.14 / v6.15 / v6.16 / v6.17 / v6.20)
    this.adaptiveMode = false;
    this.minAnticipationCpm = 100;
    this.maxAnticipationCpm = 200;
    this.tokenErrorCount = 0; // Errori commessi sul token corrente
    this.recoveryStreak = 0; // Battute corrette consecutive dopo una correzione
    this.lastActiveTokenIdx = -1; // Indice dell'ultimo token attivo

    // Configurazione Tempi di Inattività e Anti-Troncamento (Release v6.20)
    this.stallBaseDelay = 1500; // Ritardo base di inattività in ms (default 1,5s)
    this.stallLongDelay = 3500; // Ritardo esteso dopo 3 ripetizioni in ms (default 3,5s)
    this.stallSpeedFactor = 1.0; // Coefficiente modulazione inversa velocità vocale (default 1,0)
    this.currentUtteranceExpectedDuration = 1500; // Durata stimata dell'emissione attiva in ms

    // Coda a profondità 1 con assorbimento del ritardo (Release v6.14 - Domanda 1, Opzione C)
    this.pendingLookahead = null;

    // Gestione troncone post-correzione (Release v6.14 - Domanda 2)
    this.isRecoveringTroncone = false;
    this.recoveringTokenIdx = -1;

    // Gestione Spelling al 2° errore consecutivo (Release v6.14 - Domanda 3)
    this.wordSpellingTokenIdx = -1;

    // Proprietà cross-platform v.4.2 e Auto-Healing Anti-Ghost-Lock (Release v6.16 / v6.17)
    this.bestVoice = null;
    this.fallbackLocalVoice = null;
    this.watchdogTimer = null;
    this.utteranceWatchdogTimer = null; // Watchdog deterministico per singola utterance (Release v6.16)
    this.lastSpeechStartTime = 0; // Timestamp avvio dell'ultima pronuncia effettiva (Release v6.16)
    this._retainedUtterances = new Set(); // Previene il WebKit Garbage Collection Bug su Apple Safari

    // Stato per Replay Assistito e Spelling a 3 pressioni (v.4.2)
    this.currentText = "";
    this.lastReplayKey = null;
    this.replayCount = 0;

    // Dizionario fonetico simboli isolati e parentesi allineate (Release v.4.6 / v.5.0)
    this.symbolSpelling = {
      ".": "punto",
      ",": "virgola",
      ";": "punto e virgola",
      ":": "due punti",
      "?": "punto interrogativo",
      "!": "punto esclamativo",
      "'": "apostrofo",
      '"': "virgolette",
      "(": "aperta tonda",
      ")": "chiusa tonda",
      "[": "aperta quadra",
      "]": "chiusa quadra",
      "{": "aperta graffa",
      "}": "chiusa graffa",
      "<": "minore",
      ">": "maggiore",
      "/": "slash",
      "\\": "backslash",
      "-": "trattino",
      _: "trattino basso",
      "+": "più",
      "=": "uguale",
      "*": "asterisco",
      "@": "chiocciola",
      "#": "cancelletto",
      $: "dollaro",
      "£": "sterlina",
      "€": "euro",
      "%": "percento",
      "&": "e commerciale",
      "®": "invio",
      "\n": "invio",
      "→": "tàb",
      "\t": "tàb",
      "|": "pipe",
      "^": "circonflesso",
      "§": "paragrafo",
      "°": "gradi",
      ç: "cediglia",
      Ç: "cediglia",
    };

    this.charSpelling = {
      a: "a",
      b: "bi",
      c: "ci",
      d: "di",
      e: "e",
      f: "effe",
      g: "gi",
      h: "acca",
      i: "i",
      j: "i lunga",
      k: "cappa",
      l: "elle",
      m: "emme",
      n: "enne",
      o: "o",
      p: "pi",
      q: "qu",
      r: "erre",
      s: "esse",
      t: "ti",
      u: "u",
      v: "vu",
      w: "doppia vu",
      x: "ics",
      y: "ipsilon",
      z: "zeta",
      ç: "cediglia",
      à: "a grave",
      è: "e grave",
      é: "e acuta",
      ì: "i grave",
      ò: "o grave",
      ù: "u grave",
      " ": "spazio",
    };

    this.initVoices();
  }

  setAnnounceSpace(val) {
    this.announceSpace = !!val;
  }

  // Registrazione del provider per interrogare lo stato live di battitura (Release v.4.9)
  setStateProvider(provider) {
    this.stateProvider = typeof provider === "function" ? provider : null;
  }

  setAnnounceApostrophe(val) {
    this.announceApostrophe = !!val;
  }

  setSpelling(val) {
    this.forceSpelling = !!val;
  }

  // Configurazione Dettatura Adattiva Dinamica (Release v6.13)
  setAdaptiveMode(val) {
    this.adaptiveMode = !!val;
  }

  setAdaptiveCpmThresholds(minCpm, maxCpm) {
    this.minAnticipationCpm = Math.max(20, parseInt(minCpm, 10) || 100);
    this.maxAnticipationCpm = Math.max(
      this.minAnticipationCpm,
      parseInt(maxCpm, 10) || 200,
    );
  }

  // Configurazione Tempi di Inattività e Modulazione Velocità Vocale (Release v6.20)
  setStallDelays(baseDelayMs, longDelayMs, speedFactor) {
    this.stallBaseDelay = Math.max(500, parseInt(baseDelayMs, 10) || 1500);
    this.stallLongDelay = Math.max(
      this.stallBaseDelay,
      parseInt(longDelayMs, 10) || 3500,
    );
    this.stallSpeedFactor =
      typeof speedFactor === "number" && !isNaN(speedFactor)
        ? Math.max(0, Math.min(2.0, speedFactor))
        : 1.0;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: formatApostropheExplicit(word)
  // CONTESTO: Scansione esplicita di "apostrofo" per tutte le parole terminanti con ' (Comportamento 1)
  // =======================================================
  // Normalizza la pronuncia esplicita dell'apostrofo per elisioni, troncamenti e accenti (Release v.4.9)
  formatApostropheExplicit(word) {
    if (!word.includes("'")) return word;

    const apostropheIndex = word.indexOf("'");
    const prefix = word.slice(0, apostropheIndex);
    const suffix = word.slice(apostropheIndex + 1);
    const prefixLower = prefix.toLowerCase();

    // Mappa ortoepica per prefissi italiani elisi
    let prefixSpoken = "";
    if (prefixLower === "l") {
      prefixSpoken = "elle apostrofo";
    } else if (prefixLower === "dell") {
      prefixSpoken = "dell apostrofo";
    } else if (prefixLower === "all") {
      prefixSpoken = "all apostrofo";
    } else if (prefixLower === "dall") {
      prefixSpoken = "dall apostrofo";
    } else if (prefixLower === "nell") {
      prefixSpoken = "nell apostrofo";
    } else if (prefixLower === "sull") {
      prefixSpoken = "sull apostrofo";
    } else if (prefixLower === "un") {
      prefixSpoken = "un apostrofo";
    } else if (prefixLower === "c") {
      prefixSpoken = "ci apostrofo";
    } else if (prefixLower === "d") {
      prefixSpoken = "di apostrofo";
    } else if (prefixLower === "s") {
      prefixSpoken = "si apostrofo";
    } else if (prefixLower === "m") {
      prefixSpoken = "emme apostrofo";
    } else if (prefixLower === "t") {
      prefixSpoken = "ti apostrofo";
    } else if (prefixLower === "v") {
      prefixSpoken = "vi apostrofo";
    } else if (/^[aeiou]$/.test(prefixLower)) {
      // Vocale singola con apostrofo (es. E', A', O', U', I') - Comportamento A (Release v.4.9)
      prefixSpoken = `${prefix.toUpperCase()} apostrofo`;
    } else {
      prefixSpoken = `${prefix} apostrofo`;
    }

    if (suffix.length > 0) {
      return `${prefixSpoken} ${suffix}`;
    }
    // Caso troncamento o parola con apostrofo finale (es. "SALMI'", "ATTENTITA'", "po'")
    return prefixSpoken;
  }

  // Helper grammaticale: formatta il conteggio errori in italiano naturale
  _formatErrorCount(count) {
    const parole = [
      "zero",
      "un",
      "due",
      "tre",
      "quattro",
      "cinque",
      "sei",
      "sette",
      "otto",
      "nove",
      "dieci",
    ];
    const parolaNumero = parole[count] || String(count);
    return count === 1 ? "un errore" : `${parolaNumero} errori`;
  }

  // Helper per lo spelling del singolo carattere (Release v.4.6 / v.5.0)
  _spellOutChar(ch) {
    if (!ch) return "";
    const lower = ch.toLowerCase();
    if (ch === " ") return "spazio";
    if (ch === "®" || ch === "\n") return "invio";
    if (ch === "→" || ch === "\t") return "tàb";
    if (ch === "&") return "e commerciale";
    if (ch === "ç" || ch === "Ç" || lower === "ç") return "cediglia";
    if (this.symbolSpelling[ch]) return this.symbolSpelling[ch];
    if (this.charSpelling[lower]) {
      return /^[A-Z]$/.test(ch)
        ? `maiuscola ${this.charSpelling[lower]}`
        : this.charSpelling[lower];
    }
    // Compitazione esplicita cifra per cifra durante lo spelling forzato
    if (/[0-9]/.test(ch)) {
      const numNames = [
        "zero",
        "uno",
        "due",
        "tre",
        "quattro",
        "cinque",
        "sei",
        "sette",
        "otto",
        "nove",
      ];
      return numNames[parseInt(ch, 10)];
    }
    return ch;
  }

  // Helper robusto per la conversione fonetica del singolo carattere (Release v.5.0)
  getSpokenChar(ch, isOpening = false) {
    if (ch === " ") return "spazio";
    if (ch === "®" || ch === "\n") return "invio";
    if (ch === "→" || ch === "\t") return "tàb";
    if (ch === '"')
      return isOpening ? "aperte virgolette" : "chiuse virgolette";
    if (ch === "ç" || ch === "Ç") return "cediglia";
    if (this.symbolSpelling[ch]) return this.symbolSpelling[ch];
    return ch;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: _getCasingPrefix()
  // CONTESTO: Diagnosi esatta su parole con lettere e apostrofo (es. ATTENTITA')
  // =======================================================
  // Algoritmo nativo: individua se una parola è "tutto maiuscolo" o "maiuscolo" (Release v.4.9)
  _getCasingPrefix(word) {
    if (!word || typeof word !== "string") return "";
    // Isola tutti i caratteri alfabetici per valutare l'effettivo casing escludendo l'apostrofo
    const letters = word.replace(/[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g, "");
    if (letters.length === 0) return "";

    const isAllUpper =
      letters.length > 1 &&
      letters === letters.toUpperCase() &&
      /[A-Z]/.test(letters);

    const isTitleOrSingleUpper = !isAllUpper && /^[A-Z]/.test(letters[0]);

    if (isAllUpper) {
      return "tutto maiuscolo";
    } else if (isTitleOrSingleUpper) {
      return "maiuscolo";
    }
    return "";
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.5.0).js)
  // METODO: _sanitizeForTTS(text)
  // CONTESTO: Protezione fonetica anti-acronimi e conversione acustica obbligatoria di 'ç' isolata in 'cediglia'
  // =======================================================
  _sanitizeForTTS(text) {
    if (!text || typeof text !== "string") return "";

    // Sostituzione fonetica proattiva: qualsiasi 'ç' o 'Ç' isolata o racchiusa tra apici/virgolette
    // viene trascritta come "cediglia" prima di raggiungere l'API di sintesi vocale del browser
    let sanitized = text.replace(
      /(^|[^a-zA-ZàèéìòùÀÈÉÌÒÙ])[çÇ](?=$|[^a-zA-ZàèéìòùÀÈÉÌÒÙ])/g,
      "$1cediglia",
    );

    // Se l'utente ha esplicitamente richiesto lo spelling forzato o siamo in modalità a singoli caratteri, non applicare lower-case
    if (this.forceSpelling || [1, 3, 5, 6].includes(this.mode)) {
      return sanitized;
    }

    // Converte in minuscolo tutte le sequenze di 2 o più lettere maiuscole consecutive per evitare che vengano compitate
    return sanitized.replace(/[A-ZÀÈÉÌÒÙ]{2,}/g, (match) =>
      match.toLowerCase(),
    );
  }

  // =========================================================================
  // PUNTO DI INSERIMENTO: _getPunctuationSpoken(punctStr)
  // =========================================================================
  // Converte una sequenza di segni di punteggiatura e simboli nei rispettivi nomi parlati (Release v.4.9)
  _getPunctuationSpoken(punctStr) {
    if (!punctStr || typeof punctStr !== "string") return "";
    const parts = [];
    for (const ch of punctStr) {
      if (ch === '"') {
        parts.push("chiuse virgolette");
      } else if (ch === "®" || ch === "\n") {
        parts.push("invio");
      } else if (ch === "→" || ch === "\t") {
        parts.push("tàb");
      } else if (this.symbolSpelling[ch]) {
        parts.push(this.symbolSpelling[ch]);
      }
    }
    return parts.join(" ");
  }

  // Helper di normalizzazione RFC 5646 elastica: riconosce 'it', 'it-IT', 'it_IT', 'it-CH', 'ita'
  _isItalianVoice(lang) {
    if (!lang) return false;
    const clean = String(lang).toLowerCase().replace(/_/g, "-");
    return clean === "it" || clean.startsWith("it-") || clean === "ita";
  }

  // Watchdog a 2200ms calibrato per consentire l'elaborazione neurale cloud sui Fonemi complessi
  _startWatchdog(utterance, token) {
    this._clearWatchdog();
    this.watchdogTimer = setTimeout(() => {
      if (!this.isSpeaking) {
        this._retainedUtterances.delete(utterance);
        if (this.synth) {
          this.synth.cancel();
        }
        // Se la voce che si è bloccata era una voce remota, riesegue il token con la voce locale stabile
        if (
          this.fallbackLocalVoice &&
          utterance.voice !== this.fallbackLocalVoice
        ) {
          this.speakCurrentToken(this.fallbackLocalVoice);
        }
      }
    }, 2200);
  }

  _clearWatchdog() {
    if (this.watchdogTimer) {
      clearTimeout(this.watchdogTimer);
      this.watchdogTimer = null;
    }
  }

  // Watchdog deterministico anti-ghost-lock per singola emissione (Release v6.16)
  _startUtteranceWatchdog(utterance, maxDurationMs) {
    this._clearUtteranceWatchdog();
    this.utteranceWatchdogTimer = setTimeout(() => {
      if (this._retainedUtterances && this._retainedUtterances.has(utterance)) {
        // Ghost-lock rilevato: il browser non ha notificato onend entro la durata attesa
        this._clearWatchdog();
        this._clearUtteranceWatchdog();
        this.isSpeaking = false;
        this.isSpeakingReplay = false;
        this._retainedUtterances.delete(utterance);
        if (this.synth && (this.synth.speaking || this.synth.pending)) {
          try {
            this.synth.cancel();
          } catch (e) {}
        }
        if (this.pendingLookahead) {
          const next = this.pendingLookahead;
          this.pendingLookahead = null;
          if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
            this.currentIndex = next.tokenIndex;
          }
          this.speakCurrentToken(next.forcedVoice, next.customText);
        } else {
          this.resetStallTimer();
        }
      }
    }, maxDurationMs);
  }

  _clearUtteranceWatchdog() {
    if (this.utteranceWatchdogTimer) {
      clearTimeout(this.utteranceWatchdogTimer);
      this.utteranceWatchdogTimer = null;
    }
  }

  initVoices() {
    if (!this.synth) return;
    const load = () => {
      const voices = this.synth.getVoices() || [];
      const itVoices = voices.filter((v) => this._isItalianVoice(v.lang));

      if (itVoices.length === 0) {
        this.bestVoice = null;
        this.fallbackLocalVoice = null;
        return;
      }

      // Algoritmo di Scoring Pesato Cross-Platform
      const scoreVoice = (voice) => {
        let score = 0;
        const name = (voice.name || "").toLowerCase();

        // Conformità standard BCP-47
        if (String(voice.lang).toLowerCase().replace(/_/g, "-") === "it-it")
          score += 20;

        // Voci Neurali / Edge Online / Google Network
        if (
          name.includes("natural") ||
          name.includes("neural") ||
          name.includes("online")
        )
          score += 60;
        if (name.includes("google") && !name.includes("offline")) score += 40;

        // Voci Apple Enhanced / Premium / Siri (macOS / iOS)
        if (name.includes("enhanced") || name.includes("premium")) score += 45;
        if (
          name.includes("siri") ||
          name.includes("alice") ||
          name.includes("federica")
        )
          score += 30;

        // Voci Microsoft Desktop OneCore / SAPI5
        if (
          name.includes("elsa") ||
          name.includes("isabella") ||
          name.includes("paola")
        )
          score += 25;

        // Preferenza Timbro didattico: penalizzazione timbri scuri o robotici
        if (
          name.includes("cosimo") ||
          name.includes("diego") ||
          name.includes("matteo")
        )
          score -= 15;

        // Supporto Linux speech-dispatcher / espeak-ng / mbrola
        if (name.includes("espeak") || name.includes("mbrola")) score += 10;

        return score;
      };

      const ranked = [...itVoices].sort(
        (a, b) => scoreVoice(b) - scoreVoice(a),
      );
      this.bestVoice = ranked[0] || null;

      // Voce di riserva garantita a bordo macchina (localService === true) per recovery da offline
      this.fallbackLocalVoice =
        itVoices.find((v) => v.localService === true && scoreVoice(v) > 0) ||
        itVoices.find((v) => v.localService === true) ||
        ranked[ranked.length - 1] ||
        null;
    };

    load();
    if (typeof this.synth.onvoiceschanged !== "undefined") {
      this.synth.onvoiceschanged = load;
    }
  }

  setEnabled(val) {
    this.enabled = !!val;
    if (!this.enabled) {
      this.stop();
    }
  }

  setSpeed(rate) {
    this.speed = Math.max(0.6, Math.min(1.4, rate));
  }

  setAnnounceCaps(val) {
    this.announceCaps = !!val;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.5.0).js)
  // METODO: tokenizeText(text, mode)
  // CONTESTO: Gestione dello Spazio antecedente agganciato e supporto per simboli e layout
  // =======================================================
  // Tokenizzazione adattiva con lettura esplicita di apostrofo per parole terminanti con ' (Release v.4.9)
  tokenizeText(text, mode) {
    this.mode = mode;
    this.tokens = [];
    this.currentIndex = 0;
    if (!text) return;

    const isSingleCharMode = this.forceSpelling || [1, 3, 5, 6].includes(mode);

    if (isSingleCharMode) {
      for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        let spoken = "";
        const isUpper = /^[A-Z]$/.test(ch);
        const lower = ch.toLowerCase();

        if (ch === '"') {
          this.quoteCount++;
          spoken =
            this.quoteCount % 2 === 1
              ? "aperte virgolette"
              : "chiuse virgolette";
        } else if (ch === "&") {
          spoken = "e commerciale";
        } else if (ch === "ç" || ch === "Ç") {
          spoken = "cediglia";
        } else if (ch === "→" || ch === "\t") {
          spoken = "tàb";
        } else if (this.symbolSpelling[ch]) {
          spoken = this.symbolSpelling[ch];
        } else if (isUpper) {
          spoken = `maiuscola ${this.charSpelling[lower] || lower}`;
        } else if (this.charSpelling[lower]) {
          spoken = this.charSpelling[lower];
        } else if (/[0-9]/.test(ch)) {
          const numNames = [
            "zero",
            "uno",
            "due",
            "tre",
            "quattro",
            "cinque",
            "sei",
            "sette",
            "otto",
            "nove",
          ];
          spoken = numNames[parseInt(ch, 10)];
        } else {
          spoken = ch;
        }

        this.tokens.push({
          startIndex: i,
          endIndex: i + 1,
          wordStart: i,
          wordEnd: i + 1,
          rawWord: ch,
          spokenText: spoken,
        });
      }
    } else {
      let i = 0;
      const len = text.length;

      // Inclusione di Tab (→, \t) nei simboli di apertura affinché " →colonna" formi "spazio tàb colonna" (Release v.5.0)
      const openingSymbols = new Set(['"', "(", "[", "{", "→", "\t"]);
      const closingAndPunct = new Set([
        ".",
        ",",
        ";",
        ":",
        "?",
        "!",
        '"',
        ")",
        "]",
        "}",
        "®",
        "\n",
        "→",
        "\t",
      ]);

      while (i < len) {
        // Conteggio e rilevamento puntuale di OGNI singolo spazio antecedente al blocco (Release v.5.0)
        let spaceCount = 0;
        const spaceStart = i;
        while (i < len && text[i] === " ") {
          spaceCount++;
          i++;
        }

        if (i >= len) break;

        const chunkStart = spaceStart;

        // Prefisso vocale per ogni spazio antecedente rilevato
        const spacesSpokenPrefix =
          this.announceSpace && spaceCount > 0
            ? "spazio ".repeat(spaceCount)
            : "";

        if (text[i] === "<") {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i + 1,
            wordStart: i,
            wordEnd: i + 1,
            rawWord: "<",
            spokenText: `${spacesSpokenPrefix}minore`.trim(),
          });
          i++;
          continue;
        }

        if (text[i] === ">") {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i + 1,
            wordStart: i,
            wordEnd: i + 1,
            rawWord: ">",
            spokenText: `${spacesSpokenPrefix}maggiore`.trim(),
          });
          i++;
          continue;
        }

        if (text[i] === "-") {
          const isNegativeNumberLiteral =
            i + 1 < len &&
            /[0-9]/.test(text[i + 1]) &&
            (i === 0 || text[i - 1] === " " || openingSymbols.has(text[i - 1]));

          if (!isNegativeNumberLiteral) {
            let nextIdx = i + 1;
            while (nextIdx < len && text[nextIdx] === " ") {
              nextIdx++;
            }
            const nextChar = nextIdx < len ? text[nextIdx] : "";
            const isMeno =
              /[0-9]/.test(nextChar) || ["(", "[", "{"].includes(nextChar);

            const spokenMinus = isMeno ? "meno" : "trattino";
            this.tokens.push({
              startIndex: chunkStart,
              endIndex: i + 1,
              wordStart: i,
              wordEnd: i + 1,
              rawWord: "-",
              spokenText: `${spacesSpokenPrefix}${spokenMinus}`.trim(),
            });
            i++;
            continue;
          }
        }

        const leadingSpoken = [];

        // Inserimento della dicitura per ogni spazio antecedente (Release v.5.0)
        if (this.announceSpace && spaceCount > 0) {
          for (let s = 0; s < spaceCount; s++) {
            leadingSpoken.push("spazio");
          }
        }

        while (i < len && openingSymbols.has(text[i])) {
          const sym = text[i];
          if (sym === '"') {
            this.quoteCount++;
            leadingSpoken.push(
              this.quoteCount % 2 === 1
                ? "aperte virgolette"
                : "chiuse virgolette",
            );
          } else if (sym === "→" || sym === "\t") {
            leadingSpoken.push("tàb");
          } else if (this.symbolSpelling[sym]) {
            leadingSpoken.push(this.symbolSpelling[sym]);
          }
          i++;
        }

        const wordStart = i;
        while (
          i < len &&
          text[i] !== " " &&
          !openingSymbols.has(text[i]) &&
          !closingAndPunct.has(text[i]) &&
          text[i] !== "<" &&
          text[i] !== ">" &&
          (text[i] !== "-" ||
            (i === wordStart && i + 1 < len && /[0-9]/.test(text[i + 1])))
        ) {
          i++;
        }

        if (i < len && text[i] === "'") {
          const isNumericApostrophe =
            i > wordStart &&
            /[0-9]/.test(text[i - 1]) &&
            i + 1 < len &&
            /[0-9]/.test(text[i + 1]);

          if (isNumericApostrophe) {
            while (
              i < len &&
              text[i] !== " " &&
              !openingSymbols.has(text[i]) &&
              !closingAndPunct.has(text[i]) &&
              text[i] !== "<" &&
              text[i] !== ">"
            ) {
              i++;
            }
          } else {
            i++;
            while (
              i < len &&
              text[i] !== " " &&
              !openingSymbols.has(text[i]) &&
              !closingAndPunct.has(text[i]) &&
              text[i] !== "<" &&
              text[i] !== ">" &&
              text[i] !== "-"
            ) {
              i++;
            }
          }
        }

        const wordEnd = i;
        let rawWord = text.slice(wordStart, wordEnd);
        let spokenWord = "";

        if (rawWord.length > 0) {
          if (rawWord.includes("&")) {
            rawWord = rawWord.replace(/&/g, " e commerciale ");
          }

          if (rawWord.toLowerCase() === "ç") {
            spokenWord = "cediglia";
          } else if (/[0-9]/.test(rawWord)) {
            let cleanNumber = rawWord.replace(/'/g, "");
            cleanNumber = cleanNumber.replace(/(\d+),(\d+)/g, "$1 virgola $2");
            spokenWord = cleanNumber;
          } else if (this.symbolSpelling[rawWord]) {
            spokenWord = this.symbolSpelling[rawWord];
          } else if (rawWord.includes("'")) {
            // Comportamento 1: tutte le parole che terminano con apostrofo (es. SALMI', ATTENTITA', E', po')
            // pronunciano SEMPRE "apostrofo" affinché il tasto fisico non venga omesso (Release v.4.9)
            const endsWithApos = rawWord.endsWith("'");
            spokenWord =
              endsWithApos || this.announceApostrophe
                ? this.formatApostropheExplicit(rawWord)
                : rawWord;
          } else {
            spokenWord = rawWord;
          }

          if (this.announceCaps && !/[0-9]/.test(rawWord)) {
            const isAllUpper =
              rawWord.length > 1 &&
              rawWord === rawWord.toUpperCase() &&
              /[A-Z]/.test(rawWord);

            const isTitleOrSingleUpper =
              !isAllUpper && /^[A-Z]/.test(rawWord[0]);

            if (isAllUpper) {
              spokenWord = `tutto maiuscolo ${spokenWord}`;
            } else if (isTitleOrSingleUpper) {
              spokenWord = `maiuscolo ${spokenWord}`;
            }
          }
        }

        const trailingSpoken = [];
        while (i < len && closingAndPunct.has(text[i])) {
          const sym = text[i];
          if (sym === '"') {
            this.quoteCount++;
            trailingSpoken.push(
              this.quoteCount % 2 === 1
                ? "aperte virgolette"
                : "chiuse virgolette",
            );
          } else if (sym === "→" || sym === "\t") {
            trailingSpoken.push("tàb");
          } else if (this.symbolSpelling[sym]) {
            trailingSpoken.push(this.symbolSpelling[sym]);
          }
          i++;
        }

        if (i === chunkStart) {
          i++;
          continue;
        }

        const parts = [...leadingSpoken];
        if (spokenWord) parts.push(spokenWord);
        parts.push(...trailingSpoken);

        const combinedSpoken = parts.join(" ").trim();
        if (combinedSpoken.length > 0) {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i,
            wordStart: wordStart,
            wordEnd: wordEnd,
            rawWord: rawWord,
            spokenText: combinedSpoken,
          });
        }
      }
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODI: startSession, speakCurrentToken e resetStallTimer
  // CONTESTO: Disaccoppiamento timer da speakCurrentToken e ceiling di 1,5s su audio occupato
  // =======================================================

  startSession(text, mode) {
    this.stop();
    this.quoteCount = 0;
    this.currentText = text || "";
    this.lastReplayKey = null;
    this.replayCount = 0;
    this.hasFiredAutoReplay = false;
    this.isSpeakingReplay = false;
    this.isRecoveringFromCorrection = false;
    this.lastKeystrokeTime = 0;
    this.tokenErrorCount = 0;
    this.recoveryStreak = 0;
    this.lastActiveTokenIdx = -1;

    // Inizializzazione metrica di posizione per la nuova sessione
    this.lastTypedLen = 0;
    this.lastMatchLen = 0;

    this.tokenizeText(text, mode);
    this.currentIndex = 0;
    this.hasPendingError = false;

    if (this.enabled && this.tokens.length > 0) {
      setTimeout(() => {
        this.speakCurrentToken();
        // Arma il timer di inattività fin dall'inizio: se l'allievo esita sulla prima lettera, scatterà il Replay
        this.resetStallTimer();
      }, 120);
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODI: speakCurrentToken() e updateProgress()
  // CONTESTO: Riallineamento dinamico istantaneo su scavalcamento parole e protezione da freeze vocale
  // =======================================================

  // Emissione vocale protetta con auto-resume, anti-freeze e coda lookahead a profondità 1 (Release v6.14)
  speakCurrentToken(forcedVoice = null, customText = null, isDirect = false) {
    if (!this.enabled || !this.synth) return;
    if (this.currentIndex >= this.tokens.length && !customText) return;
    if (this.hasPendingError && !customText) return;

    // Se l'engine sta già pronunciando e non si tratta di un comando diretto (errore/correzione/replay),
    // applica l'Opzione C: buffer a profondità 1 con assorbimento del ritardo (Release v6.14)
    if (!isDirect && this.isSpeaking) {
      this.pendingLookahead = {
        forcedVoice,
        customText,
        tokenIndex: this.currentIndex,
      };
      return;
    }
    if (isDirect) {
      this.pendingLookahead = null;
    }

    // Se l'applicazione non sta parlando (this.isSpeaking === false) ma l'hardware
    // risulta ancora occupato da residui asincroni del browser, ripulisci preventivamente (Release v6.17)
    if (this.synth && (this.synth.speaking || this.synth.pending)) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }

    // Sblocco proattivo da eventuali stati di sospensione dell'engine vocale del browser
    try {
      if (this.synth.paused) {
        this.synth.resume();
      }
    } catch (err) {
      // Fallback silenzioso
    }

    const token = this.tokens[this.currentIndex];
    const textToSpeak =
      customText !== null ? customText : token ? token.spokenText : "";
    if (!textToSpeak) return;

    // Applicazione della protezione fonetica
    const phoneticPayload = this._sanitizeForTTS(textToSpeak);

    const utter = new SpeechSynthesisUtterance(phoneticPayload);
    utter.rate = this.speed;
    utter.pitch = 1.05;
    utter.lang = "it-IT";

    const activeVoice = forcedVoice || this.bestVoice;
    if (activeVoice) {
      utter.voice = activeVoice;
      utter.lang = activeVoice.lang;
    }

    // 1. Registrazione nel set di ancoraggio per prevenire il WebKit GC Bug
    this._retainedUtterances.add(utter);

    // 2. Avvio del Watchdog anti-stallo sia per i token standard che per i testi personalizzati (v6.1)
    this._startWatchdog(utter, token);

    // 3. Watchdog deterministico di auto-healing anti-ghost-lock calibrato sul payload fonetico e sulla velocità vocale (Release v6.16 / v6.20)
    const effectiveSpeed = Math.max(0.2, this.speed || 0.9);
    const rawExpectedDuration = Math.max(1500, phoneticPayload.length * 110 + 800);
    const speedAdjustedDuration = Math.round(rawExpectedDuration / effectiveSpeed);
    this.currentUtteranceExpectedDuration = speedAdjustedDuration;
    const expectedDurationMs = speedAdjustedDuration + 1500;
    this._startUtteranceWatchdog(utter, expectedDurationMs);

    utter.onstart = () => {
      this._clearWatchdog();
      this.isSpeaking = true;
    };

    const cleanup = () => {
      this._clearWatchdog();
      this._clearUtteranceWatchdog();
      this.isSpeaking = false;
      this.isSpeakingReplay = false;
      this._retainedUtterances.delete(utter);
    };

    utter.onend = () => {
      cleanup();
      // Scarico proattivo del buffer lookahead a profondità 1 (Opzione C, Release v6.14)
      if (this.pendingLookahead) {
        const next = this.pendingLookahead;
        this.pendingLookahead = null;
        if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
          this.currentIndex = next.tokenIndex;
        }
        this.speakCurrentToken(next.forcedVoice, next.customText);
      } else {
        // Al termine dell'ultima parola o lettera dettata: riavvia il contatore di attesa (Release v6.15)
        this.resetStallTimer();
      }
    };

    utter.onerror = (e) => {
      cleanup();
      if (e.error !== "canceled" && e.error !== "interrupted") {
        if (
          !forcedVoice &&
          this.fallbackLocalVoice &&
          this.bestVoice !== this.fallbackLocalVoice
        ) {
          this.speakCurrentToken(this.fallbackLocalVoice, customText, true);
          return;
        }
        if (this.pendingLookahead) {
          const next = this.pendingLookahead;
          this.pendingLookahead = null;
          if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
            this.currentIndex = next.tokenIndex;
          }
          this.speakCurrentToken(next.forcedVoice, next.customText);
        } else {
          this.resetStallTimer();
        }
      }
    };

    // Release v6.14 (DOMANDA 4): Nessun annullamento arbitrario via synth.cancel() durante la digitazione!
    // synth.cancel() è circoscritto rigorosamente a stopAudioOnly() su errore, backspace, replay o stop.
    this.clearStallTimer();
    this.isSpeaking = true;
    this.lastSpeechStartTime = Date.now();
    this.synth.speak(utter);
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODO: updateProgress()
  // CONTESTO: Sincronizzazione fluida e continua senza interruzione forzata dell'audio (Release v6.1)
  // =======================================================
  // Avanzamento progressivo della scrittura con riallineamento dinamico, lookahead predittivo continuo e Dettatura Adattiva (Release v6.14)
  updateProgress(typedLen, matchLen, currentCpm = 0) {
    if (!this.enabled || this.tokens.length === 0) return;

    // Auto-wake up proattivo della Web Speech API contro il sonno in background (Release v6.16)
    try {
      if (this.synth && this.synth.paused) {
        this.synth.resume();
      }
    } catch (e) {}

    const hasError = typedLen > matchLen;

    // Memorizzazione avanzamento reale
    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;
    this.lastKeystrokeTime = Date.now();
    this.hasPendingError = hasError;

    // Reset sequenza replay manuali e contatore inattività (Release v6.15):
    // Appena l'utente riprende la digitazione, riportare il contatore di attesa ad 1 secondo
    this.stallRepetitionCount = 0;
    this.lastReplayKey = null;
    this.replayCount = 0;
    this.hasFiredAutoReplay = false;

    // Riarma il timer di inattività a 1 secondo (se non ci sono emissioni audio in corso)
    this.resetStallTimer();

    // Se vi sono errori pendenti, adotta il Soft Hold
    if (hasError) {
      return;
    }

    // IPOTESI A (Release v6.19): Se l'allievo preme un tasto corretto mentre la voce sta ancora pronunciando
    // un messaggio di Replay da inattività/stallo (this.isSpeakingReplay === true), il replay della lettera/parola
    // appena digitata è ormai obsoleto: troncalo immediatamente con latenza zero per non sovrapporsi al nuovo target.
    if (this.isSpeakingReplay) {
      this.stopAudioOnly();
    }

    // REGOLA ARCHITETTURALE CONFERMATA:
    // Individuazione in tempo reale del token fisico in cui si trova il cursore dell'allievo (matchLen)
    let activeTokenIdx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (
      activeTokenIdx === -1 &&
      this.tokens.length > 0 &&
      matchLen >= this.tokens[this.tokens.length - 1].endIndex
    ) {
      activeTokenIdx = this.tokens.length - 1;
    }
    if (activeTokenIdx === -1) return;

    // Scarico proattivo del buffer lookahead se la voce è libera (Release v6.17 / v6.19)
    // Se il token nel buffer appartiene a una posizione già superata (< activeTokenIdx), scartalo per evitare ripetizioni
    if (!this.isSpeaking && this.pendingLookahead) {
      const next = this.pendingLookahead;
      this.pendingLookahead = null;
      if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
        if (next.tokenIndex >= activeTokenIdx) {
          this.currentIndex = next.tokenIndex;
          this.speakCurrentToken(next.forcedVoice, next.customText);
          if (next.tokenIndex === activeTokenIdx) {
            this.lastActiveTokenIdx = activeTokenIdx;
            return;
          }
        }
      } else {
        this.speakCurrentToken(next.forcedVoice, next.customText);
        return;
      }
    }

    // Tracciamento avanzamento token per gestione errori di parola e rampa di recupero (Release v6.14)
    if (this.lastActiveTokenIdx !== activeTokenIdx) {
      this.tokenErrorCount = 0; // Nuova parola: azzera il contatore errori di parola
      this.lastActiveTokenIdx = activeTokenIdx;
      this.recoveryStreak = 0;
      this.isRecoveringTroncone = false;
      this.recoveringTokenIdx = -1;
      this.wordSpellingTokenIdx = -1;
    } else {
      this.recoveryStreak++;
    }

    // GESTIONE SPELLING AL 2° ERRORE CONSECUTIVO SULLA STESSA PAROLA (Release v6.14 - Domanda 3):
    // Se lo spelling della parola è attivo, scandisce lettera per lettera a ogni battuta corretta
    if (this.adaptiveMode && this.wordSpellingTokenIdx !== -1) {
      if (activeTokenIdx === this.wordSpellingTokenIdx) {
        const textRef =
          (this.stateProvider && this.stateProvider().originText) ||
          this.currentText ||
          "";
        const curToken = this.tokens[activeTokenIdx];
        if (
          curToken &&
          matchLen < curToken.endIndex &&
          textRef &&
          matchLen < textRef.length
        ) {
          const nextCharToSpell = this._spellOutChar(textRef[matchLen]);
          this.speakCurrentToken(null, nextCharToSpell);
          return;
        } else {
          // Parola completata: disattiva lo spelling della parola e prosegue normalmente
          this.wordSpellingTokenIdx = -1;
          this.tokenErrorCount = 0;
        }
      } else {
        this.wordSpellingTokenIdx = -1;
        this.tokenErrorCount = 0;
      }
    }

    // GESTIONE DETTATURA TRONCONE POST-CORREZIONE (Release v6.14 - Domanda 2):
    // La digitazione delle lettere corrette appartenenti allo stesso troncone non interrompe l'audio.
    // L'anticipo della parola successiva scatterà solo quando l'allievo raggiunge o supera l'ultima lettera del troncone.
    if (this.isRecoveringTroncone) {
      const curToken = this.tokens[this.recoveringTokenIdx];
      if (
        curToken &&
        matchLen < curToken.endIndex &&
        activeTokenIdx === this.recoveringTokenIdx
      ) {
        return; // Troncone ancora in corso di digitazione: attendi il completamento della parola
      } else {
        this.isRecoveringTroncone = false;
        this.recoveringTokenIdx = -1;
      }
    }

    // Calcolo del coefficiente di anticipo (fisso 0.65 se Adattiva è disattivata, dinamico da 1.00 a 0.65 se Adattiva è attiva)
    let coeff = 0.65;
    if (this.adaptiveMode) {
      const cpm =
        currentCpm > 0
          ? currentCpm
          : (this.stateProvider && this.stateProvider().currentCpm) || 0;

      const minCpm = this.minAnticipationCpm;
      const maxCpm = this.maxAnticipationCpm;

      let baseCoeff = 1.00;
      if (cpm <= minCpm) {
        baseCoeff = 1.00; // Sotto soglia minima: nessun anticipo, attende il completamento della parola
      } else if (cpm >= maxCpm) {
        baseCoeff = 0.65; // A o sopra velocità massima: anticipo pieno
      } else {
        const ratio = (cpm - minCpm) / (maxCpm - minCpm);
        baseCoeff = 1.00 - ratio * (1.00 - 0.65);
      }

      // Rampa di ripresa progressiva post-errore: transizione graduale verso baseCoeff nelle prime 4 battute corrette
      if (this.recoveryStreak < 4) {
        const factor = Math.max(0, this.recoveryStreak) / 4;
        coeff = 1.00 - factor * (1.00 - baseCoeff);
      } else {
        coeff = baseCoeff;
      }
      coeff = Math.max(0.65, Math.min(1.00, coeff));
    }

    // Sincronizzazione predittiva avanzata (Release v6.14 con Opzione C):
    // Gestione differenziata se il cursore ha scavalcato la parola o se si trova nella parola corrente
    if (activeTokenIdx > this.currentIndex) {
      // Slancio veloce: l'allievo è avanzato oltre il token corrente.
      // Valuta se annunciare subito il nuovo token o anticipare già il successivo in base alla soglia
      const curToken = this.tokens[activeTokenIdx];
      const tokenSpan = curToken.endIndex - curToken.startIndex;
      const progressInToken = matchLen - curToken.startIndex;
      const threshold = Math.max(1, Math.floor(tokenSpan * coeff));

      if (
        progressInToken >= threshold &&
        activeTokenIdx + 1 < this.tokens.length
      ) {
        this.currentIndex = activeTokenIdx + 1;
        this.speakCurrentToken();
      } else {
        this.currentIndex = activeTokenIdx;
        this.speakCurrentToken();
      }
    } else if (activeTokenIdx === this.currentIndex) {
      // Avanzamento naturale: calcolo della soglia di anticipo (in base a coeff)
      const curToken = this.tokens[this.currentIndex];
      const tokenSpan = curToken.endIndex - curToken.startIndex;
      const progressInToken = matchLen - curToken.startIndex;
      const threshold = Math.max(1, Math.floor(tokenSpan * coeff));

      if (
        progressInToken >= threshold &&
        this.currentIndex + 1 < this.tokens.length
      ) {
        this.currentIndex++;
        this.speakCurrentToken();
      }
    }
    // Se activeTokenIdx < this.currentIndex, il token futuro è già stato anticipato dal lookahead:
    // la dettatura procede senza salti né ripetizioni.
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.14).js)
  // METODI REATTIVI: notifyError() e notifyErrorCorrection()
  // =======================================================

  // Notifica vocale istantanea alla battuta errata (Release v6.15 / v6.21)
  notifyError() {
    if (!this.enabled || !this.synth) return;
    this.stallRepetitionCount = 0;

    // v6.21: Riconoscimento Episodio di Errore (Error Burst).
    // Se vi sono già errori pendenti (this.hasPendingError === true), le battute successive
    // digitate nella foga prima di Backspace appartengono allo stesso episodio:
    // mantengono il feedback vocale ("errore") ma non incrementano tokenErrorCount.
    const isNewErrorEpisode = !this.hasPendingError;
    this.hasPendingError = true;

    if (this.adaptiveMode) {
      // Individuazione affidabile del token fisico su cui è avvenuto l'errore (usando lastMatchLen)
      let activeTokenIdx = this.tokens.findIndex(
        (t) => this.lastMatchLen >= t.startIndex && this.lastMatchLen < t.endIndex,
      );
      if (activeTokenIdx === -1 && this.tokens.length > 0) {
        if (this.lastMatchLen >= this.tokens[this.tokens.length - 1].endIndex) {
          activeTokenIdx = this.tokens.length - 1;
        } else {
          activeTokenIdx = Math.max(
            0,
            this.tokens.findIndex((t) => t.startIndex >= this.lastMatchLen),
          );
        }
      }
      if (activeTokenIdx >= 0) {
        if (this.lastActiveTokenIdx !== activeTokenIdx) {
          this.lastActiveTokenIdx = activeTokenIdx;
          this.tokenErrorCount = 0;
        }
      }

      if (isNewErrorEpisode) {
        this.tokenErrorCount++;
      }
      this.recoveryStreak = 0;

      if (this.tokenErrorCount >= 2 && activeTokenIdx >= 0) {
        this.wordSpellingTokenIdx = activeTokenIdx;
      }
    }
    this.stopAudioOnly();
    this.speakCurrentToken(null, "errore", true);
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.15).js)
  // METODO: notifyErrorCorrection()
  // CONTESTO: Ripresa prudente al 1° errore corretto e attivazione dello spelling al 2° errore sulla stessa parola (Release v6.15 / v6.21)
  // =======================================================

  // Notifica vocale atomica alla cancellazione con Backspace (Release v6.15 / v6.21)
  notifyErrorCorrection(remainingErrors, typedLen, matchLen, originText) {
    if (!this.enabled || !this.synth) return;
    this.lastKeystrokeTime = Date.now();
    this.stallRepetitionCount = 0;
    this.hasFiredAutoReplay = false;
    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;
    this.hasPendingError = remainingErrors > 0;
    this.stopAudioOnly();

    if (remainingErrors > 0) {
      // Se restano ancora errori da cancellare, scandisce quanti ne mancano
      const msg = `ancora ${this._formatErrorCount(remainingErrors)}`;
      this.speakCurrentToken(null, msg, true);
    } else {
      let activeTokenIdx = this.tokens.findIndex(
        (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
      );
      if (
        activeTokenIdx === -1 &&
        this.tokens.length > 0 &&
        matchLen >= this.tokens[this.tokens.length - 1].endIndex
      ) {
        activeTokenIdx = this.tokens.length - 1;
      }
      if (activeTokenIdx === -1) {
        activeTokenIdx = Math.max(
          0,
          this.tokens.findIndex((t) => t.startIndex >= matchLen),
        );
      }
      if (activeTokenIdx === -1) activeTokenIdx = 0;

      this.lastActiveTokenIdx = activeTokenIdx;

      // Release v6.15 / v6.21: Se la Dettatura Adattiva è attiva:
      // - Al 1° episodio di errore corretto: troncone residuo letto come blocco continuo a ritmo prudente (recoveryStreak = 0)
      // - Al 2° episodio di errore sulla medesima parola: dettatura in SPELLING lettera per lettera persistente fino a fine parola
      if (this.adaptiveMode) {
        this.recoveryStreak = 0;
        const forceSpelling = this.tokenErrorCount >= 2;
        if (forceSpelling) {
          this.wordSpellingTokenIdx = activeTokenIdx;
          this.isRecoveringTroncone = false;
          this.recoveringTokenIdx = -1;
          const textRef = originText || this.currentText || "";
          if (textRef && matchLen < textRef.length) {
            const charToSpell = this._spellOutChar(textRef[matchLen]);
            this.speakCurrentToken(null, charToSpell, true);
          }
        } else {
          this.wordSpellingTokenIdx = -1;
          this.isRecoveringTroncone = true;
          this.recoveringTokenIdx = activeTokenIdx;
          this.resumeFromKeystroke(matchLen, originText, false);
        }
      } else {
        this.resumeFromKeystroke(matchLen, originText, false);
      }
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODI AUSILIARI: _getRemainingPrompt() e resumeFromKeystroke()
  // CONTESTO: Calcolo ed emissione vocale della porzione residua non ancora digitata
  // =======================================================
  _getRemainingPrompt(token, matchLen, textRef) {
    if (!token) return "";
    const remainingParts = [];
    let remainingWordLetters = "";

    // C.1 Eventuali spazi antecedenti non ancora digitati
    let curIdx = Math.max(matchLen, token.startIndex);
    if (this.announceSpace && curIdx < token.wordStart) {
      while (
        curIdx < token.wordStart &&
        curIdx < textRef.length &&
        textRef[curIdx] === " "
      ) {
        remainingParts.push("spazio");
        curIdx++;
      }
    } else {
      while (
        curIdx < token.wordStart &&
        curIdx < textRef.length &&
        textRef[curIdx] === " "
      ) {
        curIdx++;
      }
    }

    // C.2 Eventuali simboli di apertura non ancora digitati prima della parola
    while (curIdx < token.wordStart && curIdx < textRef.length) {
      remainingParts.push(this.getSpokenChar(textRef[curIdx], true));
      curIdx++;
    }

    // C.3 Porzione residua della parola o simbolo (con Casing associato direttamente alle lettere)
    if (curIdx < token.wordEnd && curIdx < textRef.length) {
      remainingWordLetters = textRef.slice(curIdx, token.wordEnd);

      let casingPrefix = "";
      const shouldAnnounceCaps =
        this.announceCaps || [1, 3, 5, 6].includes(this.mode);

      if (
        shouldAnnounceCaps &&
        remainingWordLetters.length > 0 &&
        !/[0-9]/.test(remainingWordLetters)
      ) {
        const lettersOnly = remainingWordLetters.replace(
          /[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g,
          "",
        );
        if (lettersOnly.length > 0) {
          const rawWord = token.rawWord || "";
          const cleanRaw = rawWord.replace(/[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g, "");
          const isOriginalAllUpper =
            cleanRaw.length > 1 &&
            cleanRaw === cleanRaw.toUpperCase() &&
            /[A-Z]/.test(cleanRaw);

          if (isOriginalAllUpper && /[A-Z]/.test(lettersOnly)) {
            casingPrefix = "tutto maiuscolo ";
          } else if (/^[A-Z]/.test(lettersOnly[0])) {
            casingPrefix = "maiuscolo ";
          }
        }
      }

      if (this.symbolSpelling[remainingWordLetters]) {
        remainingParts.push(this.symbolSpelling[remainingWordLetters]);
      } else if (remainingWordLetters === "'") {
        remainingParts.push("apostrofo");
      } else if (remainingWordLetters.endsWith("'")) {
        const baseRem = remainingWordLetters.slice(0, -1);
        remainingParts.push(`${casingPrefix}${baseRem} apostrofo`.trim());
      } else if (remainingWordLetters.includes("'")) {
        remainingParts.push(
          `${casingPrefix}${this.formatApostropheExplicit(remainingWordLetters)}`.trim(),
        );
      } else if (/^[a-zA-ZàèéìòùÀÈÉÌÒÙ0-9]+$/.test(remainingWordLetters)) {
        remainingParts.push(`${casingPrefix}${remainingWordLetters}`.trim());
      } else {
        for (const ch of remainingWordLetters) {
          remainingParts.push(this.getSpokenChar(ch));
        }
      }
      curIdx = token.wordEnd;
    }

    // C.4 Eventuali simboli di chiusura, punteggiatura o layout non ancora digitati
    while (curIdx < token.endIndex && curIdx < textRef.length) {
      remainingParts.push(this.getSpokenChar(textRef[curIdx], false));
      curIdx++;
    }

    return remainingParts.join(" ").trim();
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODO: resumeFromKeystroke()
  // CONTESTO: Ripresa immediata della dettatura vocale dal primo carattere non ancora digitato
  // =======================================================
  // Ripresa immediata della dettatura vocale con supporto Opzione B (troncone continuo) e Spelling temporaneo al 2° errore (Release v6.13)
  resumeFromKeystroke(matchLen, originText, forceSpellingWord = false) {
    if (!this.enabled || !this.synth || this.tokens.length === 0) return;
    this.hasPendingError = false;
    this.lastReplayKey = null;
    this.replayCount = 0;
    this.hasFiredAutoReplay = false;
    this.stallRepetitionCount = 0;

    const textRef = originText || this.currentText || "";

    // Individuazione del token corrispondente alla posizione reale del cursore
    let idx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (idx === -1) {
      idx = this.tokens.findIndex((t) => t.startIndex >= matchLen);
    }
    if (idx === -1) idx = Math.max(0, this.tokens.length - 1);

    this.currentIndex = idx;
    const token = this.tokens[idx];
    const isSingleCharFlow =
      this.forceSpelling || [1, 3, 5, 6].includes(this.mode);

    if (isSingleCharFlow || !token) {
      if (textRef && matchLen < textRef.length) {
        const spokenChar = this._spellOutChar(textRef[matchLen]);
        this.speakCurrentToken(null, spokenChar);
      } else if (token) {
        this.speakCurrentToken(null, token.spokenText);
      }
    } else if (forceSpellingWord) {
      // Release v6.13: Spelling temporaneo del solo troncone residuo al 2° errore sulla stessa parola
      const spellParts = [];
      let curIdx = Math.max(matchLen, token.startIndex);

      // Eventuali spazi antecedenti non ancora digitati
      if (this.announceSpace && curIdx < token.wordStart) {
        while (
          curIdx < token.wordStart &&
          curIdx < textRef.length &&
          textRef[curIdx] === " "
        ) {
          spellParts.push("spazio");
          curIdx++;
        }
      } else {
        while (
          curIdx < token.wordStart &&
          curIdx < textRef.length &&
          textRef[curIdx] === " "
        ) {
          curIdx++;
        }
      }

      // Eventuali simboli di apertura non ancora digitati
      while (curIdx < token.wordStart && curIdx < textRef.length) {
        spellParts.push(this.getSpokenChar(textRef[curIdx], true));
        curIdx++;
      }

      // Compitazione lettera per lettera del residuo alfabetico/numerico
      while (curIdx < token.wordEnd && curIdx < textRef.length) {
        spellParts.push(this._spellOutChar(textRef[curIdx]));
        curIdx++;
      }

      // Eventuali simboli di chiusura / punteggiatura
      while (curIdx < token.endIndex && curIdx < textRef.length) {
        spellParts.push(this.getSpokenChar(textRef[curIdx], false));
        curIdx++;
      }

      const spelledPrompt = spellParts.filter(Boolean).join(", ");
      if (spelledPrompt) {
        this.speakCurrentToken(null, spelledPrompt);
      }
    } else {
      let promptToSpeak = "";
      if (matchLen <= token.startIndex) {
        promptToSpeak = token.spokenText;
      } else {
        promptToSpeak = this._getRemainingPrompt(token, matchLen, textRef);
      }

      if (!promptToSpeak && this.currentIndex + 1 < this.tokens.length) {
        this.currentIndex++;
        promptToSpeak = this.tokens[this.currentIndex].spokenText;
      }

      if (promptToSpeak) {
        this.speakCurrentToken(null, promptToSpeak);
      }
    }

    this.resetStallTimer();
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.15).js)
  // METODO: replay()
  // CONTESTO: Replay assistito con Ipotesi A (Formula Didattica Ultra-Sintetica) e Opzione B (Promemoria Correzione Cadenzato) (Release v6.15)
  // =======================================================
  replay(typedLen = 0, matchLen = 0, originText = null, isAutomatic = false) {
    if (!this.synth || this.tokens.length === 0) return;
    this.stopAudioOnly();

    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;

    if (isAutomatic) {
      this.hasFiredAutoReplay = true;
    } else {
      // Replay manuale: azzera il contatore di ripetizioni da inattività
      this.stallRepetitionCount = 0;
    }

    const textRef = originText || this.currentText || "";
    const numErrors = Math.max(0, typedLen - matchLen);

    // 1. Tracciamento Replay Consecutivi per la stessa posizione
    const posKey = `${typedLen}_${matchLen}`;
    if (!isAutomatic) {
      if (this.lastReplayKey === posKey) {
        this.replayCount++;
      } else {
        this.lastReplayKey = posKey;
        this.replayCount = 1;
      }
    }

    // OPZIONE B (Release v6.15 - Domanda 2): Promemoria Correzione Cadenzato
    // Se vi sono errori non ancora corretti, il sistema NON ripete la parola,
    // ma ripete unicamente l'avviso di correzione (es. "ancora un errore") cadenzato nel tempo
    if (numErrors > 0) {
      const msg = `ancora ${this._formatErrorCount(numErrors)}`;
      this.speakCurrentToken(null, msg, true);
      return;
    }

    // 2. Individuazione del token corrispondente alla posizione reale di digitazione
    let idx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (idx === -1) {
      idx = this.tokens.findIndex((t) => t.startIndex >= matchLen);
    }
    if (idx === -1) idx = Math.max(0, this.tokens.length - 1);

    this.currentIndex = idx;
    this.hasPendingError = false;
    this.isSpeakingReplay = true; // Segnala che la voce sta riproducendo un messaggio di supporto o completamento

    const token = this.tokens[idx];
    const isSingleCharFlow =
      this.forceSpelling ||
      [1, 3, 5, 6].includes(this.mode) ||
      (this.adaptiveMode && this.wordSpellingTokenIdx === idx);

    // =========================================================================
    // CASO A: 3° REPLAY MANUALE CONSECUTIVO -> SPELLING LETTERA PER LETTERA
    // =========================================================================
    if (!isAutomatic && this.replayCount >= 3) {
      const spellParts = [];
      if (textRef && matchLen < textRef.length) {
        if (textRef[matchLen] === " ") {
          spellParts.push("spazio");
        }
        if (token) {
          const spellStart = Math.max(matchLen, token.startIndex);
          const charsToSpell = textRef.slice(spellStart, token.endIndex);
          for (const ch of charsToSpell) {
            spellParts.push(this._spellOutChar(ch));
          }
        } else if (matchLen < textRef.length) {
          spellParts.push(this._spellOutChar(textRef[matchLen]));
        }
      }
      const spelledMessage = spellParts.filter(Boolean).join(", ");
      if (spelledMessage.length > 0) {
        this.speakCurrentToken(null, spelledMessage, true);
        return;
      }
    }

    // =========================================================================
    // CASO B: MODALITÀ SPELLING ATTIVA O 2° ERRORE CONSECUTIVO O NON LESSICALI
    // IPOTESI A (Release v6.15 - Domanda 1): Pronuncia unicamente il nome fonetico della singola lettera attesa
    // =========================================================================
    if (isSingleCharFlow || !token) {
      let msg = "";
      if (textRef && matchLen < textRef.length) {
        msg = this._spellOutChar(textRef[matchLen]);
      } else if (token) {
        msg = token.spokenText;
      }
      if (msg) {
        this.speakCurrentToken(null, msg.trim(), true);
      }
      return;
    }

    // =========================================================================
    // CASO C: MODALITÀ LESSICALI (Parola intera vs Troncone continuo)
    // IPOTESI A (Release v6.15 - Domanda 1): Formula Didattica Ultra-Sintetica (nessun prefisso "completa digitando...")
    // - Se a inizio parola: pronuncia la parola intera;
    // - Se a metà parola (troncone residuo): pronuncia direttamente e solo il troncone residuo come blocco fonetico continuo.
    // =========================================================================
    if (matchLen > token.startIndex) {
      const remainingPrompt = this._getRemainingPrompt(token, matchLen, textRef);
      if (remainingPrompt) {
        this.speakCurrentToken(null, remainingPrompt, true);
      } else {
        this.speakCurrentToken(null, token.spokenText, true);
      }
      return;
    }

    // Inizio token senza errori: pronuncia direttamente la parola intera
    this.speakCurrentToken(null, token.spokenText, true);
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.20).js)
  // METODO: resetStallTimer()
  // CONTESTO: Timer di inattività configurabile con ceiling dinamico anti-troncamento e modulazione velocità (Release v6.20)
  // =======================================================
  resetStallTimer(forcedDelay = null) {
    this.clearStallTimer();
    if (!this.enabled || this.tokens.length === 0) return;

    // Se l'allievo ha completato l'intero testo, non riarmare lo stallo
    const textRef =
      (this.stateProvider && this.stateProvider().originText) ||
      this.currentText ||
      "";
    if (textRef && this.lastMatchLen >= textRef.length) return;

    // Risveglio preventivo del canale audio contro il sonno di Chromium
    try {
      if (this.synth && this.synth.paused) {
        this.synth.resume();
      }
    } catch (e) {}

    const isHardwareSpeaking = !!(
      this.synth && (this.synth.speaking || this.synth.pending)
    );
    const speechDuration = Date.now() - (this.lastSpeechStartTime || 0);

    // AUTO-HEALING ANTI GHOST-LOCK DINAMICO (Release v6.16 / v6.17 / v6.20):
    // 1. Se la nostra applicazione non sta parlando (this.isSpeaking === false),
    // ma l'hardware del browser segnala ancora speaking/pending, è un Ghost-Lock orfano:
    // forziamo synth.cancel() e non blocchiamo il timer di inattività.
    const activeCeiling = Math.max(
      3500,
      Math.round((this.currentUtteranceExpectedDuration || 1500) * 1.5),
    );

    if (!this.isSpeaking && isHardwareSpeaking) {
      try {
        this.synth.cancel();
      } catch (e) {}
    } else if (this.isSpeaking) {
      // 2. Se l'applicazione sta parlando da oltre il ceiling dinamico per il token attivo,
      // sblocca forzatamente l'audio congelato.
      if (speechDuration > activeCeiling) {
        this.stopAudioOnly();
      } else {
        // Voce realmente in corso: programma un timer di verifica alla scadenza massima
        const remainingTimeToCeiling = Math.max(250, activeCeiling - speechDuration);
        this.stallTimer = setTimeout(() => {
          this.resetStallTimer(forcedDelay);
        }, Math.min(1000, remainingTimeToCeiling));
        return;
      }
    }

    // Regola di cadenza e intervallo di inattività (Release v6.15 / v6.20):
    // - In modalità Spelling o a singoli caratteri: preserva la cadenza rapida standard (1,0s base / 3,0s dopo 3 ripetizioni);
    // - Nelle modalità lessicali/fonemi: applica il ritardo configurato (default 1,5s base / 3,5s esteso),
    //   modulato inversamente dalla velocità vocale tramite il coefficiente configurato.
    const isSingleCharFlow =
      this.forceSpelling ||
      [1, 3, 5, 6].includes(this.mode) ||
      (this.adaptiveMode && this.wordSpellingTokenIdx !== -1);

    let baseDelay = 1000;
    let longDelay = 3000;

    if (isSingleCharFlow) {
      baseDelay = 1000;
      longDelay = 3000;
    } else {
      const effSpeed = Math.max(0.2, this.speed || 0.9);
      const speedMultiplier =
        1 + this.stallSpeedFactor * (Math.max(1.0, 1 / effSpeed) - 1);
      baseDelay = Math.round(this.stallBaseDelay * speedMultiplier);
      longDelay = Math.round(this.stallLongDelay * speedMultiplier);
    }

    const delay =
      forcedDelay !== null
        ? forcedDelay
        : this.stallRepetitionCount >= 3
          ? longDelay
          : baseDelay;

    this.stallTimer = setTimeout(() => {
      this._handleStallTimeout();
    }, delay);
  }

  // Gestore evento di inattività cadenzato con protezione Anti-Ghost-Lock dinamica (Release v6.17 / v6.20)
  _handleStallTimeout() {
    if (!this.enabled || this.tokens.length === 0) return;

    const isHardwareSpeaking = !!(
      this.synth && (this.synth.speaking || this.synth.pending)
    );
    const speechDuration = Date.now() - (this.lastSpeechStartTime || 0);

    const activeCeiling = Math.max(
      3500,
      Math.round((this.currentUtteranceExpectedDuration || 1500) * 1.5),
    );

    if (!this.isSpeaking && isHardwareSpeaking) {
      try {
        this.synth.cancel();
      } catch (e) {}
    } else if (this.isSpeaking) {
      if (speechDuration > activeCeiling) {
        // Ghost-lock rilevato: libera l'audio congelato dal browser
        this.stopAudioOnly();
      } else {
        // Audio ancora legittimamente attivo: riprogramma la verifica
        this.stallTimer = setTimeout(() => {
          this._handleStallTimeout();
        }, 500);
        return;
      }
    }

    let tLen = this.lastTypedLen;
    let mLen = this.lastMatchLen;
    let oText = this.currentText;

    if (this.stateProvider) {
      const live = this.stateProvider();
      if (live) {
        tLen = live.typedLen;
        mLen = live.matchLen;
        oText = live.originText || oText;
        this.lastTypedLen = tLen;
        this.lastMatchLen = mLen;
        this.currentText = oText;
      }
    }

    if (oText && mLen >= oText.length) {
      return;
    }

    // Se l'allievo ha digitato un tasto poco fa, non far scattare il replay di stallo (Release v6.19 / v6.20)
    const isSingleCharFlow =
      this.forceSpelling ||
      [1, 3, 5, 6].includes(this.mode) ||
      (this.adaptiveMode && this.wordSpellingTokenIdx !== -1);

    let currentBaseDelay = 1000;
    if (!isSingleCharFlow) {
      const effSpeed = Math.max(0.2, this.speed || 0.9);
      const speedMultiplier =
        1 + this.stallSpeedFactor * (Math.max(1.0, 1 / effSpeed) - 1);
      currentBaseDelay = Math.round(this.stallBaseDelay * speedMultiplier);
    }

    if (this.lastKeystrokeTime > 0) {
      const timeSinceKeystroke = Date.now() - this.lastKeystrokeTime;
      const guardInterval = isSingleCharFlow
        ? 950
        : Math.max(950, currentBaseDelay - 100);
      if (timeSinceKeystroke < guardInterval) {
        const remaining = Math.max(
          100,
          (isSingleCharFlow ? 1000 : currentBaseDelay) - timeSinceKeystroke,
        );
        this.stallTimer = setTimeout(() => {
          this._handleStallTimeout();
        }, remaining);
        return;
      }
    }

    // Se vi è già un'emissione in lookahead programmata per partire, non lanciare replay di stallo (Release v6.19)
    if (this.pendingLookahead) {
      return;
    }

    // Incrementa contatore ripetizioni consecutive per questa sosta
    this.stallRepetitionCount++;
    this.hasFiredAutoReplay = true;

    this.replay(tLen, mLen, oText, true);
  }

  clearStallTimer() {
    if (this.stallTimer) {
      clearTimeout(this.stallTimer);
      this.stallTimer = null;
    }
  }

  stopAudioOnly() {
    this._clearWatchdog();
    this._clearUtteranceWatchdog();
    this.pendingLookahead = null;
    if (this.synth) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }
    this._retainedUtterances.clear();
    this.isSpeaking = false;
    this.isSpeakingReplay = false;
    this.isRecoveringFromCorrection = false;
    this.isRecoveringTroncone = false;
    this.recoveringTokenIdx = -1;
    this.lastSpeechStartTime = 0;
  }

  stop() {
    this.clearStallTimer();
    this.stopAudioOnly();
    this.tokens = [];
    this.currentIndex = 0;
    this.hasPendingError = false;
    this.hasFiredAutoReplay = false;
    this.stallRepetitionCount = 0;
    this.tokenErrorCount = 0;
    this.recoveryStreak = 0;
    this.lastActiveTokenIdx = -1;
    this.pendingLookahead = null;
    this.isRecoveringTroncone = false;
    this.recoveringTokenIdx = -1;
    this.wordSpellingTokenIdx = -1;
    this.lastSpeechStartTime = 0;
  }
}
