# TenFingersTypingTrainer – Schema IndexedDB INTERROGAZIONE

**Documento:** Schema_IndexedDB_Interrogazione_v1.3  
**Baseline applicativa:** TenFingersTypingTrainer v6.23  
**Contratto di riferimento:** Contratti_Backend_Interrogazione_v1.3  
**Documenti correlati:** Matrice_Tracciabilita_Interrogazione_v1.1; Specifica_PRNG_Interrogazione_v1.0; Motore_Conoscenza_Interrogazione_v1.0; Motore_Selezione_Interrogazione_v1.1; Motore_Sessione_Interrogazione_v1.0; Decisione_Quote_Adattive_D77-D80_v1.1  
**Stato:** schema fisico progettuale, non ancora implementato  
**Destinazione canonica:** `/workspace/Schema_IndexedDB_Interrogazione_v1.3.md`

---

## 1. Scopo e perimetro della revisione

Questa versione mantiene le correzioni strutturali della v1.2 e recepisce la specifica PRNG v1.0 nei campi dello snapshot di selezione:

1. aggiunge la persistenza versionata dei template delle domande principali;
2. aggiunge una proiezione esplicita delle priorità generate dalle consultazioni;
3. completa la proiezione `knowledgeStates` con fattori, calendario e versioni di calcolo;
4. uniforma timestamp, enumerazioni e nomi dei campi;
5. completa lo snapshot di selezione necessario alla riproducibilità;
6. aggiorna indici, vincoli e transazioni interessate.

Restano validi i principi dello schema v1.1: database dedicato, IndexedDB come persistenza del dominio Interrogazione, LocalStorage gestito dal `ProfileManager`, isolamento dei dati per profilo, storico append-only e proiezioni ricostruibili.

**Nessuna modifica ai sorgenti applicativi è inclusa in questo deliverable.**

## 2. Decisioni fisiche canoniche

### 2.1 Database e versione IndexedDB

- Nome database: `TenFingersTypingTrainer_Interrogation`.
- Versione IndexedDB iniziale prevista: `1`.
- La versione del documento (`1.2`) è indipendente dalla versione numerica del database.
- La baseline non contiene ancora questo database: la versione iniziale può quindi includere direttamente tutti gli store qui definiti.
- Se, prima del rilascio, venisse distribuita una build che crea il database secondo uno schema precedente, l'aggiunta degli store richiederà un incremento della versione IndexedDB e una migrazione `onupgradeneeded`. Non è consentito modificare la struttura mantenendo lo stesso numero di versione dopo che una versione precedente è stata distribuita.

### 2.2 Timestamp

Tutti i timestamp persistiti sono numeri interi Unix in millisecondi UTC.

Convenzione unica:
- `createdAt`, `updatedAt`, `occurredAt`, `calculatedAt`, `nextReviewAt`, `publishedAt`, `consumedAt` e campi analoghi: numero intero in millisecondi;
- timestamp non ancora valorizzato: campo omesso se semanticamente non applicabile; `null` solo quando lo schema del record dichiara esplicitamente un valore nullo;
- le stringhe ISO 8601 sono ammesse soltanto nei confini UI/import-export, mai nei record IndexedDB interni.

Non si mescolano secondi Unix, millisecondi Unix e stringhe ISO nello stesso store.

### 2.3 Enumerazioni

I valori persistiti sono codici macchina inglesi, stabili e indipendenti dalla lingua dell'interfaccia. La localizzazione italiana è responsabilità della UI.

Classificazioni canoniche:
- `neverVerified`
- `weak`
- `review`
- `consolidated`
- `insufficientData`

Esiti:
- `correct`
- `incorrect`
- `consulted`

Stati dei sotto-quesiti:
- `pending`
- `answered`
- `consulted`
- `unanswered`

Stati delle priorità:
- `pending`
- `consumed`
- `invalidated`
- `notApplicable`

Le etichette italiane non devono essere memorizzate nei campi enumerati.

### 2.4 Identità, versioni e revisioni

- `semanticId` e `questionSemanticId` identificano concetti didattici stabili.
- `contentVersion` identifica una versione della definizione, non una nuova identità.
- `catalogVersion` identifica una fotografia pubblicata e coerente di elementi, relazioni, definizioni e template.
- `revision` è un intero incrementale per il controllo ottimistico dei record modificabili.
- Eventi, correzioni e audit sono append-only; non hanno `updatedAt` e non vengono modificati dalle normali API.
- Le proiezioni possono essere ricalcolate e sostituite, mantenendo la loro versione di calcolo e la provenienza.

### 2.5 Isolamento per profilo

I record di configurazione, sessione, item, evento, correzione, priorità, stato di conoscenza e ricevuta di profilo contengono `profileId`.

Le chiavi primarie e gli indici di tali store iniziano con `profileId`, salvo gli indici univoci globali `operationId` la cui unicità è garantita da UUID globali generati dall'applicazione.

Il catalogo, i template e l'audit catalografico sono condivisi tra profili.

## 3. Object store definitivi

Lo schema contiene **14 object store**.

| # | Object store | `keyPath` | Ambito | Funzione |
|---:|---|---|---|---|
| 1 | `catalogVersions` | `catalogVersion` | globale | Manifest delle versioni pubblicate |
| 2 | `catalogElements` | `[semanticId, contentVersion]` | globale | Elementi didattici versionati |
| 3 | `catalogRelations` | `relationId` | globale | Relazioni versionate tra elementi |
| 4 | `questionDefinitions` | `[questionSemanticId, contentVersion]` | globale | Sotto-quesiti e regole di risposta versionati |
| 5 | `questionTemplates` | `[templateSemanticId, contentVersion]` | globale | Template delle domande principali |
| 6 | `profileSettings` | `profileId` | profilo | Configurazione Interrogazione |
| 7 | `sessions` | `[profileId, sessionId]` | profilo | Stato e snapshot delle sessioni |
| 8 | `sessionItems` | `[profileId, sessionId, itemId]` | profilo | Domande principali e sotto-quesiti congelati |
| 9 | `exposureEvents` | `[profileId, eventId]` | profilo | Storico immutabile degli esiti |
| 10 | `eventCorrections` | `[profileId, correctionId]` | profilo | Rettifiche append-only degli eventi |
| 11 | `consultationPriorities` | `[profileId, priorityId]` | profilo | Proiezione operativa delle priorità da consultazione |
| 12 | `knowledgeStates` | `[profileId, questionSemanticId]` | profilo | Proiezione corrente della conoscenza |
| 13 | `catalogAudit` | `auditId` | globale | Audit append-only del catalogo |
| 14 | `operationReceipts` | `[scope, operationId]` | misto | Idempotenza e recovery |

Nessuno store usa `autoIncrement`. Gli identificativi sono generati dall'applicazione prima dell'apertura della transazione.

## 4. Indici definitivi

Gli indici sono parte dello schema e devono essere creati con il nome e il `keyPath` esatti indicati. Gli indici univoci sono marcati `yes`.

| Store | Nome indice | `keyPath` | Unique | Finalità |
|---|---|---|---:|---|
| `catalogVersions` | `byCreatedAt` | `createdAt` | no | Cronologia cataloghi |
| `catalogElements` | `byTypeLayoutStatus` | `[type, layoutId, status]` | no | Pool selezionabile |
| `catalogElements` | `byCategoryStatus` | `[categoryId, status]` | no | Disponibilità per categoria |
| `catalogElements` | `bySemanticId` | `semanticId` | no | Versioni di un'identità |
| `catalogElements` | `byRecordId` | `recordId` | yes | Risoluzione ID tecnico |
| `catalogRelations` | `byCatalogFrom` | `[catalogVersion, fromSemanticId]` | no | Relazioni in uscita |
| `catalogRelations` | `byCatalogTo` | `[catalogVersion, toSemanticId]` | no | Relazioni in ingresso |
| `catalogRelations` | `byCatalogType` | `[catalogVersion, relationType]` | no | Relazioni per tipo |
| `questionDefinitions` | `byQuestionSemanticId` | `questionSemanticId` | no | Versioni sotto-quesito |
| `questionDefinitions` | `byElementStatus` | `[elementSemanticId, status]` | no | Definizioni attive di un elemento |
| `questionTemplates` | `byTemplateSemanticId` | `templateSemanticId` | no | Versioni di un template |
| `questionTemplates` | `byCatalogTypeLayoutStatus` | `[catalogVersion, questionType, layoutId, status]` | no | Template applicabili a catalogo/tipologia/layout |
| `profileSettings` | `byUpdatedAt` | `updatedAt` | no | Diagnostica |
| `sessions` | `byProfileStatus` | `[profileId, status]` | no | Sessioni per stato |
| `sessions` | `byProfileCreatedAt` | `[profileId, createdAt]` | no | Storico sessioni |
| `sessions` | `oneSuspendedPerProfile` | `suspendedProfileId` | yes | Massimo una sessione sospesa per profilo |
| `sessionItems` | `bySessionOrder` | `[profileId, sessionId, order]` | yes | Ordine univoco nella sessione |
| `sessionItems` | `byMainElement` | `[profileId, mainElementSemanticId]` | no | Ricerca per elemento principale |
| `exposureEvents` | `byQuestionTime` | `[profileId, questionSemanticId, occurredAt]` | no | Storico per sotto-quesito |
| `exposureEvents` | `bySession` | `[profileId, sessionId]` | no | Eventi della sessione |
| `exposureEvents` | `byOperationId` | `operationId` | yes | Idempotenza evento |
| `exposureEvents` | `byEventSequence` | `[profileId, sessionId, eventSequence]` | yes | Sequenza evento univoca |
| `eventCorrections` | `byEvent` | `[profileId, eventId]` | no | Rettifiche per evento |
| `eventCorrections` | `byOperationId` | `operationId` | yes | Idempotenza correzione |
| `eventCorrections` | `byCreatedAt` | `[profileId, createdAt]` | no | Cronologia rettifiche |
| `consultationPriorities` | `byProfileStatusType` | `[profileId, status, questionType]` | no | Priorità applicabili |
| `consultationPriorities` | `byProfileQuestion` | `[profileId, questionSemanticId]` | no | Priorità per sotto-quesito |
| `consultationPriorities` | `bySourceEvent` | `[profileId, sourceEventId]` | no | Ricostruzione da evento origine |
| `consultationPriorities` | `byConsumedSession` | `[profileId, consumedBySessionId]` | no | Verifica consumo |
| `consultationPriorities` | `bySourceEventType` | `[profileId, sourceEventId, questionType]` | yes | Evita priorità duplicate per evento/tipologia |
| `knowledgeStates` | `byClassification` | `[profileId, classification]` | no | Pool adattivo per classe |
| `knowledgeStates` | `byNextReview` | `[profileId, nextReviewAt]` | no | Elementi da ripassare |
| `catalogAudit` | `byEntityTime` | `[entitySemanticId, createdAt]` | no | Audit per entità |
| `catalogAudit` | `byOperationId` | `operationId` | yes | Idempotenza audit |
| `catalogAudit` | `byCatalogVersion` | `catalogVersion` | no | Audit pubblicazione |
| `operationReceipts` | `byCreatedAt` | `createdAt` | no | Recovery e diagnostica |

### 4.1 Indice della sessione sospesa

` suspendedProfileId` è presente soltanto nei record `sessions` con `status: "suspended"`; negli altri stati il campo è omesso, non impostato a `null`. L'indice univoco ignora i record privi del campo e impedisce due sessioni sospese per lo stesso profilo.

La transizione verso `suspended` imposta `suspendedProfileId = profileId`. Ogni transizione fuori da `suspended` rimuove il campo. La regola è applicata dal repository.

### 4.2 Unicità degli operationId

Gli indici `byOperationId` sono univoci all'interno del rispettivo object store. Il generatore applicativo usa UUID globalmente univoci e non riutilizzati tra profili o domini. `operationReceipts` conserva inoltre la chiave composta `[scope, operationId]` per il recupero del risultato nel dominio corretto.

## 5. Strutture fisiche dei record

Gli esempi definiscono i campi persistenti e le loro semantiche. I valori tra parentesi angolari sono segnaposto descrittivi, non valori letterali.

### 5.1 `catalogVersions`

```js
{
  catalogVersion: "catalog-1",
  schemaRevision: 1,
  layoutIds: ["it-qwerty-105"],
  status: "published", // draft | published | superseded
  createdAt: 1760000000000,
  publishedAt: 1760000000000,
  createdBy: "system-seed",
  contentHash: "...",
  previousCatalogVersion: null,
  notes: ""
}
```

Una versione pubblicata è immutabile. Una modifica genera una nuova versione. Le versioni precedenti restano disponibili finché sono referenziate da sessioni, eventi, correzioni o audit.

### 5.2 `catalogElements`

```js
{
  semanticId: "character.at",
  contentVersion: 1,
  recordId: "rec_<uuid>",
  type: "CARATTERE",
  layoutId: "it-qwerty-105",
  subjectType: "CHARACTER",
  subjectId: "@",
  categoryId: "CARATTERI",
  status: "active", // active | retired
  replacedBySemanticId: null,
  validFromCatalogVersion: "catalog-1",
  createdAt: 1760000000000,
  revision: 1,
  content: {}
}
```

Una variazione editoriale mantiene `semanticId` e incrementa `contentVersion`. Un cambiamento sostanziale di identità didattica crea un nuovo `semanticId`. Gli elementi usati nello storico vengono dismessi, non eliminati.

### 5.3 `catalogRelations`

```js
{
  relationId: "rel_<uuid>",
  catalogVersion: "catalog-1",
  fromSemanticId: "character.at",
  relationType: "producedBy",
  toSemanticId: "key.physical.key_ò",
  attributes: {},
  status: "active",
  createdAt: 1760000000000
}
```

Le relazioni sono riferite a una sola versione catalogo. La pubblicazione di una nuova versione non modifica le relazioni precedenti.

### 5.4 `questionDefinitions`

```js
{
  questionSemanticId: "question.character.at.assigned-finger",
  contentVersion: 1,
  elementSemanticId: "character.at",
  aspectId: "assignedFinger",
  answerType: "FINGER_ID",
  answerDefinition: { acceptedFingerIds: [6] },
  presentationType: "keyboard-and-hands",
  evaluationPolicy: "exact-match",
  status: "active",
  catalogVersion: "catalog-1",
  createdAt: 1760000000000,
  revision: 1
}
```

Una variazione di sola formulazione non cambia `questionSemanticId`. Un aspetto autonomo nuovo richiede una nuova identità. Le versioni precedenti restano disponibili per gli snapshot storici.

### 5.5 `questionTemplates` — nuovo store

```js
{
  templateSemanticId: "template.home-row.full-hand",
  contentVersion: 1,
  catalogVersion: "catalog-1",
  questionType: "HOME_ROW",
  layoutId: "it-qwerty-105",
  status: "active", // active | retired
  mainElementSemanticId: "home-row.left",
  compositionRule: "all-active-fingers-for-hand",
  components: [
    {
      questionSemanticId: "question.home-row.left.index-finger",
      required: true,
      order: 0
    }
  ],
  candidatePolicyVersion: "candidate-composition-1",
  createdAt: 1760000000000,
  revision: 1
}
```

Responsabilità:
- rappresentare le domande principali come composizioni versionate;
- dichiarare in modo esplicito i sotto-quesiti richiesti e il loro ordine;
- vincolare il template a `catalogVersion`, tipologia e layout;
- non contenere punteggi o stato di conoscenza, che appartengono al profilo.

Non si introduce uno store persistente per i candidate temporanei. `getAvailableCandidates()` materializza candidate in modo puro e deterministico usando template, elementi attivi, definizioni attive e relazioni della medesima versione catalogo.

`candidateId` è una chiave deterministica derivata dalla combinazione canonica di `templateSemanticId`, `contentVersion`, `catalogVersion` e identità/versioni dei componenti. Non è generato casualmente. Il candidate selezionato viene congelato in `sessionItems`.

Il catalogo attuale contiene cinque template documentati. Questo store li rende persistibili, ma non certifica la completezza del catalogo QWERTY a 105 tasti.

### 5.6 `profileSettings`

```js
{
  profileId: "profile-123",
  revision: 1,
  sessionQuestionCount: 10,
  defaultMode: "adaptive",
  defaultQuestionType: "mixed",
  categoryQuotas: {},
  reviewIntervalsDays: [1, 3, 7, 14, 30, 60],
  reviewPolicyVersion: "review-calendar-1",
  updatedAt: 1760000000000
}
```

La configurazione viene copiata nella sessione all'avvio. Modifiche successive non alterano sessioni già create o sospese.

### 5.7 `sessions`

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  status: "in-progress", // in-progress | suspended | abandoned | completed
  mode: "adaptive",
  questionType: "mixed",
  requestedQuestionCount: 10,
  effectiveQuestionCount: 10,
  configSnapshot: {},
  selectionSnapshot: {
    selectionAlgorithmVersion: "selection-1",
    adaptiveQuotaAlgorithmVersion: "adaptive-quota-1.1",
    prngAlgorithmId: "xoshiro128**",
    prngAlgorithmVersion: "1.0",
    seed: "000102030405060708090a0b0c0d0e0f",
    seedEncoding: "hex-128be",
    seedSource: "crypto.getRandomValues",
    seedSecurity: "cryptographic",
    canonicalOrderingVersion: "utf16-code-unit-v1",
    prngStateAfterSelection: [66051, 67438087, 134810123, 202182159],
    prngDrawCount: 0,
    prngRejectionCount: 0,
    catalogVersion: "catalog-1",
    knowledgeSnapshotAt: 1760000000000,
    knowledgeSnapshotFingerprint: "<hash canonico>",
    candidatePoolFingerprint: "<hash canonico>",
    canonicalCandidateOrder: [],
    configuredCategoryQuotas: {},
    normalizedCategoryQuotas: {},
    adaptiveBudgetPercentagePoints: 10,
    perCategorySupplementCapRatio: 0.20,
    categoryReliabilityAndDeficits: {},
    stratumCounts: {},
    selectedCandidateIds: [],
    appliedPriorityIds: [],
    pendingPriorityIds: [],
    warnings: []
  },
  catalogVersion: "catalog-1",
  currentItemIndex: 0,
  score: 0,
  revision: 1,
  createdAt: 1760000000000,
  updatedAt: 1760000000000,
  completedAt: null
}
```

I campi PRNG sono normati da `Specifica_PRNG_Interrogazione_v1.0.md`. `seed` è una stringa esadecimale di 32 caratteri minuscoli con encoding `hex-128be`; `prngStateAfterSelection` contiene quattro interi unsigned a 32 bit; i contatori sono interi non negativi. `seedSource` e `seedSecurity` documentano la sorgente del seed e non la natura crittografica del PRNG.

Lo snapshot conserva dati sufficienti a riprodurre e verificare la selezione. La ripresa di una sessione sospesa usa sempre `sessionItems` già salvati e non richiama il selettore.

Per la sessione sospesa è presente `suspendedProfileId = profileId`; negli altri stati il campo è omesso.

### 5.8 `sessionItems`

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  order: 0,
  candidateId: "<candidate deterministico>",
  templateSemanticId: "template.home-row.full-hand",
  templateContentVersion: 1,
  mainElementSemanticId: "home-row.left",
  promptSnapshot: {},
  subQuestions: [
    {
      questionSemanticId: "question.home-row.left.index-finger",
      elementSemanticId: "home-row.left.index-finger",
      definitionVersion: 1,
      definitionSnapshot: {},
      status: "pending",
      outcome: null,
      score: 0,
      evaluatedAt: null,
      exposureEventId: null
    }
  ],
  revision: 1
}
```

Lo snapshot conserva il template e le definizioni effettivamente usati. Lo stato operativo dei sotto-quesiti può avanzare con aggiornamenti atomici; gli eventi di esposizione restano la fonte storica immutabile.

### 5.9 `exposureEvents`

```js
{
  profileId: "profile-123",
  eventId: "event_<uuid>",
  operationId: "<uuid globale>",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  questionSemanticId: "question.character.at.assigned-finger",
  elementSemanticId: "character.at",
  outcome: "correct", // correct | incorrect | consulted
  score: 3,
  occurredAt: 1760000000000,
  eventSequence: 1,
  catalogVersion: "catalog-1",
  definitionVersion: 1
}
```

Punteggi: corretta +3, consultata +1, errata 0. Visualizzazione e non risposta non producono eventi. L'evento è append-only.

### 5.10 `eventCorrections`

```js
{
  profileId: "profile-123",
  correctionId: "correction_<uuid>",
  operationId: "<uuid globale>",
  eventId: "event_<uuid>",
  correctionType: "invalidate-event", // invalidate-event | reinstate-event | annotate
  reason: "Motivazione esplicita",
  reversesCorrectionId: null,
  createdAt: 1760000000000,
  catalogVersion: "catalog-1"
}
```

Le correzioni sono append-only. L'annullamento è una nuova correzione collegata tramite `reversesCorrectionId`; nessun record precedente viene sovrascritto.

### 5.11 `consultationPriorities` — nuovo store

```js
{
  profileId: "profile-123",
  priorityId: "priority_<uuid>",
  sourceEventId: "event_<uuid>",
  sourceSessionId: "session_<uuid>",
  questionSemanticId: "question.character.at.assigned-finger",
  candidateId: "<candidate deterministico>",
  questionType: "TASTO",
  catalogVersion: "catalog-1",
  status: "pending", // pending | consumed | invalidated | notApplicable
  createdAt: 1760000000000,
  consumedBySessionId: null,
  consumedAt: null,
  invalidatedByCorrectionId: null,
  invalidationReason: null,
  revision: 1,
  updatedAt: 1760000000000
}
```

È una proiezione operativa ricostruibile, non la fonte storica. La fonte è l'evento `consulted` e la sequenza delle sue correzioni.

Regole:
- una consultazione valida crea una priorità per il candidate che contiene il sotto-quesito consultato;
- la priorità è associata alla tipologia della sessione sorgente;
- soltanto una sessione successiva `adaptive` della stessa tipologia può consumarla;
- il consumo avviene soltanto quando il candidate entra effettivamente nella sessione creata;
- priorità non selezionate, sessioni annullate prima della creazione e sessioni di altra modalità/tipologia non la consumano;
- se il candidate non è più attivo o compatibile, la priorità diventa `notApplicable` con motivazione; non viene trasferita a un'identità sostitutiva;
- se una correzione invalida esplicitamente l'evento sorgente, la priorità diventa `invalidated`; se era già stata consumata, `consumedBySessionId` e `consumedAt` restano valorizzati per conservare la traccia del consumo;
- la stessa operazione non può creare due priorità per la stessa coppia evento/tipologia.

`consumedBySessionId`, `consumedAt`, `invalidatedByCorrectionId` e `invalidationReason` sono valorizzati solo per gli stati pertinenti; gli altri campi sono omessi o null secondo il contratto uniforme del record. Per evitare ambiguità, la serializzazione implementativa deve scegliere una sola convenzione e applicarla a tutti i record.

### 5.12 `knowledgeStates` — proiezione completata

```js
{
  profileId: "profile-123",
  questionSemanticId: "question.character.at.assigned-finger",

  firstExposureAt: 1760000000000,
  lastExposureAt: 1760000000000,
  effectiveExposureCount: 4,
  equivalentExposures: 2.75,

  weaknessFactors: {
    errors: 50,
    consultations: 12.5,
    delays: 20,
    consolidation: null
  },
  consolidationPolicyVersion: null,
  consolidationCalculatedAt: null,

  rawWeaknessIndex: 32.5,
  reliability: 0.3548,
  correctedWeaknessIndex: 43.79,
  classification: "review",

  reviewLevel: 2,
  reviewIntervalDays: 7,
  nextReviewAt: 1760604800000,
  reviewPolicyVersion: "review-calendar-1",

  calculationPolicyVersion: "knowledge-1",
  projectionVersion: 1,
  sourceEventCount: 4,
  sourceCorrectionCount: 0,
  sourceFingerprint: "<hash canonico eventi+correzioni effettivi>",
  calculatedAt: 1760000000000,
  revision: 1
}
```

Semantica dei campi:
- `effectiveExposureCount`: numero cumulativo degli eventi effettivi validi, senza decadimento;
- `equivalentExposures`: somma dei pesi temporali degli eventi effettivi validi;
- `weaknessFactors.errors`: fattore errori 0–100 o `null` se non disponibile;
- `weaknessFactors.consultations`: fattore consultazioni 0–100 o `null`;
- `weaknessFactors.delays`: fattore ritardi 0–100 o `null`;
- `weaknessFactors.consolidation`: fattore mancato consolidamento 0–100 o `null`;
- `weaknessFactors.consolidation`: valore derivato dall'output `consolidationWeakness` del pianificatore; è il solo valore numerico persistito per questo fattore;
- `rawWeaknessIndex`: indice grezzo dopo rinormalizzazione dei soli fattori disponibili;
- `reliability`: affidabilità individuale tra 0 e 1;
- `correctedWeaknessIndex`: indice corretto verso il neutro 50; è il nome canonico persistito;
- `classification`: una delle cinque classificazioni canoniche;
- `reviewLevel`: intero 0–5 per elementi con calendario inizializzato; altrimenti omesso;
- `reviewIntervalDays`: intervallo applicato all'ultimo esito valutato; altrimenti omesso;
- `nextReviewAt`: data pianificata in millisecondi UTC oppure `null` se non pianificata;
- `reviewPolicyVersion`: versione degli intervalli/policy usata per pianificare;
- `calculationPolicyVersion`: versione delle formule di conoscenza;
- `projectionVersion`: versione del formato della proiezione;
- `sourceEventCount` e `sourceCorrectionCount`: conteggi delle fonti considerate;
- `sourceFingerprint`: hash deterministico delle fonti e delle versioni di policy considerate;
- `calculatedAt`: tempo di riferimento congelato del ricalcolo.

Per gli elementi `neverVerified`:
- `effectiveExposureCount` è 0;
- `equivalentExposures` è 0;
- `firstExposureAt` e `lastExposureAt` sono omessi;
- fattori, `rawWeaknessIndex` e `correctedWeaknessIndex` sono `null`;
- `reliability` è 0;
- `classification` è `neverVerified`.

Per gli elementi verificati ma privi di tutti i fattori utilizzabili, `classification` è `insufficientData`; non si assegna una classe artificiale.

La formula canonica del campo persistito è:

`correctedWeaknessIndex = 50 + reliability × (rawWeaknessIndex - 50)`

I valori sono memorizzati con precisione numerica sufficiente; l'arrotondamento è solo di presentazione. Il decadimento a emivita 60 giorni si applica ai calcoli, non allo storico né ai conteggi cumulativi.

### 5.13 `catalogAudit`

```js
{
  auditId: "audit_<uuid>",
  operationId: "<uuid globale>",
  entitySemanticId: "character.at",
  operationType: "relation-updated",
  previousValue: {},
  newValue: {},
  reason: "Motivazione esplicita",
  createdAt: 1760000000000,
  catalogVersion: "catalog-2",
  reversesAuditId: null
}
```

Audit append-only per creazioni, modifiche, dismissioni, riattivazioni, sostituzioni, pubblicazioni e rettifiche.

### 5.14 `operationReceipts`

```js
{
  scope: "profile:profile-123",
  operationId: "<uuid globale>",
  operationType: "record-outcome",
  payloadHash: "<hash canonico>",
  result: {},
  createdAt: 1760000000000
}
```

Stesso `operationId` e stesso `payloadHash`: restituire il risultato precedente. Stesso `operationId` e payload diverso: conflitto di idempotenza. La ricevuta è scritta nella stessa transazione dell'operazione applicativa.

## 6. Materializzazione dei candidate

Non viene introdotto un object store `candidates`.

`InterrogationCatalog.getAvailableCandidates()` deve:
1. ricevere `catalogVersion`, tipologia e layout;
2. leggere i template attivi della versione;
3. risolvere ogni componente contro `questionDefinitions` ed elementi attivi della stessa versione;
4. verificare che ogni componente richiesto sia risolvibile e abbia una definizione di risposta valida;
5. costruire una rappresentazione canonica ordinata;
6. calcolare `candidateId` deterministico dalla rappresentazione canonica e dalle versioni;
7. restituire candidate immutabili in memoria.

La selezione non persiste il pool completo. La sessione persiste i candidate selezionati, il template, le definizioni e i sotto-quesiti congelati in `sessionItems`.

Un candidate non risolvibile è escluso con diagnostica. Nella selezione manuale è errore bloccante e non viene sostituito silenziosamente.

## 7. Snapshot PRNG e selezione

La specifica PRNG normativa è `Specifica_PRNG_Interrogazione_v1.0.md`:

- algoritmo `xoshiro128**`, versione `1.0`;
- seed `hex-128be`, 128 bit, 32 caratteri esadecimali;
- generazione iniziale preferita con `crypto.getRandomValues`;
- fallback `Math.random` ammesso soltanto con diagnostica e marcatura non crittografica;
- bounded integer con rejection sampling;
- ordinamento `utf16-code-unit-v1`;
- Fisher–Yates discendente.

Lo snapshot conserva il seed, la sorgente del seed, la versione dell'ordinamento, lo stato PRNG dopo la selezione, i contatori di estrazione/rifiuto, il fingerprint del pool e l'intero ordine canonico. La riproduzione parte dal seed e dagli input/versioni congelati; lo stato finale consente la verifica diagnostica. La ripresa non genera nuova casualità.

Il fingerprint non sostituisce `canonicalCandidateOrder` e non è una prova crittografica. L'ordine canonico persistito è la rappresentazione necessaria per ricostruire il pool di candidate usato.

Per le quote adattive si persistono:
- budget globale: 10 punti percentuali;
- tetto individuale: 20% della quota base normalizzata;
- quote configurate e normalizzate;
- deficit/affidabilità usati;
- conteggi per categoria e strato;
- quota neutra residua e risultato del metodo dei maggiori resti.

## 8. Vincoli d'integrità applicativi

IndexedDB non offre foreign key. Il repository verifica i vincoli nella stessa transazione che modifica i record:

1. ogni `sessionItem` appartiene a una sessione dello stesso profilo;
2. ogni evento riferisce sessione, item e sotto-quesito dello stesso profilo;
3. ogni sotto-quesito è valutato una sola volta nella sessione, salvo rettifica append-only;
4. `eventSequence` è univoco e progressivo per sessione;
5. ogni correzione riferisce un evento dello stesso profilo;
6. ogni annullamento riferisce una correzione esistente dello stesso evento e profilo;
7. ogni priorità riferisce un evento `consulted` valido e un candidate compatibile;
8. una priorità può essere consumata una sola volta;
9. priorità e sessione consumatrice devono avere modalità `adaptive` e identica `questionType`;
10. template, definizioni, elementi e relazioni devono appartenere alla stessa `catalogVersion`;
11. ogni componente obbligatorio di un template deve risolversi in una definizione attiva;
12. nuove sessioni usano soltanto catalogo, template, elementi e definizioni attivi;
13. sessioni sospese conservano snapshot precedenti anche dopo sostituzioni catalografiche;
14. elementi con riferimenti storici non sono eliminabili fisicamente;
15. stesso `operationId` con payload diverso è conflitto;
16. ogni modifica a un record revisionato verifica `revision` attesa e la incrementa;
17. tutte le scritture di una singola operazione logica avvengono nella stessa transazione IndexedDB.

## 9. Matrice delle transazioni aggiornata

| Operazione | Store in transazione `readwrite` | Regole atomiche |
|---|---|---|
| `publishCatalog` | `catalogVersions`, `catalogElements`, `catalogRelations`, `questionDefinitions`, `questionTemplates`, `catalogAudit`, `operationReceipts` | Pubblicazione solo dopo validazione di tutte le entità e dei template |
| `createSession` | `sessions`, `sessionItems`, `consultationPriorities`, `operationReceipts` | Snapshot completo e consumo priorità soltanto per candidate effettivamente inclusi |
| `recordOutcome` | `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `operationReceipts` | Evento, stato item, punteggio, proiezione e receipt atomici |
| `consultSubQuestion` | `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `consultationPriorities`, `operationReceipts` | Consultazione, priorità e proiezione atomiche |
| `closeMainQuestion` | `sessions`, `sessionItems`, `operationReceipts` | Residui `unanswered`, senza eventi knowledge |
| `suspendSession` | `sessions`, `operationReceipts` | Impostazione atomica di `suspendedProfileId` |
| `resumeSession` | `sessions`, `operationReceipts` | Rimozione del campo e controllo revisione |
| `abandonSession` | `sessions`, `operationReceipts` | Conservazione degli eventi già registrati |
| `completeSession` | `sessions`, `operationReceipts` | Completamento solo dopo conferma |
| `applyCorrection` | `eventCorrections`, `knowledgeStates`, `consultationPriorities`, `operationReceipts` | Rettifica append-only e ricalcolo delle proiezioni coinvolte |
| `rebuildKnowledge` | `exposureEvents`, `eventCorrections`, `knowledgeStates`, `operationReceipts` | Proiezione sostituita solo se il fingerprint delle fonti è coerente |
| `rebuildPriorities` | `exposureEvents`, `eventCorrections`, `consultationPriorities`, `operationReceipts` | Ricostruzione idempotente da eventi e correzioni |

Le transazioni di lettura possono includere gli store sorgente necessari. Non si apre una transazione IndexedDB e la si mantiene in attesa di input utente, timer o operazioni asincrone esterne.

### 9.1 Creazione sessione e consumo priorità

La selezione viene calcolata prima della transazione finale usando snapshot coerenti. Nella transazione:
1. si ricontrollano revisioni/configurazione e stato delle priorità applicate;
2. si verifica che i candidate selezionati siano quelli contenuti nello snapshot;
3. si inseriscono sessione e item;
4. si marcano `consumed` soltanto le priorità i cui candidate sono effettivamente inclusi;
5. si scrive la receipt;
6. si completa la transazione.

Se la transazione fallisce, nessuna priorità risulta consumata. Le priorità non selezionate restano `pending`.

### 9.2 Consultazione e priorità

La consultazione è una singola operazione logica: evento `consulted`, punteggio +1, aggiornamento item/sessione, proiezione conoscenza, creazione priorità e receipt. Un errore annulla l'intera transazione.

### 9.3 Correzione di una consultazione

Se una correzione invalida l'evento sorgente:
- la correzione viene aggiunta allo storico;
- la proiezione conoscenza viene ricalcolata;
- la priorità collegata passa a `invalidated`;
- l'eventuale stato `consumed` non viene cancellato: viene conservata la storia del consumo e la rettifica viene registrata tramite campi aggiuntivi append-only/proiezione derivata.

La proiezione `consultationPriorities` non può sovrascrivere la storia dell'evento o delle correzioni. In caso di invalidazione dopo il consumo, `status` passa a `invalidated`, ma i campi di consumo già valorizzati non vengono azzerati: descrivono un fatto storico e restano disponibili alla diagnostica.

## 10. Concorrenza, idempotenza e recovery

### 10.1 Concorrenza ottimistica

Ogni record modificabile contiene `revision`. Le operazioni ricevono `expectedRevision`; una differenza produce `REVISION_CONFLICT` senza scritture parziali.

La concorrenza è verificata per singola entità. Modifiche a entità diverse possono procedere indipendentemente, salvo vincoli condivisi come una sessione sospesa per profilo o consumo della stessa priorità.

### 10.2 Idempotenza

Ogni comando persistente porta `operationId` e `payloadHash` canonico:
- ID e payload uguali: restituzione del risultato precedente;
- ID uguale e payload differente: `IDEMPOTENCY_CONFLICT`;
- ID nuovo: nuova operazione.

La receipt è parte della stessa transazione.

### 10.3 Recovery delle proiezioni

`knowledgeStates` e `consultationPriorities` sono ricostruibili:
- eventi e correzioni sono fonti append-only;
- la ricostruzione usa un `calculatedAt` congelato;
- il risultato è sostituito solo se il fingerprint delle fonti e le versioni di policy corrispondono;
- il fallimento lascia disponibile la proiezione precedente e non modifica lo storico;
- le priorità già consumate non vengono riaperte automaticamente da una ricostruzione; la storia di consumo deve essere preservata.

### 10.4 LocalStorage e IndexedDB

Non esiste una transazione distribuita tra i due storage. L'integrazione con `ProfileManager` resta una procedura recuperabile a fasi, con marker persistente, verifica del completamento e possibilità di ripresa/rollback. La cancellazione di un profilo deve isolare i dati Interrogazione e non cancellare catalogo condiviso o audit catalografico.

## 11. Migrazioni e compatibilità

Poiché il database Interrogazione non è ancora implementato nella baseline, la prima release può creare direttamente i 14 store e gli indici di questa versione con `indexedDB.open(name, 1)`.

Se una build intermedia ha già creato un database con lo schema v1.1:
- incrementare la versione IndexedDB a `2`;
- creare `questionTemplates` e `consultationPriorities`;
- creare i rispettivi indici;
- non alterare gli store esistenti se non per aggiunte compatibili;
- normalizzare eventuali record già scritti solo tramite una migrazione esplicita e verificabile;
- convertire timestamp ISO in millisecondi UTC soltanto se esistono dati reali e il formato sorgente è determinabile senza ambiguità;
- migrare `adjustedWeaknessIndex` a `correctedWeaknessIndex` senza perdere il valore originario durante la fase di migrazione;
- convertire le etichette di classificazione italiane in codici canonici soltanto tramite mapping completo e testato;
- se il dato è ambiguo, bloccare la migrazione e produrre diagnostica, senza indovinare.

Ogni migrazione:
1. è atomica nel contesto `versionchange`;
2. non cancella eventi, correzioni o audit;
3. è idempotente rispetto alla versione database;
4. verifica store, indici e record campione;
5. registra versione precedente e nuova in un manifest tecnico di migrazione;
6. non dichiara successo se una conversione obbligatoria non è completata.

## 12. Test di accettazione dello schema

I seguenti test sono requisiti da implementare; non sono dichiarati superati in assenza del repository e del test runner effettivi.

| ID | Verifica | Esito richiesto |
|---|---|---|
| IDB-01 | Apertura database vuoto | Tutti i 14 store presenti |
| IDB-02 | Indici catalogo | Nomi, keyPath e unicità conformi |
| IDB-03 | Indici profilo | Query sempre limitabili per `profileId` |
| IDB-04 | Template versionati | Più versioni dello stesso template conservabili |
| IDB-05 | Candidate deterministico | Stesso template/versioni produce stesso `candidateId` |
| IDB-06 | Template incompleto | Candidate escluso con diagnostica |
| IDB-07 | Snapshot sessione | Template e definizioni selezionate congelati in `sessionItems` |
| IDB-08 | Timestamp | Scrittura di stringhe ISO rifiutata dal validatore dominio |
| IDB-09 | Enum | Codici non canonici rifiutati |
| IDB-10 | Knowledge neverVerified | Campi numerici e null coerenti con la regola |
| IDB-11 | Knowledge insufficientData | Nessuna classificazione artificiale |
| IDB-12 | Formula correctedWeaknessIndex | Formula, limiti e precisione verificati |
| IDB-13 | Review calendar | Livello, intervallo e policy version persistiti |
| IDB-14 | Priorità consultazione | Evento valido genera una sola priorità |
| IDB-15 | Priorità per tipologia | Sessione di altra tipologia non consuma |
| IDB-16 | Priorità per modalità | Random/manual non consumano priorità |
| IDB-17 | Consumo priorità | Solo candidate effettivamente inclusi consumano |
| IDB-18 | Priorità non selezionata | Resta pending |
| IDB-19 | Correzione evento consultato | Priorità invalidata senza cancellare la storia |
| IDB-20 | Ricostruzione priorità | Idempotente e senza riaprire priorità consumate |
| IDB-21 | recordOutcome | Evento, item, sessione, knowledge e receipt atomici |
| IDB-22 | consultSubQuestion | Evento, priorità, knowledge e receipt atomici |
| IDB-23 | Rollback | Errore intermedio non lascia scritture parziali |
| IDB-24 | Idempotenza | Stesso ID/payload non duplica |
| IDB-25 | Conflitto idempotenza | Stesso ID/payload differente rifiutato |
| IDB-26 | Concorrenza | Revision mismatch blocca solo l'entità interessata |
| IDB-27 | Sessione sospesa | Indice impedisce seconda sessione sospesa per profilo |
| IDB-28 | Isolamento profili | Nessuna lettura o scrittura incrociata |
| IDB-29 | Audit | Normali API non aggiornano né eliminano audit |
| IDB-30 | Storico esposizioni | Correzioni non cancellano gli eventi originali |
| IDB-31 | Migrazione | Upgrade v1→v2 preserva dati e crea nuovi store |
| IDB-32 | Quota storage | Errore quota gestito senza dichiarare commit |
| IDB-33 | Chiusura scheda/crash | Operazioni non committate non risultano applicate |
| IDB-34 | Sessione sospesa + cambio catalogo | Snapshot ripreso invariato |
| IDB-35 | Eliminazione profilo | Dati di profilo rimossi secondo policy; catalogo condiviso preservato |

## 13. Questioni ancora aperte e non coperte da questo schema

Lo schema non risolve decisioni che appartengono ai motori o al catalogo:

1. policy definitiva del calendario: la specifica del motore la indica come formalizzazione tecnica da confrontare con il comportamento preesistente;
2. rapporto composito consultazione/errore: restano validi i parametri espliciti e la criticità matematica documentata; nessuna correzione implicita;
4. catalogo completo QWERTY a 105 tasti: lo store consente di versionarlo, ma non inventa gli elementi mancanti;
5. verifica delle associazioni discordanti dei tre modificatori destri;
6. definizione esecutiva di `consolidationWeakness` da parte del pianificatore;
7. coordinamento completo con cancellazione/import/export profilo e `ProfileManager`.

Questi punti restano gate espliciti prima della dichiarazione di completezza produttiva.

## 14. Esito

Lo schema v1.3 mantiene i disallineamenti strutturali chiusi dalla v1.2 e recepisce la decisione PRNG:

- template delle domande principali persistiti e versionati;
- priorità consultazione modellate come proiezione ricostruibile e tipizzata;
- `knowledgeStates` completo per fattori, affidabilità, classificazione, calendario e versioni;
- timestamp, enum e nome dell'indice corretto uniformati.

Aggiunge i campi PRNG canonici allo snapshot senza introdurre nuovi object store o indici. La modifica riguarda il contenuto del record `sessions.selectionSnapshot`; la versione fisica IndexedDB resta da determinare in base alla prima versione effettivamente distribuita.

**Stato:** progettazione fisica allineata; implementazione non avviata.  
**Modifiche ai sorgenti:** nessuna.


## Revisione v1.3 — PRNG

La v1.3 aggiunge `seedSource`, `seedSecurity`, `canonicalOrderingVersion`, `prngStateAfterSelection`, `prngDrawCount` e `prngRejectionCount`, e congela gli identificativi dell'algoritmo e del seed. Non aggiunge store o indici. Nessuna migrazione è necessaria nella baseline v6.23 perché il database Interrogazione non esiste ancora; eventuali build intermedie dovranno essere verificate prima di stabilire la versione IndexedDB da incrementare.
