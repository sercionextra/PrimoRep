# Architettura TenFingersTypingTrainer v6.58

Documento di aggiornamento architetturale rispetto alla v6.57.

## 1. Obiettivo della Release v6.58
1. Aggiornare il messaggio di conferma al salvataggio in modalità `Typing (Libera)` con il richiamo alla scorciatoia `CTRL+SHIFT+X`.
2. Introdurre un promemoria Toast non bloccante per il backup periodico dei dati al completamento degli esercizi e delle sessioni di Interrogazione, regolato da un intervallo minimo configurabile.
3. Evidenziare con massima priorità in `help.html` e `MANUALE_UTENTE_v6.58.md` le indicazioni su Backup/Portabilità JSON, zoom browser (`CTRL + Rotella del mouse`), layout tastiera (`ALT + SHIFT`) e ripristino focus.

## 2. Interventi Architetturali
1. **Configurazione intervallo promemoria (`js/app/controller/controller-core.js`):**
   - Aggiunti `this.backupReminderIntervalMs = 10 * 60 * 1000` (10 minuti configurabili) e `this._lastBackupReminderAt = 0` nel costruttore di `AppController`.
2. **Estensione Toast e Throttling (`js/app/controller/metodi-finestre-layout.js`):**
   - Esteso `showNotificationToast(message, icon = "ℹ", durationMs = 2500)` con durata configurabile e `max-width: min(520px, calc(100vw - 48px))` mantenendo `pointer-events: none`.
   - Aggiunto `maybeShowBackupReminderToast(nowMs = Date.now())`: mostra immediatamente al primo completamento della sessione (`_lastBackupReminderAt === 0`) e poi solo al superamento di `backupReminderIntervalMs`, con durata `5000 ms`.
3. **Punti di invocazione (`metodi-input-digitazione.js`, `metodi-toolbar-modalita.js`, `metodi-interrogazione.js`):**
   - Invocato `maybeShowBackupReminderToast()` su `res.status === "completed"`, su click `#btnAddStatistic` in Digitazione Libera e in `onSessionComplete` dell'Interrogazione.
   - Aggiornato `showAppAlert` su `#btnAddStatistic` con `"Sessione di digitazione libera registrata con successo!\n\nPremere CTRL+SHIFT+X per avviare un nuovo esercizio."`.
