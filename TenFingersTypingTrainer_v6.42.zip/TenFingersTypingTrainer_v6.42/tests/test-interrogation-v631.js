/* Test unitari e di integrazione v6.31: toggle selezione manuale, statistiche sessione, storico e ripeti interrogazione. */
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

function loadScript(ctx, relPath) {
  const full = path.join(__dirname, "..", relPath);
  const code = fs.readFileSync(full, "utf8");
  vm.runInContext(code, ctx, { filename: full });
}

async function runTests() {
  const ctx = vm.createContext({
    console,
    Date,
    Math,
    Set,
    Map,
    Array,
    Object,
    String,
    Number,
    JSON,
    Promise,
    Error,
    parseInt,
    parseFloat,
    isNaN,
    TextEncoder,
    TextDecoder,
    Uint8Array,
    crypto: require("crypto").webcrypto,
  });
  ctx.window = ctx;
  ctx.globalThis = ctx;

  loadScript(ctx, "js/data/interrogation-catalog-data.js");
  loadScript(ctx, "js/interrogation/interrogation-prng.js");
  loadScript(ctx, "js/interrogation/interrogation-layout-metadata.js");
  loadScript(ctx, "js/interrogation/interrogation-catalog.js");
  loadScript(ctx, "js/interrogation/interrogation-knowledge.js");
  loadScript(ctx, "js/interrogation/interrogation-selector.js");
  loadScript(ctx, "js/interrogation/interrogation-repository.js");
  loadScript(ctx, "js/interrogation/interrogation-session-manager.js");

  const catalog = new ctx.InterrogationCatalog();
  const repository = new ctx.InterrogationRepository({ forceMemory: true });
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository });

  // 1. Crea sessione con 2 domande CARATTERE (maxScore atteso = 36, totalBlocks = 12)
  const created = await mgr.createSession({
    profileId: "u1",
    mode: "random",
    questionTypes: ["CARATTERE"],
    requestedCount: 2,
    seed: "0123456789abcdef0123456789abcdef",
  });
  assert.strictEqual(created.session.maxScore, 36, "maxScore iniziale per 2 CARATTERE deve essere 36");

  // Valuta 3 blocchi sulla domanda 0 (1 correct, 1 incorrect, 1 consulted -> 3 ignorati)
  const item0 = created.items[0];
  const item1 = created.items[1];
  await mgr.recordBlockEvaluation({ profileId: "u1", sessionId: created.session.sessionId, itemId: item0.itemId, blockId: "accord", outcome: "correct" });
  await mgr.recordBlockEvaluation({ profileId: "u1", sessionId: created.session.sessionId, itemId: item0.itemId, blockId: "keyChars", outcome: "incorrect" });
  await mgr.recordBlockEvaluation({ profileId: "u1", sessionId: created.session.sessionId, itemId: item0.itemId, blockId: "neighbors_top", outcome: "consulted" });

  // Sulla domanda 1 lascia tutti i 6 blocchi ignorati
  const completed = await mgr.completeSession("u1", created.session.sessionId);
  assert.strictEqual(completed.session.score, 4, "Punteggio atteso: 3 + 1 = 4");
  assert.strictEqual(completed.session.maxScore, 36, "maxScore completato deve essere 36");
  assert.strictEqual(completed.session.totalBlocks, 12, "totalBlocks per 2 CARATTERE deve essere 12");
  assert.strictEqual(completed.session.correctCount, 1);
  assert.strictEqual(completed.session.incorrectCount, 1);
  assert.strictEqual(completed.session.consultedCount, 1);
  assert.strictEqual(completed.session.ignoredCount, 9);

  // 2. Verifica getSessionItemsForRepeat
  const allRep = await mgr.getSessionItemsForRepeat("u1", created.session.sessionId, ["all"]);
  assert.strictEqual(allRep.length, 2);
  const errOnly = await mgr.getSessionItemsForRepeat("u1", created.session.sessionId, ["incorrect"]);
  assert.strictEqual(errOnly.length, 1);
  assert.strictEqual(errOnly[0].itemId, item0.itemId);
  const ignOnly = await mgr.getSessionItemsForRepeat("u1", created.session.sessionId, ["ignored"]);
  assert.strictEqual(ignOnly.length, 2, "Entrambe le domande hanno almeno un blocco ignorato");

  // 3. Fallback ricostruzione statistiche su sessioni pre-v6.31
  const legacySess = await mgr.createSession({
    profileId: "u1",
    mode: "random",
    questionTypes: ["DITO"],
    requestedCount: 1,
  });
  await mgr.recordBlockEvaluation({
    profileId: "u1",
    sessionId: legacySess.session.sessionId,
    itemId: legacySess.items[0].itemId,
    blockId: "fingerKeys",
    outcome: "correct",
  });
  const legComp = await mgr.completeSession("u1", legacySess.session.sessionId);
  // Simula record legacy rimuovendo i nuovi contatori
  delete legComp.session.correctCount;
  delete legComp.session.totalBlocks;
  await repository._mem.put("sessions", legComp.session);

  const histList = await mgr.getCompletedSessionsWithStats("u1");
  assert.strictEqual(histList.length, 2);
  const legRestored = histList.find((s) => s.sessionId === legComp.session.sessionId);
  assert.strictEqual(legRestored.correctCount, 1);
  assert.strictEqual(legRestored.totalBlocks, 1);
  assert.strictEqual(legRestored.maxScore, 3);

  // 4. Verifica deleteAllCompletedSessions (mantiene sessioni sospese)
  const suspSess = await mgr.createSession({
    profileId: "u1",
    mode: "random",
    questionTypes: ["HOME_ROW"],
    requestedCount: 1,
  });
  await mgr.suspendSession("u1", suspSess.session.sessionId);
  const deletedCount = await repository.deleteAllCompletedSessions("u1");
  assert.strictEqual(deletedCount, 2);
  const remaining = await repository.getSessionsByProfile("u1");
  assert.strictEqual(remaining.length, 1);
  assert.strictEqual(remaining[0].status, "suspended");

  // 5. Verifica toggle selezione manuale su InterrogationUI con mock DOM minimale
  const domElements = new Map();
  const makeMockEl = (id, val = "") => ({
    id,
    value: val,
    innerHTML: "",
    textContent: "",
    className: "",
    classList: {
      _set: new Set(),
      add(c) { this._set.add(c); },
      remove(c) { this._set.delete(c); },
      toggle(c, force) {
        if (force === undefined) {
          if (this._set.has(c)) this._set.delete(c);
          else this._set.add(c);
        } else if (force) this._set.add(c);
        else this._set.delete(c);
      },
      contains(c) { return this._set.has(c); },
    },
    children: [],
    appendChild(ch) { this.children.push(ch); },
    addEventListener() {},
  });
  domElements.set("interrogationTypeSelect", makeMockEl("interrogationTypeSelect", "CARATTERE"));
  domElements.set("interrManualSelectedChips", makeMockEl("interrManualSelectedChips", ""));

  ctx.document = {
    getElementById: (id) => domElements.get(id) || null,
    createElement: (tag) => makeMockEl(tag, ""),
    querySelectorAll: () => [],
  };
  loadScript(ctx, "js/ui/interrogation-ui.js");

  const highlightedKeys = new Set();
  const highlightedFingers = new Set();
  const ui = new ctx.InterrogationUI({ sessionManager: mgr, catalog });
  ui.manualSvg = {
    resetKeyboard() { highlightedKeys.clear(); },
    resetHands() { highlightedFingers.clear(); },
    highlightKey(kId) { highlightedKeys.add(kId); },
    highlightFingersOnHands(fSet) {
      highlightedFingers.clear();
      fSet.forEach((f) => highlightedFingers.add(Number(f)));
    },
  };

  // Primo click su key_a -> aggiunge ed evidenzia
  ui._addManualCandidateByKeyId("key_a");
  assert.strictEqual(ui.manualSelectedIds.length, 1);
  assert.ok(highlightedKeys.has("key_a"));

  // Secondo click su key_a -> rimuove e toglie evidenziazione
  ui._addManualCandidateByKeyId("key_a");
  assert.strictEqual(ui.manualSelectedIds.length, 0);
  assert.ok(!highlightedKeys.has("key_a"));

  // Multi-selezione dita e toggle singolo dito
  ui._addManualCandidateByFingerId("4");
  ui._addManualCandidateByFingerId("7");
  assert.strictEqual(ui.manualSelectedIds.length, 2);
  assert.ok(highlightedFingers.has(4) && highlightedFingers.has(7));
  ui._addManualCandidateByFingerId("4");
  assert.strictEqual(ui.manualSelectedIds.length, 1);
  assert.ok(!highlightedFingers.has(4) && highlightedFingers.has(7));

  console.log("PASS: test-interrogation-v631 (backend stats, fallback, repeat, clearAll, toggle selezione manuale).");
}

runTests().catch((err) => {
  console.error(err);
  process.exit(1);
});
