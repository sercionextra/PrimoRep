## Ten Fingers Typing Trainer v6.7

## Manuale Utente — guida didattica completa

> **Scopo del manuale:** imparare a usare Ten Fingers Typing Trainer come strumento di formazione alla dattilografia a dieci dita, comprendendo non solo i comandi ma soprattutto **perché** usare ciascuna funzione e **quando** inserirla nel proprio percorso di apprendimento.

---

## 1. Che cos'è Ten Fingers Typing Trainer

Ten Fingers Typing Trainer è un allenatore di dattilografia progettato per sviluppare una competenza completa sulla tastiera attraverso:

- progressione didattica;
- esercizi con difficoltà crescente;
- guida visiva delle dita;
- tastiera virtuale;
- correzione degli errori;
- feedback audio;
- dettatura vocale;
- statistiche;
- allenamento personalizzato;
- esercizi adattivi sulle proprie debolezze.

L'obiettivo non è semplicemente aumentare il numero di battute al minuto. L'obiettivo è costruire una **memoria motoria affidabile**, fino a rendere la digitazione naturale e poco dipendente dalla vista.

### La regola fondamentale

> **Prima precisione, poi velocità.**

Una velocità elevata ottenuta commettendo molti errori non rappresenta una buona tecnica: rischia di consolidare movimenti sbagliati.

---

# 2. Come imparare correttamente: la posizione di riposo è il cuore del metodo

La dattilografia è un'abilità motoria. Non basta sapere **quale** tasto premere: occorre costruire una rappresentazione interna delle **distanze relative** tra ogni tasto e la posizione naturale della mano.

## La regola fondamentale: premi e torna alla base

Nelle prime fasi del corso, dopo **ogni pressione di tasto**, abitua deliberatamente il dito a **recuperare la propria posizione di riposo** (posizione di base) prima di affrontare il movimento successivo.

Il ciclo didattico fondamentale è quindi:

**posizione di riposo → movimento verso il tasto → pressione → ritorno alla posizione di riposo → nuovo movimento**

Questo può sembrare più lento della digitazione spontanea, ma è intenzionale. Il ritorno alla base permette di rinforzare:

- la memoria muscolare;
- la percezione della distanza tra il dito e il proprio tasto obiettivo;
- l'orientamento della mano senza guardare la tastiera;
- la capacità di recuperare rapidamente la posizione corretta dopo un errore o una sequenza insolita.

> **Principio guida:** all'inizio non allenare soltanto il movimento che porta al tasto; allena anche il movimento che riporta il dito alla sua posizione di equilibrio.

### Le prime esercitazioni devono essere lente

La velocità iniziale è secondaria. Se per eseguire correttamente una sequenza devi rallentare, rallenta.

Una buona ripetizione è:

1. riconoscere il carattere;
2. individuare mentalmente il dito;
3. partire dalla posizione di riposo;
4. raggiungere il tasto con il movimento necessario;
5. premere;
6. **tornare alla posizione di riposo**;
7. preparare il movimento successivo.

Con la pratica, il ritorno alla base diventerà automatico e non dovrà più essere percepito come un'azione separata.

## Perché questo migliora il trasferimento nella vita reale

Se ogni dito viene allenato a partire da un riferimento stabile, il cervello può codificare i tasti come **distanze e direzioni rispetto alla posizione di equilibrio**, anziché come semplici coordinate visive.

Questo è particolarmente importante quando:

- non puoi guardare la tastiera;
- devi scrivere un testo nuovo;
- devi ascoltare qualcuno mentre parla;
- devi pensare contemporaneamente a ciò che stai scrivendo;
- utilizzi una tastiera diversa ma con una disposizione compatibile.

## Dalla guida visiva all'autonomia

All'inizio puoi usare tutte le guide disponibili. Successivamente riducile una per volta.

**Guida visiva → ritorno alla base → ripetizione → riduzione degli aiuti → autonomia.**

L'obiettivo finale non è diventare bravo a seguire l'interfaccia di Ten Fingers Typing Trainer, ma diventare bravo a **digitare senza averne bisogno**.

---

# 2A. Il metodo in pratica: una scala di difficoltà

Il trainer può essere usato come una vera scala didattica.

| Livello | Aiuti | Obiettivo principale |
| --- | --- | --- |
| 1 | Tastiera + Mani + Auto-Correction | Stabilire la postura e i riferimenti |
| 2 | Tastiera + Mani, Auto-Correction ridotta | Imparare movimento e ritorno alla base |
| 3 | Meno guide, correzione manuale | Rafforzare memoria muscolare |
| 4 | Dettatura + guide ridotte | Separare ascolto e gesto dalla visione |
| 5 | Interfaccia nascosta o parzialmente coperta | Aumentare autonomia e carico cognitivo |
| 6 | Statistiche in primo piano + esercizio | Monitorare consapevolmente il progresso |
| 7 | Nessun aiuto essenziale, testi reali | Verificare il trasferimento nella vita reale |

### Criterio per avanzare

Non chiederti soltanto: **“Quanto sono veloce?”**

Chiediti:

- Riesco a ritrovare la posizione di base?
- Dopo ogni tasto torno spontaneamente alla posizione di riposo?
- Posso digitare senza guardare?
- Posso correggere senza perdere l'orientamento?
- Riesco a seguire una dettatura senza leggere il testo?
- Le prestazioni restano buone quando nascondo le guide?
- Il risultato si mantiene anche fuori dall'app?

Queste domande misurano meglio la qualità dell'apprendimento.

# 3. Il percorso progressivo

Le lezioni Standard sono organizzate progressivamente.

Le prime lezioni introducono piccoli gruppi di tasti; il percorso cresce fino a comprendere:

- lettere;
- maiuscole;
- numeri;
- punteggiatura;
- simboli;
- caratteri accentati;
- Invio;
- Tab;
- altri caratteri di layout.

Il percorso contiene **71 lezioni** e **996 frasi**.

## Strategia consigliata

### Fase 1 — apprendimento

Usa **PHRASES** e procedi con ordine.

### Fase 2 — consolidamento

Ripeti le lezioni già studiate finché la digitazione diventa naturale.

### Fase 3 — verifica

Usa **RANDOM** e **FONEMI** per eliminare l'aiuto della memoria delle parole.

### Fase 4 — ampliamento

Usa **ALL CHARS** per allenare l'intero repertorio.

### Fase 5 — recupero

Usa **WEAKNESSES** per concentrarti sui caratteri che generano più errori.

### Fase 6 — trasferimento

Usa **TYPING** o **Custom** con testi reali.

---

# 4. Conoscere l'interfaccia

L'interfaccia è organizzata attorno all'area di digitazione.

## Barra superiore

Raccoglie le funzioni generali:

- profilo;
- cambio utente;
- tema;
- audio;
- volume;
- dettatura;
- velocità della dettatura;
- opzioni vocali;
- replay;
- editor Custom;
- statistiche.

## Toolbar dell'esercizio

Permette di scegliere:

- modalità;
- lezione;
- sorgente;
- frase;
- esercizio.

Sono disponibili anche i comandi di navigazione e riavvio.

## Area di digitazione

Mostra:

- testo guida;
- testo già digitato;
- carattere corrente;
- spazi;
- avanzamento;
- eventuali errori.

Il carattere evidenziato rappresenta ciò che devi risolvere in quel momento.

## Metriche

Le informazioni principali comprendono:

- tempo;
- BPM;
- caratteri;
- errori.

---

# 5. Le sette modalità

## 5.1 PHRASES

È la modalità didattica principale.

Usa le frasi delle lezioni Standard.

### Serve per

- imparare nuovi tasti;
- consolidare la posizione delle dita;
- allenare la digitazione di parole e frasi;
- costruire progressivamente la tecnica.

### Scorciatoia

`Ctrl + Shift + 1`

---

## 5.2 RANDOM

Genera sequenze casuali utilizzando i caratteri appresi fino alla lezione corrente.

### Serve per

Verificare se sai usare i tasti senza essere aiutato dalla memoria delle parole.

È particolarmente utile dopo una lezione: se con le frasi vai bene ma con RANDOM aumentano gli errori, la posizione dei tasti non è ancora completamente automatizzata.

### Scorciatoia

`Ctrl + Shift + 2`

---

## 5.3 FONEMI

Genera sequenze pseudo-linguistiche mediante un modello a catena di Markov.

Sono disponibili impostazioni relative a:

- lunghezza N-gram;
- maiuscole;
- punteggiatura;
- parentesi;
- numeri;
- caratteri matematici;
- simboli;
- layout;
- corpus personalizzato.

La lunghezza N-gram è regolabile indicativamente da **2 a 15**, con valore predefinito **4**.

### Perché usarla?

Le parole vere aiutano il cervello a prevedere la sequenza successiva. FONEMI riduce questo vantaggio e obbliga le dita a gestire realmente le transizioni fra caratteri.

### Scorciatoia

`Ctrl + Shift + 3`

---

## 5.4 ALL CHARS

Allena l'inventario esteso dei caratteri.

Comprende, in funzione delle impostazioni:

- lettere;
- maiuscole;
- numeri;
- accenti;
- simboli;
- caratteri di layout.

### Serve per

Passare dalla dattilografia didattica alla padronanza completa della tastiera.

### Scorciatoie

`Ctrl + Shift + 4`

oppure

`Ctrl + Shift + G`

---

## 5.5 TYPING

È la modalità libera.

Non viene fornito un testo guida.

Scrivi come se stessi lavorando normalmente.

### Serve per

Verificare il trasferimento della tecnica alla scrittura reale.

È una delle modalità più importanti quando il percorso didattico ha già prodotto una buona base.

### Scorciatoia

`Ctrl + Shift + 5`

---

## 5.6 RANDOM THIS PHRASE

Prende la frase corrente e ne rimescola i caratteri.

### Perché è utile?

Con una frase normale puoi sfruttare la memoria linguistica. Rimescolandone i caratteri, devi risolvere nuovamente ogni movimento.

### Scorciatoia

`Ctrl + Shift + Z`

---

## 5.7 WEAKNESSES

È la modalità adattiva.

Utilizza le statistiche personali per dare maggiore importanza ai caratteri che generano più errori.

### Serve per

- recuperare caratteri deboli;
- concentrare il tempo di allenamento;
- trasformare le statistiche in esercizi personalizzati.

È consigliabile usarla dopo aver accumulato un numero sufficiente di sessioni.

### Scorciatoia

`Ctrl + Shift + 6`

---

# 6. Tastiera e dieci dita

La tastiera virtuale mostra il carattere che devi premere.

La finestra Mani mostra invece il dito che dovrebbe eseguire il movimento.

Le due rappresentazioni lavorano insieme.

## Dieci dita

| Indice | Dito |
| --- | --- |
| 1 | Mignolo sinistro |
| 2 | Anulare sinistro |
| 3 | Medio sinistro |
| 4 | Indice sinistro |
| 5 | Pollice sinistro |
| 6 | Pollice destro |
| 7 | Indice destro |
| 8 | Medio destro |
| 9 | Anulare destro |
| 10 | Mignolo destro |

La codifica visiva usa:

- rosso per i mignoli;
- arancio per gli anulari;
- verde per i medi;
- blu per gli indici;
- viola per i pollici.

---

# 7. Shift e maiuscole

Quando devi digitare una maiuscola, devi usare `Shift`.

È preferibile che il dito che preme Shift appartenga alla mano opposta rispetto a quella che digita il carattere.

Questo distribuisce il lavoro fra le mani e rende il movimento più fluido.

Esempio concettuale:

**Shift sinistro + carattere della mano destra**

oppure

**Shift destro + carattere della mano sinistra.**

---

# 8. Spazio, Invio e Tab

I caratteri di layout fanno parte della competenza di dattilografia.

L'app tratta:

- `®` come **Invio**;
- `→` come **Tab**.

Questo è particolarmente importante negli esercizi Custom.

Una normale interruzione di riga del file Custom non equivale automaticamente a un Invio digitabile.

---

# 9. Errori

L'errore è una misura didattica.

Durante la sessione viene conservata la coppia:

**carattere atteso → carattere digitato.**

Il registro permette quindi di capire non soltanto quanti errori hai commesso, ma **quali movimenti stai sbagliando**.

Esempio:

```text
g → h
r → t
l → k
```

Se una coppia ricorre molte volte, è un candidato naturale per l'allenamento WEAKNESSES.

---

# 10. Backspace

Il Backspace non è considerato una normale battuta.

Serve a correggere il testo digitato.

Quando ci sono errori pendenti, la correzione procede progressivamente fino a tornare al prefisso corretto.

### Regola didattica

Non usare Backspace freneticamente.

Fai attenzione al carattere sbagliato, individua il movimento errato e correggilo consapevolmente.

---

# 11. Auto-Correction: una stampella utile, da abbandonare presto

L'**Auto-Correction** ha un ruolo didattico molto preciso nelle prime fasi: aiutarti a **non perdere la posizione di riferimento** mentre stai ancora imparando la postura di base.

Gli indici devono trovare e riconoscere i **tasti marcati di riferimento**; da quella posizione equilibrata le altre dita imparano a raggiungere i rispettivi tasti e a ritornare alla base.

## Perché può essere utile all'inizio

Quando commetti un errore e devi interrompere continuamente il flusso per correggerlo, puoi perdere la posizione delle mani. L'Auto-Correction può evitare che una singola imprecisione ti faccia smarrire il riferimento.

In questa fase può quindi aiutare a consolidare:

- la posizione centrata della mano;
- il riferimento tattile e spaziale degli indici;
- la relazione tra ciascun dito e il proprio gruppo di tasti;
- il recupero della posizione di riposo dopo ogni battuta.

## Ma non deve diventare un'abitudine

L'Auto-Correction va **abbandonata il prima possibile**.

La sua funzione è analoga a quella di una ruota di sostegno: facilita l'apprendimento iniziale, ma non deve accompagnare l'intera esperienza.

Una progressione consigliata è:

1. **Auto-Correction attiva** mentre impari la postura e i primi tasti;
2. esercizi brevi con **Auto-Correction disattivata**;
3. alternanza fra esercizi con e senza correzione;
4. prevalenza crescente degli esercizi **senza** correzione;
5. uso della correzione automatica solo quando ha un preciso scopo didattico.

## Perché disattivarla permette di misurare il vero progresso

Quando la disattivi, ogni errore diventa un'informazione sul tuo reale livello di autonomia.

Puoi così verificare se sai:

- mantenere la posizione di base;
- recuperarla dopo ogni pressione;
- correggere senza perdere l'orientamento;
- digitare senza l'aiuto dell'interfaccia.

Questo rende l'esercizio più vicino alla realtà esterna all'applicazione.

> **Regola pratica:** se ti accorgi che riesci bene solo con Auto-Correction attiva, non interpretarlo come un risultato consolidato. È il segnale che devi dedicare più tempo agli esercizi senza correzione.

---

# 12. Audio

L'app supporta tre modalità:

- typewriter;
- beep;
- mute.

Il volume è regolabile.

L'audio è un rinforzo, non un requisito. Puoi quindi allenarti anche con l'audio disattivato.

---

# 13. Dettatura vocale: spezzare l'associazione tra ciò che vedo e ciò che digito

La **Dettatura Vocale** non è soltanto un modo alternativo per ricevere il testo dell'esercizio. È uno strumento fondamentale per evitare una possibile abitudine negativa: associare automaticamente la **visione del carattere** al gesto muscolare che lo produce.

Quando leggi continuamente sullo schermo ogni carattere che devi digitare, puoi costruire un'associazione molto forte:

**vedo la lettera → muovo il dito**

Nella vita reale, però, spesso accade qualcosa di diverso:

**ascolto / penso / formulo una parola → la trasformo mentalmente in una sequenza di caratteri → muovo le dita**

La dettatura serve proprio a esercitare questo secondo percorso.

## Perché ridurre la dipendenza dalla vista

Durante la scrittura reale devi spesso:

- pensare al contenuto;
- ascoltare una persona;
- seguire una conversazione;
- formulare una risposta;
- ricordare una parola;
- digitare senza avere davanti ogni carattere.

Se l'allenamento dipende troppo dal testo guida, i risultati ottenuti nell'app possono apparire migliori di quelli realmente ottenibili in una situazione naturale.

Per questo **vista e ascolto devono avere un peso progressivamente equilibrato**.

## Progressione consigliata

1. **Testo visibile:** serve per apprendere i nuovi movimenti.
2. **Testo + audio:** inizi a separare vista e gesto.
3. **Dettatura lenta:** ascolti, mantieni in memoria brevi porzioni e digiti.
4. **Dettatura normale:** riduci ulteriormente la dipendenza dalla lettura.
5. **Dettatura più rapida:** aumenti la capacità di trasformare il linguaggio in movimento.
6. **Esercizi senza testo guida:** verifichi il trasferimento dell'abilità.

La velocità della voce è regolabile indicativamente da **0,6× a 1,4×**, con default circa **0,9×**.

## Opzioni

Puoi controllare:

- annuncio delle maiuscole;
- annuncio dell'apostrofo;
- annuncio degli spazi;
- spelling.

Lo spelling è utile soprattutto quando vuoi isolare caratteri o sequenze particolarmente difficili.

## Gestione degli errori durante la dettatura

Se premi un tasto errato, la sintesi vocale ti avvisa subito pronunciando *"errore"*. Cancellando con il tasto Backspace, la voce ti guida scandendo quanti errori rimangono da correggere (*"ancora due errori"*, *"ancora un errore"*). Non appena tutti gli errori sono cancellati, la dettatura riprende direttamente dal primo carattere non ancora digitato, continuando a scandire le parole al ritmo naturale della tua scrittura senza interrompersi.

> **Obiettivo didattico:** non arrivare semplicemente a “sentire e trascrivere” una frase. Devi arrivare al punto in cui ascoltare o pensare una parola attiva naturalmente la corretta sequenza di movimenti delle dita.

Se il browser non dispone di una voce adatta, la funzione vocale può essere limitata, ma le funzioni di digitazione continuano a funzionare.

---

# 14. Replay e ripetizione vocale

Il replay è utile quando hai perso una parola o una sequenza.

Non usarlo continuamente: l'obiettivo è sviluppare una buona memoria breve.

Se la dettatura viene interrotta da una pausa o da un errore, l'app può utilizzare una ripetizione assistita per aiutarti a recuperare il flusso.

---

# 15. Statistiche

Le statistiche servono a rispondere a una domanda:

> **Su cosa devo allenarmi adesso?**

Non devono essere usate soltanto per cercare il numero BPM più alto.

## Dati principali

- velocità;
- caratteri;
- errori;
- errori relativi;
- statistiche per carattere;
- statistiche per dito;
- storico delle sessioni.

## Velocità netta

La velocità netta è il principale indicatore di prestazione.

È calcolata mettendo in relazione il lavoro corretto con il tempo trascorso.

---

# 16. Statistiche per carattere

Per ciascun carattere l'app conserva informazioni relative a:

- frequenza;
- numero di errori;
- dito associato.

Puoi ordinare i dati per:

- frequenza relativa;
- frequenza assoluta;
- errori relativi;
- errori assoluti;
- dito.

Questo permette di distinguere:

**“sbaglio spesso la Q”**

da:

**“ho un problema generale con il mignolo sinistro”.**

---

# 17. Grafico della velocità

Lo storico permette di analizzare l'andamento nel tempo.

Puoi osservare:

- BPM;
- numero di caratteri;
- errori relativi;
- errori assoluti.

Sono disponibili filtri temporali:

- data iniziale;
- ora iniziale;
- data finale;
- ora finale.

Puoi inoltre filtrare i campioni per tipo di allenamento.

---

# 18. Selezione e cancellazione dei campioni

Il grafico consente di selezionare punti o intervalli di esercizi.

Le operazioni disponibili permettono di:

- cancellare i selezionati: rimuove dal profilo attivo solo i campioni inclusi nella selezione corrente;
- cancellare quelli non selezionati: quando sono attivi dei filtri, rimuove esclusivamente i campioni visibili nel grafico esterni alla selezione, preservando intatti sia i campioni selezionati sia l'archivio storico non incluso nel filtro corrente; in assenza di filtri attivi, coincide con la rimozione di tutti i campioni esterni alla selezione;
- cancellare la selezione: azzera l'intervallo selezionato senza rimuovere alcun dato.

Le operazioni distruttive richiedono conferma.

---

# 19. Come leggere i progressi

Una progressione sana non è necessariamente:

```text
100 BPM → 120 BPM → 150 BPM
```

La qualità va osservata insieme agli errori.

Una progressione più significativa è:

```text
100 BPM / molti errori
↓
105 BPM / meno errori
↓
115 BPM / precisione stabile
↓
125 BPM / precisione stabile
```

Il vero obiettivo è aumentare il ritmo senza perdere il controllo.

---

# 20. Editor Custom

L'editor permette di costruire esercizi personali.

Formato:

```text
=====Titolo esercizio=====
prima frase
seconda frase
=====
=====Altro esercizio=====
una nuova frase
=====
```

## Regole

`=====Titolo=====` apre un esercizio.

Le righe successive costituiscono le frasi.

`=====` chiude il blocco.

## Caratteri speciali

| Simbolo | Significato |
| --- | --- |
| `®` | Invio |
| `→` | Tab |

Il formato permette di creare esercizi molto mirati.

### Esempi di utilizzo

- terminologia professionale;
- parole straniere;
- testi tecnici;
- documentazione;
- nomi propri;
- frasi che contengono simboli difficili;
- contenuti che utilizzi quotidianamente.

## Gestione della fonte per i Fonemi

Nella barra inferiore della finestra dell'Editor sono presenti gli strumenti per la gestione del testo sorgente dedicato alla modalità FONEMI:

- **Input Testo per Fonemi**: consente di caricare un proprio file di testo (.txt) per generare sequenze basate sul proprio vocabolario;
- **Export Testo di Input per Fonemi**: scarica una copia del testo personalizzato salvato nel profilo;
- **🗑 Elimina**: rimuove la fonte personalizzata precedentemente importata nel profilo, disattiva automaticamente la voce "Custom File" e ripristina la fonte fonemica predefinita di sistema;
- **Configurazione Fonemi**: apre il pannello per regolare la lunghezza degli N-grammi e le probabilità dei caratteri.

---

# 21. Profili

Ogni utente ha il proprio ambiente.

Sono associati al profilo:

- modalità;
- lezione;
- esercizio;
- impostazioni;
- statistiche;
- campioni;
- testo Custom;
- configurazione FONEMI;
- tema;
- audio;
- dettatura;
- posizione delle finestre.

Il cambio utente separa questi dati.

---

# 22. Backup

I dati sono locali al browser.

Per questo è consigliabile esportare periodicamente il profilo.

Il formato di export è JSON.

La procedura ideale è:

1. allenarsi;
2. accumulare statistiche;
3. esportare il profilo;
4. conservare il file in un luogo sicuro.

---

# 23. Temi

Sono disponibili quattro temi:

1. **Dark Mode**
2. **Light Mode**
3. **Retro 2003**
4. **Matrix High-Contrast**

Il tema è una scelta estetica e di leggibilità: non modifica la logica degli esercizi.

---

# 24. Finestre Mani, Statistiche ed Editor: usare l'interfaccia come livello di difficoltà

Le finestre dell'applicazione non sono soltanto strumenti di consultazione. Possono diventare parte integrante della progressione didattica.

Le finestre principali possono essere:

- trascinate;
- ridimensionate;
- chiuse;
- ripristinate;
- sovrapposte;
- utilizzate per coprire parzialmente altre aree dell'interfaccia.

## La finestra Mani come strumento di concentrazione

La finestra **Mani** è ridimensionabile e, durante esercizi specifici, può diventare l'elemento centrale dello schermo, coprendo completamente o parzialmente il resto dell'interfaccia.

Questa configurazione è utile quando vuoi:

- rallentare intenzionalmente;
- concentrarti sulla meccanica del movimento;
- osservare quali dita partecipano a un accordo;
- studiare una correzione;
- controllare con maggiore precisione quanto un dito deve essere **flesso o esteso** per abbandonare la posizione di riposo e raggiungere il tasto obiettivo.

La rappresentazione delle mani può quindi essere usata in due modi diversi:

**modalità guida:** mostra il dito e il movimento da compiere;

**modalità studio:** diventa il principale oggetto di attenzione, costringendoti a eseguire movimenti più lenti e consapevoli.

### Una pratica utile

Per un carattere difficile:

1. osserva il dito nella posizione di riposo;
2. osserva la direzione del movimento;
3. valuta quanto deve flettersi o estendersi;
4. premi il tasto;
5. **riporta il dito alla posizione di riposo**;
6. ripeti lentamente.

Ripetere questa sequenza consolida sia la posizione del tasto sia la distanza dal riferimento.

## Nascondere l'interfaccia

Le parti principali dell'interfaccia possono essere nascoste progressivamente.

Questo non serve soltanto a “fare pulizia” dello schermo: è un vero **aumento della difficoltà cognitiva**.

Quando nascondi una guida, devi:

- ricordare meglio la posizione dei tasti;
- mantenere più informazioni nella memoria;
- controllare maggiormente le dita;
- accettare una velocità inferiore;
- recuperare autonomamente la posizione di riposo.

La progressione ideale è quindi:

**molti aiuti → meno aiuti → quasi nessun aiuto → digitazione autonoma**

Il principio da non perdere mai è il ritorno alla posizione di base dopo ogni pressione.

## Statistiche come pannello di feedback

Nelle fasi avanzate puoi lasciare la finestra **Statistiche** sopra una parte dell'interfaccia.

Questo trasforma il grafico in un feedback continuo e immediatamente leggibile.

Puoi scegliere il tipo di grafico più utile e:

- selezionare la metrica di interesse;
- filtrare i dati;
- restringere il periodo temporale;
- osservare la sessione corrente o sessioni passate;
- confrontare periodi diversi;
- mantenere il grafico visibile mentre esegui gli esercizi.

Il grafico viene **aggiornato automaticamente al termine di ogni esercizio**.

Usalo per osservare una tendenza, non per inseguire ogni oscillazione momentanea.

---

# 24B. La Finestra Velocità Istantanea: esplorare i propri limiti superiori

> **Regola didattica fondamentale:** questa funzione non deve essere usata da chi sta imparando le posizioni dei tasti.

All'inizio del percorso didattico la velocità deve essere completamente ignorata. L'unico obiettivo è la precisione: trovare il tasto giusto, premerlo con il dito corretto e **ritornare alla posizione di riposo**.

La finestra **Velocità Istantanea** diventa utile in una fase avanzata:

1. dopo aver studiato l'intero programma delle lezioni;
2. dopo aver ridotto stabilmente la percentuale di errore a livelli trascurabili;
3. quando l'obiettivo didattico si sposta sullo sviluppo del ritmo e della fluidità di scrittura.

## Come utilizzare il grafico

Mentre esegui l'esercizio, la finestra traccia l'andamento del ritmo battuta per battuta:

- **Punti Verdi:** caratteri digitati correttamente.
- **Punti Rossi:** caratteri errati.
- **Punti Arancioni:** correzioni effettuate con Backspace (simbolo `⌫`).
- **Tempi sotto i caratteri:** indicano i secondi e millesimi trascorsi dall'inizio dell'esercizio, disposti in verticale per non sovrapporsi.

### A cosa servono i picchi

I picchi più alti della curva non sono anomalie: indicano le transizioni tra lettere in cui il movimento è stato immediato e privo di esitazione.

Osservare questi picchi ti consente di **stimare i tuoi limiti di velocità superiori**: ti mostrano la velocità potenziale a cui le tue mani possono già muoversi e costituiscono il punto di riferimento a cui tendere ed aspirare per l'intera frase.

## Le due linee di media

Attraverso il grafico corrono due linee orizzontali tratteggiate:

- **Linea Verde (Media Netta):** calcolata dividendo il numero di caratteri corretti per il tempo trascorso in secondi, moltiplicato per 60.
- **Linea Arancione (Media Lorda):** calcolata dividendo il totale dei tasti battuti (compresi errori e Backspace) per il tempo trascorso in secondi, moltiplicato per 60.

La distanza tra la linea arancione e la linea verde rende immediatamente visibile quanto gli errori stiano rallentando la tua resa effettiva.

## Configurazione della Media Mobile (Pulsante ⚙ Parametri)

Tramite il pulsante **⚙ Parametri** puoi regolare la larghezza della finestra di calcolo da 1 a 10 battute (valore predefinito: 3).

- Con valore 1 osservi la velocità puramente istantanea tra due singoli tasti.
- Con valori da 3 a 5 ottieni una curva più morbida e leggibile, che fotografa il ritmo reale delle parole senza sobbalzi eccessivi.

Quando confermi un nuovo valore di N, **l'intera curva dell'esercizio corrente viene immediatamente ricalcolata e ridisegnata a schermo**, permettendoti di confrontare subito il diverso grado di fluidità del grafico.

## Scorciatoia rapida

Puoi mostrare o nascondere la finestra in qualsiasi momento premendo **Ctrl + Shift + I**. Il pulsante **↺ Default** la ricolloca sopra l'area della tastiera.

---

# 25. Scorciatoie

| Funzione | Scorciatoia |
| --- | --- |
| PHRASES | `Ctrl+Shift+1` |
| RANDOM | `Ctrl+Shift+2` |
| FONEMI | `Ctrl+Shift+3` |
| ALL CHARS | `Ctrl+Shift+4` / `Ctrl+Shift+G` |
| TYPING | `Ctrl+Shift+5` |
| WEAKNESSES | `Ctrl+Shift+6` |
| Statistiche | `Ctrl+Shift+7` |
| Spelling | `Ctrl+Shift+8` / `Ctrl+Shift+P` |
| Dettatura | `Ctrl+Shift+9` / `Ctrl+Shift+V` |
| Aggiungi statistica | `Ctrl+Shift+0` / `Ctrl+Shift+Enter` |
| Lezione precedente/successiva | `Ctrl+Shift+↑/↓` |
| Frase precedente/successiva | `Ctrl+Shift+←/→` |
| Seleziona frase | `Ctrl+Shift+E` |
| Riavvia | `Ctrl+Shift+X` |
| Random This Phrase | `Ctrl+Shift+Z` |
| Testo guida | `Ctrl+Shift+O` |
| Testo digitato | `Ctrl+Shift+Y` |
| Errori | `Ctrl+Shift+L` / `Ctrl+Shift+F` |
| Tastiera | `Ctrl+Shift+K` |
| Mani | `Ctrl+Shift+M` |
| Auto-Correction | `Ctrl+Shift+B` |
| Replay dettatura | `Ctrl+Shift+Space` |
| Standard/Custom | `Ctrl+Shift+D` |

> Le combinazioni sono pensate per permettere di controllare l'applicazione senza abbandonare la posizione delle mani.

---

# 26. Routine quotidiana consigliata

Una sessione efficace può durare circa 25–30 minuti.

## 5 minuti — riscaldamento

PHRASES su una lezione conosciuta.

Obiettivo: precisione.

## 10 minuti — apprendimento

Lavora sulla lezione corrente.

Obiettivo: nuovi movimenti.

## 5 minuti — consolidamento

RANDOM oppure FONEMI.

Obiettivo: memoria motoria.

## 5 minuti — debolezze

WEAKNESSES.

Obiettivo: recupero mirato.

## 5 minuti — trasferimento

TYPING o Custom.

Obiettivo: applicazione reale.

---

# 27. Errori da evitare

### Cercare la velocità troppo presto

La velocità viene dopo la precisione.

### Guardare continuamente la tastiera

Usa la guida visiva per imparare, non per dipendere permanentemente da essa.

### Ripetere soltanto gli esercizi facili

La pratica deve includere anche ciò che non riesce bene.

### Ignorare gli errori ricorrenti

Un carattere sbagliato molte volte è un segnale didattico prezioso.

### Usare sempre la stessa modalità

Le diverse modalità allenano competenze differenti.

### Considerare il BPM come unico obiettivo

Una velocità elevata non è utile se produce una quantità eccessiva di errori.

---

# 28. FAQ

## Devo guardare la tastiera?

No. La tastiera virtuale e la finestra Mani servono soprattutto durante l'apprendimento.

## È meglio essere veloci o precisi?

Precisi. La velocità deve crescere mantenendo il controllo.

## Quando usare WEAKNESSES?

Quando hai accumulato abbastanza dati statistici da permettere al sistema di individuare i caratteri problematici.

## Perché usare FONEMI?

Per ridurre l'aiuto della memoria linguistica e allenare direttamente le transizioni tra caratteri.

## Perché esistono RANDOM e RANDOM THIS PHRASE?

RANDOM usa il repertorio della lezione; RANDOM THIS PHRASE rimescola i caratteri della frase corrente.

## Posso usare testi personali?

Sì, tramite Custom.

## Cosa significa `®`?

Invio.

## Cosa significa `→`?

Tab.

## La dettatura non funziona: cosa posso fare?

Controlla audio, browser e voci installate. La disponibilità della sintesi vocale dipende dall'ambiente.

## Ho cambiato computer: dove sono le statistiche?

I dati sono locali al browser. Usa export/import del profilo.

---

# 29. Riferimento rapido

| Obiettivo | Funzione |
| --- | --- |
| Imparare nuovi tasti | PHRASES |
| Verificare la memoria dei tasti | RANDOM |
| Allenare le transizioni | FONEMI |
| Allenare l'intera tastiera | ALL CHARS |
| Scrivere liberamente | TYPING |
| Eliminare la memoria della frase | RANDOM THIS PHRASE |
| Recuperare i caratteri deboli | WEAKNESSES |
| Allenare ascolto + digitazione | Dettatura |
| Analizzare i progressi | Statistiche |
| Allenare materiale personale | Custom |

---

# 30. La filosofia del trainer in una frase

> **Impara lentamente, correggi consapevolmente, ripeti correttamente, misura i progressi e aumenta la velocità solo quando il movimento è diventato automatico.**
