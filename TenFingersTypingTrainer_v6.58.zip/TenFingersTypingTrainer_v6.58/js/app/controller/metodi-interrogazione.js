/* TenFingersTypingTrainer v6.33 | metodi-interrogazione.js | Estensione AppController per apertura, layout e collegamento della vista Interrogazione. */
Object.assign(AppController.prototype, {
  setupInterrogationControls() {
    if (!this.interrogationUI && typeof InterrogationSessionManager === "function") {
      const catalog = new InterrogationCatalog();
      const repository = new InterrogationRepository();
      const sessionManager = new InterrogationSessionManager({
        catalog,
        repository,
      });
      this.interrogationUI = new InterrogationUI({
        sessionManager,
        catalog,
        getProfileId: () => this.profileMgr?.currentUser || "default",
        getMaxLessonReached: () =>
          typeof this.profileMgr?.getMaxLessonReached === "function"
            ? this.profileMgr.getMaxLessonReached()
            : Math.max(0, Number(this.profileMgr?.profile?.Lesson) || 0),
        setMaxLessonReached: (lessonIdx) => {
          if (typeof this.profileMgr?.setMaxLessonReached === "function") {
            return this.profileMgr.setMaxLessonReached(
              lessonIdx,
              Math.max(0, (this.standardLessons?.length || 71) - 1),
            );
          }
          return lessonIdx;
        },
        showConfirm: (msg, title, onOk, onCancel) => {
          if (typeof this.showAppConfirm === "function") {
            this.showAppConfirm(msg, title, onOk, onCancel);
          } else if (typeof window !== "undefined" && typeof window.confirm === "function") {
            if (window.confirm(msg)) onOk?.();
            else onCancel?.();
          }
        },
        showAlert: (msg, title, onOk) => {
          if (typeof this.showAppAlert === "function") {
            this.showAppAlert(msg, title, onOk);
          } else if (typeof window !== "undefined" && typeof window.alert === "function") {
            window.alert(msg);
            onOk?.();
          }
        },
        showToast: (msg, icon = "ℹ") => {
          if (typeof this.showNotificationToast === "function") {
            this.showNotificationToast(msg, icon);
          } else if (typeof this.showAppAlert === "function") {
            this.showAppAlert(msg, "ℹ Informazione");
          }
        },
        onClose: () => {
          if (typeof document !== "undefined" && document.body) {
            document.body.style.overflow = "";
          }
          this.returnFocusToTyping();
        },
        onSessionComplete: (session) => {
          if (!this.profileMgr || !session) return;
          const profile = this.profileMgr.getCurrentProfile();
          if (!profile) return;
          if (!profile.interrogationStats || typeof profile.interrogationStats !== "object") {
            profile.interrogationStats = {
              sessionsCompleted: 0,
              totalScore: 0,
              lastScore: 0,
              lastCompletedAt: null,
            };
          }
          profile.interrogationStats.sessionsCompleted += 1;
          profile.interrogationStats.totalScore += Number(session.score || 0);
          profile.interrogationStats.lastScore = Number(session.score || 0);
          profile.interrogationStats.lastCompletedAt = session.completedAt || Date.now();
          if (typeof this.profileMgr.saveProfile === "function") {
            this.profileMgr.saveProfile();
          } else if (typeof this.profileMgr.save === "function") {
            this.profileMgr.save();
          }
          if (typeof this.updateStatsDisplay === "function") {
            this.updateStatsDisplay();
          }
          if (typeof this.maybeShowBackupReminderToast === "function") {
            this.maybeShowBackupReminderToast();
          }
        },
      });
    }

    const saveInterrRectToProfile = (dialogEl) => {
      if (!dialogEl || !this.profileMgr) return;
      const profile = this.profileMgr.profile || this.profileMgr.getCurrentProfile?.();
      if (!profile) return;
      const l = parseInt(dialogEl.style.left, 10);
      const t = parseInt(dialogEl.style.top, 10);
      const w = parseInt(dialogEl.style.width, 10);
      const h = parseInt(dialogEl.style.height, 10);
      if (!Number.isNaN(l)) profile.InterrLeft = l;
      if (!Number.isNaN(t)) profile.InterrTop = t;
      if (!Number.isNaN(w)) profile.InterrWidth = w;
      if (!Number.isNaN(h)) profile.InterrHeight = h;
      if (typeof this.profileMgr.saveProfile === "function") {
        this.profileMgr.saveProfile();
      } else if (typeof this.profileMgr.save === "function") {
        this.profileMgr.save();
      }
    };

    const dialog = document.getElementById("interrogationDialog");
    const header = document.getElementById("interrogationWindowHeader");
    if (dialog && this.windowMgr && !dialog.dataset.interrWindowBound) {
      dialog.dataset.interrWindowBound = "1";
      if (header) {
        this.windowMgr.makeDraggable(dialog, header, (x, y) => {
          const profile = this.profileMgr?.profile || this.profileMgr?.getCurrentProfile?.();
          if (profile) {
            profile.InterrLeft = x;
            profile.InterrTop = y;
            if (typeof this.profileMgr.saveProfile === "function") {
              this.profileMgr.saveProfile();
            } else if (typeof this.profileMgr.save === "function") {
              this.profileMgr.save();
            }
          }
        });
      }
      this.windowMgr.makeResizable(
        dialog,
        () => {
          saveInterrRectToProfile(dialog);
          if (this.interrogationUI && typeof this.interrogationUI.handleResize === "function") {
            this.interrogationUI.handleResize();
          }
        },
        620,
        440,
      );

      const btnMax = document.getElementById("btnInterrogationMaximize");
      if (btnMax) {
        btnMax.addEventListener("click", () => {
          if (!dialog.classList.contains("window-fullscreen")) {
            const rect = dialog.getBoundingClientRect();
            this.prevInterrogationRect = {
              left: dialog.style.left || `${Math.round(rect.left)}px`,
              top: dialog.style.top || `${Math.round(rect.top)}px`,
              width: dialog.style.width || `${Math.round(rect.width)}px`,
              height: dialog.style.height || `${Math.round(rect.height)}px`,
            };
            dialog.classList.add("window-fullscreen");
            if (typeof document !== "undefined" && document.body) {
              document.body.style.overflow = "hidden";
            }
            btnMax.innerText = "🗗 Riduci";
            btnMax.title = "Ripristina dimensioni precedenti";
          } else {
            dialog.classList.remove("window-fullscreen");
            if (typeof document !== "undefined" && document.body) {
              document.body.style.overflow = "";
            }
            if (this.prevInterrogationRect) {
              dialog.style.left = this.prevInterrogationRect.left;
              dialog.style.top = this.prevInterrogationRect.top;
              dialog.style.width = this.prevInterrogationRect.width;
              dialog.style.height = this.prevInterrogationRect.height;
            }
            btnMax.innerText = "⛶ Ingrandisci";
            btnMax.title = "Massimizza / Schermo intero (o ripristina)";
            this.windowMgr.clampWindowToViewport(dialog, false);
            saveInterrRectToProfile(dialog);
          }
          if (this.interrogationUI && typeof this.interrogationUI.handleResize === "function") {
            this.interrogationUI.handleResize();
          }
        });
      }

      const btnResetLayout = document.getElementById("btnInterrogationResetLayout");
      if (btnResetLayout) {
        btnResetLayout.addEventListener("click", () => {
          this.resetInterrogationWindowLayout(true);
        });
      }
    }

    const btnOpen = document.getElementById("btnOpenInterrogation");
    if (btnOpen && !btnOpen.dataset.interrOpenBound) {
      btnOpen.dataset.interrOpenBound = "1";
      btnOpen.addEventListener("click", () => {
        this.openInterrogationModal();
      });
    }
  },

  resetInterrogationWindowLayout(saveToProfile = true) {
    const dialog = document.getElementById("interrogationDialog");
    const btnMax = document.getElementById("btnInterrogationMaximize");
    if (!dialog) return;

    dialog.classList.remove("window-fullscreen");
    if (typeof document !== "undefined" && document.body) {
      document.body.style.overflow = "";
    }

    const vpW = (typeof window !== "undefined" && window.innerWidth) || 1280;
    const vpH = (typeof window !== "undefined" && window.innerHeight) || 800;
    const w = Math.max(620, Math.min(1280, vpW - 40));
    const h = Math.max(440, Math.min(760, vpH - 90));
    const left = Math.max(10, Math.round((vpW - w) / 2));
    const top = Math.max(60, Math.round((vpH - h) / 2));

    dialog.style.left = left + "px";
    dialog.style.top = top + "px";
    dialog.style.width = w + "px";
    dialog.style.height = h + "px";
    dialog.style.maxWidth = "98vw";
    dialog.style.maxHeight = "none";

    if (btnMax) {
      btnMax.innerText = "⛶ Ingrandisci";
      btnMax.title = "Massimizza / Schermo intero (o ripristina)";
    }

    if (this.windowMgr) {
      this.windowMgr.clampWindowToViewport(dialog, false);
    }

    const profile = this.profileMgr?.profile || this.profileMgr?.getCurrentProfile?.();
    if (profile) {
      profile.InterrLeft = parseInt(dialog.style.left, 10) || left;
      profile.InterrTop = parseInt(dialog.style.top, 10) || top;
      profile.InterrWidth = parseInt(dialog.style.width, 10) || w;
      profile.InterrHeight = parseInt(dialog.style.height, 10) || h;
      if (saveToProfile) {
        if (typeof this.profileMgr.saveProfile === "function") {
          this.profileMgr.saveProfile();
        } else if (typeof this.profileMgr.save === "function") {
          this.profileMgr.save();
        }
      }
    }

    if (this.interrogationUI && typeof this.interrogationUI.handleResize === "function") {
      this.interrogationUI.handleResize();
    }
  },

  async openInterrogationModal() {
    if (!this.interrogationUI) {
      this.setupInterrogationControls();
    }
    const modal = document.getElementById("interrogationModal");
    const dialog = document.getElementById("interrogationDialog");
    if (modal && this.windowMgr) {
      this.windowMgr.bringModalToFront(modal);
    }

    if (dialog) {
      const profile = this.profileMgr?.profile || this.profileMgr?.getCurrentProfile?.();
      if (dialog.classList.contains("window-fullscreen")) {
        if (typeof document !== "undefined" && document.body) {
          document.body.style.overflow = "hidden";
        }
      } else if (
        profile &&
        Number.isFinite(Number(profile.InterrWidth)) &&
        Number.isFinite(Number(profile.InterrHeight)) &&
        Number(profile.InterrWidth) >= 620 &&
        Number(profile.InterrHeight) >= 440
      ) {
        dialog.style.left = (Number.isFinite(Number(profile.InterrLeft)) ? Number(profile.InterrLeft) : 40) + "px";
        dialog.style.top = (Number.isFinite(Number(profile.InterrTop)) ? Number(profile.InterrTop) : 60) + "px";
        dialog.style.width = Number(profile.InterrWidth) + "px";
        dialog.style.height = Number(profile.InterrHeight) + "px";
        dialog.style.maxWidth = "none";
        dialog.style.maxHeight = "none";
        this.windowMgr?.clampWindowToViewport(dialog, false);
      } else {
        this.resetInterrogationWindowLayout(false);
      }
    }

    if (this.interrogationUI) {
      await this.interrogationUI.open();
      if (dialog && !dialog.classList.contains("window-fullscreen")) {
        this.windowMgr?.clampWindowToViewport(dialog, false);
      }
      if (typeof this.interrogationUI.handleResize === "function") {
        this.interrogationUI.handleResize();
      }
    }
  },
});
