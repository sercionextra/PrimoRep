# Piano d'integrazione Backend INTERROGAZIONE — v1.2

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.24  
**Stato:** piano esecutivo aggiornato; perimetro A approvato; catalogo e PRNG verificati; hardening offline v6.24 realizzato; backend Interrogazione non ancora integrato  
**Stack vincolante:** JavaScript classico, script `defer`, DOM e storage browser nativi  
**Documenti di riferimento:**
- `Specifica_PRNG_Interrogazione_v1.0.md` e `Specifica_PRNG_Interrogazione_test_vectors_v1.0.json`
- `Contratti_Backend_Interrogazione_v1.4.md`
- `Schema_IndexedDB_Interrogazione_v1.3.md`
- `Motore_Selezione_Interrogazione_v1.2.md`
- `Matrice_Tracciabilita_Interrogazione_v1.2.md`
- `HANDOFF TECNICO INTERROGAZIONE v1.0`
- `SPECIFICA TECNICA INTERROGAZIONE v1.0`
- `Contratti_Backend_Interrogazione_v1.4.md`
- `Schema_IndexedDB_Interrogazione_v1.3.md`
- `Decisione_Quote_Adattive_D77-D80_v1.1.md`
- `Catalogo_QWERTY_Italiano_v1.0.md` e seed JSON
- `Catalogo_Domande_Interrogazione_v1.0.md` e JSON
- `Motore_Selezione_Interrogazione_v1.2.md` e vettori JSON
- `Motore_Conoscenza_Interrogazione_v1.0.md` e vettori JSON
- `Motore_Sessione_Interrogazione_v1.0.md` e vettori JSON

---

## 1. Obiettivo

Definire l'ordine d'integrazione e i gate di qualità necessari per introdurre INTERROGAZIONE nella baseline senza alterare le funzionalità esistenti. Il backend deve poter essere verificato in isolamento prima del collegamento alla UI.

L'implementazione è autorizzata nel perimetro A e nel rispetto dei vincoli di sicurezza. I nomi dei file proposti sono organizzativi: prima di crearli si verifica la compatibilità con i contratti aggiornati e con le convenzioni effettive del repository. La baseline v6.23 resta immutata; il ramo di lavoro v6.24 contiene il primo hardening offline.

## 2. Stato verificato della baseline

L'ispezione della directory `/workspace/TenFingersTypingTrainer_v6.24` conferma:

- applicazione JavaScript senza `package.json` e senza framework;
- caricamento mediante script classici con attributo `defer` e ordine esplicito in `index.html`;
- dominio in `js/domain`, motori in `js/engines`, persistenza profili in `js/profiles`, statistiche digitazione in `js/analytics`, controller in `js/app/controller`;
- avvio da `js/app/bootstrap.js`, che costruisce `AppController` al `DOMContentLoaded`;
- `ProfileManager` persiste profili e impostazioni in LocalStorage;
- `StatisticsManager` è dedicato alle statistiche di digitazione e non deve essere riutilizzato come archivio della conoscenza INTERROGAZIONE;
- non è presente un repository IndexedDB né un dominio INTERROGAZIONE nella baseline;
- i test esistenti sono script Node autonomi nella directory `tests`.

### 2.1 Baseline testata

Esecuzione completata con Node.js v22.16.0:

- `runtime-smoke.js`: superato;
- `static-check.js`: superato;
- `test-dictation-adaptive.js`: superato;
- `test-dictation-config-dialog.js`: 7 controlli superati;
- `test-fonemi-delete.js`: superato;
- `test-fonemi-length.js`: superato;
- `test-instant-speed-pin.js`: superato;
- `test-window-stacking.js`: 26 controlli superati;
- `test-zoom-buttons.js`: superato.

La checklist browser `tests/REGRESSION_CHECKLIST.md` resta da eseguire manualmente. I test Node non sostituiscono il collaudo browser.

## 3. Architettura target e confini

I componenti logici restano separati:

1. **InterrogationRepository** — apertura IndexedDB, transazioni, query, idempotenza, concorrenza e recovery.
2. **InterrogationCatalog** — lettura/validazione del catalogo versionato, relazioni, candidate e definizioni.
3. **InterrogationKnowledge** — proiezione degli eventi, decadimento, affidabilità, classificazioni, priorità e calendario.
4. **InterrogationSelector** — selezione pura casuale/adattiva/manuale e calcolo quote.
5. **InterrogationSessionManager** — ciclo di vita, snapshot, valutazione, punteggio, avanzamento e chiusura.
6. **UI INTERROGAZIONE** — configurazione, visualizzazione, acquisizione risposta e riepiloghi; nessuna regola di conoscenza o selezione duplicata nella UI.

Dipendenze consentite:

- Catalog e Knowledge possono leggere dal Repository attraverso API esplicite.
- Selector riceve input già normalizzati e snapshot coerenti; non accede direttamente allo storage.
- SessionManager orchestra Catalog, Knowledge, Selector e Repository.
- UI invoca SessionManager e presenta risultati; non scrive direttamente negli object store.
- `StatisticsManager` rimane indipendente.

## 4. Sequenza d'implementazione vincolante

### Fase 0 — Consolidamento contratti e gate preliminari

Prima dell'implementazione sono stati eseguiti questi consolidamenti:

- contratti backend v1.4 riallineati allo schema IndexedDB v1.3;
- perimetro A approvato: 52 tasti fisici verificati, catalogo parziale dichiarato;
- manifest `Candidati_Interrogazione_v1.1.json` validato: 225 candidate univoci, 445 definizioni attive, 5 template, zero riferimenti mancanti;
- PRNG `xoshiro128**` v1.0, seed `hex-128be`, rejection sampling, ordinamento canonico e Fisher–Yates verificati con 16 vettori indipendenti in Python e JavaScript;
- pesi consultazione/errore mantenuti senza modifica; fattore consolidamento non disponibile escluso con rinormalizzazione;
- baseline v6.24 creata con CSP restrittiva, guard runtime e test statici anti-network; collaudo browser ancora aperto;
- policy calendario 1/3/7/14/30/60 giorni ancora proposta: non implementare la modalità adattiva finché non viene confermata.

**Gate 0:** chiuso per catalogo A, PRNG documentale e vincoli di sicurezza statici. Restano aperti calendario adattivo, test browser, IndexedDB reale e recovery cross-storage.

### Fase 1 — Repository IndexedDB e test di persistenza

Implementare prima il repository, isolato dalla UI:

- apertura database, creazione store e indici;
- upgrade versionato e gestione `versionchange` / `blocked`;
- wrapper transazionali con completamento/abort osservabile;
- CRUD vincolato a `profileId`;
- receipt idempotenti per `operationId`;
- controllo ottimistico di `recordVersion`;
- transazioni atomiche per `recordOutcome`, creazione sessione, sospensione, ripresa, abbandono, completamento e correzioni;
- recovery delle operazioni a fasi tra LocalStorage e IndexedDB;
- export/import e cancellazione profilo secondo lo schema.

Non introdurre transazioni finte che simulino atomicità tra LocalStorage e IndexedDB: il protocollo deve usare marker persistenti, fasi verificabili e recupero idempotente.

**Gate 1:** test IndexedDB superati su browser reale; abort non lascia scritture parziali; ripetizione della stessa operationId non duplica eventi; profili distinti non si contaminano.

### Fase 2 — Catalogo e candidate espliciti

Implementare caricamento, validazione e risoluzione di:

- versioni catalogo;
- elementi fisici e identità semantiche;
- relazioni;
- definizioni di sotto-quesito;
- template di domanda principale;
- candidate materializzati e loro sotto-quesiti ordinati.

Il catalogo approvato per la prima release contiene 52 tasti fisici, 111 mapping carattere, 62 ID SVG e 60 coordinate anatomiche. Il manifest `Candidati_Interrogazione_v1.1.json` contiene 225 candidate espliciti: 10 HOME_ROW, 52 TASTO, 111 CARATTERE e 52 DITO. Le 445 definizioni attive sono tutte referenziate. I 53 elementi esclusi dal perimetro A restano fuori senza inferenze.

**Gate 2:** nessun candidate può essere selezionato se non è presente, attivo, versionato e validato. Le lacune del layout restano escluse; niente completamento per inferenza.

### Fase 3 — Motore della conoscenza puro

Separare il calcolo in funzioni pure testabili:

- ricostruzione della proiezione da eventi e correzioni append-only;
- decadimento esponenziale emivita 60 giorni;
- esposizioni equivalenti e affidabilità prudenziale;
- fattori di debolezza e indice composito;
- correzione dell'indice verso il neutro 50;
- classificazioni e aggregazioni di categoria;
- priorità temporanee delle consultazioni;
- calendario e `nextReviewAt`.

La persistenza della nuova proiezione avviene tramite Repository e non dentro le funzioni matematiche.

**Gate 3:** vettori numerici superati; ricostruzione da eventi produce la stessa proiezione; esposizione, consultazione e visualizzazione sono distinte; ricalcoli non modificano gli eventi immutabili.

### Fase 4 — Motore di selezione puro

Implementare in ordine:

1. normalizzazione e validazione input;
2. preparazione pool e filtri;
3. PRNG deterministico versionato;
4. casuale pura;
5. quote categoria e quote adattive interne;
6. budget globale 10 punti percentuali, tetto individuale 20% della quota base, redistribuzione e quota neutra;
7. conversione a conteggi interi con maggiori resti e spareggi deterministici;
8. priorità consultazioni senza violare quote;
9. selezione manuale con duplicati vietati salvo opt-in esplicito.

Il Selector non registra eventi e non scrive nel Repository. L'eventuale consumo delle priorità deve essere coordinato dal SessionManager nella transazione di creazione sessione.

**Gate 4:** vettori PRNG e di selezione eseguiti; test di proprietà superati; somme 100%; conteggi interi corretti; nessun candidato duplicato fuori dall'eccezione manuale; stesso input/seed/versioni produce lo stesso output. La modalità adattiva resta disabilitata fino alla conferma della policy calendario.

### Fase 5 — Motore di sessione

Implementare:

- creazione sessione e snapshot atomico di configurazione, catalogo, algoritmo, candidate e sotto-quesiti;
- gestione stati e transizioni;
- conferma esplicita della risposta prima della valutazione;
- `recordOutcome` atomico per evento, conoscenza, punteggio, avanzamento e receipt;
- consultazione come esito dedicato;
- non risposta senza evento di errore;
- sospensione e ripresa dallo snapshot;
- abbandono con conservazione risultati;
- completamento solo dopo conferma esplicita;
- recupero dopo reload o crash.

La regola di una sola sessione sospesa per profilo deve essere applicata nel repository. Non estendere il vincolo a tutte le sessioni `in-progress` finché non esiste una decisione funzionale esplicita.

**Gate 5:** test di transizione, idempotenza, atomicità, sospensione/ripresa e recovery superati.

### Fase 6 — Integrazione controller e UI

Solo dopo i gate backend:

- aggiungere la UI INTERROGAZIONE senza modificare il flusso di digitazione;
- collegare configurazione profilo, scelta tipologia/modalità, numero domande e selezione manuale;
- gestire avviso di disponibilità insufficiente con procedi/annulla;
- presentare prompt e sotto-quesiti con risposte appropriate al tipo;
- distinguere conferma, consultazione, salto, sospensione, abbandono e completamento;
- mostrare riepilogo punteggio e classificazioni senza esporre dettagli tecnici interni;
- rendere accessibili storico, progressi e calendario senza consentire alterazioni dirette dello storico.

Gli script restano classici con `defer`. I nuovi file devono essere inseriti in `index.html` nell'ordine di dipendenza, prima dei consumer e prima del bootstrap. Non convertire a ES modules.

**Gate 6:** test UI e browser superati; nessuna regressione alle modalità esistenti.

### Fase 7 — Export/import, migrazione e resilienza

- definire un pacchetto portabile con versione formato e checksum;
- validare tutto il pacchetto prima di applicare modifiche;
- applicare import con strategia atomica/recuperabile e rollback;
- gestire conflitti di identità semantica e versioni catalogo senza trasferire automaticamente conoscenza;
- verificare quota storage, database bloccato, upgrade concorrente, scheda chiusa durante transazione e profilo eliminato;
- documentare recovery e messaggi utente.

**Gate 7:** test import/export, rollback, recovery e compatibilità superati.

### Fase 8 — Rilascio e documentazione

- aggiornare versione applicativa secondo il processo di release del progetto;
- aggiornare changelog, architettura, manuale e HELP soltanto per comportamenti visibili all'utente;
- mantenere i dettagli interni nei documenti tecnici;
- eseguire tutti i test Node, i controlli anti-network e la checklist browser completa;
- verificare assenza di richieste remote, telemetria e uso di voci vocali non locali;
- verificare installazione/avvio da `index.html`, profili esistenti e assenza di perdita dati.

**Gate 8:** tutti i gate precedenti superati, documentazione coerente, nessuna regressione e piano di rollback pronto.

## 5. Gate residui e decisioni

| ID | Questione | Stato | Criterio di chiusura |
|---|---|---|---|
| B01 | PRNG deterministico | **Documentale chiuso** | 16 vettori verificati; implementazione e integrazione browser ancora da testare |
| B02 | Candidate espliciti | **Chiuso** | Manifest v1.1: 225 candidate univoci e tutti i riferimenti risolti |
| B03 | Copertura layout 105 tasti | **Fuori ambito A** | 52 tasti verificati autorizzati; 53 elementi esclusi, nessuna inferenza |
| B04 | Rapporto consultazione/errore | **Conservato** | Pesi invariati; effetto composito 31,25% documentato; nessuna modifica arbitraria |
| B05 | Calendario consolidamento | **Bloccante per adattivo** | Conferma della policy per corretto, errato, consultato e non risposta |
| B06 | Sessioni attive concorrenti | **Conservato** | Non introdurre limite globale `in-progress`; una sola sospesa per profilo |
| B07 | Modificatori destri | **Fuori ambito A** | Modificatori esclusi dal catalogo attivo; nessuna correzione della mappa esistente |
| B08 | Coerenza schema/contratti | **Chiuso documentale** | Contratto v1.4 riallineato allo schema v1.3; test runtime ancora necessari |
| S01 | Isolamento offline | **Static/runtime locale** | CSP e guard presenti; collaudo browser e traffico effettivo da completare |

B03 e B07 non bloccano la prima release A. B05 blocca soltanto l'attivazione della modalità adattiva; la modalità casuale e quella manuale possono procedere sul catalogo verificato. B01, B02 e B08 sono sufficientemente definiti per l'implementazione, ma richiedono test applicativi prima del rilascio.

## 6. Strategia di test

### 6.1 Livello unitario

- funzioni pure di normalizzazione, quote, PRNG, conoscenza, transizioni e punteggio;
- test con vettori JSON versionati;
- test di proprietà per quote, conteggi, classificazioni e invarianti;
- test di identità semantica e versioni catalogo.

### 6.2 Livello repository

- IndexedDB reale in browser headless/ambiente browser di test;
- transazioni multi-store, abort, chiusura connessione, upgrade e concorrenza;
- operationId ripetuto e operationId in conflitto;
- due schede sullo stesso profilo e su profili differenti;
- crash/reload in ogni fase del protocollo LocalStorage/IndexedDB.

### 6.3 Livello integrazione

- creazione sessione → risposta → evento → knowledge state → punteggio;
- consultazione → priorità successiva;
- sessione sospesa → reload → ripresa identica;
- abbandono e completamento esplicito;
- import/export e cancellazione profilo;
- catalogo aggiornato durante sessione sospesa.

### 6.4 Regressione

A ogni fase eseguire i nove test baseline elencati al §2.1. Prima del rilascio eseguire anche l'intera `tests/REGRESSION_CHECKLIST.md` su browser aggiornato. I test INTERROGAZIONE devono essere aggiunti senza rimuovere o indebolire quelli esistenti.

## 7. Strategia di versionamento e contenimento del rischio

- Nuovi file sorgente e documentazione ricevono una nuova versione secondo le convenzioni di progetto.
- Le modifiche alla baseline sono circoscritte; nessun refactoring generale del controller o di `ProfileManager`.
- Non riutilizzare `StatisticsManager` per la conoscenza didattica.
- Non cambiare storage dei profili esistenti: IndexedDB ospita il nuovo dominio, con protocollo esplicito per le impostazioni profilo e le operazioni cross-storage.
- Non modificare l'ordine esistente degli script se non per inserire i nuovi script nelle posizioni necessarie.
- Ogni fase produce test ripetibili e una baseline verde prima di procedere alla successiva.
- In caso di fallimento di un gate, fermare l'integrazione al confine della fase; non compensare con logica duplicata nella UI.

## 8. Esito e prossimo deliverable

Il gate documentale PRNG è chiuso con `Specifica_PRNG_Interrogazione_v1.0.md`, i relativi 16 vettori e le revisioni coordinate di selettore, contratti, schema e matrice di tracciabilità. La baseline esistente è verde sui test Node disponibili, ma il collaudo browser resta pendente.

Il prossimo deliverable tecnico è la **chiusura dei gate di catalogo e delle decisioni residue**: inventario candidate materializzati B02, completamento verificato del catalogo B03 e risoluzione documentata del mapping dei modificatori destri B07. In parallelo vanno formalizzate la policy calendario B05, la conseguenza matematica della consultazione B04 e il fattore consolidamento. La matrice v1.1 aggiorna il tracciamento dei contratti e dello schema; B08 è chiuso sul piano strutturale, ma i test repository/browser restano da eseguire.

**Nessun sorgente applicativo è stato modificato in questa fase.**


## Revisione v1.1 — Gate PRNG

La v1.1 recepisce la chiusura documentale del PRNG e i riferimenti contrattuali aggiornati. Non autorizza l'implementazione automatica dei sorgenti: la sequenza per fasi e i gate di qualità restano obbligatori. Nessun sorgente applicativo è stato modificato.


## 9. Revisione v1.2 — perimetro A e hardening offline

La v1.2 recepisce l'approvazione dell'utente per la prima release sui 52 tasti verificati e l'obbligo di isolamento rigoroso B. La baseline v6.24 è stata creata come fondazione di sicurezza: CSP senza `unsafe-inline`/`unsafe-eval`, `connect-src 'none'`, guard runtime locale, test statici anti-risorse remote e sintesi vocale limitata a `localService === true`.

Le suite Node della v6.24 sono state rieseguite con esito positivo. Il test browser effettivo non è stato eseguito in questo ambiente e rimane obbligatorio prima della distribuzione.

Il backend Interrogazione non è ancora integrato nella v6.24. La fase successiva implementerà prima catalogo/PRNG/selezione random e manuale sul manifest v1.1, poi repository IndexedDB e conoscenza; la modalità adattiva verrà attivata soltanto dopo la conferma della policy calendario.
