/* TenFingersTypingTrainer v6.0 — controller core. I metodi sono caricati dai moduli controller/ successivi. */
// =======================================================
// APP CONTROLLER (Coordinatore Principale e Macchina a Stati)
// =======================================================
class AppController {
  constructor(lessons, demoProfile, customDefault, fonemiCorpus) {
      this.standardLessons = lessons || [];
      this.customLessons = [];
      this.activeLessonsSource = "standard"; // "standard" or "custom"
      this.lessons = this.standardLessons;
      this.profileMgr = new ProfileManager(demoProfile, customDefault);
      this.audio = new AudioEngine();
      this.phonemeEng = new PhonemeEngine(fonemiCorpus);
      this.dictation = new DictationEngine(); // Motore Dettatura Vocale (v.3.8)
      this.typingEng = new TypingEngine(
        this.lessons,
        this.profileMgr,
        this.audio,
        this.phonemeEng,
      );
      this.visual = new VisualRenderer();
      this.windowMgr = new WindowManager();
      this.statsMgr = new StatisticsManager(this.profileMgr);
      this.prevStatsRect = null;
      this._wrongBadgeTimer = null;
  
      // Macchina a stati rigorosa per modificatori differiti (v.4.8 - Opzione 2)
      this.modifierSession = {
        activeModifiers: new Set(), // Modificatori non attesi attualmente trattenuti ("Control", "Shift", "Alt")
        expectedModsActive: new Set(), // Modificatori necessari per il carattere target corrente
        shortcutExecuted: false, // Diventa true SOLO quando viene premuto un vero tasto di comando
        abandonErrorReported: false, // Previene doppi errori sul rilascio del secondo tasto dell'accordo
      };
    }
}
