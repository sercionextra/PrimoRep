# Architettura — TenFingersTypingTrainer v6.8

## Obiettivo

La release v6.8 estende il paradigma di "Ancoraggio Intelligente" (Pin/Pinned) già collaudato sulla finestra "10 Fingers (Mani)" anche alla finestra flottante "Velocità Istantanea". Introduce il pulsante "Pin/Pinned" nell'header della finestra, sincronizza la modalità di posizionamento relativo al blocco di digitazione (`cardBottom`) e armonizza il layout predefinito in modo che la finestra tachimetrica si collochi in primo piano a copertura dell'intera area congiunta occupata da Tastiera virtuale e finestra Mani.

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo con impostazioni di ancoraggio Mani e Velocità Istantanea |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente con supporto `InstantSpeedPinned` e `InstantSpeedOffsetTop` |
| `domain/phoneme-engine.js` | Generazione/gestione degli esercizi fonemici |
| `ui/window-manager.js` | Finestre flottanti, drag & drop e vincoli al viewport |
| `engines/typing-engine.js` | Motore di digitazione, buffer tachimetrico e ricalcolo Media Mobile |
| `ui/visual-renderer.js` | Tastiera virtuale, rendering grafico mani e feedback |
| `engines/dictation-engine.js` | Dettatura vocale e sintesi vocale continua |
| `shared/export-utils.js` | Timestamp e utility di esportazione profili |
| `analytics/statistics-manager.js` | Metriche, grafici di velocità e istogrammi |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.8) |
| `app/controller/metodi-finestre-layout.js` | Gestione layout, ancoraggio intelligente (`updateInstantSpeedWindowPosition`, `updateInstantSpeedPinButtonUI`, `resetInstantSpeedDefaultPosition`) |
| `app/controller/metodi-*.js` | Metodi del controller per profili, audio, scorciatoie, input e statistiche |
| `app/bootstrap.js` | Bootstrap e registrazione eventi DOM |

## Modello di Ancoraggio (Pin/Pinned) per Velocità Istantanea

La finestra "Velocità Istantanea" adotta lo stesso sistema a doppio stato geometrico della finestra "10 Fingers (Mani)":

1. **Stato Pinned (`InstantSpeedPinned = true`):**
   - **Coordinata Orizzontale:** Relativa al margine sinistro del blocco applicativo principale (`origin = this.getAppOrigin().left`), calcolata come `Math.round(origin.left + relLeft)`.
   - **Coordinata Verticale:** Agganciata dinamicamente alla base reale della scheda di digitazione (`cardBottom = typingCard.getBoundingClientRect().bottom + window.scrollY` e `metricsGrid`), sommando l'offset relativo `InstantSpeedOffsetTop`: `top = Math.round(cardBottom + offsetTop)`.
   - **Reattività al reflow:** Durante lo zoom del browser, la variazione di altezza della finestra o la visualizzazione/occultamento di elementi della scheda (Testo Guida, Input, Errori), la finestra trasla verticalmente in modo solidale alla scheda, senza sovrapposizioni spurie o distacchi.

2. **Stato Unpinned (`InstantSpeedPinned = false`):**
   - La finestra si muove liberamente nello spazio pagina rispetto al top del container (`Math.round(origin.top + relTop)`).

3. **Drag & Resize:**
   - Durante il trascinamento manuale dell'header, se la finestra è Pinned viene aggiornato e persistito il delta relativo `InstantSpeedOffsetTop = Math.round(y - cardBottom)` e `InstantSpeedLeft = Math.round(x - origin.left)`.
   - Durante il ridimensionamento perimetrale tramite le maniglie, le dimensioni (`width`, `height`) e le coordinate relative vengono salvate in modo atomico nel profilo utente attivo.

4. **Layout Predefinito a Copertura Totale (Foreground Overlay):**
   - Tramite il pulsante "Default" (`#btnInstantSpeedDefaultPos`), la finestra assume una larghezza di 1240 px (estesa sull'unione dell'ingombro di Tastiera e finestra Mani) e un'altezza di 340 px con `z-index: 1010`, collocandosi in primo piano a totale copertura di entrambi gli elementi sottostanti.
