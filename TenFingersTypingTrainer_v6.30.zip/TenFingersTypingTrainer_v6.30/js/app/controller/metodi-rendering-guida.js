/* TenFingersTypingTrainer v6.24 — AppController: rendering guida senza attributi style inline. */
(() => {
  const controllerMethods = {
// =======================================================
  // HELPER FORMATTAZIONE CARATTERI SPECIALI (GUIDA E INPUT)
  // =======================================================

  // Traduce i caratteri speciali per la visualizzazione a video nel Testo Guida
  formatGuideChar(ch) {
    if (ch === " ") return "␣";
    if (ch === "®" || ch === "\n") return "↵\n";
    if (ch === "→" || ch === "\t") return "⇥";
    return ch;
  },

// Formatta il testo digitato per la visualizzazione nella textarea
  // (converte i token interni ® e → in ritorni a capo reali e tabulazioni)
  formatInputDisplay(text) {
    if (!text) return "";
    return text.replace(/®/g, "\n").replace(/→/g, "\t");
  },

// =======================================================
  // HELPER FORMATTAZIONE CARATTERI SPECIALI (GUIDA E INPUT)
  // =======================================================

  // Traduce i caratteri speciali per la visualizzazione nei badge di errore
  formatGuideChar(ch) {
    if (ch === " ") return "␣";
    if (ch === "®" || ch === "\n") return "↵\n";
    if (ch === "→" || ch === "\t") return "⇥";
    return ch;
  },

// Renderizza un segmento del Testo Guida incapsulando lo spazio in uno span .sym-space
  // con aggiunta di <wbr> per consentire al browser di andare a capo subito dopo lo spazio
  // esattamente nello stesso punto in cui va a capo la casella di Input (a confine di parola intera)
  renderGuideSegment(text) {
    if (!text) return "";
    let html = "";
    for (const ch of text) {
      if (ch === " ") {
        html += '<span class="sym-space">␣</span><wbr>';
      } else if (ch === "®" || ch === "\n") {
        html += '<span class="sym-enter">↵</span>\n';
      } else if (ch === "→" || ch === "\t") {
        html += '<span class="sym-tab">⇥</span>';
      } else {
        html += htmlEscape(ch);
      }
    }
    return html;
  },

// Formatta il testo digitato per la visualizzazione nella textarea
  // (converte i token interni ® e → in ritorni a capo reali e tabulazioni)
  formatInputDisplay(text) {
    if (!text) return "";
    return text.replace(/®/g, "\n").replace(/→/g, "\t");
  },

// =======================================================
  // AGGIORNAMENTO DISPLAY TESTO GUIDA CON AUTO-SCROLL
  // =======================================================
  updateOriginDisplay() {
    const container = document.getElementById("originTextWrapper");
    const badge = document.getElementById("charTargetBadge");
    if (!container) return;

    if (this.typingEng.mode === 4) {
      container.innerHTML =
        '<span class="guide-free-mode-message">Digitazione libera in corso...</span>';
      if (badge) {
        badge.innerText = "LIBERA";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
      return;
    }

    const origin = this.typingEng.originText;
    const typed = this.typingEng.typedText;

    const matchLen = this.typingEng.getMatchLength();

    const partOk = origin.slice(0, matchLen);
    const numErrors = typed.length - matchLen;

    let guideHtml = "";
    if (partOk) {
      guideHtml += `<span class="char-typed-ok">${this.renderGuideSegment(partOk)}</span>`;
    }

    if (numErrors === 0) {
      if (matchLen < origin.length) {
        const targetChar = origin[matchLen];
        guideHtml += `<span class="char-current-target" id="currentTargetCharSpan">${this.renderGuideSegment(targetChar)}</span>`;
        const partRest = origin.slice(matchLen + 1);
        if (partRest) {
          guideHtml += `<span class="char-remaining">${this.renderGuideSegment(partRest)}</span>`;
        }
      }
    } else {
      const remainingChars = origin.slice(matchLen);
      let errorSubstring = "";
      let remainingAfterErrors = "";

      if (numErrors <= remainingChars.length) {
        errorSubstring = remainingChars.slice(0, numErrors);
        remainingAfterErrors = remainingChars.slice(numErrors);
      } else {
        const excess = numErrors - remainingChars.length;
        errorSubstring = remainingChars + " ".repeat(excess);
        remainingAfterErrors = "";
      }

      guideHtml += `<span class="char-error-target" id="currentTargetCharSpan">${this.renderGuideSegment(errorSubstring)}</span>`;

      if (remainingAfterErrors) {
        guideHtml += `<span class="char-remaining">${this.renderGuideSegment(remainingAfterErrors)}</span>`;
      }
    }

    container.innerHTML = guideHtml;

    // Auto-scroll per garantire la costante visibilità del carattere bersaglio
    const targetSpan = document.getElementById("currentTargetCharSpan");
    if (targetSpan) {
      const spanTop = targetSpan.offsetTop;
      const spanHeight = targetSpan.offsetHeight;
      const contHeight = container.clientHeight;
      if (
        spanTop + spanHeight > container.scrollTop + contHeight ||
        spanTop < container.scrollTop
      ) {
        container.scrollTop = Math.max(
          0,
          spanTop - Math.round(contHeight / 2) + Math.round(spanHeight / 2),
        );
      }
    }

    const targetChar = origin[matchLen] || "";
    if (badge) {
      if (this.typingEng.isCompleted) {
        badge.innerText = "FINITO";
        badge.style.background = "var(--success-bg)";
        badge.style.color = "var(--success-color)";
      } else if (numErrors > 0) {
        badge.innerText = "CORREGGI ⌫";
        badge.style.background = "#ef4444";
        badge.style.color = "#ffffff";
      } else if (targetChar === "®" || targetChar === "\n") {
        badge.innerText = "INVIO ↵";
        badge.style.background = "#059669";
        badge.style.color = "#ffffff";
      } else if (targetChar === "→" || targetChar === "\t") {
        badge.innerText = "TAB ⇥";
        badge.style.background = "#2563eb";
        badge.style.color = "#ffffff";
      } else if (targetChar === " ") {
        badge.innerText = "SPAZIO";
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else if (targetChar) {
        badge.innerText = targetChar;
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else {
        badge.innerText = "—";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
    }
  },

updateTargetKey() {
    const errorBadge = document.getElementById("handsCentralErrorBadge");
    const successBadge = document.getElementById("handsCentralSuccessBadge");

    // TEARDOWN STATO GUIDA PER MODALITÀ 4 (TYPING LIBERA)
    if (this.typingEng.mode === 4) {
      // Spegne unicamente il bersaglio lampeggiante guidato
      this.visual.setTargetChar(null);

      if (errorBadge) errorBadge.style.opacity = "0";
      if (successBadge) successBadge.style.opacity = "0";

      const handText = document.getElementById("handIndicatorText");
      if (handText && this.visual.activePhysicalKeys.size === 0) {
        handText.innerText = "Digitazione libera (nessuna guida)";
      }
      return;
    }

    if (this.typingEng.isCompleted) {
      this.visual.setTargetChar(null);
      this.visual.clearAllPhysicalFingers();

      if (errorBadge) errorBadge.style.opacity = "0";
      if (successBadge) successBadge.style.opacity = "1";
      return;
    } else {
      if (successBadge) successBadge.style.opacity = "0";
    }

    const matchLen = this.typingEng.getMatchLength();
    let targetChar;

    const hasPendingErrors = this.typingEng.typedText.length > matchLen;
    const isAutoCorrectON = !!this.profileMgr.profile?.AutomaticCorrection;

    if (hasPendingErrors && !isAutoCorrectON) {
      targetChar = "Backspace";
    } else {
      targetChar = this.typingEng.originText[this.typingEng.typedText.length];
    }

    this.visual.setTargetChar(targetChar);

    if (errorBadge && !isAutoCorrectON) {
      if (hasPendingErrors) {
        errorBadge.style.opacity = "1";
      } else {
        errorBadge.style.opacity = "0";
      }
    }
  },

showWrongLetterPopup(wrongChar) {
    const badge = document.getElementById("wrongCharFloatingBadge");
    if (!badge) return;
    badge.innerText = wrongChar === " " ? "SPAZIO" : wrongChar;

    const targetSpan =
      document.getElementById("currentTargetCharSpan") ||
      document.querySelector(".char-current-target");
    const container =
      document.querySelector(".typing-box-container") ||
      document.getElementById("originTextWrapper")?.parentElement;

    if (targetSpan && container) {
      const spanRect = targetSpan.getBoundingClientRect();
      const contRect = container.getBoundingClientRect();
      const centerX = spanRect.left - contRect.left + spanRect.width / 2;
      const topY = spanRect.top - contRect.top - 34;
      badge.style.left = `${Math.round(centerX)}px`;
      badge.style.top = `${Math.round(topY)}px`;
      badge.style.transform = "translateX(-50%)";
    }

    badge.classList.add("visible");
    if (this._wrongBadgeTimer) clearTimeout(this._wrongBadgeTimer);
    this._wrongBadgeTimer = setTimeout(
      () => badge.classList.remove("visible"),
      550,
    );
  },

// Commuta tra i due grafici della finestra Statistiche: 1. Istogramma e 2. Velocità (CTRL+SHIFT+7)
  switchStatsView() {
    const win = document.getElementById("statsFloatingWindow");
    if (!win) return;
    if (!win.classList.contains("window-visible")) {
      this.toggleStatsWindow(true);
      return;
    }
    const btnNavHist = document.getElementById("btnStatsNavHist");
    const btnNavSpeed = document.getElementById("btnStatsNavSpeed");
    if (btnNavSpeed && btnNavSpeed.classList.contains("active")) {
      btnNavHist?.click();
    } else {
      btnNavSpeed?.click();
    }
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
