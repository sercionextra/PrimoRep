# Checklist di regressione — v6.5

Eseguire in un browser aggiornato e verificare sia il comportamento UI sia la persistenza.

## Avvio e dati

- [ ] L'app si apre direttamente da `index.html` senza errori JavaScript.
- [ ] Il titolo della pagina e l'header mostrano la versione v6.5.
- [ ] La proprietà `app.version` nella console del browser restituisce "6.5".
- [ ] I profili esistenti caricati dal Local Storage restano accessibili e vengono aggiornati alla v6.5 al salvataggio.

## Metodo e input
- [ ] Verificare le sette modalità: PHRASES, RANDOM, FONEMI, ALL CHARS, TYPING, RANDOM THIS PHRASE, WEAKNESSES.
- [ ] Verificare mappatura dita, posizione di riposo e indicazioni visive.
- [ ] Verificare caratteri accentati, Shift, modificatori e combinazioni.
- [ ] Verificare spazi, Invio (`®`), Tab (`→`), Backspace e correzione progressiva.
- [ ] Verificare auto-correction attiva e disattivata.
- [ ] Verificare avanzamento, ripetizione e completamento frase.

## Voce e feedback
- [ ] Verificare audio feedback e relative opzioni.
- [ ] Verificare dettatura, velocità, voci italiane, maiuscole, apostrofi e spazi.
- [ ] Verificare replay e recupero dopo un errore.
- [ ] Verificare che il watchdog non lasci la dettatura bloccata.

## Finestre e visualizzazione

- [ ] Verificare che digitando una frase con la finestra Velocità Istantanea aperta compaia la curva a punti.
- [ ] Cliccare su ⚙ Parametri, modificare N (es. da 3 a 1 oppure da 3 a 7) e cliccare su Conferma.
- [ ] Verificare che la curva si ricalcoli e si rimodelli immediatamente a video su tutti i caratteri già battuti.
- [ ] Verificare che il tasto "x" e il tasto Escape chiudano regolarmente il modale e restituiscano il focus alla battuta.

## Statistiche e profili
- [ ] Verificare metriche di sessione, statistiche per carattere e grafico della velocità.
- [ ] Verificare filtri per modalità e intervallo temporale.
- [ ] Verificare selezione e cancellazione dei campioni: "Elimina non selezionati" cancella solo i campioni visibili nel grafico che rispettano i filtri attivi ma non appartengono alla selezione corrente, lasciando intatti i selezionati e l'archivio non filtrato.
- [ ] Verificare creazione, rinomina, cambio ed eliminazione profili.
- [ ] Verificare backup, esportazione e importazione.
- [ ] Verificare Editor Custom, formato titoli/separatori e token `®`/`→`.

## Accettazione finale
- [ ] Nessuna perdita di dati osservata.
- [ ] Nessuna funzione della v5.1 risulta rimossa o alterata.
- [ ] Manuale, guida HTML e applicazione sono coerenti.
