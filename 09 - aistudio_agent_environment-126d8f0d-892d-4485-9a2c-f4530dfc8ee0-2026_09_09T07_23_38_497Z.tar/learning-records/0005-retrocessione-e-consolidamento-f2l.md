# Difficoltà nell'esecuzione di F (R U R' U') F' e ritorno al secondo strato

Status: active
Riferimento: lessons/0004-il-secondo-strato.html

L'utente ha riscontrato un errore di esecuzione durante il passaggio alla croce gialla (`F (R U R' U') F'`), che ha compromesso lo stato del cubo o generato confusione procedurale. Come richiesto esplicitamente, si arretra alla Lezione 4 (Secondo Strato) per verificare lo stato di partenza e consolidare l'inserimento degli spigoli intermedi prima di ritentare l'ultimo strato.
