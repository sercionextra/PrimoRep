# Manuale Utente TenFingersTypingTrainer v6.40 (Novità Storico e Classifica Urgenza)

Questa guida descrive le nuove funzioni disponibili nella finestra **Mostra storico** dell'Interrogazione dalla versione 6.40.

## 1. Passare tra i due grafici nello Storico Interrogazioni
Quando apri **📈 Mostra storico** dalla finestra **🎓 Interrogazione**, nella barra del titolo compaiono due pulsanti:
- **📈 1. Storico**: mostra il grafico cronologico delle sessioni completate (andamento punteggi, % rendimento, filtri per data/ora, eliminazione campioni e ripetizione sessioni).
- **📊 2. Urgenza**: scorre al secondo grafico dedicato alla classifica dei tasti e delle dita che richiedono maggiore attenzione.

Puoi passare da un grafico all'altro cliccando i due pulsanti nella barra del titolo oppure scorrendo verticalmente con la rotellina del mouse.

## 2. Come leggere la Classifica Urgenza (Tasti e Dita)
Il grafico ordina automaticamente tutti i tasti della tastiera e le 10 dita dal **più urgente** (a sinistra) al **meno urgente** (a destra).

Ogni barra è composta da **5 fasce di colore diverso**, la cui altezza indica il peso di ciascuna motivazione:
- **Rosso — Errori (fino a 40 pt)**: errori commessi nelle interrogazioni precedenti.
- **Arancione — Consultazioni (fino a 25 pt)**: ricorso all'aiuto durante la risposta.
- **Viola — Ritardo Ripasso (fino a 20 pt)**: quesiti scaduti rispetto al calendario di ripasso consigliato.
- **Azzurro — Non Consolidato (fino a 15 pt)**: argomenti non ancora portati al livello massimo di padronanza.
- **Grigio — Scarsa Indagine (fino a 25 pt)**: tasti o dita interrogati poche volte o mai verificati.

## 3. Filtrare le motivazioni e gli elementi
- **Caselle delle motivazioni**: puoi spuntare o deselezionare una o più motivazioni per ricalcolare subito le altezze delle barre e l'ordine della classifica in base a ciò che vuoi allenare.
- **Filtro entità**: puoi scegliere se visualizzare **Tutti** (tasti e dita insieme), **Solo Tasti** oppure **Solo Dita**.

## 4. Dettagli e avvio di un'interrogazione mirata
- **Passaggio del mouse su una barra**: mostra nel riquadro inferiore il nome completo del tasto o del dito, il punteggio totale di urgenza, i singoli valori delle 5 motivazioni e il numero di verifiche già effettuate.
- **Click su una barra**: apre una finestra di conferma per avviare subito un'interrogazione mirata sui quesiti di quel tasto o di quel dito (se non è già presente una sessione sospesa da riprendere o abbandonare).
