/* TenFingersTypingTrainer v6.24 — blocco locale delle API di comunicazione e raccolta dati. */
(() => {
  "use strict";

  const blockedAttempts = [];
  const cspViolations = [];
  const root = window;

  const recordBlockedAttempt = (apiName) => {
    blockedAttempts.push({ api: apiName, timestamp: Date.now() });
  };

  const createBlockedError = (apiName) => {
    recordBlockedAttempt(apiName);
    const error = new Error(
      `Operazione bloccata: ${apiName} non è consentita in modalità offline.`,
    );
    error.name = "SecurityError";
    return error;
  };

  const createBlockedFunction = (apiName) => function () {
    throw createBlockedError(apiName);
  };

  const replaceGlobal = (name, replacement) => {
    try {
      Object.defineProperty(root, name, {
        configurable: true,
        enumerable: true,
        writable: true,
        value: replacement,
      });
      return true;
    } catch (error) {
      recordBlockedAttempt(`GUARD_INSTALL_FAILED:${name}`);
      return false;
    }
  };

  [
    "fetch",
    "XMLHttpRequest",
    "WebSocket",
    "EventSource",
    "Worker",
    "SharedWorker",
    "WebTransport",
    "RTCPeerConnection",
    "webkitRTCPeerConnection",
    "BroadcastChannel",
  ].forEach((apiName) => {
    if (typeof root[apiName] !== "undefined") {
      replaceGlobal(apiName, createBlockedFunction(apiName));
    } else if (apiName === "fetch" || apiName === "XMLHttpRequest") {
      // Definisce anche le primitive di rete assenti, evitando fallback futuri non controllati.
      replaceGlobal(apiName, createBlockedFunction(apiName));
    }
  });

  if (root.navigator) {
    try {
      Object.defineProperty(root.navigator, "sendBeacon", {
        configurable: true,
        value: createBlockedFunction("navigator.sendBeacon"),
      });
    } catch (error) {
      recordBlockedAttempt("GUARD_INSTALL_FAILED:navigator.sendBeacon");
    }

    if (root.navigator.serviceWorker) {
      try {
        Object.defineProperty(root.navigator.serviceWorker, "register", {
          configurable: true,
          value: createBlockedFunction("navigator.serviceWorker.register"),
        });
      } catch (error) {
        recordBlockedAttempt("GUARD_INSTALL_FAILED:navigator.serviceWorker.register");
      }
    }

    if (root.navigator.mediaDevices) {
      ["getUserMedia", "enumerateDevices"].forEach((methodName) => {
        try {
          Object.defineProperty(root.navigator.mediaDevices, methodName, {
            configurable: true,
            value: createBlockedFunction(`navigator.mediaDevices.${methodName}`),
          });
        } catch (error) {
          recordBlockedAttempt(`GUARD_INSTALL_FAILED:navigator.mediaDevices.${methodName}`);
        }
      });
    }

    if (root.navigator.geolocation) {
      ["getCurrentPosition", "watchPosition"].forEach((methodName) => {
        try {
          Object.defineProperty(root.navigator.geolocation, methodName, {
            configurable: true,
            value: createBlockedFunction(`navigator.geolocation.${methodName}`),
          });
        } catch (error) {
          recordBlockedAttempt(`GUARD_INSTALL_FAILED:navigator.geolocation.${methodName}`);
        }
      });
    }

    const blockNavigatorMethods = (target, apiPrefix, methodNames) => {
      if (!target) return;
      methodNames.forEach((methodName) => {
        if (typeof target[methodName] !== "function") return;
        try {
          Object.defineProperty(target, methodName, {
            configurable: true,
            value: createBlockedFunction(`${apiPrefix}.${methodName}`),
          });
        } catch (error) {
          recordBlockedAttempt(`GUARD_INSTALL_FAILED:${apiPrefix}.${methodName}`);
        }
      });
    };

    blockNavigatorMethods(root.navigator.clipboard, "navigator.clipboard", [
      "read",
      "readText",
      "write",
      "writeText",
    ]);
    blockNavigatorMethods(root.navigator, "navigator", ["share"]);
    blockNavigatorMethods(root.navigator.credentials, "navigator.credentials", [
      "get",
      "create",
    ]);
    blockNavigatorMethods(root.navigator.mediaDevices, "navigator.mediaDevices", [
      "getDisplayMedia",
    ]);

    [
      [root.navigator.bluetooth, "navigator.bluetooth", ["requestDevice"]],
      [root.navigator.usb, "navigator.usb", ["requestDevice"]],
      [root.navigator.serial, "navigator.serial", ["requestPort"]],
      [root.navigator.hid, "navigator.hid", ["requestDevice"]],
      [root.navigator.nfc, "navigator.nfc", ["scan", "write"]],
    ].forEach(([target, prefix, methods]) => {
      blockNavigatorMethods(target, prefix, methods);
    });
  }

  const nativeOpen = typeof root.open === "function" ? root.open.bind(root) : null;
  if (nativeOpen) {
    try {
      root.open = function (url, ...args) {
      let resolvedUrl;
      let helpUrl;
      try {
        resolvedUrl = new URL(String(url), root.location.href);
        helpUrl = new URL("help.html", root.location.href);
      } catch (error) {
        throw createBlockedError("window.open(invalid-url)");
      }

      const sameLocalDocument =
        resolvedUrl.protocol === helpUrl.protocol &&
        resolvedUrl.pathname === helpUrl.pathname &&
        resolvedUrl.search === "" &&
        resolvedUrl.hash === "";

      const sameOriginHelp =
        resolvedUrl.protocol !== "file:" &&
        resolvedUrl.origin === helpUrl.origin &&
        sameLocalDocument;

      if (!sameLocalDocument || (resolvedUrl.protocol !== "file:" && !sameOriginHelp)) {
        throw createBlockedError("window.open(external-navigation)");
      }

        return nativeOpen(url, ...args);
      };
    } catch (error) {
      recordBlockedAttempt("GUARD_INSTALL_FAILED:window.open");
    }
  }

  if (root.document && typeof root.document.addEventListener === "function") {
    const blockExternalAnchor = (event) => {
      const anchor = event.target && typeof event.target.closest === "function"
        ? event.target.closest("a[href]")
        : null;
      if (!anchor) return;

      let targetUrl;
      let currentUrl;
      try {
        targetUrl = new URL(anchor.getAttribute("href"), root.location.href);
        currentUrl = new URL(root.location.href);
      } catch (error) {
        event.preventDefault();
        event.stopImmediatePropagation();
        throw createBlockedError("anchor-navigation(invalid-url)");
      }

      const sameProtocol = targetUrl.protocol === currentUrl.protocol;
      const sameFileDirectory =
        currentUrl.protocol === "file:" &&
        targetUrl.pathname.startsWith(new URL(".", currentUrl.href).pathname);
      const sameOrigin =
        currentUrl.protocol !== "file:" && targetUrl.origin === currentUrl.origin;

      if (!sameProtocol || !(sameFileDirectory || sameOrigin)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        recordBlockedAttempt("anchor-navigation(external)");
      }
    };

    ["click", "auxclick", "contextmenu"].forEach((eventName) => {
      root.document.addEventListener(eventName, blockExternalAnchor, true);
    });
  }

  root.addEventListener("securitypolicyviolation", (event) => {
    cspViolations.push({
      directive: String(event.effectiveDirective || event.violatedDirective || "unknown"),
      blockedURI: String(event.blockedURI || "unknown"),
      disposition: String(event.disposition || "enforce"),
      timestamp: Date.now(),
    });
  });

  Object.defineProperty(root, "TTTNetworkIsolationGuard", {
    configurable: false,
    enumerable: false,
    writable: false,
    value: Object.freeze({
      getDiagnostics() {
        return {
          blockedAttempts: blockedAttempts.slice(),
          cspViolations: cspViolations.slice(),
        };
      },
      resetDiagnostics() {
        blockedAttempts.length = 0;
        cspViolations.length = 0;
      },
    }),
  });
})();
