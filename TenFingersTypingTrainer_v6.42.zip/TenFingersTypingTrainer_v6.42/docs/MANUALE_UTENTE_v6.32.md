# Manuale Utente TenFingersTypingTrainer v6.32

## Novità pratiche nella finestra Interrogazione

### 1. Compilazione rapida di "1) Descrizione Accordo" dai pallini sulle mani
- Durante i quesiti **Per Carattere** e **Per Tasto**, cliccando su un pallino dell'immagine delle mani vengono compilati automaticamente tutti e 5 i menu a discesa del blocco **1) Descrizione Accordo**:
  - Colonna sinistra: **Mano**, **Dito**, **Direzione sovraccarico**, **Estensione laterale**.
  - Colonna destra: **Estensione longitudinale**, **Accordo Modificatore** e i pulsanti **Conferma Accordo** / **Consulta (+1)**.

### 2. Chiusura automatica con riepilogo su Concludi, Sospendi e Abbandona
- Premendo **Concludi sessione**, **Sospendi** o **Abbandona**, la finestra di Interrogazione si chiude automaticamente e compare un breve messaggio di riepilogo con il punteggio conseguito e il conteggio delle risposte (**Corrette**, **Errate**, **Consultate**, **Ignorate**).
