# Manuale Utente TenFingersTypingTrainer v6.50

Questa guida integra il manuale della versione 6.49 con gli aggiornamenti introdotti nella versione 6.50.

## 1. Correzioni nell'Interrogazione
- **Carattere `|` (barra verticale):** l'estensione laterale sinistra attesa per il mignolo sinistro è ora correttamente **2** (due posizioni a sinistra rispetto alla posizione di riposo).
- **Tasto `SPAZIO` e tasti della riga inferiore:** nel menu a discesa **Estensione longitudinale** è ora disponibile il valore **-2 (2 righe sotto riposo)** per poter rispondere correttamente alle domande sulla barra spaziatrice e sui tasti della stessa riga.
