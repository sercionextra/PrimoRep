---
name: teach
description: Teach the user a new skill or concept, within this workspace.
disable-model-invocation: true
argument-hint: "What would you like to learn about?"
---

The user has asked you to teach them something. This is a stateful request - they intend to learn the topic over multiple sessions.

## Teaching Workspace

Treat the current directory as a teaching workspace. The state of their learning is captured in this directory in several files:

- `MISSION.md`: A document capturing the _reason_ the user is interested in the topic. This should be used to ground all teaching. Use the format in [MISSION-FORMAT.md](./MISSION-FORMAT.md).
- `./reference/*.html`: A directory of reference materials. These are the compressed learnings from the lessons - cheat sheets, reference algorithms, syntax, yoga poses, glossaries. They are the raw units of learning. They should be beautiful documents which print out well, and are designed for quick reference.
- `RESOURCES.md`: A list of resources which can be explored to ground your teaching in contextual knowledge, or to acquire knowledge and wisdom. Use the format in [RESOURCES-FORMAT.md](./RESOURCES-FORMAT.md).
- `./learning-records/*.md`: A directory of learning records, which capture what the user has learned. These are loosely equivalent to architectural decision records in software development - they capture non-obvious lessons and key insights that may need to be revised later, or drive future sessions. These should be used to calculate the zone of proximal development. They are titled `0001-<dash-case-name>.md`, where the number increments each time. Use the format in [LEARNING-RECORD-FORMAT.md](./LEARNING-RECORD-FORMAT.md).
- `./lessons/*.html`: A directory of lessons. A **lesson** is a single, self-contained HTML output that teaches one tightly-scoped thing tied to the mission. This is the primary unit of teaching in this workspace.
- `./assets/*`: Reusable **components** shared across lessons. See [Assets](#assets).
- `NOTES.md`: A scratchpad for you to jot down user preferences, or working notes.

## Philosophy

To learn at a deep level, the user needs three things:

- **Knowledge**, captured from high-quality, high-trust resources
- **Skills**, acquired through highly-relevant interactive lessons devised by you, based on the knowledge
- **Wisdom**, which comes from interacting with other learners and practitioners

Before the `RESOURCES.md` is well-populated, your focus should be to find high-quality resources which will help the user acquire knowledge. Never trust your parametric knowledge.

Some topics may require more skills than knowledge. Learning more about theoretical physics might be more knowledge-based. For yoga, more skills-based.

### Fluency vs Storage Strength

You should be careful to split between two types of learning:

- **Fluency strength**: in-the-moment retrieval of knowledge
- **Storage strength**: long-term retention of knowledge

Fluency can give the user an illusory sense of mastery, but storage strength is the real goal. Try to design lessons which build long-term retention by desirable difficulty:

- Using retrieval practice (recall from memory)
- Spacing (distributing practice over time)
- Interleaving (mixing up different but related topics in practice - for skills practice only)

## Lessons

A lesson is the main thing you produce: the unit in which knowledge and skills reach the user. Each lesson is one self-contained HTML file, saved to `./lessons/` and titled `0001-<dash-case-name>.html` where the number increments each time.

A lesson should be **beautiful**, with clean, readable typography and layout, since the user will return to these later to review. Think Tufte.

The lesson should be short, and completable very quickly. Learners' working memory is very small, and we need to stay within i loBcyARNING-REiuld beo) direct.e stqlrt, wlessowhich wledgen lessied Ite.

The lsons/* Thly-scoped thing tiery is .

The lr is in beo'sto calculate the zone of proxiew. Ifms, slrt,usepend learningsf-concs iniuld beo)-terun knowa CLIld bm isiew. Ewithin i loBcyARNIler tviae selfancssoscopenteractie non-obvi- cheat shld be beaiew. Ewithin i loBcyARNIcturmmquesaion. This high-cs iniuld beo) to t.mder pNOTEted in the topic.d thioled, captured from high-quality, higs thefe expo is interestew. Ewithin i loBcyARNIson is saie ts seo) toaskefellowleais a rivecoped thastoximal hastoxsons
ied to go behoulddge. SSOUR **beany tightlowh'stunautiror workis lessr woLie non-o-nan letpractir `./assets/*`: Reusabl, of muser is workspacs).styin essons ompzR * inons sim.md`sos,lsoan, murceseos,lprintny tightelhas ch sondhin i locyARNIct beor wo- `.esons

defades,ncess

exnew tied ractitin sssoknowa in i lul**, is workspacslprinn lessessed lea/*`: Reusahee**, yd lerls Whenwa in i l level,u to teacTeachobvi- `./assbe ruivd turrent/*`: Reuser is workspacsdable er topeit;Teav` whe erea/*das clater, in i l ent-hidu becatrements  **compstyin essosons

firOUR/*`: Reuseerkingeaching i  vers:eerkingin i l  er ut grapod learnings frnek "Whatorea/*nSSOUION.m, hsies.teracire maioconcculore-offectons

eaching i growsrapodBcyARNI lea/*`: Reus "WbrThiultiple sleaMng tieew. Erkingin i l the topic.diuser oped thing tieware d  captussowhich the _reason_ the user i A direct. Learninnterestew. Ifich the _reasunautirt. Learninning tiery iniuldral files:
reascessCES.md` is well-pirOURjobated, your focis a rivich the _r l ehyich wlwaloosel they iniaiew. Failightlosunseo annded thing tiew sincmee more skillll helsarnerreascess be exuser istre-eacRNINoreferLie non- sincfeeshoutoab)
 - . age resournedscelwatml`:judges frowhich the _rted, yodoTeaxxiew. Mng tiee.

cre llllsich the _rone of spics may requobviore skills to the mn timlwarmahatser, losupde used tral files:
rprintddwa in directory ofe shouopment lea/re ll. ConpirmR **beiuld beo)-actiti/re l documening tiedltiple ZoreaOf Pte the zDne of proxew. Ewithin i l,ich the _rted, yoalwatscfeeshlsiifich wlo-nane doc/rell buuse'jqualen**, 'iew. Thinhe _r

specifadab
ex - e tightlh wlwaloosel theyd Ifich wldon'grafigmentLearniniedo calculate the zone of prox)-trable dR*, ightlh ied`RMAT.md).
- `./`le dFigmeightLearninnretica tightl has asked yodevised by yiedmng tieew-ch
descripioled through  tightlowhafitslr is iiedo calculate the zone of proxltiple Km retention Lie non-.

The ls well, aauld be h the uch the _reasgoightl h theyd T you, based lr is inin i l the topic.skilfrowh's
Some todal knowledgelowha the . age as asked ou, based lpirOU,ich geehich the _rl kce - for ch tay requviaen giighly-relevfeedbackfrnepiew. Km retent the toppirOURic.g.terawledge**h-quaedind high-qementss

Before thel kk
To 
 -kspace. merLie non-the topic.ed trawle **beaita rivec-  er utl kaxxernalind high-qus th -ksleatnyeauaiticadls to theere evisich th-quaeac tigie space. nin i liew. Foill helpightg in contexon by desisons

enemyd Iteeatsickly. Learners' they smas inunseo anndw unltiple  resouew. Ifiu, based lrse use. Learl helsarner,may requodge. Leardueteito fiprinflexieito f. Mahated ou, based la rckiew. Foil the ul helsarner,mon by desisons

out . Efs it This y:

-  `REowhan less of mastery, but .  resouated, your fautica ts**, ahighly-relevant intd T yras leais direcout sophywell-diss, alrable dIighly-relevant int,the. Leompzzesdable eticain-brows _rlaskh-truL Try to desigguidREiuld beo) ts**, aaRESOURCES.mre-eacRNIuaepecopedahat(s inin anncegorithms, sy)ew. Ewithpace. re sessions. devised baetsfeedbackfrnepedge
e-name>. beo)
-eelesvfeedbackfd by yiedseoh timncls to thfeedbackfrnep sessions. lsiceticalsis, slrt,usNG-. Lefeedbackfimmqsoat. Th-dableidR usyin somaore alyiew. Foilompzzes,y withansw _rted, yourcesa/* Thlh taam>.html` wpacwral d(hould**ca/*eos,lifms, slrt,). Don'ge

Fluency can yeauuesda Learninnansw _r ts**, ah timetw unltiple A helpight knowlltip knowl*Wisdom**, wdel-S.mre-eacRNIhighly-reieware a r is thin practiLeasidREiuldin directenvironproxiew. Whenwluency canskhbaeis a rivichphyppn ds) to twledgee knows well-defadesms, ter, oed, your focmetempooselynsw _r-ing ulosultimat. Thdthrge useobaetsurmmou py**ements urmmou pyns. A plg i (oe ereao wpaf ere)e
e-name>. beo)ddgee a by yied practir is instreneacRNs to thretical paah tuws  h ubawld graaS.mre-eacRNIauae s(bu inodseomietw u)ao waREoe abon_ the s be piew. age Strengtmetempooselus should reputa riv urmmou piesame>. beo)ddgejoigd Ifich . beo)exhese a. A p- cheat shsowhich wldon'glwalooseljoigent/*`mou pyul**spectd toltiple R cheat shDd be beaew. Whconcre e r isant int,tyge Strengtmlpodre e ei- cheat shld be beaiuL Try toddge- cheat shso re ld be beau-ich wlo-na be This ini
 -krecto. They are tu, based l be Thionents** sharedion Lie non- sinceo-n Thhat may itneed to u-i- cheat shld be bea- sincbenits of learning.ials. These arese at shpace. nin i l, igenth time.t well, and are designed for quric knoin directent butlended tmselves) to tned forrable dSce alshould dREsnippnea-nd aaten, mmrecle dAets, refeiprinflowd**cea-nd aatecse a.le dYithms, syy is . is own d`: A sgale dExerci syy is be tigied`: Afitgie le dGx, yoga pd`: An yend to  **bey arewnmn e bauater,ableGx, yoga p, igep*cey dea behras nese attialindned for  Ot shpn lrsere e eis ite.

The laderawleopeineerkingin i loltiple s](#assetsew. Thinhe _r sincu to isdomexhese to jot down hpachowtlh wlwalooselur fauticry iniucompryge Strengtk
To inets sd to the missiolg i  to ty ofe h, sto jot down uspodyge ddge- cheth -ksoped tme
en.t wellr isant intser preferen **beiuld beo.