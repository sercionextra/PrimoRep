# Bug di buffer/sfasamento nell'interfaccia utente (UI Lag)

L'utente ha riscontrato un disallineamento sistematico di 1 turno nella renderizzazione dei messaggi da parte dell'interfaccia utente / web client.
Diagnosi:
- Quando l'utente ha inviato la segnalazione sul pezzo Blu-Rosso (non sul tetto ma laterale), il frontend ha visualizzato la risposta del turno precedente (che conteneva la frase 'Prendiamo il pezzo BLU-ROSSO che sta sul tetto').
- Questo ha causato l'impressione che l'assistente ignorasse ripetutamente l'indicazione.
Azione correttiva:
- Suggerire il refresh della pagina della chat per forzare il riallineamento del frontend.
- Fornire la sequenza diretta di espulsione del pezzo dalla faccia laterale.
