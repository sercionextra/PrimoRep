# Manuale Utente TenFingersTypingTrainer v6.33

## Novità pratiche nella finestra Interrogazione

### 1. Spostamento, ridimensionamento e schermo intero
- **Finestra traslabile:** puoi spostare liberamente la finestra **Interrogazione Layout Tastiera Italiana** trascinandola dalla sua barra del titolo.
- **Ridimensionamento stabile:** puoi ridimensionare la finestra afferrando qualsiasi bordo o angolo; posizione e dimensioni vengono memorizzate automaticamente nel tuo profilo utente.
- **Ingrandisci / Riduci (`⛶ Ingrandisci` / `🗗 Riduci`):** porta la finestra a schermo intero con un clic e ripristina le dimensioni precedenti con un secondo clic.
- **Ripristina (`↺ Ripristina`):** riporta istantaneamente la finestra alla posizione centrata e alle dimensioni predefinite.

### 2. Ripristino globale da Gestione Utenti
- Premendo il pulsante **Reset finestre** nella finestra **Gestione Utenti**, anche la finestra **Interrogazione** viene riportata alle dimensioni e alla posizione predefinite all'interno dello schermo.
