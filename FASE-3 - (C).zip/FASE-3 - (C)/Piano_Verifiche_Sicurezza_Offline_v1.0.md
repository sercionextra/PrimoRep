# Piano di Verifica Sicurezza e Isolamento Offline — TenFingersTypingTrainer

**Versione documento:** v1.0  
**Data:** 09/11/2026  
**Baseline analizzata:** TenFingersTypingTrainer v6.23  
**Stato:** Piano di verifica e requisiti approvati; implementazione CSP e test dedicati non ancora eseguiti.

## 1. Obiettivo e perimetro

TenFingersTypingTrainer deve funzionare come applicazione autonoma. Il codice dell'applicazione non deve iniziare, consentire o richiedere comunicazioni di rete in ingresso o in uscita. I dati di profilo, configurazione, apprendimento e statistiche devono rimanere sul dispositivo dell'utente.

Il requisito si applica a:

- `index.html` e a tutte le risorse caricate dall'applicazione;
- `help.html` e alle relative risorse;
- tutti i file JavaScript, CSS, dati e moduli futuri;
- la nuova funzionalità Interrogazione;
- tutte le modalità di avvio supportate e dichiarate.

Non saranno introdotte dipendenze esterne, pacchetti, framework, CDN, font remoti, servizi cloud, endpoint di telemetria o strumenti runtime di terze parti.

## 2. Risultati dell'audit preliminare della v6.23

L'audit statico preliminare della codebase estratta ha rilevato:

- 31 script applicativi caricati da percorsi relativi locali in `index.html`;
- un foglio di stile applicativo caricato da `assets/styles/app.css`;
- nessun riferimento HTTP/HTTPS remoto nei file eseguibili e nelle pagine analizzate, esclusi gli identificatori XML/SVG `xmlns`;
- nessun uso individuato nei sorgenti JavaScript di `fetch`, `XMLHttpRequest`, `WebSocket`, `EventSource`, `sendBeacon`, `WebTransport`, WebRTC, Service Worker, Worker o API di acquisizione microfono;
- `help.html` contiene attualmente un blocco `<style>` e un blocco `<script>` inline;
- `index.html` contiene circa 251 attributi `style`; `help.html` ne contiene circa 17;
- il collegamento alla guida apre `help.html` localmente in una nuova scheda; non è un collegamento remoto.

### 2.1 Rilievo prioritario: sintesi vocale

`js/engines/dictation-engine.js` utilizza `window.speechSynthesis` e `SpeechSynthesisUtterance`. Il metodo `initVoices()` attualmente assegna punteggi maggiori a nomi contenenti indicatori come `natural`, `neural`, `online` e `google`; solo il fallback cerca esplicitamente `localService === true`.

Questa selezione non è compatibile con il requisito di isolamento rigoroso: una voce remota può essere scelta come voce primaria e il browser o il sistema operativo potrebbe inviare il testo a un servizio di sintesi esterno.

**Correzione obbligatoria prima dell'accettazione:** selezionare esclusivamente voci con `localService === true`. Non usare mai una voce con `localService === false` o con proprietà `localService` assente/non verificabile. Se non è disponibile una voce locale italiana, la sintesi vocale deve essere disabilitata o dichiarata non disponibile, senza fallback remoto. La digitazione e le altre funzioni devono continuare a funzionare.

`AudioContext` nell'`audio-engine.js` genera localmente i suoni di tastiera e non richiede di per sé una connessione di rete.

## 3. Politica CSP richiesta

La Content Security Policy deve essere restrittiva e negare per impostazione predefinita le risorse non esplicitamente autorizzate.

Direttive target per le pagine applicative, da validare sui browser supportati:

```text
default-src 'none';
script-src 'self';
script-src-attr 'none';
style-src 'self';
style-src-elem 'self';
style-src-attr 'none';
img-src 'self' data: blob:;
font-src 'self';
media-src 'none';
connect-src 'none';
object-src 'none';
frame-src 'none';
child-src 'none';
worker-src 'none';
manifest-src 'none';
base-uri 'none';
form-action 'none'
```

Note:

1. `img-src data: blob:` è ammesso solo per compatibilità con risorse generate localmente; non autorizza origini remote.
2. `connect-src 'none'` blocca le connessioni avviate dal contesto della pagina tramite le API coperte dalla CSP.
3. `script-src 'self'` e `script-src-attr 'none'` impediscono script remoti, script inline e handler HTML inline.
4. `style-src-attr 'none'` richiede la rimozione degli attributi `style` statici attualmente presenti. Le regole dovranno essere trasferite in CSS locale preservando esattamente la resa.
5. Il CSS e JavaScript inline di `help.html` dovranno essere spostati in file locali versionati (`help.css` e `help.js`) prima dell'attivazione della policy senza eccezioni inline.
6. Non utilizzare `unsafe-inline`, `unsafe-eval`, nonce generati debolmente o hash calcolati a runtime.
7. Non configurare `report-uri` o `report-to` verso endpoint remoti. Le violazioni saranno verificate localmente durante i test.
8. Non utilizzare `navigate-to` come unico controllo: il supporto dei browser non è uniforme. Navigazioni e link esterni saranno controllati anche con audit statico e test runtime.

### 3.1 Header HTTP e avvio da file locale

Quando l'applicazione viene distribuita tramite un server HTTP locale, la CSP deve essere inviata anche come header HTTP, non soltanto come elemento `<meta>`. L'header consente direttive non applicabili o non pienamente applicabili tramite meta, tra cui `frame-ancestors 'none'`.

Per l'esecuzione tramite `file://`, la CSP dichiarata nel documento resta una difesa utile, ma il comportamento dipende dal browser. Non si deve dichiarare una garanzia assoluta senza testare ogni modalità di avvio ufficialmente supportata.

Header aggiuntivi da adottare quando esiste un server locale controllato dal progetto:

```text
X-Content-Type-Options: nosniff
Referrer-Policy: no-referrer
Permissions-Policy: camera=(), microphone=(), geolocation=(), usb=(), serial=(), bluetooth=(), payment=()
```

`frame-ancestors 'none'` deve essere aggiunto alla CSP dell'header HTTP. Non introdurre un server remoto né un servizio cloud per applicare questi header.

## 4. Piano di verifica multilivello

### Gate S0 — Inventario e analisi statica

Obiettivo: impedire l'introduzione accidentale di dipendenze o riferimenti remoti.

Controlli automatici:

- scansione di tutti i file HTML, JS, CSS, JSON e degli asset;
- rilevamento di URL `http://` e `https://`, import remoti, `src`/`href` remoti, `@import`, `url()` remoti e riferimenti a CDN;
- rilevamento di API di rete: `fetch`, XHR, WebSocket, EventSource, Beacon, WebTransport, WebRTC, `navigator.sendBeacon`, Service Worker, Worker e import dinamici;
- rilevamento di form con destinazioni remote, iframe, embed, object, link esterni e navigazioni esterne;
- allowlist esplicita dei soli asset locali previsti;
- controllo delle dipendenze: nessun nuovo package manager, manifest di dipendenze o file vendor non autorizzato.

Esito richiesto: zero riferimenti o primitive di rete non autorizzati. Ogni eccezione deve essere documentata e approvata prima del merge.

### Gate S1 — CSP effettiva

Obiettivo: verificare che il browser applichi la policy prevista.

Test automatici e browser:

- verificare che `default-src`, `script-src`, `style-src`, `img-src`, `font-src`, `connect-src`, `object-src`, `frame-src`, `worker-src`, `base-uri` e `form-action` risultino effettivi;
- tentare in una pagina di test controllata il caricamento di script, CSS, immagini, font, iframe e media da un'origine remota di test: ogni tentativo deve essere bloccato;
- tentare `fetch`, XHR, WebSocket, EventSource, Beacon e Worker verso un endpoint di test: nessuna richiesta deve raggiungere la rete;
- verificare che script inline, handler HTML inline e `eval` siano bloccati;
- verificare che gli asset locali autorizzati continuino a caricarsi;
- registrare localmente gli eventi `securitypolicyviolation` durante i test e fallire il test in presenza di violazioni inattese.

I tentativi devono essere eseguiti esclusivamente nell'ambiente di test, verso endpoint controllati; non aggiungere tali tentativi al prodotto distribuito.

### Gate S2 — Osservazione reale del traffico

Obiettivo: dimostrare che l'applicazione non produce traffico di rete durante il normale utilizzo.

Procedura:

1. Avviare il browser con un profilo pulito, senza estensioni, e aprire l'applicazione.
2. Azzerare il pannello Network e attivare la conservazione del log.
3. Eseguire tutte le funzioni: login/profili locali, esercizi, statistiche, esportazione/importazione locale, audio, dettatura, guida e Interrogazione.
4. Ripetere il test con cache fredda e con cache calda.
5. Analizzare richieste, WebSocket, EventSource, beacon, redirect e tentativi bloccati.
6. Ripetere in modalità offline del browser e, ove possibile, con connettività di rete del sistema disabilitata.

Esito richiesto: zero richieste verso origini remote, zero handshake di rete e zero trasmissioni di dati. Le sole risorse ammesse sono file locali dell'applicazione.

La modalità offline del browser da sola non è prova sufficiente: deve essere affiancata dall'osservazione del traffico e dai test CSP.

### Gate S3 — API di rete e regressione runtime

Obiettivo: intercettare chiamate di rete eseguite da codice applicativo anche quando non producono una richiesta riuscita.

Il test harness deve installare, prima del bootstrap dell'applicazione, sentinelle su:

- `fetch`;
- `XMLHttpRequest.open` e `send`;
- `WebSocket`;
- `EventSource`;
- `navigator.sendBeacon`;
- `Worker` e `SharedWorker`;
- `RTCPeerConnection`;
- `navigator.serviceWorker.register`;
- `importScripts` e import dinamici, per quanto rilevabili staticamente.

Ogni invocazione inattesa deve far fallire il test e registrare API, stack e scenario, senza registrare contenuti personali digitati dall'utente.

Il test harness è esclusivamente uno strumento di test: non deve essere incluso nel bundle o nella distribuzione dell'applicazione e non deve introdurre dipendenze esterne.

### Gate S4 — Sintesi vocale locale

Obiettivo: impedire l'invio di testo a servizi vocali remoti.

Test obbligatori:

- verificare che `initVoices()` consideri esclusivamente `SpeechSynthesisVoice.localService === true`;
- verificare che voci con `localService === false` non vengano mai assegnate a `utterance.voice`;
- verificare che una voce con `localService` mancante o non verificabile venga esclusa;
- simulare assenza di voci locali italiane: la sintesi deve risultare non disponibile, senza selezionare una voce remota;
- verificare che il resto dell'applicazione resti utilizzabile;
- verificare che nessun testo di esercizi, profili o digitazione venga passato a servizi remoti.

La proprietà `localService` è il criterio tecnico disponibile per distinguere le voci locali da quelle remote. Il comportamento deve essere verificato sui browser e sistemi operativi supportati.

### Gate S5 — Persistenza e riservatezza

Obiettivo: verificare che i dati restino sul dispositivo.

Test obbligatori:

- inventariare tutte le chiavi `localStorage` e ogni futuro object store IndexedDB;
- verificare che i dati non siano inseriti in URL, query string, fragment o referrer;
- verificare che esportazione e importazione avvengano solo su azione esplicita dell'utente;
- verificare che i log non contengano testo digitato, contenuti dei profili, PIN o dati di apprendimento;
- verificare che cancellazione profili/statistiche elimini i dati previsti senza copie remote;
- verificare che la nuova funzionalità Interrogazione non introduca sincronizzazione, telemetria o identificatori remoti.

### Gate S6 — Regressione funzionale e compatibilità

Obiettivo: assicurare che la sicurezza non rompa l'applicazione.

Eseguire tutte le suite esistenti della v6.23 e la checklist manuale, quindi aggiungere test per:

- caricamento completo di `index.html` e `help.html`;
- navigazione locale verso la guida;
- temi e stile dell'interfaccia dopo la rimozione degli stili inline;
- audio sintetizzato tramite `AudioContext`;
- dettatura con voce locale e scenario senza voce locale;
- profili, salvataggio e ripristino;
- import/export;
- statistiche;
- tutte le modalità didattiche;
- Interrogazione, persistenza, ripresa e riproducibilità.

Esito richiesto: tutte le suite automatiche superate e checklist manuale completata sui browser supportati.

## 5. Matrice di accettazione

| Gate | Condizione di superamento | Bloccante per il rilascio |
|---|---|---|
| S0 | Nessuna dipendenza o primitiva remota non autorizzata | Sì |
| S1 | CSP restrittiva attiva e test di blocco superati | Sì |
| S2 | Zero traffico di rete attribuibile all'app | Sì |
| S3 | Zero invocazioni inattese delle API di rete | Sì |
| S4 | Solo voci TTS locali, oppure TTS disabilitato | Sì |
| S5 | Dati e log esclusivamente locali | Sì |
| S6 | Nessuna regressione funzionale | Sì |

Un gate non superato impedisce di dichiarare la release conforme al requisito di isolamento.

## 6. Limiti della garanzia

La CSP controlla le risorse e le connessioni avviate dal contesto della pagina secondo le direttive supportate dal browser. Non controlla il traffico autonomo del browser, del sistema operativo, delle estensioni o di altri processi.

Per una garanzia a livello di dispositivo occorre anche una policy firewall del sistema operativo o un ambiente di esecuzione senza connettività. Tale misura è esterna all'applicazione e non sarà simulata con dichiarazioni di conformità del solo codice.

L'obiettivo verificabile del progetto è: nessun codice di TenFingersTypingTrainer deve avviare o consentire comunicazioni esterne e nessun dato dell'utente deve essere trasmesso dall'applicazione.

## 7. Stato e sequenza di implementazione

1. Congelare questo piano come requisito di sicurezza.
2. Correggere la selezione delle voci TTS per consentire esclusivamente voci locali.
3. Estrarre CSS e JavaScript inline della guida in risorse locali versionate.
4. Rimuovere gli attributi `style` statici trasferendoli in CSS locale, preservando il rendering.
5. Applicare CSP restrittiva alle due pagine e, se applicabile, gli header HTTP al server locale controllato dal progetto.
6. Aggiungere test statici e runtime anti-network senza dipendenze esterne.
7. Eseguire i test CSP nel browser e la verifica reale del traffico.
8. Eseguire l'intera regressione funzionale e aggiornare architettura, Manuale Utente e Help solo per le informazioni pertinenti all'utente.

**Nessun sorgente applicativo è stato modificato con la creazione di questo documento.**
