# Manuale Utente TenFingersTypingTrainer v6.58

Questa guida integra il manuale della versione 6.57 con le avvertenze prioritarie e le novità introdotte nella versione 6.58.

## 1. Avvisi Fondamentali (Leggere Prima di Iniziare)

### 1.1 Salvataggio dei Dati, Rischi di Perdita e Portabilità (Priorità Massima)
Tutti i tuoi dati (**Profilo, Stato di Avanzamento, Statistiche, Interrogazioni e Configurazioni**) vengono memorizzati localmente dal browser.
- **Attenzione alla cancellazione dei dati del browser:** ogni volta che elimini cookie e dati di navigazione del browser, oppure quando cambi computer, i dati locali vanno persi.
- **Come fare il Backup e trasferire i progressi:** apri la finestra **Utenti** e clicca su **💾 Esporta Profilo** per salvare una copia di sicurezza in formato JSON sul tuo dispositivo. Per ripristinare i dati o trasferirli su un altro computer, usa **📂 Importa Profilo** nella stessa finestra.
- **Promemoria periodico automatico:** al termine degli esercizi e delle sessioni di Interrogazione un breve avviso in basso a destra ti ricorderà periodicamente di eseguire il backup completo.

### 1.2 Ridimensionamento dell'Applicazione nella Finestra del Browser
- Per inquadrare al meglio l'intera applicazione nella finestra del browser, puoi ingrandire o ridurre la vista tenendo premuto **CTRL** e ruotando la **rotella del mouse** (`CTRL + Rotella del mouse`), oppure modificando lo Zoom dalle impostazioni del browser.

### 1.3 Cambio Involontario del Layout di Tastiera (`ALT + SHIFT`)
- Su alcuni computer, combinazioni come `ALT + SHIFT` possono cambiare il layout di tastiera del sistema operativo (ad esempio da **Italiano** a **Inglese**). Se i tasti non corrispondono più alle lettere attese, ripremi `ALT + SHIFT` per tornare al layout Italiano.

### 1.4 Perdita di Focus dopo Sequenze di Tasti di Controllo
- A volte alcune sequenze di tasti di controllo (`CTRL`, `SHIFT`, `ALT`) possono far perdere il focus all'applicazione. Se noti che l'applicazione non risponde più o il browser reagisce in modo anomalo, clicca con il mouse in un punto qualsiasi dell'applicazione per restituirle il controllo.

## 2. Messaggio di Conferma in Digitazione Libera
- Nella modalità **Typing (Libera)**, dopo aver premuto **+ Aggiungi alle Statistiche** al termine dell'esercizio, il messaggio di conferma ti ricorda che puoi premere **CTRL+SHIFT+X** per avviare subito un nuovo esercizio.
