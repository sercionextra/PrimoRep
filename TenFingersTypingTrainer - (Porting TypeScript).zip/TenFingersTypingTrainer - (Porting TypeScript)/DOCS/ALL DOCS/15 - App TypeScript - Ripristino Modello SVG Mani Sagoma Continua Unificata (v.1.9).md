# Documento di Avanzamento Tecnico e Specifica Funzionale (Versione 1.9)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Versione rilasciata**: **1.9**  
**Data**: 30/03/2026  
**File sorgente correlati**:
- `index_(v.1.9).html`
- `help_(v.1.9).html`
- `hands_anatomical_model.svg`

---

## 1. Sommario Esecutivo

Il rilascio della **Versione 1.9** attua il ripristino immediato e rigoroso del modello vettoriale per la finestra fluttuante **10 Fingers (Mani)** alla configurazione a **sagoma continua unificata (baseline v.1.7)**, a seguito del feedback dell'utente:

1. **Rollback della Geometria Vettoriale delle Mani**:
   - È stato rimosso integralmente il modello sperimentale introdotto nella v.1.8.
   - È stato ripristinato il modello a sagoma continua unificata (`viewBox="0 0 1024 576"`), con la geometria parametrizzata della versione 1.7.
2. **Conservazione delle Caratteristiche della Sagoma Continua Unificata (v.1.7)**:
   - Sagoma perimetrale continua (`.hand-silhouette`) ad arco chiuso per ciascuna mano su asse di simmetria $x = 512$.
   - Overlay digitali (`hand_finger_1` ... `hand_finger_10`) trasparenti a riposo (`fill: transparent; stroke: transparent`) che si attivano solo sul carattere/accordo bersaglio.
   - Punti di mira per i badge dei caratteri (`hand_finger_tip_1` ... `hand_finger_tip_10`) posizionati sulle falangi distali:
     - `hand_finger_tip_1`: (147, 172)
     - `hand_finger_tip_2`: (219, 98)
     - `hand_finger_tip_3`: (285, 54)
     - `hand_finger_tip_4`: (375, 66)
     - `hand_finger_tip_5`: (509, 178)
     - `hand_finger_tip_6`: (515, 178)
     - `hand_finger_tip_7`: (649, 66)
     - `hand_finger_tip_8`: (739, 54)
     - `hand_finger_tip_9`: (805, 98)
     - `hand_finger_tip_10`: (877, 172)
3. **Integrità Totale delle Funzionalità Dattilografiche**:
   - Invariata la gestione degli accordi a mano libera (`resolveTargetChord`).
   - Invariata la gestione del timer indipendente e delle metriche in modalità libera (*Typing*).
   - Invariata la selezione a due click nel modulo statistiche con invarianza geometrica affine (`getScreenCTM().inverse()`).
   - Nessuna regressione sui 70 esercizi standard, sul corpus fonetico e sul profilo storico di collaudo *ALBERTO*.

---

## 2. Matrice di Test e Validazione Funzionale

| N° | Verifica Effettuata | Esito Atteso | Risultato |
|:---:|:---|:---|:---:|
| 1 | **Rollback SVG Mani a baseline v.1.7** | Modello 1024×576 a sagoma continua ripristinato in `index_(v.1.9).html` e `hands_anatomical_model.svg` | **PASS** |
| 2 | **Compilazione Script JavaScript V8** | Nessun errore di sintassi (`node --check`) su `index_(v.1.9).html` | **PASS** |
| 3 | **Rendering Headless Chrome (CDP)** | Finestra fluttuante mani visualizzata correttamente a 580px senza errori console | **PASS** |
| 4 | **Coerenza Identificatori e Selettori** | Piena funzionalità di `VisualRenderer` con ID `hand_finger_1..10` e `hand_finger_tip_1..10` | **PASS** |
| 5 | **Aggiornamento Documentazione e Help** | Coerenza cross-documentale tra sorgenti `v.1.9`, Help e specifiche | **PASS** |

---

## 3. Struttura dei File Rilasciati in `/workspace`

```text
/workspace/
├── index_(v.1.9).html                                                                          # SPA v.1.9 con SVG mani ripristinato a v.1.7
├── help_(v.1.9).html                                                                           # Manuale Utente v.1.9 aggiornato
├── hands_anatomical_model.svg                                                                  # Modello vettoriale SVG standalone v.1.7 ripristinato
├── 15 - App TypeScript - Ripristino Modello SVG Mani Sagoma Continua Unificata (v.1.9).md        # Specifica tecnica di avanzamento v.1.9
└── TenFingersTypingTrainer - (Porting TypeScript)/
    ├── DOCS/
    │   └── 15 - App TypeScript - Ripristino Modello SVG Mani Sagoma Continua Unificata (v.1.9).md
    └── SRC/
        ├── index_(v.1.9).html
        └── help_(v.1.9).html
```
