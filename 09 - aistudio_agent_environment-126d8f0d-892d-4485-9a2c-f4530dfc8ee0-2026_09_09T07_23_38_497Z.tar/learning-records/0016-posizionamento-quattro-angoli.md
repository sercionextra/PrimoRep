# Tutti i 4 angoli sono posizionati correttamente (Passo 6 completato)

L'utente ha confermato che tutti e 4 gli angoli si trovano nella loro posizione corretta (ciascuno tra i propri tre centri), con 3 angoli che necessitano dell'orientamento finale (giallo sul tetto).
Si avvia il Passo 7 (ultimo passo per la risoluzione del puzzle) tramite la sequenza `R' D' R D`, con enfasi critica sul completamento obbligatorio del quarto movimento (`D`) e sulla rotazione esclusiva del tetto (`U`) tra un angolo e l'altro.
