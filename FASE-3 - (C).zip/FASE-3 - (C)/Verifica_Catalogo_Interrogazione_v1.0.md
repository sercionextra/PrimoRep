# Verifica del catalogo INTERROGAZIONE — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Data verifica:** 09/11/2026  
**Esito:** superato per il perimetro parziale approvato di 52 tasti fisici verificati  
**Sorgenti applicativi modificati:** nessuno in questa verifica

## 1. Perimetro adottato

La prima release di INTERROGAZIONE utilizzerà esclusivamente i 52 tasti fisici verificati nel seed. Il catalogo resta dichiaratamente parziale rispetto al layout dichiarato da 105 tasti. Nessuna posizione mancante viene dedotta, completata o inventata.

Il perimetro contiene:

- 52 identità di tasto fisico;
- 111 mapping carattere/input;
- 10 definizioni di dito;
- 62 ID SVG, dei quali 10 sono modificatori esclusi dal catalogo interrogabile;
- 60 coordinate anatomiche.

Dei 105 tasti dichiarati, 43 posizioni non sono rappresentate dagli ID SVG verificati e 10 modificatori sono presenti nell'SVG ma non fanno parte dei 52 tasti interrogabili. Restano quindi 53 posizioni fuori dal perimetro della prima release.

## 2. Verifica della baseline

Confronto eseguito direttamente sui sorgenti v6.23:

| Verifica | Risultato |
|---|---:|
| Voci `KEY_MAP` | 111 |
| ID fisici distinti in `KEY_MAP` | 52 |
| Mapping nel seed | 111 |
| Tasti fisici nel seed | 52 |
| Dita in `FINGER_NAMES` | 10 |
| Coordinate anatomiche | 60 |
| ID SVG | 62 |

Esito: tutti i 111 mapping del seed corrispondono alle voci effettive di `KEY_MAP`, inclusi tasto fisico, dito e modificatore. Tutti i 52 tasti fisici del seed corrispondono agli ID fisici distinti della mappa applicativa. Non sono state rilevate differenze.

## 3. Verifica delle definizioni di domanda

Il catalogo domande contiene:

| Tipologia | Definizioni attive |
|---|---:|
| HOME_ROW | 8 |
| TASTO | 52 |
| CARATTERE | 333 |
| DITO | 52 |
| **Totale** | **445** |

Sono presenti 5 template di domanda principale e 3 definizioni non attivate (movimento, estensione e composizione mano completa, quest'ultima rappresentata tramite sotto-quesiti indipendenti).

## 4. Verifica dei candidate materializzati

Il manifest `Candidati_Interrogazione_v1.1.json` materializza esplicitamente 225 candidate:

| Tipologia | Candidate |
|---|---:|
| HOME_ROW | 10 |
| TASTO | 52 |
| CARATTERE | 111 |
| DITO | 52 |
| **Totale** | **225** |

I 10 candidate HOME_ROW comprendono 8 interrogazioni per singolo dito operativo e 2 interrogazioni composte per mano completa. Le due domande composte riutilizzano i quattro sotto-quesiti individuali della mano: non creano nuove statistiche aggregate.

Verifiche eseguite:

- 225 `candidateId` univoci;
- tutti i 225 template risolti;
- tutti i riferimenti ai sotto-quesiti risolti;
- tutti i riferimenti agli elementi risolti;
- tutte le 445 definizioni attive referenziate;
- nessuna definizione o combinazione creata per inferenza;
- nessuna dipendenza esterna.

**Esito:** 0 riferimenti mancanti e 0 duplicati di identità candidate.

## 5. Questioni escluse dal perimetro

- I 43 elementi non rappresentati nell'SVG non vengono creati.
- I 10 modificatori SVG non diventano candidate TASTO o DITO.
- Le caratteristiche di movimento ed estensione delle dita restano bloccate perché la baseline non fornisce dati verificati.
- Le incongruenze dei modificatori destri restano fuori dal catalogo attivo; non vengono corrette modificando `KEY_MAP` o i landmark.

## 6. Decisioni operative conseguenti

1. Il catalogo parziale è sufficiente per implementare e testare la prima release sul perimetro di 52 tasti.
2. La UI deve dichiarare che la copertura è parziale e non deve mostrare i 53 elementi esclusi come domande disponibili.
3. La struttura dati deve mantenere `layoutId` e `catalogVersion`, così da consentire una futura estensione senza cambiare le identità già pubblicate.
4. L'estensione futura dovrà aggiungere nuove identità e nuove versioni di catalogo; non dovrà rinumerare né riutilizzare identità storiche.

## 7. File di riferimento

- `Catalogo_QWERTY_Italiano_seed_v1.0.json`
- `Catalogo_Domande_Interrogazione_v1.0.json`
- `Candidati_Interrogazione_v1.1.json`
- `TenFingersTypingTrainer_v6.23/js/domain/keyboard-map.js`
- `TenFingersTypingTrainer_v6.23/js/domain/finger-names.js`
- `TenFingersTypingTrainer_v6.23/js/domain/anatomical-landmarks.js`
- `TenFingersTypingTrainer_v6.23/index.html`
