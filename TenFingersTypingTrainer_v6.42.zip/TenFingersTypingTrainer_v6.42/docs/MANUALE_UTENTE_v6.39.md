# Manuale Utente — Aggiornamento v6.39

## Novità della versione v6.39

1. **Avviso immediato in presenza di sessione sospesa:**
   - Se si tenta di avviare una nuova interrogazione mentre ne esiste già una sospesa, viene mostrato un messaggio di notifica in basso a destra: *"Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova."*

2. **Richiamo del carattere sotto esame nel selettore:**
   - Nella finestra **"Seleziona carattere / tasto"**, sulla destra della barra del titolo compare ora il richiamo all'elemento attualmente sotto esame (ad esempio `CARATTERE: "X"`).
