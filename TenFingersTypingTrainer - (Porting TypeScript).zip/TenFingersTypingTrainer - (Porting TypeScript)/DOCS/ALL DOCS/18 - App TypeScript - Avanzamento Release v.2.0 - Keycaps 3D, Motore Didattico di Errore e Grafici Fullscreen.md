# 18 - App TypeScript - Avanzamento Release v.2.0: Keycaps 3D, Motore Didattico di Errore e Grafici Fullscreen

## 1. Sintesi Esecutiva del Rilascio v.2.0

La **Release 2.0 (v.2.0)** rappresenta il completamento del passaggio evolutivo "Major" dell'applicazione didattica **Ten Fingers Typing Trainer (Web Edition)**. A valle della convergenza sul modello vettoriale anatomico continuo delle Mani a 1408 x 768 pixel (introdotto in v.1.10), la versione 2.0 introduce una serie organica di perfezionamenti visivi, didattici, interattivi e analitici commissionati tramite il protocollo di revisione tecnica approfondita.

Tutte le modifiche sono state implementate nel rigoroso rispetto dei 7 Principi Guida operativi: codice modulare e circoscritto, conservazione integrale delle funzionalità e dei commenti pertinenti, totale assenza di regressioni e perfetta coerenza incrociata tra Sorgenti (`index_(v.2.0).html`), Manuale Utente (`help_(v.2.0).html`), Asset Grafici (`hands_anatomical_model_(v.2.0).svg`) e Documentazione Tecnica.

---

## 2. Dettaglio delle Innovazioni Architetturali e Funzionali (v.2.0)

### 2.1 Badge Keycaps 3D sui Polpastrelli con Contorno Cromatico Dedicato
Nel modello SVG delle mani (risoluzione 1408 x 768 px), ciascuno dei 10 polpastrelli è stato trasformato da semplice etichetta testuale a componente grafico composito a tasto tridimensionale (`<g id="hand_finger_keycap_group_N" class="finger-keycap-group">`):
- **Geometria del Tasto**: Riquadro rettangolare con angoli arrotondati (`rx="7" ry="7"`), fondo scuro ad alto contrasto (`#0f172a`), contorno rinforzato (`stroke-width: 2.8`) e alone volumetrico di profondità (`drop-shadow`).
- **Codifica Cromatica Differenziata per Dito**: Il bordo e il glow del tastino assumono in tempo reale il colore fisiologico del dito attivo:
  - **Dita 1 e 10 (Mignoli)**: Bordo Rosso Corallo (`#ef4444`)
  - **Dita 2 e 9 (Anulari)**: Bordo Ambra Dorata (`#f59e0b`)
  - **Dita 3 e 8 (Medi)**: Bordo Verde Smeraldo (`#10b981`)
  - **Dita 4 e 7 (Indici)**: Bordo Blu Cielo (`#3b82f6`)
  - **Dita 5 e 6 (Pollici)**: Bordo Viola Ametista (`#a855f7`)
- **Tipografia e Dinamismo**: Font ingrandito a 24px in grassetto ultra (weight 900) con doppio contorno scuro (`paint-order: stroke fill`). Per etichette estese relative ai tasti modificatori (`SHIFT`, `ALT GR`, `CTRL`, `INVIO`), la larghezza del tasto si espande automaticamente da 44px fino a oltre 70px mantenendo il perfetto centraggio sul baricentro del polpastrello.

### 2.2 Azzeramento Totale dei Contatori e Arresto Timer con BackSpace a Zero Caratteri
È stato integrato il metodo `resetSessionMetrics()` nel motore dattilografico (`TypingEngine`):
- Quando l'utente preme il tasto BackSpace e la lunghezza del testo digitato si riduce a zero (`typedText.length === 0`):
  - Il conteggio delle battute totali (`countTotalChars`) e degli errori commessi (`countErrors`) viene azzerato istantaneamente.
  - Il timer della sessione viene fermato (`clearInterval`) e la variabile temporale reimpostata a `null`.
  - I display a video vengono reimpostati su valori neutri: `Tempo: 00:00`, `Battute: 0`, `Errori: 0`, `WPM / BTM: 0`, `Accuratezza: 100%`.
  - Il cronometro riprenderà la misurazione temporale solo alla digitazione del primo nuovo carattere valido.

### 2.3 Motore Didattico di Evidenziazione Errori nel Testo Guida
Nel metodo `updateOriginDisplay()` di `AppController`, quando l'opzione "Auto-Correzione" non è attiva, è stato implementato il nuovo algoritmo visivo di segnalazione a catena:
- Sia `matchLen` la lunghezza del prefisso coincidente tra il testo originale e l'input dell'utente.
- Sia `numErrors = typedText.length - matchLen` il numero di caratteri errati consecutivi introdotti:
  - **Nessun Errore attivo (`numErrors === 0`)**: Il carattere bersaglio da digitare `origin[matchLen]` mantiene lo sfondo **BLU** (`.char-current-target`, `#2563eb`).
  - **Presenza di Errori (`numErrors > 0`)**: Lo sfondo del carattere diventa **ROSSO ACCESO** (`.char-error-target`, `#ef4444`) ed estende la sua copertura esattamente per tanti caratteri quanti sono gli errori digitati (`numErrors`).
  - **Superamento della Fine della Frase**: Se l'utente introduce più lettere errate di quante ne manchino alla conclusione della frase guida, il sistema genera e accoda in tempo reale spazi fittizi rossi (`␣`) per coprire ogni singolo errore eccedente.
  - **Cancellazione Progressiva**: A ogni pressione di BackSpace, `numErrors` si riduce di 1 e l'estensione del blocco rosso si contrae lettera per lettera. Quando tutti gli errori sono cancellati (`numErrors === 0`), lo sfondo del carattere corrente torna immediatamente **BLU**, sbloccando la prosecuzione ordinaria dell'esercizio.

### 2.4 Grafici Statistiche Fullscreen e Layout Elastico Reattivo
- I contenitori `#statsSpeedSvgBox` e `#statsHistogramSvgBox` all'interno della finestra fluttuante delle statistiche sono stati configurati con regole CSS flessibili (`flex: 1 1 auto; height: 100%; min-height: 280px`).
- In modalità a schermo intero (`.window-fullscreen`, attivata dal pulsante "⛶ Ingrandisci" nell'header della finestra o mediante trascinamento degli 8 handle di ridimensionamento perimetrali), il corpo della finestra e i box dei grafici si espandono per occupare l'intera area visibile del monitor (100vw x 100vh).
- È stato agganciato un osservatore nativo `ResizeObserver` che intercetta i mutamenti dimensionali del contenitore con debounce a 80 ms, invocando `renderSpeedChart()` e `renderHistogram()` con larghezza e altezza effettive calcolate dinamicamente (`W = Math.max(760, container.clientWidth)`, `H = Math.max(260, container.clientHeight - 35)`).

### 2.5 Crosshair Orizzontale Rosso con Quota in Ordinata
All'interno del grafico di velocità dei campioni:
- Al movimento del cursore del mouse viene proiettata una linea orizzontale rossa tratteggiata (`#chartCrosshairH`, `#ef4444`) estesa dal margine sinistro `padL` al margine destro `W - padR` alla coordinata Y del mouse.
- Sull'asse verticale delle ordinate compare simultaneamente un'etichetta numerica rossa ad alta visibilità (`#chartCrosshairYLabel`) che indica in tempo reale il valore esatto corrispondente alla quota del puntatore (espresso in Battute al Minuto, es. `185 BTM`).

### 2.6 Didascalia del Campione con Percentuale Errori Formattata in NN.N%
Nella barra d'ispezione situata al di sotto del grafico di velocità, al passaggio del mouse (`mouseenter`) su qualsiasi punto/campione registrato, il calcolo della quota di errore viene esposto rigorosamente nel formato con un decimale `NN.N%`:
- Formula: `errPct = len > 0 ? ((err / len) * 100).toFixed(1) + "%" : "0.0%"`
- Visualizzazione tooltip:
  `Campione #14 | Valore: 210 | Errori: 2 (4.8%) | Caratteri: 42 | Esercizio: "Invio"`

### 2.7 Macchina a Stati per Selezione Campioni a 3 Fasi Sequenziali
Il sistema di selezione e filtraggio dei campioni nel grafico cartesiano è stato reingegnerizzato secondo una sequenza deterministica a 3 fasi:
1. **Fase 0 (Pre-selezione / Cursore Libero)**: Quando nessuna selezione è attiva e l'utente muove il cursore sopra al grafico, una linea verticale tratteggiata ciano (`#chartPreviewVLine`, `#38bdf8`) segue la coordinata X del mouse, indicando con precisione la linea delle ascisse da cui partirà la selezione.
2. **Primo Click (Inizio Selezione)**: Fissa l'ascissa iniziale `startSvgX`. Al movimento del cursore, il rettangolo di selezione semitrasparente si estende dinamicamente mostrando in anteprima i campioni intercettati.
3. **Secondo Click (Fine Selezione e Ricalcolo Metriche)**: Fissa l'intervallo finale `[minX, maxX]`, illumina i campioni inclusi in colore ambra (`#f59e0b`) e ricalcola all'istante le metriche della barra di controllo (media BTM e conteggio campioni) limitatamente al sottoinsieme selezionato.
4. **Terzo Click (Annullamento Selezione e Ripristino Globale)**: Resetta completamente la selezione, nasconde il rettangolo d'area, ricalcola le metriche su tutti i campioni filtrati e ripristina la linea verticale mobile di pre-selezione.

### 2.8 Scorciatoia CTRL+SHIFT+E con Finestra Modale Glassmorphism
- Nel gestore centralizzato degli eventi da tastiera (`setupShortcuts`) è stata cablata la combinazione `CTRL+SHIFT+E`.
- La scorciatoia apre la finestra modale dedicata `#selectPhraseModal` progettata nello stile grafico scuro glassmorphism coerente con la finestra di Login utente:
  - Espone il nome della Lezione attiva e il range di frasi ammesse (es. `da 1 a 25`).
  - Campo numerico centrato con autofocus e preselezione del valore corrente.
  - Tasto `Invio` per confermare e saltare istantaneamente alla frase desiderata avviando l'esercizio; tasto `Esc` per chiudere senza modifiche.

---

## 3. Matrice dei File Rilasciati e Sincronizzati

| File Rilasciato | Percorso Radice | Percorso Mirror Repository | Stato Validazione |
| :--- | :--- | :--- | :--- |
| **Interfaccia Web Principale** | `/workspace/index_(v.2.0).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/index_(v.2.0).html` | Validato Chrome CDP (0 Errori) |
| **Manuale e Guida Utente** | `/workspace/help_(v.2.0).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/help_(v.2.0).html` | Completo & Sincronizzato |
| **Modello Vettoriale Mani SVG** | `/workspace/hands_anatomical_model_(v.2.0).svg` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/` | 1408 x 768 px con 10 Keycaps |
| **Documentazione Tecnica** | `/workspace/18 - App TypeScript - Avanzamento Release v.2.0 - Keycaps 3D, Motore Didattico di Errore e Grafici Fullscreen.md` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/DOCS/ALL DOCS/` | Redatto e Allineato |

---

## 4. Risultati della Suite di Collaudo Headless Chrome (CDP)

I test di esecuzione eseguiti direttamente nell'ambiente sandbox con browser headless Google Chrome (protocollo DevTools) hanno certificato i seguenti esiti:

1. **Inizializzazione e Login Profilo**: Profilo utente predefinito `ALBERTO` caricato correttamente all'avvio con caricamento sincronizzato di opzioni, layout e campioni storici.
2. **Componenti Keycaps SVG (10 Dita)**: Rilevati con successo 10 elementi `.finger-keycap-rect` e 10 etichette `.finger-tip-label` con posizionamento e dimensioni coerenti.
3. **Evidenziazione Dinamica Errore con Spazi Fittizi**: Simulazione di 3 errori con soli 2 caratteri rimanenti nella frase. Risultato: classe `.char-error-target` applicata ed estesa con aggiunta del carattere spazio fittizio `␣` (`text: 'bc␣'`).
4. **Cancellazione con BackSpace e Reset a Zero**:
   - Con la rimozione del primo errore: classe ripristinata immediatamente a `.char-current-target` (sfondo blu).
   - Con la cancellazione completa a 0 caratteri: `typedLenFinal = 0`, `countCharsFinal = 0`, `countErrorsFinal = 0`, `timerRunningFinal = false` (arresto del timer verificato).
5. **Finestra Modale CTRL+SHIFT+E**: Apertura, lettura intervallo consentito (1 - 25), validazione del campo input e chiusura verificate con successo.
6. **Grafico di Velocità Fullscreen & Crosshair**: Presenza e integrità di `#chartCrosshairH`, `#chartCrosshairYLabel`, `#chartPreviewVLine` e `#chartSelectionRect` verificate.
