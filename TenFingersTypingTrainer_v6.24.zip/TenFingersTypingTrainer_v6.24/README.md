# TenFingersTypingTrainer v6.24

Release di hardening offline: CSP restrittiva, blocco runtime delle API di rete, dei canali tra contesti e della navigazione esterna, sintesi vocale limitata alle sole voci italiane locali. Nessuna dipendenza esterna, CDN, telemetria o servizio remoto. La release conserva dati e funzionalità preesistenti.

Release v6.23 con risoluzione dell'isolamento modale DOM (finestra Utenti e Configurazione Dettatura), architettura ergonomica a tre fasce (TitleBar fissa, Body centrale scrollabile e Footer ancorato con Salva sempre visibile), ridimensionamento verticale bidirezionale (rh-n e rh-s con vincoli 420px - 92vh) e flusso di conferma con ripristino valori Default.

## Avvio

Aprire `index.html` in un browser moderno. L'applicazione non richiede Node.js, server applicativi, pacchetti npm o servizi remoti per il normale funzionamento.

## Struttura

- `index.html`: interfaccia principale e ordine di caricamento dei componenti.
- `assets/styles/app.css`: foglio di stile locale dell'interfaccia principale.
- `assets/styles/help.css`: foglio di stile locale della guida, estratto per applicare la CSP restrittiva.
- `js/data/`: dataset didattico, profilo demo, testo Custom predefinito e corpus fonemico.
- `js/domain/`: helper puri, mappature della tastiera, landmark anatomici e logica di dominio.
- `js/engines/`: motori audio, digitazione e dettatura.
- `js/profiles/`: profili e persistenza browser.
- `js/ui/`: finestre, rendering visivo e comportamento della guida locale.
- `js/security/network-isolation-guard.js`: blocco runtime delle API di rete e delle richieste a dispositivi non necessari.
- `js/analytics/`: statistiche e grafici.
- `js/app/`: coordinamento dell'applicazione, metodi del controller suddivisi per responsabilità e avvio.
- `js/shared/`: utilità condivise.
- `docs/`: manuale e specifica comportamentale di riferimento.
- `tests/`: controlli di regressione, test anti-network e checklist manuale.

## Compatibilità e strategia architetturale

Per minimizzare il rischio di regressioni, i componenti JavaScript sono separati in file per responsabilità ma mantengono in questa release il modello di caricamento classico e ordinato. Questo conserva le binding globali condivise dai sorgenti storici e permette l'apertura diretta come sito statico. La migrazione a moduli ES/TypeScript deve avvenire per dipendenze esplicite e con test di equivalenza, non tramite una conversione automatica che possa cambiare il comportamento.

## Metodo didattico

La filosofia del trainer resta invariata: precisione prima della velocità, ritorno alla posizione di riposo, apprendimento progressivo, uso delle modalità didattiche originali e feedback degli errori. Le lezioni, il corpus fonemico, il profilo demo e il formato degli esercizi Custom sono conservati nel codice sorgente estratto.

## Persistenza

La versione originale usa Local Storage con le chiavi TFTT esistenti. Questa release conserva tali chiavi e il modello dati: non effettua migrazioni distruttive e non richiede di cancellare i dati del browser. Prima di distribuire aggiornamenti successivi, verificare sempre importazione/esportazione e compatibilità dei profili.

## Verifiche

Con Node.js installato, dalla cartella del progetto eseguire `node tests/static-check.js` e `node tests/runtime-smoke.js`. Il primo controlla la presenza e il collegamento degli asset; il secondo carica in un contesto JavaScript simulato i componenti nell’ordine previsto e verifica i dataset e i contratti essenziali. Consultare inoltre `tests/REGRESSION_CHECKLIST.md`: i test automatici non sostituiscono la verifica completa nel browser di tutte le interazioni e dei dati persistenti.

## Isolamento offline

`index.html` e `help.html` applicano una Content Security Policy restrittiva: risorse locali, nessuna connessione, nessun frame/worker/media remoto e nessun codice inline. Il guard runtime blocca le API di rete e le aperture di finestre diverse dalla guida locale. La sintesi vocale usa soltanto voci italiane dichiarate locali dal browser; se non sono disponibili, l'audio della dettatura non viene riprodotto.

Per eseguire i controlli automatici, dalla cartella del progetto lanciare `node tests/security-static-check.js` e `node tests/test-network-isolation-guard.js`, `node tests/test-dom-injection-safety.js` e `node tests/test-build-manifest.js`. Eseguire inoltre tutte le suite `tests/*.js` e la checklist browser `tests/REGRESSION_CHECKLIST_v6.24.md`. I controlli statici/runtime non sostituiscono il collaudo del traffico effettivo nel browser e del firewall del sistema operativo.
