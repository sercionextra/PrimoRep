/* TenFingersTypingTrainer v6.0 — AppController: statistics. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// Configurazione Listener UI Statistiche e Filtri Temporali
  setupStatsUI() {
    // 1. Radio Ordinamento Istogramma (Restituzione focus post-selezione)
    document.querySelectorAll('input[name="statsSort"]').forEach((radio) => {
      const handleSort = (e) => {
        document.querySelectorAll('input[name="statsSort"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.sortMode = e.target.value;
        this.statsMgr.renderHistogram();
        this.returnFocusToTyping();
      };
      radio.addEventListener("change", handleSort);
      radio.addEventListener("click", () => this.returnFocusToTyping());
    });

    // 2. Radio Metrica Velocità BPM (Restituzione focus post-selezione)
    document.querySelectorAll('input[name="speedMetric"]').forEach((radio) => {
      const handleMetric = (e) => {
        document.querySelectorAll('input[name="speedMetric"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.speedMetric = e.target.value;
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      };
      radio.addEventListener("change", handleMetric);
      radio.addEventListener("click", () => this.returnFocusToTyping());
    });

    // 3. Filtri Checkbox Tipi di Sessione (Restituzione focus post-toggle)
    document.querySelectorAll(".speed-filter-chk").forEach((chk) => {
      chk.addEventListener("change", () => {
        const types = [];
        document.querySelectorAll(".speed-filter-chk:checked").forEach((c) => {
          types.push(parseInt(c.value, 10));
        });
        this.statsMgr.filterTypes = types;
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      });
    });

    // 4. Listener per i campi Range Data-Ora (Input, Change e Tasti Invio/Esc)
    const onDateFilterChange = () => {
      this.statsMgr.renderSpeedChart();
    };

    [
      "filterStartDate",
      "filterStartTime",
      "filterEndDate",
      "filterEndTime",
    ].forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", onDateFilterChange);
        el.addEventListener("change", () => {
          onDateFilterChange();
          this.returnFocusToTyping();
        });
        el.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === "Escape") {
            e.preventDefault();
            this.returnFocusToTyping();
          }
        });
      }
    });

    // 5. Listener cancellazione singola per ciascun campo del range data/ora
    const clearSingleField = (inputId) => {
      const input = document.getElementById(inputId);
      if (input) {
        input.value = "";
        input.classList.remove("input-field-error");
        input.classList.remove("filter-active");
        // Ricalcola immediatamente la validità del range e aggiorna il grafico
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      }
    };

    document
      .getElementById("btnClearStartDate")
      ?.addEventListener("click", () => clearSingleField("filterStartDate"));
    document
      .getElementById("btnClearStartTime")
      ?.addEventListener("click", () => clearSingleField("filterStartTime"));
    document
      .getElementById("btnClearEndDate")
      ?.addEventListener("click", () => clearSingleField("filterEndDate"));
    document
      .getElementById("btnClearEndTime")
      ?.addEventListener("click", () => clearSingleField("filterEndTime"));

    // 6. Tasto Reset Periodo per azzerare tutti i controlli temporali
    document
      .getElementById("btnResetDateFilter")
      ?.addEventListener("click", () => {
        const elA = document.getElementById("filterStartDate");
        const elB = document.getElementById("filterStartTime");
        const elC = document.getElementById("filterEndDate");
        const elD = document.getElementById("filterEndTime");
        const msgEl = document.getElementById("lblDateRangeValidationMessage");

        if (elA) elA.value = "";
        if (elB) elB.value = "";
        if (elC) elC.value = "";
        if (elD) elD.value = "";

        [elA, elB, elC, elD].forEach((inp) => {
          if (inp) {
            inp.classList.remove("input-field-error");
            inp.classList.remove("filter-active");
          }
        });
        if (msgEl) {
          msgEl.style.display = "none";
          msgEl.textContent = "";
        }

        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      });

    // 7. Pulsante Azzera Statistiche (con dialogo modale)
    document.getElementById("btnClearStats")?.addEventListener("click", () => {
      this.showAppConfirm(
        "Azzerare definitivamente tutte le statistiche e i campioni dell'utente loggato?",
        "⚠ Azzeramento Statistiche",
        () => {
          this.profileMgr.clearUserStats();
          this.statsMgr.clearSelection();
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
          this.returnFocusToTyping();
        },
        () => {
          this.returnFocusToTyping();
        },
      );
    });

    // 8. Pulsante Elimina Selezionati (con dialogo modale)
    document
      .getElementById("btnClearSelection")
      ?.addEventListener("click", () => {
        const count = this.statsMgr.selectedSampleIndices.size;
        if (count === 0) return;
        const msg = `Sei sicuro di voler eliminare definitivamente i ${count} campioni selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}"?\n\nQuesta operazione cancellerà solo i campioni evidenziati nel grafico e non potrà essere annullata.`;
        this.showAppConfirm(
          msg,
          "🗑 Elimina Selezionati",
          () => {
            const p = this.profileMgr.profile;
            if (p && p.Campioni) {
              p.Campioni = p.Campioni.filter(
                (s) => !this.statsMgr.selectedSampleIndices.has(s.Index),
              );
              p.Campioni.forEach((s, idx) => (s.Index = idx));
              this.profileMgr.saveProfile();
            }
            this.statsMgr.clearSelection();
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
            this.showAppAlert(
              `Eliminati con successo ${count} campioni selezionati.`,
              "📊 Statistiche",
              () => this.returnFocusToTyping(),
            );
          },
          () => this.returnFocusToTyping(),
        );
      });

    // 9. Pulsante Elimina Non Selezionati (con dialogo modale)
    document
      .getElementById("btnClearNotSelected")
      ?.addEventListener("click", () => {
        const countSel = this.statsMgr.selectedSampleIndices.size;
        const totalFiltered = this.statsMgr.currentFilteredSamples.length;
        const countNot = totalFiltered - countSel;
        if (countSel === 0 || countNot <= 0) return;
        const msg = `ATTENZIONE: Stai per eliminare TUTTI i ${countNot} campioni NON selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}".\n\nVerranno conservati ESCLUSIVAMENTE i ${countSel} campioni attualmente selezionati nel grafico.\n\nSei sicuro di voler procedere? L'operazione non può essere annullata.`;
        this.showAppConfirm(
          msg,
          "✂ Elimina Non Selezionati",
          () => {
            const p = this.profileMgr.profile;
            if (p && p.Campioni) {
              p.Campioni = p.Campioni.filter((s) =>
                this.statsMgr.selectedSampleIndices.has(s.Index),
              );
              p.Campioni.forEach((s, idx) => (s.Index = idx));
              this.profileMgr.saveProfile();
            }
            this.statsMgr.clearSelection();
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
            this.showAppAlert(
              `Eliminati con successo ${countNot} campioni non selezionati.`,
              "📊 Statistiche",
              () => this.returnFocusToTyping(),
            );
          },
          () => this.returnFocusToTyping(),
        );
      });

    // 10. Clic generico nella finestra Statistiche (grafici, etichette e sfondo)
    const statsWin = document.getElementById("statsFloatingWindow");
    statsWin?.addEventListener("click", (e) => {
      const t = e.target;
      if (
        t.tagName === "INPUT" &&
        (t.type === "date" || t.type === "time" || t.type === "text")
      ) {
        return;
      }
      this.returnFocusToTyping();
    });
  },

// Garantisce il collasso istantaneo dell'altezza della scheda
  // e ricolloca la finestra Mani senza lasciare gap o spazi vuoti.
  toggleErrorsVis(show) {
    const box = document.getElementById("errorsBoxContainer");
    const typingCard = document.getElementById("typingCardContainer");

    if (box) {
      box.style.display = show ? "flex" : "none";
      // 1. Forza il ricalcolo sincrono del reflow nel DOM (Layout Flush)
      void box.offsetHeight;
      if (typingCard) {
        void typingCard.offsetHeight;
      }
    }

    const chk = document.getElementById("chkShowErrors");
    if (chk && chk.checked !== !!show) {
      chk.checked = !!show;
    }

    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowErrors = !!show;
      this.profileMgr.saveProfile();
    }

    // 2. Ricalcolo immediato sincrono della quota della scheda
    this.updateHandsWindowPosition();

    // 3. Secondo passaggio a frame stabilizzato per eliminare qualsiasi residuo di scrollbar
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
    });

    // 4. Timer di sicurezza a 30ms per garantire la perfetta aderenza su tutti i browser
    setTimeout(() => {
      this.updateHandsWindowPosition();
    }, 30);
  },

// Rendering dinamico delle coppie di errori commessi
  renderErrorsList() {
    const listCont = document.getElementById("errorsListContent");
    const countBadge = document.getElementById("lblErrorsCountBadge");
    const emptyPlaceholder = document.getElementById(
      "lblErrorsEmptyPlaceholder",
    );
    const handsCounter = document.getElementById("handsErrorCountText");

    if (!listCont) return;

    const errors = this.typingEng.sessionErrors || [];
    if (countBadge) countBadge.innerText = errors.length;

    // Sincronizzazione e visibilità condizionata contatore in alto al centro nella finestra Mani
    if (handsCounter) {
      handsCounter.textContent = `Errori: ${errors.length}`;
      handsCounter.style.display = errors.length > 0 ? "inline" : "none";
    }

    // Reset Immediato a cursore zero o inizio sessione
    if (errors.length === 0) {
      listCont.innerHTML = "";
      listCont.scrollTop = 0;
      if (emptyPlaceholder) emptyPlaceholder.style.display = "inline";
      return;
    }

    if (emptyPlaceholder) emptyPlaceholder.style.display = "none";

    let html = "";
    errors.forEach((err) => {
      const expFmt = this.formatGuideChar(err.expected);
      const wrgFmt = this.formatGuideChar(err.wrong);
      html +=
        `<span class="error-pair" title="Atteso: '${htmlEscape(err.expected)}' | Digitato: '${htmlEscape(err.wrong)}'">` +
        `<span class="char-expected">${htmlEscape(expFmt)}</span>` +
        `<span class="char-wrong">${htmlEscape(wrgFmt)}</span>` +
        `</span>`;
    });

    listCont.innerHTML = html;
    // Auto-scroll verticale verso il basso per inquadrare l'ultimo errore aggiunto
    listCont.scrollTop = listCont.scrollHeight;
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
