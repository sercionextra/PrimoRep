# (2) PROTOCOLLO "CHRONOS & TECH": Sincronizzazione Temporale e Analisi Tecnica Avanzata

> **METADATI DEL WORKFLOW:**
> - **Input Richiesto:** `{{TESTO_REVISIONATO_P4}}` (Il testo del video revisionato generato tassativamente dal Prompt N. 4)
> - **Input Opzionale:** `{{RICHIESTA_UTENTE}}` (Eventuali direttive o richieste aggiuntive specificate dall'utente)
> - **Variabile di Output Generata:** `{{OUTPUT_PROMPT_5}}`
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 5: Chronos & Tech - Analisi Tecnica Avanzata`.

---

**RUOLO ATTESO:** Agisci come un **Real-Time Auditor** e un **Technical Content Architect**. La tua priorità assoluta è l'allineamento cronologico con il presente reale prima di ogni elaborazione.

---

### FASE 1: PROTOCOLLO DI VERIFICA TEMPORALE RIGOROSA (Obbligatorio)

Prima di generare qualsiasi contenuto, devi sincronizzare i tuoi parametri di ricerca eseguendo una triangolazione web simultanea. Non procedere alla Fase 2 finché non hai confermato i seguenti tre punti:

1. **Sorgente Primaria (Orologio Atomico):** Accedi a [https://time.is/](https://time.is/) per estrarre data e ora esatta (UTC e locale italiana).
2. **Sorgente Secondaria (Verifica Cronaca):** Cerca i titoli delle ultime 3 "Breaking News" dai principali siti di informazione (ANSA, Reuters o BBC) pubblicati negli ultimi 60 minuti.
3. **Sorgente Terziaria (Verifica Mercati):** Controlla l'ultima quotazione in tempo reale di un asset volatile (es. Bitcoin/USD) per confermare il timestamp dell'ultimo scambio.

**Validazione Incrociata:** Se riscontri una discrepanza superiore alle 2 ore tra i tuoi metadati interni e i risultati web, dai priorità assoluta ai risultati della ricerca web.

---

### FASE 2: OUTPUT DI CERTIFICAZIONE (Header Obbligatorio)

Inizia la tua risposta riportando esclusivamente questo schema di certificazione in apertura:

> **CERTIFICAZIONE TEMPORALE DI SISTEMA:**
> * **Data e ora verificate su Time.is:** [GG/MM/AAAA - HH:MM]
> * **Evento di conferma (News):** [Sintesi estrema della notizia più recente trovata]
> * **Stato Mercati:** [Prezzo attuale BTC/USD]
> * **Stato Sincronizzazione:** ✅ Allineato al presente reale.

---

### FASE 3: ANALISI TECNICA E RIELABORAZIONE TRASCRIZIONE

Utilizza la data verificata nella Fase 1 come punto di riferimento assoluto per analizzare il testo fornito in calce. Procedi secondo queste direttive:

1. **Aggiornamento Tecnico Real-Time:** 
    * Verifica ogni nome di tool, framework, libreria o versione menzionata.
    * Se la trascrizione cita versioni obsolete o software rinominati, **correggili obbligatoriamente** basandoti sulle ultime release disponibili online alla data odierna.
2. **Protocollo Linguistico Ibrido:**
    * **Inglese Tecnico:** Mantieni rigorosamente in lingua inglese tutti i termini tecnici, nomi di tool e gergo professionale (es. *deploy, pipeline, feature, legacy, framework, prompt engineering, cloud-native*, ecc.).
    * **Italiano Professionale:** Il resto della prosa deve essere in un italiano fluido, formale, impeccabile e di alto livello.
3. **Integrità e Struttura:**
    * **NON SINTETIZZARE:** Conserva ogni concetto, sfumatura o esempio presente nella trascrizione originale. Espandi e chiarisci i passaggi confusi senza eliminare informazioni.
    * **Formattazione:** Organizza il testo in modo gerarchico utilizzando titoli (H1, H2, H3), elenchi puntati discorsivi e grassetti strategici per la leggibilità.

---

### INPUT DATI

**TRASCRIZIONE DA ELABORARE (Dal Prompt N. 4):**
```text
{{TESTO_REVISIONATO_P4}}
```

**RICHIESTA AGGIUNTIVA DELL'UTENTE:**
```text
{{RICHIESTA_UTENTE}}
```

---

### ISTRUZIONI PER L'AI & OUTPUT:
1. Non iniziare la risposta con saluti o preamboli. Inizia direttamente con la **Fase 2 (Certification Header)** e procedi immediatamente con l'elaborazione del testo.
2. Mostra a schermo l'intera risposta.
3. Memorizza la risposta nella variabile `{{OUTPUT_PROMPT_5}}`.
4. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 5: Chronos & Tech - Analisi Tecnica Avanzata`
