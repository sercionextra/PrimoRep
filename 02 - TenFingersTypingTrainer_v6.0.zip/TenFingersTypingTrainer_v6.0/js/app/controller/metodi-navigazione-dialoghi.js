/* TenFingersTypingTrainer v6.0 — AppController: navigation. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
showAppConfirm(
    message,
    title = "❓ Conferma",
    onConfirm = null,
    onCancel = null,
  ) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal) return;

    const titleEl = document.getElementById("lessonNavModalTitle");
    const bodyEl = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!bodyEl || !btnYes || !btnNo) return;

    if (titleEl) titleEl.textContent = title;
    bodyEl.textContent = message;
    if (btnNo) btnNo.style.display = "";
    btnYes.textContent = "Sì";
    btnNo.textContent = "No";
    modal.style.zIndex = "4000"; // Elevato a Livello 3 per dominare su tutti i modali
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      modal.style.zIndex = "";
      if (titleEl) titleEl.textContent = "📖 Navigazione Lezione";
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.returnFocusToTyping();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
      if (onCancel) onCancel();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  },

showLessonNavAlert(message) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const title = document.getElementById("lessonNavModalTitle");
    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes) return;

    if (title) title.textContent = "ℹ Informazione";
    body.textContent = message;
    if (btnNo) btnNo.style.display = "none";
    btnYes.textContent = "OK";
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      if (btnNo) btnNo.style.display = "";
      btnYes.textContent = "Sì";
      if (title) title.textContent = "📖 Navigazione Lezione";
      btnYes.removeEventListener("click", handleOk);
      btnClose?.removeEventListener("click", handleOk);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleOk = () => cleanup();
    const handleKey = (e) => {
      if (e.key === "Escape" || e.key === "Enter") {
        e.preventDefault();
        cleanup();
      }
    };

    btnYes.addEventListener("click", handleOk);
    btnClose?.addEventListener("click", handleOk);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  },

showLessonNavConfirmCustom(customMessage, onConfirm) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const title = document.getElementById("lessonNavModalTitle");
    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes || !btnNo) return;

    if (title) title.textContent = "📖 Navigazione Lezione";
    body.textContent = customMessage;
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  },

showLessonNavConfirm(aaaa, bbbb, onConfirm) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes || !btnNo) return;

    const msg = `E' stato raggiunto ${aaaa} esercizio della lezione corrente.\nSi desidera abbandonarla\ne passare ad un esercizio della lezione ${bbbb}?`;
    body.textContent = msg;
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  },

navPhrase(delta) {
    if (this.typingEng.mode === 4) {
      this.notifyShortcutDisabled(
        "Navigazione frase non disponibile in Digitazione Libera",
      );
      return;
    }

    if ([1, 2, 3, 5, 6].includes(this.typingEng.mode)) {
      if (delta > 0) {
        // Genera nuova sequenza/frase per la modalità attiva senza alterare l'indice di frase corrente
        this.startExercise(false);
      } else {
        this.notifyShortcutDisabled(
          "Frase precedente non disponibile in questa modalità",
        );
      }
      return;
    }

    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    let next = this.typingEng.currentPhraseIdx + delta;

    if (delta < 0 && next < 0 && this.typingEng.currentLessonIdx === 0) {
      this.audio.playError();
      this.showLessonNavAlert(
        "Sei già al primo esercizio della prima lezione.",
      );
      return;
    }

    if (
      delta > 0 &&
      next >= total &&
      this.typingEng.currentLessonIdx >= this.lessons.length - 1
    ) {
      this.audio.playError();
      this.showLessonNavAlert(
        "Sei già all'ultimo esercizio dell'ultima lezione.",
      );
      return;
    }

    if (next < 0 || next >= total) {
      const aaaa = delta < 0 ? "il primo" : "l'ultimo";
      const bbbb = delta < 0 ? "precedente" : "successiva";
      this.showLessonNavConfirm(aaaa, bbbb, () => {
        if (delta < 0) {
          let prevLessonIdx = this.typingEng.currentLessonIdx - 1;
          this.typingEng.currentLessonIdx = prevLessonIdx;
          const prevLesson = this.lessons[prevLessonIdx];
          const prevTotal = (prevLesson?.phrases || []).length;
          this.typingEng.currentPhraseIdx = Math.max(0, prevTotal - 1);
          const cbo = document.getElementById("cboLessons");
          if (cbo) cbo.value = String(prevLessonIdx);
          if (
            this.profileMgr.profile &&
            this.activeLessonsSource === "standard"
          ) {
            this.profileMgr.profile.Lesson = prevLessonIdx;
            this.profileMgr.profile.Exercise = this.typingEng.currentPhraseIdx;
            this.profileMgr.saveProfile();
          }
          this.startExercise();
        } else {
          this.navLesson(1);
        }
      });
      return;
    }

    this.typingEng.currentPhraseIdx = next;
    if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
      this.profileMgr.profile.Exercise = next;
      this.profileMgr.saveProfile();
    }
    this.startExercise();
  },

randomPhrase() {
    if ([1, 2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
      this.notifyShortcutDisabled(
        "Estrazione casuale non disponibile nella modalità attiva",
      );
      return;
    }
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    if (total > 1) {
      let r = Math.floor(Math.random() * total);
      if (r === this.typingEng.currentPhraseIdx) r = (r + 1) % total;
      this.typingEng.currentPhraseIdx = r;
      if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
        this.profileMgr.profile.Exercise = r;
        this.profileMgr.saveProfile();
      }
    }
    this.startExercise();
  },

startExercise(keepCurrent = false) {
    // Politica B (v.4.7): reset del flag per consentire un nuovo avviso al primo tasto del nuovo esercizio se la memoria è ancora satura
    if (this.profileMgr) {
      this.profileMgr.quotaExceededNotified = false;
    }

    this.typingEng.initSession(keepCurrent);
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    const titleEl = document.getElementById("lblExerciseTitle");
    const rangeEl = document.getElementById("lblPhraseRange");
    const prefix =
      this.activeLessonsSource === "custom" ? "Custom " : "Lezione ";

    if (this.typingEng.mode === 0) {
      if (titleEl)
        titleEl.innerText = `${prefix}${this.typingEng.currentLessonIdx + 1}: ${lesson?.name || ""}`;
      if (rangeEl)
        rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} di ${total}`;
    } else if (this.typingEng.mode === 1) {
      if (titleEl)
        titleEl.innerText = `Random Caratteri: ${prefix}${this.typingEng.currentLessonIdx + 1}`;
      if (rangeEl) rangeEl.innerText = "50 caratteri casuali";
    } else if (this.typingEng.mode === 2) {
      if (titleEl) titleEl.innerText = "Modalità Fonemi (Sillabico IT)";
      if (rangeEl) rangeEl.innerText = "Testo generato con Markov";
    } else if (this.typingEng.mode === 3) {
      if (titleEl) titleEl.innerText = "Modalità Tutti i Caratteri";
      if (rangeEl) rangeEl.innerText = "50 caratteri QWERTY IT";
    } else if (this.typingEng.mode === 4) {
      if (titleEl) titleEl.innerText = "Modalità Digitazione Libera (Typing)";
      if (rangeEl) rangeEl.innerText = "Digitazione libera senza guida";
    } else if (this.typingEng.mode === 5) {
      if (titleEl) titleEl.innerText = "Modalità Rimescola Frase Corrente";
      if (rangeEl)
        rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} rimescolata`;
    } else if (this.typingEng.mode === 6) {
      if (titleEl) titleEl.innerText = "Modalità WEAKNESSES (Carenze)";
      if (rangeEl) rangeEl.innerText = "30 caratteri mirati sugli errori";
    }

    const input = document.getElementById("txtTypedInput");
    if (input) {
      input.value = "";
      input.scrollTop = 0;
      input.classList.remove("error-active");
    }

    const origWrapper = document.getElementById("originTextWrapper");
    if (origWrapper) {
      origWrapper.scrollTop = 0;
    }

    this.updateOriginDisplay();
    this.updateTargetKey();
    this.renderErrorsList();
    this.typingEng.updateMetrics();

    // Avvio della Dettatura Vocale per il nuovo testo proposto (v.3.8)
    if (this.typingEng.mode !== 4 && this.typingEng.originText) {
      this.dictation.startSession(
        this.typingEng.originText,
        this.typingEng.mode,
      );
    } else {
      this.dictation.stop();
    }

    this.returnFocusToTyping();
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
