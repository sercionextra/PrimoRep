/* TenFingersTypingTrainer v6.0 — AppController: lifecycle. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// HELPER CENTRALE: Auto-Refocus UI aggressivo e resiliente a elementi occultati
  returnFocusToTyping() {
    if (document.querySelector(".modal-overlay.active")) return;
    const inp = document.getElementById("txtTypedInput");
    // Se la casella di testo è visibile a schermo, le assegniamo il focus
    if (inp && window.getComputedStyle(inp).display !== "none") {
      inp.focus();
    } else {
      // REQUISITO CRITICO: Esercizio con campo Input nascosto (display: none).
      // Chiamare focus() su un elemento display:none non produce effetti nel DOM, lasciando
      // il focus bloccato sull'ultimo controllo (es. il select appena cliccato).
      // Eseguendo blur() su qualsiasi elemento attivo, il focus torna al body del documento,
      // consentendo al listener globale di catturare ed elaborare regolarmente tutte le battute.
      if (document.activeElement && document.activeElement !== document.body) {
        document.activeElement.blur();
      }
    }
  },

// Gestione disaccoppiata dell'uscita del focus da un elemento Select nativo
  gestisciUscitaDropdown(select, motivo) {
    // Delay di 60ms indispensabile per consentire all'OS e al browser engine
    // di terminare la distruzione e la chiusura grafica della tendina nativa
    setTimeout(() => {
      if (document.querySelector(".modal-overlay.active")) {
        // Se un modale è aperto e il select appartiene ad esso, non inviamo il focus all'input di battitura
        return;
      }
      this.returnFocusToTyping();
    }, 60);
  },

// Registrazione macchina a stati per tutti i DropDownList nativi
  setupDropdownFocusManagement() {
    const selects = document.querySelectorAll("select");
    selects.forEach((select) => {
      let isOpen = false;
      let initialValue = select.value;
      let justChanged = false;
      let escInCorso = false;

      select.addEventListener("focus", () => {
        initialValue = select.value;
        isOpen = false;
      });

      select.addEventListener("click", () => {
        // Se il click è residuo immediato di un cambio valore con mouse, lo ignoriamo
        if (justChanged) {
          justChanged = false;
          return;
        }
        if (isOpen) {
          // Secondo click: tendina già aperta. Se il valore coincide, l'utente ha riselezionato la stessa voce
          if (select.value === initialValue) {
            this.gestisciUscitaDropdown(
              select,
              `[#${select.id}] Stessa voce confermata via mouse ("${select.value}")`,
            );
          }
          isOpen = false;
        } else {
          // Primo click: apertura logica della tendina
          isOpen = true;
          initialValue = select.value;
        }
      });

      select.addEventListener("change", () => {
        initialValue = select.value;
        isOpen = false;
        justChanged = true;
        setTimeout(() => {
          justChanged = false;
        }, 100);
        this.gestisciUscitaDropdown(
          select,
          `[#${select.id}] Valore modificato in ("${select.value}")`,
        );
      });

      const gestisciPressioneEsc = () => {
        if (escInCorso) return;
        escInCorso = true;
        isOpen = false;
        setTimeout(() => {
          escInCorso = false;
        }, 150);
        this.gestisciUscitaDropdown(
          select,
          `[#${select.id}] Uscita con tasto ESC`,
        );
      };

      select.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          gestisciPressioneEsc();
          return;
        }
        const isOpeningKey =
          e.key === " " ||
          (e.altKey && e.key === "ArrowDown") ||
          e.key === "F4";
        if (!isOpen && isOpeningKey) {
          isOpen = true;
          initialValue = select.value;
          return;
        }
        if (e.key === "Enter" || (isOpen && e.key === " ")) {
          if (select.value === initialValue) {
            this.gestisciUscitaDropdown(
              select,
              `[#${select.id}] Stessa voce confermata da tastiera ("${select.value}")`,
            );
          }
          isOpen = false;
        }
      });

      // Ascolto combinato su keyup per garantire la cattura di ESC su tutti i browser Chromium
      select.addEventListener("keyup", (e) => {
        if (e.key === "Escape") {
          gestisciPressioneEsc();
        }
      });

      select.addEventListener("blur", () => {
        isOpen = false;
      });
    });
  },

// =======================================================
  // CLASSE: AppController (main_B_(v.4.9).js)
  // METODO: start()
  // CONTESTO: Registrazione del StateProvider per la Dettatura Vocale
  // =======================================================
  start() {
    this.profileMgr.init();

    // Registrazione StateProvider dinamico per ricontrollare sempre le coordinate live (Release v.4.9)
    this.dictation.setStateProvider(() => ({
      typedLen: this.typingEng.typedText.length,
      matchLen: this.typingEng.getMatchLength(),
      originText: this.typingEng.originText,
    }));

    // Registrazione handler combinati memoria Local Storage (v.4.7: Politica B + C)
    this.profileMgr.setQuotaExceededHandler(() => {
      // 1. Politica C: attiva il badge di allerta permanente nell'Header
      const badge = document.getElementById("storageWarningBadge");
      if (badge) badge.style.display = "inline-flex";

      // 2. Politica B: mostra il modale di avviso per il nuovo esercizio
      this.showAppAlert(
        "Spazio di memoria del browser esaurito (Local Storage). Per non perdere i tuoi progressi: esporta il tuo profilo dal pannello Utenti (file .json) e rimuovi i campioni più vecchi dalle Statistiche o i profili obsoleti degli utenti che non utilizzi più.",
        "⚠ Memoria Browser Esaurita",
      );
    });

    this.profileMgr.setQuotaRestoredHandler(() => {
      // Scomparsa automatica del badge quando lo spazio torna disponibile
      const badge = document.getElementById("storageWarningBadge");
      if (badge) badge.style.display = "none";
    });

    // Clic sul badge: permette all'utente di rileggere il messaggio quando desidera
    document
      .getElementById("storageWarningBadge")
      ?.addEventListener("click", () => {
        this.showAppAlert(
          "Spazio di memoria del browser esaurito (Local Storage). Per non perdere i tuoi progressi: esporta il tuo profilo dal pannello Utenti (file .json) e rimuovi i campioni più vecchi dalle Statistiche o i profili obsoleti degli utenti che non utilizzi più.",
          "⚠ Memoria Browser Esaurita",
        );
      });

    const savedCustomText =
      this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    this.customLessons = parseCustomExercises(savedCustomText);

    this.setupTheme();
    this.setupAudio();
    this.setupFloatingWindows();
    this.setupLoginModal();
    this.setupSelectPhraseModal();
    this.setupToolbar();
    this.setupFonemiDropdown();
    this.setupFonemiEditorButtons();
    this.setupFonemiConfigModal();
    this.setupCheckboxes();
    this.setupDictationControls();
    this.setupCustomEditor();
    this.setupStatsUI();
    this.setupImportConflictModal();
    this.setupDropdownFocusManagement();
    this.setupTypingListeners();
    this.setupShortcuts();

    const active = this.profileMgr.activeUser;
    if (active) {
      this.loginUser(active);
      setTimeout(() => {
        this.returnFocusToTyping();
      }, 150);
    } else {
      const badge = document.getElementById("loggedUserBadge");
      if (badge) badge.innerText = "Utente: --";
      this.showLoginModal();
    }

    window.addEventListener("resize", () => {
      this.updateHandsWindowPosition();
      this.syncLayoutArrangement();
    });
  },

setupTheme() {
    const sel = document.getElementById("themeSelect");
    if (!sel) return;
    sel.addEventListener("change", (e) => {
      const theme = e.target.value;
      document.body.classList.remove(
        "theme-dark",
        "theme-light",
        "theme-retro",
        "theme-matrix",
      );
      document.body.classList.add(theme);
      if (this.profileMgr.profile) {
        this.profileMgr.profile.Theme = theme;
        this.profileMgr.saveProfile();
      }
      this.returnFocusToTyping();
    });
  },

setupAudio() {
    const modeSel = document.getElementById("audioModeSelect");
    const volSlider = document.getElementById("audioVolumeSlider");
    if (modeSel) {
      modeSel.addEventListener("change", (e) => {
        this.audio.setMode(e.target.value);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioMode = e.target.value;
          this.profileMgr.saveProfile();
        }
        this.returnFocusToTyping();
      });
    }
    if (volSlider) {
      volSlider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value) / 100;
        this.audio.setVolume(val);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioVolume = val;
          this.profileMgr.saveProfile();
        }
      });
      // Il refocus avviene solo al rilascio del mouse, per non interrompere il drag dello slider
      volSlider.addEventListener("change", () => {
        this.returnFocusToTyping();
      });
    }
  },

getAppOrigin() {
    const main = document.querySelector("main");
    if (main) {
      const rect = main.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY,
      };
    }
    return { left: 0, top: 0 };
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
