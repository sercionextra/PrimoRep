# PROMPT N. 4: Revisione Dettagliata e Sfoltimento dei Timestamp

> **METADATI DEL WORKFLOW:**
> - **Input Richiesto:** `{{TESTO_INPUT_PROMPT_4}}` (Corrisponde a `{{OUTPUT_PROMPT_3}}` se elaborato, oppure a `{{OUTPUT_PROMPT_1}}` se non è stata necessaria traduzione/riformattazione).
> - **Variabile di Output Generata:** `{{TESTO_REVISIONATO_P4}}`
> - **AVVISO IMPORTANTE:** L'output generato da questo prompt costituisce il testo di input obbligatorio per i successivi **Prompt N. 5** e **Prompt N. 6**.
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 4: Revisione Dettagliata e Sfoltimento Timestamp`.

---

### DIRETTIVE OPERATIVE

Utilizza la data verificata nella Fase 1 come punto di riferimento assoluto per analizzare il testo fornito in calce. Procedi secondo queste direttive:

1. **Sfoltimento degli eventuali Timestamp:** Fornisci una versione strutturata del testo, eliminando i **timestamp (orari che eventualmente precedono ogni frase)**, riportando gli **ORARI, solo per i capitoli, paragrafi, capoversi e concetti chiave**. 
2. **Meticolosità è meglio della Sintesi:** Sii **rigoroso, meticoloso e puntiglioso**, non perdere nessuna affermazione significativa. Non sintetizzare troppo !!!
3. **Aggiornamento Tecnico Real-Time:** 
    * Verifica ogni nome di tool, framework, libreria o versione menzionata.
    * Se la trascrizione cita versioni obsolete o software rinominati, **correggili obbligatoriamente** basandoti sulle ultime release disponibili online alla data odierna.
4. **Protocollo Linguistico Ibrido:**
    * **Inglese Tecnico:** Mantieni rigorosamente in lingua inglese tutti i termini tecnici, nomi di tool e gergo professionale (es. *deploy, pipeline, feature, legacy, framework, prompt engineering, cloud-native*, ecc.).
    * **Italiano Professionale:** Il resto della prosa deve essere in un italiano fluido, formale, impeccabile e di alto livello.
5. **Integrità e Struttura:**
    * **NON SINTETIZZARE:** Conserva ogni concetto, sfumatura o esempio presente nella trascrizione originale. Espandi e chiarisci i passaggi confusi senza eliminare informazioni.
    * **Formattazione:** Organizza il testo in modo gerarchico utilizzando titoli (H1, H2, H3), elenchi puntati discorsivi e grassetti strategici per la leggibilità.

---

### INPUT DATI PER L'ELABORAZIONE

**TESTO DA REVISIONARE:**
```text
{{TESTO_INPUT_PROMPT_4}}
```

---

### ISTRUZIONI DI OUTPUT:
1. Mostra a schermo l'intera risposta revisionata.
2. Assegna l'intero testo generato alla variabile `{{TESTO_REVISIONATO_P4}}`.
3. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 4: Revisione Dettagliata e Sfoltimento Timestamp`
