# Manuale Utente TenFingersTypingTrainer v6.52

Questa guida integra il manuale della versione 6.51 con gli aggiornamenti introdotti nella versione 6.52.

## 1. Colorazione per modalità nel grafico delle velocità
- **Riconoscimento immediato:** nel grafico delle velocità ogni pallino assume ora un colore specifico in base alla modalità dell'esercizio svolto (Phrases, Custom, Random, Typing, Random Phrase, All Chars, Fonemi, Carenze).
- **Legenda integrata nei filtri:** sotto ciascun filtro di **"Filtra sessioni:"** è presente una riga colorata spessa 4 pixel che indica il colore corrispondente a quella modalità sul grafico.
- **Stati di evidenziazione invariati:**
  - **Verde:** campione attualmente evidenziato al passaggio del mouse.
  - **Arancione:** campioni selezionati per l'eventuale eliminazione o analisi.
