#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const indexHtml = fs.readFileSync(path.join(root, "index.html"), "utf8");
const appCss = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const svgRenderer = fs.readFileSync(path.join(root, "js/ui/interrogation-svg-renderer.js"), "utf8");

function assert(cond, msg) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exit(1);
  }
}

assert(!indexHtml.includes('<circle class="base-dot"'), "I pallini .base-dot devono essere rimossi da index.html");
assert((indexHtml.match(/<line class="key-bump"/g) || []).length === 2, "I due trattini tattili .key-bump su f e j devono essere mantenuti");
assert(indexHtml.includes('id="homeRowFrameLeft"') && indexHtml.includes('x="101.5"') && indexHtml.includes('width="231"'), "Manca il riquadro sinistro #homeRowFrameLeft");
assert(indexHtml.includes('id="homeRowFrameRight"') && indexHtml.includes('x="449.5"') && indexHtml.includes('height="57"'), "Manca il riquadro destro #homeRowFrameRight");
assert(appCss.includes(".home-row-frame") && appCss.includes("stroke: var(--base-dot)") && appCss.includes("pointer-events: none"), "Stile .home-row-frame mancante o incompleto in app.css");
assert(appCss.includes(".interr-keyboard-bn .home-row-frame"), "Occultamento CSS .interr-keyboard-bn .home-row-frame mancante in app.css");
assert(svgRenderer.includes('clone.querySelectorAll(".home-row-frame").forEach((el) => el.remove())'), "Rimozione .home-row-frame mancante in interrogation-svg-renderer.js");

console.log("PASS: test-home-row-frames-v656 verificato.");
