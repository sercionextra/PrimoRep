/* TenFingersTypingTrainer v6.27 | interrogation-ui.js | Interfaccia grafica interattiva Interrogazione (Tastiera B/N, Mani SVG, Popover ASCII, 3 blocchi Carattere, Dito, Riposo). */
(function (global) {
  "use strict";

  const FINGER_NAMES_BASE = [
    { id: "mignolo", label: "Mignolo" },
    { id: "anulare", label: "Anulare" },
    { id: "medio", label: "Medio" },
    { id: "indice", label: "Indice" },
    { id: "pollice", label: "Pollice" },
  ];

  const FINGER_NUM_TO_BASE = {
    "1": { hand: "left", base: "mignolo" },
    "2": { hand: "left", base: "anulare" },
    "3": { hand: "left", base: "medio" },
    "4": { hand: "left", base: "indice" },
    "5": { hand: "left", base: "pollice" },
    "6": { hand: "right", base: "pollice" },
    "7": { hand: "right", base: "indice" },
    "8": { hand: "right", base: "medio" },
    "9": { hand: "right", base: "anulare" },
    "10": { hand: "right", base: "mignolo" },
  };

  function resolveFingerNumber(hand, baseName) {
    const map = {
      left: { mignolo: "1", anulare: "2", medio: "3", indice: "4", pollice: "5" },
      right: { pollice: "6", indice: "7", medio: "8", anulare: "9", mignolo: "10" },
    };
    return (map[hand] && map[hand][baseName]) || "";
  }

  function createEl(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = String(text);
    return el;
  }

  function createSvgEl(tag, attrs) {
    const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
    Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, String(v)));
    return el;
  }

  class InterrogationUI {
    constructor(deps) {
      this.sessionMgr = deps.sessionManager;
      this.catalog = deps.catalog;
      this.getProfileId = deps.getProfileId || (() => "default");
      this.getMaxLessonReached = deps.getMaxLessonReached || (() => 0);
      this.setMaxLessonReached = deps.setMaxLessonReached || (() => {});
      this.showConfirm = deps.showConfirm || ((msg, _title, onOk, onCancel) => {
        if (typeof window !== "undefined" && typeof window.confirm === "function") {
          if (window.confirm(msg)) onOk?.();
          else onCancel?.();
        } else {
          onOk?.();
        }
      });
      this.showAlert = deps.showAlert || ((msg, _title, onOk) => {
        if (typeof window !== "undefined" && typeof window.alert === "function") {
          window.alert(msg);
        }
        onOk?.();
      });
      this.showToast = deps.showToast || ((msg, _icon) => {
        this.showAlert(msg, "ℹ Informazione");
      });
      this.onClose = deps.onClose || (() => {});
      this.onSessionComplete = deps.onSessionComplete || (() => {});

      this.activeSession = null;
      this.activeItems = [];
      this.currentItemIdx = 0;
      this.bound = false;

      this.fingerMode = "soli_tasti_fisici";
      this.manualSelectedIds = [];
      this.manualListeningKeyboard = false;
      this._boundManualKeyHandler = null;
      this._popoverCallback = null;

      this.manualSvg = null;
      this.runSvg = null;

      // Stato vista storico (allineato a StatisticsManager v6.31)
      this.historyMetric = "score";
      this.historyFilterTypes = ["CARATTERE", "TASTO", "DITO", "HOME_ROW"];
      this.historyScopeFilter = "all";
      this._historyAllSessions = [];
      this._historyFilteredSessions = [];
      this._historySelectedIds = new Set();
      this._historySelectionState = 0;
      this._historyResizeObserver = null;

      // Stato vista classifica urgenza tasti e dita (v6.40)
      this.urgencyReasons = {
        error: true,
        consultation: true,
        delay: true,
        consolidation: true,
        underinvestigated: true,
      };
      this.urgencyEntityFilter = "all";
      this._urgencyEvents = [];
      this._urgencyCorrections = [];
      this._urgencyRankingItems = [];
    }

    init() {
      if (this.bound) return;
      this.bound = true;

      document.getElementById("btnCloseInterrogationModal")?.addEventListener("click", () => this.close());
      document.getElementById("btnInterrogationCloseFooter")?.addEventListener("click", () => this.close());

      this._populateMaxLessonSelect();

      const selScope = document.getElementById("interrogationScopeSelect");
      const selMaxLesson = document.getElementById("interrogationMaxLessonSelect");
      const btnSaveMaxLesson = document.getElementById("btnInterrSaveMaxLesson");

      selScope?.addEventListener("change", () => {
        this._refreshCurriculumControls();
        this.manualSelectedIds = [];
        this._renderManualChips();
        this._syncManualVisualSelection();
      });

      selMaxLesson?.addEventListener("change", () => {
        this._refreshCurriculumControls();
        this.manualSelectedIds = [];
        this._renderManualChips();
        this._syncManualVisualSelection();
      });

      btnSaveMaxLesson?.addEventListener("click", () => {
        if (!selMaxLesson) return;
        const chosen = Math.max(0, parseInt(selMaxLesson.value, 10) || 0);
        const currentSaved = this.getMaxLessonReached();
        const applyUpdate = () => {
          this.setMaxLessonReached(chosen);
          this._refreshCurriculumControls();
          this.showToast(`Traguardo lezioni aggiornato a Lez. ${chosen + 1}.`, "✓");
        };
        if (chosen < currentSaved) {
          this.showConfirm(
            `Vuoi abbassare il traguardo salvato nel profilo dalla Lezione ${currentSaved + 1} alla Lezione ${chosen + 1}?`,
            "Aggiorna traguardo lezioni",
            applyUpdate,
          );
        } else {
          applyUpdate();
        }
      });

      document.getElementById("interrHistScopeFilter")?.addEventListener("change", (e) => {
        this.historyScopeFilter = e.target.value || "all";
        this._clearHistorySelection();
        this._renderHistoryChart();
      });

      const selMode = document.getElementById("interrogationModeSelect");
      selMode?.addEventListener("change", () => {
        const manualBox = document.getElementById("interrogationManualBox");
        if (manualBox) {
          manualBox.classList.toggle("is-hidden", selMode.value !== "manual");
        }
        if (selMode.value === "manual") {
          this._mountManualSvg();
          this._syncManualVisualSelection();
          this._setManualKeyboardListen(true);
        } else {
          this._setManualKeyboardListen(false);
        }
      });

      document.getElementById("interrogationTypeSelect")?.addEventListener("change", () => {
        this._syncManualVisualSelection();
        this._renderManualChips();
      });

      document.getElementById("interrogationFingerModeSelect")?.addEventListener("change", (e) => {
        this.fingerMode = e.target.value || "soli_tasti_fisici";
      });

      document.getElementById("btnInterrManualAsciiPicker")?.addEventListener("click", (e) => {
        this._openAsciiPopover(e.currentTarget, { includeSpecial: false, includeNone: false }, (val) => {
          this._addManualCandidateByChar(val);
        });
      });

      document.getElementById("btnInterrManualKeyboardListen")?.addEventListener("click", () => {
        this._setManualKeyboardListen(!this.manualListeningKeyboard);
      });

      document.getElementById("btnInterrManualClear")?.addEventListener("click", () => {
        this.manualSelectedIds = [];
        this._renderManualChips();
        this._syncManualVisualSelection();
      });

      document.getElementById("btnCloseAsciiPopover")?.addEventListener("click", () => {
        this._closeAsciiPopover();
      });

      document.getElementById("btnStartInterrogation")?.addEventListener("click", () => this.handleStartSession());
      document.getElementById("btnOpenInterrogationHistory")?.addEventListener("click", () => this.showHistoryView());
      document.getElementById("btnInterrHistBack")?.addEventListener("click", () => this.showSetupView());

      // Selettori metriche storico
      document.querySelectorAll('input[name="interrHistMetric"]').forEach((radio) => {
        radio.addEventListener("change", (e) => {
          document.querySelectorAll('input[name="interrHistMetric"]').forEach((r) => {
            r.parentElement?.classList.remove("radio-label-active");
          });
          e.target.parentElement?.classList.add("radio-label-active");
          this.historyMetric = e.target.value || "score";
          this._renderHistoryChart();
        });
      });

      // Filtri tipologia quesito storico
      document.querySelectorAll(".interr-hist-type-chk").forEach((chk) => {
        chk.addEventListener("change", () => {
          const types = [];
          document.querySelectorAll(".interr-hist-type-chk:checked").forEach((c) => {
            types.push(c.value);
          });
          this.historyFilterTypes = types;
          this._clearHistorySelection();
          this._renderHistoryChart();
        });
      });

      // Filtri Data e Ora separati (allineati a StatisticsManager)
      [
        "interrHistStartDate",
        "interrHistStartTime",
        "interrHistEndDate",
        "interrHistEndTime",
      ].forEach((id) => {
        const el = document.getElementById(id);
        if (el) {
          el.addEventListener("input", () => this._renderHistoryChart());
          el.addEventListener("change", () => this._renderHistoryChart());
        }
      });

      const clearHistField = (inputId) => {
        const input = document.getElementById(inputId);
        if (input) {
          input.value = "";
          input.classList.remove("input-field-error");
          input.classList.remove("filter-active");
          this._renderHistoryChart();
        }
      };
      document.getElementById("btnInterrHistClearStartDate")?.addEventListener("click", () => clearHistField("interrHistStartDate"));
      document.getElementById("btnInterrHistClearStartTime")?.addEventListener("click", () => clearHistField("interrHistStartTime"));
      document.getElementById("btnInterrHistClearEndDate")?.addEventListener("click", () => clearHistField("interrHistEndDate"));
      document.getElementById("btnInterrHistClearEndTime")?.addEventListener("click", () => clearHistField("interrHistEndTime"));

      document.getElementById("btnInterrHistResetFilter")?.addEventListener("click", () => {
        [
          "interrHistStartDate",
          "interrHistStartTime",
          "interrHistEndDate",
          "interrHistEndTime",
        ].forEach((id) => {
          const inp = document.getElementById(id);
          if (inp) {
            inp.value = "";
            inp.classList.remove("input-field-error", "filter-active");
          }
        });
        const msgEl = document.getElementById("lblInterrHistDateValidationMessage");
        if (msgEl) {
          msgEl.classList.add("is-hidden");
          msgEl.textContent = "";
        }
        this._clearHistorySelection();
        this._renderHistoryChart();
      });

      document.getElementById("btnInterrHistDeleteSelected")?.addEventListener("click", () => this._deleteHistorySamples("selected"));
      document.getElementById("btnInterrHistDeleteNotSelected")?.addEventListener("click", () => this._deleteHistorySamples("notSelected"));
      document.getElementById("btnInterrHistClearAll")?.addEventListener("click", () => this._clearAllHistory());

      document.getElementById("btnInterrHistRepeat")?.addEventListener("click", () => this._openRepeatPanel());
      document.getElementById("btnInterrHistRepeatAll")?.addEventListener("click", () => this._startRepeatSession(true));
      document.getElementById("btnInterrHistRepeatFiltered")?.addEventListener("click", () => this._startRepeatSession(false));
      document.getElementById("btnInterrHistRepeatCancel")?.addEventListener("click", () => this._closeRepeatPanel());

      const histHost = document.getElementById("interrHistoryChartHost");
      const urgencyHost = document.getElementById("interrUrgencyChartHost");
      if ((histHost || urgencyHost) && typeof global.ResizeObserver === "function" && !this._historyResizeObserver) {
        this._historyResizeObserver = new global.ResizeObserver(() => this.handleResize());
        if (histHost) this._historyResizeObserver.observe(histHost);
        if (urgencyHost) this._historyResizeObserver.observe(urgencyHost);
      }
      window.addEventListener("resize", () => this.handleResize());

      // Switcher segmentato 2 grafici storico (stile Statistiche v6.40)
      document.getElementById("btnInterrHistNavChrono")?.addEventListener("click", () => {
        this._scrollToHistorySection(1);
      });
      document.getElementById("btnInterrHistNavUrgency")?.addEventListener("click", () => {
        this._scrollToHistorySection(2);
      });
      document.getElementById("btnInterrUrgencyBackToTop")?.addEventListener("click", () => {
        this._scrollToHistorySection(1);
      });

      const histViewEl = document.getElementById("interrogationView_history");
      histViewEl?.addEventListener("scroll", () => {
        const sec2 = document.getElementById("interrHistorySection2");
        if (!sec2 || !histViewEl) return;
        const threshold = histViewEl.clientHeight * 0.45;
        this._updateHistoryTabButtons(histViewEl.scrollTop >= threshold ? 2 : 1);
      });

      // Checkbox motivazioni classifica urgenza (v6.40)
      document.querySelectorAll(".interr-urgency-reason-chk").forEach((chk) => {
        chk.addEventListener("change", () => {
          const next = Object.assign({}, this.urgencyReasons);
          document.querySelectorAll(".interr-urgency-reason-chk").forEach((c) => {
            next[c.value] = !!c.checked;
          });
          this.urgencyReasons = next;
          this._renderUrgencyChart();
        });
      });

      // Filtro entità classifica urgenza: Tutti / Solo Tasti / Solo Dita (v6.40)
      document.querySelectorAll('input[name="interrUrgencyEntity"]').forEach((radio) => {
        radio.addEventListener("change", (e) => {
          document.querySelectorAll('input[name="interrUrgencyEntity"]').forEach((r) => {
            r.parentElement?.classList.remove("radio-label-active");
          });
          e.target.parentElement?.classList.add("radio-label-active");
          this.urgencyEntityFilter = e.target.value || "all";
          this._renderUrgencyChart();
        });
      });

      document.getElementById("btnResumeSuspendedInterrogation")?.addEventListener("click", () => this.handleResumeSuspended());
      document.getElementById("btnAbandonSuspendedInterrogation")?.addEventListener("click", () => this.handleAbandonSuspended());
      document.getElementById("btnInterrogationFinishItem")?.addEventListener("click", () => this.handleFinishMainQuestion());
      document.getElementById("btnInterrogationSuspend")?.addEventListener("click", () => this.handleSuspend());
      document.getElementById("btnInterrogationAbandon")?.addEventListener("click", () => this.handleAbandonActive());
      document.getElementById("btnInterrogationComplete")?.addEventListener("click", () => this.handleComplete());
      document.getElementById("btnInterrogationNewSession")?.addEventListener("click", () => this.showSetupView());
    }

    async open() {
      this.init();
      const modal = document.getElementById("interrogationModal");
      if (!modal) return;
      modal.classList.add("active");
      await this.showSetupView();
    }

    close() {
      this._setManualKeyboardListen(false);
      this._closeAsciiPopover();
      const modal = document.getElementById("interrogationModal");
      if (modal) modal.classList.remove("active");
      this.onClose();
    }

    _switchView(viewName) {
      this._closeAsciiPopover();
      this._setManualKeyboardListen(false);
      ["setup", "run", "summary", "history"].forEach((v) => {
        const el = document.getElementById(`interrogationView_${v}`);
        if (el) el.classList.toggle("is-hidden", v !== viewName);
      });
      const hdrMeta = document.getElementById("interrHeaderMeta");
      if (hdrMeta) {
        hdrMeta.classList.toggle("is-hidden", viewName !== "run");
      }
      const navGroup = document.getElementById("interrHistoryNavGroup");
      if (navGroup) {
        navGroup.classList.toggle("is-hidden", viewName !== "history");
      }
    }

    _populateMaxLessonSelect() {
      const sel = document.getElementById("interrogationMaxLessonSelect");
      const scopeApi = global.LessonCurriculumScope;
      if (!sel || !scopeApi) return;
      const count = scopeApi.getLessonCount();
      if (count <= 0) return;
      sel.innerHTML = "";
      for (let i = 0; i < count; i++) {
        const opt = document.createElement("option");
        opt.value = String(i);
        const name = scopeApi.getLessonName(i);
        opt.textContent = name ? `Lez. ${i + 1}: ${name}` : `Lez. ${i + 1}`;
        sel.appendChild(opt);
      }
      const saved = Math.max(0, Math.min(count - 1, this.getMaxLessonReached()));
      sel.value = String(saved);
    }

    _getActiveSetupScope() {
      const selScope = document.getElementById("interrogationScopeSelect");
      const selMaxLesson = document.getElementById("interrogationMaxLessonSelect");
      const lessonScope = selScope ? selScope.value || "curriculum" : "curriculum";
      if (lessonScope !== "curriculum") {
        return { lessonScope: "full", maxLessonIndex: null };
      }
      const raw = selMaxLesson ? parseInt(selMaxLesson.value, 10) : this.getMaxLessonReached();
      const maxLessonIndex = Number.isNaN(raw) ? this.getMaxLessonReached() : Math.max(0, raw);
      return { lessonScope: "curriculum", maxLessonIndex };
    }

    _refreshCurriculumControls() {
      const { lessonScope, maxLessonIndex } = this._getActiveSetupScope();
      const lessonRow = document.getElementById("interrogationLessonRow");
      const btnSave = document.getElementById("btnInterrSaveMaxLesson");
      const summaryEl = document.getElementById("interrCurriculumSummary");

      if (lessonRow) {
        lessonRow.classList.toggle("is-hidden", lessonScope !== "curriculum");
      }
      if (btnSave) {
        const saved = this.getMaxLessonReached();
        const showSave = lessonScope === "curriculum" && maxLessonIndex !== null && maxLessonIndex !== saved;
        btnSave.classList.toggle("is-hidden", !showSave);
      }
      if (summaryEl && lessonScope === "curriculum" && maxLessonIndex !== null) {
        const scopeApi = global.LessonCurriculumScope;
        if (scopeApi && typeof scopeApi.getScopeUpToLesson === "function") {
          const s = scopeApi.getScopeUpToLesson(maxLessonIndex);
          summaryEl.textContent = `Inclusi fino a Lez. ${maxLessonIndex + 1}: ${s.unlockedKeyIds.size} tasti, ${s.unlockedChars.size} caratteri`;
        } else {
          summaryEl.textContent = "";
        }
      } else if (summaryEl) {
        summaryEl.textContent = "";
      }
    }

    async showSetupView() {
      this._switchView("setup");
      const profileId = this.getProfileId();

      const selMaxLesson = document.getElementById("interrogationMaxLessonSelect");
      if (selMaxLesson) {
        if (selMaxLesson.options.length === 0) {
          this._populateMaxLessonSelect();
        }
        const maxCount = Math.max(0, selMaxLesson.options.length - 1);
        const saved = Math.max(0, Math.min(maxCount, this.getMaxLessonReached()));
        selMaxLesson.value = String(saved);
      }
      this._refreshCurriculumControls();

      const progress = await this.sessionMgr.getProfileProgress(profileId);
      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt("interrStatTotal", progress.totalDefinitions);
      setTxt("interrStatNever", progress.neverVerified);
      setTxt("interrStatWeak", progress.weak);
      setTxt("interrStatReview", progress.review);
      setTxt("interrStatConsolidated", progress.consolidated);
      setTxt("interrStatDue", progress.dueNow);

      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      const suspBanner = document.getElementById("interrogationSuspendedBanner");
      if (suspBanner) {
        suspBanner.classList.toggle("is-hidden", !suspended);
        if (suspended) {
          const scopeBadge =
            suspended.lessonScope === "curriculum" && suspended.maxLessonIndex !== null && suspended.maxLessonIndex !== undefined
              ? `Piano di Studio Lez. 1-${suspended.maxLessonIndex + 1}`
              : "Tastiera Completa";
          setTxt(
            "interrogationSuspendedInfo",
            `Sessione sospesa (${scopeBadge}, ${suspended.mode}, domanda ${(suspended.currentItemIndex || 0) + 1} di ${suspended.effectiveCount}, punteggio ${suspended.score})`,
          );
        }
      }
      const btnStart = document.getElementById("btnStartInterrogation");
      if (btnStart) {
        btnStart.classList.toggle("is-blocked", !!suspended);
        btnStart.title = suspended
          ? "Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova."
          : "";
      }

      const selMode = document.getElementById("interrogationModeSelect");
      if (selMode && selMode.value === "manual") {
        this._mountManualSvg();
        this._syncManualVisualSelection();
        this._setManualKeyboardListen(true);
      } else {
        this._setManualKeyboardListen(false);
      }
      this._renderManualChips();
    }

    _mountManualSvg() {
      const kbHost = document.getElementById("interrManualKeyboardHost");
      const hHost = document.getElementById("interrManualHandsHost");
      if (!kbHost || !hHost || typeof global.InterrogationSvgRenderer !== "function") return;

      if (!this.manualSvg) {
        this.manualSvg = new global.InterrogationSvgRenderer({
          onKeyClick: (keyId) => this._addManualCandidateByKeyId(keyId),
          onFingerClick: (fingerId) => this._addManualCandidateByFingerId(fingerId),
          onLandmarkClick: (info) => {
            const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
            if (typeVal === "DITO") {
              this._addManualCandidateByFingerId(info.fingerId);
            } else if (info.keyId) {
              this._addManualCandidateByKeyId(info.keyId);
            } else if (info.keyLabel) {
              this._addManualCandidateByChar(String(info.keyLabel).toLowerCase());
            } else if (info.fingerId) {
              this._addManualCandidateByFingerId(info.fingerId);
            }
          },
        });
      }
      this.manualSvg.mount(kbHost, hHost);
      this._syncManualVisualSelection();
    }

    _setManualKeyboardListen(enabled) {
      this.manualListeningKeyboard = !!enabled;
      const btn = document.getElementById("btnInterrManualKeyboardListen");
      if (btn) {
        btn.textContent = enabled
          ? "Ascolta tastiera fisica: ON (premi un tasto)"
          : "Ascolta tastiera fisica: OFF";
        btn.classList.toggle("btn-primary", enabled);
      }

      if (this._boundManualKeyHandler) {
        window.removeEventListener("keydown", this._boundManualKeyHandler, true);
        this._boundManualKeyHandler = null;
      }

      if (enabled) {
        this._boundManualKeyHandler = (e) => {
          if (e.key === "Escape") {
            this._setManualKeyboardListen(false);
            return;
          }
          if (["Shift", "Control", "Alt", "AltGraph", "Meta", "CapsLock"].includes(e.key)) {
            return;
          }
          e.preventDefault();
          e.stopPropagation();
          this._addManualCandidateByChar(e.key);
        };
        window.addEventListener("keydown", this._boundManualKeyHandler, true);
      }
    }

    _syncManualVisualSelection() {
      if (!this.manualSvg) return;
      this.manualSvg.resetKeyboard();
      this.manualSvg.resetHands();

      const selectedKeys = new Set();
      const selectedFingers = new Set();
      const meta = global.InterrogationLayoutMetadata;

      this.manualSelectedIds.forEach((cid) => {
        const c = this.catalog.getCandidateById(cid);
        if (!c) return;

        let resolvedKeyId = c.keyId || null;
        if (!resolvedKeyId && c.character && meta && typeof meta.getKeyIdForChar === "function") {
          resolvedKeyId = meta.getKeyIdForChar(c.character);
        }
        if (resolvedKeyId) {
          selectedKeys.add(resolvedKeyId);
        }

        if (c.questionType === "DITO") {
          const fNum = String(c.fingerId || c.mainElementSemanticId || "").replace(/^finger\./, "");
          if (fNum) selectedFingers.add(Number(fNum));
        } else if (c.questionType === "HOME_ROW" && meta && meta.HOME_ROW_KEYS) {
          const hand = c.handId || (String(c.candidateId || "").includes("right") ? "right" : "left");
          const hrKeys = meta.HOME_ROW_KEYS[hand] || [];
          hrKeys.forEach((hk) => {
            if (hk && hk.keyId) selectedKeys.add(hk.keyId);
          });
        }
      });

      selectedKeys.forEach((kId) => {
        this.manualSvg.highlightKey(kId, "interr-key-selected");
      });
      this.manualSvg.highlightFingersOnHands(selectedFingers);
    }

    _toggleManualCandidate(match) {
      if (!match) return;
      const { lessonScope, maxLessonIndex } = this._getActiveSetupScope();
      if (
        lessonScope === "curriculum" &&
        maxLessonIndex !== null &&
        this.catalog &&
        typeof this.catalog.isCandidateInCurriculum === "function" &&
        !this.catalog.isCandidateInCurriculum(match, maxLessonIndex)
      ) {
        this.showToast(`Elemento non ancora in programma fino alla Lez. ${maxLessonIndex + 1}.`, "⚠");
        return;
      }
      const idx = this.manualSelectedIds.indexOf(match.candidateId);
      if (idx >= 0) {
        this.manualSelectedIds.splice(idx, 1);
      } else {
        this.manualSelectedIds.push(match.candidateId);
      }
      this._syncManualVisualSelection();
      this._renderManualChips();
    }

    _addManualCandidateByKeyId(keyId) {
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const all = this.catalog.getCandidates({});
      let match = null;

      if (typeVal === "HOME_ROW") {
        const pk = this.catalog.getPhysicalKey(keyId);
        const hand = pk && Number(pk.assignedFinger) <= 5 ? "left" : "right";
        match = all.find((c) => c.questionType === "HOME_ROW" && (c.handId === hand || c.candidateId.includes(hand)));
      } else if (typeVal === "DITO") {
        const pk = this.catalog.getPhysicalKey(keyId);
        if (pk) {
          match = all.find((c) => c.questionType === "DITO" && String(c.fingerId) === String(pk.assignedFinger));
        }
      } else if (typeVal === "TASTO") {
        match = all.find((c) => c.questionType === "TASTO" && c.keyId === keyId);
      } else {
        // CARATTERE o MIXED: cerca carattere normale del tasto
        const slots = global.InterrogationLayoutMetadata?.getKeySlots(keyId);
        const targetChar = slots && slots.normal ? slots.normal : null;
        if (targetChar) {
          match = all.find((c) => c.questionType === "CARATTERE" && c.character === targetChar);
        }
        if (!match) {
          match = all.find((c) => c.keyId === keyId);
        }
      }

      this._toggleManualCandidate(match);
    }

    _addManualCandidateByChar(ch) {
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const all = this.catalog.getCandidates({});
      let match = null;

      if (typeVal === "TASTO") {
        const charCand = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
        if (charCand && charCand.keyId) {
          match = all.find((c) => c.questionType === "TASTO" && c.keyId === charCand.keyId);
        }
      } else if (typeVal === "DITO") {
        const charCand = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
        if (charCand && charCand.keyId) {
          const pk = this.catalog.getPhysicalKey(charCand.keyId);
          if (pk) {
            match = all.find((c) => c.questionType === "DITO" && String(c.fingerId) === String(pk.assignedFinger));
          }
        }
      } else {
        match = all.find((c) => c.questionType === "CARATTERE" && c.character === ch);
      }

      this._toggleManualCandidate(match);
    }

    _addManualCandidateByFingerId(fingerId) {
      const fNum = String(fingerId || "").replace(/^finger\./, "");
      const all = this.catalog.getCandidates({ questionType: "DITO" });
      const match = all.find((c) => String(c.fingerId) === fNum || String(c.mainElementSemanticId) === `finger.${fNum}`);
      this._toggleManualCandidate(match);
    }

    _renderManualChips() {
      const box = document.getElementById("interrManualSelectedChips");
      if (!box) return;
      box.innerHTML = "";
      if (this.manualSelectedIds.length === 0) {
        box.appendChild(createEl("span", "interr-chip-empty", "Nessuna selezione manuale effettuata."));
        return;
      }
      this.manualSelectedIds.forEach((cid) => {
        const c = this.catalog.getCandidateById(cid);
        if (!c) return;
        const lbl =
          typeof this.catalog.getReadableCandidateLabel === "function"
            ? this.catalog.getReadableCandidateLabel(c)
            : cid;
        const chip = createEl("span", "interr-selected-chip");
        chip.appendChild(createEl("span", "", lbl));
        const rm = createEl("button", "interr-chip-remove", "✕");
        rm.type = "button";
        rm.addEventListener("click", () => {
          this.manualSelectedIds = this.manualSelectedIds.filter((id) => id !== cid);
          this._syncManualVisualSelection();
          this._renderManualChips();
        });
        chip.appendChild(rm);
        box.appendChild(chip);
      });
    }

    _setSetupFeedback(msg, kind) {
      const el = document.getElementById("interrogationSetupFeedback");
      if (!el) return;
      el.textContent = msg || "";
      el.className = "interrogation-feedback" + (kind ? ` is-${kind}` : "");
    }

    _setFeedback(msg, kind) {
      const el = document.getElementById("interrogationFeedback");
      if (!el) return;
      el.textContent = msg || "";
      el.className = "interrogation-feedback" + (kind ? ` is-${kind}` : "");
    }

    async handleStartSession() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (suspended) {
        const msg = "Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova.";
        this._setSetupFeedback(msg, "error");
        this.showToast(msg, "⚠");
        return;
      }
      const mode = document.getElementById("interrogationModeSelect")?.value || "random";
      const typeVal = document.getElementById("interrogationTypeSelect")?.value || "CARATTERE";
      const countVal = parseInt(document.getElementById("interrogationCountSelect")?.value || "10", 10);
      this.fingerMode = document.getElementById("interrogationFingerModeSelect")?.value || "soli_tasti_fisici";

      let manualIds = [];
      if (mode === "manual") {
        manualIds = this.manualSelectedIds.slice();
        if (manualIds.length === 0) {
          this._setSetupFeedback(
            "Seleziona almeno un elemento (clic su tastiera B/N, mani, tastiera fisica o griglia ASCII).",
            "error",
          );
          return;
        }
      }

      this._setSetupFeedback("", "");
      const { lessonScope, maxLessonIndex } = this._getActiveSetupScope();
      const created = await this.sessionMgr.createSession({
        profileId,
        mode,
        lessonScope,
        maxLessonIndex,
        questionTypes: typeVal === "MIXED" ? ["HOME_ROW", "TASTO", "CARATTERE", "DITO"] : [typeVal],
        requestedCount: mode === "manual" ? manualIds.length : countVal,
        manualCandidateIds: manualIds,
      });

      if (created.reducedAvailability) {
        this.showToast(
          `Disponibili ${created.session.effectiveCount} domande su ${created.session.requestedCount} per il programma selezionato.`,
          "ℹ",
        );
      }

      this.activeSession = created.session;
      this.activeItems = created.items;
      this.currentItemIdx = 0;
      this._setFeedback("", "");
      this._renderRunView();
    }

    async handleResumeSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      const resumed = await this.sessionMgr.resumeSession(profileId, suspended.sessionId);
      this.activeSession = resumed.session;
      this.activeItems = resumed.items;
      this.currentItemIdx = resumed.session.currentItemIndex || 0;
      this._renderRunView();
    }

    async handleAbandonSuspended() {
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (!suspended) return;
      await this.sessionMgr.abandonSession(profileId, suspended.sessionId);
      await this.showSetupView();
    }

    _mountRunSvg() {
      const kbHost = document.getElementById("interrRunKeyboardHost");
      const hHost = document.getElementById("interrRunHandsHost");
      if (!kbHost || !hHost || typeof global.InterrogationSvgRenderer !== "function") return;
      if (!this.runSvg) {
        this.runSvg = new global.InterrogationSvgRenderer({
          onKeyClick: (keyId) => this._handleRunKeyboardClick(keyId),
          onFingerClick: (fingerId) => {
            if (typeof this._activeRunFingerClickHandler === "function") {
              this._activeRunFingerClickHandler(fingerId);
            }
          },
          onLandmarkClick: (info) => {
            if (typeof this._activeRunLandmarkClickHandler === "function") {
              this._activeRunLandmarkClickHandler(info);
            }
          },
        });
      }
      this.runSvg.mount(kbHost, hHost);
    }

    _handleRunKeyboardClick(keyId) {
      if (typeof this._activeRunKeyClickHandler === "function") {
        this._activeRunKeyClickHandler(keyId);
      }
    }

    _computeSessionMaxScore() {
      if (!Array.isArray(this.activeItems) || this.activeItems.length === 0) {
        return (this.activeSession && this.activeSession.maxScore) || 0;
      }
      return this.activeItems.reduce((acc, it) => {
        if (it.questionType === "CARATTERE" || it.questionType === "TASTO") {
          return acc + 18; // 3 (Accordo) + 3 (Slot Tasto) + 12 (4 direzioni Margherita)
        }
        return acc + 3;
      }, 0);
    }

    _updateRunScoreHeader() {
      const scoreEl = document.getElementById("interrogationRunScore");
      if (scoreEl && this.activeSession) {
        const maxScore = this._computeSessionMaxScore();
        scoreEl.textContent = `Punteggio: ${this.activeSession.score} / ${maxScore}`;
      }
    }

    _resolveTargetCharacterForItem(item) {
      const meta = global.InterrogationLayoutMetadata;
      let resolvedKeyId = item.keyId || null;
      let resolvedChar = item.character || null;

      if (!resolvedChar && item.mainElementSemanticId && this.catalog) {
        const mapping = this.catalog.getCharacterMappingBySemanticId(item.mainElementSemanticId);
        if (mapping) {
          resolvedChar = mapping.value;
          if (!resolvedKeyId && mapping.physicalKeySemanticId) {
            resolvedKeyId = String(mapping.physicalKeySemanticId).replace(/^key\./, "");
          }
        }
      }
      if (!resolvedKeyId && item.mainElementSemanticId && String(item.mainElementSemanticId).startsWith("key.")) {
        resolvedKeyId = String(item.mainElementSemanticId).replace(/^key\./, "");
      }
      if (!resolvedKeyId && resolvedChar && meta) {
        resolvedKeyId = meta.getKeyIdForChar(resolvedChar);
      }

      if (item.questionType === "CARATTERE" && resolvedChar) {
        return { char: resolvedChar, keyId: resolvedKeyId };
      }
      if (item.questionType === "TASTO" && resolvedKeyId && meta) {
        if (!item._resolvedRandomChar) {
          const slots = meta.getKeySlots(resolvedKeyId) || {};
          const available = [slots.normal, slots.shift, slots.altgr, slots.shiftAltgr].filter(Boolean);
          const idx = available.length > 0 ? Math.floor(Math.random() * available.length) : 0;
          item._resolvedRandomChar = available[idx] || resolvedKeyId;
        }
        return { char: item._resolvedRandomChar, keyId: resolvedKeyId };
      }
      return { char: resolvedChar || "", keyId: resolvedKeyId };
    }

    _renderRunView() {
      this._switchView("run");
      this._mountRunSvg();
      this._activeRunKeyClickHandler = null;
      this._activeRunFingerClickHandler = null;
      this._activeRunLandmarkClickHandler = null;

      const total = this.activeItems.length;
      const item = this.activeItems[this.currentItemIdx];
      if (!item) return;

      const progEl = document.getElementById("interrogationRunProgress");
      const badgeEl = document.getElementById("interrTargetBadge");
      const titleEl = document.getElementById("interrogationQuestionTitle");
      const panelEl = document.getElementById("interrInteractivePanel");
      const btnNext = document.getElementById("btnInterrogationFinishItem");
      const btnComp = document.getElementById("btnInterrogationComplete");

      if (progEl) progEl.textContent = `Domanda ${this.currentItemIdx + 1} di ${total}`;
      this._updateRunScoreHeader();

      if (btnNext) btnNext.classList.toggle("is-hidden", this.currentItemIdx >= total - 1);
      if (btnComp) btnComp.classList.toggle("is-hidden", this.currentItemIdx < total - 1);

      this.runSvg.resetKeyboard();
      this.runSvg.resetHands();
      if (panelEl) panelEl.innerHTML = "";

      const setQuestionTitle = (prefix, targetText, suffix = "") => {
        if (!titleEl) return;
        const targetSpan = createEl("span", "", targetText);
        targetSpan.id = "target";
        titleEl.replaceChildren(
          document.createTextNode(prefix),
          targetSpan,
          document.createTextNode(suffix),
        );
      };

      if (item.questionType === "CARATTERE" || item.questionType === "TASTO") {
        const target = this._resolveTargetCharacterForItem(item);
        if (badgeEl) badgeEl.textContent = `CARATTERE: "${target.char}"`;
        if (item.questionType === "TASTO") {
          setQuestionTitle('TASTO selezionato (CARATTERE estratto): "', target.char, '"');
        } else {
          setQuestionTitle('CARATTERE da analizzare: "', target.char, '"');
        }
        this._renderCharacterQuestionPanel(panelEl, item, target.char, target.keyId);
      } else if (item.questionType === "DITO") {
        const fId = String(item.fingerId || item.mainElementSemanticId || "").replace(/^finger\./, "");
        const fLabel = this.catalog.getReadableFingerName(fId);
        if (badgeEl) badgeEl.textContent = `DITO: ${fLabel}`;
        setQuestionTitle("Individua i TASTI/CARATTERI per il dito: ", fLabel);
        this._renderFingerQuestionPanel(panelEl, item, fId);
      } else if (item.questionType === "HOME_ROW") {
        const hand =
          item.handId ||
          (String(item.candidateId || "").includes("right") ? "right" : "left");
        const handLabel = hand === "right" ? "Mano Destra" : "Mano Sinistra";
        if (badgeEl) badgeEl.textContent = `RIPOSO: ${handLabel}`;
        setQuestionTitle("Tasti in POSIZIONE di RIPOSO — ", handLabel);
        this._renderHomeRowQuestionPanel(panelEl, item, hand);
      }
    }

    async _recordBlock(item, blockId, outcome, userAnswer) {
      const res = await this.sessionMgr.recordBlockEvaluation({
        profileId: this.getProfileId(),
        sessionId: this.activeSession.sessionId,
        itemId: item.itemId,
        blockId,
        outcome,
        userAnswer,
      });
      this.activeSession.score = res.sessionScore;
      this._updateRunScoreHeader();
      return res;
    }

    _applyBlockBadge(badgeEl, outcome, detailText) {
      if (!badgeEl) return;
      badgeEl.className = "interr-outcome-badge";
      if (outcome === "correct") {
        badgeEl.classList.add("is-ok");
        badgeEl.textContent = `OK (+3 pt) ${detailText || ""}`.trim();
      } else if (outcome === "consulted") {
        badgeEl.classList.add("is-consulted");
        badgeEl.textContent = `CONSULTA (+1 pt) ${detailText || ""}`.trim();
      } else {
        badgeEl.classList.add("is-ko");
        badgeEl.textContent = `KO (0 pt) ${detailText || ""}`.trim();
      }
    }

    _getModifierKeyIdsForMode(modMode) {
      const norm = global.InterrogationLayoutMetadata?.normalizeModifierMode(modMode) || "none";
      if (norm === "shift") return ["key_shift_l", "key_shift_r"];
      if (norm === "altgr") return ["key_altgr", "key_ctrl_l", "key_alt_l"];
      if (norm === "shiftAltgr") return ["key_shift_l", "key_altgr", "key_ctrl_l", "key_alt_l"];
      return [];
    }

    _renderCharacterQuestionPanel(panelEl, item, targetChar, keyId) {
      const meta = global.InterrogationLayoutMetadata;
      const pk = this.catalog.getPhysicalKey(keyId);
      const ext = meta.getKeyExtension(keyId);
      const slots = meta.getKeySlots(keyId) || {};
      const neighbors = meta.getNeighbors(keyId) || {};

      // Determina lo slot noto del carattere target
      let knownSlot = "normal";
      let expectedModMode = "none";
      if (slots.shift === targetChar) {
        knownSlot = "shift";
        expectedModMode = "shift";
      } else if (slots.altgr === targetChar) {
        knownSlot = "altgr";
        expectedModMode = "altgr";
      } else if (slots.shiftAltgr === targetChar) {
        knownSlot = "shiftAltgr";
        expectedModMode = "shiftAltgr";
      }

      const expectedFingerNum = String(pk ? pk.assignedFinger : item.fingerId || "");
      const expectedFingerInfo = FINGER_NUM_TO_BASE[expectedFingerNum] || { hand: "left", base: "indice" };

      const grid = createEl("div", "interr-char-blocks-grid");

      // =========================================================
      // BLOCCO 1: DESCRIZIONE ACCORDO
      // =========================================================
      const blk1 = createEl("section", "interr-block-card");
      const h1 = createEl("div", "interr-block-header");
      h1.appendChild(createEl("h5", "", "1) Descrizione Accordo"));
      const badge1 = createEl("span", "interr-outcome-badge");
      h1.appendChild(badge1);
      blk1.appendChild(h1);

      const form1 = createEl("div", "interr-accord-grid-compact");
      const leftCol = createEl("div", "interr-accord-left-col");
      const rightCol = createEl("div", "interr-accord-right-col");

      const addEmptyOpt = (sel, label = "—") => {
        const opt = createEl("option", "", label);
        opt.value = "";
        sel.appendChild(opt);
      };

      const selHand = createEl("select", "interr-input");
      addEmptyOpt(selHand);
      [
        { v: "left", l: "Sinistra (sn)" },
        { v: "right", l: "Destra (dx)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selHand.appendChild(opt);
      });
      selHand.value = "";

      const selFinger = createEl("select", "interr-input");
      addEmptyOpt(selFinger);
      FINGER_NAMES_BASE.forEach((f) => {
        const opt = createEl("option", "", f.label);
        opt.value = f.id;
        selFinger.appendChild(opt);
      });
      selFinger.value = "";

      const selLatExt = createEl("select", "interr-input");
      addEmptyOpt(selLatExt);
      ["0", "1", "2", "3"].forEach((v) => {
        const opt = createEl("option", "", v === "0" ? "0 (normale)" : v);
        opt.value = v;
        selLatExt.appendChild(opt);
      });
      selLatExt.value = "";

      const selLatDir = createEl("select", "interr-input");
      addEmptyOpt(selLatDir);
      [
        { v: "none", l: "Nessuna (0)" },
        { v: "sn", l: "Sinistra (sn)" },
        { v: "dx", l: "Destra (dx)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selLatDir.appendChild(opt);
      });
      selLatDir.value = "";

      const selLongExt = createEl("select", "interr-input");
      addEmptyOpt(selLongExt);
      [
        { v: "2", l: "+2 (2 righe sopra riposo)" },
        { v: "1", l: "+1 (1 riga sopra riposo)" },
        { v: "0", l: "0 (Posizione di Riposo)" },
        { v: "-1", l: "-1 (1 riga sotto riposo)" },
      ].forEach((o) => {
        const opt = createEl("option", "", o.l);
        opt.value = o.v;
        selLongExt.appendChild(opt);
      });
      selLongExt.value = "";

      const addRowTo = (parent, lbl, ctrl) => {
        const r = createEl("div", "interr-field-row");
        r.appendChild(createEl("label", "", lbl));
        r.appendChild(ctrl);
        parent.appendChild(r);
      };
      addRowTo(leftCol, "Mano:", selHand);
      addRowTo(leftCol, "Dito:", selFinger);
      addRowTo(leftCol, "Direzione sovraccarico:", selLatDir);
      addRowTo(leftCol, "Estensione laterale:", selLatExt);

      addRowTo(rightCol, "Estensione longitudinale:", selLongExt);

      // Checkboxes modificatori: CTRL, SHIFT, ALT, AltGr
      const modBox = createEl("div", "interr-mod-checkboxes");
      modBox.appendChild(createEl("span", "interr-mod-title", "Accordo Modificatore:"));
      const modCbs = {};
      ["CTRL", "SHIFT", "ALT", "AltGr"].forEach((mName) => {
        const lbl = createEl("label", "interr-cb-label");
        const cb = document.createElement("input");
        cb.type = "checkbox";
        modCbs[mName.toLowerCase()] = cb;
        lbl.appendChild(cb);
        lbl.appendChild(createEl("span", "", mName));
        modBox.appendChild(lbl);
      });
      rightCol.appendChild(modBox);

      const act1 = createEl("div", "interr-block-actions");
      const btnOk1 = createEl("button", "btn btn-primary btn-sm", "Conferma Accordo");
      const btnCons1 = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk1.type = "button";
      btnCons1.type = "button";
      act1.appendChild(btnOk1);
      act1.appendChild(btnCons1);
      rightCol.appendChild(act1);

      form1.appendChild(leftCol);
      form1.appendChild(rightCol);
      blk1.appendChild(form1);

      // Scorciatoia grafica: clic su dito o pallino delle mani pre-compila i dropdown senza confermare
      this._activeRunFingerClickHandler = (fId) => {
        if (btnOk1.disabled) return;
        const info = FINGER_NUM_TO_BASE[String(fId)];
        if (info) {
          selHand.value = info.hand;
          selFinger.value = info.base;
          this.runSvg.highlightFingerOnHands(fId);
        }
      };

      this._activeRunLandmarkClickHandler = (info) => {
        if (btnOk1.disabled || !info) return;
        const fInfo = FINGER_NUM_TO_BASE[String(info.fingerId)];
        if (fInfo) {
          selHand.value = fInfo.hand;
          selFinger.value = fInfo.base;
        }
        if (meta) {
          const resolvedKeyId =
            info.keyId ||
            (info.keyLabel && typeof meta.resolveKeyIdFromToken === "function"
              ? meta.resolveKeyIdFromToken(info.keyLabel)
              : null);
          if (resolvedKeyId && typeof meta.getKeyExtension === "function") {
            const lmExt = meta.getKeyExtension(resolvedKeyId);
            if (lmExt) {
              selLatExt.value = String(lmExt.lateralExt);
              selLatDir.value = String(lmExt.lateralDir || "none");
              selLongExt.value = String(lmExt.longitudinalExt);
            }
          }
        }
        if (info.fingerId) {
          this.runSvg.highlightFingerOnHands(info.fingerId);
        }
      };

      const showAccordSolution = (outcome) => {
        btnOk1.disabled = true;
        btnCons1.disabled = true;
        this.runSvg.highlightTargetLandmark(
          keyId,
          expectedFingerNum,
          this._getModifierKeyIdsForMode(expectedModMode),
        );
        const partialSlots = { [knownSlot]: targetChar };
        this.runSvg.revealKey(keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-ko", partialSlots);
        const longLabel = keyId === "key_enter"
          ? "0 o +1"
          : (ext.longitudinalExt > 0 ? "+" + ext.longitudinalExt : ext.longitudinalExt);
        const solText = `Mano ${expectedFingerInfo.hand === "left" ? "sn" : "dx"}, ${expectedFingerInfo.base}, est. lat ${ext.lateralExt} (${ext.lateralDir}), est. long ${longLabel}, mod: ${expectedModMode}`;
        this._applyBlockBadge(badge1, outcome, `— ${solText}`);
      };

      btnOk1.addEventListener("click", async () => {
        if (!selHand.value || !selFinger.value || selLatExt.value === "" || !selLatDir.value || selLongExt.value === "") {
          this._setFeedback("Seleziona tutti i menu a tendina di Descrizione Accordo prima di confermare.", "error");
          return;
        }
        this._setFeedback("", "");
        const chosenFinger = resolveFingerNumber(selHand.value, selFinger.value);
        const fingerOk = chosenFinger === expectedFingerNum;
        const latExtOk = Number(selLatExt.value) === Number(ext.lateralExt);
        const latDirOk = Number(ext.lateralExt) === 0
          ? (selLatDir.value === "none" || Number(selLatExt.value) === 0)
          : selLatDir.value === ext.lateralDir;
        const longOk = keyId === "key_enter"
          ? (selLongExt.value === "0" || selLongExt.value === "1")
          : Number(selLongExt.value) === Number(ext.longitudinalExt);
        const modOk = meta.isModifierMatch(expectedModMode, {
          ctrl: modCbs.ctrl.checked,
          shift: modCbs.shift.checked,
          alt: modCbs.alt.checked,
          altgr: modCbs.altgr.checked,
        });
        const isOk = fingerOk && latExtOk && latDirOk && longOk && modOk;
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "accord", outcome, {
          hand: selHand.value,
          finger: selFinger.value,
          latExt: selLatExt.value,
          latDir: selLatDir.value,
          longExt: selLongExt.value,
        });
        showAccordSolution(outcome);
      });

      btnCons1.addEventListener("click", async () => {
        await this._recordBlock(item, "accord", "consulted", null);
        showAccordSolution("consulted");
      });

      grid.appendChild(blk1);

      // =========================================================
      // BLOCCO 2: CARATTERI SUL TASTO
      // =========================================================
      const blk2 = createEl("section", "interr-block-card");
      const h2 = createEl("div", "interr-block-header");
      h2.appendChild(createEl("h5", "", "2) Caratteri sul Tasto"));
      const badge2 = createEl("span", "interr-outcome-badge");
      h2.appendChild(badge2);
      blk2.appendChild(h2);

      const slotsWrap = createEl("div", "interr-key-slots-wrap");
      const miniHost = createEl("div", "interr-mini-keycap-host");
      const slotList = createEl("div", "interr-slot-list");

      const slotAnswers = {
        normal: knownSlot === "normal" ? targetChar : "",
        shift: knownSlot === "shift" ? targetChar : "",
        altgr: knownSlot === "altgr" ? targetChar : "",
        shiftAltgr: knownSlot === "shiftAltgr" ? targetChar : "",
      };

      const refreshMini = () => {
        this.runSvg.renderKeycapPreview(miniHost, keyId, slotAnswers);
      };
      refreshMini();

      const slotDefs = [
        { key: "normal", label: "NORMALE" },
        { key: "shift", label: "(SHIFT)" },
        { key: "altgr", label: "(CTRL + ALT / AltGr)" },
        { key: "shiftAltgr", label: "(CTRL + ALT + SHIFT)" },
      ];

      const isCurriculumSession =
        (item.lessonScope === "curriculum" || (this.activeSession && this.activeSession.lessonScope === "curriculum")) &&
        (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex) !== null &&
        (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex) !== undefined;
      const itemMaxLessonIdx =
        item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex;
      const scopeApi = global.LessonCurriculumScope;
      const slotConstraints = {};

      slotDefs.forEach((sd) => {
        const constraint =
          isCurriculumSession && scopeApi && typeof scopeApi.getSlotConstraint === "function"
            ? scopeApi.getSlotConstraint(sd.key, slots[sd.key], itemMaxLessonIdx)
            : { allowed: true, requiredLesson1Based: null };
        slotConstraints[sd.key] = constraint;

        const row = createEl("div", "interr-slot-row");
        row.appendChild(createEl("span", "interr-slot-name", sd.label));

        let btnText = sd.key === knownSlot ? targetChar : "Scegli...";
        if (!constraint.allowed && sd.key !== knownSlot) {
          btnText = constraint.requiredLesson1Based
            ? `Da studiare (Lez. ${constraint.requiredLesson1Based})`
            : "Non in programma";
        }

        const btnPick = createEl("button", "btn btn-sm interr-slot-btn", btnText);
        btnPick.type = "button";
        if (sd.key === knownSlot) {
          btnPick.disabled = true;
          btnPick.classList.add("is-prefilled");
        } else if (!constraint.allowed) {
          btnPick.disabled = true;
          btnPick.classList.add("is-out-of-curriculum");
          btnPick.title = btnText;
        } else {
          btnPick.addEventListener("click", (e) => {
            this._openAsciiPopover(
              e.currentTarget,
              {
                includeSpecial: false,
                includeNone: true,
                title: `Seleziona carattere — ${sd.label}`,
              },
              (val) => {
                slotAnswers[sd.key] = val;
                btnPick.textContent = val === "NONE" ? "NESSUNO" : val;
                refreshMini();
              },
            );
          });
        }
        row.appendChild(btnPick);
        slotList.appendChild(row);
      });

      slotsWrap.appendChild(slotList);
      slotsWrap.appendChild(miniHost);
      blk2.appendChild(slotsWrap);

      const act2 = createEl("div", "interr-block-actions");
      const btnOk2 = createEl("button", "btn btn-primary btn-sm", "Conferma Caratteri");
      const btnCons2 = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk2.type = "button";
      btnCons2.type = "button";
      act2.appendChild(btnOk2);
      act2.appendChild(btnCons2);
      blk2.appendChild(act2);

      const showSlotsSolution = (outcome) => {
        btnOk2.disabled = true;
        btnCons2.disabled = true;
        this.runSvg.renderKeycapPreview(miniHost, keyId, {
          normal: true,
          shift: true,
          altgr: true,
          shiftAltgr: true,
        });
        this.runSvg.revealKey(keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-ko");
        this.runSvg.highlightTargetLandmark(
          keyId,
          expectedFingerNum,
          this._getModifierKeyIdsForMode(expectedModMode),
        );
        const summary = `N: ${slots.normal || "NONE"} | S: ${slots.shift || "NONE"} | AG: ${slots.altgr || "NONE"} | S+AG: ${slots.shiftAltgr || "NONE"}`;
        this._applyBlockBadge(badge2, outcome, `— ${summary}`);
      };

      btnOk2.addEventListener("click", async () => {
        const expected = {
          normal: slots.normal || "NONE",
          shift: slots.shift || "NONE",
          altgr: slots.altgr || "NONE",
          shiftAltgr: slots.shiftAltgr || "NONE",
        };
        const isOk = slotDefs.every((sd) => {
          if (slotConstraints[sd.key] && !slotConstraints[sd.key].allowed && sd.key !== knownSlot) {
            return true;
          }
          const ans = slotAnswers[sd.key] || "NONE";
          return ans === expected[sd.key];
        });
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "keyChars", outcome, slotAnswers);
        showSlotsSolution(outcome);
      });

      btnCons2.addEventListener("click", async () => {
        await this._recordBlock(item, "keyChars", "consulted", null);
        showSlotsSolution("consulted");
      });

      grid.appendChild(blk2);

      // =========================================================
      // BLOCCO 3: TASTI INTORNO (MARGHERITA)
      // =========================================================
      const blk3 = createEl("section", "interr-block-card interr-block-wide");
      const h3 = createEl("div", "interr-block-header");
      h3.appendChild(createEl("h5", "", "3) Tasti intorno (Margherita)"));
      const badge3 = createEl("span", "interr-outcome-badge");
      h3.appendChild(badge3);
      blk3.appendChild(h3);

      const margheritaGrid = createEl("div", "interr-margherita-grid");
      const neighborGroups = [
        { id: "top", label: "Coppia sopra", slots: ["topLeft", "topRight"] },
        { id: "left", label: "Sinistra", slots: ["left"] },
        { id: "right", label: "Destra", slots: ["right"] },
        { id: "bottom", label: "Coppia sotto", slots: ["bottomLeft", "bottomRight"] },
      ];

      const neighborAnswers = {};
      neighborGroups.forEach((grp) => {
        const gCard = createEl("div", "interr-neighbor-group");
        gCard.appendChild(createEl("div", "interr-neighbor-title", grp.label));

        const isEnterLeft = keyId === "key_enter" && grp.id === "left";
        const formatOutLabel = (c) =>
          c && c.requiredLesson1Based ? `Da studiare (Lez. ${c.requiredLesson1Based})` : "Non in programma";

        const slotConstraints = {};
        grp.slots.forEach((sName) => {
          if (!isCurriculumSession || !scopeApi || typeof scopeApi.getKeyConstraint !== "function") {
            slotConstraints[sName] = { allowed: true, requiredLesson1Based: null };
          } else if (isEnterLeft && sName === "left") {
            const cPlus = scopeApi.getKeyConstraint("key_plus", itemMaxLessonIdx);
            const cUgrave = scopeApi.getKeyConstraint("key_ugrave", itemMaxLessonIdx);
            if (cPlus.allowed || cUgrave.allowed) {
              slotConstraints[sName] = { allowed: true, requiredLesson1Based: null };
            } else {
              const minReq = [cPlus.requiredLesson1Based, cUgrave.requiredLesson1Based]
                .filter((n) => n !== null)
                .sort((a, b) => a - b)[0] || null;
              slotConstraints[sName] = { allowed: false, requiredLesson1Based: minReq };
            }
          } else {
            slotConstraints[sName] = scopeApi.getKeyConstraint(neighbors[sName], itemMaxLessonIdx);
          }
        });

        const allowedSlots = grp.slots.filter((sName) => slotConstraints[sName].allowed);
        const allOutOfCurriculum = allowedSlots.length === 0;

        const gSlots = createEl("div", "interr-neighbor-slots");
        if (grp.slots.length === 2) {
          grp.slots.forEach((sName) => {
            neighborAnswers[sName] = "";
          });

          if (allOutOfCurriculum) {
            const l0 = formatOutLabel(slotConstraints[grp.slots[0]]);
            const l1 = formatOutLabel(slotConstraints[grp.slots[1]]);
            const txt = l0 === l1 ? l0 : `${l0} , ${l1}`;
            const btnPair = createEl("button", "btn btn-sm interr-slot-btn is-out-of-curriculum", txt);
            btnPair.type = "button";
            btnPair.disabled = true;
            btnPair.title = txt;
            gSlots.appendChild(btnPair);
          } else if (allowedSlots.length === 1) {
            const allowedIdx = slotConstraints[grp.slots[0]].allowed ? 0 : 1;
            const outIdx = allowedIdx === 0 ? 1 : 0;
            const allowedName = grp.slots[allowedIdx];
            const outLabel = formatOutLabel(slotConstraints[grp.slots[outIdx]]);
            const initTxt = allowedIdx === 0 ? `Scegli... , ${outLabel}` : `${outLabel} , Scegli...`;
            const btnPair = createEl("button", "btn btn-sm interr-slot-btn", initTxt);
            btnPair.type = "button";
            btnPair.addEventListener("click", (e) => {
              const posTxt = allowedIdx === 0 ? "1° tasto (a sinistra)" : "2° tasto (a destra)";
              this._openAsciiPopover(
                e.currentTarget,
                {
                  includeSpecial: true,
                  includeNone: true,
                  title: `${grp.label} — ${posTxt}`,
                },
                (val) => {
                  neighborAnswers[allowedName] = val;
                  const disp = val === "NONE" ? "NESSUNO" : val;
                  btnPair.textContent = allowedIdx === 0 ? `${disp} , ${outLabel}` : `${outLabel} , ${disp}`;
                },
              );
            });
            gSlots.appendChild(btnPair);
          } else {
            const btnPair = createEl("button", "btn btn-sm interr-slot-btn", "Scegli...");
            btnPair.type = "button";
            btnPair.addEventListener("click", (e) => {
              let step = 0;
              const firstTitle = `${grp.label} — 1° tasto (a sinistra)`;
              const firstHint = "Seleziona in ordine: prima il 1° tasto (a sinistra), poi il 2° tasto (a destra).";
              this._openAsciiPopover(
                e.currentTarget,
                {
                  includeSpecial: true,
                  includeNone: true,
                  keepOpen: true,
                  title: firstTitle,
                  hint: firstHint,
                },
                (val, ctx) => {
                  const disp = val === "NONE" ? "NESSUNO" : val;
                  if (step === 0) {
                    neighborAnswers[grp.slots[0]] = val;
                    btnPair.textContent = `${disp} , ...`;
                    step = 1;
                    if (ctx && typeof ctx.updateHeader === "function") {
                      ctx.updateHeader(
                        `${grp.label} — 2° tasto (a destra)`,
                        `1° tasto scelto: "${disp}". Ora seleziona il 2° tasto (a destra).`,
                      );
                    }
                  } else {
                    neighborAnswers[grp.slots[1]] = val;
                    const firstDisp =
                      neighborAnswers[grp.slots[0]] === "NONE"
                        ? "NESSUNO"
                        : neighborAnswers[grp.slots[0]] || "NESSUNO";
                    btnPair.textContent = `${firstDisp} , ${disp}`;
                    this._closeAsciiPopover();
                  }
                },
              );
            });
            gSlots.appendChild(btnPair);
          }
        } else {
          const sName = grp.slots[0];
          neighborAnswers[sName] = "";
          if (allOutOfCurriculum) {
            const outLabel = formatOutLabel(slotConstraints[sName]);
            const btn = createEl("button", "btn btn-sm interr-slot-btn is-out-of-curriculum", outLabel);
            btn.type = "button";
            btn.disabled = true;
            btn.title = outLabel;
            gSlots.appendChild(btn);
          } else {
            const btn = createEl("button", "btn btn-sm interr-slot-btn", "Scegli...");
            btn.type = "button";
            btn.addEventListener("click", (e) => {
              const purposeTitle =
                grp.id === "left" ? "Tasto a sinistra" : grp.id === "right" ? "Tasto a destra" : grp.label;
              this._openAsciiPopover(
                e.currentTarget,
                {
                  includeSpecial: true,
                  includeNone: true,
                  title: purposeTitle,
                },
                (val) => {
                  neighborAnswers[sName] = val;
                  btn.textContent = val === "NONE" ? "NESSUNO" : val;
                },
              );
            });
            gSlots.appendChild(btn);
          }
        }
        gCard.appendChild(gSlots);

        const gBadge = createEl("span", "interr-outcome-badge interr-mini-badge");
        const gActs = createEl("div", "interr-block-actions");
        const bOk = createEl("button", "btn btn-primary btn-sm", "Conferma");
        const bCons = createEl("button", "btn btn-sm", "Consulta (+1)");
        bOk.type = "button";
        bCons.type = "button";
        if (allOutOfCurriculum) {
          bOk.disabled = true;
          bCons.disabled = true;
          gBadge.textContent = "Fuori programma";
        }
        gActs.appendChild(bOk);
        gActs.appendChild(bCons);
        gCard.appendChild(gActs);
        gCard.appendChild(gBadge);

        const revealGroup = (outcome) => {
          bOk.disabled = true;
          bCons.disabled = true;
          let expectedLabels;
          if (isEnterLeft) {
            this.runSvg.revealKey("key_plus", "interr-key-neighbor");
            this.runSvg.revealKey("key_ugrave", "interr-key-neighbor");
            expectedLabels = ["+ / ù"];
          } else {
            expectedLabels = grp.slots.map((sName) => {
              if (slotConstraints[sName] && !slotConstraints[sName].allowed) {
                return formatOutLabel(slotConstraints[sName]);
              }
              const nk = neighbors[sName];
              if (nk) {
                this.runSvg.revealKey(nk, "interr-key-neighbor");
              }
              return meta.getKeyDisplayToken(nk);
            });
          }
          this._applyBlockBadge(gBadge, outcome, `— ${expectedLabels.join(" , ")}`);
          this.runSvg.revealKey(
            keyId,
            "interr-key-target",
            btnOk2.disabled ? null : { [knownSlot]: targetChar },
          );
          this.runSvg.highlightTargetLandmark(
            keyId,
            expectedFingerNum,
            this._getModifierKeyIdsForMode(expectedModMode),
          );
        };

        bOk.addEventListener("click", async () => {
          const isOk = grp.slots.every((sName) => {
            if (slotConstraints[sName] && !slotConstraints[sName].allowed) {
              return true;
            }
            const expectedKeyId = neighbors[sName];
            const givenToken = neighborAnswers[sName] || "NONE";
            if (isEnterLeft && sName === "left") {
              const resolved = meta.resolveKeyIdFromToken(givenToken);
              return resolved === "key_plus" || resolved === "key_ugrave" || givenToken === "+" || givenToken === "ù";
            }
            if (!expectedKeyId) return givenToken === "NONE";
            return meta.resolveKeyIdFromToken(givenToken) === expectedKeyId;
          });
          const outcome = isOk ? "correct" : "incorrect";
          await this._recordBlock(item, `neighbors_${grp.id}`, outcome, neighborAnswers);
          revealGroup(outcome);
        });

        bCons.addEventListener("click", async () => {
          await this._recordBlock(item, `neighbors_${grp.id}`, "consulted", null);
          revealGroup("consulted");
        });

        margheritaGrid.appendChild(gCard);
      });

      blk3.appendChild(margheritaGrid);
      grid.appendChild(blk3);
      panelEl.appendChild(grid);
    }

    _renderFingerQuestionPanel(panelEl, item, fingerId) {
      const meta = global.InterrogationLayoutMetadata;
      const card = createEl("section", "interr-block-card interr-block-wide");
      const h = createEl("div", "interr-block-header");
      h.appendChild(createEl("h5", "", "Tasti e Caratteri associati al Dito"));
      const badge = createEl("span", "interr-outcome-badge");
      h.appendChild(badge);
      card.appendChild(h);

      // Evidenzia solo il dito sulle mani; NESSUNA evidenziazione preventiva dei tasti (nessun suggerimento)
      this.runSvg.highlightFingerOnHands(fingerId);

      const selectedDisplay = createEl("div", "interr-selected-chips");
      // Mappa keyId -> carattere/token scelto dall'utente
      const userChoices = new Map();
      let isLocked = false;

      const renderSelectionChips = () => {
        selectedDisplay.innerHTML = "";
        if (userChoices.size === 0) {
          selectedDisplay.appendChild(
            createEl(
              "span",
              "interr-chip-empty",
              "Clicca un tasto sulla tastiera B/N per colorarlo di giallo e abbinargli il carattere dalla palette.",
            ),
          );
          return;
        }
        userChoices.forEach((chosenChar, kId) => {
          const chip = createEl("span", "interr-selected-chip", chosenChar);
          if (!isLocked) {
            const rm = createEl("button", "interr-chip-remove", "×");
            rm.type = "button";
            rm.title = "Rimuovi selezione tasto";
            rm.addEventListener("click", () => {
              userChoices.delete(kId);
              this.runSvg.unhighlightKey(kId, "interr-key-yellow");
              this.runSvg.setKeyUserBadge(kId, "");
              renderSelectionChips();
            });
            chip.appendChild(rm);
          }
          selectedDisplay.appendChild(chip);
        });
      };
      renderSelectionChips();

      this._activeRunKeyClickHandler = (keyId) => {
        if (isLocked) return;
        this.runSvg.highlightKey(keyId, "interr-key-yellow");
        const keyEl = document.querySelector(`#interrKeyboardHost [data-key-id="${keyId}"]`);
        this._openAsciiPopover(
          keyEl || selectedDisplay,
          { includeSpecial: true, includeNone: false },
          (chosenChar) => {
            if (isLocked) return;
            userChoices.set(keyId, chosenChar);
            this.runSvg.highlightKey(keyId, "interr-key-yellow");
            this.runSvg.setKeyUserBadge(keyId, chosenChar);
            renderSelectionChips();
          },
        );
      };

      card.appendChild(selectedDisplay);

      const acts = createEl("div", "interr-block-actions");
      const btnOk = createEl("button", "btn btn-primary btn-sm", "Conferma Selezione");
      const btnCons = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk.type = "button";
      btnCons.type = "button";
      acts.appendChild(btnOk);
      acts.appendChild(btnCons);
      card.appendChild(acts);

      const doesCharBelongToKey = (keyId, ch) => {
        if (!ch) return false;
        const sl = meta.getKeySlots(keyId) || {};
        const token = meta.getKeyDisplayToken(keyId);
        const valid = [sl.normal, sl.shift, sl.altgr, sl.shiftAltgr, token].filter(Boolean);
        if (valid.includes(ch)) return true;
        return meta.resolveKeyIdFromToken(ch) === keyId;
      };

      const getExpectedFingerKeys = () => {
        const allKeys = meta.getKeysForFinger(this.catalog, fingerId, {});
        const isCurr =
          (item.lessonScope === "curriculum" || (this.activeSession && this.activeSession.lessonScope === "curriculum")) &&
          (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
            ? item.maxLessonIndex
            : this.activeSession?.maxLessonIndex) !== null &&
          (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
            ? item.maxLessonIndex
            : this.activeSession?.maxLessonIndex) !== undefined;
        const maxIdx =
          item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
            ? item.maxLessonIndex
            : this.activeSession?.maxLessonIndex;
        const scopeApi = global.LessonCurriculumScope;
        if (isCurr && scopeApi && typeof scopeApi.getScopeUpToLesson === "function") {
          const scope = scopeApi.getScopeUpToLesson(maxIdx);
          const filtered = allKeys.filter((k) => scope.unlockedKeyIds.has(String(k.keyId).replace(/^key\./, "")));
          if (filtered.length > 0) return filtered;
        }
        return allKeys;
      };

      const revealFingerSolution = (outcome) => {
        isLocked = true;
        btnOk.disabled = true;
        btnCons.disabled = true;
        this._closeAsciiPopover();

        const expected = getExpectedFingerKeys();
        const expectedSet = new Set(expected.map((k) => k.keyId));

        // Tasti corretti del dito: verde con caratteri reali svelati
        expected.forEach((k) => {
          this.runSvg.unhighlightKey(k.keyId, "interr-key-yellow");
          this.runSvg.setKeyUserBadge(k.keyId, "");
          this.runSvg.revealKey(k.keyId, "interr-key-ok");
        });

        // Tasti scelti dall'utente fuori posto: restano gialli con l'informazione inserita dall'utente
        userChoices.forEach((chosenChar, kId) => {
          if (!expectedSet.has(kId)) {
            this.runSvg.highlightKey(kId, "interr-key-yellow");
            this.runSvg.setKeyUserBadge(kId, chosenChar);
          }
        });

        renderSelectionChips();
        const txt = expected.map((k) => meta.getKeyDisplayToken(k.keyId)).join(", ");
        this._applyBlockBadge(badge, outcome, `— Tasti attesi: ${txt}`);
      };

      btnOk.addEventListener("click", async () => {
        const expectedKeys = getExpectedFingerKeys();
        const expSet = new Set(expectedKeys.map((k) => k.keyId));
        const isOk =
          expSet.size === userChoices.size &&
          Array.from(expSet).every((kId) => userChoices.has(kId) && doesCharBelongToKey(kId, userChoices.get(kId)));

        const outcome = isOk ? "correct" : "incorrect";
        const payload = Array.from(userChoices.entries()).map(([keyId, char]) => ({ keyId, char }));
        await this._recordBlock(item, "fingerKeys", outcome, payload);
        revealFingerSolution(outcome);
      });

      btnCons.addEventListener("click", async () => {
        await this._recordBlock(item, "fingerKeys", "consulted", null);
        revealFingerSolution("consulted");
      });

      panelEl.appendChild(card);
    }

    _renderHomeRowQuestionPanel(panelEl, item, hand) {
      const meta = global.InterrogationLayoutMetadata;
      const rawExpectedList = meta.HOME_ROW_KEYS[hand] || meta.HOME_ROW_KEYS.left;
      const isCurr =
        (item.lessonScope === "curriculum" || (this.activeSession && this.activeSession.lessonScope === "curriculum")) &&
        (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex) !== null &&
        (item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex) !== undefined;
      const maxIdx =
        item.maxLessonIndex !== null && item.maxLessonIndex !== undefined
          ? item.maxLessonIndex
          : this.activeSession?.maxLessonIndex;
      const scopeApi = global.LessonCurriculumScope;
      let expectedList = rawExpectedList;
      if (isCurr && scopeApi && typeof scopeApi.getScopeUpToLesson === "function") {
        const scope = scopeApi.getScopeUpToLesson(maxIdx);
        const filtered = rawExpectedList.filter((exp) =>
          scope.unlockedKeyIds.has(String(exp.keyId).replace(/^key\./, "")),
        );
        if (filtered.length > 0) {
          expectedList = filtered;
        }
      }

      const card = createEl("section", "interr-block-card interr-block-wide");
      const h = createEl("div", "interr-block-header");
      const nKeys = expectedList.length;
      h.appendChild(
        createEl(
          "h5",
          "",
          `Clicca ${nKeys === 1 ? "il tasto" : `i ${nKeys} tasti`} in Posizione di Riposo (${hand === "left" ? "Sinistra" : "Destra"}) sulla tastiera B/N e indica carattere + dito`,
        ),
      );
      const badge = createEl("span", "interr-outcome-badge");
      h.appendChild(badge);
      card.appendChild(h);

      const rowsBox = createEl("div", "interr-homerow-rows");
      const entries = expectedList.map((_, idx) => ({
        idx,
        keyId: "",
        char: "",
        fingerId: "",
      }));

      let activeRowIdx = 0;

      const renderRows = () => {
        rowsBox.innerHTML = "";
        entries.forEach((ent) => {
          const r = createEl("div", "interr-homerow-row" + (ent.idx === activeRowIdx ? " is-active" : ""));
          const btnPickKey = createEl(
            "button",
            `btn btn-sm interr-homerow-pick-${ent.idx}`,
            ent.keyId ? `Tasto #${ent.idx + 1} selezionato` : `Seleziona tasto #${ent.idx + 1} su tastiera`,
          );
          btnPickKey.type = "button";
          btnPickKey.addEventListener("click", () => {
            activeRowIdx = ent.idx;
            renderRows();
          });

          const btnChar = createEl("button", "btn btn-sm interr-slot-btn", ent.char || "Carattere...");
          btnChar.type = "button";
          btnChar.addEventListener("click", (e) => {
            this._openAsciiPopover(
              e.currentTarget,
              {
                includeSpecial: false,
                includeNone: false,
                title: `Posizione di Riposo — Carattere tasto #${ent.idx + 1}`,
              },
              (ch) => {
                ent.char = ch;
                btnChar.textContent = ch;
              },
            );
          });

          const selFinger = createEl("select", "interr-input");
          const optEmpty = createEl("option", "", "Dito...");
          optEmpty.value = "";
          selFinger.appendChild(optEmpty);
          Object.entries(FINGER_NUM_TO_BASE).forEach(([id, info]) => {
            const opt = createEl("option", "", `${info.base} (${info.hand === "left" ? "sn" : "dx"})`);
            opt.value = id;
            selFinger.appendChild(opt);
          });
          selFinger.value = ent.fingerId;
          selFinger.addEventListener("change", () => {
            ent.fingerId = selFinger.value;
          });

          r.appendChild(btnChar);
          r.appendChild(selFinger);
          r.appendChild(btnPickKey);
          rowsBox.appendChild(r);
        });
      };
      renderRows();

      this._activeRunKeyClickHandler = (keyId) => {
        const rowCls = `interr-key-row-${activeRowIdx}`;
        const prevKeyId = entries[activeRowIdx].keyId;
        if (prevKeyId) {
          this.runSvg.unhighlightKey(prevKeyId, rowCls);
        }
        entries[activeRowIdx].keyId = keyId;
        this.runSvg.highlightKey(keyId, rowCls);
        if (activeRowIdx < entries.length - 1) activeRowIdx++;
        renderRows();
      };

      card.appendChild(rowsBox);

      const acts = createEl("div", "interr-block-actions");
      const btnOk = createEl("button", "btn btn-primary btn-sm", "Conferma Posizione Riposo");
      const btnCons = createEl("button", "btn btn-sm", "Consulta (+1)");
      btnOk.type = "button";
      btnCons.type = "button";
      acts.appendChild(btnOk);
      acts.appendChild(btnCons);
      card.appendChild(acts);

      const revealHomeSolution = (outcome) => {
        btnOk.disabled = true;
        btnCons.disabled = true;
        entries.forEach((ent) => {
          if (ent.keyId) {
            this.runSvg.unhighlightKey(ent.keyId, `interr-key-row-${ent.idx}`);
          }
        });
        expectedList.forEach((exp) => {
          this.runSvg.revealKey(exp.keyId, outcome === "correct" ? "interr-key-ok" : "interr-key-neighbor");
        });
        const txt = expectedList.map((e) => `${e.char} (${e.fingerLabel})`).join(" | ");
        this._applyBlockBadge(badge, outcome, `— ${txt}`);
      };

      btnOk.addEventListener("click", async () => {
        const isOk = expectedList.every((exp) => {
          return entries.some(
            (ent) => ent.keyId === exp.keyId && ent.char === exp.char && String(ent.fingerId) === exp.fingerId,
          );
        });
        const outcome = isOk ? "correct" : "incorrect";
        await this._recordBlock(item, "homeRow", outcome, entries);
        revealHomeSolution(outcome);
      });

      btnCons.addEventListener("click", async () => {
        await this._recordBlock(item, "homeRow", "consulted", null);
        revealHomeSolution("consulted");
      });

      panelEl.appendChild(card);
    }

    _openAsciiPopover(anchorEl, options, onSelect) {
      const pop = document.getElementById("interrAsciiPopover");
      const body = document.getElementById("interrAsciiPopoverBody");
      const titleSpan = document.getElementById("interrAsciiPopoverTitle");
      if (!pop || !body) return;

      const opts = options || {};
      const meta = global.InterrogationLayoutMetadata;
      body.innerHTML = "";

      if (titleSpan) {
        titleSpan.textContent = opts.title || "Seleziona carattere / tasto";
      }

      const targetBadgeEl = document.getElementById("interrAsciiPopoverTarget");
      if (targetBadgeEl) {
        const runView = document.getElementById("interrogationView_run");
        const inRun = runView && !runView.classList.contains("is-hidden");
        const badgeText =
          opts.targetBadge !== undefined
            ? String(opts.targetBadge || "")
            : inRun
              ? document.getElementById("interrTargetBadge")?.textContent || ""
              : "";
        targetBadgeEl.textContent = badgeText;
        targetBadgeEl.classList.toggle("is-hidden", !badgeText);
      }

      let hintEl = null;
      if (opts.hint) {
        hintEl = createEl("div", "interr-ascii-hint", opts.hint);
        body.appendChild(hintEl);
      }

      const pickerCtx = {
        updateHeader: (newTitle, newHint) => {
          if (titleSpan && newTitle) titleSpan.textContent = newTitle;
          if (hintEl && newHint) hintEl.textContent = newHint;
        },
      };

      const handlePick = (val) => {
        if (!opts.keepOpen) {
          this._closeAsciiPopover();
        }
        onSelect(val, pickerCtx);
      };

      const makeNoneButton = () => {
        const noneBtn = createEl("button", "btn btn-sm interr-ascii-btn interr-ascii-none", "NESSUNO");
        noneBtn.type = "button";
        noneBtn.addEventListener("click", () => handlePick("NONE"));
        return noneBtn;
      };

      if (opts.includeNone) {
        body.appendChild(makeNoneButton());
      }

      const CHAR_ROWS = [
        ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"],
        ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"],
        ["à", "è", "é", "ì", "ò", "ù", "ç"],
        ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
        ["*", "+", "-", "/", "^", "(", ")", "[", "]", "{", "}", "<", "=", ">"],
        ["$", "£", "€", "%", "&", "°", "@", "#", "\\", "|", "_", "\"", "'", "`", "~", "§"],
        [",", ".", ";", ":", "?", "!"],
      ];

      const charsWrap = createEl("div", "interr-ascii-rows");
      CHAR_ROWS.forEach((rowChars) => {
        const rowEl = createEl("div", "interr-ascii-row");
        rowChars.forEach((ch) => {
          const b = createEl("button", "btn btn-sm interr-ascii-btn", ch);
          b.type = "button";
          b.title = `ASCII ${ch.charCodeAt(0)}`;
          b.addEventListener("click", () => handlePick(ch));
          rowEl.appendChild(b);
        });
        charsWrap.appendChild(rowEl);
      });
      body.appendChild(charsWrap);

      if (opts.includeSpecial && meta) {
        const specialRows = [
          ["TAB", "CAPS", "SHIFT-sn", "SHIFT-dx", "CTRL-sn", "CTRL-dx"],
          ["WIN-sn", "WIN-dx", "ALT", "ALTGR", "MENU", "SPAZIO", "INVIO", "BACK"],
        ];
        const specWrap = createEl("div", "interr-ascii-rows");
        specialRows.forEach((rowLabels) => {
          const rowEl = createEl("div", "interr-ascii-row");
          rowLabels.forEach((lbl) => {
            const b = createEl("button", "btn btn-sm interr-ascii-btn interr-ascii-special", lbl);
            b.type = "button";
            b.addEventListener("click", () => handlePick(lbl));
            rowEl.appendChild(b);
          });
          specWrap.appendChild(rowEl);
        });
        body.appendChild(specWrap);
      }

      if (opts.includeNone) {
        body.appendChild(makeNoneButton());
      }

      pop.classList.remove("is-hidden");

      // Posiziona dinamicamente vicino al pulsante cliccato (orizzontalmente centrato, sopra o sotto) via CSSOM (CSP-safe)
      if (anchorEl) {
        pop.classList.add("is-positioned");
        const vpW = (typeof window !== "undefined" && window.innerWidth) || 1280;
        const vpH = (typeof window !== "undefined" && window.innerHeight) || 800;
        const margin = 12;
        const gap = 8;

        const rect = anchorEl.getBoundingClientRect();
        const popRect = pop.getBoundingClientRect();
        const popW = popRect.width || Math.min(780, Math.round(vpW * 0.96));
        const popH = popRect.height || Math.min(500, Math.round(vpH * 0.70));

        let left = Math.round(rect.left + rect.width / 2 - popW / 2);
        left = Math.max(margin, Math.min(vpW - popW - margin, left));

        let top = Math.round(rect.bottom + gap);
        if (top + popH > vpH - margin) {
          const aboveTop = Math.round(rect.top - popH - gap);
          if (aboveTop >= margin) {
            top = aboveTop;
          } else {
            top = Math.max(margin, vpH - popH - margin);
          }
        }

        pop.style.right = "auto";
        pop.style.bottom = "auto";
        pop.style.left = left + "px";
        pop.style.top = top + "px";
      } else {
        pop.classList.remove("is-positioned");
        pop.style.left = "";
        pop.style.top = "";
        pop.style.right = "";
        pop.style.bottom = "";
      }
    }

    _closeAsciiPopover() {
      const pop = document.getElementById("interrAsciiPopover");
      if (pop) {
        pop.classList.add("is-hidden");
        pop.classList.remove("is-positioned");
      }
    }

    async handleFinishMainQuestion() {
      const item = this.activeItems[this.currentItemIdx];
      if (!item || !this.activeSession) return;
      await this.sessionMgr.finishMainQuestion({
        profileId: this.getProfileId(),
        sessionId: this.activeSession.sessionId,
        itemId: item.itemId,
      });
      if (this.currentItemIdx < this.activeItems.length - 1) {
        this.currentItemIdx++;
        this._setFeedback("", "");
        this._renderRunView();
      }
    }

    _buildSessionSummaryAlertText(session, prefixText) {
      const score = Number((session && session.score) || 0);
      const maxSc = Number((session && session.maxScore) || this._computeSessionMaxScore() || 0);
      const pct = maxSc > 0 ? Math.round((score / maxSc) * 100) : 0;

      let c = 0;
      let cons = 0;
      let inc = 0;
      let ign = 0;
      if (session && typeof session.correctCount === "number") {
        c = session.correctCount;
        cons = session.consultedCount || 0;
        inc = session.incorrectCount || 0;
        ign = session.ignoredCount || 0;
      } else if (typeof this.sessionMgr._computeSessionStats === "function") {
        const stats = this.sessionMgr._computeSessionStats(this.activeItems || [], session);
        c = stats.correctCount;
        cons = stats.consultedCount;
        inc = stats.incorrectCount;
        ign = stats.ignoredCount;
      }

      return (
        `${prefixText}\n\n` +
        `Punteggio: ${score} / ${maxSc} pt (${pct}%)\n` +
        `Corrette: ${c} | Errate: ${inc} | Consultate: ${cons} | Ignorate: ${ign}`
      );
    }

    async handleSuspend() {
      if (!this.activeSession) return;
      const currentSess = this.activeSession;
      const profileId = currentSess.profileId || this.getProfileId();
      try {
        const sess = await this.sessionMgr.suspendSession(profileId, currentSess.sessionId);
        const msg = this._buildSessionSummaryAlertText(
          sess || currentSess,
          "Sessione sospesa: potrai riprenderla alla prossima apertura dell'Interrogazione.",
        );
        this.activeSession = null;
        this.close();
        this.showAlert(msg, "⏸ Sessione Sospesa");
      } catch (err) {
        this._setFeedback((err && err.message) || "Impossibile sospendere la sessione.", "error");
      }
    }

    async handleAbandonActive() {
      if (!this.activeSession) return;
      const currentSess = this.activeSession;
      const profileId = currentSess.profileId || this.getProfileId();
      try {
        const sess = await this.sessionMgr.abandonSession(profileId, currentSess.sessionId);
        const msg = this._buildSessionSummaryAlertText(
          sess || currentSess,
          "Sessione abbandonata.",
        );
        this.activeSession = null;
        this.close();
        this.showAlert(msg, "✖ Sessione Abbandonata");
      } catch (err) {
        this._setFeedback((err && err.message) || "Impossibile abbandonare la sessione.", "error");
      }
    }

    async handleComplete() {
      if (!this.activeSession) return;
      const currentSess = this.activeSession;
      const profileId = currentSess.profileId || this.getProfileId();
      try {
        const result = await this.sessionMgr.completeSession(profileId, currentSess.sessionId);
        const completed = result && result.session ? result.session : result;
        try {
          this.onSessionComplete(completed);
        } catch (cbErr) {
          if (typeof console !== "undefined" && typeof console.error === "function") {
            console.error("Errore salvataggio statistiche sessione:", cbErr);
          }
        }
        const msg = this._buildSessionSummaryAlertText(
          completed,
          "Sessione completata e salvata nello storico e nelle statistiche del profilo.",
        );
        this.activeSession = null;
        this.close();
        this.showAlert(msg, "🎓 Sessione Conclusa");
      } catch (err) {
        this._setFeedback((err && err.message) || "Impossibile completare la sessione.", "error");
      }
    }

    _renderSummaryView(session) {
      this._switchView("summary");
      const sumScore = document.getElementById("interrogationSummaryScore");
      if (sumScore) {
        const maxSc = Number(session.maxScore || this._computeSessionMaxScore() || 0);
        const pct = maxSc > 0 ? Math.round((Number(session.score || 0) / maxSc) * 100) : 0;
        sumScore.textContent = `Punteggio finale: ${session.score} / ${maxSc} punti (${pct}%)`;
      }

      const items = this.activeItems || [];
      let c = 0, cons = 0, inc = 0, unans = 0;
      if (typeof session.correctCount === "number") {
        c = session.correctCount;
        cons = session.consultedCount || 0;
        inc = session.incorrectCount || 0;
        unans = session.ignoredCount || 0;
      } else {
        items.forEach((it) => {
          const evals = Object.values(it.blockEvaluations || {});
          if (evals.length > 0) {
            evals.forEach((ev) => {
              if (ev.outcome === "correct") c++;
              else if (ev.outcome === "consulted") cons++;
              else if (ev.outcome === "incorrect") inc++;
            });
          } else {
            (it.subQuestions || []).forEach((sq) => {
              if (sq.outcome === "correct") c++;
              else if (sq.outcome === "consulted") cons++;
              else if (sq.outcome === "incorrect") inc++;
              else unans++;
            });
          }
        });
      }

      const setTxt = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = String(val);
      };
      setTxt("interrSumCorrect", c);
      setTxt("interrSumConsulted", cons);
      setTxt("interrSumIncorrect", inc);
      setTxt("interrSumUnanswered", unans);

      const notice = document.getElementById("interrSummaryStatsNotice");
      if (notice) {
        notice.textContent = `Punteggio (+${session.score} pt) salvato nelle statistiche del profilo.`;
      }
    }

    handleResize() {
      const histView = document.getElementById("interrogationView_history");
      if (histView && !histView.classList.contains("is-hidden")) {
        this._renderHistoryChart();
        this._renderUrgencyChart();
      }
    }

    async showHistoryView() {
      this._switchView("history");
      this._closeRepeatPanel();
      this._historySelectedIds = new Set();
      this._historySelectionState = 0;
      this._updateHistoryTabButtons(1);
      const histView = document.getElementById("interrogationView_history");
      if (histView) histView.scrollTop = 0;
      await Promise.all([this._loadHistorySessions(), this._loadUrgencyData()]);
      this._renderHistoryChart();
      this._renderUrgencyChart();
    }

    async _loadHistorySessions() {
      const profileId = this.getProfileId();
      if (typeof this.sessionMgr.getCompletedSessionsWithStats === "function") {
        this._historyAllSessions = await this.sessionMgr.getCompletedSessionsWithStats(profileId);
      } else {
        const all = await this.sessionMgr.repository.getSessionsByProfile(profileId);
        this._historyAllSessions = (all || [])
          .filter((s) => s.status === "completed")
          .sort((a, b) => (a.completedAt || a.createdAt || 0) - (b.completedAt || b.createdAt || 0));
      }
    }

    _parseHistoryDateTimeRange() {
      const elDateA = document.getElementById("interrHistStartDate");
      const elTimeB = document.getElementById("interrHistStartTime");
      const elDateC = document.getElementById("interrHistEndDate");
      const elTimeD = document.getElementById("interrHistEndTime");
      const msgEl = document.getElementById("lblInterrHistDateValidationMessage");

      const clearInputErrors = () => {
        [elDateA, elTimeB, elDateC, elTimeD].forEach((inp) => {
          if (inp) {
            inp.classList.remove("input-field-error");
            inp.classList.toggle("filter-active", inp.value.trim().length > 0);
          }
        });
        if (msgEl) {
          msgEl.classList.add("is-hidden");
          msgEl.textContent = "";
        }
      };

      const markError = (inp) => {
        if (!inp) return;
        inp.classList.add("input-field-error");
        inp.classList.remove("filter-active");
      };

      if (!elDateA || !elTimeB || !elDateC || !elTimeD) {
        return { isValid: true, hasFilter: false, minTs: -Infinity, maxTs: Infinity };
      }

      clearInputErrors();

      const valA = elDateA.value.trim();
      const valB = elTimeB.value.trim();
      const valC = elDateC.value.trim();
      const valD = elTimeD.value.trim();

      const hasA = valA.length > 0;
      const hasB = valB.length > 0;
      const hasC = valC.length > 0;
      const hasD = valD.length > 0;

      if (!hasA && !hasB && !hasC && !hasD) {
        return { isValid: true, hasFilter: false, minTs: -Infinity, maxTs: Infinity };
      }

      if (hasA && hasD && !hasC) {
        markError(elDateC);
        markError(elTimeD);
        if (msgEl) {
          msgEl.textContent = "⚠ Specificare la data di fine per applicare il filtro temporale.";
          msgEl.classList.remove("is-hidden");
        }
        return { isValid: false, hasFilter: true, minTs: -Infinity, maxTs: Infinity };
      }

      if (hasC && hasB && !hasA) {
        markError(elDateA);
        markError(elTimeB);
        if (msgEl) {
          msgEl.textContent = "⚠ Specificare la data di inizio per applicare il filtro temporale.";
          msgEl.classList.remove("is-hidden");
        }
        return { isValid: false, hasFilter: true, minTs: -Infinity, maxTs: Infinity };
      }

      const todayObj = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const todayStr = `${todayObj.getFullYear()}-${pad(todayObj.getMonth() + 1)}-${pad(todayObj.getDate())}`;

      let startTs = 0;
      let endTs = todayObj.getTime();
      const areDatesMissing = !hasA && !hasC;

      if (areDatesMissing) {
        if (hasB && !hasD) {
          startTs = new Date(`${todayStr}T${valB}:00`).getTime();
          endTs = todayObj.getTime();
        } else if (!hasB && hasD) {
          startTs = new Date(`${todayStr}T00:00:00`).getTime();
          endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
        } else if (hasB && hasD) {
          startTs = new Date(`${todayStr}T${valB}:00`).getTime();
          endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
        }
      } else {
        startTs = hasA ? new Date(`${valA}T${hasB ? `${valB}:00` : "00:00:00"}`).getTime() : 0;
        endTs = hasC ? new Date(`${valC}T${hasD ? `${valD}:59.999` : "23:59:59.999"}`).getTime() : todayObj.getTime();
      }

      if (startTs > endTs) {
        if (hasA) markError(elDateA);
        if (hasB) markError(elTimeB);
        if (hasC) markError(elDateC);
        if (hasD) markError(elTimeD);
        if (msgEl) {
          msgEl.textContent = "⚠ La data/ora iniziale non può essere successiva a quella finale.";
          msgEl.classList.remove("is-hidden");
        }
        return { isValid: false, hasFilter: true, minTs: -Infinity, maxTs: Infinity };
      }

      return { isValid: true, hasFilter: true, minTs: startTs, maxTs: endTs };
    }

    _getFilteredHistorySessions() {
      const all = this._historyAllSessions || [];
      const range = this._parseHistoryDateTimeRange();
      if (!range.isValid) return null;

      const activeTypes = new Set(this.historyFilterTypes || []);
      const scopeFilter = this.historyScopeFilter || "all";
      return all.filter((s) => {
        if (scopeFilter !== "all") {
          const sScope = s.lessonScope === "curriculum" ? "curriculum" : "full";
          if (sScope !== scopeFilter) return false;
        }
        const qTypes = Array.isArray(s.questionTypes) && s.questionTypes.length > 0
          ? s.questionTypes
          : ["CARATTERE"];
        if (activeTypes.size === 0) return false;
        const typeMatch = qTypes.some((t) => activeTypes.has(t));
        if (!typeMatch) return false;

        if (range.hasFilter) {
          const ts = Number(s.completedAt || s.createdAt || 0);
          if (ts < range.minTs || ts > range.maxTs) return false;
        }
        return true;
      });
    }

    _getHistorySampleVal(s) {
      const score = Number(s.score || 0);
      const maxScore = Number(s.maxScore || 0);
      if (this.historyMetric === "pct") {
        return maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
      }
      if (this.historyMetric === "total") {
        return Number(s.totalBlocks !== undefined ? s.totalBlocks : (s.effectiveCount || 0));
      }
      if (this.historyMetric === "correct") return Number(s.correctCount || 0);
      if (this.historyMetric === "incorrect") return Number(s.incorrectCount || 0);
      if (this.historyMetric === "consulted") return Number(s.consultedCount || 0);
      if (this.historyMetric === "ignored") return Number(s.ignoredCount || 0);
      return score;
    }

    _formatDateTimeIT(ts) {
      const italianWeekDays = [
        "domenica",
        "lunedì",
        "martedì",
        "mercoledì",
        "giovedì",
        "venerdì",
        "sabato",
      ];
      const d = new Date(ts || Date.now());
      const dd = String(d.getDate()).padStart(2, "0");
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const yyyy = d.getFullYear();
      const hh = String(d.getHours()).padStart(2, "0");
      const min = String(d.getMinutes()).padStart(2, "0");
      const dayName = italianWeekDays[d.getDay()];
      return {
        dateStr: `${dd}/${mm}/${yyyy}`,
        isoDate: `${yyyy}-${mm}-${dd}`,
        timeStr: `${hh}:${min}`,
        dayName,
        full: `${dd}/${mm}/${yyyy} ${hh}:${min}`,
        scrubber: `${yyyy}-${mm}-${dd} - ${hh}:${min} ( ${dayName} )`,
      };
    }

    _formatSessionTypesLabel(s) {
      const qTypes = Array.isArray(s.questionTypes) ? s.questionTypes : [];
      if (qTypes.length === 0) return "CARATTERE";
      if (qTypes.length === 1) return qTypes[0];
      return `MISTA (${qTypes.join(", ")})`;
    }

    _formatHistoryDetailText(s, idx) {
      const t = Number(s.completedAt || s.createdAt || 0);
      const fmt = this._formatDateTimeIT(t);
      const score = Number(s.score || 0);
      const maxScore = Number(s.maxScore || 0);
      const pct = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
      const nDom = Number(s.effectiveCount || s.requestedCount || 0);
      const tipo = this._formatSessionTypesLabel(s);
      const scopeLabel =
        s.lessonScope === "curriculum" && s.maxLessonIndex !== null && s.maxLessonIndex !== undefined
          ? `Piano di Studio Lez. 1-${Number(s.maxLessonIndex) + 1}`
          : "Tastiera Completa";
      const c = Number(s.correctCount || 0);
      const err = Number(s.incorrectCount || 0);
      const cons = Number(s.consultedCount || 0);
      const ign = Number(s.ignoredCount || 0);
      return (
        `Campione #${idx + 1} | ${fmt.dayName} ${fmt.dateStr} ${fmt.timeStr} | ` +
        `[${scopeLabel}] Tipo: ${tipo} (${nDom} dom.) | Punteggio: ${score} / ${maxScore} pt (${pct}%) | ` +
        `Corrette: ${c} | Errate: ${err} | Consultate: ${cons} | Ignorate: ${ign}`
      );
    }

    _clearHistorySelection() {
      this._historySelectedIds.clear();
      this._historySelectionState = 0;
      const selRect = document.getElementById("interrHistSelectionRect");
      if (selRect) selRect.style.display = "none";

      document.querySelectorAll(".interr-history-point").forEach((dot) => {
        dot.classList.remove("selected");
        dot.setAttribute("fill", "#3b82f6");
        dot.setAttribute("r", "4");
      });

      this._updateHistorySelectionUI(this._historyFilteredSessions || []);
      this._closeRepeatPanel();
    }

    _updateHistorySelectionUI(filtered) {
      const list = Array.isArray(filtered) ? filtered : [];
      const selectedList = list.filter((s) => this._historySelectedIds.has(s.sessionId));
      const selCount = selectedList.length;
      const notSelCount = list.length - selCount;

      const btnDelSel = document.getElementById("btnInterrHistDeleteSelected");
      const btnDelNotSel = document.getElementById("btnInterrHistDeleteNotSelected");
      const lblSelCount = document.getElementById("lblInterrHistSelectedCount");
      const lblNotSelCount = document.getElementById("lblInterrHistNotSelectedCount");
      const btnRepeat = document.getElementById("btnInterrHistRepeat");
      const summaryEl = document.getElementById("lblInterrHistSummary");

      if (lblSelCount) lblSelCount.textContent = String(selCount);
      if (lblNotSelCount) lblNotSelCount.textContent = String(Math.max(0, notSelCount));

      if (btnDelSel) {
        btnDelSel.classList.toggle("is-hidden-vis", selCount === 0);
        btnDelSel.disabled = selCount === 0;
      }
      if (btnDelNotSel) {
        const showNot = selCount > 0 && notSelCount > 0;
        btnDelNotSel.classList.toggle("is-hidden-vis", !showNot);
        btnDelNotSel.disabled = !showNot;
      }
      if (btnRepeat) {
        btnRepeat.classList.toggle("is-hidden", selCount !== 1);
      }
      if (selCount !== 1) {
        this._closeRepeatPanel();
      }

      if (summaryEl) {
        const unit = this.historyMetric === "pct" ? "%" : "";
        if (selCount > 0) {
          const vals = selectedList.map((s) => this._getHistorySampleVal(s));
          const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
          const countTxt = selCount === 1 ? "1 campione selezionato" : `${selCount} campioni selezionati`;
          const span = createEl("span", "stats-value-warning", `${avg}${unit}`);
          summaryEl.replaceChildren(span, document.createTextNode(` (su ${countTxt})`));
        } else if (list.length > 0) {
          const vals = list.map((s) => this._getHistorySampleVal(s));
          const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
          summaryEl.textContent = `${avg}${unit} (globale su ${list.length} campioni)`;
        } else {
          summaryEl.textContent = "0";
        }
      }
    }

    _renderHistoryChart() {
      const host = document.getElementById("interrHistoryChartHost");
      const detailBox = document.getElementById("interrHistoryDetailBox");
      const scrubberLabel = document.getElementById("lblInterrHistScrubberTimestamp");
      if (!host) return;

      const samples = this._getFilteredHistorySessions();
      if (samples === null) {
        return;
      }

      this._historyFilteredSessions = samples;
      host.innerHTML = "";

      if (samples.length === 0) {
        host.appendChild(createEl("div", "interr-history-empty", "Nessuna interrogazione completata corrisponde ai filtri selezionati."));
        if (detailBox) detailBox.textContent = "Nessun campione disponibile.";
        if (scrubberLabel) scrubberLabel.textContent = "Sposta il mouse sul grafico";
        this._clearHistorySelection();
        return;
      }

      const W = Math.max(760, host.clientWidth || 820);
      const H = Math.max(180, host.clientHeight || 260);
      const padL = 54;
      const padR = 25;
      const padT = 16;
      const padB = 26;
      const plotW = W - padL - padR;
      const plotH = Math.max(20, H - padT - padB);

      const values = samples.map((s) => this._getHistorySampleVal(s));
      const maxVal = this.historyMetric === "pct"
        ? 100
        : Math.max(10, Math.ceil(Math.max(...values) * 1.15));

      const pts = samples.map((s, idx) => {
        const val = this._getHistorySampleVal(s);
        const x = padL + (idx / Math.max(1, samples.length - 1)) * plotW;
        const y = padT + plotH - (val / maxVal) * plotH;
        const t = Number(s.completedAt || s.createdAt || 0);
        return { session: s, x, y, val, idx, fmt: this._formatDateTimeIT(t) };
      });

      const svgNS = "http://www.w3.org/2000/svg";
      const svgEl = (tag, attrs) => {
        const el = document.createElementNS(svgNS, tag);
        Object.entries(attrs || {}).forEach(([k, v]) => el.setAttribute(k, String(v)));
        return el;
      };

      const svg = svgEl("svg", {
        id: "interrHistorySvgPlot",
        viewBox: `0 0 ${W} ${H}`,
        preserveAspectRatio: "none",
        class: "interr-history-svg",
      });

      // Griglia orizzontale e quote Y
      for (let g = 0; g <= 4; g++) {
        const gy = padT + (plotH / 4) * g;
        const valLabel = Math.round(maxVal - (maxVal / 4) * g);
        svg.appendChild(svgEl("line", {
          x1: padL, y1: gy, x2: W - padR, y2: gy,
          stroke: "var(--border-color, #334155)", "stroke-dasharray": "3 3",
        }));
        const lbl = svgEl("text", {
          x: padL - 8, y: gy + 4, "font-size": 10, "text-anchor": "end", fill: "var(--text-muted, #94a3b8)",
        });
        lbl.textContent = this.historyMetric === "pct" ? `${valLabel}%` : String(valLabel);
        svg.appendChild(lbl);
      }

      // Spezzata
      if (pts.length > 1) {
        let pathD = "";
        pts.forEach((pt, i) => {
          pathD += (i === 0 ? "M " : "L ") + `${pt.x},${pt.y} `;
        });
        svg.appendChild(svgEl("path", { d: pathD, fill: "none", stroke: "#3b82f6", "stroke-width": 2.5 }));
      }

      // Rettangolo selezione + crosshair (identici a StatisticsManager)
      const selRect = svgEl("rect", {
        id: "interrHistSelectionRect",
        x: 0, y: padT, width: 0, height: plotH,
        fill: "rgba(59, 130, 246, 0.22)", stroke: "#3b82f6", "stroke-width": 1.5, "stroke-dasharray": "4 3",
        display: "none", "pointer-events": "none",
      });
      const crossH = svgEl("line", {
        id: "interrHistCrosshairH",
        stroke: "#ef4444", "stroke-width": 1.5, "stroke-dasharray": "4 2",
        display: "none", "pointer-events": "none",
      });
      const crossY = svgEl("text", {
        id: "interrHistCrosshairYLabel",
        fill: "#ef4444", "font-size": 22, "font-weight": 800,
        "text-anchor": "end", "dominant-baseline": "central",
        display: "none", "pointer-events": "none",
      });
      const vLine = svgEl("line", {
        id: "interrHistPreviewVLine",
        stroke: "#38bdf8", "stroke-width": 1.5, "stroke-dasharray": "3 3",
        display: "none", "pointer-events": "none",
      });

      svg.appendChild(selRect);
      svg.appendChild(crossH);
      svg.appendChild(crossY);
      svg.appendChild(vLine);

      pts.forEach((pt) => {
        const isSel = this._historySelectedIds.has(pt.session.sessionId);
        const circle = svgEl("circle", {
          cx: pt.x,
          cy: pt.y,
          r: isSel ? 6 : 4,
          fill: isSel ? "#f59e0b" : "#3b82f6",
          stroke: "#ffffff",
          "stroke-width": 1.5,
          class: isSel ? "interr-history-point selected" : "interr-history-point",
          "data-sid": pt.session.sessionId,
        });

        circle.addEventListener("mouseenter", () => {
          svg.querySelectorAll(".interr-history-point.inspected").forEach((el) => el.classList.remove("inspected"));
          circle.classList.add("inspected");
          if (detailBox) {
            detailBox.textContent = this._formatHistoryDetailText(pt.session, pt.idx);
          }
        });

        svg.appendChild(circle);
      });

      let startSvgX = 0;
      const getSvgCoords = (e) => {
        if (typeof svg.createSVGPoint === "function" && typeof svg.getScreenCTM === "function") {
          const ctm = svg.getScreenCTM();
          if (ctm) {
            const p = svg.createSVGPoint();
            p.x = e.clientX;
            p.y = e.clientY;
            return p.matrixTransform(ctm.inverse());
          }
        }
        const rect = svg.getBoundingClientRect();
        return {
          x: rect.width ? ((e.clientX - rect.left) / rect.width) * W : padL,
          y: rect.height ? ((e.clientY - rect.top) / rect.height) * H : padT,
        };
      };

      const applySelection = (selPts) => {
        this._historySelectedIds = new Set(selPts.map((p) => p.session.sessionId));
        svg.querySelectorAll(".interr-history-point").forEach((dot) => {
          const sid = dot.getAttribute("data-sid");
          if (this._historySelectedIds.has(sid)) {
            dot.classList.add("selected");
            dot.setAttribute("fill", "#f59e0b");
            dot.setAttribute("r", "6");
          } else {
            dot.classList.remove("selected");
            dot.setAttribute("fill", "#3b82f6");
            dot.setAttribute("r", "4");
          }
        });
        this._updateHistorySelectionUI(samples);
        if (selPts.length === 1 && detailBox) {
          detailBox.textContent = this._formatHistoryDetailText(selPts[0].session, selPts[0].idx);
        }
      };

      svg.addEventListener("mousemove", (e) => {
        const svgPt = getSvgCoords(e);
        const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
        const curY = Math.max(padT, Math.min(padT + plotH, svgPt.y));

        if (pts.length > 0 && scrubberLabel) {
          let closestPt = pts[0];
          let minDist = Math.abs(pts[0].x - curX);
          for (let i = 1; i < pts.length; i++) {
            const dist = Math.abs(pts[i].x - curX);
            if (dist < minDist) {
              minDist = dist;
              closestPt = pts[i];
            } else if (pts[i].x > curX) {
              break;
            }
          }
          scrubberLabel.textContent = closestPt.fmt.scrubber;
        }

        const yVal = Math.round(maxVal - ((curY - padT) / plotH) * maxVal);
        crossH.setAttribute("x1", padL);
        crossH.setAttribute("y1", curY);
        crossH.setAttribute("x2", W - padR);
        crossH.setAttribute("y2", curY);
        crossH.style.display = "block";

        crossY.setAttribute("x", padL - 8);
        crossY.setAttribute("y", curY);
        crossY.textContent = this.historyMetric === "pct" ? `${yVal}%` : String(yVal);
        crossY.style.display = "block";

        if (this._historySelectionState === 0) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        } else if (this._historySelectionState === 1) {
          vLine.style.display = "none";
          const minX = Math.max(padL, Math.min(startSvgX, curX));
          const maxX = Math.min(W - padR, Math.max(startSvgX, curX));
          const selW = Math.max(0, maxX - minX);

          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(2, selW));
          selRect.style.display = "block";

          let previewPts = [];
          if (selW <= 14 && pts.length > 0) {
            let closest = pts[0];
            let minDist = Math.abs(pts[0].x - minX);
            for (const p of pts) {
              const d = Math.abs(p.x - minX);
              if (d < minDist) {
                minDist = d;
                closest = p;
              }
            }
            previewPts = [closest];
          } else {
            previewPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
          }

          svg.querySelectorAll(".interr-history-point").forEach((dot) => {
            const sid = dot.getAttribute("data-sid");
            if (previewPts.some((p) => p.session.sessionId === sid)) {
              dot.setAttribute("fill", "#f59e0b");
              dot.setAttribute("r", "6");
            } else {
              dot.setAttribute("fill", "#3b82f6");
              dot.setAttribute("r", "4");
            }
          });
        }
      });

      svg.addEventListener("mouseleave", () => {
        crossH.style.display = "none";
        crossY.style.display = "none";
        if (this._historySelectionState === 0) vLine.style.display = "none";
        if (scrubberLabel) scrubberLabel.textContent = "Sposta il mouse sul grafico";
        svg.querySelectorAll(".interr-history-point.inspected").forEach((el) => el.classList.remove("inspected"));
        if (detailBox && this._historySelectedIds.size !== 1) {
          detailBox.textContent = "Passa con il mouse sui campioni per le coordinate e i dettagli, oppure clicca per selezionare.";
        }
      });

      svg.addEventListener("click", (e) => {
        if (e.button !== 0) return;
        const svgPt = getSvgCoords(e);
        const curX = Math.max(padL, Math.min(W - padR, svgPt.x));

        if (this._historySelectionState === 0) {
          this._historySelectionState = 1;
          startSvgX = curX;
          vLine.style.display = "none";
          selRect.setAttribute("x", startSvgX);
          selRect.setAttribute("width", 2);
          selRect.style.display = "block";
          const summaryEl = document.getElementById("lblInterrHistSummary");
          if (summaryEl) {
            const hint = createEl("span", "stats-hint-blue", "Seleziona il secondo punto...");
            summaryEl.replaceChildren(hint);
          }
        } else if (this._historySelectionState === 1) {
          this._historySelectionState = 2;
          const endSvgX = curX;
          const minX = Math.max(padL, Math.min(startSvgX, endSvgX));
          const maxX = Math.min(W - padR, Math.max(startSvgX, endSvgX));
          const selW = Math.max(0, maxX - minX);

          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(4, selW));
          selRect.style.display = "block";

          let selPts = [];
          if (selW <= 14 && pts.length > 0) {
            let closest = pts[0];
            let minDist = Math.abs(pts[0].x - minX);
            for (const p of pts) {
              const d = Math.abs(p.x - minX);
              if (d < minDist) {
                minDist = d;
                closest = p;
              }
            }
            selPts = [closest];
            selRect.setAttribute("x", closest.x - 8);
            selRect.setAttribute("width", 16);
          } else {
            selPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
          }
          applySelection(selPts);
        } else if (this._historySelectionState === 2) {
          this._clearHistorySelection();
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      });

      host.appendChild(svg);
      this._updateHistorySelectionUI(samples);
    }

    async _deleteHistorySamples(mode) {
      const profileId = this.getProfileId();
      const filtered = this._historyFilteredSessions || [];
      const selectedIds = this._historySelectedIds || new Set();
      let idsToDelete = [];
      let confirmMsg = "";
      let confirmTitle = "";

      if (mode === "selected") {
        idsToDelete = filtered
          .filter((s) => selectedIds.has(s.sessionId))
          .map((s) => s.sessionId);
        if (idsToDelete.length === 0) return;
        confirmTitle = "🗑 Elimina Selezionati";
        confirmMsg = `Sei sicuro di voler eliminare definitivamente i ${idsToDelete.length} campioni selezionati dallo storico interrogazioni?\n\nQuesta operazione non può essere annullata.`;
      } else if (mode === "notSelected") {
        if (selectedIds.size === 0) return;
        idsToDelete = filtered
          .filter((s) => !selectedIds.has(s.sessionId))
          .map((s) => s.sessionId);
        if (idsToDelete.length === 0) return;
        confirmTitle = "✂ Elimina Non Selezionati";
        confirmMsg = `ATTENZIONE: Stai per eliminare i ${idsToDelete.length} campioni non selezionati attualmente visibili nel grafico.\n\nVerranno conservati i ${selectedIds.size} campioni selezionati e gli altri campioni esclusi dai filtri attivi.\n\nProcedere?`;
      }

      if (idsToDelete.length === 0) return;

      this.showConfirm(confirmMsg, confirmTitle, async () => {
        await this.sessionMgr.repository.deleteSessions(profileId, idsToDelete);
        this._clearHistorySelection();
        await this._loadHistorySessions();
        this._renderHistoryChart();
        this.showAlert(`Eliminati con successo ${idsToDelete.length} campioni dallo storico.`, "📈 Storico Interrogazioni");
      });
    }

    async _clearAllHistory() {
      const profileId = this.getProfileId();
      this.showConfirm(
        "Eliminare definitivamente TUTTO l'archivio storico delle interrogazioni completate per il profilo attivo?\n\nQuesta operazione non può essere annullata.",
        "🗑 Elimina Archivio Storico",
        async () => {
          await this.sessionMgr.repository.deleteAllCompletedSessions(profileId);
          this._clearHistorySelection();
          await this._loadHistorySessions();
          this._renderHistoryChart();
          this.showAlert("Archivio storico interrogazioni eliminato definitivamente.", "📈 Storico Interrogazioni");
        },
      );
    }

    _openRepeatPanel() {
      const panel = document.getElementById("interrHistoryRepeatPanel");
      const infoEl = document.getElementById("interrHistRepeatSampleInfo");
      const fb = document.getElementById("interrHistRepeatFeedback");
      if (!panel) return;
      if (this._historySelectedIds.size !== 1) return;

      const sid = Array.from(this._historySelectedIds)[0];
      const session = (this._historyAllSessions || []).find((s) => s.sessionId === sid);
      if (!session) return;

      if (infoEl) {
        const fmt = this._formatDateTimeIT(session.completedAt || session.createdAt);
        infoEl.textContent = `${fmt.full} — Corrette: ${session.correctCount || 0}, Errate: ${session.incorrectCount || 0}, Consultate: ${session.consultedCount || 0}, Ignorate: ${session.ignoredCount || 0}`;
      }
      if (fb) {
        fb.textContent = "";
        fb.className = "interrogation-feedback";
      }
      panel.classList.remove("is-hidden");
    }

    _closeRepeatPanel() {
      const panel = document.getElementById("interrHistoryRepeatPanel");
      if (panel) panel.classList.add("is-hidden");
    }

    async _startRepeatSession(useAll) {
      if (this._historySelectedIds.size !== 1) return;
      const sid = Array.from(this._historySelectedIds)[0];
      const profileId = this.getProfileId();
      const fb = document.getElementById("interrHistRepeatFeedback");

      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (suspended) {
        const msg = "Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova.";
        if (fb) {
          fb.textContent = msg;
          fb.className = "interrogation-feedback is-error";
        }
        this.showToast(msg, "⚠");
        return;
      }

      let filters = ["all"];
      if (!useAll) {
        filters = [];
        document.querySelectorAll(".interr-repeat-outcome-chk:checked").forEach((chk) => {
          filters.push(chk.value);
        });
        if (filters.length === 0) {
          if (fb) {
            fb.textContent = "Seleziona almeno una tipologia di esito (Corrette, Errate, Consultate, Ignorate) oppure clicca 'Tutti i quesiti'.";
            fb.className = "interrogation-feedback is-error";
          }
          return;
        }
      }

      const items = await this.sessionMgr.getSessionItemsForRepeat(profileId, sid, filters);
      if (!items || items.length === 0) {
        if (fb) {
          fb.textContent = "Nessun quesito trovato con i filtri di esito selezionati.";
          fb.className = "interrogation-feedback is-error";
        }
        return;
      }

      const candidateIds = items.map((it) => it.candidateId).filter(Boolean);
      const qTypes = Array.from(new Set(items.map((it) => it.questionType).filter(Boolean)));

      this._closeRepeatPanel();
      const created = await this.sessionMgr.createSession({
        profileId,
        mode: "manual",
        questionTypes: qTypes.length > 0 ? qTypes : ["CARATTERE", "TASTO", "DITO", "HOME_ROW"],
        requestedCount: candidateIds.length,
        manualCandidateIds: candidateIds,
        allowDuplicates: true,
      });

      this.activeSession = created.session;
      this.activeItems = created.items;
      this.currentItemIdx = 0;
      this._setFeedback("", "");
      this._renderRunView();
    }

    _updateHistoryTabButtons(activeSectionNum) {
      const btnChrono = document.getElementById("btnInterrHistNavChrono");
      const btnUrgency = document.getElementById("btnInterrHistNavUrgency");
      if (!btnChrono || !btnUrgency) return;
      if (activeSectionNum === 1) {
        btnChrono.classList.add("active");
        btnUrgency.classList.remove("active");
      } else {
        btnUrgency.classList.add("active");
        btnChrono.classList.remove("active");
      }
    }

    _scrollToHistorySection(sectionNum) {
      this._updateHistoryTabButtons(sectionNum);
      const histView = document.getElementById("interrogationView_history");
      const sec1 = document.getElementById("interrHistorySection1");
      const sec2 = document.getElementById("interrHistorySection2");
      if (sectionNum === 1) {
        if (sec1 && typeof sec1.scrollIntoView === "function") {
          sec1.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (histView) {
          histView.scrollTo({ top: 0, behavior: "smooth" });
        }
        this._renderHistoryChart();
      } else {
        if (sec2 && typeof sec2.scrollIntoView === "function") {
          sec2.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (histView) {
          histView.scrollTo({ top: histView.clientHeight, behavior: "smooth" });
        }
        this._renderUrgencyChart();
      }
    }

    async _loadUrgencyData() {
      const profileId = this.getProfileId();
      const repo = this.sessionMgr && this.sessionMgr.repository;
      if (!repo) {
        this._urgencyEvents = [];
        this._urgencyCorrections = [];
        return;
      }
      const [events, corrections] = await Promise.all([
        typeof repo.getExposureEvents === "function" ? repo.getExposureEvents(profileId) : [],
        typeof repo.getEventCorrections === "function" ? repo.getEventCorrections(profileId) : [],
      ]);
      this._urgencyEvents = Array.isArray(events) ? events : [];
      this._urgencyCorrections = Array.isArray(corrections) ? corrections : [];
    }

    _renderUrgencyChart() {
      const host = document.getElementById("interrUrgencyChartHost");
      const detailBox = document.getElementById("interrUrgencyDetailBox");
      if (!host) return;
      host.innerHTML = "";

      const Knowledge = global.InterrogationKnowledge;
      if (!Knowledge || typeof Knowledge.computeUrgencyRanking !== "function" || !this.catalog) {
        host.appendChild(createEl("div", "interr-history-empty", "Motore classifica urgenza non disponibile."));
        return;
      }

      const { lessonScope, maxLessonIndex } = this._getActiveSetupScope();
      const candidates = this.catalog.getCandidates(
        lessonScope === "curriculum" && maxLessonIndex !== null ? { maxLessonIndex } : {},
      );
      const ranking = Knowledge.computeUrgencyRanking({
        candidates,
        events: this._urgencyEvents,
        corrections: this._urgencyCorrections,
        catalog: this.catalog,
        activeReasons: this.urgencyReasons,
        entityFilter: this.urgencyEntityFilter,
      });

      const items = ranking.items || [];
      this._urgencyRankingItems = items;

      if (items.length === 0) {
        host.appendChild(createEl("div", "interr-history-empty", "Nessun elemento disponibile per il filtro selezionato."));
        return;
      }

      const hostWidth = Math.max(host.clientWidth - 16, 480);
      const hostHeight = Math.max(host.clientHeight - 16, 230);
      const padL = 44;
      const padR = 16;
      const padT = 18;
      const padB = 56;
      const barStep = 30;
      const barW = 20;
      const minPlotW = Math.max(hostWidth - padL - padR, items.length * barStep);
      const svgW = padL + minPlotW + padR;
      const svgH = hostHeight;
      const plotH = Math.max(90, svgH - padT - padB);
      const baselineY = padT + plotH;

      const maxScore = Math.max(
        10,
        items.reduce((acc, it) => Math.max(acc, Number(it.totalScore || 0)), 0),
      );
      const niceMax = Math.ceil(maxScore / 25) * 25;

      const svg = createSvgEl("svg", {
        width: String(svgW),
        height: String(svgH),
        viewBox: `0 0 ${svgW} ${svgH}`,
      });

      // Griglia Y (0..niceMax)
      const ticks = 5;
      for (let i = 0; i <= ticks; i++) {
        const val = (niceMax / ticks) * i;
        const y = baselineY - (val / niceMax) * plotH;
        svg.appendChild(
          createSvgEl("line", {
            x1: String(padL),
            y1: y.toFixed(1),
            x2: String(svgW - padR),
            y2: y.toFixed(1),
            stroke: i === 0 ? "#475569" : "#1e293b",
            "stroke-width": i === 0 ? "1.5" : "1",
          }),
        );
        const lbl = createSvgEl("text", {
          x: String(padL - 6),
          y: (y + 4).toFixed(1),
          "text-anchor": "end",
          fill: "#94a3b8",
          "font-size": "11",
        });
        lbl.textContent = String(Math.round(val));
        svg.appendChild(lbl);
      }

      const segmentDefs = [
        { key: "error", label: "Errori", color: "#ef4444" },
        { key: "consultation", label: "Consultazioni", color: "#f59e0b" },
        { key: "delay", label: "Ritardo Ripasso", color: "#8b5cf6" },
        { key: "consolidation", label: "Non Consolidato", color: "#06b6d4" },
        { key: "underinvestigated", label: "Scarsa Indagine", color: "#64748b" },
      ];

      items.forEach((item, idx) => {
        const cx = padL + idx * barStep + barStep / 2;
        const bx = cx - barW / 2;
        const group = createSvgEl("g", {
          class: "interr-urgency-bar-group",
          "data-entity-id": item.entityId,
        });

        // Sfondo cliccabile/hover sull'intera colonna
        group.appendChild(
          createSvgEl("rect", {
            class: "interr-urgency-bar-bg",
            x: (cx - barStep / 2).toFixed(1),
            y: String(padT),
            width: String(barStep),
            height: String(plotH),
            fill: "transparent",
          }),
        );

        let curY = baselineY;
        segmentDefs.forEach((seg) => {
          const val = Number((item.contributions && item.contributions[seg.key]) || 0);
          if (val <= 0) return;
          const segH = Math.max(1.5, (val / niceMax) * plotH);
          const nextY = curY - segH;
          group.appendChild(
            createSvgEl("rect", {
              x: bx.toFixed(1),
              y: nextY.toFixed(1),
              width: String(barW),
              height: segH.toFixed(1),
              fill: seg.color,
              rx: "1",
            }),
          );
          curY = nextY;
        });

        // Etichetta X (Dita evidenziate in ambra, Tasti in grigio chiaro)
        const shortLbl = item.label.length > 5 ? item.label.slice(0, 5) : item.label;
        const xText = createSvgEl("text", {
          class: "interr-urgency-xlabel",
          x: cx.toFixed(1),
          y: (baselineY + 14).toFixed(1),
          "text-anchor": "end",
          transform: `rotate(-38 ${cx.toFixed(1)} ${(baselineY + 14).toFixed(1)})`,
          fill: item.entityType === "finger" ? "#fbbf24" : "#cbd5e1",
          "font-size": "11",
          "font-weight": item.entityType === "finger" ? "700" : "500",
        });
        xText.textContent = shortLbl;
        group.appendChild(xText);

        group.addEventListener("mouseenter", () => {
          if (!detailBox) return;
          const c = item.contributions || {};
          const typeTag = item.entityType === "finger" ? "DITO" : "TASTO";
          detailBox.textContent =
            `[${typeTag}] ${item.fullLabel} — Urgenza: ${item.totalScore.toFixed(1)} pt ` +
            `(Errori: ${c.error.toFixed(1)}, Consult.: ${c.consultation.toFixed(1)}, ` +
            `Ritardo: ${c.delay.toFixed(1)}, Consolid.: ${c.consolidation.toFixed(1)}, ` +
            `Scarsa ind.: ${c.underinvestigated.toFixed(1)}) | ` +
            `Verifiche: ${item.effectiveExposureCount} | Quesiti: ${item.questionCount} — Clicca per interrogare`;
        });

        group.addEventListener("click", () => {
          this._promptStartUrgencySession(item);
        });

        svg.appendChild(group);
      });

      host.appendChild(svg);
    }

    async _promptStartUrgencySession(item) {
      if (!item || !Array.isArray(item.candidateIds) || item.candidateIds.length === 0) return;
      const profileId = this.getProfileId();
      const suspended = await this.sessionMgr.repository.getSuspendedSession(profileId);
      if (suspended) {
        const msg = "Esiste una sessione sospesa: riprendila o abbandonala prima di avviare un'interrogazione mirata.";
        this.showAlert(msg, "📊 Classifica Urgenza");
        return;
      }

      const kindLabel = item.entityType === "finger" ? "il dito" : "il tasto";
      const confirmMsg =
        `Vuoi avviare subito un'interrogazione mirata per ${kindLabel} "${item.fullLabel}"?\n\n` +
        `Verranno inclusi ${item.candidateIds.length} quesiti associati (punteggio urgenza attuale: ${item.totalScore.toFixed(1)} pt).`;

      this.showConfirm(confirmMsg, "📊 Interrogazione Mirata", async () => {
        const created = await this.sessionMgr.createSession({
          profileId,
          mode: "manual",
          questionTypes:
            Array.isArray(item.questionTypes) && item.questionTypes.length > 0
              ? item.questionTypes
              : ["CARATTERE", "TASTO", "DITO", "HOME_ROW"],
          requestedCount: item.candidateIds.length,
          manualCandidateIds: item.candidateIds.slice(),
        });
        this.activeSession = created.session;
        this.activeItems = created.items;
        this.currentItemIdx = 0;
        this._setFeedback("", "");
        this._renderRunView();
      });
    }
  }

  global.InterrogationUI = InterrogationUI;
})(typeof window !== "undefined" ? window : globalThis);
