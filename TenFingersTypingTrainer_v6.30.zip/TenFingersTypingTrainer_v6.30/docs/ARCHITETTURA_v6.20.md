# Architettura — TenFingersTypingTrainer v6.20

## Obiettivo

La release v6.20 risolve in modo definitivo l'anomalia di troncamento anticipato della dettatura vocale su vocaboli complessi, frasi con punteggiatura estesa e numeri a più cifre (es. *"SPAZIO farfalle PUNTO INTERROGATIVO"* o *"SPAZIO TUTTO MAIUSCOLO figlia PUNTO INTERROGATIVO"*), superando il vecchio limite fisso a 2,2 secondi che scambiava la normale riproduzione per un freeze hardware del browser ("Ghost-Lock").
La release introduce inoltre la configurabilità completa dei tempi di inattività e di Auto-Replay (1,5 secondi base predefiniti, 3,5 secondi estesi dopo 3 ripetizioni consecutive), una formula di modulazione inversamente proporzionale alla velocità vocale, la persistenza dei nuovi parametri nel profilo utente e la piena esposizione delle formule didattiche in notazione naturale nella finestra modale di configurazione.

---

## Analisi Architetturale del Problema

### 1. Il Limite Rigido Anti-Ghost-Lock a 2200 ms
Nelle release v6.16 e v6.17 era stato introdotto un meccanismo di protezione per sbloccare l'audio in caso di freeze del motore vocale del browser (Chromium/WebKit Web Speech API bug). Tale controllo conteneva un tetto rigido codificato come:
`if (speechDuration > 2200) { this.stopAudioOnly(); }`

Nelle frasi composte, nelle modalità con annuncio esplicito di Spazio/Maiuscole e nei numeri estesi pronunciati per intero, l'enunciato fonetico richiede frequentemente tra 2,3 e 3,5 secondi per essere scandito completamente (specialmente quando l'allievo imposta una velocità della voce ridotta, ad esempio 0,7x o 0,8x). Raggiunti i 2200 ms di riproduzione legittima, l'applicazione scambiava la pronuncia per un blocco del sintetizzatore, invocava `stopAudioOnly()` (stroncando la parola sulle ultime sillabe) e faceva scattare a catena l'Auto-Replay di inattività.

### 2. Mancata Relazione tra Watchdog e Velocità della Voce
Il calcolo della durata stimata dell'enunciato (`expectedDurationMs = Math.max(1500, phoneticPayload.length * 90 + 600)`) non teneva conto del parametro `this.speed`. Abbassando la velocità della voce dal 100% al 60%, la durata effettiva della pronuncia quasi raddoppiava, ma la stima e il ceiling rimanevano ancorati a tempi inadeguati.

### 3. Rigidità del Timer di Stallo a 1,0 Secondo
Il ritardo base di inattività di 1,0 secondo (1000 ms), introdotto nella v6.15, risultava eccessivamente pressante per l'ascolto di parole lunghe, lasciando all'allievo troppo poco tempo per metabolizzare la pronuncia prima che scattasse un nuovo sollecito.

---

## Soluzione Architetturale Implementata nella Release v6.20

### 1. Ceiling Dinamico Anti-Ghost-Lock
Eliminazione del valore fisso a 2200 ms in `resetStallTimer()` e in `_handleStallTimeout()`. Il nuovo tetto di sicurezza viene calcolato dinamicamente a partire dalla durata stimata del token attivo e dalla velocità della voce:
`activeCeiling = Massimo tra 3500 ms e 1,5 * DurataStimata`
dove la durata stimata tiene conto della velocità:
`DurataStimata = (LunghezzaFonetica * 110 + 800) / VelocitàVoce`
In questo modo, nessun enunciato legittimo può più essere interrotto anticipatamente, pur mantenendo la protezione automatica qualora il browser dovesse realmente bloccarsi.

### 2. Tempi di Inattività Configurabili
Il motore `DictationEngine` gestisce ora tre parametri configurabili:
* `stallBaseDelay`: ritardo prima del primo Replay automatico (intervallo 1,0 s - 3,0 s, default **1,5 secondi**);
* `stallLongDelay`: ritardo esteso dopo 3 ripetizioni consecutive senza digitazione (intervallo 2,0 s - 6,0 s, default **3,5 secondi**);
* `stallSpeedFactor`: coefficiente di modulazione proporzionale alla lentezza della voce (intervallo 0,0 - 1,5, default **1,0**).

### 3. Modulazione Inversamente Proporzionale alla Velocità Vocale
Nelle modalità lessicali e fonemiche (con esclusione dello Spelling rapido), il tempo effettivo di attesa viene modulato secondo la formula didattica in chiaro:
`TempoEffettivo = TempoBase * (1 + CoefficienteModulazione * ((1 / VelocitàVoce) - 1))`
* Se la velocità vocale è 1,0x (100%), il fattore moltiplicativo è pari a 1,0 e il tempo corrisponde esattamente al Tempo Base (1,5 secondi).
* Se la velocità vocale è lenta (es. 0,6x) e il coefficiente è 1,0, il tempo si dilata a 2,5 secondi, concedendo il tempo necessario per percepire la voce prima del promemoria.
* Se il coefficiente è 0,0, i tempi rimangono fissi indipendentemente dalla velocità vocale.

### 4. Preservazione Assoluta della Modalità Spelling
Quando è attiva la modalità *Spelling* (o nelle modalità didattiche a singoli caratteri), i tempi di stallo rimangono rigorosamente fissi ai valori rapidi standard (1,0 secondo base / 3,0 secondi dopo 3 ripetizioni), garantendo la massima fluidità nella compitazione lettera per lettera senza rallentamenti artificiali.

### 5. Estensione Interfaccia Utente e Documentazione Didattica
Nella finestra modale `⚙ Configurazione Dettatura` (`#dictationConfigModal`):
* È stata inserita la Sezione 3 con slider e campi numerici a sincronizzazione bidirezionale per i tre nuovi parametri;
* È presente un box informativo didattico che espone le formule operative in notazione naturale chiara (senza formule o delimitatori LaTeX);
* Il pulsante di ripristino predefiniti aggiorna simultaneamente le soglie CPM e i tempi di inattività ai valori nominali consigliati (100 CPM, 200 CPM, 1,5s base, 3,5s esteso, Coeff. 1,0).

---

## Mappa dei Componenti Modificati (Release v6.20)

| Componente | Responsabilità v6.20 |
|---|---|
| `engines/dictation-engine.js` | Implementazione del ceiling dinamico anti-troncamento, calcolo durata utterance con velocità vocale, gestione ritardi di stallo configurabili e modulazione velocità |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.20 (`window.APP_VERSION = "6.20"`) |
| `app/controller/metodi-dettatura.js` | Gestione eventi modale per i tempi di inattività, sincronizzazione bidirezionale slider/input, applicazione immediata all'engine e persistenza nel profilo |
| `profiles/profile-manager.js` | Profilo utente e persistenza aggiornati ad `AppVersion = "6.20"` con inizializzazione difensiva dei tre nuovi parametri |
| `data/demo-profile.js` | Profilo demo aggiornato con i valori di default di stallo e modulazione |
| `index.html` | Sezione 3 modale con controlli interattivi, box informativo formule didattiche in notazione naturale e allineamento titoli/badge v6.20 |
| `help.html` | Note di rilascio v6.20, aggiornamento descrizioni didattiche sulla dettatura e allineamento tag di versione |
| `docs/MANUALE_UTENTE_v6.20.md` | Manuale utente aggiornato con le istruzioni didattiche sui tempi di inattività e anti-troncamento (notazione naturale) |
| `docs/ARCHITETTURA_v6.20.md` | Documento architetturale della release v6.20 |
| `CHANGELOG.md` | Registro dettagliato delle modifiche introdotte nella release v6.20 |
| `tests/test-dictation-adaptive.js` | Suite di collaudo estesa con TEST 14 per la verifica dei tempi configurabili, ceiling dinamico e modulazione vocale |
| `tests/static-check.js` | Verifica statica aggiornata al marker v6.20 |
| `tests/runtime-smoke.js` | Smoke test a runtime aggiornato alla versione 6.20 |
| `tests/REGRESSION_CHECKLIST.md` | Checklist di collaudo manuale aggiornata alla release v6.20 |
| `BUILD_MANIFEST.json` | Manifest di integrità aggiornato alla release v6.20 |
