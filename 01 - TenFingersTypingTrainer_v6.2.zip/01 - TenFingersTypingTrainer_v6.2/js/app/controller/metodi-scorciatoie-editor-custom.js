/* TenFingersTypingTrainer v6.0 — AppController: shortcuts. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
setupShortcuts() {
    window.addEventListener("keydown", (e) => {
      if (e.repeat) return;
      if (document.querySelector(".modal-overlay.active")) return;

      if (e.key === "F1") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) helpBtn.click();
        return;
      }

      // Se non ci sono CTRL e SHIFT premuti contemporaneamente, ignora
      if (!e.ctrlKey || !e.shiftKey) return;

      // CRUCIALE: se il tasto premuto è solo un modificatore puro (Control o Shift),
      // NON considerarlo una shortcut completata e lascia lavorare la macchina a stati!
      if (
        e.key === "Control" ||
        e.key === "Shift" ||
        e.key === "Alt" ||
        e.key === "AltGraph"
      ) {
        return;
      }

      // Qui viene premuto un vero tasto di azione (terzo tasto): convalida la shortcut!
      this.modifierSession.shortcutExecuted = true;
      this.modifierSession.activeModifiers.clear();

      const k = e.key.toUpperCase();

      // SCORCIATOIA REPLAY DETTATURA VOCALE (CTRL+SHIFT+SPAZIO - v.3.8)
      if (e.code === "Space" || e.key === " ") {
        e.preventDefault();
        this.replayDictation();
        this.returnFocusToTyping();
        return;
      }

      if (e.key === "ArrowLeft") {
        e.preventDefault();
        this.navPhrase(-1);
        this.returnFocusToTyping();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        this.navPhrase(1);
        this.returnFocusToTyping();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        this.confirmNavLesson(-1);
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        this.confirmNavLesson(1);
      } else if (
        e.code === "Digit1" ||
        e.code === "Numpad1" ||
        e.key === "1" ||
        e.key === "!"
      ) {
        e.preventDefault();
        this.typingEng.mode = 0;
        document.getElementById("cboMode").value = "0";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit2" ||
        e.code === "Numpad2" ||
        e.key === "2" ||
        e.key === '"' ||
        e.key === "@"
      ) {
        e.preventDefault();
        this.typingEng.mode = 1;
        document.getElementById("cboMode").value = "1";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit3" ||
        e.code === "Numpad3" ||
        e.key === "3" ||
        e.key === "£" ||
        e.key === "#"
      ) {
        e.preventDefault();
        this.typingEng.mode = 2;
        document.getElementById("cboMode").value = "2";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit4" ||
        e.code === "Numpad4" ||
        e.key === "4" ||
        e.key === "$"
      ) {
        e.preventDefault();
        this.typingEng.mode = 3;
        document.getElementById("cboMode").value = "3";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit5" ||
        e.code === "Numpad5" ||
        e.key === "5" ||
        e.key === "%"
      ) {
        e.preventDefault();
        this.typingEng.mode = 4;
        document.getElementById("cboMode").value = "4";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit6" ||
        e.code === "Numpad6" ||
        e.key === "6" ||
        e.key === "&"
      ) {
        e.preventDefault();
        this.typingEng.mode = 6;
        document.getElementById("cboMode").value = "6";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit8" ||
        e.code === "Numpad8" ||
        k === "P" ||
        e.code === "KeyP"
      ) {
        e.preventDefault();
        const chkSpelling = document.getElementById("chkDictationSpelling");
        if (chkSpelling) {
          chkSpelling.checked = !chkSpelling.checked;
          chkSpelling.dispatchEvent(new Event("change"));
        }
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit9" ||
        e.code === "Numpad9" ||
        k === "V" ||
        e.code === "KeyV"
      ) {
        e.preventDefault();
        const chkDict = document.getElementById("chkDictation");
        if (chkDict) {
          chkDict.checked = !chkDict.checked;
          chkDict.dispatchEvent(new Event("change"));
        }
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit0" ||
        e.code === "Numpad0" ||
        e.key === "0" ||
        e.code === "Enter" ||
        e.code === "NumpadEnter" ||
        e.key === "Enter"
      ) {
        e.preventDefault();
        if (this.typingEng.mode === 4) {
          const btnAdd = document.getElementById("btnAddStatistic");
          if (btnAdd) {
            btnAdd.click();
          }
        } else {
          this.notifyShortcutDisabled(
            "Aggiungi alle Statistiche disponibile solo in Digitazione Libera",
          );
        }
        this.returnFocusToTyping();
      } else if (k === "X") {
        e.preventDefault();
        this.startExercise(true);
        this.returnFocusToTyping();
      } else if (k === "A") {
        e.preventDefault();
        this.randomPhrase();
        this.returnFocusToTyping();
      } else if (k === "E") {
        e.preventDefault();
        this.showSelectPhraseModal();
      } else if (k === "Z") {
        e.preventDefault();
        if (this.typingEng.mode === 4) {
          this.notifyShortcutDisabled(
            "Rimescola frase non disponibile in Digitazione Libera",
          );
        } else {
          this.typingEng.mode = 5;
          document.getElementById("cboMode").value = "5";
          this.updateModeUI();
          this.startExercise();
        }
        this.returnFocusToTyping();
      } else if (k === "G") {
        e.preventDefault();
        this.typingEng.mode = 3;
        document.getElementById("cboMode").value = "3";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (k === "M") {
        e.preventDefault();
        this.toggleHandsVis(
          !document
            .getElementById("handsFloatingWindow")
            ?.classList.contains("window-visible"),
        );
        this.returnFocusToTyping();
      } else if (k === "S") {
        e.preventDefault();
        this.toggleStatsWindow();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit7" ||
        e.code === "Numpad7" ||
        e.key === "7" ||
        e.key === "/"
      ) {
        e.preventDefault();
        this.switchStatsView();
        this.returnFocusToTyping();
      } else if (k === "U") {
        e.preventDefault();
        this.showLoginModal();
      } else if (k === "K") {
        e.preventDefault();
        const chk = document.getElementById("chkShowKeyBoard");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleKeyboardVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "O") {
        e.preventDefault();
        const chk = document.getElementById("chkShowOrigin");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleOriginVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "Y") {
        e.preventDefault();
        const chk = document.getElementById("chkShowTyped");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleTypedVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "B") {
        e.preventDefault();
        const chk = document.getElementById("chkAutomaticCorrection");
        if (chk) {
          chk.checked = !chk.checked;
          if (this.profileMgr.profile) {
            this.profileMgr.profile.AutomaticCorrection = chk.checked;
            this.profileMgr.saveProfile();
          }
          if (chk.checked) {
            this.purgePreExistingErrors();
          }
        }
        this.returnFocusToTyping();
      } else if (k === "H" || e.code === "KeyH") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) {
          helpBtn.click();
        } else {
          window.open("help_(v.4.9).html", "_blank");
        }
      } else if (k === "F" || k === "L") {
        e.preventDefault();
        const chk = document.getElementById("chkShowErrors");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleErrorsVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "D") {
        e.preventDefault();
        if ([1, 2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
          this.notifyShortcutDisabled(
            "Commutazione sorgente non disponibile nella modalità attiva",
          );
        } else {
          const btnToggleSource = document.getElementById(
            "btnToggleLessonSource",
          );
          if (btnToggleSource) {
            btnToggleSource.click();
          }
        }
        this.returnFocusToTyping();
      }
    });
  },

openCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    if (!win || !textarea) return;
    textarea.value =
      this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    win.classList.add("window-visible");
    win.style.display = "flex";
    this.windowMgr.clampWindowToViewport(win, false);
  },

setupCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    const btnSave = document.getElementById("btnCustomSave");
    const btnUpload = document.getElementById("btnCustomUpload");
    const btnDownload = document.getElementById("btnCustomDownload");
    const fileInput = document.getElementById("customFileInput");

    // Pulsanti toolbar rapida
    const btnInsertTitle = document.getElementById("btnCustomInsertTitle");
    const btnInsertSeparator = document.getElementById(
      "btnCustomInsertSeparator",
    );
    const btnInsertEnter = document.getElementById("btnCustomInsertEnter");
    const btnInsertTab = document.getElementById("btnCustomInsertTab");

    // Modale Inserisci Titolo Nuova Tipologia Esercizi
    const titleModal = document.getElementById("customTitleModal");
    const titleInput = document.getElementById("txtCustomExerciseTitle");
    const btnConfirmTitle = document.getElementById("btnConfirmCustomTitle");
    const btnCancelTitle = document.getElementById("btnCancelCustomTitle");
    const btnCloseTitleModal = document.getElementById(
      "btnCloseCustomTitleModal",
    );

    // Inserimento alla posizione corrente del cursore nella textarea con supporto Undo
    const insertAtCursor = (charToInsert) => {
      if (!textarea) return;
      textarea.focus();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      if (typeof textarea.setRangeText === "function") {
        textarea.setRangeText(charToInsert, start, end, "end");
      } else {
        const val = textarea.value;
        textarea.value =
          val.substring(0, start) + charToInsert + val.substring(end);
        textarea.selectionStart = textarea.selectionEnd =
          start + charToInsert.length;
      }
    };

    btnInsertEnter?.addEventListener("click", () => {
      insertAtCursor("®");
    });

    btnInsertTab?.addEventListener("click", () => {
      insertAtCursor("→");
    });

    btnInsertSeparator?.addEventListener("click", () => {
      if (!textarea) return;
      const start = textarea.selectionStart;
      const val = textarea.value;
      let toInsert = "=====\n";
      if (start > 0 && val[start - 1] !== "\n") {
        toInsert = "\n" + toInsert;
      }
      insertAtCursor(toInsert);
    });

    const openTitleModal = () => {
      if (!titleModal || !titleInput) return;
      titleInput.value = "";
      titleModal.classList.add("active");
      setTimeout(() => {
        titleInput.focus();
      }, 60);
    };

    const closeTitleModal = () => {
      if (titleModal) titleModal.classList.remove("active");
      if (textarea) textarea.focus();
    };

    const confirmInsertTitle = () => {
      if (!textarea || !titleInput) return;
      const rawTitle = titleInput.value.trim();
      const title = rawTitle || "Nuova Tipologia Esercizio";
      const formatted = `=====${title}=====\n`;

      const currentVal = textarea.value;
      let newVal = currentVal;
      if (newVal.length > 0 && !newVal.endsWith("\n")) {
        newVal += "\n";
      }
      newVal += formatted;
      textarea.value = newVal;

      textarea.selectionStart = textarea.selectionEnd = textarea.value.length;
      textarea.scrollTop = textarea.scrollHeight;

      closeTitleModal();
    };

    btnInsertTitle?.addEventListener("click", openTitleModal);
    btnConfirmTitle?.addEventListener("click", confirmInsertTitle);
    btnCancelTitle?.addEventListener("click", closeTitleModal);
    btnCloseTitleModal?.addEventListener("click", closeTitleModal);

    titleInput?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        confirmInsertTitle();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeTitleModal();
      }
    });

    // Chiusura da tastiera con tasto Escape per il modale del titolo
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && titleModal?.classList.contains("active")) {
        closeTitleModal();
      }
    });

    titleModal?.addEventListener("click", (e) => {
      if (e.target === titleModal) closeTitleModal();
    });

    // Chiusura della finestra Editor Custom con il tasto ESCAPE (Release v.4.6)
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        // Se il modale del titolo è aperto in primo piano, la priorità di chiusura spetta ad esso
        if (titleModal && titleModal.classList.contains("active")) return;
        if (
          win &&
          (win.classList.contains("window-visible") ||
            win.style.display === "flex")
        ) {
          e.preventDefault();
          win.classList.remove("window-visible");
          win.style.display = "none";
          this.returnFocusToTyping();
        }
      }
    });

    btnSave?.addEventListener("click", () => {
      if (this.profileMgr?.profile && textarea) {
        const textVal = textarea.value;
        const prevCustomText = this.profileMgr.profile.CustomText || "";

        // Assegnazione temporanea per il tentativo di salvataggio
        this.profileMgr.profile.CustomText = textVal;
        const saved = this.profileMgr.saveProfile();

        if (saved) {
          const parsed = parseCustomExercises(textVal);
          if (parsed.length > 0) {
            this.customLessons = parsed;
            this.setLessonsSource("custom");
            this.showAppAlert(
              `Esercizi personalizzati salvati! Caricate ${parsed.length} lezioni custom nel menu.`,
              "📝 Editor Custom",
            );
          } else {
            this.showAppAlert(
              "Esercizi salvati nel profilo.",
              "📝 Editor Custom",
            );
          }
          win?.classList.remove("window-visible");
          if (win) win.style.display = "none";
        } else {
          // Rollback: ripristina il testo precedente in memoria
          this.profileMgr.profile.CustomText = prevCustomText;
          this.showAppAlert(
            "Impossibile salvare le frasi personalizzate: spazio di memoria del browser esaurito (Local Storage).\n\nLe modifiche sono state annullate (rollback). Libera memoria eliminando profili o campioni prima di salvare.",
            "⚠ Salvataggio Fallito (Memoria Esaurita)",
          );
        }
      }
      this.returnFocusToTyping();
    });

    btnDownload?.addEventListener("click", () => {
      if (!textarea) return;
      const blob = new Blob([textarea.value], {
        type: "text/plain;charset=utf-8",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "TypingTrainerCustom.txt";
      a.click();
      URL.revokeObjectURL(url);
      this.returnFocusToTyping();
    });

    btnUpload?.addEventListener("click", () => {
      fileInput?.click();
    });

    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const textVal = ev.target?.result || "";
        if (!this.profileMgr?.profile) return;

        const prevCustomText = this.profileMgr.profile.CustomText || "";
        this.profileMgr.profile.CustomText = textVal;
        const saved = this.profileMgr.saveProfile();

        if (saved) {
          if (textarea) textarea.value = textVal;
          const parsed = parseCustomExercises(textVal);
          if (parsed.length > 0) {
            this.customLessons = parsed;
            this.setLessonsSource("custom");
            this.showAppAlert(
              `File "${file.name}" caricato con successo! ${parsed.length} lezioni personalizzate caricate nel menu.`,
              "📂 Caricamento File",
            );
          }
        } else {
          // Rollback: ripristina il testo precedente in memoria e nell'area di testo
          this.profileMgr.profile.CustomText = prevCustomText;
          if (textarea) textarea.value = prevCustomText;
          this.showAppAlert(
            `Impossibile importare il file "${file.name}": spazio di memoria del browser esaurito (Local Storage).\n\nL'operazione è stata annullata (rollback). Libera spazio eliminando profili o campioni prima di importare.`,
            "⚠ Importazione Fallita (Memoria Esaurita)",
          );
        }
        fileInput.value = "";
      };
      reader.readAsText(file);
    });
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
