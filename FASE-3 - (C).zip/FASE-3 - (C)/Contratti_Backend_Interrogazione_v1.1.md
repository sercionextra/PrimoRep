# TenFingersTypingTrainer – Contratti Backend INTERROGAZIONE

**Documento:** Contratti_Backend_Interrogazione_v1.1  
**Baseline:** TenFingersTypingTrainer v6.23  
**Riferimenti funzionali:** SPECIFICA_TECNICA_INTERROGAZIONE_v1.0 e decisioni consolidate nella progettazione  
**Stato:** proposta esecutiva backend; nessuna modifica ai sorgenti  
**Destinazione:** `/workspace/Contratti_Backend_Interrogazione_v1.0.md`

---

## 1. Obiettivo e vincoli

Definire i contratti tra i componenti backend della funzionalità INTERROGAZIONE, in modo da poter progettare IndexedDB e implementare successivamente senza introdurre dipendenze esterne.

Vincoli:

- JavaScript classico, coerente con la baseline; niente moduli ES, TypeScript o framework.
- `KEY_MAP`, `resolveTargetChord()`, `FINGER_NAMES` e i riferimenti anatomici restano le fonti esistenti per i dati della tastiera.
- Le statistiche di digitazione restano separate dalle statistiche di conoscenza.
- La configurazione di una sessione viene congelata all'avvio.
- Storico delle esposizioni, correzioni e audit non vengono riscritti.
- Nessuna implementazione è inclusa in questo documento.

## 2. Componenti e responsabilità

| Componente logico | Responsabilità | Non deve fare |
|---|---|---|
| `InterrogationCatalog` | Leggere e validare elementi, identità, relazioni e definizioni dei sotto-quesiti | Calcolare punteggi o conoscere la UI |
| `InterrogationSelector` | Selezionare gli elementi secondo modalità casuale, adattiva o manuale | Scrivere dati o modificare statistiche |
| `InterrogationKnowledge` | Calcolare esposizioni equivalenti, debolezza, affidabilità, classificazione e prossima verifica | Selezionare direttamente le domande |
| `InterrogationSessionManager` | Creare, avanzare, sospendere, riprendere, abbandonare e completare sessioni | Accedere direttamente al DOM |
| `InterrogationRepository` | Incapsulare IndexedDB, transazioni, indici, migrazioni e recovery | Contenere regole di presentazione |
| UI Interrogazione | Acquisire input, mostrare domande, risposte, feedback e riepiloghi | Calcolare o persistere autonomamente la conoscenza |

I nomi sono identificatori progettuali proposti. Prima dell'implementazione saranno confrontati con convenzioni e dipendenze del controller esistente.

## 3. Identità e record di dominio

### 3.1 Elemento di catalogo

```js
{
  recordId: "rec_<uuid>",
  semanticId: "key.character.at.it-qwerty105",
  type: "CARATTERE", // HOME_ROW | TASTO | CARATTERE | DITO
  layoutId: "it-qwerty-105",
  subjectType: "CHARACTER",
  subjectId: "@",
  categoryId: "CARATTERI",
  status: "active", // active | retired
  contentVersion: 1,
  replacedBySemanticId: null,
  catalogVersion: "catalog-1"
}
```

`semanticId` identifica il significato didattico e rimane stabile finché il significato non cambia. `recordId` identifica il record tecnico. La sostituzione collega due identità distinte e non trasferisce conoscenza.

### 3.2 Relazione di catalogo

```js
{
  relationId: "rel_<uuid>",
  catalogVersion: "catalog-1",
  fromSemanticId: "character.at",
  relationType: "producedBy",
  toSemanticId: "key.physical.key_ò",
  attributes: {},
  status: "active"
}
```

Relazioni iniziali previste: `producedBy`, `requiresModifier`, `assignedToFinger`, `belongsToHand`, `neighborOf`, `homeRowPosition`, `replacedBy`. I nomi effettivi e i valori ammessi saranno validati sul catalogo reale. Le relazioni sono versionate con il catalogo.

### 3.3 Definizione di sotto-quesito

```js
{
  questionSemanticId: "question.character.at.assigned-finger",
  elementSemanticId: "character.at",
  aspectId: "assignedFinger",
  answerType: "FINGER_ID",
  answerDefinition: { acceptedFingerIds: [6] },
  presentationType: "keyboard-and-hands",
  evaluationPolicy: "exact-match",
  contentVersion: 1,
  status: "active"
}
```

Un sotto-quesito identifica una conoscenza autonoma. Cambiare soltanto testo o presentazione non cambia l'identità; aggiungere un aspetto autonomo richiede un nuovo `questionSemanticId`. Ogni sotto-quesito mantiene statistiche indipendenti.

### 3.4 Sessione

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  status: "in-progress", // in-progress | suspended | abandoned | completed
  mode: "adaptive", // adaptive | random | manual
  questionType: "mixed",
  requestedQuestionCount: 10,
  effectiveQuestionCount: 10,
  configSnapshot: {},
  selectionSnapshot: {},
  catalogVersion: "catalog-1",
  algorithmVersion: "selection-1",
  currentItemIndex: 0,
  score: 0,
  createdAt: "ISO-8601",
  updatedAt: "ISO-8601",
  completedAt: null
}
```

La sessione conserva snapshot della configurazione, selezione, catalogo e algoritmo. Una sessione sospesa non viene ricalcolata quando cambiano catalogo, configurazione o statistiche.

### 3.5 Domanda principale e sotto-quesiti della sessione

```js
{
  profileId: "profile-123",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  order: 0,
  mainElementSemanticId: "character.at",
  promptSnapshot: {},
  subQuestions: [
    {
      questionSemanticId: "question.character.at.assigned-finger",
      elementSemanticId: "character.at",
      definitionSnapshot: {},
      status: "pending", // pending | answered | consulted | unanswered
      outcome: null,
      score: 0,
      evaluatedAt: null
    }
  ]
}
```

Le definizioni e i dati necessari alla visualizzazione vengono copiati nello snapshot della sessione. Le risposte già valutate non vengono ricalcolate.

### 3.6 Evento di esposizione

```js
{
  profileId: "profile-123",
  eventId: "event_<uuid>",
  operationId: "operation_<uuid>",
  sessionId: "session_<uuid>",
  itemId: "item_<uuid>",
  questionSemanticId: "question.character.at.assigned-finger",
  elementSemanticId: "character.at",
  outcome: "correct", // correct | incorrect | consulted
  score: 3,
  occurredAt: "ISO-8601",
  eventSequence: 1,
  catalogVersion: "catalog-1",
  definitionVersion: 1
}
```

La semplice visualizzazione e la non risposta non generano eventi di conoscenza. La consultazione genera un evento con punteggio +1; corretta +3; errata 0. Gli eventi sono append-only.

### 3.7 Correzione di evento

```js
{
  profileId: "profile-123",
  correctionId: "correction_<uuid>",
  operationId: "operation_<uuid>",
  eventId: "event_<uuid>",
  correctionType: "invalidate-event", // invalidate-event | reinstate-event | annotate
  reason: "Motivazione esplicita",
  reversesCorrectionId: null,
  catalogVersion: "catalog-2",
  createdAt: "ISO-8601"
}
```

Una correzione non modifica l'evento originale. L'annullamento è una nuova correzione che riferisce quella da annullare. Il motore di conoscenza calcola gli eventi effettivi applicando la sequenza delle correzioni.

### 3.8 Registrazione di audit del catalogo

```js
{
  auditId: "audit_<uuid>",
  operationId: "operation_<uuid>",
  entitySemanticId: "character.at",
  operationType: "relation-updated",
  previousValue: {},
  newValue: {},
  reason: "Motivazione esplicita",
  createdAt: "ISO-8601",
  catalogVersion: "catalog-2"
}
```

L'audit è append-only. Una rettifica genera una nuova registrazione collegata logicamente all'operazione precedente; nessun record di audit viene aggiornato o cancellato dalle normali funzionalità applicative.

### 3.9 Stato di conoscenza derivato

```js
{
  profileId: "profile-123",
  questionSemanticId: "question.character.at.assigned-finger",
  firstExposureAt: "ISO-8601",
  lastExposureAt: "ISO-8601",
  effectiveExposureCount: 4,
  equivalentExposures: 2.75,
  rawWeaknessIndex: 62,
  reliability: 0.3548,
  adjustedWeaknessIndex: 54.26,
  classification: "da-ripassare",
  nextReviewAt: "ISO-8601",
  pendingConsultationPriority: false,
  projectionVersion: 1,
  calculatedAt: "ISO-8601"
}
```

È una proiezione ricostruibile dagli eventi e dalle correzioni. Non sostituisce lo storico. I valori di esempio sono illustrativi, non dati reali.

## 4. Persistenza IndexedDB proposta

**Nome database:** `TenFingersTypingTrainer_Interrogation`  
**Versione iniziale schema:** `1`

| Object store | Chiave primaria | Indici principali | Ambito |
|---|---|---|---|
| `catalogVersions` | `catalogVersion` | `createdAt` | globale |
| `catalogElements` | `[semanticId, contentVersion]` | `semanticId`, `type`, `layoutId`, `status`, `categoryId` | globale |
| `catalogRelations` | `relationId` | `catalogVersion`, `fromSemanticId`, `toSemanticId`, `relationType` | globale |
| `questionDefinitions` | `[questionSemanticId, contentVersion]` | `questionSemanticId`, `elementSemanticId`, `status` | globale |
| `profileSettings` | `profileId` | — | profilo |
| `sessions` | `[profileId, sessionId]` | `[profileId, status]`, `[profileId, createdAt]` | profilo |
| `sessionItems` | `[profileId, sessionId, itemId]` | `[profileId, sessionId, order]` | profilo |
| `exposureEvents` | `[profileId, eventId]` | `[profileId, questionSemanticId, occurredAt]`, `[profileId, sessionId]`, `operationId` | profilo |
| `eventCorrections` | `[profileId, correctionId]` | `[profileId, eventId]`, `operationId` | profilo |
| `knowledgeStates` | `[profileId, questionSemanticId]` | `[profileId, classification]`, `[profileId, nextReviewAt]` | profilo |
| `catalogAudit` | `auditId` | `entitySemanticId`, `createdAt`, `operationId` | globale |
| `operationReceipts` | `[scope, operationId]` | `createdAt` | globale/profilo secondo scope |

Le chiavi composte isolano i dati dei profili. Le definizioni di elemento e sotto-quesito sono versionate, così le versioni precedenti restano disponibili. Il catalogo è condiviso; eventi, sessioni, configurazioni e conoscenza sono partizionati per profilo.

### 4.1 Dati non duplicati

- `KEY_MAP` resta la fonte del mapping carattere/tasto/dito già codificato nella baseline; il catalogo aggiunge identità e semantica didattica, non una seconda mappa tecnica concorrente.
- I nomi delle dita provengono da `FINGER_NAMES`.
- Le coordinate anatomiche provengono dai dati già esistenti.
- Le statistiche di digitazione restano nel profilo LocalStorage e in `StatisticsManager`.
- Le statistiche di conoscenza vengono conservate in IndexedDB.

## 5. Contratti dei servizi

Le funzioni pubbliche saranno asincrone quando coinvolgono IndexedDB. I nomi seguenti descrivono il contratto, non codice già implementato.

| Servizio | Operazione | Input essenziale | Output |
|---|---|---|---|
| Repository | `open()` | — | database pronto e schema verificato |
| Catalog | `getAvailableElements()` | tipo, layout, categoria | elementi attivi e validi |
| Catalog | `getQuestionDefinitions()` | semanticId o tipologia | sotto-quesiti attivi |
| Selector | `buildSelection()` | profilo, configurazione, catalogo, snapshot conoscenza, seed | selezione ordinata e quote effettive |
| Session Manager | `createSession()` | profilo, configurazione, modalità | sessione e snapshot persistiti |
| Session Manager | `recordOutcome()` | profilo, sessione, item, sotto-quesito, risposta, operationId | esito persistito e sessione aggiornata |
| Session Manager | `suspendSession()` | profilo, sessione | sessione sospesa |
| Session Manager | `resumeSession()` | profilo | sessione sospesa ripristinata senza ricalcolo |
| Session Manager | `abandonSession()` | profilo, sessione, conferma | sessione abbandonata; risultati conservati |
| Session Manager | `completeSession()` | profilo, sessione, conferma | sessione formalmente completata |
| Knowledge | `rebuildQuestionState()` | profilo, questionSemanticId | proiezione conoscenza aggiornata |
| Repository | `exportProfile()` | profilo | pacchetto versionato completo |
| Repository | `importProfile()` | pacchetto, strategia conflitti | esito importazione e report |

### 5.1 Contratto di `recordOutcome()`

È l'operazione transazionale centrale. Deve:

1. Verificare esistenza, profilo, sessione e stato del sotto-quesito.
2. Verificare `operationId` per impedire doppie registrazioni.
3. Rifiutare una seconda valutazione dello stesso sotto-quesito, salvo flusso esplicito di correzione.
4. Registrare l'evento immutabile.
5. Aggiornare la proiezione `knowledgeStates`.
6. Aggiornare esito, punteggio e avanzamento in `sessionItems` e `sessions`.
7. Registrare la ricevuta dell'operazione.
8. Confermare tutto in una singola transazione IndexedDB oppure annullare tutto.

La classificazione aggiornata vale per le sessioni future. La sessione corrente conserva lo snapshot iniziale.

## 6. Regole di consistenza

- **Idempotenza:** `operationReceipts` usa la coppia scope/operationId come chiave univoca. Stessa chiave e stesso payload restituiscono l'esito già registrato; stessa chiave con payload differente genera conflitto.
- **Concorrenza:** ogni record modificabile usa `revision` incrementale o confronto del valore/versione letto. Le modifiche indipendenti non si bloccano reciprocamente.
- **Eliminazione:** elementi usati nello storico vengono dismessi; non vengono rimossi fisicamente. Le dipendenze sono validate nella stessa transazione.
- **Versioni:** sessioni ed eventi mantengono riferimenti alle versioni di catalogo e definizione utilizzate.
- **Audit:** modifiche del catalogo, dismissioni, riattivazioni, sostituzioni, correzioni e risoluzioni conflitto producono record append-only.
- **Recovery:** all'avvio si controllano sessioni `in-progress`, operazioni pendenti e importazioni interrotte; nessun risultato già confermato viene duplicato.
- **Profilo:** ogni query e cancellazione relativa ai dati personali deve includere `profileId` nella chiave o nell'indice usato.

## 7. Confine transazionale LocalStorage / IndexedDB

IndexedDB e LocalStorage non condividono una transazione atomica. Non sarà dichiarata atomicità distribuita tra i due storage.

Per importazione, esportazione e cancellazione profilo si userà una procedura recuperabile a fasi:

1. Validare integralmente il pacchetto e preparare il piano.
2. Scrivere un marker di operazione pendente.
3. Applicare i dati IndexedDB in una transazione atomica.
4. Applicare i dati LocalStorage tramite le procedure del `ProfileManager`.
5. Verificare entrambi gli esiti e chiudere il marker.
6. Se il browser si interrompe, il successivo avvio rileva il marker e completa il rollback o la ripresa secondo la fase raggiunta.

La cancellazione di un profilo richiede prima un export completato e verificato. Se export o cancellazione falliscono, il profilo non deve essere dichiarato eliminato. La cancellazione IndexedDB usa esclusivamente le chiavi del profilo selezionato.

**Nota d'integrazione:** `ProfileManager.importProfileData()` aggiorna `TFT_ACTIVE_USER` dopo il salvataggio del profilo e della lista utenti, ma non verifica il risultato di quella scrittura finale. Questo punto dovrà essere gestito con un adattamento circoscritto durante l'integrazione, senza riscrivere il gestore profili.

## 8. Migrazioni e compatibilità

- La versione IndexedDB cresce solo quando cambia lo schema fisico.
- Ogni migrazione è sequenziale, deterministica e non distruttiva.
- Le migrazioni non cambiano le identità semantiche né riscrivono eventi storici.
- Il pacchetto di esportazione include `packageFormatVersion`, `appVersion`, `profileId`, `exportedAt`, `catalogVersion`, `profileData` e `interrogationData`.
- L'importazione valida versione, struttura, riferimenti, duplicati e integrità prima di scrivere.
- Gli eventi con `eventId` già presenti e payload identico vengono ignorati come duplicati; payload differente produce conflitto.
- Le identità semantiche uguali con definizioni incompatibili non vengono fuse automaticamente.

## 9. Errori applicativi minimi

Codici logici previsti:

- `DB_UNAVAILABLE`: IndexedDB non disponibile o apertura fallita.
- `DB_UPGRADE_BLOCKED`: aggiornamento bloccato da un'altra scheda.
- `QUOTA_EXCEEDED`: spazio disponibile insufficiente.
- `PROFILE_NOT_FOUND`: profilo non esistente.
- `SESSION_NOT_FOUND`: sessione non esistente.
- `SESSION_STATE_CONFLICT`: transizione di stato non consentita.
- `STALE_RECORD`: versione letta non più corrente.
- `DUPLICATE_OPERATION`: operazione già applicata con payload identico.
- `OPERATION_ID_CONFLICT`: stesso operationId con payload differente.
- `SEMANTIC_ID_CONFLICT`: identità semantica con significato incompatibile.
- `IMPORT_VALIDATION_FAILED`: pacchetto non valido.

Gli errori devono essere gestiti dalla UI con messaggi comprensibili; i dettagli tecnici vanno nel registro diagnostico, non nell'HELP.

## 10. Questioni da chiudere nel deliverable successivo

1. **Quote adattive D77–D80:** formalizzazione matematica consolidata in `Decisione_Quote_Adattive_D77-D80_v1.1`. Budget globale 10 punti percentuali, tetto individuale 20% della quota base normalizzata, riparto proporzionale iterativo ai deficit, quota neutra per il residuo e nessuna correzione se tutti i deficit sono nulli. I test numerici vincolanti sono definiti nell'addendum.
2. Completare il catalogo iniziale per layout italiano QWERTY 105 tasti, controllando `KEY_MAP`, SVG e landmark.
3. Definire il seed e il generatore casuale deterministico usato per riprodurre una selezione di sessione.
4. Fissare gli intervalli e la transizione del calendario di consolidamento in coerenza con la specifica funzionale.
5. Definire la gestione di storage non disponibile, quota esaurita e upgrade bloccato in più schede.

Questi punti non bloccano la definizione dei contratti, ma devono essere risolti prima di implementare il motore completo.

## 11. Esito

Il backend è separato in catalogo, selezione, conoscenza, sessioni e repository. IndexedDB è la fonte persistente per il dominio Interrogazione; LocalStorage e `ProfileManager` continuano a gestire i dati profilo già esistenti. Il punto di coerenza più importante è la transazione di valutazione, che deve registrare insieme evento, conoscenza, punteggio e avanzamento.

Questo documento non autorizza modifiche ai sorgenti. È la base per il successivo schema fisico IndexedDB e per il piano di test.
