#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
  let _lastTimeoutDelay = null;
  let _lastTimeoutCallback = null;
  const sandbox = {
    console,
    window: {
      speechSynthesis: {
        speak: () => {},
        cancel: () => {},
        resume: () => {},
        pause: () => {},
        speaking: false,
        pending: false,
        paused: false,
        getVoices: () => []
      }
    },
    SpeechSynthesisUtterance: function(text) { this.text = text; },
    setTimeout: (cb, ms) => {
      _lastTimeoutDelay = ms;
      _lastTimeoutCallback = cb;
      return 1;
    },
    getLastTimeoutDelay: () => _lastTimeoutDelay,
    triggerLastTimeout: () => { if (typeof _lastTimeoutCallback === "function") _lastTimeoutCallback(); },
    clearTimeout: () => {},
    Date: { now: () => 1000 }
  };
vm.createContext(sandbox);

const files = [
  "js/domain/helpers.js",
  "js/engines/dictation-engine.js"
];

for (const f of files) {
  const code = fs.readFileSync(path.join(root, f), "utf8");
  vm.runInContext(code, sandbox, { filename: f });
}

const testResults = vm.runInContext(`
(() => {
  const de = new DictationEngine();
  de.setEnabled(true);
  const text = "la tastiera ergonomica funziona bene";
  de.startSession(text, 0);

  const spokenLog = [];
  de.speakCurrentToken = function(forcedVoice, customText) {
    const token = this.tokens[this.currentIndex];
    const textToSpeak = customText !== null && customText !== undefined ? customText : (token ? token.spokenText : "");
    spokenLog.push({ index: this.currentIndex, text: textToSpeak });
  };

  const results = [];

  // TEST 1: Con Dettatura Adattiva DISATTIVATA (Default), il coefficiente è fisso a 0.65
  de.setAdaptiveMode(false);
  const token0 = de.tokens[0]; // "la" (span: 2)
  const token1 = de.tokens[1]; // " tastiera" (start: 2, end: 11, span: 9)
  
  // A matchLen 2 siamo all'inizio di " tastiera"
  de.currentIndex = 1;
  spokenLog.length = 0;
  // Con soglia fissa 0.65 su tokenSpan 9: threshold = Math.floor(9 * 0.65) = 5
  // matchLen = 2 + 4 = 6 -> progressInToken = 4 < 5 -> nessun anticipo
  de.updateProgress(6, 6, 80);
  results.push({ name: "Adaptive OFF: progress 4 < 5, no anticipo", pass: de.currentIndex === 1 });

  // matchLen = 2 + 5 = 7 -> progressInToken = 5 >= 5 -> anticipo scattato!
  de.updateProgress(7, 7, 80);
  results.push({ name: "Adaptive OFF: progress 5 >= 5, anticipo a next token", pass: de.currentIndex === 2 });

  // TEST 2: Attivazione Dettatura Adattiva con soglie 100 CPM e 200 CPM
  de.setAdaptiveMode(true);
  de.setAdaptiveCpmThresholds(100, 200);
  de.startSession(text, 0);
  de.currentIndex = 1; // " tastiera", start: 2, end: 11, span: 9
  spokenLog.length = 0;

  // TEST 2A: Velocità lenta <= 100 CPM (es. 80 CPM) -> coeff = 1.00 -> threshold = 9
  // progressInToken = 5 -> nessun anticipo
  de.updateProgress(7, 7, 80);
  results.push({ name: "Adaptive ON (80 CPM): progress 5 < 9, no anticipo", pass: de.currentIndex === 1 });

  // progressInToken = 8 -> nessun anticipo
  de.updateProgress(10, 10, 80);
  results.push({ name: "Adaptive ON (80 CPM): progress 8 < 9, no anticipo", pass: de.currentIndex === 1 });

  // progressInToken = 9 (ultimo carattere 'a' digitato) -> threshold 9 raggiunta! Anticipo al completamento della parola!
  de.updateProgress(11, 11, 80);
  results.push({ name: "Adaptive ON (80 CPM): progress 9 == 9, anticipo a parola completata", pass: de.currentIndex === 2 });

  // TEST 2B: Velocità veloce >= 200 CPM (es. 220 CPM) -> coeff = 0.65 -> threshold = 5
  de.startSession(text, 0);
  de.currentIndex = 1;
  // 4 battute veloci per completare la rampa di recupero/avvio
  de.updateProgress(3, 3, 220);
  de.updateProgress(4, 4, 220);
  de.updateProgress(5, 5, 220);
  de.updateProgress(6, 6, 220);
  results.push({ name: "Adaptive ON (220 CPM): progress 4 < 5, no anticipo", pass: de.currentIndex === 1 });

  de.updateProgress(7, 7, 220);
  results.push({ name: "Adaptive ON (220 CPM): progress 5 >= 5, anticipo al 65%", pass: de.currentIndex === 2 });

  // TEST 3: Gestione Errori e Ripresa (1° Errore vs 2° Errore)
  de.startSession(text, 0);
  de.currentIndex = 1; // " tastiera" (start: 2, end: 11)
  spokenLog.length = 0;

  // L'allievo digita correttamente " ta" (matchLen 4), poi commette il 1° errore
  de.notifyError();
  results.push({ name: "1° Errore: tokenErrorCount == 1", pass: de.tokenErrorCount === 1 && spokenLog[spokenLog.length - 1].text === "errore" });

  // Cancella l'errore con Backspace (remainingErrors == 0)
  // Al 1° errore: deve pronunciare il troncone residuo "stiera" come parola continua
  spokenLog.length = 0;
  de.notifyErrorCorrection(0, 4, 4, text);
  results.push({ 
    name: "1° Errore corretto: troncone residuo continuo ('stiera')", 
    pass: spokenLog.length > 0 && spokenLog[spokenLog.length - 1].text.includes("stiera") && !spokenLog[spokenLog.length - 1].text.includes(",") 
  });
  results.push({ name: "1° Errore corretto: recoveryStreak azzerata (prudente)", pass: de.recoveryStreak === 0 });
  results.push({ name: "1° Errore corretto: isRecoveringTroncone attivo", pass: de.isRecoveringTroncone === true && de.recoveringTokenIdx === 1 });

  // Digitazione lettere corrette all'interno del troncone (matchLen 5 < 11): non deve anticipare la parola successiva
  de.updateProgress(5, 5, 150);
  results.push({ name: "Troncone in corso: nessun anticipo durante digitazione del troncone", pass: de.currentIndex === 1 });

  // L'allievo commette un 2° errore sulla stessa parola!
  de.notifyError();
  results.push({ name: "2° Errore: tokenErrorCount == 2", pass: de.tokenErrorCount === 2 });

  // Cancella nuovamente l'errore con Backspace (remainingErrors == 0)
  // Al 2° errore: deve attivare lo SPELLING persistente e pronunciare la lettera corrente a spelling (text[4] == 'a')
  spokenLog.length = 0;
  de.notifyErrorCorrection(0, 4, 4, text);
  results.push({ 
    name: "2° Errore corretto: SPELLING persistente attivo", 
    pass: de.wordSpellingTokenIdx === 1 && spokenLog.length > 0 && spokenLog[spokenLog.length - 1].text === "a"
  });

  // La battuta corretta successiva nella parola continua a scandire a spelling la lettera successiva (text[5] == 's' -> 'esse')
  spokenLog.length = 0;
  de.updateProgress(5, 5, 150);
  results.push({
    name: "2° Errore: battuta successiva scandisce lettera a spelling",
    pass: spokenLog.length > 0 && spokenLog[spokenLog.length - 1].text === "esse"
  });

  // TEST 4: Cambio parola resetta tokenErrorCount e wordSpellingTokenIdx
  // L'allievo supera " tastiera" e approda a " ergonomica" (activeTokenIdx = 2)
  de.updateProgress(12, 12, 150);
  results.push({ name: "Avanzamento parola: tokenErrorCount resettato a 0", pass: de.tokenErrorCount === 0 && de.wordSpellingTokenIdx === -1 });

  // TEST 5: Flag Globale SPELLING ha precedenza assoluta
  de.setSpelling(true);
  results.push({ name: "Spelling Globale attivo", pass: de.forceSpelling === true });

  // TEST 6: Verifica non-interruzione e buffer lookahead a profondità 1 (Opzione C)
  const realEngine = new DictationEngine();
  realEngine.setEnabled(true);
  let synthCancelCalls = 0;
  let synthSpeakCalls = 0;
  let lastUtterance = null;
  realEngine.synth = {
    speaking: false,
    pending: false,
    paused: false,
    speak: (u) => { synthSpeakCalls++; lastUtterance = u; },
    cancel: () => { synthCancelCalls++; },
    resume: () => {},
    pause: () => {},
    getVoices: () => []
  };
  realEngine.startSession(text, 0);
  realEngine.speakCurrentToken(); // avvia l'utterance iniziale attiva
  synthCancelCalls = 0; // reset dopo startSession

  // Simuliamo che la voce stia attualmente pronunciando token 0
  realEngine.synth.speaking = true;
  realEngine.isSpeaking = true;

  // L'allievo digita un tasto corretto che raggiunge la soglia di anticipo
  realEngine.updateProgress(1, 1, 150);
  // Con Opzione C: synth.cancel() NON deve essere chiamato!
  results.push({ name: "Opzione C: Nessun synth.cancel() su battuta corretta", pass: synthCancelCalls === 0 });
  results.push({ name: "Opzione C: Prossimo token memorizzato in pendingLookahead", pass: realEngine.pendingLookahead !== null });

  // Quando l'audio corrente termina (onend): scarica pendingLookahead
  realEngine.synth.speaking = false;
  realEngine.isSpeaking = false;
  if (lastUtterance && typeof lastUtterance.onend === "function") {
    lastUtterance.onend();
  }
  results.push({ name: "Opzione C: Scarico proattivo pendingLookahead all'onend", pass: realEngine.pendingLookahead === null });

  // TEST 7: Cadenza Inattività a 1s e rallentamento a 3s dopo 3 tentativi consecutivi (Release v6.15)
  const cadenceEngine = new DictationEngine();
  cadenceEngine.setEnabled(true);
  cadenceEngine.startSession(text, 0);

  // Inizialmente senza ripetizioni: delay deve essere esattamente 1000 ms (1 secondo)
  cadenceEngine.resetStallTimer();
  results.push({ 
    name: "v6.15: Delay iniziale inattività pari a 1000 ms", 
    pass: getLastTimeoutDelay() === 1000 
  });

  // Simulazione di 3 ripetizioni consecutive di inattività con conclusione audio (onend)
  cadenceEngine._handleStallTimeout(); // 1a ripetizione
  results.push({ name: "v6.15: 1a ripetizione incrementa stallRepetitionCount a 1", pass: cadenceEngine.stallRepetitionCount === 1 });
  cadenceEngine.isSpeaking = false; // l'audio è terminato
  cadenceEngine.resetStallTimer();
  results.push({ name: "v6.15: Delay dopo 1a ripetizione ancora 1000 ms", pass: getLastTimeoutDelay() === 1000 });

  cadenceEngine._handleStallTimeout(); // 2a ripetizione
  results.push({ name: "v6.15: 2a ripetizione incrementa stallRepetitionCount a 2", pass: cadenceEngine.stallRepetitionCount === 2 });
  cadenceEngine.isSpeaking = false; // l'audio è terminato
  cadenceEngine.resetStallTimer();
  results.push({ name: "v6.15: Delay dopo 2a ripetizione ancora 1000 ms", pass: getLastTimeoutDelay() === 1000 });

  cadenceEngine._handleStallTimeout(); // 3a ripetizione
  results.push({ name: "v6.15: 3a ripetizione incrementa stallRepetitionCount a 3", pass: cadenceEngine.stallRepetitionCount === 3 });
  cadenceEngine.isSpeaking = false; // l'audio è terminato
  cadenceEngine.resetStallTimer();
  // Dopo 3 ripetizioni consecutive, il delay deve salire a 3000 ms (3 secondi)
  results.push({ 
    name: "v6.15: Delay dopo 3 ripetizioni consecutive passa a 3000 ms", 
    pass: getLastTimeoutDelay() === 3000 
  });

  // Appena l'utente riprende la digitazione: contatore e delay si resettano istantaneamente a 1 secondo
  cadenceEngine.isSpeaking = false;
  cadenceEngine.updateProgress(1, 1, 120);
  results.push({ 
    name: "v6.15: Digitazione utente azzera stallRepetitionCount a 0", 
    pass: cadenceEngine.stallRepetitionCount === 0 
  });
  cadenceEngine.isSpeaking = false;
  cadenceEngine.resetStallTimer();
  results.push({ 
    name: "v6.15: Digitazione utente riporta il timer a 1000 ms", 
    pass: getLastTimeoutDelay() === 1000 
  });

  // TEST 8: Ipotesi A (Formula Didattica Ultra-Sintetica - Nessun prefisso 'completa digitando...')
  let replaySpoken = "";
  cadenceEngine.speakCurrentToken = (voice, txt) => { replaySpoken = txt; };

  // Caso 8A: Inizio parola -> pronuncia la parola intera
  cadenceEngine.replay(0, 0, text, true);
  results.push({ 
    name: "v6.15 (Ipotesi A): Inizio parola pronuncia intera senza prefissi", 
    pass: replaySpoken === "la" && !replaySpoken.includes("completa digitando") 
  });

  // Caso 8B: Metà parola (matchLen 4 -> "ta" digitato di "tastiera") -> pronuncia solo il troncone residuo continuo ("stiera")
  cadenceEngine.replay(4, 4, text, true);
  results.push({ 
    name: "v6.15 (Ipotesi A): Metà parola pronuncia unicamente il troncone residuo ('stiera')", 
    pass: replaySpoken.includes("stiera") && !replaySpoken.includes("completa digitando") 
  });

  // TEST 9: Opzione B (Promemoria Correzione Cadenzato)
  // Se l'utente ha commesso 1 errore (typedLen 5 > matchLen 4), il replay ripete unicamente l'avviso di correzione
  cadenceEngine.replay(5, 4, text, true);
  results.push({ 
    name: "v6.15 (Opzione B): Presenza errori notifica 'ancora un errore' e non ripete la parola", 
    pass: replaySpoken === "ancora un errore" 
  });

  // Se l'utente ha commesso 2 errori
  cadenceEngine.replay(6, 4, text, true);
  results.push({ 
    name: "v6.15 (Opzione B): Due errori notifica 'ancora due errori'", 
    pass: replaySpoken === "ancora due errori" 
  });

  // TEST 10: Riavvio del timer di attesa al termine naturale dell'audio (utter.onend)
  let onEndCalledReset = false;
  const onEndEngine = new DictationEngine();
  onEndEngine.setEnabled(true);
  onEndEngine.startSession(text, 0);
  let capturedUtterance = null;
  onEndEngine.synth = {
    speaking: false,
    pending: false,
    paused: false,
    speak: (u) => { capturedUtterance = u; },
    cancel: () => {},
    resume: () => {},
    pause: () => {},
    getVoices: () => []
  };
  onEndEngine.speakCurrentToken();
  onEndEngine.resetStallTimer = () => { onEndCalledReset = true; };
  if (capturedUtterance && typeof capturedUtterance.onend === "function") {
    capturedUtterance.onend();
  }
  results.push({ 
    name: "v6.15: utter.onend riavvia il contatore di attesa al termine della pronuncia", 
    pass: onEndCalledReset === true 
  });

  // TEST 11: Auto-Healing per Ghost-Lock (Release v6.16)
  const ghostEngine = new DictationEngine();
  ghostEngine.setEnabled(true);
  ghostEngine.startSession(text, 0);
  // Simuliamo un ghost-lock: isSpeaking = true e synth.speaking = true, avviato oltre 2300 ms fa
  ghostEngine.isSpeaking = true;
  ghostEngine.synth = {
    speaking: true,
    pending: false,
    paused: false,
    speak: () => {},
    cancel: () => { ghostEngine.synth.speaking = false; },
    resume: () => {},
    pause: () => {},
    getVoices: () => []
  };
  ghostEngine.lastSpeechStartTime = 1000 - 2500;
  // Con l'Auto-Healing v6.16/v6.17, resetStallTimer rileva il ghost-lock, forza stopAudioOnly() e arma il timer a 1000 ms
  ghostEngine.resetStallTimer();
  results.push({
    name: "v6.16: Auto-Healing sblocca ghost-lock e azzera isSpeaking",
    pass: ghostEngine.isSpeaking === false
  });
  results.push({
    name: "v6.16: Auto-Healing riarma regolarmente il timer di inattività a 1000 ms",
    pass: getLastTimeoutDelay() === 1000
  });

  // TEST 12: Disaccoppiamento hardware e protezione Ghost-Lock orfano (Release v6.17)
  const orphanEngine = new DictationEngine();
  orphanEngine.setEnabled(true);
  orphanEngine.startSession(text, 0);
  let synthCancelCalled = false;
  let synthSpeakCalled = false;
  orphanEngine.isSpeaking = false; // L'applicazione NON sta parlando
  orphanEngine.synth = {
    speaking: true, // Ma l'hardware del browser è rimasto congelato a true
    pending: false,
    paused: false,
    speak: () => { synthSpeakCalled = true; },
    cancel: () => { synthCancelCalled = true; orphanEngine.synth.speaking = false; },
    resume: () => {},
    pause: () => {},
    getVoices: () => []
  };
  orphanEngine.resetStallTimer();
  results.push({
    name: "v6.17: resetStallTimer disaccoppia Ghost-Lock orfano ed esegue synth.cancel()",
    pass: synthCancelCalled === true
  });
  results.push({
    name: "v6.17: resetStallTimer arma regolarmente il timer di inattività a 1000 ms",
    pass: getLastTimeoutDelay() === 1000
  });

  // Verifica speakCurrentToken non si blocca in pendingLookahead se isSpeaking === false
  orphanEngine.synth.speaking = true; // Di nuovo ghost-lock hardware
  synthCancelCalled = false;
  orphanEngine.speakCurrentToken();
  results.push({
    name: "v6.17: speakCurrentToken bypassa ghost hardware ed emette voce senza intrappolarsi",
    pass: synthSpeakCalled === true && orphanEngine.pendingLookahead === null
  });

  // TEST 13: Ipotesi A e protezione da duplicazione acustica nello spelling (Release v6.19)
  const ipoEngine = new DictationEngine();
  ipoEngine.setEnabled(true);
  ipoEngine.setAdaptiveMode(true);
  ipoEngine.startSession("roma", 1); // Mode 1: Lettere singole
  
  // Simula un Replay da inattività in corso per la prima lettera ('r')
  ipoEngine.isSpeakingReplay = true;
  ipoEngine.isSpeaking = true;
  let cancelTriggeredOnCorrectKey = false;
  ipoEngine.synth = {
    speaking: true,
    pending: false,
    paused: false,
    speak: () => {},
    cancel: () => { cancelTriggeredOnCorrectKey = true; },
    resume: () => {},
    pause: () => {},
    getVoices: () => []
  };

  // L'allievo preme la lettera corretta 'r' (matchLen = 1)
  ipoEngine.updateProgress(1, 1, 120);

  results.push({
    name: "v6.19 (Ipotesi A): battuta corretta interrompe immediatamente il replay di stallo della lettera passata",
    pass: cancelTriggeredOnCorrectKey === true && ipoEngine.isSpeakingReplay === false
  });
  results.push({
    name: "v6.19 (Ipotesi A): dopo l'interruzione del replay, il cursore vocale punta alla lettera successiva ('o')",
    pass: ipoEngine.currentIndex === 1
  });

  // Verifica Keystroke Inactivity Guard nel timer di stallo a 1 secondo
  ipoEngine.lastKeystrokeTime = 1000;
  // Se Date.now() è 1500 (500ms dalla battuta), _handleStallTimeout non deve avviare replay
  let replayFiredPrematurely = false;
  ipoEngine.replay = () => { replayFiredPrematurely = true; };
  Date.now = () => 1500;
  ipoEngine._handleStallTimeout();
  results.push({
    name: "v6.19: il timer di stallo non avvia il replay se l'utente ha digitato meno di 1 secondo fa",
    pass: replayFiredPrematurely === false
  });

  return results;
})()
`, sandbox);

let allPassed = true;
for (const r of testResults) {
  if (r.pass) {
    console.log("PASS:", r.name);
  } else {
    console.error("FAIL:", r.name);
    allPassed = false;
  }
}

if (!allPassed) {
  process.exit(1);
}
console.log("TEST RESULT: TUTTI I TEST DETTATURA ADATTIVA SUPERATI CON SUCCESSO!");
