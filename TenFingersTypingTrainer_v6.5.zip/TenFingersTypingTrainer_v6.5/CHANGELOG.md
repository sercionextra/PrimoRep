# Changelog

## v6.5 — 30/10/2026

- Risolto il mancato ricalcolo retroattivo della Media Mobile nella finestra Velocità Istantanea: implementato il metodo `TypingEngine.recalculateInstantSpeedMovingAverages()`, che ricalcola all'istante l'intera serie dei campioni già digitati nell'esercizio corrente appena l'utente modifica il parametro N nel modale Parametri.
- La curva del grafico si rimodella immediatamente a schermo alla conferma del nuovo valore di N senza richiedere il riavvio dell'esercizio.
- Allineata la documentazione didattica in `help.html` e nel Manuale Utente per illustrare il comportamento del ricalcolo dinamico.
- Sincronizzati codice sorgente, documentazione, manifest e test automatici alla release v6.5.

## v6.4 — 30/10/2026

- Corretto il calcolo delle linee medie cumulative Netta e Lorda nella finestra Velocità Istantanea: applicata la formula basata sul tempo trascorso in secondi (Media Netta = Caratteri Corretti *60 / Tempo Secondi; Media Lorda = Caratteri Totali* 60 / Tempo Secondi).
- Ingrandito il font dei caratteri in ascissa a 18px bold e dei timestamp sss.mmm verticali a 13px bold, aumentando il margine inferiore a 112px per garantire assenza di sovrapposizioni o troncamenti.
- Ingrandita l'indicazione BPM del crosshair orizzontale rosso a 18px bold con ancoraggio dinamico allo scorrimento orizzontale per rimanere sempre visibile nella porzione di finestra visualizzata.
- Ingrandita l'indicazione del crosshair verticale azzurro a 16px bold con mantenimento all'interno dei bordi visibili dello schermo.
- Ingranditi i font delle etichette delle Medie Lorda e Netta a 15px bold con posizionamento sticky visibile durante lo scorrimento.
- Risolto il blocco della finestra "Parametri Velocità Istantanea": registrata l'inizializzazione dei listener in AppController.start() e in setupFloatingWindows(), abilitati tasto di chiusura "x", pulsanti Conferma, Annulla, Default, tasto Escape e click sull'overlay esterno.
- Integrata nell'Help in linea e nel Manuale Utente la spiegazione pedagogica sull'uso della finestra tachimetrica: strumento avanzato da utilizzare dopo il completamento del programma per stimare i limiti di velocità superiori tramite i picchi del grafico.
- Sincronizzati tutti i file applicativi, documentazione, manuale utente e test alla versione v6.4.

## v6.3 — 30/10/2026

- Introdotta la nuova funzionalità "Velocità Istantanea": finestra fluttuante traslabile e ridimensionabile con 8 maniglie perimetrali per il monitoraggio in tempo reale del ritmo di battitura.
- Implementato il grafico SVG ad auto-scorrimento orizzontale continuo con passo costante (30 px) e timestamp sss.mmm ruotati in verticale a 90 gradi antiorari.
- Calcolo della velocità tramite Media Mobile fisicamente consistente (Metodo B: tempo cumulato degli ultimi N intervalli).
- Parametro N della finestra mobile (range 1-10, default 3) configurabile tramite modale dedicato "Parametri" e persistito nel profilo utente.
- Visualizzazione di due linee medie orizzontali di riferimento per la velocità cumulativa lorda e netta.
- Integrazione del crosshair interattivo al passaggio del mouse con lettura dei BPM sull'asse delle ordinate e del tempo sull'asse delle ascisse.
- Aggiunto il checkbox dedicato nella toolbar dei controlli e assegnata la scorciatoia da tastiera globale CTRL+SHIFT+I.
- Pulsante "Default" per il ripristino immediato della posizione e dimensione standard ancorata sopra l'area tastiera.
- Aggiornata la documentazione didattica, il manuale utente, la guida in linea, i test statici e i manifest alla release v6.3.

## v6.2 — 29/10/2026

- Risolta l'anomalia nella cancellazione dei campioni non selezionati nelle statistiche in presenza di filtri attivi: il pulsante "Elimina non selezionati" cancella solo i campioni visibili nel grafico che rispettano i filtri applicati ma non appartengono alla selezione corrente.
- Preservati intatti sia i campioni selezionati sia l'intero archivio storico dei campioni esterni ai filtri attivi.
- Disabilitazione contestuale coerente del pulsante "Elimina non selezionati" all'avvio e quando non ci sono campioni da eliminare nella vista corrente.
- Aggiornati dialoghi di conferma modale, messaggi di notifica, documentazione, manuale utente, guida in linea e suite di verifica alla v6.2.

## v6.1 — 29/10/2026

- Risolto il blocco della dettatura vocale dopo la correzione degli errori: rimossa la formula prolissa di completamento ed eliminata l'interruzione brusca dell'audio alla digitazione.
- La dettatura riprende direttamente dal primo carattere non ancora digitato appena gli errori tornano a zero con Backspace.
- Ottimizzato il tracciamento del token attivo e del lookahead predittivo durante la digitazione rapida, prevenendo desincronizzazioni e blocchi della voce.
- Allineati codice sorgente, documentazione, manuale utente, help in-app e suite di verifica alla v6.1.

## v6.0 — 27/10/2026

- Avviato il refactoring strutturale dei sorgenti in file separati per responsabilità.
- Estratto il CSS dell'interfaccia in un asset dedicato.
- Conservati dataset didattico, motori, interfaccia e persistenza della v5.1 come baseline di equivalenza.
- Allineati titolo, percorsi degli asset e guida HTML alla v6.0.
- Aggiunti documentazione architetturale e checklist di regressione.
- Nessuna migrazione distruttiva dei dati browser introdotta.

Nota: questa release privilegia la compatibilità; la conversione completa a moduli ES/TypeScript richiede una fase ulteriore di estrazione delle dipendenze e test runtime.
