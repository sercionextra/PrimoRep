# Esperienza pregressa e vincolo del simulatore virtuale

Lo studente ha già provato a risolvere il cubo in passato, quindi ha familiarità visiva con il puzzle, ma non possiede un cubo fisico e praticherà esclusivamente sul simulatore [Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3).

- **Evidence**: Dichiarazione diretta dell'utente durante la definizione della missione.
- **Implications**: Le lezioni devono evitare consigli basati sulla memoria muscolare fisica (fingertricks) e puntare invece su sequenze brevi, facili da eseguire con mouse/tastiera e verificabili visivamente sullo schermo.
