#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(
  path.join(root, "js/engines/dictation-engine.js"),
  "utf8",
);

function createEngine(voices) {
  let speakCalls = 0;
  const synth = {
    speaking: false,
    pending: false,
    paused: false,
    onvoiceschanged: null,
    getVoices: () => voices,
    speak: () => { speakCalls += 1; },
    cancel: () => {},
    resume: () => {},
    pause: () => {},
  };
  const sandbox = {
    window: { speechSynthesis: synth },
    SpeechSynthesisUtterance: function (text) { this.text = text; },
    setTimeout: () => 1,
    clearTimeout: () => {},
    Date,
    console,
  };
  vm.createContext(sandbox);
  vm.runInContext(`${source}\nglobalThis.DictationEngine = DictationEngine;`, sandbox, { filename: "dictation-engine.js" });
  const engine = new sandbox.DictationEngine();
  engine.enabled = true;
  engine.tokens = [{ spokenText: "prova" }];
  engine.currentIndex = 0;
  return { engine, synth, getSpeakCalls: () => speakCalls };
}

// 1. Default (allowRemoteTtsVoices = true): seleziona la migliore voce italiana (anche online/neurale) e mantiene fallback locale
const onlineAllowed = createEngine([
  { name: "Italian Local Basic", lang: "it-IT", localService: true },
  { name: "Microsoft Elsa Online (Natural) - Italian (Italy)", lang: "it-IT", localService: false },
]);
if (!onlineAllowed.engine.allowRemoteTtsVoices) {
  throw new Error("Il consenso predefinito per le voci TTS online dovrebbe essere true.");
}
if (!onlineAllowed.engine.bestVoice || !onlineAllowed.engine.bestVoice.name.includes("Natural")) {
  throw new Error("Con consenso attivo dovrebbe preferire la voce neurale/online.");
}
if (!onlineAllowed.engine.fallbackLocalVoice || onlineAllowed.engine.fallbackLocalVoice.localService !== true) {
  throw new Error("La voce di riserva deve essere locale quando disponibile.");
}
onlineAllowed.engine.speakCurrentToken();
if (onlineAllowed.getSpeakCalls() !== 1) {
  throw new Error("La sintesi vocale con consenso attivo non ha pronunciato il token.");
}

// 2. Consenso disattivato (allowRemoteTtsVoices = false): esclude voci remote e non ricade sul default del browser
const remoteOnly = createEngine([
  { name: "Italian Online Neural", lang: "it-IT", localService: false },
  { name: "Italian Unknown", lang: "it-IT" },
]);
remoteOnly.engine.setAllowRemoteTtsVoices(false);
if (remoteOnly.engine.bestVoice !== null || remoteOnly.engine.localVoiceAvailable !== false) {
  throw new Error("Voci remote o non dichiarate locali accettate erroneamente.");
}
remoteOnly.engine.speakCurrentToken();
if (remoteOnly.getSpeakCalls() !== 0) {
  throw new Error("La sintesi vocale ha usato la voce predefinita senza garanzia locale.");
}

const mixed = createEngine([
  { name: "Italian Online Neural", lang: "it-IT", localService: false },
  { name: "Italian Local", lang: "it-IT", localService: true },
  { name: "Italian Local Secondary", lang: "it", localService: true },
]);
mixed.engine.setAllowRemoteTtsVoices(false);
if (!mixed.engine.bestVoice || mixed.engine.bestVoice.localService !== true) {
  throw new Error("La voce selezionata non è locale.");
}
if (!mixed.engine.fallbackLocalVoice || mixed.engine.fallbackLocalVoice.localService !== true) {
  throw new Error("La voce di riserva non è locale.");
}
mixed.engine.speakCurrentToken();
if (mixed.getSpeakCalls() !== 1) {
  throw new Error("La voce italiana locale non è stata utilizzata.");
}

console.log("PASS: consenso TTS online attivo seleziona le voci neurali migliori con fallback locale.");
console.log("PASS: con consenso disattivato le voci remote e non classificate locali vengono escluse.");
console.log("PASS: con consenso disattivato la sintesi vocale non ricade sulla voce predefinita del browser.");
console.log("PASS: voce primaria e voce di riserva locali verificate.");
