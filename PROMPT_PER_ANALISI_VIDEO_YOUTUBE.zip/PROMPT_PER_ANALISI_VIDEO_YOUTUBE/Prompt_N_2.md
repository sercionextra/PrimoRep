# PROMPT N. 2: Traduzione in Italiano con Allineamento Temporale

> **METADATI DEL WORKFLOW:**
> - **Input Richiesto:** `{{OUTPUT_PROMPT_1}}` (Trascrizione revisionata tecnicamente dal Prompt 1)
> - **Condizione di Esecuzione:** Condizionale. Esegui questo prompt SOLO se la lingua originale del video/trascrizione NON è l'italiano. Se il testo originale è già in italiano, ignora questo prompt e passa direttamente al Prompt 4 (o al Prompt 3).
> - **Variabile di Output Generata:** `{{OUTPUT_PROMPT_2}}`
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 2: Traduzione in Italiano`.

---

### DIRETTIVE OPERATIVE

Traducilo in italiano conservando in inglese i termini tecnici e gergali. 
Rispetta il più possibile, se presenti, gli orari, comunque non alterarne i valori, eventualmente sposta solo i pezzi di frasi nell'intorno di quell'orario, per rispettare al massimo le corrispondenze temporali delle pronunce delle singole frasi.

---

### INPUT DATI PER L'ELABORAZIONE

**TESTO DA TRADURRE:**
```text
{{OUTPUT_PROMPT_1}}
```

---

### ISTRUZIONI DI OUTPUT:
1. Mostra a schermo l'intera risposta tradotta.
2. Memorizza la risposta nella variabile `{{OUTPUT_PROMPT_2}}`.
3. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 2: Traduzione in Italiano`
