# Catalogo iniziale QWERTY italiano — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline esaminata:** `TenFingersTypingTrainer_v6.23(2).zip`  
**Layout obiettivo:** Italiano QWERTY, 105 tasti  
**Stato:** inventario verificato della baseline e seed parziale; catalogo completo non ancora certificabile  
**Ambito:** catalogo logico per le tipologie Home row, TASTO, CARATTERE e DITO.  
**Nessuna modifica ai sorgenti applicativi.**

---

## 1. Esito dell'audit

La baseline fornisce una base riutilizzabile, ma non contiene un catalogo completo e coerente di 105 tasti.

| Fonte | Quantità verificata | Significato |
|---|---:|---|
| `KEY_MAP` | 111 voci | Caratteri, alias e comandi risolti dal codice |
| ID fisici distinti in `KEY_MAP` | 52 | Tasti target associati a caratteri o comandi |
| ID `key_*` presenti nell'SVG tastiera | 62 | Elementi grafici identificati |
| `KEY_ID_TO_LANDMARK_KEY` | 62 | Associazioni tra ID SVG e chiave anatomica |
| `ANATOMICAL_KEY_COORDINATES` | 60 | Coordinate anatomiche calibrate |
| `FINGER_NAMES` | 10 | Dita numerate da 1 a 10 |

I 62 ID SVG non equivalgono a 62 tasti interrogabili in `KEY_MAP`: comprendono anche modificatori e tasti speciali. La baseline dichiara il layout obiettivo da 105 tasti, ma l'inventario effettivamente presente nei binding esaminati non consente di ricostruire e certificare i 105 tasti. I 43 elementi non documentati non vengono inventati né inseriti nel seed.

**Conclusione:** il presente documento chiude l'inventario delle entità verificabili e definisce la struttura del catalogo. Non dichiara completato il catalogo 105 tasti.

## 2. Fonti di baseline e criteri

Sono stati esaminati direttamente:

- `js/domain/keyboard-map.js` — `KEY_MAP`;
- `js/domain/finger-names.js` — `FINGER_NAMES`;
- `js/domain/anatomical-landmarks.js` — coordinate, lookup e `KEY_ID_TO_LANDMARK_KEY`;
- `js/domain/keyboard-helpers.js` — `getAnatomicalLandmark()` e `resolveTargetChord()`;
- `index.html` — identificativi e classi degli elementi SVG della tastiera.

Criteri applicati:

1. L'identità di un tasto fisico è distinta dall'identità del carattere prodotto.
2. Maiuscole, simboli e caratteri ottenuti con modificatori sono identità CARATTERE distinte, anche quando condividono il medesimo tasto fisico.
3. Alias di input che rappresentano lo stesso comando fisico (ad esempio Invio e newline) non diventano automaticamente tasti fisici diversi.
4. Le assegnazioni dita riportate sono quelle della baseline; non vengono corrette implicitamente.
5. L'assenza di una relazione o di una coordinata è registrata come lacuna, non colmata per supposizione.

## 3. Identità e struttura logica

### 3.1 Tasto fisico

Identità proposta e stabile: `key.<id-svg>`, ad esempio `key.key_a`.

Attributi minimi:

- `semanticId` e `recordId`;
- `layoutId = it-qwerty-105`;
- `keyId` corrispondente all'ID fisico/SVG;
- riga o gruppo funzionale;
- dito assegnato, quando presente e verificato;
- stato `active`, `retired` o `draft`;
- versione del contenuto.

La denominazione `it-qwerty-105` identifica il layout obiettivo, non certifica che tutti i suoi 105 tasti siano già catalogati.

### 3.2 Carattere

Identità proposta: `char.<codepoint-esadecimale>`. Esempi: `char.61` per `a`, `char.41` per `A`, `char.20ac` per `€`.

Attributi minimi:

- valore Unicode esatto;
- nome visualizzato;
- `physicalKeySemanticId`;
- dito di riferimento derivato dalla mappa e verificabile;
- modificatore richiesto (`none`, `shiftL`, `shiftR`, `altgr`, `shiftAltgr`);
- definizione del gesto/accordo di digitazione;
- stato e versione.

I caratteri di controllo o gli alias (`Backspace`, newline, tabulazione) devono essere classificati separatamente dai caratteri stampabili. La distinzione evita che un alias di input venga scambiato per un carattere tipografico.

### 3.3 Dito

Identità proposta: `finger.1` … `finger.10`. I nomi sono quelli presenti in `FINGER_NAMES` e sono riportati nella sezione 5.

Il dito è un'entità didattica autonoma. Le relazioni con tasti, caratteri e landmark non devono essere duplicate come identità statistiche.

### 3.4 Sotto-quesiti

L'identità del sotto-quesito è distinta dall'identità dell'elemento. Il catalogo può collegare più aspetti interrogabili allo stesso elemento, senza fondere i relativi storici.

Aspetti iniziali ammessi dalla specifica:

- Home row: mano completa o singolo dito; valutazione indipendente dei quattro dita operativi della mano;
- TASTO: riconoscimento del tasto fisico;
- CARATTERE: riconoscimento del carattere e delle relazioni con tasto, dito e modificatori;
- DITO: riconoscimento del dito competente e delle caratteristiche di movimento/estensione.

La formulazione concreta, il tipo di risposta e la policy di valutazione di ogni sotto-quesito saranno definiti nella specifica dei contenuti didattici. Non si generano domande prive di risposta univoca verificata.

## 4. Inventario dei tasti fisici verificati

La tabella riporta i 52 ID fisici distinti presenti in `KEY_MAP`, raggruppati per riga funzionale. Le etichette non sono una nuova mappatura: sono ricavate dalle chiavi e dai nomi presenti nel sorgente.

| Gruppo | ID fisico | Dito baseline | Osservazioni |
|---|---|---:|---|
| Riga numerica | `key_backslash` | 1 | `\\` e `\|` |
| Riga numerica | `key_1` | 1 | `1`, `!` |
| Riga numerica | `key_2` | 1 | `2`, `"` |
| Riga numerica | `key_3` | 2 | `3`, `£` |
| Riga numerica | `key_4` | 3 | `4`, `$` |
| Riga numerica | `key_5` | 4 | `5`, `%` |
| Riga numerica | `key_6` | 4 | `6`, `&` |
| Riga numerica | `key_7` | 7 | `7`, `/` |
| Riga numerica | `key_8` | 7 | `8`, `(` |
| Riga numerica | `key_9` | 8 | `9`, `)` |
| Riga numerica | `key_0` | 9 | `0`, `=` |
| Riga numerica | `key_quote` | 10 | Apostrofo e varianti |
| Riga numerica | `key_igrave` | 10 | `ì`, `^`, `~` |
| Riga superiore | `key_q` | 1 | `q`, `Q` |
| Riga superiore | `key_w` | 2 | `w`, `W` |
| Riga superiore | `key_e` | 3 | `e`, `E`, `€` |
| Riga superiore | `key_r` | 4 | `r`, `R` |
| Riga superiore | `key_t` | 4 | `t`, `T` |
| Riga superiore | `key_y` | 7 | `y`, `Y` |
| Riga superiore | `key_u` | 7 | `u`, `U` |
| Riga superiore | `key_i` | 8 | `i`, `I` |
| Riga superiore | `key_o` | 9 | `o`, `O` |
| Riga superiore | `key_p` | 10 | `p`, `P` |
| Riga superiore | `key_egrave` | 10 | `è`, `é`, parentesi quadre/graffe |
| Riga superiore | `key_plus` | 10 | `+`, `*`, parentesi quadre/graffe |
| Home row | `key_a` | 1 | `a`, `A` |
| Home row | `key_s` | 2 | `s`, `S` |
| Home row | `key_d` | 3 | `d`, `D` |
| Home row | `key_f` | 4 | `f`, `F` |
| Home row | `key_g` | 4 | `g`, `G` |
| Home row | `key_h` | 7 | `h`, `H` |
| Home row | `key_j` | 7 | `j`, `J` |
| Home row | `key_k` | 8 | `k`, `K` |
| Home row | `key_l` | 9 | `l`, `L` |
| Home row | `key_ograve` | 10 | `ò`, `ç`, `@` |
| Home row | `key_agrave` | 10 | `à`, `°`, `#` |
| Home row | `key_ugrave` | 10 | `ù`, `§` |
| Riga inferiore | `key_less` | 1 | `<`, `>` |
| Riga inferiore | `key_z` | 1 | `z`, `Z` |
| Riga inferiore | `key_x` | 2 | `x`, `X` |
| Riga inferiore | `key_c` | 3 | `c`, `C` |
| Riga inferiore | `key_v` | 4 | `v`, `V` |
| Riga inferiore | `key_b` | 4 | `b`, `B` |
| Riga inferiore | `key_n` | 7 | `n`, `N` |
| Riga inferiore | `key_m` | 7 | `m`, `M` |
| Riga inferiore | `key_comma` | 8 | `,`, `;` |
| Riga inferiore | `key_period` | 9 | `.`, `:` |
| Riga inferiore | `key_minus` | 10 | `-`, `_` |
| Riga spazio | `key_space` | 5 | Spazio; la mappa assegna il pollice sinistro |
| Speciale | `key_tab` | 1 | Tabulazione; alias `→` e `\t` |
| Speciale | `key_enter` | 10 | Invio; alias `®` e newline |
| Speciale | `key_backspace` | 10 | Backspace |

Nota: la tabella comprende i 52 ID univoci, non 52 elementi aggiuntivi rispetto ai tasti speciali. Il campo `finger` viene mantenuto come dato baseline; non è una raccomandazione ergonomica indipendente.

## 5. Dita

| ID | Nome baseline | Mano |
|---:|---|---|
| 1 | Mignolo Sinistro | Sinistra |
| 2 | Anulare Sinistro | Sinistra |
| 3 | Medio Sinistro | Sinistra |
| 4 | Indice Sinistro | Sinistra |
| 5 | Pollice Sinistro | Sinistra |
| 6 | Pollice Destro | Destra |
| 7 | Indice Destro | Destra |
| 8 | Medio Destro | Destra |
| 9 | Anulare Destro | Destra |
| 10 | Mignolo Destro | Destra |

Per Home row, la modalità mano completa deve produrre sotto-quesiti indipendenti per i quattro dita operativi della mano. Il pollice non viene aggiunto automaticamente alla valutazione Home row.

## 6. Home row: perimetro derivato dalla baseline

I tasti assegnati nella baseline al gruppo centrale sono:

| Mano | Dito | Tasto/i |
|---|---|---|
| Sinistra | Mignolo (1) | `A` |
| Sinistra | Anulare (2) | `S` |
| Sinistra | Medio (3) | `D` |
| Sinistra | Indice (4) | `F`, `G` |
| Destra | Indice (7) | `H`, `J` |
| Destra | Medio (8) | `K` |
| Destra | Anulare (9) | `L` |
| Destra | Mignolo (10) | `Ò`, `À`, `Ù` |

Questa suddivisione segue i valori `finger` in `KEY_MAP`. La presenza di tre tasti assegnati al mignolo destro e l'inclusione delle lettere accentate devono essere confermate nella definizione didattica finale di Home row: la baseline li colloca nella riga centrale, ma la specifica funzionale non elenca esplicitamente i singoli tasti.

## 7. Caratteri e combinazioni

`KEY_MAP` contiene 111 voci e costituisce la fonte iniziale per la relazione carattere → tasto fisico/dito/modificatore.

La mappatura include almeno queste famiglie:

- lettere minuscole e maiuscole;
- cifre e simboli ottenuti con Shift;
- lettere accentate italiane;
- simboli ottenuti con AltGr e Shift+AltGr;
- punteggiatura;
- spazio e comandi speciali (Invio, Tab, Backspace).

Il seed JSON allegato contiene tutte le 111 voci estratte, senza ricostruzioni manuali. Ogni voce carattere punta a un'identità tasto fisico distinta. L'identità statistica CARATTERE resta autonoma da quella TASTO: conoscere `A` non consolida automaticamente il tasto fisico `A` né il dito 1.

`resolveTargetChord(char)` è riutilizzabile come risolutore della combinazione, ma non deve diventare la fonte persistente del catalogo. La sua logica resta una funzione di dominio; il catalogo memorizza definizioni e relazioni versionate. Prima dell'integrazione andranno testati i casi AltGr, Shift+AltGr, CapsLock e le differenze tra modificatori logici e tasti fisici.

## 8. SVG e landmark

L'SVG della tastiera in `index.html` contiene 62 ID `key_*`. La mappa `KEY_ID_TO_LANDMARK_KEY` contiene 62 associazioni e tutte le chiavi mappate trovano una coordinata nel dataset da 60 record tramite il valore di landmark associato. Questo conteggio non significa che esistano 62 coordinate distinte: più ID possono convergere sulla stessa chiave anatomica.

Il seed JSON allegato riporta gli ID SVG e i 60 record di coordinate rilevati.

### 8.1 Incongruenza confermata sui modificatori destri

Per `key_win_r`, `key_menu` e `key_ctrl_r`:

- l'SVG assegna la classe `finger-10`;
- `KEY_ID_TO_LANDMARK_KEY` li associa a `CTRL-dx`;
- il record anatomico `CTRL-dx` è associato al dito 6;
- `getAnatomicalLandmark()` cerca il landmark usando il dito passato dal chiamante.

Se il chiamante passa il dito 10 ricavato dalla classe SVG, la ricerca del landmark associato al dito 6 non trova corrispondenza. È un'incongruenza reale tra SVG, mapping e coordinate. **Non viene corretta in questo deliverable**, perché la correzione richiede una decisione coerente sul dito competente e sul gesto didattico dei tre tasti.

### 8.2 Limite del requisito di selezione a 3 pixel

La baseline contiene coordinate anatomiche, ma l'audit non ha identificato una regola completa e verificata per selezionare un landmark con tolleranza di 3 pixel in coordinate SVG. Il requisito va implementato e collaudato considerando viewBox, trasformazioni, scala CSS e coordinate del puntatore; non va applicato direttamente alle coordinate schermo senza trasformazione.

## 9. Relazioni di catalogo da materializzare

Relazioni minime previste:

- `producedBy`: carattere → tasto fisico;
- `assignedToFinger`: tasto/carattere → dito, con provenienza e versione;
- `belongsToHand`: dito → mano;
- `locatedOnRow`: tasto → riga/gruppo;
- `renderedBySvgKey`: tasto fisico → ID SVG;
- `hasLandmark`: tasto/dito → riferimento anatomico;
- `requiresModifier`: carattere → modificatore logico/fisico;
- `hasQuestionDefinition`: elemento → sotto-quesito;
- `replacedBy`: vecchia identità → nuova identità, solo per sostituzioni semantiche esplicite.

Le relazioni devono essere versionate e auditabili. Una correzione della mappatura non deve riscrivere lo storico delle esposizioni. Se cambia soltanto una definizione didattica, si incrementa la versione contenuto; se cambia il significato dell'elemento, si crea una nuova identità semantica secondo le regole già consolidate.

## 10. Lacune da chiudere prima del seed completo

1. **Inventario 105 tasti:** confrontare il layout dichiarato con una fonte grafica/strutturale completa; individuare e identificare i 43 tasti non rappresentati nell'inventario attuale. Non assumere che siano tutti tasti del tastierino numerico.
2. **Modificatori e tasti funzione:** decidere quali siano interrogabili come TASTO, quali siano soltanto componenti di accordo e quali siano esclusi dalla prima release.
3. **Home row:** confermare l'inclusione dei tasti accentati `ò`, `à`, `ù` e la definizione esatta dei gruppi per mano.
4. **Modificatori destri:** risolvere la discordanza `finger-10` / `CTRL-dx` / dito 6 per Win destro, Menu e Ctrl destro.
5. **AltGr:** verificare la corrispondenza tra tasto fisico AltGr nel disegno, uso di Ctrl+Alt e regole di `resolveTargetChord()` nei browser e sistemi operativi supportati.
6. **Landmark:** verificare coordinate, punti selezionabili e tolleranza di 3 pixel nel sistema di coordinate corretto.
7. **Rosa tasti circostanti:** definire formalmente adiacenza, bordo, righe sfalsate e tasti non alfabetici prima di produrre domande su tasti circostanti.
8. **Definizioni didattiche:** completare per ogni sotto-quesito risposta attesa, modalità di presentazione, policy di valutazione e immagine di soluzione.

## 11. Criteri di accettazione del catalogo completo

Il catalogo sarà dichiarato completo soltanto quando:

- contiene esattamente 105 identità fisiche attive per il layout approvato, oppure una diversa cardinalità formalmente motivata;
- ogni identità fisica ha una posizione univoca e una rappresentazione verificata;
- le identità CARATTERE sono distinte da quelle TASTO;
- ogni carattere supportato ha una combinazione di tasto/modificatore risolvibile e testata;
- ogni assegnazione dito è coerente con la fonte approvata e con SVG/landmark;
- le dieci dita hanno definizioni e relazioni coerenti;
- i quattro tipi di interrogazione dispongono di sotto-quesiti con risposte verificabili;
- nessuna domanda mostra anticipatamente la risposta;
- tutte le relazioni hanno versionamento e integrità referenziale;
- ogni elemento dismesso resta nello storico e non viene proposto in nuove sessioni;
- i test automatici verificano conteggi, unicità, mapping, modificatori, landmark e casi limite.

## 12. Artefatti prodotti

- `Catalogo_QWERTY_Italiano_v1.0.md`: audit, inventario verificato, regole e lacune.
- `Catalogo_QWERTY_Italiano_seed_v1.0.json`: seed machine-readable derivato direttamente dalla baseline, con 52 tasti fisici, 111 mapping carattere/input, 62 ID SVG, 60 coordinate anatomiche e 10 dita.

Il JSON è un seed parziale di analisi, non è pronto per essere importato in IndexedDB e non deve essere caricato in produzione senza completamento e validazione del catalogo 105 tasti.
