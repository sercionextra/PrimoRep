# Architettura TenFingersTypingTrainer v6.50

Documento di aggiornamento architetturale rispetto alla v6.49.

## 1. Obiettivo della Release v6.50
Correggere due incongruenze nei metadati di estensione e nei controlli di risposta dell'Interrogazione per i quesiti **Carattere / Tasto** (`CARATTERE`, `TASTO`):
1. **`key_backslash` (`\` / `|`):** `lateralExt` corretto da `1` a `2` (`lateralDir: "sn"`, `longitudinalExt: 2`) in `KEY_EXTENSIONS` (`js/interrogation/interrogation-layout-metadata.js`), poiché il tasto si trova due colonne a sinistra rispetto al mignolo sinistro (`key_a`).
2. **Dropdown `Estensione longitudinale` (`selLongExt` in `js/ui/interrogation-ui.js`):** aggiunta l'opzione `{ v: "-2", l: "-2 (2 righe sotto riposo)" }`, indispensabile per i tasti della riga inferiore (`key_space`, `key_ctrl_l`, `key_win_l`, `key_alt_l`, `key_altgr`, `key_win_r`, `key_menu`, `key_ctrl_r`).
