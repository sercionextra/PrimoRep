# Motore di Sessione INTERROGAZIONE — v1.0

**Stato:** specifica esecutiva progettuale  
**Ambito:** ciclo di vita della sessione, avanzamento, valutazione, sospensione, ripresa, abbandono e completamento.  
**Dipendenze:** Contratti Backend INTERROGAZIONE v1.1; Schema IndexedDB INTERROGAZIONE v1.1; Motore di Selezione v1.0; Motore della Conoscenza v1.0; Catalogo Domande v1.0; Specifica Tecnica INTERROGAZIONE v1.0.

## 1. Obiettivo e vincoli

Il Session Manager orchestra una sessione senza incorporare le regole di calcolo della conoscenza o di selezione. Coordina catalogo, selettore, repository e motore della conoscenza attraverso contratti asincroni e transazioni IndexedDB.

Vincoli non negoziabili:

- JavaScript classico, coerente con la baseline; nessuna conversione a moduli ES o TypeScript.
- Una sessione conserva gli snapshot con cui è stata creata. Modifiche successive a configurazione, catalogo, algoritmo o conoscenza non la ricalcolano.
- La valutazione è registrata soltanto dopo conferma esplicita.
- Le valutazioni confermate sono immutabili; rettifiche passano dal sistema append-only di correzioni.
- Un sotto-quesito non valutato non produce punti, errore, esposizione o aggiornamento della conoscenza.
- Tutte le modifiche persistenti correlate a un esito sono atomiche.
- Tutte le operazioni sono isolate per `profileId` e protette da `operationId` e controllo di versione.

## 2. Responsabilità e confini

### 2.1 Responsabilità del Session Manager

1. Validare la richiesta di creazione e acquisire snapshot coerenti.
2. Richiedere la selezione al motore dedicato.
3. Preparare e persistere domande principali e sotto-quesiti con definizioni congelate.
4. Governare lo stato della sessione e il punto esatto di avanzamento.
5. Registrare gli esiti confermati e il punteggio.
6. Gestire conclusione parziale della domanda principale.
7. Sospendere e riprendere senza ricostruire la selezione.
8. Abbandonare solo dopo conferma, conservando gli esiti.
9. Formalizzare il completamento solo dopo conferma esplicita.
10. Produrre un riepilogo ricostruibile dai record persistiti.

### 2.2 Responsabilità esterne

- `InterrogationSelector`: selezione e quote; il Session Manager non reimplementa l'algoritmo.
- `InterrogationKnowledge`: proiezioni di conoscenza, affidabilità, classificazioni e calendario.
- `InterrogationCatalog`: disponibilità e definizioni attive al momento della creazione.
- `InterrogationRepository`: transazioni, idempotenza, persistenza e recovery.
- UI: raccolta input, richiesta conferme, visualizzazione; non decide esiti né modifica direttamente i record.

## 3. Stati e transizioni

### 3.1 Stato della sessione

Valori ammessi:

- `in-progress`: sessione attiva e modificabile.
- `suspended`: sessione sospesa, riprendibile senza nuova selezione.
- `abandoned`: sessione abbandonata con risultati conservati; terminale.
- `completed`: sessione formalmente completata; terminale.

Transizioni ammesse:

| Stato corrente | Operazione | Stato successivo | Condizioni |
|---|---|---|---|
| — | `createSession` | `in-progress` | Selezione e snapshot validi; conferma utente se la disponibilità riduce il numero richiesto |
| `in-progress` | `suspendSession` | `suspended` | Persistenza atomica del punto esatto |
| `suspended` | `resumeSession` | `in-progress` | Nessuna sessione attiva concorrente per lo stesso profilo |
| `in-progress` | `abandonSession` | `abandoned` | Conferma esplicita |
| `suspended` | `abandonSession` | `abandoned` | Conferma esplicita |
| `in-progress` | `completeSession` | `completed` | Tutte le domande gestite e conferma esplicita del riepilogo |

Non sono ammesse transizioni da `abandoned` o `completed`. La ripresa non crea una nuova sessione e non richiama il selettore.

### 3.2 Stato del sotto-quesito

Valori ammessi:

- `pending`: nessun esito registrato.
- `answered`: valutazione esplicita registrata; `outcome` è `correct` oppure `incorrect`.
- `consulted`: soluzione richiesta e consultazione registrata.
- `unanswered`: sotto-quesito chiuso senza risposta nell'ambito della conclusione esplicita della domanda principale.

Vincoli:

- `pending` non ha `outcome`, `evaluatedAt` o punti.
- `answered` ha un solo `outcome` tra `correct` e `incorrect`.
- `consulted` ha `outcome: consulted` e punteggio +1.
- `unanswered` non ha evento di esposizione, non ha `outcome` didattico e vale zero punti.
- Una transizione da stato finale a un altro stato finale è vietata attraverso il normale flusso UI.

### 3.3 Stato della domanda principale

È derivato dai sotto-quesiti e dal marcatore di chiusura esplicita:

- `open`: esiste almeno un sotto-quesito `pending` e la domanda non è stata chiusa.
- `closed`: tutti i sotto-quesiti sono in stato finale, oppure l'utente ha confermato di concludere lasciando i rimanenti `unanswered`.

Il riepilogo indica sempre quanti sotto-quesiti sono gestiti sul totale, ad esempio `4/6`. La domanda chiusa non viene riaperta durante la stessa sessione.

## 4. Modello dati operativo

I campi si aggiungono ai record definiti nei contratti backend; non li sostituiscono.

### 4.1 Sessione

Campi minimi:

```js
{
  profileId,
  sessionId,
  status: "in-progress",
  mode: "adaptive", // adaptive | random | manual
  questionType,
  requestedQuestionCount,
  effectiveQuestionCount,
  configSnapshot,
  selectionSnapshot,
  catalogVersion,
  algorithmVersion,
  knowledgeAlgorithmVersion,
  currentItemIndex,
  currentSubQuestionId,
  score,
  revision,
  createdAt,
  updatedAt,
  suspendedAt: null,
  abandonedAt: null,
  completedAt: null
}
```

`currentItemIndex` individua la domanda principale corrente. `currentSubQuestionId` identifica il punto preciso di ripresa, se la domanda è ancora aperta. Gli identificativi e i nomi delle versioni sono quelli dello schema fisico e dei contratti approvati; nessun campo deve essere dedotto dalla UI.

### 4.2 Item di sessione

Ogni item conserva `order`, `itemId`, `mainElementSemanticId`, `promptSnapshot` e i sotto-quesiti con `definitionSnapshot`. Lo snapshot contiene tutti i dati necessari a rendere la domanda anche se il catalogo corrente viene aggiornato o l'elemento dismesso.

Ogni sotto-quesito conserva almeno:

- `questionSemanticId` ed `elementSemanticId`;
- `definitionSnapshot`;
- `status`;
- `outcome` solo quando applicabile;
- `score`;
- `evaluatedAt`;
- `eventId` quando è stato generato un evento;
- `revision` o token di concorrenza equivalente.

### 4.3 Riepilogo

Il riepilogo non è fonte autonoma di verità: viene calcolato dai record della sessione. Può essere memorizzato come cache, purché ricostruibile e aggiornato nella stessa transazione delle modifiche che lo influenzano.

## 5. Creazione della sessione

`createSession(profileId, request, operationId)` segue questa sequenza logica:

1. Verificare profilo esistente e autorizzato.
2. Verificare che non vi sia una sessione `suspended` non gestita. Se esiste una sospesa, l'utente deve riprenderla o abbandonarla prima di iniziarne un'altra. Non viene introdotto un blocco generale basato sulla sola presenza di altre sessioni `in-progress`, perché non è previsto dalla specifica funzionale.
3. Validare modalità, tipologia, numero richiesto, categorie e opzioni manuali.
4. Acquisire una fotografia coerente della configurazione del profilo, del catalogo attivo, delle definizioni e, solo per la modalità adattiva, dello stato conoscenza.
5. Chiamare `buildSelection()` con gli snapshot e il seed deterministico previsto dal contratto del selettore.
6. Calcolare il numero effettivo di domande. Se gli elementi distinti sono meno del richiesto, preparare una proposta ridotta e attendere la scelta dell'utente: procedere o annullare. Non persistere una sessione avviata prima della conferma.
7. Preparare tutti gli item e i sotto-quesiti, congelando le definizioni necessarie alla presentazione e alla valutazione.
8. Persistire sessione, item, snapshot, ricevuta idempotente e vincolo di unicità della sessione attiva in una transazione atomica.
9. Restituire sessione e primo item.

Se il flusso viene annullato prima del commit, non esiste una sessione parziale e non viene scritto alcun evento di conoscenza.

### 5.1 Modalità

- `adaptive`: usa la selezione adattiva e congela classificazioni, quote, priorità, snapshot di conoscenza e versioni.
- `random`: non legge statistiche o priorità per decidere gli elementi; conserva comunque gli esiti per le sessioni adattive future.
- `manual`: conserva l'ordine scelto dall'utente; duplicati vietati per default e consentiti soltanto se esplicitamente abilitati nella sessione manuale corrente. L'opzione non modifica la configurazione adattiva del profilo.

## 6. Gestione dell'input e valutazione

### 6.1 Input prima della conferma

La UI può raccogliere una risposta provvisoria. L'utente può correggere l'input fisico o cambiare la selezione grafica prima della conferma. Il valore provvisorio non aggiorna sessione, punteggio, storico o conoscenza.

La valutazione avviene soltanto su conferma esplicita. Il confronto con la risposta attesa usa `definitionSnapshot` e `evaluationPolicy` congelati, non la definizione live del catalogo.

### 6.2 Risposta confermata

`recordOutcome()` deve validare profilo, sessione, item, sotto-quesito, stato `pending`, snapshot e `operationId`. In un'unica transazione:

1. verifica idempotenza e revisione;
2. determina `correct` o `incorrect` secondo la policy congelata;
3. inserisce l'evento append-only;
4. aggiorna il sotto-quesito a `answered`;
5. assegna +3 per `correct`, 0 per `incorrect`;
6. aggiorna punteggio e avanzamento;
7. aggiorna la proiezione conoscenza e calendario secondo il contratto del motore;
8. registra la receipt;
9. esegue commit.

Se uno qualsiasi dei passaggi fallisce, non deve risultare né l'evento né la modifica del sotto-quesito né il punteggio aggiornato.

### 6.3 Consultazione

Il comando `?` è un'azione esplicita, non una visualizzazione passiva. Mostra soluzione e immagine, registra `consulted`, assegna +1 e crea un evento di esposizione. La consultazione è definitiva per quel sotto-quesito nella sessione corrente; gli altri sotto-quesiti restano affrontabili.

La semplice visualizzazione iniziale della domanda, dell'immagine o della tastiera grafica non genera esposizione e non modifica conoscenza.

### 6.4 Non risposta e chiusura anticipata

L'utente può chiedere di concludere la domanda principale lasciando sotto-quesiti incompleti. Dopo conferma:

- i sotto-quesiti `pending` diventano `unanswered`;
- non vengono creati eventi di esposizione;
- non vengono assegnati punti né errori;
- la domanda principale passa a `closed`;
- l'avanzamento passa alla domanda successiva, se presente.

La chiusura anticipata non deve essere confusa con l'abbandono dell'intera sessione.

## 7. Avanzamento e navigazione

- I sotto-quesiti di una domanda principale possono essere affrontati in qualsiasi ordine.
- Il passaggio al successivo sotto-quesito non deve saltare o duplicare valutazioni già confermate.
- La domanda principale si chiude quando tutti i sotto-quesiti sono gestiti oppure dopo conferma esplicita di chiusura con incompleti.
- Dopo la chiusura della domanda principale, l'utente usa `Prosegui` per passare all'item successivo.
- Non è consentito modificare una valutazione già registrata tornando indietro. La navigazione può mostrare l'esito, non riaprire il sotto-quesito.
- Il completamento di tutti gli item apre il riepilogo finale; non marca automaticamente la sessione `completed`.

L'ordinamento visuale dei sotto-quesiti può cambiare durante la domanda, ma gli identificativi e gli stati persistiti restano stabili.

## 8. Sospensione e ripresa

### 8.1 Sospensione

`suspendSession(profileId, sessionId, operationId)` è ammessa soltanto per una sessione `in-progress`. La transazione salva:

- stato `suspended` e timestamp;
- item corrente e sotto-quesito corrente;
- tutti gli stati e gli esiti già confermati;
- punteggio;
- snapshot originali e revisioni.

Gli input non confermati non sono valutazioni e non devono essere recuperati come esiti. Possono essere scartati. Nessun sotto-quesito `pending` diventa `unanswered` per effetto della sospensione.

### 8.2 Ripresa

`resumeSession(profileId, operationId)` individua l'unica sessione `suspended` del profilo e la riporta a `in-progress` in modo atomico. Ripristina esattamente l'item e il sotto-quesito correnti. Non richiama catalogo, selettore o motore conoscenza per ricalcolare la sessione.

Se catalogo, configurazione, statistiche o algoritmo sono cambiati dopo la sospensione, la sessione mantiene i propri snapshot. Gli elementi dismessi restano visualizzabili nella sessione già avviata.

## 9. Abbandono

`abandonSession(profileId, sessionId, confirmation, operationId)` richiede un valore di conferma esplicito e verificabile. Senza conferma non modifica alcun dato.

Prima di confermare, la UI mostra almeno:

- domande principali completate;
- sotto-quesiti corretti, errati e consultati;
- sotto-quesiti incompleti;
- punteggio già acquisito.

Confermata l'operazione, la transazione marca la sessione `abandoned`, registra timestamp e conserva integralmente tutti gli eventi, gli esiti e il punteggio già acquisiti. Gli incompleti restano senza punti e senza errori; non si generano esposizioni retroattive.

Una sessione abbandonata è terminale e non riprendibile. I suoi eventi restano nello storico e concorrono alle statistiche secondo le regole del motore conoscenza.

## 10. Completamento

Il completamento è consentito soltanto quando tutti gli item sono chiusi e non esistono sotto-quesiti `pending`. Il riepilogo viene presentato all'utente e richiede conferma esplicita.

- Se l'utente conferma, `completeSession()` marca `completed`, salva `completedAt` e chiude la sessione in transazione.
- Se l'utente non conferma o chiude il riepilogo, la sessione resta persistita ma non è formalmente completata. Rimane `in-progress` fino a completamento o sospensione/abbandono.
- Un riepilogo già mostrato non equivale a conferma.
- Un secondo invio idempotente con stesso `operationId` e stesso payload restituisce il risultato già registrato.
- Un tentativo di completare con item aperti o sotto-quesiti `pending` è rifiutato senza modifiche.

## 11. Punteggio e riepiloghi

Punteggio per sotto-quesito:

| Stato/esito | Punti |
|---|---:|
| `answered` / `correct` | +3 |
| `consulted` | +1 |
| `answered` / `incorrect` | 0 |
| `unanswered` | 0 |
| `pending` | 0 |

Punteggio domanda principale = somma dei punteggi dei suoi sotto-quesiti. Punteggio sessione = somma dei punteggi di tutte le domande. Il punteggio non sostituisce affidabilità, classificazione o metriche di conoscenza.

Il riepilogo deve distinguere almeno corretti, errati, consultati, non risposti e ancora pendenti; questi conteggi non devono essere accorpati in una generica categoria “sbagliati”.

## 12. Atomicità, idempotenza e concorrenza

Ogni comando che modifica stato riceve `operationId`. Regole:

- stesso scope, `operationId` e payload: restituire il risultato già registrato;
- stesso scope e `operationId` con payload differente: errore di conflitto;
- nuovo `operationId`: nuova operazione, sottoposta a validazione di stato e revisione;
- valutazione ripetuta sullo stesso sotto-quesito: rifiutata, anche con un nuovo `operationId`;
- operazione concorrente su revisione superata: conflitto, nessun commit;
- modifiche su profili diversi: indipendenti;
- due schede che tentano di creare/riprendere una sessione dello stesso profilo: una sola può acquisire la transizione; l'altra riceve conflitto/stato aggiornato.

Le transazioni IndexedDB devono includere tutti gli store necessari a mantenere coerenti sessione, item, eventi, knowledge state e receipt. La regola “una sola sessione sospesa per profilo” deve essere verificata atomicamente; non va estesa automaticamente a tutte le sessioni attive. Non effettuare attese di rete o callback UI dentro una transazione IndexedDB.

## 13. Recovery

All'avvio del modulo:

1. individuare sessioni `in-progress` e `suspended` per il profilo;
2. verificare coerenza tra sessione, item, sotto-quesiti ed eventi;
3. riconciliare soltanto proiezioni/cache ricostruibili, mai inventare valutazioni;
4. rilevare eventuali receipt e operazioni già committate;
5. non trasformare automaticamente `in-progress` in `completed`;
6. se lo stato persistito è incoerente e non ricostruibile senza perdita, bloccare le operazioni sulla sessione e produrre un errore diagnostico, preservando i dati originali.

Un crash prima del commit lascia invariato lo stato precedente; un crash dopo il commit deve essere riconoscibile tramite receipt e stato persistito.

## 14. Contratti logici proposti

Le firme sono indicative e devono rispettare lo stile JavaScript classico della baseline:

```js
createSession(profileId, request, operationId)
getActiveSession(profileId)
getSuspendedSession(profileId)
getSessionSnapshot(profileId, sessionId)
recordOutcome(profileId, sessionId, itemId, questionSemanticId, response, operationId, expectedRevision)
consultSubQuestion(profileId, sessionId, itemId, questionSemanticId, operationId, expectedRevision)
closeMainQuestion(profileId, sessionId, itemId, confirmation, operationId, expectedRevision)
advanceSession(profileId, sessionId, operationId, expectedRevision)
suspendSession(profileId, sessionId, operationId, expectedRevision)
resumeSession(profileId, operationId, expectedRevision)
getAbandonmentSummary(profileId, sessionId)
abandonSession(profileId, sessionId, confirmation, operationId, expectedRevision)
getCompletionSummary(profileId, sessionId)
completeSession(profileId, sessionId, confirmation, operationId, expectedRevision)
```

Questi sono contratti di dominio, non implementazioni già presenti. I nomi definitivi e la suddivisione in file saranno stabiliti nell'integrazione dopo il controllo completo delle dipendenze della baseline.

## 15. Errori applicativi minimi

| Codice logico | Condizione |
|---|---|
| `PROFILE_NOT_FOUND` | Profilo inesistente |
| `SESSION_NOT_FOUND` | Sessione non trovata nel profilo |
| `SESSION_ALREADY_ACTIVE` | Esiste già una sessione attiva incompatibile |
| `SUSPENDED_SESSION_EXISTS` | Si tenta una nuova sessione senza gestire quella sospesa |
| `INVALID_SESSION_STATE` | Operazione non ammessa nello stato corrente |
| `SUBQUESTION_ALREADY_EVALUATED` | Sotto-quesito già valutato |
| `SUBQUESTION_NOT_PENDING` | Il sotto-quesito non è valutabile |
| `SESSION_NOT_READY_TO_COMPLETE` | Esistono item o sotto-quesiti aperti |
| `CONFIRMATION_REQUIRED` | Conferma esplicita assente |
| `IDEMPOTENCY_CONFLICT` | Stesso operationId con payload differente |
| `REVISION_CONFLICT` | Versione/revisione superata |
| `SESSION_DATA_INCONSISTENT` | Relazioni o stati persistiti incoerenti |
| `SELECTION_CAPACITY_REQUIRES_CONFIRMATION` | Disponibilità inferiore alla richiesta |

Gli errori non devono produrre scritture parziali.

## 16. Test di accettazione

### 16.1 Creazione e snapshot

1. Creazione standard con 10 domande e snapshot completo.
2. Numero disponibile inferiore al richiesto: proposta ridotta e nessun commit prima della conferma.
3. Annullamento della proposta ridotta: nessuna sessione o evento persistito.
4. Impossibilità di creare una nuova sessione quando ne esiste una sospesa.
5. Modalità casuale non legge statistiche o priorità.
6. Modalità manuale conserva ordine e configurazione adattiva del profilo.
7. Duplicati manuali rifiutati per default e ammessi solo con opzione esplicita della sessione.
8. Modifica successiva del catalogo/configurazione/conoscenza non cambia gli snapshot della sessione.

### 16.2 Valutazione e punteggio

9. Input modificabile prima della conferma senza scritture.
10. Conferma corretta: evento, stato e +3 persistiti atomicamente.
11. Conferma errata: evento, stato e 0 punti persistiti atomicamente.
12. Consultazione: evento, stato e +1; gli altri sotto-quesiti restano pendenti.
13. Visualizzazione semplice: nessun evento e nessun aggiornamento conoscenza.
14. Chiusura anticipata: pending diventano unanswered, senza evento né errore.
15. Seconda valutazione dello stesso sotto-quesito rifiutata.
16. Errore simulato prima del commit: nessuna modifica parziale.
17. Stesso operationId/payload: risultato precedente restituito senza duplicati.
18. Stesso operationId/payload differente: conflitto.

### 16.3 Avanzamento e sessione composta

19. Sotto-quesiti affrontabili in qualsiasi ordine.
20. La domanda si chiude solo quando tutti sono gestiti o dopo conferma di chiusura anticipata.
21. Il riepilogo della domanda mostra conteggio gestiti/totali.
22. Prosegui porta all'item successivo senza duplicare eventi.
23. La sessione non diventa completed automaticamente all'ultimo esito.

### 16.4 Sospensione, abbandono e completamento

24. Sospensione conserva item e sotto-quesito correnti.
25. Sospensione non trasforma pending in unanswered.
26. Ripresa ripristina lo snapshot originario senza richiamare selettore.
27. Modifiche catalogo durante la sospensione non alterano item già preparati.
28. Abbandono senza conferma non modifica dati.
29. Abbandono confermato conserva esiti e punteggio; sessione terminale.
30. Completamento con item aperti rifiutato.
31. Riepilogo senza conferma non marca completed.
32. Conferma del riepilogo marca completed una sola volta.

### 16.5 Concorrenza e recovery

33. Due schede non possono creare due sessioni sospese per lo stesso profilo.
34. Due schede che valutano lo stesso sotto-quesito: un solo commit.
35. Conflitto di revisione non produce scritture parziali.
36. Profili differenti operano indipendentemente.
37. Crash prima del commit lascia lo stato precedente.
38. Crash dopo il commit viene riconosciuto dalla receipt.
39. Recovery non inventa esiti e non completa automaticamente la sessione.
40. Proiezioni incoerenti non causano cancellazione o sovrascrittura dello storico.

## 17. Questioni residue e assunzioni esplicite

- **Persistenza dell'input non confermato:** la specifica funzionale garantisce la conservazione del punto esatto e degli esiti registrati, ma non richiede di conservare il testo digitato prima della conferma. In questa versione l'input provvisorio viene scartato alla sospensione; non viene trasformato in esito.
- **Chiusura anticipata:** gli incompleti diventano `unanswered` solo dopo conferma esplicita di chiusura della domanda principale. Non sono eventi di esposizione.
- **Sessione lasciata aperta dopo il riepilogo:** senza conferma finale resta `in-progress`; l'utente può completare in seguito, sospendere o abbandonare.
- **Sessioni attive concorrenti:** la specifica limita a una la sessione sospesa per profilo, ma non definisce un vincolo generale di unicità per le sessioni `in-progress`. Questa versione applica il vincolo esplicito alla sessione sospesa e lascia la gestione di più sessioni attive come decisione da non codificare implicitamente.
- **Conferma finale dopo l'ultimo item:** la specifica richiede conferma esplicita; non è previsto completamento automatico.
- **Input e valutazione specifica:** le policy di confronto restano nelle definizioni congelate del sotto-quesito; il Session Manager non introduce normalizzazioni ad hoc.

Questi punti sono esplicitati per non confondere decisioni già approvate con dettagli implementativi. Eventuali modifiche funzionali dovranno essere versionate nella specifica prima dell'implementazione.

## 18. Sequenza implementativa raccomandata

1. Repository e transazioni IndexedDB già definite nello schema fisico.
2. Funzioni pure per transizioni di stato e calcolo riepiloghi.
3. `createSession()` con snapshot e selezione.
4. `recordOutcome()` e consultazione come transazioni atomiche.
5. Chiusura domanda e avanzamento.
6. Sospensione/ripresa.
7. Abbandono/completamento.
8. Recovery e concorrenza multi-scheda.
9. Test automatici di dominio e persistenza.
10. Integrazione UI e collaudo browser senza regressioni.

## 19. Esito

Il ciclo di vita della sessione è specificato a livello di stati, transizioni, invarianti, transazioni, errori e test. Il documento non costituisce autorizzazione a modificare i sorgenti: l'implementazione resta subordinata alla verifica finale delle dipendenze e all'autorizzazione già richiesta dal protocollo di progetto.
