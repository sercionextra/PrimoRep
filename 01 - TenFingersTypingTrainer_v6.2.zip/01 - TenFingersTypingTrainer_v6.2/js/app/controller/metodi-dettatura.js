/* TenFingersTypingTrainer v6.0 — AppController: dictation. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// Configurazione dei controlli interattivi della Dettatura Vocale (v.3.8 / v.3.9 / v.5.0)
  setupDictationControls() {
    const chkDict = document.getElementById("chkDictation");
    const rngSpeed = document.getElementById("rngDictationSpeed");
    const chkSpelling = document.getElementById("chkDictationSpelling");
    const chkCaps = document.getElementById("chkDictationCaps");
    const btnReplay = document.getElementById("btnDictationReplay");
    const chkApos = document.getElementById("chkDictationApostrophe");
    const chkSpace = document.getElementById("chkDictationSpace");

    if (chkSpelling) {
      chkSpelling.addEventListener("change", (e) => {
        const isSpell = e.target.checked;
        this.dictation.setSpelling(isSpell);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpelling = isSpell;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la modalità spelling attiva
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
          // Allinea immediatamente la voce al punto in cui si trova il cursore
          const matchLen = this.typingEng.getMatchLength();
          const typedLen = this.typingEng.typedText.length;
          this.dictation.updateProgress(typedLen, matchLen);
        }
        this.returnFocusToTyping();
      });
    }

    if (chkApos) {
      chkApos.addEventListener("change", (e) => {
        const isApos = e.target.checked;
        this.dictation.setAnnounceApostrophe(isApos);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationApostrophe = isApos;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la nuova modalità apostrofo
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (chkSpace) {
      chkSpace.addEventListener("change", (e) => {
        const isSpace = e.target.checked;
        this.dictation.setAnnounceSpace(isSpace);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpace = isSpace;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione fonetica con la nuova modalità spazio
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (chkDict) {
      chkDict.addEventListener("change", (e) => {
        const isEn = e.target.checked;
        this.dictation.setEnabled(isEn);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationEnabled = isEn;
          this.profileMgr.saveProfile();
        }
        if (isEn && !this.typingEng.isCompleted && this.typingEng.originText) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (rngSpeed) {
      rngSpeed.addEventListener("input", (e) => {
        const rate = parseFloat(e.target.value) / 100;
        this.dictation.setSpeed(rate);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationSpeed = rate;
          this.profileMgr.saveProfile();
        }
      });
      rngSpeed.addEventListener("change", () => {
        this.returnFocusToTyping();
      });
    }

    if (chkCaps) {
      chkCaps.addEventListener("change", (e) => {
        const isCaps = e.target.checked;
        this.dictation.setAnnounceCaps(isCaps);
        if (this.profileMgr?.profile) {
          this.profileMgr.profile.DictationCaps = isCaps;
          this.profileMgr.saveProfile();
        }
        // Riavvia la segmentazione con la nuova regola maiuscole
        if (
          this.dictation.enabled &&
          !this.typingEng.isCompleted &&
          this.typingEng.originText
        ) {
          this.dictation.startSession(
            this.typingEng.originText,
            this.typingEng.mode,
          );
        }
        this.returnFocusToTyping();
      });
    }

    if (btnReplay) {
      btnReplay.addEventListener("click", () => {
        this.replayDictation();
        this.returnFocusToTyping();
      });
    }
  },

// Riascolto della dettatura con invio di typedLen, matchLen e originText (v.4.2)
  replayDictation() {
    if (!this.dictation.enabled) {
      const chkDict = document.getElementById("chkDictation");
      if (chkDict) {
        chkDict.checked = true;
        this.dictation.setEnabled(true);
      }
    }
    const matchLen = this.typingEng.getMatchLength();
    const typedLen = this.typingEng.typedText.length;
    const originText = this.typingEng.originText;
    this.dictation.replay(typedLen, matchLen, originText);
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
