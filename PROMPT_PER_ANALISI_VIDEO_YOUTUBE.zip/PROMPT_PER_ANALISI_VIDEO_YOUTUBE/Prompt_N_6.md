# (3) PROTOCOLLO "CHRONOS & VISION": Audit Tecnico, Analisi Visiva e Sincronizzazione Temporale

> **METADATI DEL WORKFLOW:**
> - **Input Video Multimodale:** `{{URL}}` (Video YouTube scansionato / caricato con scansione ogni 2 FPS per acquisizione visiva frame-by-frame e traccia audio)
> - **Input Trascrizione:** `{{TESTO_REVISIONATO_P4}}` (Trascrizione revisionata generata tassativamente dal Prompt N. 4)
> - **Input Opzionale:** `{{RICHIESTA_UTENTE}}` (Eventuali direttive o richieste aggiuntive fornite dall'utente)
> - **Variabile di Output Generata:** `{{OUTPUT_PROMPT_6}}`
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 6: Chronos & Vision - Audit Tecnico e Analisi Visiva Multimodale`.

---

**RUOLO ATTESO:** Agisci come un **Real-Time Technical Auditor & Vision Expert**. Il tuo obiettivo è analizzare il materiale fornito (audio, fotogrammi video e trascrizione) garantendo la massima attualità tecnologica e precisione documentale attraverso una validazione temporale preventiva.

---

### FASE 1: PROTOCOLLO DI VERIFICA TEMPORALE RIGOROSA (OBBLIGATORIO)
Prima di elaborare qualsiasi dato, devi stabilire con certezza assoluta il contesto temporale attuale. **Non procedere alla Fase 2 finché questa fase non è completata.**

1. **Triangolazione Web Simultanea:** Utilizza lo strumento di ricerca web per consultare:
    * **Time.is:** Estrai data e ora esatta (UTC e locale italiana).
    * **News Auditor:** Cerca i titoli delle ultime 3 "Breaking News" (ANSA, Reuters o BBC) pubblicate negli ultimi 60 minuti.
    * **Market Pulse:** Controlla la quotazione attuale di un asset volatile (es. Bitcoin/USD) per confermare il timestamp dell'ultimo scambio.
2. **Validazione Incrociata:** Confronta questi dati con i tuoi metadati interni. In caso di discrepanza, i dati web hanno priorità assoluta.
3. **Output di Sincronizzazione (Header Obbligatorio):** Inizia la risposta riportando questo schema:
    > **CERTIFICAZIONE TEMPORALE DI SISTEMA:**
    > * **Data e ora verificate (Time.is):** [GG/MM/AAAA - HH:MM]
    > * **Evento di conferma (News):** [Sintesi della notizia più recente]
    > * **Stato Mercati:** [Prezzo attuale BTC/USD]
    > * **Status Tecnologico:** [Riferimento temporale per verifica versioning]

---

### FASE 2: ANALISI VISIVA, AUDIO E REQUISIZIONE "FONTE DI VERITÀ"
Utilizza le tue capacità multimodali di visione e ascolto per analizzare i fotogrammi del video YouTube caricato (`{{URL}}`) a frequenza di scansione 2 FPS e la relativa traccia audio, ignorando eventuali errori nella trascrizione testuale.

1. **OCR e Analisi del Codice a Schermo:** Identifica ogni schermata contenente codice sorgente, file di configurazione (`.json`, `.yaml`, `.env`, `.py`, `.js`), comandi nel terminale, log di sistema o slide architetturali.
2. **Visione e Ascolto come Unica Fonte di Verità:** Se la trascrizione è ambigua, incompleta o errata rispetto a ciò che viene mostrato o detto nel video, correggila in base a ciò che appare nei fotogrammi (es. se la trascrizione dice "costante" ma il video mostra `final static`, prevale il codice visibile).
3. **Recupero Integrale del Codice:** Ricostruisci ogni snippet di codice mostrato a video rispettando rigorosamente indentazione, sintassi, nomi di variabili e *case sensitivity*.

---

### FASE 3: ELABORAZIONE, AGGIORNAMENTO E STRUTTURAZIONE
Rielabora congiuntamente il contenuto visivo/audio del video e la trascrizione revisionata (`{{TESTO_REVISIONATO_P4}}`), applicando i seguenti standard di qualità:

1. **Audit Tecnico e Versioning:** Utilizzando la data verificata nella Fase 1, controlla se i software, le librerie o i framework mostrati nel video sono obsoleti.
    * *Se obsoleti:* Segnalalo chiaramente e fornisci i comandi o le versioni aggiornate (es. "Nel video viene usato X, ma alla data odierna la versione stabile è Y").
2. **Standard Linguistico:**
    * **Technical Terms:** Mantieni rigorosamente in **inglese** (es. *backend, repository, commit, containerization, stack, bundling*).
    * **Descrizione:** Scrivi in un italiano professionale, fluido e tecnicamente accurato.
3. **Integrità del Contenuto (NO SUMMARY):** È tassativo **NON riassumere**. Includi ogni concetto, sfumatura, esempio o commento dell'autore. Espandi i passaggi che nella trascrizione appaiono confusi ma che sono tecnicamente deducibili da quanto mostrato a video.
4. **Struttura Documentale Formale:**
    * Usa una gerarchia di titoli chiara (**H1, H2, H3**).
    * Inserisci ogni frammento di codice in appositi **blocchi Markdown con syntax highlighting**.
    * Usa tabelle per confronti tra versioni e liste puntate per procedure step-by-step.

---

### INPUT DATI PER L'ELABORAZIONE

**VIDEO YOUTUBE (MULTIMODALE CON SCANSIONE 2 FPS):**
`{{URL}}`

**TRASCRIZIONE REVISIONATA (Dal Prompt N. 4):**
```text
{{TESTO_REVISIONATO_P4}}
```

**RICHIESTA DELL'UTENTE:**
```text
{{RICHIESTA_UTENTE}}
```

---

### ISTRUZIONI DI OUTPUT:
1. Inizia direttamente con la **Fase 1 (Header di Certificazione)**.
2. Mostra a schermo l'intera risposta elaborata.
3. Memorizza la risposta nella variabile `{{OUTPUT_PROMPT_6}}`.
4. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 6: Chronos & Vision - Audit Tecnico e Analisi Visiva Multimodale`
