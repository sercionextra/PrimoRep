# Architettura TenFingersTypingTrainer v6.43

Documento di aggiornamento architetturale rispetto alla v6.42.

## 1. Obiettivo della Release v6.43
Introdurre l'ambito **Piano di Studio (solo lezioni seguite)** nell'Interrogazione sul layout della tastiera italiana, rendendolo l'opzione proposta per prima e predefinita, con filtraggio rigoroso di candidate e sotto-quesiti entro la lezione raggiunta (`MaxLessonReached`) e correzione esplicita del traguardo sul profilo.

## 2. Mappa Curriculum Statica (`js/data/lesson-curriculum-scope.js`)
Modulo puro `LessonCurriculumScope` che indicizza le 71 lezioni di `EMBEDDED_LESSONS` e i mapping di `INTERROGATION_CATALOG_DATA`:
- Mappa per ogni carattere, tasto fisico (`keyId`), dito (`fingerId`) e modificatore (`shift` da Lez. 26, `altgr` da Lez. 55) la prima lezione di introduzione, con correzioni puntuali per caratteri spuri presenti in frasi di lezioni precedenti (`,`, `.`, `'`, `\n`, `?`, `\t`).
- Espone `getScopeUpToLesson(maxLessonIndex)` e `getSlotConstraint(slotName, slotChar, maxLessonIndex)` per unificare la logica di ammissibilità tra backend e UI.

## 3. Profilo Utente (`js/profiles/profile-manager.js`, `metodi-toolbar-modalita.js`)
- Aggiunto `MaxLessonReached` al profilo utente (inizializzazione difensiva in `loadUser` a `Lesson` se assente).
- Aggiunti `getMaxLessonReached()`, `setMaxLessonReached(lessonIdx, maxLimit)` (per correzione manuale anche in riduzione) e `updateMaxLessonReachedIfHigher(lessonIdx, maxLimit)` (invocato su avanzamento lezione standard).

## 4. Contratto Backend Interrogazione (`interrogation-catalog.js`, `interrogation-session-manager.js`)
- `InterrogationCatalog.getCandidates(filter)` accetta `filter.maxLessonIndex` e filtra `CARATTERE`, `TASTO`, `DITO` e `HOME_ROW` (coerenza stretta sui tasti di riposo sbloccati) tramite `isCandidateInCurriculum`.
- `InterrogationSessionManager.createSession(input)` accetta `lessonScope` (`"curriculum"` | `"full"`) e `maxLessonIndex`, salvandoli in `sessionRecord`, `configSnapshot` e nei singoli `item` per garantire ripresa deterministica delle sessioni sospese.
- `knowledgeStates` rimane unico per profilo, evitando la perdita dello storico al passaggio a *Tastiera Completa*.

## 5. Frontend & Storico (`index.html`, `metodi-interrogazione.js`, `interrogation-ui.js`, `assets/styles/app.css`)
- **Setup:** `#interrogationScopeSelect` come primo controllo del form con `Piano di Studio` selezionato di default, affiancato da `#interrogationMaxLessonSelect` e da `#btnInterrSaveMaxLesson` (`Imposta come traguardo`).
- **Esecuzione (Mascheramento in ingresso):**
  - Blocco 2 (`Caratteri sul Tasto`): gli slot fuori programma sono disabilitati con etichetta `Da studiare (Lez. X)` (o `Non in programma`) ed esclusi dalla verifica di correttezza.
  - Quesiti `DITO` e `HOME_ROW`: attesa limitata ai soli tasti sbloccati fino a `maxLessonIndex`.
  - Selezione `Manuale`: blocco di selezione con notifica toast per elementi fuori programma.
- **Storico e Urgenza:** filtro `#interrHistScopeFilter` (`Tutte` | `Piano di Studio` | `Tastiera Completa`), etichetta ambito nel dettaglio campione e filtraggio contestuale dei candidati in `_renderUrgencyChart()`.
