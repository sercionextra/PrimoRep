/* TenFingersTypingTrainer v6.25 | interrogation-prng.js | PRNG deterministico xoshiro128** v1.0, ordinamento canonico utf16-code-unit-v1 e Fisher-Yates. */
(function (global) {
  "use strict";

  const ALGORITHM_ID = "xoshiro128**";
  const ALGORITHM_VERSION = "1.0";
  const SEED_ENCODING = "hex-128be";
  const CANONICAL_ORDERING_VERSION = "utf16-code-unit-v1";
  const UINT32_MOD = 4294967296;

  function rotl32(x, k) {
    return (((x << k) | (x >>> (32 - k))) >>> 0);
  }

  function imul32(a, b) {
    return Math.imul(a, b) >>> 0;
  }

  function createError(code, message) {
    const err = new Error(message || code);
    err.code = code;
    return err;
  }

  function parseHexSeed(seedHex) {
    if (typeof seedHex !== "string" || !/^[0-9a-fA-F]{32}$/.test(seedHex)) {
      throw createError(
        "PRNG_INVALID_SEED",
        "Il seed deve essere una stringa esadecimale di esattamente 32 caratteri (hex-128be).",
      );
    }
    const normalized = seedHex.toLowerCase();
    const state = [0, 0, 0, 0];
    for (let i = 0; i < 4; i++) {
      state[i] = parseInt(normalized.slice(i * 8, i * 8 + 8), 16) >>> 0;
    }
    if ((state[0] | state[1] | state[2] | state[3]) === 0) {
      throw createError("PRNG_ZERO_STATE", "Lo stato iniziale all-zero non è ammesso per xoshiro128**.");
    }
    return { normalized, state };
  }

  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }

  function isAllZeroBytes(bytes) {
    for (let i = 0; i < bytes.length; i++) {
      if (bytes[i] !== 0) return false;
    }
    return true;
  }

  function generateSeed() {
    const warnings = [];
    const bytes = new Uint8Array(16);
    const hasCrypto =
      typeof global.crypto !== "undefined" &&
      global.crypto &&
      typeof global.crypto.getRandomValues === "function";

    if (hasCrypto) {
      try {
        for (let attempt = 0; attempt < 8; attempt++) {
          global.crypto.getRandomValues(bytes);
          if (!isAllZeroBytes(bytes)) {
            return {
              seed: bytesToHex(bytes),
              seedEncoding: SEED_ENCODING,
              seedSource: "crypto.getRandomValues",
              seedSecurity: "cryptographic",
              warnings,
            };
          }
        }
      } catch (e) {
        // Fallback esplicito documentato
      }
    }

    warnings.push("PRNG_SEED_FALLBACK_NON_CRYPTOGRAPHIC");
    for (let attempt = 0; attempt < 8; attempt++) {
      for (let i = 0; i < 16; i++) {
        bytes[i] = Math.floor(Math.random() * 256) & 0xff;
      }
      if (!isAllZeroBytes(bytes)) {
        return {
          seed: bytesToHex(bytes),
          seedEncoding: SEED_ENCODING,
          seedSource: "Math.random-fallback",
          seedSecurity: "non-cryptographic",
          warnings,
        };
      }
    }

    bytes[15] = 1;
    warnings.push("PRNG_SEED_DEGENERATE_FALLBACK");
    return {
      seed: bytesToHex(bytes),
      seedEncoding: SEED_ENCODING,
      seedSource: "Math.random-fallback",
      seedSecurity: "non-cryptographic",
      warnings,
    };
  }

  class Xoshiro128StarStar {
    constructor(seedHex) {
      const parsed = parseHexSeed(seedHex);
      this.seed = parsed.normalized;
      this.s0 = parsed.state[0];
      this.s1 = parsed.state[1];
      this.s2 = parsed.state[2];
      this.s3 = parsed.state[3];
      this.drawCount = 0;
      this.rejectionCount = 0;
    }

    nextUint32() {
      const result = imul32(rotl32(imul32(this.s1, 5), 7), 9);
      const t = (this.s1 << 9) >>> 0;

      this.s2 = (this.s2 ^ this.s0) >>> 0;
      this.s3 = (this.s3 ^ this.s1) >>> 0;
      this.s1 = (this.s1 ^ this.s2) >>> 0;
      this.s0 = (this.s0 ^ this.s3) >>> 0;

      this.s2 = (this.s2 ^ t) >>> 0;
      this.s3 = rotl32(this.s3, 11);

      this.drawCount += 1;
      return result >>> 0;
    }

    nextInt(bound) {
      if (
        typeof bound !== "number" ||
        !Number.isInteger(bound) ||
        bound < 1 ||
        bound > UINT32_MOD
      ) {
        throw createError("PRNG_INVALID_BOUND", "Bound PRNG non valido.");
      }
      if (bound === UINT32_MOD) {
        return this.nextUint32();
      }
      const threshold = (UINT32_MOD - bound) % bound;
      while (true) {
        const r = this.nextUint32();
        if (r >= threshold) {
          return r % bound;
        }
        this.rejectionCount += 1;
      }
    }

    getState() {
      return [this.s0 >>> 0, this.s1 >>> 0, this.s2 >>> 0, this.s3 >>> 0];
    }

    getDiagnostics() {
      return {
        prngAlgorithmId: ALGORITHM_ID,
        prngAlgorithmVersion: ALGORITHM_VERSION,
        seed: this.seed,
        seedEncoding: SEED_ENCODING,
        canonicalOrderingVersion: CANONICAL_ORDERING_VERSION,
        prngStateAfterSelection: this.getState(),
        prngDrawCount: this.drawCount,
        prngRejectionCount: this.rejectionCount,
      };
    }
  }

  function canonicalSortCandidateIds(candidateIds) {
    if (!Array.isArray(candidateIds)) {
      throw createError("SELECTION_INVALID_POOL", "Il pool di candidate deve essere un array.");
    }
    const seen = new Set();
    const copy = [];
    for (let i = 0; i < candidateIds.length; i++) {
      const id = candidateIds[i];
      if (typeof id !== "string" || id.length === 0 || /^\s+$/.test(id)) {
        throw createError("SELECTION_INVALID_CANDIDATE_ID", "candidateId non valido nel pool.");
      }
      if (seen.has(id)) {
        throw createError("SELECTION_DUPLICATE_CANDIDATE_ID", `candidateId duplicato: ${id}`);
      }
      seen.add(id);
      copy.push(id);
    }
    copy.sort((a, b) => (a < b ? -1 : a > b ? 1 : 0));
    return copy;
  }

  function shuffleFisherYates(items, prng) {
    const arr = items.slice();
    const n = arr.length;
    if (n <= 1) return arr;
    for (let i = n - 1; i > 0; i--) {
      const j = prng.nextInt(i + 1);
      const tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }

  async function computePoolFingerprint(canonicalCandidateOrder) {
    if (
      typeof TextEncoder === "undefined" ||
      typeof global.crypto === "undefined" ||
      !global.crypto ||
      !global.crypto.subtle ||
      typeof global.crypto.subtle.digest !== "function"
    ) {
      throw createError(
        "SELECTION_FINGERPRINT_UNAVAILABLE",
        "WebCrypto SHA-256 non disponibile per calcolare il fingerprint del pool.",
      );
    }
    const encoded = new TextEncoder().encode(JSON.stringify(canonicalCandidateOrder));
    const digestBuffer = await global.crypto.subtle.digest("SHA-256", encoded);
    const hashBytes = new Uint8Array(digestBuffer);
    return "sha256:" + bytesToHex(hashBytes);
  }

  global.InterrogationPRNG = Object.freeze({
    ALGORITHM_ID,
    ALGORITHM_VERSION,
    SEED_ENCODING,
    CANONICAL_ORDERING_VERSION,
    parseHexSeed,
    generateSeed,
    Xoshiro128StarStar,
    canonicalSortCandidateIds,
    shuffleFisherYates,
    computePoolFingerprint,
  });
})(typeof window !== "undefined" ? window : globalThis);
