# Mission: Risolvere il Cubo di Rubik 3x3

## Why
Riuscire a risolvere il Cubo di Rubik 3x3 in autonomia, senza consultare guide o istruzioni, per pura soddisfazione personale.

## Success looks like
- Risolvere un cubo 3x3 mescolato dall'inizio alla fine sul simulatore [Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3) senza aiuti esterni.
- Comprendere la struttura del cubo (centri, spigoli, angoli) e la logica di base di ogni fase, così da saper recuperare eventuali errori senza dover ricominciare da zero.
- Ricordare a memoria un metodo semplice, affidabile e con pochissimi algoritmi.

## Constraints
- Nessun cubo fisico a disposizione: tutta la pratica avviene sul simulatore online [Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3).
- Tempo flessibile: nessuna fretta, priorità alla comprensione solida e alla ritenzione a lungo termine.
- Lingua del percorso: italiano.

## Out of scope
- Speedcubing competitivo, fingertricks avanzati e tempi sotto il minuto.
- Metodi avanzati con decine di algoritmi (es. CFOP completo, OLL/PLL completi).
