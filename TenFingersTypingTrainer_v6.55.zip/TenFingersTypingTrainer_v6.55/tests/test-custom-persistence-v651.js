const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function createStorageMock() {
  const map = new Map();
  return {
    getItem(key) {
      return map.has(key) ? map.get(key) : null;
    },
    setItem(key, val) {
      map.set(key, String(val));
    },
    removeItem(key) {
      map.delete(key);
    },
    clear() {
      map.clear();
    },
  };
}

function createElementMock(id = "") {
  return {
    id,
    value: "",
    innerText: "",
    innerHTML: "",
    placeholder: "",
    checked: false,
    disabled: false,
    style: {},
    classList: {
      add() {},
      remove() {},
      contains() {
        return false;
      },
      toggle() {},
    },
    addEventListener() {},
    removeEventListener() {},
    focus() {},
    select() {},
    setAttribute() {},
    querySelectorAll() {
      return [];
    },
  };
}

const elements = new Map();
function getEl(id) {
  if (!elements.has(id)) elements.set(id, createElementMock(id));
  return elements.get(id);
}

const localStorageMock = createStorageMock();

const sandbox = {
  console,
  localStorage: localStorageMock,
  window: { APP_VERSION: "6.51" },
  document: {
    body: createElementMock("body"),
    getElementById: getEl,
    querySelectorAll: () => [],
  },
  htmlEscape: (s) => String(s),
  setTimeout: (fn) => {
    if (typeof fn === "function") fn();
    return 0;
  },
  clearTimeout: () => {},
  AppController: null,
  AudioEngine: class { setMode() {} setVolume() {} playError() {} },
  TypingEngine: class { constructor(lessons) { this.lessons = lessons; this.mode = 0; this.currentLessonIdx = 0; this.currentPhraseIdx = 0; } },
  VisualRenderer: class { constructor() { return new Proxy(this, { get: (t, p) => t[p] || (() => {}) }); } },
  DictationEngine: class { constructor() { return new Proxy(this, { get: (t, p) => t[p] || (() => {}) }); } },
  WindowManager: class { bringModalToFront() {} clampWindowToViewport() {} },
  StatisticsManager: class {},
  PhonemeEngine: class {},
};
sandbox.window.document = sandbox.document;
sandbox.window.localStorage = localStorageMock;

const scripts = [
  "js/domain/helpers.js",
  "js/profiles/profile-manager.js",
  "js/app/controller/controller-core.js",
  "js/app/controller/metodi-profili-modali.js",
  "js/app/controller/metodi-toolbar-modalita.js",
  "js/app/controller/metodi-navigazione-dialoghi.js",
];

for (const rel of scripts) {
  const code = fs.readFileSync(path.join(root, rel), "utf8");
  vm.runInNewContext(code, sandbox, { filename: rel });
}

const ProfileManager = vm.runInNewContext("ProfileManager", sandbox);
const AppController = vm.runInNewContext("AppController", sandbox);
const parseCustomExercises = vm.runInNewContext("parseCustomExercises", sandbox);

// Costruisci 12 lezioni custom (ciascuna con 3 frasi separate da =====) e 5 lezioni standard
let customText = "";
for (let i = 1; i <= 12; i++) {
  customText += `=====CustomTitle_${i}=====\n`;
  customText += `frase ${i} uno\n=====\nfrase ${i} due\n=====\nfrase ${i} tre\n`;
}
const standardLessons = Array.from({ length: 5 }, (_, i) => ({
  name: `Std_${i + 1}`,
  phrases: [`std ${i + 1} a`, `std ${i + 1} b`],
}));

// Stub minimi su AppController.prototype per testare senza DOM completo
AppController.prototype.startExercise = function () {};
AppController.prototype.updateFonemiDropdownSummary = function () {};
AppController.prototype.updateInstantSpeedVisibility = function () {};
AppController.prototype.updateModeUI =
  AppController.prototype.updateModeUI || function () {};
AppController.prototype.returnFocusToTyping = function () {};
AppController.prototype.setControlEnabled = function () {};
AppController.prototype.applyTheme = function () {};
AppController.prototype.toggleHandsVis = function () {};
AppController.prototype.toggleKeyboardVis = function () {};
AppController.prototype.toggleInstantSpeedVis = function () {};
AppController.prototype.updateHandsWindowPosition = function () {};
AppController.prototype.updateInstantSpeedWindowPosition = function () {};
AppController.prototype.syncLayoutArrangement = function () {};
AppController.prototype.applyZoom = function () {};
AppController.prototype.updateHandsPinButtonUI = function () {};
AppController.prototype.updateInstantSpeedPinButtonUI = function () {};
AppController.prototype.toggleOriginVis = function () {};
AppController.prototype.toggleTypedVis = function () {};
AppController.prototype.toggleErrorsVis = function () {};

function makeController() {
  const ctrl = new AppController(standardLessons, {}, customText, "");
  ctrl.profileMgr = new ProfileManager({}, customText);
  ctrl.typingEng = {
    mode: 0,
    lessons: standardLessons,
    lessonsSource: "standard",
    currentLessonIdx: 0,
    currentPhraseIdx: 0,
  };
  ctrl.audio = { setMode() {}, setVolume() {}, playError() {} };
  ctrl.windowMgr = { bringModalToFront() {}, clampWindowToViewport() {} };
  return ctrl;
}

// 1. Verifica inizializzazione difensiva su profilo legacy privo dei nuovi campi
localStorageMock.setItem("TenFingers_Users", JSON.stringify(["LEGACY_USER"]));
localStorageMock.setItem(
  "TenFingers_Profile_LEGACY_USER",
  JSON.stringify({
    UserID: "LEGACY_USER",
    Mode: 0,
    Lesson: 3,
    Exercise: 1,
    CustomText: customText,
  }),
);
const pmLegacy = new ProfileManager({}, customText);
const loadedLegacy = pmLegacy.loadUser("LEGACY_USER");
assert.strictEqual(loadedLegacy.LessonsSource, "standard");
assert.strictEqual(loadedLegacy.CustomLesson, 0);
assert.strictEqual(loadedLegacy.CustomExercise, 0);

// 2. Utente imposta Standard a Lezione 4 (idx 3) frase 2 (idx 1), poi passa a Custom 9 (idx 8) frase 2 (idx 1)
const ctrl1 = makeController();
ctrl1.profileMgr.createUser("MARIO");
ctrl1.loginUser("MARIO");
ctrl1.profileMgr.profile.Lesson = 3;
ctrl1.profileMgr.profile.Exercise = 1;
ctrl1.profileMgr.saveProfile();

ctrl1.setLessonsSource("custom");
assert.strictEqual(ctrl1.activeLessonsSource, "custom");
assert.strictEqual(ctrl1.profileMgr.profile.LessonsSource, "custom");

// Naviga a Custom 9 (idx 8), frase 2 (idx 1)
ctrl1.navLesson(8);
assert.strictEqual(ctrl1.typingEng.currentLessonIdx, 8);
assert.strictEqual(ctrl1.profileMgr.profile.CustomLesson, 8);
assert.strictEqual(ctrl1.profileMgr.profile.Lesson, 3, "La lezione Standard non deve essere sovrascritta");

ctrl1.navPhrase(1);
assert.strictEqual(ctrl1.typingEng.currentPhraseIdx, 1);
assert.strictEqual(ctrl1.profileMgr.profile.CustomExercise, 1);
assert.strictEqual(ctrl1.profileMgr.profile.Exercise, 1);

// 3. Simula chiusura e riapertura del browser (nuova istanza AppController + ProfileManager)
const ctrl2 = makeController();
ctrl2.loginUser("MARIO");
assert.strictEqual(ctrl2.activeLessonsSource, "custom", "Alla riapertura deve restare in custom");
assert.strictEqual(ctrl2.typingEng.currentLessonIdx, 8, "Alla riapertura deve ripristinare Custom 9 (idx 8)");
assert.strictEqual(ctrl2.typingEng.currentPhraseIdx, 1, "Alla riapertura deve ripristinare frase 2 (idx 1)");
assert.strictEqual(getEl("cboLessons").value, "8");
assert.strictEqual(getEl("lblLessonSource").innerText, "Custom");

// 4. Opzione B: passaggio temporaneo a modalità 2 (Fonemi) e ritorno a modalità 0 (Phrases)
ctrl2.typingEng.mode = 2;
ctrl2.updateModeUI();
assert.strictEqual(ctrl2.activeLessonsSource, "standard", "In modalità != 0 la sorgente runtime passa a standard");
assert.strictEqual(ctrl2.profileMgr.profile.LessonsSource, "custom", "Opzione B: LessonsSource nel profilo resta custom");

ctrl2.typingEng.mode = 0;
ctrl2.updateModeUI();
assert.strictEqual(ctrl2.activeLessonsSource, "custom", "Tornando a mode 0 deve ripristinare custom");
assert.strictEqual(ctrl2.typingEng.currentLessonIdx, 8);
assert.strictEqual(ctrl2.typingEng.currentPhraseIdx, 1);

// 5. Passaggio manuale a Standard recupera il cursore Standard (Lezione 4, frase 2 -> idx 3, 1)
ctrl2.setLessonsSource("standard");
assert.strictEqual(ctrl2.activeLessonsSource, "standard");
assert.strictEqual(ctrl2.typingEng.currentLessonIdx, 3);
assert.strictEqual(ctrl2.typingEng.currentPhraseIdx, 1);

// 6. Ritorno manuale a Custom recupera Custom 9, frase 2 (idx 8, 1)
ctrl2.setLessonsSource("custom");
assert.strictEqual(ctrl2.typingEng.currentLessonIdx, 8);
assert.strictEqual(ctrl2.typingEng.currentPhraseIdx, 1);

// 7. Clamp se il testo custom si riduce a sole 3 lezioni
ctrl2.customLessons = parseCustomExercises(
  "=====A=====\nuno\n=====\n=====B=====\ndue\n=====\n=====C=====\ntre\n=====",
);
ctrl2.setLessonsSource("custom");
assert.strictEqual(ctrl2.typingEng.currentLessonIdx, 2);
assert.strictEqual(ctrl2.typingEng.currentPhraseIdx, 0);

console.log("PASS test-custom-persistence-v651");
