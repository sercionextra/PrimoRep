README_DEFINIZIONE_E_USO_AGENTE_ANTIGRAVITY.md
==============================================

In GoogleAiStudio

=============================================================
- AZIONE_N_1) Scegliere un Modello : "Agent" - "Antigravity"
=============================================================

=============================================================
- AZIONE_N_2) Scegliere un Modello AI : "Gemini 3.8 Flash"
=============================================================

=============================================================
- AZIONE_N_3) Impostare le API Key
=============================================================

	- (btn) Link API Key
	- (flag) Collega chiave API
	- (btn) Seleziona chiave
	

=============================================================
- AZIONE_N_4) Impostare le seguenti System Instructions :
=============================================================
--------------------------------------------------------------------------------------------------------------
Sei un Real-Time Technical Auditor, Content Architect e Vision Expert. Il tuo compito è eseguire una pipeline sequenziale e modulare di analisi su un video di YouTube e sulla relativa trascrizione temporizzata.

### PROTOCOLLO DI ACQUISIZIONE INIZIALE:
Al primo avvio, richiedi tassativamente all'utente:
1. {{URL}}: Il link del video YouTube.
2. {{TESTO_ORIGINALE}}: La trascrizione temporizzata del video.
3. Lingua del video: Chiedi all'utente se la trascrizione è in lingua inglese o già in italiano.

Non procedere con l'elaborazione dei prompt prima di aver ricevuto questi dati.

### GESTIONE DELLE VARIABILI E FLUSSO DI ESECUZIONE:
- Prompt 1: Elabora {{TESTO_ORIGINALE}} -> genera {{OUTPUT_PROMPT_1}}.
- Prompt 2 (CONDIZIONALE): Se la lingua originale NON è l'italiano, elabora {{OUTPUT_PROMPT_1}} -> genera {{OUTPUT_PROMPT_2}}. Se è già in italiano, SALTA il Prompt 2 e imposta {{INPUT_TESTO_PROMPT_3}} = {{OUTPUT_PROMPT_1}}.
- Prompt 3: Elabora {{INPUT_TESTO_PROMPT_3}} -> genera {{OUTPUT_PROMPT_3}}.
- Prompt 4: Elabora il testo in ingresso ({{OUTPUT_PROMPT_3}} o {{OUTPUT_PROMPT_1}}) -> genera {{TESTO_REVISIONATO_P4}}.
  * REGOLA AUREA: La variabile {{TESTO_REVISIONATO_P4}} generata dal Prompt 4 costituisce l'input obbligatorio e vincolante per il Prompt 5 e il Prompt 6.
- Prompt 5: Elabora {{TESTO_REVISIONATO_P4}} ed eventuali istruzioni utente -> genera {{OUTPUT_PROMPT_5}}.
- Prompt 6: Elabora l'URL video multimodale (audio + fotogrammi scansione 2 FPS) congiuntamente a {{TESTO_REVISIONATO_P4}} -> genera {{OUTPUT_PROMPT_6}}.

### PROTOCOLLO DI LOGGING E OUTPUT:
Per ogni singolo prompt eseguito:
1. Mostra la risposta completa a schermo.
2. Formatta l'output in modo che sia pronto per essere accodato nel file master "ANALISI_VIDEO.md", inserendo sempre in testa il titolo del prompt:
   - `# RISPOSTA PROMPT 1: Revisione Tecnica della Trascrizione`
   - `# RISPOSTA PROMPT 2: Traduzione in Italiano`
   - `# RISPOSTA PROMPT 3: Riformattazione Strutturata e Paragrafi`
   - `# RISPOSTA PROMPT 4: Revisione Dettagliata e Sfoltimento Timestamp`
   - `# RISPOSTA PROMPT 5: Chronos & Tech - Analisi Tecnica Avanzata`
   - `# RISPOSTA PROMPT 6: Chronos & Vision - Audit Tecnico e Analisi Visiva Multimodale`
   
3. Il file "ANALISI_VIDEO.md" deve iniziare con il Titolo del video, e tra parentesi il canale Youtube di origine, seguito dall'url del video visibile per esteso
4. Nel file "ANALISI_VIDEO.md" deve essere presente un indice cliccabile che linka alle risposte dei singoli prompt
--------------------------------------------------------------------------------------------------------------


=============================================================
- AZIONE_N_5) Definire le Sources seguente:
=============================================================

Source N.1 - Type : "REPOSITORY":
	Nome : /new-repository
	Testo:
--------------------------------------------------------------------------------
		https://github.com/sercionextra/PrimoRep
--------------------------------------------------------------------------------

===========================================================================================
- AZIONE_N_6) Definire la Source specificante i dati di INPUT, editando il segente esempio:
===========================================================================================
Source N.2 - Type : "INLINE":
	Nome : /INPUT_SOURCE.md	
	Testo:
--------------------------------------------------------------------------------
# SOURCE INLINE - CONFIGURAZIONE E TRASCRIZIONE VIDEO
---
URL: https://www.youtube.com/watch?v=ESEMPIO_ID													<<<<< INDICARE QUI L'URL DEL VIDEO DI YOUTUBE
LINGUA: [EN | IT ]																				<<<<< INDICARE QUI LA LINGUA DELLA TRASCRIZIONE DEL VIDEO DI YOUTUBE (EN / IT)
---

### TESTO_ORIGINALE
[00:00:00] Inserisci qui il testo completo della trascrizione temporizzata...					<<<<< SOSTITUIRE QUESTO ESEMPIO CON LA VERA TRASCRIZIONE TEMPORIZZATA DEL VIDEO DI YOUTUBE
[00:00:15] Ogni frase può essere preceduta dal relativo timestamp tra parentesi quadre...
[00:00:45] Continuazione della trascrizione...
...
--------------------------------------------------------------------------------


====================================================================================================================
AZIONE_N_7) Eseguire questi due prompt in sequenza per di DECOMPRIMERE il file zip contenente i prompt da eseguire ed avviare la sequenza
====================================================================================================================

	Prompt n.1:
		unzip "/new_repository/PROMPT_PER_ANALISI_VIDEO_YOUTUBE.zip" -d /workspace
	
	Prompt n.2:
		"Prosegui"

=============================================================
AZIONE_N_8)	Proseguire negli STEP successivi
=============================================================

	inserere vari prompt PROMPT con il testo seguente:
		
		"PROCSEGUI"
		
	per avanzare nella sequenza di elaborazione, un prompt dopo l'altro, fino all'esecuzione completa di tutti i prompt previsti.
	
	
=============================================================
AZIONE_N_9) Eseguire il Download del file .tar compresso con l'intero drive virtuale dell'agente
=============================================================

		- (btn) DOWNLOAD
		
		- Decompressione del file (.tar) 
		- Apertura del file di output "/workspace/ANALISI_VIDEO.md" con VSCode (modalità Anteprima file Markdown)
	
=============================================================
AZIONE_N_10) Procedura di emergenza se il file downlodato non contiene i risultati attesi (Esegue il FLUSH dei file da scrivere nell'output e aggiorna i metadati
=============================================================

	Eseguire il seguente PROMPT:
	
		find /workspace -exec touch {} + && sync
	
	
	- (btn) DOWNLOAD			>>>>  Produce un PRIMO download(di sicurezza) (.tar) nella directory DOWNLOAD dell'intero Drive Virtuale (Sandbox di Antigravity)
	
	
	- BACKUP CHAT tramite script per Google DevTools (dedicato ad Antigravity)
	
	
	SEGUITO DA:
	- F5 	sulla pagina Web della chat di ANTIGRAVITY  (ALLE VOLTE GIRA ALL'INFINITO se la CHAT è molto lunga)

	- (btn) DOWNLOAD			>>>>  Produce un SECONDO download (.tar) nella directory DOWNLOAD dell'intero Drive VIRTUALE (Sandbox di Antigravity)
		