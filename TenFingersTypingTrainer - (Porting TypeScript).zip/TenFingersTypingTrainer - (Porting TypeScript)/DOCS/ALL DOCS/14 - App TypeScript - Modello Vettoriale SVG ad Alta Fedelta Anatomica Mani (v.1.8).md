# Documento di Avanzamento Tecnico e Specifica Funzionale (Versione 1.8)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Versione rilasciata**: **1.8**  
**Data**: 30/03/2026  
**File sorgente correlati**:
- `index_(v.1.8).html`
- `help_(v.1.8).html`
- `hands_anatomical_model.svg`

---

## 1. Sommario Esecutivo

Il rilascio della **Versione 1.8** attua la revisione integrale e definitiva del modello vettoriale per la finestra fluttuante **10 Fingers (Mani)**, superando i difetti riscontrati nelle versioni 1.5–1.7 (spessori disomogenei e rastremati a cuneo, dita convesse dislocate ed escrescenze/discontinuità perimetrali):

1. **Ricalco Matematico Diretto dall'Asset Originale (`TastieraMani.gif` / `TastieraManiSelezionata.gif`)**:
   - I contorni vettoriali sono stati estratti e parametrizzati direttamente dalla line-art originale del software WinForms 2003 di Alberto Modenese.
   - La postura delle mani adotta la corretta impostazione dattilografica di riposo sulla riga base (*Home Row*: `A S D F` per la mano sinistra, `J K L ò` per la mano destra), con i pollici orientati con naturalezza verso l'interno/basso in direzione della barra spaziatrice (anziché protesi verticalmente verso l'alto o a contatto al centro).
2. **Spessori Fisiologici Costanti e Uniformi delle Dita**:
   - I diametri di ciascuna falange digitale mantengono un andamento anatomico cilindrico regolare (36–45 px di larghezza all'arco ungueale):
     - *Mignoli (1 e 10):* silhouette affusolata ma solida, inclinata all'esterno con raccordo continuo lungo l'eminenza ipotenar.
     - *Anulari (2 e 9):* profilo allungato con raccordi a U sul terzo distale.
     - *Medi (3 e 8):* apice culminante verticale della mano con calotta semisferica naturale.
     - *Indici (4 e 7):* falangi robuste con piega interdigitale profonda verso il primo metacarpo.
     - *Pollici (5 e 6):* muscolatura tenar organica con orientamento convergente verso lo spazio centrale.
3. **Eliminazione Radicale di Tutte le Escrescenze e Difetti Perimetrali**:
   - La sagoma esterna (`.hand-silhouette`) è generata come una curva spline Bézier $C^1$ continua e chiusa.
   - Tutti gli overlay digitali interattivi (`hand_finger_1` ... `hand_finger_10`), le unghie (`.finger-nail`) e le pieghe interfalangee (`.finger-crease`) sono racchiusi all'interno di elementi vettoriali `<clipPath id="leftHandClip">` e `<clipPath id="rightHandClip">`.
   - Questa soluzione architetturale garantisce con rigore geometrico assoluto che nessun bordo, bagliore o animazione pulsante possa mai debordare o generare scalini/escrescenze all'esterno della silhouette della mano.
4. **Allineamento Millimetrico dei Badge sui Polpastrelli**:
   - Le etichette dei caratteri bersaglio e degli accordi (`hand_finger_tip_1` ... `hand_finger_tip_10`) risiedono con precisione al centro di gravità del polpastrello di ciascun dito, dotate di contorno anti-alone ad alto contrasto (`stroke: #090d16; stroke-width: 3.5px; paint-order: stroke fill;`) per una lettura immediata sia dei singoli tasti sia delle legature complesse (`Ctrl`, `Alt`, `Shift`).

---

## 2. Mappatura Geometrica del Canvas Vettoriale (`viewBox="0 0 1024 450"`)

### 2.1 Coordinate di Riferimento dei Polpastrelli (`hand_finger_tip_X`)
Il canvas adotta un asse di simmetria centrale $x = 512$:
$$x_{destra} = 1024 - x_{sinistra}$$

| Dito | Denominazione Anatomica | Mano | Coordinate $(X, Y)$ | Tasto Base Riposo |
|:---:|:---|:---:|:---:|:---:|
| **1** | Mignolo Sinistro | Sinistra | `(64, 134)` | `A` |
| **2** | Anulare Sinistro | Sinistra | `(132, 85)` | `S` |
| **3** | Medio Sinistro | Sinistra | `(234, 68)` | `D` |
| **4** | Indice Sinistro | Sinistra | `(334, 94)` | `F` |
| **5** | Pollice Sinistro | Sinistra | `(408, 226)` | `Spazio` |
| **6** | Pollice Destro | Destra | `(616, 226)` | `Spazio` |
| **7** | Indice Destro | Destra | `(690, 94)` | `J` |
| **8** | Medio Destro | Destra | `(790, 68)` | `K` |
| **9** | Anulare Destro | Destra | `(892, 85)` | `L` |
| **10** | Mignolo Destro | Destra | `(960, 134)` | `ò` |

---

## 3. Matrice di Test e Validazione Funzionale

| N° | Verifica Effettuata | Esito Atteso | Risultato |
|:---:|:---|:---|:---:|
| 1 | **Verifica Sintassi JavaScript V8** | Nessun errore di compilazione su `index_(v.1.8).html` (`node --check`) | **PASS** |
| 2 | **Rendering Headless Chrome (CDP)** | Canvas SVG 1024×450 renderizzato senza overflow e proporzioni corrette | **PASS** |
| 3 | **Assenza di Escrescenze Perimetrali** | Elementi interni rigorosamente contenuti entro `clipPath` della sagoma | **PASS** |
| 4 | **Uniformità Spessori Digitali** | Larghezza dita compresa costantemente tra 36px e 45px senza strozzature | **PASS** |
| 5 | **Evidenziazione Accordi e Tip Badges** | Tasti composti (`Ctrl` + `Alt` + `}`) visibili con contrasto chiaro/scuro | **PASS** |
| 6 | **Allineamento Versioning e Help** | Coerenza cross-documentale tra sorgenti `v.1.8`, help e specifiche | **PASS** |

---

## 4. Struttura dei File Rilasciati in `/workspace`

```text
/workspace/
├── index_(v.1.8).html                                                                          # SPA v.1.8 con SVG mani ad alta fedeltà
├── help_(v.1.8).html                                                                           # Manuale Utente v.1.8 con sezione dedicata
├── hands_anatomical_model.svg                                                                  # Modello vettoriale SVG standalone 1024x450
├── 14 - App TypeScript - Modello Vettoriale SVG ad Alta Fedelta Anatomica Mani (v.1.8).md        # Specifica tecnica di avanzamento v.1.8
└── TenFingersTypingTrainer - (Porting TypeScript)/
    ├── DOCS/
    │   └── 14 - App TypeScript - Modello Vettoriale SVG ad Alta Fedelta Anatomica Mani (v.1.8).md
    └── SRC/
        ├── index_(v.1.8).html
        └── help_(v.1.8).html
```
