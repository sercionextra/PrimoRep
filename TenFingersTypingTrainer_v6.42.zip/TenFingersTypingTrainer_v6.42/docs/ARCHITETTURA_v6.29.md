# Architettura Applicativa — TenFingersTypingTrainer v6.29

**Versione:** 6.29
**Baseline precedente:** v6.26
**Stack:** JavaScript classico (`defer`), HTML5, CSS3, LocalStorage (`ProfileManager`), IndexedDB (`InterrogationRepository`), Web Speech API (`DictationEngine`). Zero dipendenze esterne.

## Novità architetturali della v6.29 — Interrogazione Grafica Interattiva

### 1. Metadati topologici e anatomici (`js/interrogation/interrogation-layout-metadata.js`)
- `KEY_BOXES` e `KEY_NEIGHBORS`: topologia esatta dei 62 tasti SVG con mappa dei vicini ("margherita") `{ topLeft, topRight, left, right, bottomLeft, bottomRight }` e gestione esplicita dei bordi (`null` -> valutato come `NONE`).
- `KEY_EXTENSIONS`: estensione longitudinale (`-1, 0, +1, +2`) ed estensione laterale (`0, 1, 2, 3` con direzione `none | sn | dx`, incluso `key_enter` a `3 dx`).
- `KEY_SLOTS` e `ASCII_CHARACTERS`: mapping dei 4 slot per tasto (`normal`, `shift`, `altgr`, `shiftAltgr`) e dizionario ordinato per codice ASCII + tasti speciali.
- `isModifierMatch`: valutazione modificatori con supporto checkbox `CTRL`, `SHIFT`, `ALT`, `AltGr` ed equivalenza tra `AltGr` e `CTRL + ALT` (e `SHIFT + AltGr` equivalente a `CTRL + ALT + SHIFT`).

### 2. Renderer SVG isolato (`js/ui/interrogation-svg-renderer.js`)
- Clona `#keyboardSvg` e `#handsSvg` nella modale prefissando tutti gli ID con `interr_` per evitare collisioni DOM con `VisualRenderer`.
- Modalità tastiera B/N anonima: nasconde tutti i simboli `<text>` finché i tasti non vengono sbloccati dalle risposte o da Consulta.
- Mani SVG interattive: tutte le 10 dita selezionabili e layer dedicato ai landmark anatomici con raggio hit-target calibrato dinamicamente su `ResizeObserver` (garanzia di almeno 3 pixel reali su schermo). Punto target evidenziato in verde maggiorato insieme ai modificatori coinvolti.

### 3. Sessione e UI (`interrogation-session-manager.js`, `interrogation-ui.js`, `metodi-interrogazione.js`)
- `recordBlockEvaluation`: registra in modo atomico i blocchi interattivi (`+3` corretta, `+1` Consulta, `0` errata).
- Supporto completo ai 4 tipi di interrogazione: `CARATTERE` (3 blocchi: Accordo, Caratteri sul Tasto con mini-keycap, Margherita), `TASTO` (estrazione random di un carattere del tasto), `DITO` (opzione configurabile `soli_tasti_fisici` | `tutti_i_singoli_caratteri` con filtro progressivo), `HOME_ROW` (4 tasti sinistri/destri su tastiera B/N + carattere e dito).
- Popover ASCII compatto per inserimento senza indizi sulla tastiera.
- Integrazione statistiche profilo (`profile.interrogationStats`) al completamento della sessione.

## Aggiornamento v6.29
- Rimosso vincolo `max-width: 460px` su `.interrogation-dialog-wide` (`width: min(1720px, 98vw); max-width: 98vw`).
- Derivazione automatica di `keyId`, `character`, `modifierMode`, `fingerId`, `handId` nei candidati `InterrogationCatalog`.
- Attivazione automatica ascolto tastiera fisica in modalità manuale e `pointer-events: all` su dita e pallini SVG.

## Aggiornamento v6.29
- Rimozione di `#interr_handsErrorCountText`, `#interr_dotsLeftGroup`, `#interr_dotsRightGroup` e classi live `.active-target` dal clone SVG.
- Sagome anatomiche complete delle 10 dita (`FULL_FINGER_PATHS`) e regola `.interr-key-label-hidden { opacity: 0 !important; }`.
- Barra titolo compatta con `#interrHeaderMeta` (`Punteggio p / max`) e rimozione del footer duplicato.
- Scorciatoie grafiche da dita e pallini delle mani verso i dropdown del Blocco 1.
