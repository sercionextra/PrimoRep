# Comprensione di notazione e trigger destro (Sexy Move)

L'utente ha compreso l'anatomia fondamentale del cubo (centri fissi, spigoli a due facce, angoli a tre facce) e ha dimostrato di saper interpretare ed eseguire la notazione standard (`R`, `U`, `R'`, `U'`) completando il ciclo di 6 iterazioni della *Sexy Move* su simulatore, riportando il cubo allo stato risolto. Questo stabilisce la base per gli algoritmi dei passaggi successivi.
