# PROMPT N. 3: Riformattazione Strutturata e Suddivisione in Paragrafi

> **METADATI DEL WORKFLOW:**
> - **Input Richiesto:** `{{INPUT_TESTO_PROMPT_3}}` (Utilizza `{{OUTPUT_PROMPT_2}}` se è stata effettuata la traduzione, oppure `{{OUTPUT_PROMPT_1}}` se la trascrizione originale era già in lingua italiana).
> - **Variabile di Output Generata:** `{{OUTPUT_PROMPT_3}}`
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 3: Riformattazione Strutturata e Suddivisione in Paragrafi`.

---

### DIRETTIVE OPERATIVE

Riscrivi il testo in italiano eliminando i ritorni a capo superflui e mettendo gli orari tra parentesi quadre (es.: "[12:45] testo x [12:52] testo y"), introducendo il grassetto per le parole più significative ed importanti e suddividendo il testo in paragrafi titolati.

---

### INPUT DATI PER L'ELABORAZIONE

**TESTO DA RIFORMATTARE:**
```text
{{INPUT_TESTO_PROMPT_3}}
```

---

### ISTRUZIONI DI OUTPUT:
1. Mostra a schermo l'intera risposta riformattata.
2. Memorizza la risposta nella variabile `{{OUTPUT_PROMPT_3}}`.
3. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 3: Riformattazione Strutturata e Suddivisione in Paragrafi`
