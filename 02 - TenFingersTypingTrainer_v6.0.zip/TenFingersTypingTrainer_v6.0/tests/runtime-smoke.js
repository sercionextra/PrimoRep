#!/usr/bin/env node
// Smoke test dei binding globali e dell'ordine di caricamento, senza DOM reale.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const listeners = {};
const sandbox = {
  console,
  document: {
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: (name, cb) => { (listeners['document:' + name] ||= []).push(cb); },
    createElement: () => ({ style: {}, classList: { add(){}, remove(){}, toggle(){} }, appendChild(){}, setAttribute(){}, addEventListener(){} }),
    body: { appendChild(){}, classList: { add(){}, remove(){}, toggle(){} } },
    documentElement: { style: { setProperty(){} }, classList: { add(){}, remove(){}, toggle(){} } }
  },
  localStorage: { getItem: () => null, setItem(){}, removeItem(){}, key(){ return null; }, get length(){ return 0; } },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  requestAnimationFrame: () => 0,
  cancelAnimationFrame: () => {},
  performance: { now: () => 0 },
  Blob: function(){},
  URL: { createObjectURL: () => '', revokeObjectURL(){} },
  navigator: {},
  alert(){}, confirm(){ return false; }, prompt(){ return null; }
};
sandbox.window = sandbox;
sandbox.window.addEventListener = (name, cb) => { (listeners['window:' + name] ||= []).push(cb); };
sandbox.window.speechSynthesis = null;
sandbox.window.localStorage = sandbox.localStorage;
sandbox.window.navigator = sandbox.navigator;
vm.createContext(sandbox);
const files = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];
for (const file of files) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  try { vm.runInContext(source, sandbox, { filename: file }); }
  catch (error) { console.error('FAIL loading', file, error); process.exit(1); }
  console.log('LOADED', file);
}
const result = vm.runInContext(`({
  lessons: EMBEDDED_LESSONS.length,
  phrases: EMBEDDED_LESSONS.reduce((n, lesson) => n + lesson.phrases.length, 0),
  classes: [typeof AudioEngine, typeof ProfileManager, typeof PhonemeEngine, typeof WindowManager, typeof TypingEngine, typeof VisualRenderer, typeof DictationEngine, typeof StatisticsManager, typeof AppController].every(type => type === 'function'),
  controllerMethods: [typeof AppController.prototype.start, typeof AppController.prototype.setupTypingListeners, typeof AppController.prototype.setupStatsUI, typeof AppController.prototype.replayDictation].every(type => type === 'function'),
  customParser: typeof parseCustomExercises === 'function',
  customExample: parseCustomExercises('=====Prova=====\\nprima riga\\nseconda riga\\n=====')[0].phrases[0],
  appStartupRegistered: true
})`, sandbox);
if (!result.classes || !result.controllerMethods || !result.customParser || result.lessons !== 71 || result.phrases !== 996 || !(listeners['window:DOMContentLoaded'] || []).length) {
  console.error('FAIL assertions', result);
  process.exit(1);
}
if (result.customExample !== 'prima riga seconda riga') {
  console.error('FAIL Custom parser semantics', result.customExample);
  process.exit(1);
}
console.log('PASS runtime smoke:', JSON.stringify(result));
