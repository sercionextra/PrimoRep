# PROMPT N. 2: Traduzione in Italiano con Allineamento Temporale

> **METADATI DEL WORKFLOW:**
> - **Input Richiesto:** `{{OUTPUT_PROMPT_1}}` (Trascrizione revisionata tecnicamente dal Prompt 1)
> - **Variabile di Controllo:** `{{LINGUA}}` (Acquisita dal file di Source Inline)
> - **Condizione di Esecuzione Mandatoria:**
>   - Se `{{LINGUA}}` è "IT", "italiano" o analogo: **NON ESEGUIRE QUESTO PROMPT**. Imposta automaticamente la variabile `{{INPUT_TESTO_PROMPT_3}} = {{OUTPUT_PROMPT_1}}` e passa direttamente al Prompt N. 3 (o Prompt N. 4).
>   - Se `{{LINGUA}}` è "EN", "inglese" o qualsiasi lingua diversa dall'italiano: **ESEGUI QUESTO PROMPT**.
> - **Variabile di Output Generata:** `{{OUTPUT_PROMPT_2}}`
> - **Destinazione Log:** Visualizza la risposta a schermo e accodala nel file `ANALISI_VIDEO.md` sotto l'intestazione `# RISPOSTA PROMPT 2: Traduzione in Italiano`.

---

### DIRETTIVE OPERATIVE

Traducilo in italiano conservando in inglese i termini tecnici e gergali. 
Rispetta il più possibile, se presenti, gli orari, comunque non alterarne i valori, eventualmente sposta solo i pezzi di frasi nell'intorno di quell'orario, per rispettare al massimo le corrispondenze temporali delle pronunce delle singole frasi.

---

### INPUT DATI PER L'ELABORAZIONE

**TESTO DA TRADURRE:**
```text
{{OUTPUT_PROMPT_1}}
```

---

### ISTRUZIONI DI OUTPUT:
1. Mostra a schermo l'intera risposta tradotta.
2. Memorizza la risposta nella variabile `{{OUTPUT_PROMPT_2}}`.
3. Accoda la risposta nel file `ANALISI_VIDEO.md` preceduta dal titolo:
   `# RISPOSTA PROMPT 2: Traduzione in Italiano`
