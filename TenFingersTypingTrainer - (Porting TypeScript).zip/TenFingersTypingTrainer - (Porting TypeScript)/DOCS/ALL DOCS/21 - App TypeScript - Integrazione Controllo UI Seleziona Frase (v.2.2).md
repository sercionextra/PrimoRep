# 21 - App TypeScript - Integrazione Controllo UI Seleziona Frase (v.2.2)

## 1. Analisi Tecnica e Obiettivo Architetturale

La scorciatoia di tastiera `CTRL+SHIFT+E` introdotta a partire dalla versione 2.0 consente l'accesso rapido alla finestra modale per la selezione mirata di lezione e frase. Tuttavia, da una prospettiva di usabilità ergonomica e accessibilità visiva, l'interfaccia utente (UI) non presentava un comando esplicito e visibile per richiamare tale funzionalità tramite puntatore (mouse/touch), costringendo l'utente a conoscere a priori la combinazione di tasti rapidi.

La **Release 2.2 (v.2.2)** implementa il controllo UI visibile richiesto, integrando due punti di contatto dedicati e coerenti con l'architettura dell'applicazione:
1. **Pulsante Dedicato nella Toolbar 2 (Azioni Frase)**: Inserimento del controllo visibile `#btnSelectPhraseModal` recante l'etichetta `📖 Vai a Frase...` e il tooltip esplicito `Seleziona Frase ed Esercizio (CTRL+SHIFT+E)`.
2. **Badge Interattivo del Conteggio Frasi nella Toolbar 1**: Trasformazione dell'elemento `#lblPhraseRange` in un badge interattivo (`cursor: pointer`, micro-interazione visiva `hover` con bordo d'accento e sfondo secondario) che apre direttamente la stessa maschera di selezione.
3. **Sincronizzazione Bidirezionale dei Controlli Toolbar**: Garanzia che la selezione di una lezione effettuata all'interno della modale aggiorni in tempo reale anche il selettore principale `#cboLessons` presente sulla barra degli strumenti.

*(Nota redazionale: il documento rispetta il divieto tassativo di formule o delimitatori LaTeX, esponendo numeri, identificatori e proprietà in testo semplice).*

---

## 2. Struttura del Progetto e File Modificati

| File Coinvolto | Percorso Workspace | Percorso Mirror Repository | Natura Modifica |
| :--- | :--- | :--- | :--- |
| **Applicazione Principale** | `/workspace/index_(v.2.2).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/index_(v.2.2).html` | Controllo UI visibile, CSS hover, binding eventi |
| **Guida Utente e Manuale** | `/workspace/help_(v.2.2).html` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/help_(v.2.2).html` | Sezione 3 aggiornata con nuovo controllo UI |
| **Modello Vettoriale SVG** | `/workspace/hands_anatomical_model_(v.2.2).svg` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/SRC/hands_anatomical_model_(v.2.2).svg` | Allineamento versione formale v.2.2 |
| **Documentazione Tecnica** | `/workspace/21 - App TypeScript - Integrazione Controllo UI Seleziona Frase (v.2.2).md` | `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/DOCS/ALL DOCS/` | Documento di rilascio e verifica architetturale |

---

## 3. Implementazione di Dettaglio

### 3.1 Markup HTML dei Nuovi Controlli Visibili

Nel blocco della barra degli strumenti (Toolbar):

```html
<!-- TOOLBAR 1: Badge Interattivo Conteggio Frasi -->
<div class="control-group">
  <button id="btnPrevLesson" class="btn btn-nav" title="Lezione precedente (CTRL+SHIFT+↑)">▲</button>
  <select id="cboLessons" class="select" style="min-width:210px;font-weight:600;"></select>
  <button id="btnToggleLessonSource" class="btn" style="font-size:0.75rem;padding:4px 8px;" title="Commuta tra le 70 lezioni standard e gli esercizi custom">📚 <span id="lblLessonSource">Standard</span></button>
  <button id="btnNextLesson" class="btn btn-nav" title="Lezione successiva (CTRL+SHIFT+↓)">▼</button>
  <span id="lblPhraseRange" style="font-size:0.8rem;color:var(--text-muted);font-weight:600;cursor:pointer;padding:3px 8px;border-radius:4px;border:1px solid transparent;transition:all 0.15s ease;" title="Clicca per aprire la finestra Seleziona Frase (CTRL+SHIFT+E)">(1 - 20)</span>
</div>

<!-- TOOLBAR 2: Pulsante Diretto nella Schiera Azioni Frase -->
<div class="toolbar-row">
  <div class="control-group">
    <button id="btnPrevPhrase" class="btn btn-nav" title="Frase precedente (CTRL+SHIFT+←)">◀</button>
    <button id="btnNextPhrase" class="btn btn-nav" title="Frase successiva (CTRL+SHIFT+→)">▶</button>
    <button id="btnSelectPhraseModal" class="btn" title="Seleziona Frase ed Esercizio (CTRL+SHIFT+E)" style="font-weight:700;">📖 Vai a Frase...</button>
    <button id="btnRandomPhrase" class="btn" title="Estrai frase casuale (CTRL+SHIFT+A)">🎲 Random Frase</button>
    <button id="btnRestartPhrase" class="btn" title="Riavvia esercizio / Pulisci (CTRL+SHIFT+X)">↺ Riavvia</button>
    <button id="btnRandomThisPhrase" class="btn" title="Rimescola frase corrente (CTRL+SHIFT+Z)">🔀 Rimescola</button>
    <button id="btnRandomAllChars" class="btn" title="Esercizio tutti i caratteri (CTRL+SHIFT+G)">🌐 All Chars</button>
  </div>
```

### 3.2 Regola di Stile CSS per Feedback Interattivo

```css
#lblPhraseRange:hover {
  background: var(--surface-alt);
  border-color: var(--accent-color) !important;
  color: var(--text-main) !important;
}
```

### 3.3 Gestione Eventi e Sincronizzazione State Machine (`AppController`)

All'interno di `setupSelectPhraseModal()`:
```javascript
// Registrazione listener su pulsante dedicato Toolbar 2 e badge Toolbar 1
document.getElementById("btnSelectPhraseModal")?.addEventListener("click", () => this.showSelectPhraseModal());
document.getElementById("lblPhraseRange")?.addEventListener("click", () => this.showSelectPhraseModal());
```

All'interno di `confirmSelectPhrase()`:
```javascript
// Sincronizzazione esplicita con il selettore a tendina delle lezioni nella toolbar
const toolbarLesson = document.getElementById("cboLessons") || document.getElementById("selLesson");
if (toolbarLesson) {
  toolbarLesson.value = String(lesIdx);
}
```

---

## 4. Considerazioni di Deployment, Accessibilità e Scalabilità

1. **Accessibilità Multi-Modale (A11y)**:
   La finestra può essere invocata indifferentemente con:
   - Scorciatoia globale da tastiera: `CTRL+SHIFT+E`.
   - Pulsante dedicato ad alta visibilità: `📖 Vai a Frase...`.
   - Click contestuale sul badge numerico: `Frase X di Y`.
2. **Coerenza di Stato**:
   Qualora l'utente cambi sia la Lezione che il numero di Frase dall'interno della modale, il sistema garantisce il riallineamento sia del motore dattilografico (`TypingEngine`), sia della UI principale (`cboLessons`), sia del titolo dell'esercizio (`lblExerciseTitle`), sia del badge di stato (`lblPhraseRange`), focalizzando immediatamente l'area di battitura per consentire l'avvio immediato dell'esercizio.
3. **Resilienza e Zero Regressioni**:
   Tutte le funzionalità preesistenti (filtri statistici, keycaps 3D, grafici cartesiani responsive a tutto schermo) mantengono la piena integrità operativa.

---

## 5. Report di Collaudo E2E con Google Chrome DevTools (CDP)

Il collaudo automatizzato su `index_(v.2.2).html` ha riportato i seguenti risultati:
- **Rilevamento Controlli**: Elemento `#btnSelectPhraseModal` presente e visibile con testo `📖 Vai a Frase...` e attributo `title` corretto. Elemento `#lblPhraseRange` con cursore di tipo `pointer`.
- **Test Apertura via Pulsante**: Click su `#btnSelectPhraseModal` apre correttamente la modale glassmorphism; chiusura con pulsante *Annulla* verificata.
- **Test Apertura via Badge**: Click su `#lblPhraseRange` apre la modale; chiusura con pulsante *&times;* verificata.
- **Test Sincronizzazione Lezione/Frase**: Selezione di Lezione 3 e Frase 3 all'interno della modale con click su *Conferma*: il motore registra Lezione 2 e Frase 2 (base zero), e la select della toolbar `#cboLessons` riflette immediatamente il valore `'2'`.
- **Totale Errori in Console DevTools**: **0**.
