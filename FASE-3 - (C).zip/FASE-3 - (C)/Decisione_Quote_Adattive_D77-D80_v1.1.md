# Decisione tecnica sulle quote adattive D77–D80 v1.1

**Documento:** Decisione_Quote_Adattive_D77-D80_v1.1  
**Stato:** decisione approvata e formalizzazione esecutiva  
**Baseline funzionale:** SPECIFICA TECNICA INTERROGAZIONE v1.0, sezione 10.3  
**Decisione utente:** adozione dell'Alternativa B  
**Budget globale approvato:** 10 punti percentuali  
**Tetto individuale:** 20% della quota base normalizzata della categoria  
**Ambito:** motore di selezione adattiva; nessuna modifica ai sorgenti in questo documento

---

## 1. Decisione e prevalenza

È approvata l'Alternativa B della verifica matematica D77–D80: budget globale fisso inferiore alla capacità aggregata massima dei tetti individuali, mantenendo distribuzione proporzionale ai deficit, redistribuzione iterativa e quota neutra.

Il budget globale è fissato a **10 punti percentuali della sessione** (`B = 0,10`). Il valore sostituisce, per la regola D77–D80, i 20 punti percentuali indicati nella sezione 10.3 della SPECIFICA TECNICA INTERROGAZIONE v1.0. La specifica v1.0 resta integra come fonte storica; questo documento costituisce l'addendum decisionale successivo e prevale limitatamente ai punti qui disciplinati.

Il tetto individuale resta invariato: **20% della quota base normalizzata** della categoria (`cap_i = 0,20 × b_i`). Il budget globale e il tetto individuale sono parametri distinti.

La scelta di 10 punti è una decisione progettuale approvata per rendere effettiva l'adattività senza saturare ordinariamente la capacità complessiva dei tetti. Non è un valore ricavato dalla baseline applicativa.

## 2. Variabili e normalizzazione

Si considerano esclusivamente le categorie disponibili per la sessione, cioè quelle che dispongono di elementi interrogabili sufficienti.

Per ogni categoria disponibile `i`:

- `q_i`: quota configurata originaria;
- `b_i`: quota base normalizzata sulle sole categorie disponibili;
- `r_i`: affidabilità categoria, compresa tra 0 e 1;
- `d_i = 1 - r_i`: deficit di affidabilità;
- `cap_i = 0,20 × b_i`: capacità massima del supplemento adattivo;
- `B = 0,10`: budget globale di correzione, pari a 10 punti percentuali.

La normalizzazione avviene prima del calcolo dei tetti:

`b_i = q_i / somma(q_j delle sole categorie disponibili)`

Pertanto `somma(b_i) = 1` e `somma(cap_i) = 0,20`. Il budget globale di 0,10 è quindi inferiore alla capacità aggregata massima di 0,20.

Le categorie indisponibili non partecipano alla normalizzazione, al riparto, al prelievo o alla quota neutra. La redistribuzione delle quote configurate delle categorie indisponibili segue la regola già prevista dalla sezione 10.4 della specifica funzionale e precede questo algoritmo.

## 3. Categorie eleggibili

Una categoria è eleggibile al supplemento adattivo se e solo se:

- è disponibile;
- `b_i > 0`;
- `d_i > 0`.

Le categorie con deficit nullo non ricevono supplemento adattivo e non partecipano alla redistribuzione proporzionale. Restano però categorie disponibili e partecipano alla distribuzione della quota neutra, quando questa si forma.

### 3.1 Caso senza deficit

Se tutte le categorie disponibili hanno `d_i = 0`, non si applica alcuna correzione:

- supplemento adattivo totale = 0;
- quota neutra = 0;
- prelievo dalle quote base = 0;
- quote finali = quote base normalizzate.

Questa eccezione evita una riallocazione artificiale quando non esiste alcuna mancanza di affidabilità da compensare.

## 4. Distribuzione proporzionale con tetto e redistribuzione iterativa

Si calcola il supplemento `s_i` mediante un riparto proporzionale ai deficit, con tetto individuale.

Inizializzazione:

- `s_i = 0` per ogni categoria;
- `residuo = B`;
- insieme attivo `E` = categorie eleggibili;
- capacità residua della categoria `i`: `capResidua_i = cap_i - s_i`.

A ogni iterazione:

1. Si calcola `pesoTotale = somma(d_i per i in E)`.
2. Per ogni categoria attiva si calcola la quota provvisoria `alloc_i = residuo × d_i / pesoTotale`.
3. Se una o più categorie hanno `alloc_i >= capResidua_i`, ciascuna di esse riceve soltanto la propria capacità residua, viene rimossa dall'insieme attivo e l'importo assegnato viene sottratto dal residuo.
4. Si ripete il calcolo sulle categorie ancora attive, usando il residuo aggiornato.
5. Se nessuna categoria raggiunge il tetto nell'iterazione, il residuo viene distribuito tra le categorie attive in proporzione ai rispettivi deficit e l'algoritmo termina.
6. L'algoritmo termina anche quando il residuo è zero o non esistono più categorie attive.

Il supplemento complessivo assegnato è `S = somma(s_i)`. Per costruzione:

- `0 <= s_i <= cap_i` per ogni categoria;
- `0 <= S <= B`.

La quota neutra complessiva è:

`N = B - S`

La quota neutra è quindi positiva soltanto quando il budget non può essere assegnato integralmente perché tutte le categorie eleggibili hanno raggiunto il proprio tetto. È distribuita in parti uguali tra tutte le categorie disponibili, comprese quelle con deficit nullo.

## 5. Prelievo e quote finali

Quando esiste almeno una categoria eleggibile, l'intero budget globale `B` viene prelevato dalle quote base normalizzate in proporzione alle stesse quote base:

`prelievo_i = B × b_i`

La quota neutra per categoria è:

`neutra_i = N / numeroCategorieDisponibili`

La quota finale è:

`finale_i = b_i - prelievo_i + s_i + neutra_i`

Equivalentemente:

`finale_i = 0,90 × b_i + s_i + neutra_i`

La formula si applica soltanto se esiste almeno una categoria eleggibile. Nel caso senza deficit definito al paragrafo 3.1 si mantengono direttamente le quote base.

### 5.1 Invarianti

Per ogni sessione con almeno una categoria eleggibile:

- somma dei prelievi = `B`;
- somma dei supplementi = `S`;
- somma delle quote neutre = `N = B - S`;
- somma delle quote finali = `1 - B + S + N = 1`, cioè 100%;
- nessuna quota finale è negativa;
- nessun supplemento supera il 20% della quota base normalizzata;
- la quota neutra non concorre al tetto individuale del supplemento.

Nel caso senza deficit, le quote finali coincidono con le quote base normalizzate e sommano comunque al 100%.

## 6. Esempi numerici vincolanti

I valori sono espressi in punti percentuali. Gli esempi assumono quattro categorie disponibili con quota base del 25% ciascuna, salvo diversa indicazione.

### 6.1 Tutte le categorie hanno deficit positivo

Deficit: A = 100%, B = 75%, C = 50%, D = 25%.

Il budget di 10 punti viene distribuito in proporzione ai deficit: A 4, B 3, C 2, D 1. Ogni tetto individuale è 5 punti, quindi nessun tetto viene raggiunto.

| Categoria | Base | Prelievo | Supplemento | Neutra | Finale |
|---|---:|---:|---:|---:|---:|
| A | 25,00 | 2,50 | 4,00 | 0,00 | 26,50 |
| B | 25,00 | 2,50 | 3,00 | 0,00 | 25,50 |
| C | 25,00 | 2,50 | 2,00 | 0,00 | 24,50 |
| D | 25,00 | 2,50 | 1,00 | 0,00 | 23,50 |
| **Totale** | **100,00** | **10,00** | **10,00** | **0,00** | **100,00** |

Il risultato dimostra che le quote finali reagiscono ai diversi deficit, senza saturare tutti i tetti.

### 6.2 Una sola categoria eleggibile

Deficit: A = 100%; B, C e D = 0%. Ogni categoria ha base 25% e tetto 5 punti.

A riceve il proprio tetto di 5 punti. Il residuo di 5 punti diventa quota neutra, pari a 1,25 punti per ciascuna delle quattro categorie. Il prelievo resta 2,5 punti per categoria.

| Categoria | Base | Prelievo | Supplemento | Neutra | Finale |
|---|---:|---:|---:|---:|---:|
| A | 25,00 | 2,50 | 5,00 | 1,25 | 28,75 |
| B | 25,00 | 2,50 | 0,00 | 1,25 | 23,75 |
| C | 25,00 | 2,50 | 0,00 | 1,25 | 23,75 |
| D | 25,00 | 2,50 | 0,00 | 1,25 | 23,75 |
| **Totale** | **100,00** | **10,00** | **5,00** | **5,00** | **100,00** |

### 6.3 Tutti i deficit sono nulli

Deficit: A = B = C = D = 0%.

Non si applica la correzione e le quote finali restano 25%, 25%, 25%, 25%. Non si effettua alcun prelievo e non si genera quota neutra.

### 6.4 Redistribuzione dopo il raggiungimento dei tetti

Quote base: A 10%, B 20%, C 30%, D 40%. Deficit: A 100%, B 50%, C 25%, D 0%.

Tetti: A 2, B 4, C 6, D 8 punti. Il riparto iniziale proporzionale assegna ad A più del suo tetto; A viene fissata a 2 e rimossa. Il residuo viene ripartito tra B e C; B raggiunge il tetto a 4 e viene rimossa. C riceve i 4 punti residui. Il supplemento finale è A 2, B 4, C 4, D 0, per un totale di 10 punti.

Il prelievo è A 1, B 2, C 3, D 4 punti. Non resta quota neutra.

| Categoria | Base | Prelievo | Supplemento | Neutra | Finale |
|---|---:|---:|---:|---:|---:|
| A | 10,00 | 1,00 | 2,00 | 0,00 | 11,00 |
| B | 20,00 | 2,00 | 4,00 | 0,00 | 22,00 |
| C | 30,00 | 3,00 | 4,00 | 0,00 | 31,00 |
| D | 40,00 | 4,00 | 0,00 | 0,00 | 36,00 |
| **Totale** | **100,00** | **10,00** | **10,00** | **0,00** | **100,00** |

## 7. Precisione, arrotondamento e conteggi interi

Il calcolo delle quote deve usare aritmetica decimale controllata, senza arrotondamenti intermedi che alterino il budget o i tetti.

Regole:

1. Normalizzare le quote configurate sulle sole categorie disponibili.
2. Calcolare deficit, tetti e riparto con precisione decimale controllata.
3. Conservare separatamente prelievo, supplemento e quota neutra.
4. Correggere l'eventuale residuo numerico di precisione in modo deterministico, senza superare i tetti.
5. Convertire le quote finali in conteggi interi con il metodo dei maggiori resti.
6. In caso di parità dei resti, applicare nell'ordine: maggiore debolezza, minore affidabilità, ordine canonico delle categorie.

Il metodo dei maggiori resti deve garantire che la somma dei conteggi sia esattamente il numero di domande della sessione. La conversione in conteggi interi non deve modificare retroattivamente le quote percentuali calcolate.

## 8. Categorie indisponibili

Le categorie senza elementi sufficienti sono escluse prima della normalizzazione. Le quote configurate originarie delle categorie disponibili vengono rinormalizzate per ottenere `b_i`.

Tetti, budget e prelievo sono calcolati sulle quote base normalizzate. La quota neutra viene distribuita soltanto tra le categorie disponibili. Una categoria che torna disponibile rientra dalla sessione successiva, con lo storico e l'affidabilità già conservati.

## 9. Test di accettazione D77–D80

Il motore deve superare almeno i seguenti test deterministici:

1. Quattro categorie con quote uguali e deficit 100%, 75%, 50%, 25%: supplementi 4, 3, 2, 1 punti; quote finali 26,5%, 25,5%, 24,5%, 23,5%.
2. Una sola categoria eleggibile su quattro: supplemento al tetto della categoria, residuo neutro equamente distribuito tra tutte le disponibili.
3. Tutti i deficit nulli: nessun prelievo, nessun supplemento, nessuna quota neutra, quote base invariate.
4. Quote base 10%, 20%, 30%, 40% e deficit 100%, 50%, 25%, 0%: supplementi 2, 4, 4, 0 punti.
5. Nessun supplemento supera il 20% della quota base normalizzata.
6. Budget prelevato non superiore a 10 punti e, quando esiste almeno una categoria eleggibile, pari a 10 punti.
7. Supplemento più quota neutra pari al prelievo.
8. Somma delle quote finali pari esattamente al 100% prima della conversione in conteggi.
9. Nessuna quota negativa.
10. Categorie indisponibili escluse da normalizzazione, riparto e quota neutra.
11. Parità e arrotondamenti riproducibili su esecuzioni ripetute.
12. Conteggi interi con somma esattamente uguale al numero di domande.
13. Modifica delle affidabilità durante una sessione non altera le quote già congelate nella sessione.
14. Budget, tetto e versione algoritmo sono salvati nello snapshot della sessione per consentire riproducibilità.

## 10. Versionamento e impatto

Questa decisione è identificata come `adaptiveQuotaAlgorithmVersion: "1.1"`.

Le sessioni nuove usano budget globale 10 punti percentuali. Le sessioni già create o sospese mantengono lo snapshot dell'algoritmo e dei parametri con cui sono state avviate; non vengono ricalcolate retroattivamente.

La specifica funzionale v1.0 non viene modificata. Questo addendum la integra e la prevale limitatamente al budget globale, al trattamento dei deficit nulli e alla definizione esecutiva della quota neutra.

Nessun sorgente è stato modificato. Prima dell'implementazione restano da completare gli altri punti progettuali indipendenti (catalogo QWERTY, seed casuale, calendario di consolidamento, recovery e integrazione UI).
