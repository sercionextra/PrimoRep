// =======================================================
// File: /workspace/main_B_(v.2.32).js
// Versione: 2.32
// Data rilascio: 08/10/2026
// Note di rilascio v.2.32:
//   1. Implementata Gestione Avanzata del Focus e del Ciclo di Vita delle Dropdown List Native (<select>):
//      - Rilevamento conferma della stessa voce sia via mouse (2° click) che via tastiera (Invio o Spazio).
//      - Gestione robusta del tasto ESC con intercettazione combinata keydown/keyup e debounce a 150ms.
//      - Prevenzione rimbalzo ed errata riapertura post-change tramite flag justChanged (100ms).
//      - Disaccoppiamento asincrono a 60ms per consentire la corretta chiusura dei popup nativi dell'OS.
//   2. Risolto Edge Case Input Occultato: garantita la prosecuzione fluida della digitazione
//      anche con textarea nascosta (display: none), tramite defocus mirato (blur) sul body.
//   3. Auto-Refocus UI: riporta istantaneamente il focus sulla casella di testo
//      dopo l'interazione con Select, Checkbox, Slider e Bottoni della toolbar.
//   4. Conservate funzionalità v.2.30 (Scrubber temporale, Validation Asimmetrica, Inversione).
// =======================================================

// STATISTICS MANAGER (Histogram & Speed Chart con Filtro Temporale Range)
class StatisticsManager {
  constructor(profileMgr) {
    this.profileMgr = profileMgr;
    this.sortMode = "freqRel"; // freqRel, freqAss, errRel, errAss, ditoRel, ditoAss
    this.speedMetric = "bpm"; // bpm, chars, errRel, errAss
    this.filterTypes = [1, 2, 3, 4, 5, 6, 7, 8];
    this.selectedSampleIndices = new Set();
    this.currentFilteredSamples = [];
  }

  renderHistogram() {
    const container = document.getElementById("statsHistogramSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Caratteri || p.Caratteri.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun dato statistico disponibile</div>';
      return;
    }

    // Process data
    let list = p.Caratteri.map((c) => ({
      char: String.fromCharCode(c.CharUnicode),
      freq: c.Frequenza || 0,
      err: c.Errori || 0,
      errRate: c.Frequenza > 0 ? (c.Errori / c.Frequenza) * 100 : 0,
      finger: (KEY_MAP[String.fromCharCode(c.CharUnicode)] || {}).finger || 0,
    }));

    // Sorting
    const isPerDito =
      this.sortMode === "ditoRel" || this.sortMode === "ditoAss";
    if (this.sortMode === "freqRel" || this.sortMode === "freqAss") {
      list.sort((a, b) => b.freq - a.freq);
    } else if (this.sortMode === "errRel") {
      list.sort((a, b) => b.errRate - a.errRate);
    } else if (this.sortMode === "errAss") {
      list.sort((a, b) => b.err - a.err);
    } else if (this.sortMode === "ditoRel") {
      list.sort(
        (a, b) => (a.finger || 99) - (b.finger || 99) || b.errRate - a.errRate,
      );
    } else if (this.sortMode === "ditoAss") {
      list.sort((a, b) => (a.finger || 99) - (b.finger || 99) || b.err - a.err);
    }

    const maxFreq = Math.max(1, ...list.map((x) => x.freq));
    const maxErr = Math.max(1, ...list.map((x) => x.err));
    const maxErrRate = Math.max(0.1, ...list.map((x) => x.errRate));

    const isErrRelMode =
      this.sortMode === "errRel" || this.sortMode === "ditoRel";
    const isErrAssMode =
      this.sortMode === "errAss" || this.sortMode === "ditoAss";

    const activeMax = isErrRelMode
      ? maxErrRate
      : isErrAssMode
        ? maxErr
        : maxFreq;

    // Risoluzione Dinamica : altezza determinata esattamente dallo spazio residuo della sezione
    const containerH = container.clientHeight || 200;
    const height = Math.max(140, containerH);

    const chartBaseline = height - 26;
    const topLimit = isPerDito ? 24 : 14;
    const maxBarH = Math.max(20, chartBaseline - topLimit - 6);

    const fingerMeta = {
      1: {
        name: "Mignolo Sx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
      2: {
        name: "Anulare Sx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      3: {
        name: "Medio Sx",
        color: "#10b981",
        fill: "rgba(16, 185, 129, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      4: {
        name: "Indice Sx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      5: {
        name: "Pollice Sx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      6: {
        name: "Pollice Dx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      7: {
        name: "Indice Dx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      8: {
        name: "Medio Dx",
        color: "#10b981",
        fill: "rgba(16, 185, 129, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      9: {
        name: "Anulare Dx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      10: {
        name: "Mignolo Dx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
    };

    const barPitch = 36;
    const barWidth = 24;
    const startX = 20;
    const width = Math.max(760, list.length * barPitch + 40);

    let svg = `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" style="width:${width}px;min-width:${width}px;height:${height}px;display:block;">`;

    if (isPerDito) {
      let currentFinger = null;
      let groupStartIndex = 0;
      let groups = [];

      list.forEach((item, idx) => {
        if (item.finger !== currentFinger) {
          if (currentFinger !== null) {
            groups.push({
              finger: currentFinger,
              start: groupStartIndex,
              count: idx - groupStartIndex,
            });
          }
          currentFinger = item.finger;
          groupStartIndex = idx;
        }
      });
      if (currentFinger !== null) {
        groups.push({
          finger: currentFinger,
          start: groupStartIndex,
          count: list.length - groupStartIndex,
        });
      }

      groups.forEach((grp) => {
        const meta = fingerMeta[grp.finger] || {
          name: `Dito ${grp.finger}`,
          color: "#64748b",
          fill: "rgba(100, 116, 139, 0.08)",
          stroke: "rgba(100, 116, 139, 0.5)",
        };
        const gx = startX + grp.start * barPitch - 5;
        const gw = grp.count * barPitch;
        const gy = 4;
        const gh = chartBaseline - gy + 22;

        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" rx="6" fill="${meta.fill}" stroke="${meta.stroke}" stroke-width="1.6" />`;
        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="17" rx="5" fill="${meta.color}" opacity="0.9" />`;
        svg += `<text x="${gx + gw / 2}" y="${gy + 12.5}" font-size="10" font-weight="700" fill="#ffffff" text-anchor="middle">${meta.name}</text>`;
      });
    }

    svg += `<line x1="6" y1="${chartBaseline}" x2="${width - 6}" y2="${chartBaseline}" stroke="var(--border-color)" stroke-width="1.5" />`;

    list.forEach((item, idx) => {
      const x = startX + idx * barPitch;
      const meta = fingerMeta[item.finger] || { color: "#3b82f6" };
      let primaryVal = item.freq;
      let displayVal = `${item.freq}`;

      if (isErrRelMode) {
        primaryVal = item.errRate;
        displayVal = `${item.errRate.toFixed(1)}%`;
      } else if (isErrAssMode) {
        primaryVal = item.err;
        displayVal = `${item.err}`;
      }

      const barH = activeMax > 0 ? (primaryVal / activeMax) * maxBarH : 0;
      const y = chartBaseline - barH;
      const barColor = isPerDito
        ? meta.color
        : isErrRelMode || isErrAssMode
          ? "#ef4444"
          : "#3b82f6";

      svg += `<g class="hist-bar" data-char="${htmlEscape(item.char)}" data-freq="${item.freq}" data-err="${item.err}" data-rate="${item.errRate.toFixed(1)}" data-finger="${meta.name || ""}">`;

      if (barH > 0) {
        svg += `<rect x="${x}" y="${y}" width="${barWidth}" height="${barH}" rx="3" fill="${barColor}" opacity="0.85" />`;
      }

      if (!isErrRelMode && !isErrAssMode && item.err > 0) {
        const errH = (item.err / maxFreq) * maxBarH;
        const errY = chartBaseline - errH;
        svg += `<rect x="${x}" y="${errY}" width="${barWidth}" height="${errH}" rx="3" fill="#ef4444" opacity="0.9" />`;
      }

      svg += `<text x="${x + barWidth / 2}" y="${chartBaseline + 17}" font-size="12.5" font-weight="700" text-anchor="middle" fill="var(--text-main)">${htmlEscape(item.char === " " ? "␣" : item.char)}</text>`;

      const labelY = Math.max(isPerDito ? 31 : 13, y - 4);
      svg += `<text x="${x + barWidth / 2}" y="${labelY}" font-size="9.5" font-weight="600" text-anchor="middle" fill="var(--text-muted)">${displayVal}</text>`;
      svg += `</g>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    container.querySelectorAll(".hist-bar").forEach((bar) => {
      bar.addEventListener("mouseenter", () => {
        const c = bar.getAttribute("data-char");
        const f = bar.getAttribute("data-freq");
        const er = bar.getAttribute("data-err");
        const rt = bar.getAttribute("data-rate");
        const d = bar.getAttribute("data-finger");
        const dStr = d ? ` | Dito: ${d}` : "";
        document.getElementById("histTooltipText").innerText =
          `Tasto: "${c}" | Frequenza: ${f} | Errori: ${er} (${rt}%)${dStr}`;
      });
    });
  }

  getSampleVal(s) {
    if (this.speedMetric === "bpm") return s.BattuteMinuto || 0;
    if (this.speedMetric === "chars") return s.NumCaratteri || 0;
    if (this.speedMetric === "errRel")
      return s.NumCaratteri > 0 ? (s.NumErrori / s.NumCaratteri) * 100 : 0;
    if (this.speedMetric === "errAss") return s.NumErrori || 0;
    return s.BattuteMinuto || 0;
  }

  clearSelection() {
    this.selectedSampleIndices.clear();
    this.selectionState = 0;
    const selRect = document.getElementById("chartSelectionRect");
    if (selRect) selRect.style.display = "none";
    document.querySelectorAll(".speed-point").forEach((dot) => {
      dot.classList.remove("selected");
      dot.setAttribute("fill", "#3b82f6");
      dot.setAttribute("r", "4");
    });

    const btnClearSel = document.getElementById("btnClearSelection");
    const btnClearNotSel = document.getElementById("btnClearNotSelected");
    if (btnClearSel) btnClearSel.style.visibility = "hidden";
    if (btnClearNotSel) btnClearNotSel.style.visibility = "hidden";

    if (this.currentFilteredSamples.length > 0) {
      const vals = this.currentFilteredSamples.map((s) => this.getSampleVal(s));
      const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
      document.getElementById("lblMediaValori").innerHTML =
        `${avg} (globale su ${this.currentFilteredSamples.length} campioni)`;
    }
  }

  // =======================================================
  // PARSER E VALIDATORE RANGE DATA-ORA
  // Regole:
  //   1. Campi A, B, C, D non obbligatori.
  //   2. Se mancano le date, gli orari si riferiscono alla data corrente.
  //   3. Se mancano gli orari si intendono tutti gli orari della giornata (date incluse).
  //   4. Se mancano info su FINE: estende fino ad ora.
  //   5. Se mancano info su INIZIO: estende dall'inizio dei dati (1970-01-01 00:00:00).
  //   6. Se data su un estremo e sull'altro solo orario: occorre la data su entrambi, altrimenti non valido.
  //   7. Se solo orario di fine: tutti i campioni del giorno corrente antecedenti a quell'orario.
  //   8. Se solo orario di inizio: tutti i campioni del giorno corrente successivi a quell'orario.
  //   9. Inversione: se Inizio > Fine: non valido (Opzione 1: blocco con avviso visivo).
  // =======================================================
  parseDateTimeRange() {
    const elDateA = document.getElementById("filterStartDate");
    const elTimeB = document.getElementById("filterStartTime");
    const elDateC = document.getElementById("filterEndDate");
    const elTimeD = document.getElementById("filterEndTime");
    const msgEl = document.getElementById("lblDateRangeValidationMessage");

    const clearInputErrors = () => {
      [elDateA, elTimeB, elDateC, elTimeD].forEach((inp) => {
        if (inp) {
          inp.classList.remove("input-field-error");
          inp.classList.toggle("filter-active", inp.value.trim().length > 0);
        }
      });
      if (msgEl) {
        msgEl.style.display = "none";
        msgEl.textContent = "";
      }
    };

    // Helper: assegna la classe di errore e rimuove contestualmente lo stato attivo
    const markError = (inp) => {
      if (!inp) return;
      inp.classList.add("input-field-error");
      inp.classList.remove("filter-active");
    };

    if (!elDateA || !elTimeB || !elDateC || !elTimeD) {
      return {
        isValid: true,
        hasFilter: false,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    clearInputErrors();

    const valA = elDateA.value.trim(); // YYYY-MM-DD
    const valB = elTimeB.value.trim(); // HH:mm
    const valC = elDateC.value.trim(); // YYYY-MM-DD
    const valD = elTimeD.value.trim(); // HH:mm

    const hasA = valA.length > 0;
    const hasB = valB.length > 0;
    const hasC = valC.length > 0;
    const hasD = valD.length > 0;

    // Caso 1: Nessun filtro attivo
    if (!hasA && !hasB && !hasC && !hasD) {
      return {
        isValid: true,
        hasFilter: false,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    // Regola 6: Vincolo asimmetrico
    if (hasA && hasD && !hasC) {
      markError(elDateC);
      markError(elTimeD);
      if (msgEl) {
        msgEl.textContent =
          "⚠ Specificare la data di fine per applicare il filtro temporale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    if (hasC && hasB && !hasA) {
      markError(elDateA);
      markError(elTimeB);
      if (msgEl) {
        msgEl.textContent =
          "⚠ Specificare la data di inizio per applicare il filtro temporale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    const todayObj = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const todayStr = `${todayObj.getFullYear()}-${pad(todayObj.getMonth() + 1)}-${pad(todayObj.getDate())}`;

    let startTs = 0;
    let endTs = todayObj.getTime();

    const areDatesMissing = !hasA && !hasC;

    if (areDatesMissing) {
      if (hasB && !hasD) {
        startTs = new Date(`${todayStr}T${valB}:00`).getTime();
        endTs = todayObj.getTime();
      } else if (!hasB && hasD) {
        startTs = new Date(`${todayStr}T00:00:00`).getTime();
        endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
      } else if (hasB && hasD) {
        startTs = new Date(`${todayStr}T${valB}:00`).getTime();
        endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
      }
    } else {
      if (hasA) {
        const timePart = hasB ? `${valB}:00` : "00:00:00";
        startTs = new Date(`${valA}T${timePart}`).getTime();
      } else {
        startTs = 0;
      }

      if (hasC) {
        const timePart = hasD ? `${valD}:59.999` : "23:59:59.999";
        endTs = new Date(`${valC}T${timePart}`).getTime();
      } else {
        endTs = todayObj.getTime();
      }
    }

    // Regola 9: Inversione cronologica (Inizio > Fine)
    if (startTs > endTs) {
      // Nel caso specificato (es. 06/10/2026 19:51 > 06/10/2026 19:48), vengono accesi
      // in ERRORE ROSSO tutti e 4 i controlli (Data Inizio, Ora Inizio, Data Fine, Ora Fine)
      if (hasA) markError(elDateA);
      if (hasB) markError(elTimeB);
      if (hasC) markError(elDateC);
      if (hasD) markError(elTimeD);

      if (!hasA && hasB) markError(elTimeB);
      if (!hasC && hasD) markError(elTimeD);

      if (msgEl) {
        msgEl.textContent =
          "⚠ La data/ora iniziale non può essere successiva a quella finale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    return { isValid: true, hasFilter: true, minTs: startTs, maxTs: endTs };
  }

  // Rendering Grafico Cronologico Velocità con Filtro Temporale e Giorno della Settimana
  renderSpeedChart() {
    const container = document.getElementById("statsSpeedSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Campioni || p.Campioni.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione di velocità registrato</div>';
      this.clearSelection();
      return;
    }

    // Valutazione range temporale
    const rangeResult = this.parseDateTimeRange();
    if (!rangeResult.isValid) {
      // In caso di validazione fallita (asimmetria o inversione), sospendiamo l'applicazione del filtro
      // e non modifichiamo il set campioni, consentendo all'utente di correggere i campi
      return;
    }

    let filtered = p.Campioni.filter((s) =>
      this.filterTypes.includes(s.TipoCampione),
    );

    // Applicazione del filtro data-ora
    if (rangeResult.hasFilter) {
      filtered = filtered.filter((s) => {
        // Fallback per campioni legacy privi di DataOra: 1970-01-01 00:00:00 (timestamp 0)
        let sampleTs = 0;
        if (s.DataOra) {
          sampleTs = new Date(s.DataOra).getTime();
          if (isNaN(sampleTs)) sampleTs = 0;
        }
        return sampleTs >= rangeResult.minTs && sampleTs <= rangeResult.maxTs;
      });
    }

    this.currentFilteredSamples = filtered;
    if (filtered.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione corrisponde ai filtri selezionati</div>';
      this.clearSelection();
      return;
    }

    // Risoluzione Dinamica : assorbimento al 100% dell'altezza residua con maggiore risoluzione
    const W = Math.max(760, container.clientWidth || 760);
    const containerH = container.clientHeight || 200;
    const H = Math.max(140, containerH);

    const padL = 48;
    const padR = 25;
    const padT = 16;
    const padB = 26;
    const plotW = W - padL - padR;
    const plotH = Math.max(20, H - padT - padB);

    const values = filtered.map((s) => this.getSampleVal(s));
    const maxVal = Math.max(10, Math.ceil(Math.max(...values) * 1.15));

    const pts = filtered.map((s, idx) => {
      const x = padL + (idx / Math.max(1, filtered.length - 1)) * plotW;
      const y = padT + plotH - (this.getSampleVal(s) / maxVal) * plotH;
      return { x, y, sample: s, val: this.getSampleVal(s), idx };
    });

    let pathD = "";
    pts.forEach((pt, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${pt.x},${pt.y} `;
    });

    // L'SVG scala ed occupa sempre il 100% dello spazio verticale del box
    let svg = `<svg id="speedSvgPlot" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:100%;cursor:crosshair;user-select:none;display:block;">`;

    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="10" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    svg += `<path d="${pathD}" fill="none" stroke="#3b82f6" stroke-width="2.5" />`;
    svg += `<rect id="chartSelectionRect" x="0" y="${padT}" width="0" height="${plotH}" fill="rgba(59, 130, 246, 0.22)" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4 3" style="display:none;pointer-events:none;" />`;
    svg += `<line id="chartCrosshairH" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2" style="display:none;pointer-events:none;" />`;
    svg += `<text id="chartCrosshairYLabel" fill="#ef4444" font-size="11" font-weight="800" text-anchor="end" style="display:none;pointer-events:none;"></text>`;
    svg += `<line id="chartPreviewVLine" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3" style="display:none;pointer-events:none;" />`;

    const italianWeekDays = [
      "domenica",
      "lunedì",
      "martedì",
      "mercoledì",
      "giovedì",
      "venerdì",
      "sabato",
    ];

    pts.forEach((pt) => {
      const isSel = this.selectedSampleIndices.has(pt.sample.Index);
      const dotCls = isSel ? "speed-point selected" : "speed-point";

      // Formattazione data con giorno della settimana in italiano
      let dateFormatted = "Storico pre-v.2.30";
      if (pt.sample.DataOra) {
        const d = new Date(pt.sample.DataOra);
        if (!isNaN(d.getTime())) {
          const dayName = italianWeekDays[d.getDay()];
          const timeClean = pt.sample.DataOra.replace("T", " ");
          dateFormatted = `${dayName} ${timeClean}`;
        } else {
          dateFormatted = pt.sample.DataOra.replace("T", " ");
        }
      }

      svg += `<circle class="${dotCls}" cx="${pt.x}" cy="${pt.y}" r="${isSel ? 6 : 4}" fill="${isSel ? "#f59e0b" : "#3b82f6"}" stroke="#ffffff" stroke-width="1.5" data-idx="${pt.sample.Index}" data-val="${Math.round(pt.val)}" data-err="${pt.sample.NumErrori}" data-len="${pt.sample.NumCaratteri}" data-title="${htmlEscape(pt.sample.Esercizio || "")}" data-time="${htmlEscape(dateFormatted)}" />`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    const svgEl = document.getElementById("speedSvgPlot");
    if (!svgEl) return;

    // Helper di formattazione per lo scrubber temporale
    const formatScrubberDate = (sample) => {
      if (!sample || !sample.DataOra) return "Data non disponibile";
      const d = new Date(sample.DataOra);
      if (isNaN(d.getTime())) return "Data non disponibile";
      const dayName = italianWeekDays[d.getDay()];
      const [datePart, timePart] = sample.DataOra.split("T");
      return `${datePart} - ${timePart} ( ${dayName} )`;
    };

    const scrubberLabel = document.getElementById("lblChartScrubberTimestamp");
    if (scrubberLabel) {
      scrubberLabel.textContent = "Sposta il mouse sul grafico";
    }

    svgEl.querySelectorAll(".speed-point").forEach((dot) => {
      dot.addEventListener("mouseenter", () => {
        // Rimuove lo stato ispezionato da tutti gli altri campioni
        svgEl
          .querySelectorAll(".speed-point.inspected")
          .forEach((el) => el.classList.remove("inspected"));
        // Aggiunge priorità visiva verde al campione corrente (v.2.32)
        dot.classList.add("inspected");

        const idx = dot.getAttribute("data-idx");
        const val = dot.getAttribute("data-val");
        const err = parseInt(dot.getAttribute("data-err") || "0", 10);
        const len = parseInt(dot.getAttribute("data-len") || "0", 10);
        const title = dot.getAttribute("data-title");
        const timeStr = dot.getAttribute("data-time") || "";
        const errPct = len > 0 ? ((err / len) * 100).toFixed(1) + "%" : "0.0%";

        // Applicazione colore dinamico temattizzato (var(--success-color)) sul valore testuale (v.2.32)
        document.getElementById("speedInspectText").innerHTML =
          `Campione #${idx} | Data: ${timeStr} | Valore: <span style="color: var(--success-color); font-weight: 800;">${val}</span> | Errori: ${err} (${errPct}) | Caratteri: ${len} | Esercizio: "${title}"`;
      });
    });

    this.selectionState = 0;
    let startSvgX = 0;

    const getSvgCoords = (e) => {
      const pt = svgEl.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      return pt.matrixTransform(svgEl.getScreenCTM().inverse());
    };

    const applySelection = (selPts) => {
      this.selectedSampleIndices = new Set(selPts.map((p) => p.sample.Index));
      svgEl.querySelectorAll(".speed-point").forEach((dot) => {
        const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
        if (this.selectedSampleIndices.has(sIdx)) {
          dot.classList.add("selected");
          dot.setAttribute("fill", "#f59e0b");
          dot.setAttribute("r", "6");
        } else {
          dot.classList.remove("selected");
          dot.setAttribute("fill", "#3b82f6");
          dot.setAttribute("r", "4");
        }
      });

      if (selPts.length > 0) {
        const selVals = selPts.map((p) => p.val);
        const avg = Math.round(
          selVals.reduce((a, b) => a + b, 0) / selVals.length,
        );
        const countTxt =
          selPts.length === 1
            ? "1 campione selezionato"
            : `${selPts.length} campioni selezionati`;
        document.getElementById("lblMediaValori").innerHTML =
          `<span style="color:#f59e0b;font-weight:800;">${avg}</span> (su ${countTxt})`;

        const btnClearSel = document.getElementById("btnClearSelection");
        const btnClearNotSel = document.getElementById("btnClearNotSelected");
        const countNot = filtered.length - selPts.length;

        if (btnClearSel) {
          btnClearSel.style.visibility = "visible";
          document.getElementById("lblSelectedCount").innerText = selPts.length;
        }
        if (btnClearNotSel) {
          btnClearNotSel.style.visibility = countNot > 0 ? "visible" : "hidden";
          document.getElementById("lblNotSelectedCount").innerText = countNot;
        }
      } else {
        this.clearSelection();
      }
    };

    svgEl.addEventListener("mousemove", (e) => {
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const curY = Math.max(padT, Math.min(padT + plotH, svgPt.y));

      // Stima del campione più vicino lungo l'asse X per la riga azzurra
      if (pts.length > 0 && scrubberLabel) {
        let closestPt = pts[0];
        let minDist = Math.abs(pts[0].x - curX);
        for (let i = 1; i < pts.length; i++) {
          const dist = Math.abs(pts[i].x - curX);
          if (dist < minDist) {
            minDist = dist;
            closestPt = pts[i];
          } else if (pts[i].x > curX) {
            break; // Ottimizzazione O(N): pts è ordinato monotonicamente per x
          }
        }
        scrubberLabel.textContent = formatScrubberDate(closestPt.sample);
      }

      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH && crossY) {
        const yVal = Math.round(maxVal - ((curY - padT) / plotH) * maxVal);
        crossH.setAttribute("x1", padL);
        crossH.setAttribute("y1", curY);
        crossH.setAttribute("x2", W - padR);
        crossH.setAttribute("y2", curY);
        crossH.style.display = "block";

        crossY.setAttribute("x", padL - 8);
        crossY.setAttribute("y", curY + 4);
        crossY.textContent = yVal;
        crossY.style.display = "block";
      }

      const vLine = document.getElementById("chartPreviewVLine");
      const selRect = document.getElementById("chartSelectionRect");

      if (this.selectionState === 0) {
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      } else if (this.selectionState === 1) {
        if (vLine) vLine.style.display = "none";
        const minX = Math.max(padL, Math.min(startSvgX, curX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, curX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(2, selW));
          selRect.style.display = "block";
        }

        let previewPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          previewPts = [closest];
        } else {
          previewPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        svgEl.querySelectorAll(".speed-point").forEach((dot) => {
          const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
          if (previewPts.some((p) => p.sample.Index === sIdx)) {
            dot.setAttribute("fill", "#f59e0b");
            dot.setAttribute("r", "6");
          } else {
            dot.setAttribute("fill", "#3b82f6");
            dot.setAttribute("r", "4");
          }
        });
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      const vLine = document.getElementById("chartPreviewVLine");
      if (vLine && this.selectionState === 0) vLine.style.display = "none";

      if (scrubberLabel) {
        scrubberLabel.textContent = "Sposta il mouse sul grafico";
      }

      // Ripristino stato ispezionato e testuale all'uscita dal grafico (v.2.32)
      svgEl
        .querySelectorAll(".speed-point.inspected")
        .forEach((el) => el.classList.remove("inspected"));
      const inspectText = document.getElementById("speedInspectText");
      if (inspectText) {
        inspectText.innerHTML =
          "Passa con il mouse sui campioni per le coordinate";
      }
    });

    svgEl.addEventListener("click", (e) => {
      if (e.button !== 0) return;
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const selRect = document.getElementById("chartSelectionRect");
      const vLine = document.getElementById("chartPreviewVLine");

      if (this.selectionState === 0) {
        this.selectionState = 1;
        startSvgX = curX;
        if (vLine) vLine.style.display = "none";
        if (selRect) {
          selRect.setAttribute("x", startSvgX);
          selRect.setAttribute("width", 2);
          selRect.style.display = "block";
        }
        document.getElementById("lblMediaValori").innerHTML =
          `<span style="color:#3b82f6;font-style:italic;">Seleziona il secondo punto...</span>`;
      } else if (this.selectionState === 1) {
        this.selectionState = 2;
        const endSvgX = curX;
        const minX = Math.max(padL, Math.min(startSvgX, endSvgX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, endSvgX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(4, selW));
          selRect.style.display = "block";
        }

        let selPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          selPts = [closest];
          if (selRect) {
            selRect.setAttribute("x", closest.x - 8);
            selRect.setAttribute("width", 16);
          }
        } else {
          selPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        applySelection(selPts);
      } else if (this.selectionState === 2) {
        this.selectionState = 0;
        this.clearSelection();
        if (selRect) selRect.style.display = "none";
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      }
    });

    if (this.selectedSampleIndices.size === 0) {
      const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
      document.getElementById("lblMediaValori").innerText =
        `${avg} (globale su ${values.length} campioni)`;
    }
  }
}

class AppController {
  constructor(lessons, demoProfile, customDefault, fonemiCorpus) {
    this.standardLessons = lessons || [];
    this.customLessons = [];
    this.activeLessonsSource = "standard"; // "standard" or "custom"
    this.lessons = this.standardLessons;
    this.profileMgr = new ProfileManager(demoProfile, customDefault);
    this.audio = new AudioEngine();
    this.phonemeEng = new PhonemeEngine(fonemiCorpus);
    this.typingEng = new TypingEngine(
      this.lessons,
      this.profileMgr,
      this.audio,
      this.phonemeEng,
    );
    this.visual = new VisualRenderer();
    this.windowMgr = new WindowManager();
    this.statsMgr = new StatisticsManager(this.profileMgr);
    this.prevStatsRect = null;
    this._wrongBadgeTimer = null;
  }

  // HELPER CENTRALE: Auto-Refocus UI aggressivo e resiliente a elementi occultati
  returnFocusToTyping() {
    if (document.querySelector(".modal-overlay.active")) return;
    const inp = document.getElementById("txtTypedInput");
    // Se la casella di testo è visibile a schermo, le assegniamo il focus
    if (inp && window.getComputedStyle(inp).display !== "none") {
      inp.focus();
    } else {
      // REQUISITO CRITICO: Esercizio con campo Input nascosto (display: none).
      // Chiamare focus() su un elemento display:none non produce effetti nel DOM, lasciando
      // il focus bloccato sull'ultimo controllo (es. il select appena cliccato).
      // Eseguendo blur() su qualsiasi elemento attivo, il focus torna al body del documento,
      // consentendo al listener globale di catturare ed elaborare regolarmente tutte le battute.
      if (document.activeElement && document.activeElement !== document.body) {
        document.activeElement.blur();
      }
    }
  }

  // Gestione disaccoppiata dell'uscita del focus da un elemento Select nativo
  gestisciUscitaDropdown(select, motivo) {
    // Delay di 60ms indispensabile per consentire all'OS e al browser engine
    // di terminare la distruzione e la chiusura grafica della tendina nativa
    setTimeout(() => {
      if (document.querySelector(".modal-overlay.active")) {
        // Se un modale è aperto e il select appartiene ad esso, non inviamo il focus all'input di battitura
        return;
      }
      this.returnFocusToTyping();
    }, 60);
  }

  // Registrazione macchina a stati per tutti i DropDownList nativi
  setupDropdownFocusManagement() {
    const selects = document.querySelectorAll("select");
    selects.forEach((select) => {
      let isOpen = false;
      let initialValue = select.value;
      let justChanged = false;
      let escInCorso = false;

      select.addEventListener("focus", () => {
        initialValue = select.value;
        isOpen = false;
      });

      select.addEventListener("click", () => {
        // Se il click è residuo immediato di un cambio valore con mouse, lo ignoriamo
        if (justChanged) {
          justChanged = false;
          return;
        }
        if (isOpen) {
          // Secondo click: tendina già aperta. Se il valore coincide, l'utente ha riselezionato la stessa voce
          if (select.value === initialValue) {
            this.gestisciUscitaDropdown(
              select,
              `[#${select.id}] Stessa voce confermata via mouse ("${select.value}")`,
            );
          }
          isOpen = false;
        } else {
          // Primo click: apertura logica della tendina
          isOpen = true;
          initialValue = select.value;
        }
      });

      select.addEventListener("change", () => {
        initialValue = select.value;
        isOpen = false;
        justChanged = true;
        setTimeout(() => {
          justChanged = false;
        }, 100);
        this.gestisciUscitaDropdown(
          select,
          `[#${select.id}] Valore modificato in ("${select.value}")`,
        );
      });

      const gestisciPressioneEsc = () => {
        if (escInCorso) return;
        escInCorso = true;
        isOpen = false;
        setTimeout(() => {
          escInCorso = false;
        }, 150);
        this.gestisciUscitaDropdown(
          select,
          `[#${select.id}] Uscita con tasto ESC`,
        );
      };

      select.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
          gestisciPressioneEsc();
          return;
        }
        const isOpeningKey =
          e.key === " " ||
          (e.altKey && e.key === "ArrowDown") ||
          e.key === "F4";
        if (!isOpen && isOpeningKey) {
          isOpen = true;
          initialValue = select.value;
          return;
        }
        if (e.key === "Enter" || (isOpen && e.key === " ")) {
          if (select.value === initialValue) {
            this.gestisciUscitaDropdown(
              select,
              `[#${select.id}] Stessa voce confermata da tastiera ("${select.value}")`,
            );
          }
          isOpen = false;
        }
      });

      // Ascolto combinato su keyup per garantire la cattura di ESC su tutti i browser Chromium
      select.addEventListener("keyup", (e) => {
        if (e.key === "Escape") {
          gestisciPressioneEsc();
        }
      });

      select.addEventListener("blur", () => {
        isOpen = false;
      });
    });
  }

  start() {
    this.profileMgr.init();

    // Inizializza gli esercizi personalizzati dal testo salvato nel profilo
    const savedCustomText =
      this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    this.customLessons = parseCustomExercises(savedCustomText);

    this.setupTheme();
    this.setupAudio();
    this.setupFloatingWindows();
    this.setupLoginModal();
    this.setupSelectPhraseModal();
    this.setupToolbar();
    this.setupCheckboxes();
    this.setupCustomEditor();
    this.setupStatsUI();
    this.setupDropdownFocusManagement(); // Attivazione macchina a stati DropDown nativi
    this.setupTypingListeners();
    this.setupShortcuts();

    // Gestione Sessione : Login solo se esiste un utente valido; altrimenti barriera bloccante
    const active = this.profileMgr.activeUser;
    if (active) {
      this.loginUser(active);
      setTimeout(() => {
        this.returnFocusToTyping();
      }, 150);
    } else {
      const badge = document.getElementById("loggedUserBadge");
      if (badge) badge.innerText = "Utente: --";
      this.showLoginModal();
    }

    // Mantiene la finestra Mani ancorata all'applicazione durante resize e zoom
    window.addEventListener("resize", () => {
      this.updateHandsWindowPosition();
      this.syncLayoutArrangement();
    });
  }

  setupTheme() {
    const sel = document.getElementById("themeSelect");
    if (!sel) return;
    sel.addEventListener("change", (e) => {
      const theme = e.target.value;
      document.body.classList.remove(
        "theme-dark",
        "theme-light",
        "theme-retro",
        "theme-matrix",
      );
      document.body.classList.add(theme);
      if (this.profileMgr.profile) {
        this.profileMgr.profile.Theme = theme;
        this.profileMgr.saveProfile();
      }
      this.returnFocusToTyping();
    });
  }

  setupAudio() {
    const modeSel = document.getElementById("audioModeSelect");
    const volSlider = document.getElementById("audioVolumeSlider");
    if (modeSel) {
      modeSel.addEventListener("change", (e) => {
        this.audio.setMode(e.target.value);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioMode = e.target.value;
          this.profileMgr.saveProfile();
        }
        this.returnFocusToTyping();
      });
    }
    if (volSlider) {
      volSlider.addEventListener("input", (e) => {
        const val = parseFloat(e.target.value) / 100;
        this.audio.setVolume(val);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AudioVolume = val;
          this.profileMgr.saveProfile();
        }
      });
      // Il refocus avviene solo al rilascio del mouse, per non interrompere il drag dello slider
      volSlider.addEventListener("change", () => {
        this.returnFocusToTyping();
      });
    }
  }

  getAppOrigin() {
    const main = document.querySelector("main");
    if (main) {
      const rect = main.getBoundingClientRect();
      return {
        left: rect.left + window.scrollX,
        top: rect.top + window.scrollY,
      };
    }
    return { left: 0, top: 0 };
  }

  // Ancoraggio Dinamico e Aggiornamento Posizione Finestra Mani
  updateHandsWindowPosition() {
    const handsWin = document.getElementById("handsFloatingWindow");
    if (!handsWin || !this.profileMgr?.profile) return;
    const origin = this.getAppOrigin();
    const prof = this.profileMgr.profile;
    const typingCard =
      document.getElementById("typingCardContainer") ||
      document.querySelector("main .card");

    let relLeft = prof.HandsLeft !== undefined ? prof.HandsLeft : 660;
    if (relLeft > 1300) {
      relLeft = 660;
      prof.HandsLeft = relLeft;
    }

    if (prof.HandsPinned) {
      // Modalità PIN Attivo (Smart Anchor): ancorata alla base del blocco di digitazione
      const cardRect = typingCard ? typingCard.getBoundingClientRect() : null;
      const cardBottom = cardRect
        ? cardRect.bottom + window.scrollY
        : origin.top + 340;
      const offsetTop =
        prof.HandsOffsetTop !== undefined ? prof.HandsOffsetTop : 16;
      let targetTop = Math.round(cardBottom + offsetTop);
      let targetLeft = Math.round(origin.left + relLeft);

      handsWin.style.left = targetLeft + "px";
      handsWin.style.top = targetTop + "px";
    } else {
      // Modalità Libera (Unpinned): ancorata all'angolo superiore di <main>
      let relTop = prof.HandsTop !== undefined ? prof.HandsTop : 120;
      handsWin.style.left = Math.round(origin.left + relLeft) + "px";
      handsWin.style.top = Math.round(origin.top + relTop) + "px";
    }

    // Viewport Boundary Guard: impedisce coordinate fuori schermo
    this.windowMgr.clampWindowToViewport(handsWin, true);
  }

  updateHandsPinButtonUI() {
    const btn = document.getElementById("btnHandsPin");
    if (!btn || !this.profileMgr?.profile) return;
    const isPinned = !!this.profileMgr.profile.HandsPinned;
    if (isPinned) {
      btn.classList.add("pinned");
      btn.innerText = "📍 Pinned";
      btn.title =
        "Ancoraggio Intelligente: agganciata alla base del blocco di digitazione (clicca per sbloccare)";
    } else {
      btn.classList.remove("pinned");
      btn.innerText = "📌 Pin";
      btn.title =
        "Ancoraggio Libero: clicca per agganciare la finestra alla base del blocco di digitazione";
    }
  }

  setupFloatingWindows() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const handsHeader = document.getElementById("handsWindowHeader");
    const statsWin = document.getElementById("statsFloatingWindow");
    const statsHeader = document.getElementById("statsWindowHeader");
    const customWin = document.getElementById("customEditorWindow");
    const customHeader = document.getElementById("customEditorHeader");

    if (handsWin && handsHeader) {
      this.windowMgr.makeDraggable(handsWin, handsHeader, (x, y) => {
        if (this.profileMgr.profile) {
          const origin = this.getAppOrigin();
          const relX = Math.round(x - origin.left);
          this.profileMgr.profile.HandsLeft = relX;

          if (this.profileMgr.profile.HandsPinned) {
            // Il drag calibra la distanza relativa dal fondo della scheda digitazione
            const typingCard =
              document.getElementById("typingCardContainer") ||
              document.querySelector("main .card");
            const cardBottom = typingCard
              ? typingCard.getBoundingClientRect().bottom + window.scrollY
              : origin.top;
            const offsetTop = Math.round(y - cardBottom);
            this.profileMgr.profile.HandsOffsetTop = offsetTop;
          } else {
            const relY = Math.round(y - origin.top);
            this.profileMgr.profile.HandsTop = relY;
          }
          this.profileMgr.saveProfile();
        }
      });

      this.windowMgr.makeResizable(
        handsWin,
        (w, h, x, y) => {
          if (this.profileMgr.profile) {
            const origin = this.getAppOrigin();
            const relX = Math.round(x - origin.left);
            this.profileMgr.profile.HandsWidth = Math.round(w);
            this.profileMgr.profile.HandsHeight = Math.round(h);
            this.profileMgr.profile.HandsLeft = relX;

            if (this.profileMgr.profile.HandsPinned) {
              const typingCard =
                document.getElementById("typingCardContainer") ||
                document.querySelector("main .card");
              const cardBottom = typingCard
                ? typingCard.getBoundingClientRect().bottom + window.scrollY
                : origin.top;
              this.profileMgr.profile.HandsOffsetTop = Math.round(
                y - cardBottom,
              );
            } else {
              this.profileMgr.profile.HandsTop = Math.round(y - origin.top);
            }
            this.profileMgr.saveProfile();
          }
          this.visual.adjustHandsViewport(w, h);
        },
        340,
        200,
      );
    }

    const btnHandsPin = document.getElementById("btnHandsPin");
    if (btnHandsPin) {
      btnHandsPin.addEventListener("click", () => {
        if (this.profileMgr.profile) {
          this.profileMgr.profile.HandsPinned =
            !this.profileMgr.profile.HandsPinned;
          this.profileMgr.saveProfile();
          this.updateHandsPinButtonUI();
          this.updateHandsWindowPosition();
        }
        this.returnFocusToTyping();
      });
    }

    const btnHandsDef = document.getElementById("btnHandsDefaultPos");
    if (btnHandsDef) {
      btnHandsDef.addEventListener("click", () => {
        this.resetHandsDefaultPosition();
        this.returnFocusToTyping();
      });
    }

    if (statsWin && statsHeader) {
      this.windowMgr.makeDraggable(statsWin, statsHeader, (x, y) => {
        if (this.profileMgr.profile) {
          this.profileMgr.profile.StatLeft = x;
          this.profileMgr.profile.StatTop = y;
          this.profileMgr.saveProfile();
        }
      });

      this.windowMgr.makeResizable(
        statsWin,
        (w, h, x, y) => {
          if (this.profileMgr.profile) {
            this.profileMgr.profile.StatWidth = w;
            this.profileMgr.profile.StatHeight = h;
            this.profileMgr.profile.StatLeft = x;
            this.profileMgr.profile.StatTop = y;
            this.profileMgr.saveProfile();
          }
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
        },
        540,
        380,
      );
    }

    if (customWin && customHeader) {
      this.windowMgr.makeDraggable(customWin, customHeader, null);
    }

    const btnMax = document.getElementById("btnStatsMaximize");
    if (btnMax && statsWin) {
      btnMax.addEventListener("click", () => {
        if (!statsWin.classList.contains("window-fullscreen")) {
          this.prevStatsRect = {
            left: statsWin.style.left || "180px",
            top: statsWin.style.top || "80px",
            width: statsWin.style.width || "820px",
            height: statsWin.style.height || "600px",
          };
          statsWin.classList.add("window-fullscreen");
          // Blocco dello scroll del body principale per evitare conflitti di scrollbar
          document.body.style.overflow = "hidden";
          btnMax.innerText = "🗗 Riduci";
          btnMax.title = "Ripristina dimensioni precedenti";
        } else {
          statsWin.classList.remove("window-fullscreen");
          // Ripristino dello scroll del body principale
          document.body.style.overflow = "";
          if (this.prevStatsRect) {
            statsWin.style.left = this.prevStatsRect.left;
            statsWin.style.top = this.prevStatsRect.top;
            statsWin.style.width = this.prevStatsRect.width;
            statsWin.style.height = this.prevStatsRect.height;
          }
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero";
          this.windowMgr.clampWindowToViewport(statsWin, false);

          if (this.profileMgr.profile) {
            this.profileMgr.profile.StatLeft = parseInt(
              statsWin.style.left,
              10,
            );
            this.profileMgr.profile.StatTop = parseInt(statsWin.style.top, 10);
            this.profileMgr.profile.StatWidth = parseInt(
              statsWin.style.width,
              10,
            );
            this.profileMgr.profile.StatHeight = parseInt(
              statsWin.style.height,
              10,
            );
            this.profileMgr.saveProfile();
          }
        }
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      });
    }

    const btnResetLayout = document.getElementById("btnStatsResetLayout");
    if (btnResetLayout && statsWin) {
      btnResetLayout.addEventListener("click", () => {
        statsWin.classList.remove("window-fullscreen");
        // Ripristino dello scroll del body principale
        document.body.style.overflow = "";
        statsWin.style.left = "180px";
        statsWin.style.top = "80px";
        statsWin.style.width = "820px";
        statsWin.style.height = "600px";
        statsWin.style.maxWidth = "95vw";
        if (btnMax) {
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero";
        }
        this.windowMgr.clampWindowToViewport(statsWin, false);

        if (this.profileMgr.profile) {
          this.profileMgr.profile.StatLeft = 180;
          this.profileMgr.profile.StatTop = 80;
          this.profileMgr.profile.StatWidth = 820;
          this.profileMgr.profile.StatHeight = 600;
          this.profileMgr.saveProfile();
        }
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      });
    }

    // Responsive ResizeObserver per ridisegno dinamico dei grafici
    if (window.ResizeObserver) {
      let resizeTimer = null;
      const ro = new ResizeObserver(() => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          const sw = document.getElementById("statsFloatingWindow");
          if (sw && sw.classList.contains("window-visible")) {
            this.statsMgr.renderSpeedChart();
            this.statsMgr.renderHistogram();
          }
        }, 80);
      });
      const speedBox = document.getElementById("statsSpeedSvgBox");
      const histBox = document.getElementById("statsHistogramSvgBox");
      if (speedBox) ro.observe(speedBox);
      if (histBox) ro.observe(histBox);
    }

    // Ricalcolo geometrico immediato allo scorrimento magnetico tra Sezione 1 e Sezione 2 (v.2.30)
    const statsBody = document.querySelector(
      "#statsFloatingWindow .floating-window-body",
    );
    if (statsBody) {
      let scrollDebounce = null;
      statsBody.addEventListener(
        "scroll",
        () => {
          clearTimeout(scrollDebounce);
          scrollDebounce = setTimeout(() => {
            const sw = document.getElementById("statsFloatingWindow");
            if (sw && sw.classList.contains("window-visible")) {
              const speedBox = document.getElementById("statsSpeedSvgBox");
              if (speedBox && speedBox.clientHeight > 0) {
                this.statsMgr.renderSpeedChart();
              }
            }
          }, 50);
        },
        { passive: true },
      );
    }

    document.getElementById("btnHandsClose")?.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      this.toggleHandsVis(false);
      this.returnFocusToTyping();
    });

    document.getElementById("btnStatsClose")?.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      document.body.style.overflow = "";
      this.toggleStatsWindow(false);
      this.returnFocusToTyping();
    });

    document
      .getElementById("btnCustomClose")
      ?.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();
        const customWin = document.getElementById("customEditorWindow");
        if (customWin) {
          customWin.classList.remove("window-visible");
          customWin.style.display = "none";
        }
        this.returnFocusToTyping();
      });
  }

  resetHandsDefaultPosition() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const kbCont = document.querySelector(".keyboard-container");
    const kbSvg = document.getElementById("keyboardSvg");
    const typingCard =
      document.getElementById("typingCardContainer") ||
      document.querySelector("main .card");
    if (!handsWin) return;

    const origin = this.getAppOrigin();
    let relLeft = 660;
    let offsetTop = 16;
    let relTop = 120;

    if (kbSvg && kbCont && typingCard) {
      const kbRect = kbSvg.getBoundingClientRect();
      const mainRect = document.querySelector("main")?.getBoundingClientRect();
      const cardRect = typingCard.getBoundingClientRect();
      if (mainRect && cardRect) {
        relLeft = Math.round(kbRect.right - mainRect.left + 16);
        offsetTop = Math.round(kbRect.top - cardRect.bottom);
        relTop = Math.max(10, Math.round(kbRect.top - mainRect.top));
      }
    }

    handsWin.style.width = "580px";
    handsWin.style.height = "330px";

    if (this.profileMgr?.profile) {
      this.profileMgr.profile.HandsPinned = true;
      this.profileMgr.profile.HandsOffsetTop = offsetTop;
      this.profileMgr.profile.HandsLeft = relLeft;
      this.profileMgr.profile.HandsTop = relTop;
      this.profileMgr.profile.HandsWidth = 580;
      this.profileMgr.profile.HandsHeight = 330;
      this.profileMgr.saveProfile();
    }

    this.updateHandsPinButtonUI();
    this.updateHandsWindowPosition();
    this.visual.adjustHandsViewport(580, 330);
    this.syncLayoutArrangement();
  }

  syncLayoutArrangement() {
    const handsWin = document.getElementById("handsFloatingWindow");
    const kbCont = document.querySelector(".keyboard-container");
    const handsVisible =
      handsWin && handsWin.classList.contains("window-visible");
    const chkKb = document.getElementById("chkShowKeyBoard");
    const kbVisible = chkKb ? chkKb.checked : true;

    if (kbCont) {
      if (handsVisible && kbVisible) {
        kbCont.classList.add("align-left");
      } else {
        kbCont.classList.remove("align-left");
      }
    }
  }

  toggleHandsVis(show) {
    const hw = document.getElementById("handsFloatingWindow");
    if (hw) {
      if (show) {
        hw.classList.add("window-visible");
        hw.style.display = "flex";
        this.updateHandsPinButtonUI();
        this.updateHandsWindowPosition();
      } else {
        hw.classList.remove("window-visible");
        hw.style.display = "none";
      }
    }
    const chk = document.getElementById("chkShowHands");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr && this.profileMgr.profile) {
      this.profileMgr.profile.ShowHands = !!show;
      this.profileMgr.saveProfile();
    }
    this.syncLayoutArrangement();
  }

  toggleKeyboardVis(show) {
    const kb = document.getElementById("keyboardCardContainer");
    if (kb) kb.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowKeyBoard");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowKeyBoard = !!show;
      this.profileMgr.saveProfile();
    }
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
      this.syncLayoutArrangement();
    });
  }

  toggleOriginVis(show) {
    const orig = document.getElementById("originTextWrapper");
    if (orig) orig.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowOrigin");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowOrigin = !!show;
      this.profileMgr.saveProfile();
    }
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
    });
  }

  toggleTypedVis(show) {
    const inp = document.getElementById("txtTypedInput");
    if (inp) inp.style.display = show ? "block" : "none";
    const chk = document.getElementById("chkShowTyped");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowTyped = !!show;
      this.profileMgr.saveProfile();
    }
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
    });
  }

  toggleStatsWindow(forceState) {
    const win = document.getElementById("statsFloatingWindow");
    if (!win) return;
    const shouldShow =
      typeof forceState === "boolean"
        ? forceState
        : !win.classList.contains("window-visible");
    if (shouldShow) {
      win.classList.add("window-visible");
      win.style.display = "flex";
      this.windowMgr.clampWindowToViewport(win, false);
      this.statsMgr.renderHistogram();
      this.statsMgr.renderSpeedChart();
    } else {
      win.classList.remove("window-visible");
      win.style.display = "none";
    }
    const btn = document.getElementById("btnOpenStats");
    if (btn) btn.classList.toggle("active", shouldShow);
  }

  showLoginModal() {
    const modal = document.getElementById("loginModal");
    const select = document.getElementById("loginUserSelect");
    const input = document.getElementById("loginNewUserInput");
    if (!modal || !select || !input) return;

    const users = this.profileMgr.getUsers();
    select.innerHTML =
      '<option value="">-- Seleziona Utente Esistente --</option>';
    users.forEach((u) => {
      select.innerHTML += `<option value="${htmlEscape(u)}">${htmlEscape(u)}</option>`;
    });

    if (
      this.profileMgr.activeUser &&
      users.includes(this.profileMgr.activeUser)
    ) {
      select.value = this.profileMgr.activeUser;
    } else {
      select.value = "";
    }
    input.value = "";
    modal.classList.add("active");
  }

  showSelectPhraseModal() {
    const modal = document.getElementById("selectPhraseModal");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const numInput = document.getElementById("txtSelectPhraseNum");
    const rangeLabel = document.getElementById("lblSelectPhraseRange");
    if (!modal || !lessonSelect || !numInput) return;

    const lessons = this.typingEng.lessons || [];
    if (lessons.length === 0) return;

    lessonSelect.innerHTML = "";
    lessons.forEach((les, idx) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      opt.textContent = `${idx + 1}. ${les.name || les.title || "Lezione " + (idx + 1)}`;
      lessonSelect.appendChild(opt);
    });

    const currentLessonIdx = this.typingEng.currentLessonIdx || 0;
    lessonSelect.value = String(currentLessonIdx);

    const updateRange = () => {
      const lesIdx = parseInt(lessonSelect.value, 10);
      const chosenLesson = lessons[lesIdx] || lessons[0];
      const phrases = chosenLesson?.phrases || [];
      const totalPhrases = Math.max(1, phrases.length);

      if (rangeLabel) {
        rangeLabel.innerText = `Numero Frase consentito (da 1 a ${totalPhrases}):`;
      }
      numInput.min = "1";
      numInput.max = String(totalPhrases);

      if (lesIdx === currentLessonIdx) {
        numInput.value = String((this.typingEng.currentPhraseIdx || 0) + 1);
      } else {
        numInput.value = "1";
      }
    };

    lessonSelect.onchange = updateRange;
    updateRange();

    modal.classList.add("active");
    setTimeout(() => {
      numInput.focus();
      numInput.select();
    }, 50);
  }

  confirmSelectPhrase() {
    const modal = document.getElementById("selectPhraseModal");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const numInput = document.getElementById("txtSelectPhraseNum");
    if (!modal || !numInput) return;

    const lessons = this.typingEng.lessons || [];
    const lesIdx = lessonSelect
      ? parseInt(lessonSelect.value, 10)
      : this.typingEng.currentLessonIdx;
    const chosenLesson = lessons[lesIdx] || lessons[0];
    const phrases = chosenLesson?.phrases || [];
    const totalPhrases = phrases.length;
    const val = parseInt(numInput.value, 10);

    if (!isNaN(val) && val >= 1 && val <= totalPhrases) {
      this.typingEng.currentLessonIdx = lesIdx;
      this.typingEng.currentPhraseIdx = val - 1;

      const toolbarLesson =
        document.getElementById("cboLessons") ||
        document.getElementById("selLesson");
      if (toolbarLesson) {
        toolbarLesson.value = String(lesIdx);
      }

      this.startExercise();
      modal.classList.remove("active");
      setTimeout(() => {
        this.returnFocusToTyping();
      }, 50);
    } else {
      numInput.classList.add("error-active");
      setTimeout(() => numInput.classList.remove("error-active"), 300);
    }
  }

  setupSelectPhraseModal() {
    const modal = document.getElementById("selectPhraseModal");
    const numInput = document.getElementById("txtSelectPhraseNum");
    const lessonSelect = document.getElementById("selSelectPhraseLesson");
    const btnConfirm = document.getElementById("btnConfirmSelectPhrase");
    const btnCancel = document.getElementById("btnCancelSelectPhrase");
    const btnClose = document.getElementById("btnCloseSelectPhraseModal");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      this.startExercise();
    };

    btnConfirm?.addEventListener("click", () => this.confirmSelectPhrase());
    btnCancel?.addEventListener("click", closeModal);
    btnClose?.addEventListener("click", closeModal);

    numInput?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        this.confirmSelectPhrase();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    lessonSelect?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        this.confirmSelectPhrase();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    modal?.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });
    document
      .getElementById("btnSelectPhraseModal")
      ?.addEventListener("click", () => this.showSelectPhraseModal());
    document
      .getElementById("lblPhraseRange")
      ?.addEventListener("click", () => this.showSelectPhraseModal());
  }

  setupLoginModal() {
    const modal = document.getElementById("loginModal");
    const select = document.getElementById("loginUserSelect");
    const input = document.getElementById("loginNewUserInput");
    const btnEnter = document.getElementById("btnLoginEnter");
    const btnDelete = document.getElementById("btnLoginDelete");
    const btnResetArchive = document.getElementById("btnResetDefaultArchive");

    const closeModal = () => {
      // Barriera : impossibile uscire senza un utente loggato
      if (!this.profileMgr.activeUser) {
        this.showAppAlert(
          "È obbligatorio selezionare o creare un utente per accedere all'applicazione.",
          "⚠ Accesso Richiesto",
        );
        return;
      }
      if (modal) modal.classList.remove("active");
      this.startExercise();
    };

    const doEnter = () => {
      const newName = input.value.trim();
      const chosen = newName || select.value;
      if (!chosen) {
        this.showAppAlert(
          "Selezionare un utente esistente o digitare un nuovo nome.",
          "👤 Gestione Utenti",
        );
        return;
      }
      this.loginUser(chosen);
      if (modal) modal.classList.remove("active");
    };

    btnEnter?.addEventListener("click", doEnter);
    modal?.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });

    input?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doEnter();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    select?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        doEnter();
      } else if (e.key === "Escape") {
        e.preventDefault();
        closeModal();
      }
    });

    window.addEventListener("keydown", (e) => {
      const navModal = document.getElementById("lessonNavModal");
      if (navModal && navModal.classList.contains("active")) return;
      if (e.key === "Escape" && modal?.classList.contains("active"))
        closeModal();
    });

    btnDelete?.addEventListener("click", () => {
      const chosen = select.value;
      if (!chosen) {
        this.showAppAlert(
          "Selezionare un utente da eliminare.",
          "👤 Gestione Utenti",
        );
        return;
      }
      this.showAppConfirm(
        `Eliminare definitivamente tutti i dati dell'utente "${chosen}"?`,
        "⚠ Conferma Eliminazione",
        () => {
          this.profileMgr.deleteUser(chosen);
          if (!this.profileMgr.activeUser) {
            const badge = document.getElementById("loggedUserBadge");
            if (badge) badge.innerText = "Utente: --";
          }
          this.showLoginModal();
        },
      );
    });

    btnResetDefaultArchive?.addEventListener("click", () => {
      this.showAppConfirm(
        "Ripristinare l'archivio demo originale (UTENTE_DEMO)?",
        "🔄 Ripristino Archivio",
        () => {
          this.profileMgr.resetToDefaultArchive();
          this.loginUser("UTENTE_DEMO");
          if (modal) modal.classList.remove("active");
        },
      );
    });

    document
      .getElementById("btnHeaderSwitchUser")
      ?.addEventListener("click", () => {
        this.showLoginModal();
      });
  }

  // GESTIONE SORGENTE LEZIONI: STANDARD VS CUSTOM
  setLessonsSource(source) {
    this.activeLessonsSource = source;
    const isCustom =
      source === "custom" &&
      this.customLessons &&
      this.customLessons.length > 0;
    this.lessons = isCustom ? this.customLessons : this.standardLessons;
    this.typingEng.lessons = this.lessons;
    this.typingEng.currentLessonIdx = 0;
    this.typingEng.currentPhraseIdx = 0;

    const lbl = document.getElementById("lblLessonSource");
    if (lbl) lbl.innerText = isCustom ? "Custom" : "Standard";

    const cboLessons = document.getElementById("cboLessons");
    if (cboLessons) {
      cboLessons.innerHTML = "";
      this.lessons.forEach((l, idx) => {
        const prefix = isCustom ? "Custom " : "Lezione ";
        cboLessons.innerHTML += `<option value="${idx}">${prefix}${idx + 1}: ${htmlEscape(l.name)}</option>`;
      });
      cboLessons.value = "0";
    }

    this.startExercise();
  }

  loginUser(userId) {
    const prof = this.profileMgr.loadUser(userId);
    const badge = document.getElementById("loggedUserBadge");
    if (badge) badge.innerText = `Utente: ${userId}`;

    const theme = prof.Theme || "theme-dark";
    document.body.classList.remove(
      "theme-dark",
      "theme-light",
      "theme-retro",
      "theme-matrix",
    );
    document.body.classList.add(theme);
    const themeSel = document.getElementById("themeSelect");
    if (themeSel) themeSel.value = theme;

    const audioMode = prof.AudioMode || "typewriter";
    this.audio.setMode(audioMode);
    const audioSel = document.getElementById("audioModeSelect");
    if (audioSel) audioSel.value = audioMode;

    const audioVol = prof.AudioVolume !== undefined ? prof.AudioVolume : 0.7;
    this.audio.setVolume(audioVol);
    const volSlider = document.getElementById("audioVolumeSlider");
    if (volSlider) volSlider.value = String(Math.round(audioVol * 100));

    this.toggleHandsVis(prof.ShowHands !== false);
    const handsWin = document.getElementById("handsFloatingWindow");
    if (handsWin) {
      this.updateHandsPinButtonUI();
      this.updateHandsWindowPosition();
      if (prof.HandsWidth && prof.HandsHeight) {
        handsWin.style.width = prof.HandsWidth + "px";
        handsWin.style.height = prof.HandsHeight + "px";
        this.visual.adjustHandsViewport(prof.HandsWidth, prof.HandsHeight);
      } else {
        handsWin.style.width = "580px";
        handsWin.style.height = "330px";
        this.visual.adjustHandsViewport(580, 330);
      }
      this.windowMgr.clampWindowToViewport(handsWin, true);
    }

    const statsWin = document.getElementById("statsFloatingWindow");
    if (statsWin) {
      if (prof.StatLeft && prof.StatTop) {
        statsWin.style.left = prof.StatLeft + "px";
        statsWin.style.top = prof.StatTop + "px";
      }
      if (prof.StatWidth && prof.StatHeight) {
        statsWin.style.width = prof.StatWidth + "px";
        statsWin.style.height = prof.StatHeight + "px";
        statsWin.style.maxWidth = "none";
      }
      this.windowMgr.clampWindowToViewport(statsWin, false);
    }

    this.toggleKeyboardVis(prof.ShowKeyBoard !== false);
    this.toggleOriginVis(prof.ShowOrigin !== false);
    this.toggleTypedVis(prof.ShowTyped !== false);
    this.toggleErrorsVis(prof.ShowErrors !== false);
    const chkAuto = document.getElementById("chkAutomaticCorrection");
    if (chkAuto) chkAuto.checked = !!prof.AutomaticCorrection;

    this.typingEng.mode = prof.Mode || 0;
    const cboMode = document.getElementById("cboMode");
    if (cboMode) cboMode.value = String(this.typingEng.mode);

    this.setLessonsSource("standard");
    this.typingEng.currentLessonIdx = Math.max(
      0,
      Math.min(prof.Lesson || 0, this.lessons.length - 1),
    );
    this.typingEng.currentPhraseIdx = prof.Exercise || 0;
    const cboLessons = document.getElementById("cboLessons");
    if (cboLessons) cboLessons.value = String(this.typingEng.currentLessonIdx);

    this.updateModeUI();
    this.startExercise();
  }

  setupToolbar() {
    const cboLessons = document.getElementById("cboLessons");
    const cboMode = document.getElementById("cboMode");
    const btnToggleSource = document.getElementById("btnToggleLessonSource");

    if (cboLessons) {
      cboLessons.addEventListener("change", (e) => {
        this.typingEng.currentLessonIdx = parseInt(e.target.value, 10);
        this.typingEng.currentPhraseIdx = 0;
        if (
          this.profileMgr.profile &&
          this.activeLessonsSource === "standard"
        ) {
          this.profileMgr.profile.Lesson = this.typingEng.currentLessonIdx;
          this.profileMgr.profile.Exercise = 0;
          this.profileMgr.saveProfile();
        }
        this.startExercise();
        this.returnFocusToTyping();
      });
    }

    if (btnToggleSource) {
      btnToggleSource.addEventListener("click", () => {
        if (this.activeLessonsSource === "standard") {
          if (!this.customLessons || this.customLessons.length === 0) {
            const txt =
              this.profileMgr.profile?.CustomText ||
              this.profileMgr.defaultCustomText;
            this.customLessons = parseCustomExercises(txt);
          }
          if (this.customLessons.length > 0) {
            this.setLessonsSource("custom");
          } else {
            this.showAppAlert(
              "Nessun esercizio custom trovato. Apri l'Editor Custom per inserire o caricare un file.",
              "ℹ Esercizi Custom",
            );
          }
        } else {
          this.setLessonsSource("standard");
        }
        this.returnFocusToTyping();
      });
    }

    if (cboMode) {
      cboMode.addEventListener("change", (e) => {
        this.typingEng.mode = parseInt(e.target.value, 10);
        if (this.profileMgr.profile) {
          this.profileMgr.profile.Mode = this.typingEng.mode;
          this.profileMgr.saveProfile();
        }
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      });
    }

    // Clic su ▲ e ▼ navigano direttamente (intenzionalità mouse)
    document.getElementById("btnPrevLesson")?.addEventListener("click", () => {
      this.navLesson(-1);
      this.returnFocusToTyping();
    });
    document.getElementById("btnNextLesson")?.addEventListener("click", () => {
      this.navLesson(1);
      this.returnFocusToTyping();
    });

    document.getElementById("btnPrevPhrase")?.addEventListener("click", () => {
      this.navPhrase(-1);
      this.returnFocusToTyping();
    });
    document.getElementById("btnNextPhrase")?.addEventListener("click", () => {
      this.navPhrase(1);
      this.returnFocusToTyping();
    });
    document
      .getElementById("btnRestartPhrase")
      ?.addEventListener("click", () => {
        this.startExercise();
        this.returnFocusToTyping();
      });
    document
      .getElementById("btnRandomPhrase")
      ?.addEventListener("click", () => {
        this.randomPhrase();
        this.returnFocusToTyping();
      });
    document
      .getElementById("btnRandomThisPhrase")
      ?.addEventListener("click", () => {
        this.typingEng.mode = 5;
        if (cboMode) cboMode.value = "5";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      });
    document
      .getElementById("btnRandomAllChars")
      ?.addEventListener("click", () => {
        this.typingEng.mode = 3;
        if (cboMode) cboMode.value = "3";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      });

    document.getElementById("btnOpenStats")?.addEventListener("click", () => {
      this.toggleStatsWindow();
      this.returnFocusToTyping();
    });
    document
      .getElementById("btnOpenCustomEditor")
      ?.addEventListener("click", () => {
        this.openCustomEditor();
        this.returnFocusToTyping();
      });

    document
      .getElementById("btnAddStatistic")
      ?.addEventListener("click", () => {
        if (this.typingEng.mode === 4) {
          this.typingEng.recordManualTypingSample();
          this.showAppAlert(
            "Sessione di digitazione libera registrata con successo!",
            "📊 Statistiche",
          );
          this.typingEng.initSession();
          this.typingEng.updateMetrics();

          // Ridisegno immediato dei grafici se la finestra Statistiche è aperta e visibile (v.2.32)
          const statsWin = document.getElementById("statsFloatingWindow");
          if (statsWin && statsWin.classList.contains("window-visible")) {
            this.statsMgr.renderHistogram();
            this.statsMgr.renderSpeedChart();
          }
        }
        this.returnFocusToTyping();
      });
  }

  // Bonifica immediata degli errori pre-esistenti all'attivazione dell'Auto-Correzione
  // Ripulisce esclusivamente il buffer di battitura e il testo guida, preservando
  // integralmente lo storico nel Registro Errori (sessionErrors) e i contatori statistici.
  purgePreExistingErrors() {
    if (this.typingEng.mode === 4 || this.typingEng.isCompleted) return;
    const matchLen = this.typingEng.getMatchLength();
    if (this.typingEng.typedText.length > matchLen) {
      // Troncamento del testo digitato al prefisso coincidente privo di errori
      this.typingEng.typedText = this.typingEng.typedText.slice(0, matchLen);
      this.typingEng.currentTargetHasError = false;

      const input = document.getElementById("txtTypedInput");
      if (input) {
        input.value = this.typingEng.typedText;
        input.classList.remove("error-active");
      }

      // Aggiornamento immediato di display guida, tastiera/mani e metriche
      this.updateOriginDisplay();
      this.updateTargetKey();
      this.typingEng.updateMetrics();
    }
  }

  setupCheckboxes() {
    document
      .getElementById("chkShowOrigin")
      ?.addEventListener("change", (e) => {
        this.toggleOriginVis(e.target.checked);
        this.returnFocusToTyping();
      });
    document.getElementById("chkShowTyped")?.addEventListener("change", (e) => {
      this.toggleTypedVis(e.target.checked);
      this.returnFocusToTyping();
    });
    document
      .getElementById("chkShowErrors")
      ?.addEventListener("change", (e) => {
        this.toggleErrorsVis(e.target.checked);
        this.returnFocusToTyping();
      });
    document
      .getElementById("chkShowKeyBoard")
      ?.addEventListener("change", (e) => {
        this.toggleKeyboardVis(e.target.checked);
        this.returnFocusToTyping();
      });
    document.getElementById("chkShowHands")?.addEventListener("change", (e) => {
      this.toggleHandsVis(e.target.checked);
      this.returnFocusToTyping();
    });
    document
      .getElementById("chkAutomaticCorrection")
      ?.addEventListener("change", (e) => {
        if (this.profileMgr.profile) {
          this.profileMgr.profile.AutomaticCorrection = e.target.checked;
          this.profileMgr.saveProfile();
        }
        // Se l'Auto-Correzione viene attivata, elimina all'istante gli errori pendenti
        if (e.target.checked) {
          this.purgePreExistingErrors();
        }
        this.returnFocusToTyping();
      });
  }

  updateModeUI() {
    const fixing = document.getElementById("fixingDataPanel");
    const input = document.getElementById("txtTypedInput");
    if (this.typingEng.mode === 4) {
      if (fixing) fixing.style.display = "flex";
      if (input)
        input.placeholder = "Digitazione libera: scrivi qualsiasi testo qui...";
    } else {
      if (fixing) fixing.style.display = "none";
      if (input) input.placeholder = "Inizia a digitare qui...";
    }
  }

  navLesson(delta) {
    let next = this.typingEng.currentLessonIdx + delta;
    if (next < 0) next = 0;
    if (next >= this.lessons.length) next = this.lessons.length - 1;
    this.typingEng.currentLessonIdx = next;
    this.typingEng.currentPhraseIdx = 0;
    const cbo = document.getElementById("cboLessons");
    if (cbo) cbo.value = String(next);
    if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
      this.profileMgr.profile.Lesson = next;
      this.profileMgr.profile.Exercise = 0;
      this.profileMgr.saveProfile();
    }
    this.startExercise();
  }

  // Navigazione Lezione con conferma esplicita per scorciatoie da tastiera
  confirmNavLesson(delta) {
    if (delta < 0 && this.typingEng.currentLessonIdx === 0) {
      this.audio.playError();
      this.showLessonNavAlert("Sei già alla prima lezione.");
      return;
    }

    if (
      delta > 0 &&
      this.typingEng.currentLessonIdx >= this.lessons.length - 1
    ) {
      this.audio.playError();
      this.showLessonNavAlert("Sei già all'ultima lezione.");
      return;
    }

    const msg =
      delta < 0
        ? "Si vuole abbandonare la lezione corrente, e passare alla precedente?"
        : "Si vuole abbandonare la lezione corrente, e passare alla successiva?";

    this.showLessonNavConfirmCustom(msg, () => {
      this.navLesson(delta);
    });
  }

  // =======================================================
  // HELPER MODALI ASINCRONI TEMATIZZATI
  // =======================================================
  showAppAlert(message, title = "ℹ Informazione", onClose = null) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal) return;

    const titleEl = document.getElementById("lessonNavModalTitle");
    const bodyEl = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!bodyEl || !btnYes) return;

    if (titleEl) titleEl.textContent = title;
    bodyEl.textContent = message;
    if (btnNo) btnNo.style.display = "none";
    btnYes.textContent = "OK";
    modal.style.zIndex = "3000";
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      modal.style.zIndex = "";
      if (btnNo) btnNo.style.display = "";
      btnYes.textContent = "Sì";
      if (titleEl) titleEl.textContent = "📖 Navigazione Lezione";
      btnYes.removeEventListener("click", handleOk);
      btnClose?.removeEventListener("click", handleOk);
      window.removeEventListener("keydown", handleKey);
      if (onClose) onClose();
      this.returnFocusToTyping();
    };

    const handleOk = () => cleanup();
    const handleKey = (e) => {
      if (e.key === "Escape" || e.key === "Enter") {
        e.preventDefault();
        cleanup();
      }
    };

    btnYes.addEventListener("click", handleOk);
    btnClose?.addEventListener("click", handleOk);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  showAppConfirm(
    message,
    title = "❓ Conferma",
    onConfirm = null,
    onCancel = null,
  ) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal) return;

    const titleEl = document.getElementById("lessonNavModalTitle");
    const bodyEl = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!bodyEl || !btnYes || !btnNo) return;

    if (titleEl) titleEl.textContent = title;
    bodyEl.textContent = message;
    if (btnNo) btnNo.style.display = "";
    btnYes.textContent = "Sì";
    btnNo.textContent = "No";
    modal.style.zIndex = "3000";
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      modal.style.zIndex = "";
      if (titleEl) titleEl.textContent = "📖 Navigazione Lezione";
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.returnFocusToTyping();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
      if (onCancel) onCancel();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  showLessonNavAlert(message) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const title = document.getElementById("lessonNavModalTitle");
    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes) return;

    if (title) title.textContent = "ℹ Informazione";
    body.textContent = message;
    if (btnNo) btnNo.style.display = "none";
    btnYes.textContent = "OK";
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      if (btnNo) btnNo.style.display = "";
      btnYes.textContent = "Sì";
      if (title) title.textContent = "📖 Navigazione Lezione";
      btnYes.removeEventListener("click", handleOk);
      btnClose?.removeEventListener("click", handleOk);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleOk = () => cleanup();
    const handleKey = (e) => {
      if (e.key === "Escape" || e.key === "Enter") {
        e.preventDefault();
        cleanup();
      }
    };

    btnYes.addEventListener("click", handleOk);
    btnClose?.addEventListener("click", handleOk);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  showLessonNavConfirmCustom(customMessage, onConfirm) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const title = document.getElementById("lessonNavModalTitle");
    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes || !btnNo) return;

    if (title) title.textContent = "📖 Navigazione Lezione";
    body.textContent = customMessage;
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  showLessonNavConfirm(aaaa, bbbb, onConfirm) {
    const modal = document.getElementById("lessonNavModal");
    if (!modal || modal.classList.contains("active")) return;

    const body = document.getElementById("lessonNavModalBody");
    const btnYes = document.getElementById("btnLessonNavYes");
    const btnNo = document.getElementById("btnLessonNavNo");
    const btnClose = document.getElementById("btnCloseLessonNavModal");
    if (!body || !btnYes || !btnNo) return;

    const msg = `E' stato raggiunto ${aaaa} esercizio della lezione corrente.\nSi desidera abbandonarla\ne passare ad un esercizio della lezione ${bbbb}?`;
    body.textContent = msg;
    modal.classList.add("active");

    const cleanup = () => {
      modal.classList.remove("active");
      btnYes.removeEventListener("click", handleYes);
      btnNo.removeEventListener("click", handleNo);
      btnClose?.removeEventListener("click", handleNo);
      window.removeEventListener("keydown", handleKey);
      this.startExercise();
    };

    const handleYes = () => {
      cleanup();
      if (onConfirm) onConfirm();
    };

    const handleNo = () => {
      cleanup();
    };

    const handleKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        handleNo();
      } else if (e.key === "Enter") {
        e.preventDefault();
        handleYes();
      }
    };

    btnYes.addEventListener("click", handleYes);
    btnNo.addEventListener("click", handleNo);
    btnClose?.addEventListener("click", handleNo);
    window.addEventListener("keydown", handleKey);
    btnYes.focus();
  }

  navPhrase(delta) {
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    let next = this.typingEng.currentPhraseIdx + delta;

    if (delta < 0 && next < 0 && this.typingEng.currentLessonIdx === 0) {
      this.audio.playError();
      this.showLessonNavAlert(
        "Sei già al primo esercizio della prima lezione.",
      );
      return;
    }

    if (
      delta > 0 &&
      next >= total &&
      this.typingEng.currentLessonIdx >= this.lessons.length - 1
    ) {
      this.audio.playError();
      this.showLessonNavAlert(
        "Sei già all'ultimo esercizio dell'ultima lezione.",
      );
      return;
    }

    if (next < 0 || next >= total) {
      const aaaa = delta < 0 ? "il primo" : "l'ultimo";
      const bbbb = delta < 0 ? "precedente" : "successiva";
      this.showLessonNavConfirm(aaaa, bbbb, () => {
        if (delta < 0) {
          let prevLessonIdx = this.typingEng.currentLessonIdx - 1;
          this.typingEng.currentLessonIdx = prevLessonIdx;
          const prevLesson = this.lessons[prevLessonIdx];
          const prevTotal = (prevLesson?.phrases || []).length;
          this.typingEng.currentPhraseIdx = Math.max(0, prevTotal - 1);
          const cbo = document.getElementById("cboLessons");
          if (cbo) cbo.value = String(prevLessonIdx);
          if (
            this.profileMgr.profile &&
            this.activeLessonsSource === "standard"
          ) {
            this.profileMgr.profile.Lesson = prevLessonIdx;
            this.profileMgr.profile.Exercise = this.typingEng.currentPhraseIdx;
            this.profileMgr.saveProfile();
          }
          this.startExercise();
        } else {
          this.navLesson(1);
        }
      });
      return;
    }

    this.typingEng.currentPhraseIdx = next;
    if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
      this.profileMgr.profile.Exercise = next;
      this.profileMgr.saveProfile();
    }
    this.startExercise();
  }

  randomPhrase() {
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    if (total > 1) {
      let r = Math.floor(Math.random() * total);
      if (r === this.typingEng.currentPhraseIdx) r = (r + 1) % total;
      this.typingEng.currentPhraseIdx = r;
      if (this.profileMgr.profile && this.activeLessonsSource === "standard") {
        this.profileMgr.profile.Exercise = r;
        this.profileMgr.saveProfile();
      }
    }
    this.startExercise();
  }

  startExercise() {
    this.typingEng.initSession();
    const lesson = this.lessons[this.typingEng.currentLessonIdx];
    const total = (lesson?.phrases || []).length;
    const titleEl = document.getElementById("lblExerciseTitle");
    const rangeEl = document.getElementById("lblPhraseRange");
    const prefix =
      this.activeLessonsSource === "custom" ? "Custom " : "Lezione ";

    if (this.typingEng.mode === 0) {
      if (titleEl)
        titleEl.innerText = `${prefix}${this.typingEng.currentLessonIdx + 1}: ${lesson?.name || ""}`;
      if (rangeEl)
        rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} di ${total}`;
    } else if (this.typingEng.mode === 1) {
      if (titleEl)
        titleEl.innerText = `Random Caratteri: ${prefix}${this.typingEng.currentLessonIdx + 1}`;
      if (rangeEl) rangeEl.innerText = "50 caratteri casuali";
    } else if (this.typingEng.mode === 2) {
      if (titleEl) titleEl.innerText = "Modalità Fonemi (Sillabico IT)";
      if (rangeEl) rangeEl.innerText = "Testo generato con Markov";
    } else if (this.typingEng.mode === 3) {
      if (titleEl) titleEl.innerText = "Modalità Tutti i Caratteri";
      if (rangeEl) rangeEl.innerText = "50 caratteri QWERTY IT";
    } else if (this.typingEng.mode === 4) {
      if (titleEl) titleEl.innerText = "Modalità Digitazione Libera (Typing)";
      if (rangeEl) rangeEl.innerText = "Digitazione libera senza guida";
    } else if (this.typingEng.mode === 5) {
      if (titleEl) titleEl.innerText = "Modalità Rimescola Frase Corrente";
      if (rangeEl)
        rangeEl.innerText = `Frase ${this.typingEng.currentPhraseIdx + 1} rimescolata`;
    } else if (this.typingEng.mode === 6) {
      if (titleEl) titleEl.innerText = "Modalità WEAKNESSES (Carenze)";
      if (rangeEl) rangeEl.innerText = "30 caratteri mirati sugli errori";
    }

    const input = document.getElementById("txtTypedInput");
    if (input) {
      input.value = "";
      input.classList.remove("error-active");
    }
    this.updateOriginDisplay();
    this.updateTargetKey();
    this.renderErrorsList();
    this.typingEng.updateMetrics();

    this.returnFocusToTyping();
  }

  formatGuideChar(ch) {
    if (ch === " ") return "␣";
    if (ch === "®" || ch === "\n") return "↵\n";
    if (ch === "→" || ch === "\t") return "⇥";
    return ch;
  }

  updateOriginDisplay() {
    const container = document.getElementById("originTextWrapper");
    const badge = document.getElementById("charTargetBadge");
    if (!container) return;

    if (this.typingEng.mode === 4) {
      container.innerHTML =
        '<span style="color:var(--text-muted);font-style:italic;">Digitazione libera in corso...</span>';
      if (badge) {
        badge.innerText = "LIBERA";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
      return;
    }

    const origin = this.typingEng.originText;
    const typed = this.typingEng.typedText;

    let matchLen = 0;
    while (
      matchLen < typed.length &&
      matchLen < origin.length &&
      typed[matchLen] === origin[matchLen]
    ) {
      matchLen++;
    }

    const partOk = origin.slice(0, matchLen);
    const numErrors = typed.length - matchLen;

    let guideHtml = "";
    if (partOk) {
      const formattedOk = Array.from(partOk)
        .map((c) => this.formatGuideChar(c))
        .join("");
      guideHtml += `<span class="char-typed-ok">${htmlEscape(formattedOk)}</span>`;
    }

    if (numErrors === 0) {
      if (matchLen < origin.length) {
        const targetChar = origin[matchLen];
        const formattedTarget = this.formatGuideChar(targetChar);
        guideHtml += `<span class="char-current-target" id="currentTargetCharSpan">${htmlEscape(formattedTarget)}</span>`;
        const partRest = origin.slice(matchLen + 1);
        if (partRest) {
          const formattedRest = Array.from(partRest)
            .map((c) => this.formatGuideChar(c))
            .join("");
          guideHtml += `<span class="char-remaining">${htmlEscape(formattedRest)}</span>`;
        }
      }
    } else {
      const remainingChars = origin.slice(matchLen);
      let errorSubstring = "";
      let remainingAfterErrors = "";

      if (numErrors <= remainingChars.length) {
        errorSubstring = remainingChars.slice(0, numErrors);
        remainingAfterErrors = remainingChars.slice(numErrors);
      } else {
        const excess = numErrors - remainingChars.length;
        errorSubstring = remainingChars + "␣".repeat(excess);
        remainingAfterErrors = "";
      }

      const formattedErrors = Array.from(errorSubstring)
        .map((c) => this.formatGuideChar(c))
        .join("");
      guideHtml += `<span class="char-error-target" id="currentTargetCharSpan">${htmlEscape(formattedErrors)}</span>`;

      if (remainingAfterErrors) {
        const formattedRest = Array.from(remainingAfterErrors)
          .map((c) => this.formatGuideChar(c))
          .join("");
        guideHtml += `<span class="char-remaining">${htmlEscape(formattedRest)}</span>`;
      }
    }

    container.innerHTML = guideHtml;

    const targetChar = origin[matchLen] || "";
    if (badge) {
      if (this.typingEng.isCompleted) {
        badge.innerText = "FINITO";
        badge.style.background = "var(--success-bg)";
        badge.style.color = "var(--success-color)";
      } else if (numErrors > 0) {
        badge.innerText = "CORREGGI ⌫";
        badge.style.background = "#ef4444";
        badge.style.color = "#ffffff";
      } else if (targetChar === "®" || targetChar === "\n") {
        badge.innerText = "INVIO ↵";
        badge.style.background = "#059669";
        badge.style.color = "#ffffff";
      } else if (targetChar === "→" || targetChar === "\t") {
        badge.innerText = "TAB ⇥";
        badge.style.background = "#2563eb";
        badge.style.color = "#ffffff";
      } else if (targetChar === " ") {
        badge.innerText = "SPAZIO";
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else if (targetChar) {
        badge.innerText = targetChar;
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else {
        badge.innerText = "—";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
    }
  }

  updateTargetKey() {
    if (this.typingEng.mode === 4) {
      return;
    }

    const errorBadge = document.getElementById("handsCentralErrorBadge");
    const successBadge = document.getElementById("handsCentralSuccessBadge");

    if (this.typingEng.isCompleted) {
      this.visual.setTargetChar(null);
      this.visual.clearAllPhysicalFingers();

      // Esercizio completato: disattiva ERRORE e accende permanentemente FINITO
      if (errorBadge) errorBadge.style.opacity = "0";
      if (successBadge) successBadge.style.opacity = "1";
      return;
    } else {
      // Spegnimento garantito del badge FINITO all'avvio di un nuovo esercizio
      if (successBadge) successBadge.style.opacity = "0";
    }

    const matchLen = this.typingEng.getMatchLength();
    let targetChar;

    // Se ci sono errori pendenti nel buffer e l'Auto-Correzione è DISATTIVATA,
    // l'unico tasto corretto da premere per proseguire è obbligatoriamente il Backspace.
    const hasPendingErrors = this.typingEng.typedText.length > matchLen;
    const isAutoCorrectON = !!this.profileMgr.profile?.AutomaticCorrection;

    if (hasPendingErrors && !isAutoCorrectON) {
      targetChar = "Backspace";
    } else {
      targetChar = this.typingEng.originText[this.typingEng.typedText.length];
    }

    this.visual.setTargetChar(targetChar);

    // Gestione persistenza Badge Centrale Mani per Auto-Correzione OFF
    if (errorBadge && !isAutoCorrectON) {
      if (hasPendingErrors) {
        errorBadge.style.opacity = "1";
      } else {
        errorBadge.style.opacity = "0";
      }
    }
  }

  showWrongLetterPopup(wrongChar) {
    const badge = document.getElementById("wrongCharFloatingBadge");
    if (!badge) return;
    badge.innerText = wrongChar === " " ? "SPAZIO" : wrongChar;

    const targetSpan =
      document.getElementById("currentTargetCharSpan") ||
      document.querySelector(".char-current-target");
    const container =
      document.querySelector(".typing-box-container") ||
      document.getElementById("originTextWrapper")?.parentElement;

    if (targetSpan && container) {
      const spanRect = targetSpan.getBoundingClientRect();
      const contRect = container.getBoundingClientRect();
      const centerX = spanRect.left - contRect.left + spanRect.width / 2;
      const topY = spanRect.top - contRect.top - 34;
      badge.style.left = `${Math.round(centerX)}px`;
      badge.style.top = `${Math.round(topY)}px`;
      badge.style.transform = "translateX(-50%)";
    }

    badge.classList.add("visible");
    if (this._wrongBadgeTimer) clearTimeout(this._wrongBadgeTimer);
    this._wrongBadgeTimer = setTimeout(
      () => badge.classList.remove("visible"),
      550,
    );
  }

  setupTypingListeners() {
    const input = document.getElementById("txtTypedInput");
    if (!input) return;

    const handleKeyDown = (e) => {
      if (document.querySelector(".modal-overlay.active")) return;
      if (
        e.target &&
        e.target !== input &&
        (e.target.tagName === "INPUT" ||
          e.target.tagName === "TEXTAREA" ||
          e.target.tagName === "SELECT")
      )
        return;

      const isAppShortcutKey =
        [
          "Digit1",
          "Digit2",
          "Digit3",
          "Digit4",
          "Digit5",
          "Digit6",
          "KeyZ",
          "KeyG",
          "KeyX",
          "KeyA",
          "KeyE",
          "KeyM",
          "KeyS",
          "KeyU",
          "KeyK",
          "KeyO",
          "KeyY",
          "KeyF",
          "KeyL",
          "KeyB",
          "KeyH",
          "KeyD", // <-- Aggiunto D per il toggle Database/Sorgente Custom
        ].includes(e.code) ||
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key);
      const isAltGrActive =
        e.key === "AltGraph" ||
        e.code === "AltRight" ||
        (typeof e.getModifierState === "function" &&
          e.getModifierState("AltGraph"));
      if (
        e.ctrlKey &&
        e.shiftKey &&
        isAppShortcutKey &&
        !isAltGrActive &&
        !e.altKey
      )
        return;
      if (e._handledByApp) return;
      e._handledByApp = true;

      // 1. DISABILITAZIONE AUTO-REPEAT (consentito unicamente per Backspace)
      if (e.repeat && e.key !== "Backspace") {
        e.preventDefault();
        return;
      }

      // 2. STATO CAPS LOCK FISICO
      const isCapsOn =
        typeof e.getModifierState === "function" &&
        e.getModifierState("CapsLock");
      this.visual.updateCapsLockLed(isCapsOn);

      const isAltGrKey = e.key === "AltGraph" || e.code === "AltRight";
      if (
        isAltGrKey &&
        !this.visual.activePhysicalKeys.has("AltLeft") &&
        !this.visual.activePhysicalKeys.has("Alt_AltLeft_1")
      ) {
        this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
        this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
      }
      if (e.key === "Control" && e.code === "ControlLeft") {
        if (
          typeof e.getModifierState === "function" &&
          e.getModifierState("AltGraph") &&
          !this.visual.activePhysicalKeys.has("ControlLeft") &&
          !this.visual.activePhysicalKeys.has("Control_ControlLeft_1")
        ) {
          return;
        }
      }

      // 3. EVIDENZIAZIONE FISICA DEL TASTO PREMUTO
      this.visual.setKeyPressed(e.key, e.code, e.location, true);

      if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
        this.visual.setPhysicalKeyDown(e.key, e.code, e.location);
      }

      const targetChar =
        this.typingEng.mode === 4 || this.typingEng.isCompleted
          ? null
          : this.typingEng.originText[this.typingEng.typedText.length];

      // 4. GESTIONE MODIFICATORI INDEBITI COME ERRORI CATTURABILI
      if (
        e.key === "Shift" ||
        e.key === "Control" ||
        e.key === "Alt" ||
        e.key === "AltGraph" ||
        e.key === "CapsLock"
      ) {
        if (
          this.typingEng.mode === 4 ||
          this.typingEng.isCompleted ||
          !targetChar
        ) {
          return;
        }

        const chord = resolveTargetChord(targetChar);
        const isExpectedMod = chord && chord.allowedMods.has(e.key);

        if (!isExpectedMod) {
          e.preventDefault();
          this.audio.playError();

          let modLabel = "SHIFT";
          if (e.key === "Control") modLabel = "CTRL";
          else if (e.key === "Alt") modLabel = "ALT";
          else if (e.key === "AltGraph") modLabel = "ALT GR";
          else if (e.key === "CapsLock") modLabel = "CAPS";

          if (this.typingEng.canCaptureError()) {
            this.typingEng.countErrors++;
            if (targetChar) this.typingEng.recordCharStat(targetChar, true);
            this.typingEng.sessionErrors.push({
              expected: targetChar,
              wrong: modLabel,
            });
            this.typingEng.currentTargetHasError = true;
            this.renderErrorsList();
          }

          this.typingEng.updateMetrics();
          this.showWrongLetterPopup(modLabel);
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      if (e.key === "Meta" || e.key === "OS" || e.key === "ContextMenu") {
        e.preventDefault();
        this.audio.playError();
        const keyLabel = e.key === "ContextMenu" ? "MENU" : "WIN";

        if (this.typingEng.canCaptureError() && targetChar) {
          this.typingEng.countErrors++;
          this.typingEng.recordCharStat(targetChar, true);
          this.typingEng.sessionErrors.push({
            expected: targetChar,
            wrong: keyLabel,
          });
          this.typingEng.currentTargetHasError = true;
          this.renderErrorsList();
        }

        this.typingEng.updateMetrics();
        this.showWrongLetterPopup(keyLabel);
        input.classList.add("error-active");
        setTimeout(() => input.classList.remove("error-active"), 250);
        return;
      }

      // 5. BACKSPACE CON AZZERAMENTO COMPLETO AL CURSORE ZERO
      if (e.key === "Backspace") {
        e.preventDefault();
        if (this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("", true);
          input.value = this.typingEng.typedText;
          if (this.typingEng.typedText.length === 0) {
            this.typingEng.resetSessionMetrics();
            this.renderErrorsList();
          }
          return;
        }

        if (this.profileMgr.profile?.AutomaticCorrection) {
          this.audio.playError();
          this.showWrongLetterPopup("BACKSPACE");
          return;
        }

        if (this.typingEng.typedText.length === 0) {
          this.audio.playError();
          this.showWrongLetterPopup("BACKSPACE");
          return;
        }

        const res = this.typingEng.handleKeyInput("", true);
        input.value = this.typingEng.typedText;
        input.classList.remove("error-active");

        if (this.typingEng.typedText.length === 0) {
          this.typingEng.resetSessionMetrics();
          this.renderErrorsList();
        }

        this.updateOriginDisplay();
        this.updateTargetKey();
        return;
      }

      // 6. ENTER (Return)
      if (e.key === "Enter") {
        e.preventDefault();
        const isExpected = targetChar === "®" || targetChar === "\n";
        if (isExpected || this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("®", false);
          this.processTypingResult(res, "↵");
        } else {
          this.audio.playError();
          if (this.typingEng.canCaptureError() && targetChar) {
            this.typingEng.countErrors++;
            this.typingEng.recordCharStat(targetChar, true);
            this.typingEng.sessionErrors.push({
              expected: targetChar,
              wrong: "↵",
            });
            this.typingEng.currentTargetHasError = true;
            this.renderErrorsList();
          }
          this.typingEng.updateMetrics();
          this.showWrongLetterPopup("INVIO");
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      // 7. TAB
      if (e.key === "Tab") {
        e.preventDefault();
        const isExpected = targetChar === "→" || targetChar === "\t";
        if (isExpected || this.typingEng.mode === 4) {
          const res = this.typingEng.handleKeyInput("→", false);
          this.processTypingResult(res, "⇥");
        } else {
          this.audio.playError();
          if (this.typingEng.canCaptureError() && targetChar) {
            this.typingEng.countErrors++;
            this.typingEng.recordCharStat(targetChar, true);
            this.typingEng.sessionErrors.push({
              expected: targetChar,
              wrong: "⇥",
            });
            this.typingEng.currentTargetHasError = true;
            this.renderErrorsList();
          }
          this.typingEng.updateMetrics();
          this.showWrongLetterPopup("TAB");
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
        }
        return;
      }

      // 8. CARATTERI ALFANUMERICI E SIMBOLI
      const isAltGrChar =
        e.key === "AltGraph" ||
        e.code === "AltRight" ||
        (typeof e.getModifierState === "function" &&
          e.getModifierState("AltGraph")) ||
        (e.ctrlKey && e.altKey);
      if (e.key.length === 1 && (!e.ctrlKey || isAltGrChar) && !e.metaKey) {
        e.preventDefault();
        const res = this.typingEng.handleKeyInput(e.key, false);
        this.processTypingResult(res, e.key);
      }
    };

    const handleKeyUp = (e) => {
      const isAltGrKeyRelease = e.key === "AltGraph" || e.code === "AltRight";
      if (
        isAltGrKeyRelease &&
        !this.visual.activePhysicalKeys.has("AltLeft") &&
        !this.visual.activePhysicalKeys.has("Alt_AltLeft_1")
      ) {
        this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
        if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
          this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
        }
      }
      if (e.key === "Control" && e.code === "ControlLeft") {
        if (
          typeof e.getModifierState === "function" &&
          e.getModifierState("AltGraph") &&
          !this.visual.activePhysicalKeys.has("ControlLeft") &&
          !this.visual.activePhysicalKeys.has("Control_ControlLeft_1")
        ) {
          return;
        }
      }
      const isCapsOn =
        typeof e.getModifierState === "function" &&
        e.getModifierState("CapsLock");
      this.visual.updateCapsLockLed(isCapsOn);
      this.visual.setKeyPressed(e.key, e.code, e.location, false);
      if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
        this.visual.setPhysicalKeyUp(e.key, e.code, e.location);
      }
    };

    input.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keydown", handleKeyDown);
    input.addEventListener("keyup", handleKeyUp);
    window.addEventListener("keyup", handleKeyUp);

    window.addEventListener("blur", () => {
      document
        .querySelectorAll(".key.key-pressed")
        .forEach((el) => el.classList.remove("key-pressed"));
      this.visual.clearAllPhysicalFingers();
    });

    document.addEventListener("click", (e) => {
      if (document.querySelector(".modal-overlay.active")) return;
      const t = e.target;
      // Esclusione mirata UI per consentire il funzionamento dei click nativi
      // Il refocus reale avverrà dopo il trigger dell'evento "change"
      if (
        t.closest(".floating-window") ||
        t.closest("button") ||
        t.closest("select") ||
        t.closest("input") ||
        t.closest("textarea") ||
        t.closest("a") ||
        t.closest("label")
      )
        return;
      this.returnFocusToTyping();
    });

    document
      .getElementById("btnClearTypingSession")
      ?.addEventListener("click", () => {
        this.typingEng.resetTypingSession();
        this.renderErrorsList(); // Reset immediato visivo del registro errori
        this.returnFocusToTyping();
      });
  }

  processTypingResult(res, charTyped) {
    const input = document.getElementById("txtTypedInput");
    const badge = document.getElementById("handsCentralErrorBadge");

    if (!res || !input) return;

    if (res.status === "correct" || res.status === "typing") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.remove("error-active");

      // Spegnimento immediato del badge Mani se viene premuto il tasto corretto
      // prima della scadenza del timer di Auto-Correzione (v.2.32)
      if (badge) {
        badge.style.opacity = "0";
        if (this._handsBadgeTimer) clearTimeout(this._handsBadgeTimer);
      }

      this.updateOriginDisplay();
      this.updateTargetKey();
    } else if (res.status === "error") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.add("error-active");
      this.showWrongLetterPopup(charTyped);
      this.updateOriginDisplay();
      this.renderErrorsList();
      // Aggiornamento forzato del targetKey essenziale per far commutare il tasto da premere su "Backspace" (v.2.32)
      this.updateTargetKey();
    } else if (res.status === "error-corrected") {
      input.classList.add("error-active");
      this.showWrongLetterPopup(charTyped);
      setTimeout(() => input.classList.remove("error-active"), 200);

      // Mostra temporaneamente (Max 1 sec) il badge Mani in Auto-Correzione (v.2.32)
      if (badge) {
        badge.style.opacity = "1";
        if (this._handsBadgeTimer) clearTimeout(this._handsBadgeTimer);
        this._handsBadgeTimer = setTimeout(() => {
          badge.style.opacity = "0";
        }, 1000);
      }

      this.updateOriginDisplay();
      this.renderErrorsList();
    } else if (res.status === "completed") {
      input.value = this.typingEng.typedText;
      input.scrollTop = input.scrollHeight;
      input.classList.remove("error-active");
      if (badge) badge.style.opacity = "0";
      this.visual.clearAllPhysicalFingers();
      this.visual.setTargetChar(null);
      this.updateOriginDisplay();
      this.updateTargetKey();

      // Ridisegno immediato dei grafici se la finestra Statistiche è attualmente aperta e visibile (v.2.32)
      const statsWin = document.getElementById("statsFloatingWindow");
      if (statsWin && statsWin.classList.contains("window-visible")) {
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      }
    }
  }

  setupShortcuts() {
    window.addEventListener("keydown", (e) => {
      if (e.repeat) return;
      if (document.querySelector(".modal-overlay.active")) return;

      if (e.key === "F1") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) helpBtn.click();
        return;
      }

      if (!e.ctrlKey || !e.shiftKey) return;
      const k = e.key.toUpperCase();

      if (e.key === "ArrowLeft") {
        e.preventDefault();
        this.navPhrase(-1);
        this.returnFocusToTyping();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        this.navPhrase(1);
        this.returnFocusToTyping();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        this.confirmNavLesson(-1);
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        this.confirmNavLesson(1);
      } else if (
        e.code === "Digit1" ||
        e.code === "Numpad1" ||
        e.key === "1" ||
        e.key === "!"
      ) {
        e.preventDefault();
        this.typingEng.mode = 0;
        document.getElementById("cboMode").value = "0";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit2" ||
        e.code === "Numpad2" ||
        e.key === "2" ||
        e.key === '"' ||
        e.key === "@"
      ) {
        e.preventDefault();
        this.typingEng.mode = 1;
        document.getElementById("cboMode").value = "1";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit3" ||
        e.code === "Numpad3" ||
        e.key === "3" ||
        e.key === "£" ||
        e.key === "#"
      ) {
        e.preventDefault();
        this.typingEng.mode = 2;
        document.getElementById("cboMode").value = "2";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit4" ||
        e.code === "Numpad4" ||
        e.key === "4" ||
        e.key === "$"
      ) {
        e.preventDefault();
        this.typingEng.mode = 3;
        document.getElementById("cboMode").value = "3";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit5" ||
        e.code === "Numpad5" ||
        e.key === "5" ||
        e.key === "%"
      ) {
        e.preventDefault();
        this.typingEng.mode = 4;
        document.getElementById("cboMode").value = "4";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (
        e.code === "Digit6" ||
        e.code === "Numpad6" ||
        e.key === "6" ||
        e.key === "&"
      ) {
        e.preventDefault();
        this.typingEng.mode = 6;
        const cbo = document.getElementById("cboMode");
        if (cbo) cbo.value = "6";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (k === "X") {
        e.preventDefault();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (k === "A") {
        e.preventDefault();
        this.randomPhrase();
        this.returnFocusToTyping();
      } else if (k === "E") {
        e.preventDefault();
        this.showSelectPhraseModal();
      } else if (k === "Z") {
        e.preventDefault();
        this.typingEng.mode = 5;
        document.getElementById("cboMode").value = "5";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (k === "G") {
        e.preventDefault();
        this.typingEng.mode = 3;
        document.getElementById("cboMode").value = "3";
        this.updateModeUI();
        this.startExercise();
        this.returnFocusToTyping();
      } else if (k === "M") {
        e.preventDefault();
        this.toggleHandsVis(
          !document
            .getElementById("handsFloatingWindow")
            ?.classList.contains("window-visible"),
        );
        this.returnFocusToTyping();
      } else if (k === "S") {
        e.preventDefault();
        this.toggleStatsWindow();
        this.returnFocusToTyping();
      } else if (k === "U") {
        e.preventDefault();
        this.showLoginModal();
      } else if (k === "K") {
        e.preventDefault();
        const chk = document.getElementById("chkShowKeyBoard");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleKeyboardVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "O") {
        e.preventDefault();
        const chk = document.getElementById("chkShowOrigin");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleOriginVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "Y") {
        e.preventDefault();
        const chk = document.getElementById("chkShowTyped");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleTypedVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "B") {
        e.preventDefault();
        const chk = document.getElementById("chkAutomaticCorrection");
        if (chk) {
          chk.checked = !chk.checked;
          if (this.profileMgr.profile) {
            this.profileMgr.profile.AutomaticCorrection = chk.checked;
            this.profileMgr.saveProfile();
          }
          // Se l'Auto-Correzione viene attivata da tastiera, elimina all'istante gli errori pendenti
          if (chk.checked) {
            this.purgePreExistingErrors();
          }
        }
        this.returnFocusToTyping();
      } else if (k === "H" || e.code === "KeyH") {
        e.preventDefault();
        const helpBtn = document.getElementById("btnHelpLink");
        if (helpBtn) {
          helpBtn.click();
        } else {
          window.open("help_(v.2.32).html", "_blank");
        }
      } else if (k === "F" || k === "L") {
        e.preventDefault();
        const chk = document.getElementById("chkShowErrors");
        if (chk) {
          chk.checked = !chk.checked;
          this.toggleErrorsVis(chk.checked);
        }
        this.returnFocusToTyping();
      } else if (k === "D") {
        // Toggle tra Database Standard ed Esercizi Custom (v.2.32)
        e.preventDefault();
        const btnToggleSource = document.getElementById(
          "btnToggleLessonSource",
        );
        if (btnToggleSource) {
          btnToggleSource.click();
        }
        this.returnFocusToTyping();
      }
    });
  }

  openCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    if (!win || !textarea) return;
    textarea.value =
      this.profileMgr.profile?.CustomText || this.profileMgr.defaultCustomText;
    win.classList.add("window-visible");
    win.style.display = "flex";
    this.windowMgr.clampWindowToViewport(win, false);
  }

  setupCustomEditor() {
    const win = document.getElementById("customEditorWindow");
    const textarea = document.getElementById("customEditorTextarea");
    const btnSave = document.getElementById("btnCustomSave");
    const btnUpload = document.getElementById("btnCustomUpload");
    const btnDownload = document.getElementById("btnCustomDownload");
    const fileInput = document.getElementById("customFileInput");

    btnSave?.addEventListener("click", () => {
      if (this.profileMgr.profile && textarea) {
        const textVal = textarea.value;
        this.profileMgr.profile.CustomText = textVal;
        this.profileMgr.saveProfile();

        const parsed = parseCustomExercises(textVal);
        if (parsed.length > 0) {
          this.customLessons = parsed;
          this.setLessonsSource("custom");
          this.showAppAlert(
            `Esercizi personalizzati salvati! Caricate ${parsed.length} lezioni custom nel menu.`,
            "📝 Editor Custom",
          );
        } else {
          this.showAppAlert(
            "Esercizi salvati nel profilo.",
            "📝 Editor Custom",
          );
        }
        win?.classList.remove("window-visible");
        if (win) win.style.display = "none";
      }
      this.returnFocusToTyping();
    });

    btnDownload?.addEventListener("click", () => {
      if (!textarea) return;
      const blob = new Blob([textarea.value], {
        type: "text/plain;charset=utf-8",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "TypingTrainerCustom.txt";
      a.click();
      URL.revokeObjectURL(url);
      this.returnFocusToTyping();
    });

    btnUpload?.addEventListener("click", () => {
      fileInput?.click();
    });

    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const textVal = ev.target?.result || "";
        if (textarea) textarea.value = textVal;
        if (this.profileMgr.profile) {
          this.profileMgr.profile.CustomText = textVal;
          this.profileMgr.saveProfile();
        }
        const parsed = parseCustomExercises(textVal);
        if (parsed.length > 0) {
          this.customLessons = parsed;
          this.setLessonsSource("custom");
          this.showAppAlert(
            `File "${file.name}" caricato con successo! ${parsed.length} lezioni personalizzate caricate nel menu.`,
            "📂 Caricamento File",
          );
        }
      };
      reader.readAsText(file);
    });
  }

  // Configurazione Listener UI Statistiche e Filtri Temporali
  setupStatsUI() {
    document.querySelectorAll('input[name="statsSort"]').forEach((radio) => {
      radio.addEventListener("change", (e) => {
        // Gestione dinamica evidenziazione visiva label attiva
        document.querySelectorAll('input[name="statsSort"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.sortMode = e.target.value;
        this.statsMgr.renderHistogram();
      });
    });

    document.querySelectorAll('input[name="speedMetric"]').forEach((radio) => {
      radio.addEventListener("change", (e) => {
        // Gestione dinamica evidenziazione visiva label attiva
        document.querySelectorAll('input[name="speedMetric"]').forEach((r) => {
          r.parentElement.classList.remove("radio-label-active");
        });
        e.target.parentElement.classList.add("radio-label-active");

        this.statsMgr.speedMetric = e.target.value;
        this.statsMgr.renderSpeedChart();
      });
    });

    document.querySelectorAll(".speed-filter-chk").forEach((chk) => {
      chk.addEventListener("change", () => {
        const types = [];
        document.querySelectorAll(".speed-filter-chk:checked").forEach((c) => {
          types.push(parseInt(c.value, 10));
        });
        this.statsMgr.filterTypes = types;
        this.statsMgr.renderSpeedChart();
      });
    });

    // Listener interattivi per i campi Range Data-Ora
    const onDateFilterChange = () => {
      this.statsMgr.renderSpeedChart();
    };

    [
      "filterStartDate",
      "filterStartTime",
      "filterEndDate",
      "filterEndTime",
    ].forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener("input", onDateFilterChange);
        el.addEventListener("change", onDateFilterChange);
      }
    });

    // Listener di cancellazione singola per ciascun campo del range (v.2.30)
    const clearSingleField = (inputId) => {
      const input = document.getElementById(inputId);
      if (input) {
        input.value = "";
        input.classList.remove("input-field-error");
        input.classList.remove("filter-active");
        // Ricalcola immediatamente la validità del range e aggiorna il grafico
        this.statsMgr.renderSpeedChart();
      }
    };

    document
      .getElementById("btnClearStartDate")
      ?.addEventListener("click", () => clearSingleField("filterStartDate"));
    document
      .getElementById("btnClearStartTime")
      ?.addEventListener("click", () => clearSingleField("filterStartTime"));
    document
      .getElementById("btnClearEndDate")
      ?.addEventListener("click", () => clearSingleField("filterEndDate"));
    document
      .getElementById("btnClearEndTime")
      ?.addEventListener("click", () => clearSingleField("filterEndTime"));

    // Tasto Reset Periodo per azzerare tutti i controlli temporali insieme
    document
      .getElementById("btnResetDateFilter")
      ?.addEventListener("click", () => {
        const elA = document.getElementById("filterStartDate");
        const elB = document.getElementById("filterStartTime");
        const elC = document.getElementById("filterEndDate");
        const elD = document.getElementById("filterEndTime");
        const msgEl = document.getElementById("lblDateRangeValidationMessage");

        if (elA) elA.value = "";
        if (elB) elB.value = "";
        if (elC) elC.value = "";
        if (elD) elD.value = "";

        [elA, elB, elC, elD].forEach((inp) => {
          if (inp) {
            inp.classList.remove("input-field-error");
            inp.classList.remove("filter-active"); // Rimozione risalto all'azzeramento
          }
        });
        if (msgEl) {
          msgEl.style.display = "none";
          msgEl.textContent = "";
        }

        this.statsMgr.renderSpeedChart();
      });

    document.getElementById("btnClearStats")?.addEventListener("click", () => {
      this.showAppConfirm(
        "Azzerare definitivamente tutte le statistiche e i campioni dell'utente loggato?",
        "⚠ Azzeramento Statistiche",
        () => {
          this.profileMgr.clearUserStats();
          this.statsMgr.clearSelection();
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
        },
      );
    });

    document
      .getElementById("btnClearSelection")
      ?.addEventListener("click", () => {
        const count = this.statsMgr.selectedSampleIndices.size;
        if (count === 0) return;
        const msg = `Sei sicuro di voler eliminare definitivamente i ${count} campioni selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}"?\n\nQuesta operazione cancellerà solo i campioni evidenziati nel grafico e non potrà essere annullata.`;
        this.showAppConfirm(msg, "🗑 Elimina Selezionati", () => {
          const p = this.profileMgr.profile;
          if (p && p.Campioni) {
            p.Campioni = p.Campioni.filter(
              (s) => !this.statsMgr.selectedSampleIndices.has(s.Index),
            );
            p.Campioni.forEach((s, idx) => (s.Index = idx));
            this.profileMgr.saveProfile();
          }
          this.statsMgr.clearSelection();
          this.statsMgr.renderSpeedChart();
          this.statsMgr.renderHistogram();
          this.showAppAlert(
            `Eliminati con successo ${count} campioni selezionati.`,
            "📊 Statistiche",
          );
        });
      });

    document
      .getElementById("btnClearNotSelected")
      ?.addEventListener("click", () => {
        const countSel = this.statsMgr.selectedSampleIndices.size;
        const totalFiltered = this.statsMgr.currentFilteredSamples.length;
        const countNot = totalFiltered - countSel;
        if (countSel === 0 || countNot <= 0) return;
        const msg = `ATTENZIONE: Stai per eliminare TUTTI i ${countNot} campioni NON selezionati dall'archivio storico dell'utente "${this.profileMgr.activeUser}".\n\nVerranno conservati ESCLUSIVAMENTE i ${countSel} campioni attualmente selezionati nel grafico.\n\nSei sicuro di voler procedere? L'operazione non può essere annullata.`;
        this.showAppConfirm(msg, "✂ Elimina Non Selezionati", () => {
          const p = this.profileMgr.profile;
          if (p && p.Campioni) {
            p.Campioni = p.Campioni.filter((s) =>
              this.statsMgr.selectedSampleIndices.has(s.Index),
            );
            p.Campioni.forEach((s, idx) => (s.Index = idx));
            this.profileMgr.saveProfile();
          }
          this.statsMgr.clearSelection();
          this.statsMgr.renderSpeedChart();
          this.statsMgr.renderHistogram();
          this.showAppAlert(
            `Eliminati con successo ${countNot} campioni non selezionati.`,
            "📊 Statistiche",
          );
        });
      });

    document.getElementById("btnExportJson")?.addEventListener("click", () => {
      const jsonStr = this.profileMgr.exportJson();
      const blob = new Blob([jsonStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `TFTT_${this.profileMgr.activeUser || "profile"}.json`;
      a.click();
      URL.revokeObjectURL(url);
    });

    document.getElementById("btnExportXml")?.addEventListener("click", () => {
      const xmlStr = this.profileMgr.exportXml();
      const blob = new Blob([xmlStr], { type: "application/xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `TFTT_${this.profileMgr.activeUser || "profile"}.xml`;
      a.click();
      URL.revokeObjectURL(url);
    });

    const importInput = document.getElementById("statsImportInput");
    document
      .getElementById("btnImportProfile")
      ?.addEventListener("click", () => {
        importInput?.click();
      });

    importInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const text = ev.target?.result || "";
        try {
          if (file.name.endsWith(".json") || text.trim().startsWith("{")) {
            const data = JSON.parse(text);
            if (data.UserID) {
              const uId = data.UserID;
              this.profileMgr.profile = data;
              this.profileMgr.activeUser = uId;
              const users = this.profileMgr.getUsers();
              if (!users.includes(uId)) {
                users.push(uId);
                this.profileMgr.saveUsers(users);
              }
              this.profileMgr.saveProfile();
              this.showAppAlert(
                `Profilo utente "${uId}" importato con successo!`,
                "📂 Importazione Profilo",
              );
              this.loginUser(uId);
              this.statsMgr.renderHistogram();
              this.statsMgr.renderSpeedChart();
            }
          } else {
            this.showAppAlert(
              "File XML rilevato. Per il backup completo utilizzare preferibilmente il formato JSON.",
              "📄 Importazione XML",
            );
          }
        } catch (err) {
          this.showAppAlert(
            "Errore durante l'importazione del file: " + err.message,
            "⚠ Errore Importazione",
          );
        }
      };
      reader.readAsText(file);
    });
  }

  // Gestione visibilità del pannello Registro Errori
  toggleErrorsVis(show) {
    const box = document.getElementById("errorsBoxContainer");
    if (box) box.style.display = show ? "flex" : "none";
    const chk = document.getElementById("chkShowErrors");
    if (chk && chk.checked !== !!show) chk.checked = !!show;
    if (this.profileMgr?.profile) {
      this.profileMgr.profile.ShowErrors = !!show;
      this.profileMgr.saveProfile();
    }
    // Sincronizza la finestra Mani che risente della variazione di altezza della scheda
    requestAnimationFrame(() => {
      this.updateHandsWindowPosition();
    });
  }

  // Rendering dinamico delle coppie di errori commessi
  renderErrorsList() {
    const listCont = document.getElementById("errorsListContent");
    const countBadge = document.getElementById("lblErrorsCountBadge");
    const emptyPlaceholder = document.getElementById(
      "lblErrorsEmptyPlaceholder",
    );
    const handsCounter = document.getElementById("handsErrorCountText");

    if (!listCont) return;

    const errors = this.typingEng.sessionErrors || [];
    if (countBadge) countBadge.innerText = errors.length;

    // Sincronizzazione e visibilità condizionata contatore in alto al centro nella finestra Mani
    if (handsCounter) {
      handsCounter.textContent = `Errori: ${errors.length}`;
      handsCounter.style.display = errors.length > 0 ? "inline" : "none";
    }

    // Reset Immediato a cursore zero o inizio sessione
    if (errors.length === 0) {
      listCont.innerHTML = "";
      listCont.scrollTop = 0;
      if (emptyPlaceholder) emptyPlaceholder.style.display = "inline";
      return;
    }

    if (emptyPlaceholder) emptyPlaceholder.style.display = "none";

    let html = "";
    errors.forEach((err) => {
      const expFmt = this.formatGuideChar(err.expected);
      const wrgFmt = this.formatGuideChar(err.wrong);
      html +=
        `<span class="error-pair" title="Atteso: '${htmlEscape(err.expected)}' | Digitato: '${htmlEscape(err.wrong)}'">` +
        `<span class="char-expected">${htmlEscape(expFmt)}</span>` +
        `<span class="char-wrong">${htmlEscape(wrgFmt)}</span>` +
        `</span>`;
    });

    listCont.innerHTML = html;
    // Auto-scroll verticale verso il basso per inquadrare l'ultimo errore aggiunto
    listCont.scrollTop = listCont.scrollHeight;
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const app = new AppController(
    EMBEDDED_LESSONS,
    EMBEDDED_DEMO_PROFILE,
    EMBEDDED_CUSTOM_DEFAULT,
    EMBEDDED_FONEMI_CORPUS,
  );
  app.start();
  window.app = window.__app = app;
});
