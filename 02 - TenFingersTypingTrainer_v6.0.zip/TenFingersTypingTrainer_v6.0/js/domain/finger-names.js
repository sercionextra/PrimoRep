/* TenFingersTypingTrainer v6.0 — Nomi delle dieci dita; contenuto estratto senza cambiare le regole del dominio. */
const FINGER_NAMES = {
  1: "Mignolo Sinistro",
  2: "Anulare Sinistro",
  3: "Medio Sinistro",
  4: "Indice Sinistro",
  5: "Pollice Sinistro",
  6: "Pollice Destro",
  7: "Indice Destro",
  8: "Medio Destro",
  9: "Anulare Destro",
  10: "Mignolo Destro",
};

