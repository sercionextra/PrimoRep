/* TenFingersTypingTrainer v6.0 — AppController: typing. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
    // =======================================================
    // CLASSE: AppController (main_B_(v.4.9).js)
    // METODO: setupTypingListeners()
    // CONTESTO: Gestione Backspace, Enter/Tab errati con sincronizzazione Dettatura
    // =======================================================
    setupTypingListeners() {
      const input = document.getElementById("txtTypedInput");
      if (!input) return;

      const handleKeyDown = (e) => {
        if (document.querySelector(".modal-overlay.active")) return;
        if (
          e.target &&
          e.target !== input &&
          (e.target.tagName === "INPUT" ||
            e.target.tagName === "TEXTAREA" ||
            e.target.tagName === "SELECT")
        )
          return;

        const isAppShortcutKey =
          [
            "Digit1",
            "Digit2",
            "Digit3",
            "Digit4",
            "Digit5",
            "Digit6",
            "Digit7",
            "Digit8",
            "Digit9",
            "Digit0",
            "Numpad1",
            "Numpad2",
            "Numpad3",
            "Numpad4",
            "Numpad5",
            "Numpad6",
            "Numpad7",
            "Numpad8",
            "Numpad9",
            "Numpad0",
            "Enter",
            "NumpadEnter",
            "KeyP",
            "KeyV",
            "KeyZ",
            "KeyG",
            "KeyX",
            "KeyA",
            "KeyE",
            "KeyM",
            "KeyS",
            "KeyU",
            "KeyK",
            "KeyO",
            "KeyY",
            "KeyF",
            "KeyL",
            "KeyB",
            "KeyH",
            "KeyD",
            "KeyI", // Scorciatoia Velocità Istantanea (Release v6.3)
            "Space",
          ].includes(e.code) ||
          ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(
            e.key,
          );

        const isAltGrActive =
          e.key === "AltGraph" ||
          e.code === "AltRight" ||
          (typeof e.getModifierState === "function" &&
            e.getModifierState("AltGraph"));

        // Se viene premuto un reale tasto di scorciatoia combinato con CTRL+SHIFT
        if (
          e.ctrlKey &&
          e.shiftKey &&
          isAppShortcutKey &&
          !isAltGrActive &&
          !e.altKey
        ) {
          this.modifierSession.shortcutExecuted = true;
          this.modifierSession.activeModifiers.clear();
          return;
        }

        if (e._handledByApp) return;
        e._handledByApp = true;

        // 1. DISABILITAZIONE AUTO-REPEAT (consentito unicamente per Backspace)
        if (e.repeat && e.key !== "Backspace") {
          e.preventDefault();
          return;
        }

        // 2. STATO CAPS LOCK FISICO
        const isCapsOn =
          typeof e.getModifierState === "function" &&
          e.getModifierState("CapsLock");
        this.visual.updateCapsLockLed(isCapsOn);

        const isAltGrKey = e.key === "AltGraph" || e.code === "AltRight";
        if (
          isAltGrKey &&
          !this.visual.activePhysicalKeys.has("AltLeft") &&
          !this.visual.activePhysicalKeys.has("Alt_AltLeft_1")
        ) {
          this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
          this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
        }
        if (e.key === "Control" && e.code === "ControlLeft") {
          if (
            typeof e.getModifierState === "function" &&
            e.getModifierState("AltGraph") &&
            !this.visual.activePhysicalKeys.has("ControlLeft") &&
            !this.visual.activePhysicalKeys.has("Control_ControlLeft_1")
          ) {
            return;
          }
        }

        // 3. EVIDENZIAZIONE FISICA DEL TASTO PREMUTO
        this.visual.setKeyPressed(e.key, e.code, e.location, true);

        if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
          this.visual.setPhysicalKeyDown(e.key, e.code, e.location);
        }

        // Barriera di protezione a sessione completata
        if (this.typingEng.isCompleted && this.typingEng.mode !== 4) {
          e.preventDefault();
          return;
        }

        const targetChar =
          this.typingEng.mode === 4 || this.typingEng.isCompleted
            ? null
            : this.typingEng.originText[this.typingEng.typedText.length];

        // 4. GESTIONE MODIFICATORI: NESSUN ERRORE SU KEYDOWN (v.4.8 - Opzione 2)
        if (
          e.key === "Shift" ||
          e.key === "Control" ||
          e.key === "Alt" ||
          e.key === "AltGraph" ||
          e.key === "CapsLock"
        ) {
          if (
            this.typingEng.mode === 4 ||
            this.typingEng.isCompleted ||
            !targetChar
          ) {
            return;
          }

          const chord = resolveTargetChord(targetChar);
          const isExpectedMod = chord && chord.allowedMods.has(e.key);

          if (isExpectedMod) {
            // Modificatore legittimo necessario per il tasto bersaglio
            this.modifierSession.expectedModsActive.add(e.key);
          } else {
            // Modificatore non previsto per il carattere target: entra nello stato di attesa shortcut
            this.modifierSession.activeModifiers.add(e.key);
            this.modifierSession.shortcutExecuted = false;
            this.modifierSession.abandonErrorReported = false;
          }
          return;
        }

        if (e.key === "Meta" || e.key === "OS" || e.key === "ContextMenu") {
          e.preventDefault();
          this.audio.playError();
          this.dictation.notifyError(); // Notifica vocale immediata "errore" (Release v.5.1)
          const keyLabel = e.key === "ContextMenu" ? "MENU" : "WIN";

          if (this.typingEng.canCaptureError() && targetChar) {
            this.typingEng.countErrors++;
            this.typingEng.recordCharStat(targetChar, true);
            this.typingEng.sessionErrors.push({
              expected: targetChar,
              wrong: keyLabel,
            });
            this.typingEng.currentTargetHasError = true;
            this.renderErrorsList();
          }

          this.typingEng.updateMetrics();
          this.showWrongLetterPopup(keyLabel);
          input.classList.add("error-active");
          setTimeout(() => input.classList.remove("error-active"), 250);
          return;
        }

        if (
          (e.ctrlKey || e.altKey) &&
          !isAltGrActive &&
          this.modifierSession.activeModifiers.size > 0
        ) {
          e.preventDefault();
          return;
        }

        // 5. BACKSPACE CON AZZERAMENTO COMPLETO E NOTIFICA SCALARE ERRORI (Release v.5.1 - Opzione 2)
        if (e.key === "Backspace") {
          e.preventDefault();
          if (this.typingEng.mode === 4) {
            const res = this.typingEng.handleKeyInput("", true);
            input.value = this.formatInputDisplay(this.typingEng.typedText);
            if (this.typingEng.typedText.length === 0) {
              this.typingEng.resetSessionMetrics();
              this.renderErrorsList();
            }
            this.renderInstantSpeedChart();
            return;
          }

          if (this.profileMgr.profile?.AutomaticCorrection) {
            this.audio.playError();
            this.showWrongLetterPopup("BACKSPACE");
            this.dictation.notifyError();
            return;
          }

          if (this.typingEng.typedText.length === 0) {
            this.audio.playError();
            this.showWrongLetterPopup("BACKSPACE");
            return;
          }

          const res = this.typingEng.handleKeyInput("", true);
          input.value = this.formatInputDisplay(this.typingEng.typedText);
          input.classList.remove("error-active");

          if (this.typingEng.typedText.length === 0) {
            this.typingEng.resetSessionMetrics();
            this.renderErrorsList();
          }

          this.updateOriginDisplay();
          this.updateTargetKey();
          this.renderInstantSpeedChart();

          // Notifica atomica: su Backspace NON chiamiamo updateProgress per non abortire la voce con stopAudioOnly()
          if (this.typingEng.mode !== 4) {
            const matchLen = this.typingEng.getMatchLength();
            const typedLen = this.typingEng.typedText.length;
            const remainingErrors = Math.max(0, typedLen - matchLen);
            this.dictation.notifyErrorCorrection(
              remainingErrors,
              typedLen,
              matchLen,
              this.typingEng.originText,
            );
          }
          return;
        }

        // 6. ENTER (Return)
        if (e.key === "Enter") {
          e.preventDefault();
          const isExpected = targetChar === "®" || targetChar === "\n";
          if (isExpected || this.typingEng.mode === 4) {
            const res = this.typingEng.handleKeyInput("®", false);
            this.processTypingResult(res, "↵");
          } else {
            this.audio.playError();
            this.dictation.notifyError(); // Notifica vocale immediata "errore" (Release v.5.1)
            const isCapturable = this.typingEng.canCaptureError();
            if (isCapturable && targetChar) {
              this.typingEng.countErrors++;
              this.typingEng.recordCharStat(targetChar, true);
              this.typingEng.sessionErrors.push({
                expected: targetChar,
                wrong: "↵",
              });
              this.typingEng.currentTargetHasError = true;
              this.renderErrorsList();
            }
            this.typingEng.updateMetrics();
            this.showWrongLetterPopup("INVIO");

            if (!this.profileMgr.profile?.AutomaticCorrection) {
              this.typingEng.typedText += "®";
              input.value = this.formatInputDisplay(this.typingEng.typedText);
              input.classList.add("error-active");
              this.updateOriginDisplay();
              this.updateTargetKey();

              if (this.typingEng.mode !== 4) {
                const matchLen = this.typingEng.getMatchLength();
                this.dictation.updateProgress(
                  this.typingEng.typedText.length,
                  matchLen,
                );
              }
            } else {
              input.classList.add("error-active");
              setTimeout(() => input.classList.remove("error-active"), 250);
            }
          }
          return;
        }

        // 7. TAB
        if (e.key === "Tab") {
          e.preventDefault();
          const isExpected = targetChar === "→" || targetChar === "\t";
          if (isExpected || this.typingEng.mode === 4) {
            const res = this.typingEng.handleKeyInput("→", false);
            this.processTypingResult(res, "⇥");
          } else {
            this.audio.playError();
            this.dictation.notifyError(); // Notifica vocale immediata "errore" (Release v.5.1)
            const isCapturable = this.typingEng.canCaptureError();
            if (isCapturable && targetChar) {
              this.typingEng.countErrors++;
              this.typingEng.recordCharStat(targetChar, true);
              this.typingEng.sessionErrors.push({
                expected: targetChar,
                wrong: "⇥",
              });
              this.typingEng.currentTargetHasError = true;
              this.renderErrorsList();
            }
            this.typingEng.updateMetrics();
            this.showWrongLetterPopup("TAB");

            if (!this.profileMgr.profile?.AutomaticCorrection) {
              this.typingEng.typedText += "→";
              input.value = this.formatInputDisplay(this.typingEng.typedText);
              input.classList.add("error-active");
              this.updateOriginDisplay();
              this.updateTargetKey();

              if (this.typingEng.mode !== 4) {
                const matchLen = this.typingEng.getMatchLength();
                this.dictation.updateProgress(
                  this.typingEng.typedText.length,
                  matchLen,
                );
              }
            } else {
              input.classList.add("error-active");
              setTimeout(() => input.classList.remove("error-active"), 250);
            }
          }
          return;
        }

        // 8. CARATTERI ALFANUMERICI E SIMBOLI
        const isAltGrChar =
          e.key === "AltGraph" ||
          e.code === "AltRight" ||
          (typeof e.getModifierState === "function" &&
            e.getModifierState("AltGraph")) ||
          (e.ctrlKey && e.altKey);
        if (e.key.length === 1 && (!e.ctrlKey || isAltGrChar) && !e.metaKey) {
          e.preventDefault();
          const res = this.typingEng.handleKeyInput(e.key, false);
          this.processTypingResult(res, e.key);
        }
      };

      const handleKeyUp = (e) => {
        const isAltGrKeyRelease = e.key === "AltGraph" || e.code === "AltRight";
        if (
          isAltGrKeyRelease &&
          !this.visual.activePhysicalKeys.has("AltLeft") &&
          !this.visual.activePhysicalKeys.has("Alt_AltLeft_1")
        ) {
          this.visual.setKeyPressed("Control", "ControlLeft", 1, false);
          this.visual.setPhysicalKeyUp("Control", "ControlLeft", 1);
        }
        if (e.key === "Control" && e.code === "ControlLeft") {
          if (
            typeof e.getModifierState === "function" &&
            e.getModifierState("AltGraph") &&
            !this.visual.activePhysicalKeys.has("ControlLeft") &&
            !this.visual.activePhysicalKeys.has("Control_ControlLeft_1")
          ) {
            return;
          }
        }
        const isCapsOn =
          typeof e.getModifierState === "function" &&
          e.getModifierState("CapsLock");
        this.visual.updateCapsLockLed(isCapsOn);
        this.visual.setKeyPressed(e.key, e.code, e.location, false);
        if (this.typingEng.mode === 4 || this.typingEng.isCompleted) {
          this.visual.setPhysicalKeyUp(e.key, e.code, e.location);
        }

        // DIAGNOSI DIFFERITA MODIFICATORI SU KEYUP (v.4.8 - Opzione 2)
        if (
          e.key === "Shift" ||
          e.key === "Control" ||
          e.key === "Alt" ||
          e.key === "AltGraph" ||
          e.key === "CapsLock"
        ) {
          if (this.modifierSession.expectedModsActive.has(e.key)) {
            this.modifierSession.expectedModsActive.delete(e.key);
          } else if (this.modifierSession.activeModifiers.has(e.key)) {
            if (
              !this.modifierSession.shortcutExecuted &&
              !this.modifierSession.abandonErrorReported
            ) {
              this.modifierSession.abandonErrorReported = true;

              const hadBoth =
                this.modifierSession.activeModifiers.has("Control") &&
                this.modifierSession.activeModifiers.has("Shift");
              let modLabel = hadBoth
                ? "CTRL+SHIFT"
                : e.key === "Control"
                  ? "CTRL"
                  : e.key === "Shift"
                    ? "SHIFT"
                    : e.key === "Alt"
                      ? "ALT"
                      : e.key === "AltGraph"
                        ? "ALT GR"
                        : "CAPS";

              const targetChar =
                this.typingEng.mode === 4 || this.typingEng.isCompleted
                  ? null
                  : this.typingEng.originText[this.typingEng.typedText.length];

              this.audio.playError();
              this.dictation.notifyError(); // Notifica vocale immediata "errore" (Release v.5.1)
              const isCapturable = this.typingEng.canCaptureError();
              if (isCapturable && targetChar) {
                this.typingEng.countErrors++;
                this.typingEng.recordCharStat(targetChar, true);
                this.typingEng.sessionErrors.push({
                  expected: targetChar,
                  wrong: modLabel,
                });
                this.typingEng.currentTargetHasError = true;
                this.renderErrorsList();
              }

              this.typingEng.updateMetrics();
              this.showWrongLetterPopup(modLabel);

              if (input) {
                input.classList.add("error-active");
                setTimeout(() => input.classList.remove("error-active"), 250);
              }
            }

            this.modifierSession.activeModifiers.delete(e.key);
          }

          if (!e.ctrlKey && !e.shiftKey && !e.altKey) {
            this.modifierSession.activeModifiers.clear();
            this.modifierSession.expectedModsActive.clear();
            this.modifierSession.shortcutExecuted = false;
            this.modifierSession.abandonErrorReported = false;
          }
        }
      };

      input.addEventListener("keydown", handleKeyDown);
      window.addEventListener("keydown", handleKeyDown);
      input.addEventListener("keyup", handleKeyUp);
      window.addEventListener("keyup", handleKeyUp);

      window.addEventListener("blur", () => {
        document
          .querySelectorAll(".key.key-pressed")
          .forEach((el) => el.classList.remove("key-pressed"));
        this.visual.clearAllPhysicalFingers();
        this.modifierSession.activeModifiers.clear();
        this.modifierSession.expectedModsActive.clear();
        this.modifierSession.shortcutExecuted = false;
        this.modifierSession.abandonErrorReported = false;
      });

      document.addEventListener("click", (e) => {
        if (document.querySelector(".modal-overlay.active")) return;
        const t = e.target;
        if (
          t.closest(".floating-window") ||
          t.closest("button") ||
          t.closest("select") ||
          t.closest("input") ||
          t.closest("textarea") ||
          t.closest("a") ||
          t.closest("label")
        )
          return;
        this.returnFocusToTyping();
      });
    },

    // =======================================================
    // NUOVO METODO (v.3.7): Innesca lo sfarfallio sincronizzato (90 ms)
    // su #charTargetBadge e sul keycap SVG delle mani virtuali
    // =======================================================
    triggerConsecutiveTargetFlicker(targetChar) {
      const badge = document.getElementById("charTargetBadge");
      if (badge) {
        badge.classList.remove("target-flicker-badge");
        void badge.offsetWidth; // Flush sincrono di reflow per riavviare l'animazione
        badge.classList.add("target-flicker-badge");
      }

      const chord = resolveTargetChord(targetChar);
      if (
        chord &&
        chord.info &&
        typeof this.visual?.triggerTargetFlicker === "function"
      ) {
        this.visual.triggerTargetFlicker(chord.info.finger);
      }
    },

    // =======================================================
    // METODO AGGIORNATO (v.3.7): Elaborazione esito battuta
    // Rileva se il carattere successivo coincide con quello appena digitato
    // ed attiva lo sfarfallio di riscontro visivo.
    // =======================================================
    processTypingResult(res, charTyped) {
      const input = document.getElementById("txtTypedInput");
      const badge = document.getElementById("handsCentralErrorBadge");

      if (!res || !input) return;

      if (res.status === "correct" || res.status === "typing") {
        input.value = this.formatInputDisplay(this.typingEng.typedText);
        input.scrollTop = input.scrollHeight;
        input.classList.remove("error-active");

        if (badge) {
          badge.style.opacity = "0";
          if (this._handsBadgeTimer) clearTimeout(this._handsBadgeTimer);
        }

        this.updateOriginDisplay();

        if (this.typingEng.mode !== 4) {
          this.updateTargetKey();
        }

        // Sfarfallio visivo su battute consecutive identiche (v.3.7)
        if (
          res.status === "correct" &&
          this.typingEng.mode !== 4 &&
          !this.typingEng.isCompleted
        ) {
          const prevChar =
            this.typingEng.originText[this.typingEng.typedText.length - 1];
          const nextChar =
            this.typingEng.originText[this.typingEng.typedText.length];
          if (nextChar && prevChar === nextChar) {
            this.triggerConsecutiveTargetFlicker(nextChar);
          }
        }

        // Sincronizzazione Dettatura: avanza con Lookahead ad anticipo fluido (v.3.8)
        if (this.typingEng.mode !== 4) {
          const matchLen = this.typingEng.getMatchLength();
          this.dictation.updateProgress(
            this.typingEng.typedText.length,
            matchLen,
          );
        }
      } else if (res.status === "error") {
        input.value = this.formatInputDisplay(this.typingEng.typedText);
        input.scrollTop = input.scrollHeight;
        input.classList.add("error-active");
        this.showWrongLetterPopup(charTyped);
        this.updateOriginDisplay();
        this.renderErrorsList();
        this.updateTargetKey();

        // Riscontro vocale istantaneo al momento dello sbaglio (Release v.5.1)
        this.dictation.notifyError();

        // Soft Hold: congela la coda della dettatura vocale finché l'errore non viene rimosso
        if (this.typingEng.mode !== 4) {
          const matchLen = this.typingEng.getMatchLength();
          this.dictation.updateProgress(
            this.typingEng.typedText.length,
            matchLen,
          );
        }
      } else if (res.status === "error-corrected") {
        input.classList.add("error-active");
        this.showWrongLetterPopup(charTyped);
        setTimeout(() => input.classList.remove("error-active"), 200);

        if (badge) {
          badge.style.opacity = "1";
          if (this._handsBadgeTimer) clearTimeout(this._handsBadgeTimer);
          this._handsBadgeTimer = setTimeout(() => {
            badge.style.opacity = "0";
          }, 1000);
        }

        this.updateOriginDisplay();
        this.renderErrorsList();

        // Riscontro vocale istantaneo con auto-correzione (Release v.5.1)
        this.dictation.notifyError();

        if (this.typingEng.mode !== 4) {
          const matchLen = this.typingEng.getMatchLength();
          this.dictation.updateProgress(
            this.typingEng.typedText.length,
            matchLen,
          );
        }
      } else if (res.status === "completed") {
        input.value = this.formatInputDisplay(this.typingEng.typedText);
        input.scrollTop = input.scrollHeight;
        input.classList.remove("error-active");
        if (badge) badge.style.opacity = "0";
        this.visual.clearAllPhysicalFingers();
        this.visual.setTargetChar(null);
        this.updateOriginDisplay();
        this.updateTargetKey();

        // Termina e ripulisce la dettatura al completamento dell'esercizio
        this.dictation.stop();

        const statsWin = document.getElementById("statsFloatingWindow");
        if (statsWin && statsWin.classList.contains("window-visible")) {
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
        }
      }

      // Aggiornamento reattivo del tracciato di Velocità Istantanea (Release v6.3)
      this.renderInstantSpeedChart();
    },
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
