/* TenFingersTypingTrainer v6.0 — AppController: windows. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
    // Rileva dinamicamente il fondo reale della zona di battitura
    updateHandsWindowPosition() {
      const handsWin = document.getElementById("handsFloatingWindow");
      if (!handsWin || !this.profileMgr?.profile) return;
      const origin = this.getAppOrigin();
      const prof = this.profileMgr.profile;
      const typingCard =
        document.getElementById("typingCardContainer") ||
        document.querySelector("main .card");
      const metricsGrid = document.querySelector(".metrics-grid");

      let relLeft = prof.HandsLeft !== undefined ? prof.HandsLeft : 660;
      if (relLeft > 1300) {
        relLeft = 660;
        prof.HandsLeft = relLeft;
      }

      if (prof.HandsPinned) {
        // Calcola il fondo reale considerando sia la card che l'ultimo elemento visibile
        let cardBottom = origin.top + 340;
        if (typingCard) {
          cardBottom =
            typingCard.getBoundingClientRect().bottom + window.scrollY;
        }
        if (metricsGrid) {
          const gridBottom =
            metricsGrid.getBoundingClientRect().bottom + window.scrollY;
          // Prende il massimo per non lasciare mai vuoti anche con padding card differenziati
          cardBottom = Math.max(cardBottom, gridBottom);
        }

        const offsetTop =
          prof.HandsOffsetTop !== undefined ? prof.HandsOffsetTop : 16;
        let targetTop = Math.round(cardBottom + offsetTop);
        let targetLeft = Math.round(origin.left + relLeft);

        handsWin.style.left = targetLeft + "px";
        handsWin.style.top = targetTop + "px";
      } else {
        let relTop = prof.HandsTop !== undefined ? prof.HandsTop : 120;
        handsWin.style.left = Math.round(origin.left + relLeft) + "px";
        handsWin.style.top = Math.round(origin.top + relTop) + "px";
      }

      // Viewport Boundary Guard: impedisce coordinate fuori schermo
      this.windowMgr.clampWindowToViewport(handsWin, true);
    },

    updateHandsPinButtonUI() {
      const btn = document.getElementById("btnHandsPin");
      if (!btn || !this.profileMgr?.profile) return;
      const isPinned = !!this.profileMgr.profile.HandsPinned;
      if (isPinned) {
        btn.classList.add("pinned");
        btn.innerText = "📍 Pinned";
        btn.title =
          "Ancoraggio Intelligente: agganciata alla base del blocco di digitazione (clicca per sbloccare)";
      } else {
        btn.classList.remove("pinned");
        btn.innerText = "📌 Pin";
        btn.title =
          "Ancoraggio Libero: clicca per agganciare la finestra alla base del blocco di digitazione";
      }
    },

    setupFloatingWindows() {
      const handsWin = document.getElementById("handsFloatingWindow");
      // Risoluzione ID difensiva con fallback bivalente (v.3.2)
      const handsHeader =
        document.getElementById("handsWindowHeader") ||
        document.getElementById("handsFloatingWindowHeader");
      const statsWin = document.getElementById("statsFloatingWindow");
      const statsHeader = document.getElementById("statsWindowHeader");
      const customWin = document.getElementById("customEditorWindow");
      // Risoluzione ID difensiva per la finestra Custom (v.3.2)
      const customHeader =
        document.getElementById("customEditorHeader") ||
        document.getElementById("customEditorWindowHeader");

      // Finestra Velocità Istantanea (Release v6.3)
      const instantWin = document.getElementById("instantSpeedFloatingWindow");
      const instantHeader = document.getElementById("instantSpeedWindowHeader");

      if (handsWin && handsHeader) {
        this.windowMgr.makeDraggable(handsWin, handsHeader, (x, y) => {
          if (this.profileMgr.profile) {
            const origin = this.getAppOrigin();
            const relX = Math.round(x - origin.left);
            this.profileMgr.profile.HandsLeft = relX;

            if (this.profileMgr.profile.HandsPinned) {
              // Il drag calibra la distanza relativa dal fondo della scheda digitazione
              const typingCard =
                document.getElementById("typingCardContainer") ||
                document.querySelector("main .card");
              const cardBottom = typingCard
                ? typingCard.getBoundingClientRect().bottom + window.scrollY
                : origin.top;
              const offsetTop = Math.round(y - cardBottom);
              this.profileMgr.profile.HandsOffsetTop = offsetTop;
            } else {
              const relY = Math.round(y - origin.top);
              this.profileMgr.profile.HandsTop = relY;
            }
            this.profileMgr.saveProfile();
          }
        });

        this.windowMgr.makeResizable(
          handsWin,
          (w, h, x, y) => {
            if (this.profileMgr.profile) {
              const origin = this.getAppOrigin();
              const relX = Math.round(x - origin.left);
              this.profileMgr.profile.HandsWidth = Math.round(w);
              this.profileMgr.profile.HandsHeight = Math.round(h);
              this.profileMgr.profile.HandsLeft = relX;

              if (this.profileMgr.profile.HandsPinned) {
                const typingCard =
                  document.getElementById("typingCardContainer") ||
                  document.querySelector("main .card");
                const cardBottom = typingCard
                  ? typingCard.getBoundingClientRect().bottom + window.scrollY
                  : origin.top;
                this.profileMgr.profile.HandsOffsetTop = Math.round(
                  y - cardBottom,
                );
              } else {
                this.profileMgr.profile.HandsTop = Math.round(y - origin.top);
              }
              this.profileMgr.saveProfile();
            }
            this.visual.adjustHandsViewport(w, h);
          },
          340,
          200,
        );
      }

      const btnHandsPin = document.getElementById("btnHandsPin");
      if (btnHandsPin) {
        btnHandsPin.addEventListener("click", () => {
          if (this.profileMgr.profile) {
            this.profileMgr.profile.HandsPinned =
              !this.profileMgr.profile.HandsPinned;
            this.profileMgr.saveProfile();
            this.updateHandsPinButtonUI();
            this.updateHandsWindowPosition();
          }
          this.returnFocusToTyping();
        });
      }

      // TOGGLE POSIZIONE TASTI: Alterna tra polpastrelli fissi e falangi reali con pallini guida (v.3.5)
      const btnTogglePos =
        document.getElementById("btnToggleKeyPositions") ||
        document.getElementById("btnToggleKeyDistances");

      if (btnTogglePos) {
        btnTogglePos.addEventListener("click", () => {
          const newState = !this.visual.useCustomKeyDistances;
          this.visual.useCustomKeyDistances = newState;
          btnTogglePos.classList.toggle("active", newState);

          // Se la modalità Posizione Tasti viene ATTIVATA, rimuove immediatamente
          // qualsiasi evidenziazione pulsante attiva sui polpastrelli
          if (newState) {
            document
              .querySelectorAll(".hand-finger.finger-active")
              .forEach((el) => el.classList.remove("finger-active"));
          }

          // Mostra o nasconde i 49 pallini guida vettoriali sul layer SVG
          this.visual.updatePositionDots(newState);

          if (this.profileMgr?.profile) {
            this.profileMgr.profile.UseKeyPositions = newState;
            this.profileMgr.profile.UseCustomKeyDistances = newState;
            this.profileMgr.saveProfile();
          }

          // Rinfresca istantaneamente il rendering delle mani
          this.updateTargetKey();
          this.returnFocusToTyping();
        });
      }

      const btnHandsDef = document.getElementById("btnHandsDefaultPos");
      if (btnHandsDef) {
        btnHandsDef.addEventListener("click", () => {
          this.resetHandsDefaultPosition();
          this.returnFocusToTyping();
        });
      }

      if (statsWin && statsHeader) {
        this.windowMgr.makeDraggable(statsWin, statsHeader, (x, y) => {
          if (this.profileMgr.profile) {
            this.profileMgr.profile.StatLeft = x;
            this.profileMgr.profile.StatTop = y;
            this.profileMgr.saveProfile();
          }
        });

        this.windowMgr.makeResizable(
          statsWin,
          (w, h, x, y) => {
            if (this.profileMgr.profile) {
              this.profileMgr.profile.StatWidth = w;
              this.profileMgr.profile.StatHeight = h;
              this.profileMgr.profile.StatLeft = x;
              this.profileMgr.profile.StatTop = y;
              this.profileMgr.saveProfile();
            }
            this.statsMgr.renderHistogram();
            this.statsMgr.renderSpeedChart();
          },
          540,
          380,
        );
      }

      if (customWin && customHeader) {
        this.windowMgr.makeDraggable(customWin, customHeader, null);
        this.windowMgr.makeResizable(
          customWin,
          (w, h, x, y) => {
            this.windowMgr.clampWindowToViewport(customWin, false);
          },
          650,
          360,
        );
      }

      // Cablaggio Drag & Resize Finestra Velocità Istantanea (Release v6.4)
      if (instantWin && instantHeader) {
        this.setupInstantSpeedParamsModal();

        this.windowMgr.makeDraggable(instantWin, instantHeader, (x, y) => {
          if (this.profileMgr.profile) {
            this.profileMgr.profile.InstantSpeedLeft = x;
            this.profileMgr.profile.InstantSpeedTop = y;
            this.profileMgr.saveProfile();
          }
        });

        this.windowMgr.makeResizable(
          instantWin,
          (w, h, x, y) => {
            if (this.profileMgr.profile) {
              this.profileMgr.profile.InstantSpeedWidth = w;
              this.profileMgr.profile.InstantSpeedHeight = h;
              this.profileMgr.profile.InstantSpeedLeft = x;
              this.profileMgr.profile.InstantSpeedTop = y;
              this.profileMgr.saveProfile();
            }
            this.renderInstantSpeedChart();
          },
          540,
          240,
        );

        document.getElementById("btnInstantSpeedDefaultPos")?.addEventListener("click", () => {
          this.resetInstantSpeedDefaultPosition();
          this.returnFocusToTyping();
        });

        document.getElementById("btnInstantSpeedParams")?.addEventListener("click", () => {
          this.openInstantSpeedParamsModal();
        });

        document.getElementById("btnInstantSpeedClose")?.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          this.toggleInstantSpeedVis(false);
          this.returnFocusToTyping();
        });
      }

      const btnMax = document.getElementById("btnStatsMaximize");
      if (btnMax && statsWin) {
        btnMax.addEventListener("click", () => {
          if (!statsWin.classList.contains("window-fullscreen")) {
            this.prevStatsRect = {
              left: statsWin.style.left || "180px",
              top: statsWin.style.top || "80px",
              width: statsWin.style.width || "820px",
              height: statsWin.style.height || "600px",
            };
            statsWin.classList.add("window-fullscreen");
            // Blocco dello scroll del body principale per evitare conflitti di scrollbar
            document.body.style.overflow = "hidden";
            btnMax.innerText = "🗗 Riduci";
            btnMax.title = "Ripristina dimensioni precedenti";
          } else {
            statsWin.classList.remove("window-fullscreen");
            // Ripristino dello scroll del body principale
            document.body.style.overflow = "";
            if (this.prevStatsRect) {
              statsWin.style.left = this.prevStatsRect.left;
              statsWin.style.top = this.prevStatsRect.top;
              statsWin.style.width = this.prevStatsRect.width;
              statsWin.style.height = this.prevStatsRect.height;
            }
            btnMax.innerText = "⛶ Ingrandisci";
            btnMax.title = "Massimizza / Schermo intero";
            this.windowMgr.clampWindowToViewport(statsWin, false);

            if (this.profileMgr.profile) {
              this.profileMgr.profile.StatLeft = parseInt(
                statsWin.style.left,
                10,
              );
              this.profileMgr.profile.StatTop = parseInt(
                statsWin.style.top,
                10,
              );
              this.profileMgr.profile.StatWidth = parseInt(
                statsWin.style.width,
                10,
              );
              this.profileMgr.profile.StatHeight = parseInt(
                statsWin.style.height,
                10,
              );
              this.profileMgr.saveProfile();
            }
          }
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
          this.returnFocusToTyping();
        });
      }

      const btnResetLayout = document.getElementById("btnStatsResetLayout");
      if (btnResetLayout && statsWin) {
        btnResetLayout.addEventListener("click", () => {
          statsWin.classList.remove("window-fullscreen");
          // Ripristino dello scroll del body principale
          document.body.style.overflow = "";
          statsWin.style.left = "180px";
          statsWin.style.top = "80px";
          statsWin.style.width = "820px";
          statsWin.style.height = "600px";
          statsWin.style.maxWidth = "95vw";
          if (btnMax) {
            btnMax.innerText = "⛶ Ingrandisci";
            btnMax.title = "Massimizza / Schermo intero";
          }
          this.windowMgr.clampWindowToViewport(statsWin, false);

          if (this.profileMgr.profile) {
            this.profileMgr.profile.StatLeft = 180;
            this.profileMgr.profile.StatTop = 80;
            this.profileMgr.profile.StatWidth = 820;
            this.profileMgr.profile.StatHeight = 600;
            this.profileMgr.saveProfile();
          }
          this.statsMgr.renderHistogram();
          this.statsMgr.renderSpeedChart();
          this.returnFocusToTyping();
        });
      }

      // =======================================================
      // SWITCHER 2 GRAFICI STATISTICHE: EVENTI CLICK E SCROLL SYNC
      // =======================================================
      const btnNavHist = document.getElementById("btnStatsNavHist");
      const btnNavSpeed = document.getElementById("btnStatsNavSpeed");
      const sec1 = document.getElementById("statsSection1");
      const sec2 = document.getElementById("statsSection2");
      const statsBody = document.querySelector(
        "#statsFloatingWindow .floating-window-body",
      );

      const updateStatsTabButtons = (activeSectionNum) => {
        if (!btnNavHist || !btnNavSpeed) return;
        if (activeSectionNum === 1) {
          btnNavHist.classList.add("active");
          btnNavSpeed.classList.remove("active");
        } else {
          btnNavSpeed.classList.add("active");
          btnNavHist.classList.remove("active");
        }
      };

      btnNavHist?.addEventListener("click", () => {
        updateStatsTabButtons(1);
        if (sec1) {
          sec1.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (statsBody) {
          statsBody.scrollTo({ top: 0, behavior: "smooth" });
        }
        this.statsMgr.renderHistogram();
        this.returnFocusToTyping();
      });

      btnNavSpeed?.addEventListener("click", () => {
        updateStatsTabButtons(2);
        if (sec2) {
          sec2.scrollIntoView({ behavior: "smooth", block: "start" });
        } else if (statsBody) {
          statsBody.scrollTo({
            top: statsBody.clientHeight,
            behavior: "smooth",
          });
        }
        this.statsMgr.renderSpeedChart();
        this.returnFocusToTyping();
      });

      // Responsive ResizeObserver per ridisegno dinamico dei grafici
      if (window.ResizeObserver) {
        let resizeTimer = null;
        const ro = new ResizeObserver(() => {
          clearTimeout(resizeTimer);
          resizeTimer = setTimeout(() => {
            const sw = document.getElementById("statsFloatingWindow");
            if (sw && sw.classList.contains("window-visible")) {
              this.statsMgr.renderSpeedChart();
              this.statsMgr.renderHistogram();
            }
            const iw = document.getElementById("instantSpeedFloatingWindow");
            if (iw && iw.classList.contains("window-visible")) {
              this.renderInstantSpeedChart();
            }
          }, 80);
        });
        const speedBox = document.getElementById("statsSpeedSvgBox");
        const histBox = document.getElementById("statsHistogramSvgBox");
        const instantBox = document.getElementById("instantSpeedSvgBox");
        if (speedBox) ro.observe(speedBox);
        if (histBox) ro.observe(histBox);
        if (instantBox) ro.observe(instantBox);
      }

      // Sincronizzazione automatica della classe attiva e ridisegno durante lo scroll manuale
      if (statsBody) {
        let scrollDebounce = null;
        statsBody.addEventListener("scroll", () => {
          clearTimeout(scrollDebounce);
          scrollDebounce = setTimeout(() => {
            const h1 = sec1 ? sec1.offsetHeight : 0;
            const currentScroll = statsBody.scrollTop;
            // Se lo scroll supera la metà della prima sezione, il tab attivo diventa il secondo
            if (currentScroll >= h1 / 2) {
              updateStatsTabButtons(2);
              this.statsMgr.renderSpeedChart();
            } else {
              updateStatsTabButtons(1);
              this.statsMgr.renderHistogram();
            }
          }, 100);
        });
      }

      document
        .getElementById("btnHandsClose")
        ?.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          this.toggleHandsVis(false);
          this.returnFocusToTyping();
        });

      document
        .getElementById("btnStatsClose")
        ?.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          document.body.style.overflow = "";
          this.toggleStatsWindow(false);
          this.returnFocusToTyping();
        });

      document
        .getElementById("btnCustomClose")
        ?.addEventListener("click", (e) => {
          e.stopPropagation();
          e.preventDefault();
          const customWin = document.getElementById("customEditorWindow");
          if (customWin) {
            customWin.classList.remove("window-visible");
            customWin.style.display = "none";
          }
          this.returnFocusToTyping();
        });
    },

    resetInstantSpeedDefaultPosition() {
      const instantWin = document.getElementById("instantSpeedFloatingWindow");
      const kbCont =
        document.getElementById("keyboardCardContainer") ||
        document.querySelector(".keyboard-container");
      if (!instantWin) return;

      let targetLeft = 180;
      let targetTop = 360;
      let targetWidth = 920;
      let targetHeight = 340;

      if (kbCont) {
        const rect = kbCont.getBoundingClientRect();
        targetLeft = Math.round(rect.left + window.scrollX);
        targetTop = Math.round(rect.top + window.scrollY);
        targetWidth = Math.max(540, Math.round(rect.width));
        targetHeight = Math.max(240, Math.round(rect.height + 40));
      }

      instantWin.style.left = `${targetLeft}px`;
      instantWin.style.top = `${targetTop}px`;
      instantWin.style.width = `${targetWidth}px`;
      instantWin.style.height = `${targetHeight}px`;

      this.windowMgr.clampWindowToViewport(instantWin, false);

      if (this.profileMgr?.profile) {
        this.profileMgr.profile.InstantSpeedLeft = parseInt(
          instantWin.style.left,
          10,
        );
        this.profileMgr.profile.InstantSpeedTop = parseInt(
          instantWin.style.top,
          10,
        );
        this.profileMgr.profile.InstantSpeedWidth = parseInt(
          instantWin.style.width,
          10,
        );
        this.profileMgr.profile.InstantSpeedHeight = parseInt(
          instantWin.style.height,
          10,
        );
        this.profileMgr.saveProfile();
      }

      this.renderInstantSpeedChart();
    },

    toggleInstantSpeedVis(show) {
      const win = document.getElementById("instantSpeedFloatingWindow");
      if (win) {
        if (show) {
          win.classList.add("window-visible");
          win.style.display = "flex";
          this.windowMgr.clampWindowToViewport(win, false);
          this.renderInstantSpeedChart();
        } else {
          win.classList.remove("window-visible");
          win.style.display = "none";
        }
      }
      const chk = document.getElementById("chkShowInstantSpeed");
      if (chk && chk.checked !== !!show) {
        chk.checked = !!show;
      }
      if (this.profileMgr?.profile) {
        this.profileMgr.profile.ShowInstantSpeed = !!show;
        this.profileMgr.saveProfile();
      }
    },

    resetAllWindowLayouts() {
      // 1. Ripristino Finestra Mani ("10 Fingers")
      this.resetHandsDefaultPosition();

      // 2. Ripristino Finestra Statistiche
      const statsWin = document.getElementById("statsFloatingWindow");
      const btnMax = document.getElementById("btnStatsMaximize");
      if (statsWin) {
        statsWin.classList.remove("window-fullscreen");
        document.body.style.overflow = "";
        statsWin.style.left = "180px";
        statsWin.style.top = "80px";
        statsWin.style.width = "820px";
        statsWin.style.height = "600px";
        statsWin.style.maxWidth = "95vw";
        if (btnMax) {
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero (o ripristina)";
        }
        this.windowMgr.clampWindowToViewport(statsWin, false);

        if (this.profileMgr?.profile) {
          this.profileMgr.profile.StatLeft = 180;
          this.profileMgr.profile.StatTop = 80;
          this.profileMgr.profile.StatWidth = 820;
          this.profileMgr.profile.StatHeight = 600;
        }
      }

      // 3. Ripristino Finestra Editor Frasi Personalizzate
      const customWin = document.getElementById("customEditorWindow");
      if (customWin) {
        customWin.style.left = "240px";
        customWin.style.top = "120px";
        customWin.style.width = "680px";
        customWin.style.height = "480px";
        customWin.style.minWidth = "650px";
        customWin.style.minHeight = "360px";
        this.windowMgr.clampWindowToViewport(customWin, false);
      }

      // 4. Ripristino Finestra Velocità Istantanea (Release v6.3)
      this.resetInstantSpeedDefaultPosition();

      // 5. Salvataggio atomico delle impostazioni nel profilo
      if (this.profileMgr?.profile) {
        this.profileMgr.saveProfile();
      }

      // 6. Notifica visiva di conferma
      this.showAppAlert(
        "Le posizioni e le dimensioni di tutte le finestre fluttuanti (Mani, Statistiche, Editor Custom, Velocità Istantanea) sono state ripristinate ai valori predefiniti all'interno dello schermo.",
        "🪟 Reset Layout Finestre",
      );
    },

    resetHandsDefaultPosition() {
      const handsWin = document.getElementById("handsFloatingWindow");
      const kbCont = document.querySelector(".keyboard-container");
      const kbSvg = document.getElementById("keyboardSvg");
      const typingCard =
        document.getElementById("typingCardContainer") ||
        document.querySelector("main .card");
      if (!handsWin) return;

      const origin = this.getAppOrigin();
      let relLeft = 660;
      let offsetTop = 16;
      let relTop = 120;

      if (kbSvg && kbCont && typingCard) {
        const kbRect = kbSvg.getBoundingClientRect();
        const mainRect = document
          .querySelector("main")
          ?.getBoundingClientRect();
        const cardRect = typingCard.getBoundingClientRect();
        if (mainRect && cardRect) {
          relLeft = Math.round(kbRect.right - mainRect.left + 16);
          offsetTop = Math.round(kbRect.top - cardRect.bottom);
          relTop = Math.max(10, Math.round(kbRect.top - mainRect.top));
        }
      }

      handsWin.style.width = "580px";
      handsWin.style.height = "330px";

      if (this.profileMgr?.profile) {
        this.profileMgr.profile.HandsPinned = true;
        this.profileMgr.profile.HandsOffsetTop = offsetTop;
        this.profileMgr.profile.HandsLeft = relLeft;
        this.profileMgr.profile.HandsTop = relTop;
        this.profileMgr.profile.HandsWidth = 580;
        this.profileMgr.profile.HandsHeight = 330;
        this.profileMgr.saveProfile();
      }

      this.updateHandsPinButtonUI();
      this.updateHandsWindowPosition();
      this.visual.adjustHandsViewport(580, 330);
      this.syncLayoutArrangement();
    },

    syncLayoutArrangement() {
      const handsWin = document.getElementById("handsFloatingWindow");
      const kbCont = document.querySelector(".keyboard-container");
      const handsVisible =
        handsWin && handsWin.classList.contains("window-visible");
      const chkKb = document.getElementById("chkShowKeyBoard");
      const kbVisible = chkKb ? chkKb.checked : true;

      if (kbCont) {
        if (handsVisible && kbVisible) {
          kbCont.classList.add("align-left");
        } else {
          kbCont.classList.remove("align-left");
        }
      }
    },

    toggleHandsVis(show) {
      const hw = document.getElementById("handsFloatingWindow");
      if (hw) {
        if (show) {
          hw.classList.add("window-visible");
          hw.style.display = "flex";
          this.updateHandsPinButtonUI();
          this.updateHandsWindowPosition();
        } else {
          hw.classList.remove("window-visible");
          hw.style.display = "none";
        }
      }
      const chk = document.getElementById("chkShowHands");
      if (chk && chk.checked !== !!show) chk.checked = !!show;
      if (this.profileMgr && this.profileMgr.profile) {
        this.profileMgr.profile.ShowHands = !!show;
        this.profileMgr.saveProfile();
      }
      this.syncLayoutArrangement();
    },

    toggleKeyboardVis(show) {
      const kb = document.getElementById("keyboardCardContainer");
      if (kb) kb.style.display = show ? "block" : "none";
      const chk = document.getElementById("chkShowKeyBoard");
      if (chk && chk.checked !== !!show) chk.checked = !!show;
      if (this.profileMgr?.profile) {
        this.profileMgr.profile.ShowKeyBoard = !!show;
        this.profileMgr.saveProfile();
      }
      requestAnimationFrame(() => {
        this.updateHandsWindowPosition();
        this.syncLayoutArrangement();
      });
    },

    toggleOriginVis(show) {
      const orig = document.getElementById("originTextWrapper");
      const typingCard = document.getElementById("typingCardContainer");
      if (orig) {
        orig.style.display = show ? "block" : "none";
        void orig.offsetHeight;
        if (typingCard) void typingCard.offsetHeight;
      }
      const chk = document.getElementById("chkShowOrigin");
      if (chk && chk.checked !== !!show) chk.checked = !!show;
      if (this.profileMgr?.profile) {
        this.profileMgr.profile.ShowOrigin = !!show;
        this.profileMgr.saveProfile();
      }
      this.updateHandsWindowPosition();
      requestAnimationFrame(() => {
        this.updateHandsWindowPosition();
      });
    },

    toggleTypedVis(show) {
      const inp = document.getElementById("txtTypedInput");
      const typingCard = document.getElementById("typingCardContainer");
      if (inp) {
        inp.style.display = show ? "block" : "none";
        void inp.offsetHeight;
        if (typingCard) void typingCard.offsetHeight;
      }
      const chk = document.getElementById("chkShowTyped");
      if (chk && chk.checked !== !!show) chk.checked = !!show;
      if (this.profileMgr?.profile) {
        this.profileMgr.profile.ShowTyped = !!show;
        this.profileMgr.saveProfile();
      }
      this.updateHandsWindowPosition();
      requestAnimationFrame(() => {
        this.updateHandsWindowPosition();
      });
    },

    toggleStatsWindow(forceState) {
      const win = document.getElementById("statsFloatingWindow");
      if (!win) return;
      const shouldShow =
        typeof forceState === "boolean"
          ? forceState
          : !win.classList.contains("window-visible");
      if (shouldShow) {
        win.classList.add("window-visible");
        win.style.display = "flex";
        this.windowMgr.clampWindowToViewport(win, false);
        this.statsMgr.renderHistogram();
        this.statsMgr.renderSpeedChart();
      } else {
        win.classList.remove("window-visible");
        win.style.display = "none";
      }
      const btn = document.getElementById("btnOpenStats");
      if (btn) btn.classList.toggle("active", shouldShow);
    },
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
