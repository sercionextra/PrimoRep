# Architettura — TenFingersTypingTrainer v6.12

## Obiettivo

La release v6.12 risolve in modo definitivo l'anomalia di generazione nella modalità **FONEMI (Sillabario Italiano N-gram)**, in cui, indipendentemente dal valore configurato per la lunghezza dell'esercizio (fino a 500 caratteri), l'algoritmo generava frequentemente frasi ridotte a una sola riga o a una singola parola striminzita (5-8 caratteri).

---

## Analisi Architetturale del Problema (Root Cause)

1. **Il Ciclo di Generazione Markoviano:**
   - Nel metodo `PhonemeEngine.generate()`, il flusso di caratteri viene costruito iterativamente all'interno di un ciclo `while (safetyCounter < 2000)`.
   - A ogni iterazione, il motore cerca nel corpus attivo le continuazioni possibili per il prefisso corrente (`currentPrefix`).
   - Nel corpus predefinito (e in molti testi caricati dall'utente), dopo le parole a fine riga sono presenti combinazioni di spazi e ritorni a capo che, normalizzati a livello di corpus, producono sequenze di spazi contigui (es. `"falsa  "` o `"sala  "`).

2. **La Trappola del `continue` senza Avanzamento:**
   - Quando il carattere successivo estratto era uno spazio (`nextChar === " "`), il codice verificava se il risultato terminava già con un delimitatore:
     ```javascript
     if (nextChar === " ") {
       if (result.endsWith(" ") || result.endsWith("\n") || result.endsWith("®") || result.endsWith("→")) {
         continue; // TRAPPOLA: il prefisso non veniva aggiornato!
       }
     ```
   - L'istruzione `continue;` saltava l'aggiornamento del prefisso di contesto (`currentPrefix = " ";`), lasciando `currentPrefix` invariato (ancorato al suffisso della parola terminata con spazio, es. `"falsa "`).
   - Nelle iterazioni successive, la ricerca con il medesimo prefisso continuava a restituire il medesimo spazio contiguo dal corpus.
   - Di conseguenza, `safetyCounter` incrementava rapidamente fino a esaurire il limite massimo di guardia (2000 iterazioni) senza aggiungere alcun carattere a `result`.
   - All'uscita forzata del ciclo, il metodo restituiva la sola prima parola estratta (es. "falsa", "saggi", "galla", "ghisa"), manifestando il bug di frase striminzita.

3. **Comportamento con N elevato (N >= 6):**
   - Più la lunghezza dell'N-gramma cresceva, maggiore era la specificità del contesto nel corpus, aumentando drasticamente la probabilità di cadere in un vicolo cieco deterministico e bloccando fino al 25% delle generazioni.

---

## Soluzione Architetturale Adottata (Release v6.12)

La soluzione introdotta in `PhonemeEngine.generate()` agisce su due livelli:

1. **Sblocco del Prefisso tramite Ri-seeding Immediato (`getRandomWordSeed()`):**
   - Quando viene estratto uno spazio e il testo termina già con un delimitatore, anziché eseguire un `continue` passivo mantenendo il vecchio prefisso, il motore assegna immediatamente un nuovo seed casuale compatibile:
     ```javascript
     if (
       result.endsWith(" ") ||
       result.endsWith("\n") ||
       result.endsWith("®") ||
       result.endsWith("→")
     ) {
       currentPrefix = getRandomWordSeed();
       continue;
     }
     ```
   - In questo modo la catena di Markov salta istantaneamente a una nuova parola valida, impedendo loop a vuoto e consentendo a `result` di progredire fluidamente fino alla lunghezza richiesta (es. 500 caratteri).

2. **Guardia di Sicurezza su Parole Runaway a Fine Esercizio:**
   - Nella condizione di arresto naturale alla conclusione dell'esercizio:
     ```javascript
     if (result.length >= this.targetLength) {
       if (
         result.endsWith(" ") ||
         result.endsWith("\n") ||
         result.endsWith("®") ||
         result.endsWith("→") ||
         result.length >= this.targetLength + 40 ||
         safetyCounter > 1500
       ) {
         break;
       }
     }
     ```
   - È stata aggiunta la clausola `result.length >= this.targetLength + 40`: se in presenza di corpus custom insoliti (o N-grammi molto bassi con ripetizioni di lettere senza spazi) la parola finale tarda a concludersi, l'esercizio si interrompe comunque a una distanza di sicurezza contenuta (entro 40 caratteri oltre la soglia target), evitando la generazione di parole anomale estese fino a 1500 caratteri.

---

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `domain/helpers.js` | Normalizzazione, parsing Custom e helper puri |
| `data/lessons.js` | Lezioni e frasi originali |
| `data/demo-profile.js` | Profilo demo con impostazioni predefinite (`FonemiTargetLength: 100`) |
| `data/custom-default.js` | Esercizio Custom predefinito |
| `data/phoneme-corpus.js` | Corpus fonemico di default |
| `domain/keyboard-map.js` | Mappatura tasti/caratteri |
| `domain/finger-names.js` | Nomi delle dita |
| `domain/anatomical-landmarks.js` | Coordinate anatomiche e indici dei landmark |
| `domain/keyboard-helpers.js` | Risoluzione landmark e accordi di tasti |
| `engines/audio-engine.js` | Feedback audio |
| `profiles/profile-manager.js` | Profili multiutente con supporto `FonemiTargetLength` (normalizzazione difensiva, AppVersion v6.12) |
| `domain/phoneme-engine.js` | Generatore markoviano con supporto `targetLength` dinamico (20 - 500) e sblocco immediato del prefisso a confine di parola (v6.12) |
| `ui/window-manager.js` | Finestre flottanti, drag & drop, z-index e vincoli al viewport |
| `engines/typing-engine.js` | Motore di digitazione, passaggio di `targetLength` a `phonemeEng.generate()` in Modalità 2 |
| `ui/visual-renderer.js` | Tastiera virtuale, rendering grafico mani e feedback |
| `engines/dictation-engine.js` | Dettatura vocale e sintesi vocale continua |
| `shared/export-utils.js` | Timestamp e utility di esportazione profili |
| `analytics/statistics-manager.js` | Metriche, grafici di velocità e istogrammi |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.12) |
| `app/controller/metodi-fonemi-dropdown.js` | Configurazione Fonemi, validazione (20 - 500) e persistenza nel profilo |
| `app/controller/metodi-finestre-layout.js` | Gestione layout finestre, modale scorciatoie zoom e notifiche toast |
| `app/controller/metodi-scorciatoie-editor-custom.js` | Gestione scorciatoie globali da tastiera |
| `app/controller/metodi-profili-modali.js` | Ripristino layout profili e reset pulito |
| `app/controller/metodi-avvio-temi-audio.js` | Ciclo di vita applicativo e registrazione bootstrap |
| `app/bootstrap.js` | Bootstrap e registrazione eventi DOM |

---

## Verifiche e Garanzie di Regressione

1. **Benchmark Markoviano N=2..15:**
   - Eseguiti 700 campionamenti su tutti i valori di N (da 2 a 15) con `targetLength = 500`:
   - 0 campioni anomali o striminziti (0 frasi < 100 caratteri);
   - Lunghezza media costantemente compresa tra 500.0 e 502.5 caratteri;
   - Piena preservazione delle opzioni aggiuntive (maiuscole, numeri, matematica, simboli, layout, punteggiatura).
