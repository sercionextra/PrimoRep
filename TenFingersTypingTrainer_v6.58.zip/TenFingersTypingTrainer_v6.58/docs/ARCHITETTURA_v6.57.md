# Architettura TenFingersTypingTrainer v6.57

Documento di aggiornamento architetturale rispetto alla v6.56.

## 1. Obiettivo della Release v6.57
1. Migliorare il contrasto visivo dei due riquadri `.home-row-frame` sui temi scuri `Dark` e `Matrix`.

## 2. Interventi Architetturali
1. **Variabile di tema `--base-dot` (`assets/styles/app.css`):**
   - In `body.theme-dark`: aggiornato `--base-dot` da `#38bdf8` a `#fdfdfa`.
   - In `body.theme-matrix`: aggiornato `--base-dot` da `#10b981` a `#fdfdfa`.
   - Invariati `body.theme-light` (`#0284c7`) e `body.theme-retro` (`#0000cc`).
