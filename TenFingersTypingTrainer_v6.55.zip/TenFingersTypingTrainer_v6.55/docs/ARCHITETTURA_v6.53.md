# Architettura TenFingersTypingTrainer v6.53

Documento di aggiornamento architetturale rispetto alla v6.52.

## 1. Obiettivo della Release v6.53
Migliorare la leggibilità cromatica dei campioni nel grafico delle velocità eliminando l'alone bianco sui punti normali, massimizzando la separazione tra le 8 modalità (`TipoCampione` 1..8) e introducendo l'evidenziazione interattiva a costo computazionale O(1) al passaggio del mouse sui filtri di sessione (Opzione A).

## 2. Interventi Architetturali
1. **Palette ad alto contrasto (`js/analytics/statistics-manager.js`, `assets/styles/app.css`):**
   - `1` Phrases: `#3b82f6` (Blu)
   - `2` Custom: `#facc15` (Giallo limone)
   - `3` Random: `#06b6d4` (Ciano / Turchese)
   - `4` Typing: `#f472b6` (Rosa chiaro)
   - `5` Random Phrase: `#a855f7` (Viola)
   - `6` All Chars: `#ef4444` (Rosso corallo)
   - `7` Fonemi: `#94a3b8` (Grigio perla)
   - `8` Carenze: `#be185d` (Lampone / Amaranto)
2. **Rimozione bordo bianco sui punti normali (`js/analytics/statistics-manager.js`):**
   - In `renderSpeedChart()`, i `<circle>` non selezionati utilizzano `stroke="none"` e `stroke-width="0"`; il bordo bianco resta riservato esclusivamente agli stati `.selected` e `.inspected`.
3. **Evidenziazione O(1) in hover sui filtri (`js/app/controller/metodi-statistiche.js`, `assets/styles/app.css`):**
   - In `setupStatsUI()`, `mouseenter` e `mouseleave` sulle `.speed-filter-label` aggiungono/rimuovono `hover-filter-active` e `hover-type-<1..8>` sul solo nodo `#speedSvgPlot`, delegando al motore CSS del browser l'attenuazione (`opacity: 0.25`) degli altri punti e l'ingrandimento (`r: 8`) dei soli punti con `data-type="<1..8>"`.
