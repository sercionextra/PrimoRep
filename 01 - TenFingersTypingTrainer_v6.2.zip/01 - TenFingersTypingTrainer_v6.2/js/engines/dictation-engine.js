/* TenFingersTypingTrainer v6.1 | dictation-engine.js | Ripresa fluida dal primo carattere non ancora digitato e continuità del lookahead. */
class DictationEngine {
  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: constructor()
  // =======================================================
  constructor() {
    this.synth = window.speechSynthesis || null;
    this.enabled = false;
    this.speed = 0.9;
    this.announceCaps = false;
    this.announceApostrophe = false; // Opzione A (Esplicita Didattica) vs Opzione B (Naturale)
    this.announceSpace = false; // Dettatura esplicita dello spazio agganciato alla parola seguente (Release v.5.0)
    this.forceSpelling = false; // Forza la dettatura lettera per lettera (v.4.2)
    this.quoteCount = 0; // Tracciamento alternanza virgolette (dispari: aperte, pari: chiuse)
    this.mode = 0;
    this.tokens = [];
    this.currentIndex = 0;
    this.isSpeaking = false;
    this.hasPendingError = false;
    this.stallTimer = null;
    this.hasFiredAutoReplay = false; // Flag One-Shot: garantisce che il Replay automatico su inattività intervenga una sola volta per pausa (Release v.5.0)
    this.isSpeakingReplay = false; // Flag di emissione attiva di un messaggio di Replay/supporto (Release v6.0)
    this.isRecoveringFromCorrection = false; // Flag di avvenuta correzione degli errori in attesa di ripresa digitazione (Release v6.0)

    // Tracciamento metriche correnti per Replay automatico su inattività (Release v.4.9)
    this.lastTypedLen = 0;
    this.lastMatchLen = 0;
    this.stateProvider = null; // Provider dinamico dello stato di battitura live (Release v.4.9)

    // Proprietà cross-platform v.4.2
    this.bestVoice = null;
    this.fallbackLocalVoice = null;
    this.watchdogTimer = null;
    this._retainedUtterances = new Set(); // Previene il WebKit Garbage Collection Bug su Apple Safari

    // Stato per Replay Assistito e Spelling a 3 pressioni (v.4.2)
    this.currentText = "";
    this.lastReplayKey = null;
    this.replayCount = 0;

    // Dizionario fonetico simboli isolati e parentesi allineate (Release v.4.6 / v.5.0)
    this.symbolSpelling = {
      ".": "punto",
      ",": "virgola",
      ";": "punto e virgola",
      ":": "due punti",
      "?": "punto interrogativo",
      "!": "punto esclamativo",
      "'": "apostrofo",
      '"': "virgolette",
      "(": "aperta tonda",
      ")": "chiusa tonda",
      "[": "aperta quadra",
      "]": "chiusa quadra",
      "{": "aperta graffa",
      "}": "chiusa graffa",
      "<": "minore",
      ">": "maggiore",
      "/": "slash",
      "\\": "backslash",
      "-": "trattino",
      _: "trattino basso",
      "+": "più",
      "=": "uguale",
      "*": "asterisco",
      "@": "chiocciola",
      "#": "cancelletto",
      $: "dollaro",
      "£": "sterlina",
      "€": "euro",
      "%": "percento",
      "&": "e commerciale",
      "®": "invio",
      "\n": "invio",
      "→": "tàb",
      "\t": "tàb",
      "|": "pipe",
      "^": "circonflesso",
      "§": "paragrafo",
      "°": "gradi",
      ç: "cediglia",
      Ç: "cediglia",
    };

    this.charSpelling = {
      a: "a",
      b: "bi",
      c: "ci",
      d: "di",
      e: "e",
      f: "effe",
      g: "gi",
      h: "acca",
      i: "i",
      j: "i lunga",
      k: "cappa",
      l: "elle",
      m: "emme",
      n: "enne",
      o: "o",
      p: "pi",
      q: "qu",
      r: "erre",
      s: "esse",
      t: "ti",
      u: "u",
      v: "vu",
      w: "doppia vu",
      x: "ics",
      y: "ipsilon",
      z: "zeta",
      ç: "cediglia",
      à: "a grave",
      è: "e grave",
      é: "e acuta",
      ì: "i grave",
      ò: "o grave",
      ù: "u grave",
      " ": "spazio",
    };

    this.initVoices();
  }

  setAnnounceSpace(val) {
    this.announceSpace = !!val;
  }

  // Registrazione del provider per interrogare lo stato live di battitura (Release v.4.9)
  setStateProvider(provider) {
    this.stateProvider = typeof provider === "function" ? provider : null;
  }

  setAnnounceApostrophe(val) {
    this.announceApostrophe = !!val;
  }

  setSpelling(val) {
    this.forceSpelling = !!val;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: formatApostropheExplicit(word)
  // CONTESTO: Scansione esplicita di "apostrofo" per tutte le parole terminanti con ' (Comportamento 1)
  // =======================================================
  // Normalizza la pronuncia esplicita dell'apostrofo per elisioni, troncamenti e accenti (Release v.4.9)
  formatApostropheExplicit(word) {
    if (!word.includes("'")) return word;

    const apostropheIndex = word.indexOf("'");
    const prefix = word.slice(0, apostropheIndex);
    const suffix = word.slice(apostropheIndex + 1);
    const prefixLower = prefix.toLowerCase();

    // Mappa ortoepica per prefissi italiani elisi
    let prefixSpoken = "";
    if (prefixLower === "l") {
      prefixSpoken = "elle apostrofo";
    } else if (prefixLower === "dell") {
      prefixSpoken = "dell apostrofo";
    } else if (prefixLower === "all") {
      prefixSpoken = "all apostrofo";
    } else if (prefixLower === "dall") {
      prefixSpoken = "dall apostrofo";
    } else if (prefixLower === "nell") {
      prefixSpoken = "nell apostrofo";
    } else if (prefixLower === "sull") {
      prefixSpoken = "sull apostrofo";
    } else if (prefixLower === "un") {
      prefixSpoken = "un apostrofo";
    } else if (prefixLower === "c") {
      prefixSpoken = "ci apostrofo";
    } else if (prefixLower === "d") {
      prefixSpoken = "di apostrofo";
    } else if (prefixLower === "s") {
      prefixSpoken = "si apostrofo";
    } else if (prefixLower === "m") {
      prefixSpoken = "emme apostrofo";
    } else if (prefixLower === "t") {
      prefixSpoken = "ti apostrofo";
    } else if (prefixLower === "v") {
      prefixSpoken = "vi apostrofo";
    } else if (/^[aeiou]$/.test(prefixLower)) {
      // Vocale singola con apostrofo (es. E', A', O', U', I') - Comportamento A (Release v.4.9)
      prefixSpoken = `${prefix.toUpperCase()} apostrofo`;
    } else {
      prefixSpoken = `${prefix} apostrofo`;
    }

    if (suffix.length > 0) {
      return `${prefixSpoken} ${suffix}`;
    }
    // Caso troncamento o parola con apostrofo finale (es. "SALMI'", "ATTENTITA'", "po'")
    return prefixSpoken;
  }

  // Helper grammaticale: formatta il conteggio errori in italiano naturale
  _formatErrorCount(count) {
    const parole = [
      "zero",
      "un",
      "due",
      "tre",
      "quattro",
      "cinque",
      "sei",
      "sette",
      "otto",
      "nove",
      "dieci",
    ];
    const parolaNumero = parole[count] || String(count);
    return count === 1 ? "un errore" : `${parolaNumero} errori`;
  }

  // Helper per lo spelling del singolo carattere (Release v.4.6 / v.5.0)
  _spellOutChar(ch) {
    if (!ch) return "";
    const lower = ch.toLowerCase();
    if (ch === " ") return "spazio";
    if (ch === "®" || ch === "\n") return "invio";
    if (ch === "→" || ch === "\t") return "tàb";
    if (ch === "&") return "e commerciale";
    if (ch === "ç" || ch === "Ç" || lower === "ç") return "cediglia";
    if (this.symbolSpelling[ch]) return this.symbolSpelling[ch];
    if (this.charSpelling[lower]) {
      return /^[A-Z]$/.test(ch)
        ? `maiuscola ${this.charSpelling[lower]}`
        : this.charSpelling[lower];
    }
    // Compitazione esplicita cifra per cifra durante lo spelling forzato
    if (/[0-9]/.test(ch)) {
      const numNames = [
        "zero",
        "uno",
        "due",
        "tre",
        "quattro",
        "cinque",
        "sei",
        "sette",
        "otto",
        "nove",
      ];
      return numNames[parseInt(ch, 10)];
    }
    return ch;
  }

  // Helper robusto per la conversione fonetica del singolo carattere (Release v.5.0)
  getSpokenChar(ch, isOpening = false) {
    if (ch === " ") return "spazio";
    if (ch === "®" || ch === "\n") return "invio";
    if (ch === "→" || ch === "\t") return "tàb";
    if (ch === '"')
      return isOpening ? "aperte virgolette" : "chiuse virgolette";
    if (ch === "ç" || ch === "Ç") return "cediglia";
    if (this.symbolSpelling[ch]) return this.symbolSpelling[ch];
    return ch;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: _getCasingPrefix()
  // CONTESTO: Diagnosi esatta su parole con lettere e apostrofo (es. ATTENTITA')
  // =======================================================
  // Algoritmo nativo: individua se una parola è "tutto maiuscolo" o "maiuscolo" (Release v.4.9)
  _getCasingPrefix(word) {
    if (!word || typeof word !== "string") return "";
    // Isola tutti i caratteri alfabetici per valutare l'effettivo casing escludendo l'apostrofo
    const letters = word.replace(/[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g, "");
    if (letters.length === 0) return "";

    const isAllUpper =
      letters.length > 1 &&
      letters === letters.toUpperCase() &&
      /[A-Z]/.test(letters);

    const isTitleOrSingleUpper = !isAllUpper && /^[A-Z]/.test(letters[0]);

    if (isAllUpper) {
      return "tutto maiuscolo";
    } else if (isTitleOrSingleUpper) {
      return "maiuscolo";
    }
    return "";
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.5.0).js)
  // METODO: _sanitizeForTTS(text)
  // CONTESTO: Protezione fonetica anti-acronimi e conversione acustica obbligatoria di 'ç' isolata in 'cediglia'
  // =======================================================
  _sanitizeForTTS(text) {
    if (!text || typeof text !== "string") return "";

    // Sostituzione fonetica proattiva: qualsiasi 'ç' o 'Ç' isolata o racchiusa tra apici/virgolette
    // viene trascritta come "cediglia" prima di raggiungere l'API di sintesi vocale del browser
    let sanitized = text.replace(
      /(^|[^a-zA-ZàèéìòùÀÈÉÌÒÙ])[çÇ](?=$|[^a-zA-ZàèéìòùÀÈÉÌÒÙ])/g,
      "$1cediglia",
    );

    // Se l'utente ha esplicitamente richiesto lo spelling forzato o siamo in modalità a singoli caratteri, non applicare lower-case
    if (this.forceSpelling || [1, 3, 5, 6].includes(this.mode)) {
      return sanitized;
    }

    // Converte in minuscolo tutte le sequenze di 2 o più lettere maiuscole consecutive per evitare che vengano compitate
    return sanitized.replace(/[A-ZÀÈÉÌÒÙ]{2,}/g, (match) =>
      match.toLowerCase(),
    );
  }

  // =========================================================================
  // PUNTO DI INSERIMENTO: _getPunctuationSpoken(punctStr)
  // =========================================================================
  // Converte una sequenza di segni di punteggiatura e simboli nei rispettivi nomi parlati (Release v.4.9)
  _getPunctuationSpoken(punctStr) {
    if (!punctStr || typeof punctStr !== "string") return "";
    const parts = [];
    for (const ch of punctStr) {
      if (ch === '"') {
        parts.push("chiuse virgolette");
      } else if (ch === "®" || ch === "\n") {
        parts.push("invio");
      } else if (ch === "→" || ch === "\t") {
        parts.push("tàb");
      } else if (this.symbolSpelling[ch]) {
        parts.push(this.symbolSpelling[ch]);
      }
    }
    return parts.join(" ");
  }

  // Helper di normalizzazione RFC 5646 elastica: riconosce 'it', 'it-IT', 'it_IT', 'it-CH', 'ita'
  _isItalianVoice(lang) {
    if (!lang) return false;
    const clean = String(lang).toLowerCase().replace(/_/g, "-");
    return clean === "it" || clean.startsWith("it-") || clean === "ita";
  }

  // Watchdog a 2200ms calibrato per consentire l'elaborazione neurale cloud sui Fonemi complessi
  _startWatchdog(utterance, token) {
    this._clearWatchdog();
    this.watchdogTimer = setTimeout(() => {
      if (!this.isSpeaking) {
        this._retainedUtterances.delete(utterance);
        if (this.synth) {
          this.synth.cancel();
        }
        // Se la voce che si è bloccata era una voce remota, riesegue il token con la voce locale stabile
        if (
          this.fallbackLocalVoice &&
          utterance.voice !== this.fallbackLocalVoice
        ) {
          this.speakCurrentToken(this.fallbackLocalVoice);
        }
      }
    }, 2200);
  }

  _clearWatchdog() {
    if (this.watchdogTimer) {
      clearTimeout(this.watchdogTimer);
      this.watchdogTimer = null;
    }
  }

  initVoices() {
    if (!this.synth) return;
    const load = () => {
      const voices = this.synth.getVoices() || [];
      const itVoices = voices.filter((v) => this._isItalianVoice(v.lang));

      if (itVoices.length === 0) {
        this.bestVoice = null;
        this.fallbackLocalVoice = null;
        return;
      }

      // Algoritmo di Scoring Pesato Cross-Platform
      const scoreVoice = (voice) => {
        let score = 0;
        const name = (voice.name || "").toLowerCase();

        // Conformità standard BCP-47
        if (String(voice.lang).toLowerCase().replace(/_/g, "-") === "it-it")
          score += 20;

        // Voci Neurali / Edge Online / Google Network
        if (
          name.includes("natural") ||
          name.includes("neural") ||
          name.includes("online")
        )
          score += 60;
        if (name.includes("google") && !name.includes("offline")) score += 40;

        // Voci Apple Enhanced / Premium / Siri (macOS / iOS)
        if (name.includes("enhanced") || name.includes("premium")) score += 45;
        if (
          name.includes("siri") ||
          name.includes("alice") ||
          name.includes("federica")
        )
          score += 30;

        // Voci Microsoft Desktop OneCore / SAPI5
        if (
          name.includes("elsa") ||
          name.includes("isabella") ||
          name.includes("paola")
        )
          score += 25;

        // Preferenza Timbro didattico: penalizzazione timbri scuri o robotici
        if (
          name.includes("cosimo") ||
          name.includes("diego") ||
          name.includes("matteo")
        )
          score -= 15;

        // Supporto Linux speech-dispatcher / espeak-ng / mbrola
        if (name.includes("espeak") || name.includes("mbrola")) score += 10;

        return score;
      };

      const ranked = [...itVoices].sort(
        (a, b) => scoreVoice(b) - scoreVoice(a),
      );
      this.bestVoice = ranked[0] || null;

      // Voce di riserva garantita a bordo macchina (localService === true) per recovery da offline
      this.fallbackLocalVoice =
        itVoices.find((v) => v.localService === true && scoreVoice(v) > 0) ||
        itVoices.find((v) => v.localService === true) ||
        ranked[ranked.length - 1] ||
        null;
    };

    load();
    if (typeof this.synth.onvoiceschanged !== "undefined") {
      this.synth.onvoiceschanged = load;
    }
  }

  setEnabled(val) {
    this.enabled = !!val;
    if (!this.enabled) {
      this.stop();
    }
  }

  setSpeed(rate) {
    this.speed = Math.max(0.6, Math.min(1.4, rate));
  }

  setAnnounceCaps(val) {
    this.announceCaps = !!val;
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.5.0).js)
  // METODO: tokenizeText(text, mode)
  // CONTESTO: Gestione dello Spazio antecedente agganciato e supporto per simboli e layout
  // =======================================================
  // Tokenizzazione adattiva con lettura esplicita di apostrofo per parole terminanti con ' (Release v.4.9)
  tokenizeText(text, mode) {
    this.mode = mode;
    this.tokens = [];
    this.currentIndex = 0;
    if (!text) return;

    const isSingleCharMode = this.forceSpelling || [1, 3, 5, 6].includes(mode);

    if (isSingleCharMode) {
      for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        let spoken = "";
        const isUpper = /^[A-Z]$/.test(ch);
        const lower = ch.toLowerCase();

        if (ch === '"') {
          this.quoteCount++;
          spoken =
            this.quoteCount % 2 === 1
              ? "aperte virgolette"
              : "chiuse virgolette";
        } else if (ch === "&") {
          spoken = "e commerciale";
        } else if (ch === "ç" || ch === "Ç") {
          spoken = "cediglia";
        } else if (ch === "→" || ch === "\t") {
          spoken = "tàb";
        } else if (this.symbolSpelling[ch]) {
          spoken = this.symbolSpelling[ch];
        } else if (isUpper) {
          spoken = `maiuscola ${this.charSpelling[lower] || lower}`;
        } else if (this.charSpelling[lower]) {
          spoken = this.charSpelling[lower];
        } else if (/[0-9]/.test(ch)) {
          const numNames = [
            "zero",
            "uno",
            "due",
            "tre",
            "quattro",
            "cinque",
            "sei",
            "sette",
            "otto",
            "nove",
          ];
          spoken = numNames[parseInt(ch, 10)];
        } else {
          spoken = ch;
        }

        this.tokens.push({
          startIndex: i,
          endIndex: i + 1,
          wordStart: i,
          wordEnd: i + 1,
          rawWord: ch,
          spokenText: spoken,
        });
      }
    } else {
      let i = 0;
      const len = text.length;

      // Inclusione di Tab (→, \t) nei simboli di apertura affinché " →colonna" formi "spazio tàb colonna" (Release v.5.0)
      const openingSymbols = new Set(['"', "(", "[", "{", "→", "\t"]);
      const closingAndPunct = new Set([
        ".",
        ",",
        ";",
        ":",
        "?",
        "!",
        '"',
        ")",
        "]",
        "}",
        "®",
        "\n",
        "→",
        "\t",
      ]);

      while (i < len) {
        // Conteggio e rilevamento puntuale di OGNI singolo spazio antecedente al blocco (Release v.5.0)
        let spaceCount = 0;
        const spaceStart = i;
        while (i < len && text[i] === " ") {
          spaceCount++;
          i++;
        }

        if (i >= len) break;

        const chunkStart = spaceStart;

        // Prefisso vocale per ogni spazio antecedente rilevato
        const spacesSpokenPrefix =
          this.announceSpace && spaceCount > 0
            ? "spazio ".repeat(spaceCount)
            : "";

        if (text[i] === "<") {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i + 1,
            wordStart: i,
            wordEnd: i + 1,
            rawWord: "<",
            spokenText: `${spacesSpokenPrefix}minore`.trim(),
          });
          i++;
          continue;
        }

        if (text[i] === ">") {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i + 1,
            wordStart: i,
            wordEnd: i + 1,
            rawWord: ">",
            spokenText: `${spacesSpokenPrefix}maggiore`.trim(),
          });
          i++;
          continue;
        }

        if (text[i] === "-") {
          const isNegativeNumberLiteral =
            i + 1 < len &&
            /[0-9]/.test(text[i + 1]) &&
            (i === 0 || text[i - 1] === " " || openingSymbols.has(text[i - 1]));

          if (!isNegativeNumberLiteral) {
            let nextIdx = i + 1;
            while (nextIdx < len && text[nextIdx] === " ") {
              nextIdx++;
            }
            const nextChar = nextIdx < len ? text[nextIdx] : "";
            const isMeno =
              /[0-9]/.test(nextChar) || ["(", "[", "{"].includes(nextChar);

            const spokenMinus = isMeno ? "meno" : "trattino";
            this.tokens.push({
              startIndex: chunkStart,
              endIndex: i + 1,
              wordStart: i,
              wordEnd: i + 1,
              rawWord: "-",
              spokenText: `${spacesSpokenPrefix}${spokenMinus}`.trim(),
            });
            i++;
            continue;
          }
        }

        const leadingSpoken = [];

        // Inserimento della dicitura per ogni spazio antecedente (Release v.5.0)
        if (this.announceSpace && spaceCount > 0) {
          for (let s = 0; s < spaceCount; s++) {
            leadingSpoken.push("spazio");
          }
        }

        while (i < len && openingSymbols.has(text[i])) {
          const sym = text[i];
          if (sym === '"') {
            this.quoteCount++;
            leadingSpoken.push(
              this.quoteCount % 2 === 1
                ? "aperte virgolette"
                : "chiuse virgolette",
            );
          } else if (sym === "→" || sym === "\t") {
            leadingSpoken.push("tàb");
          } else if (this.symbolSpelling[sym]) {
            leadingSpoken.push(this.symbolSpelling[sym]);
          }
          i++;
        }

        const wordStart = i;
        while (
          i < len &&
          text[i] !== " " &&
          !openingSymbols.has(text[i]) &&
          !closingAndPunct.has(text[i]) &&
          text[i] !== "<" &&
          text[i] !== ">" &&
          (text[i] !== "-" ||
            (i === wordStart && i + 1 < len && /[0-9]/.test(text[i + 1])))
        ) {
          i++;
        }

        if (i < len && text[i] === "'") {
          const isNumericApostrophe =
            i > wordStart &&
            /[0-9]/.test(text[i - 1]) &&
            i + 1 < len &&
            /[0-9]/.test(text[i + 1]);

          if (isNumericApostrophe) {
            while (
              i < len &&
              text[i] !== " " &&
              !openingSymbols.has(text[i]) &&
              !closingAndPunct.has(text[i]) &&
              text[i] !== "<" &&
              text[i] !== ">"
            ) {
              i++;
            }
          } else {
            i++;
            while (
              i < len &&
              text[i] !== " " &&
              !openingSymbols.has(text[i]) &&
              !closingAndPunct.has(text[i]) &&
              text[i] !== "<" &&
              text[i] !== ">" &&
              text[i] !== "-"
            ) {
              i++;
            }
          }
        }

        const wordEnd = i;
        let rawWord = text.slice(wordStart, wordEnd);
        let spokenWord = "";

        if (rawWord.length > 0) {
          if (rawWord.includes("&")) {
            rawWord = rawWord.replace(/&/g, " e commerciale ");
          }

          if (rawWord.toLowerCase() === "ç") {
            spokenWord = "cediglia";
          } else if (/[0-9]/.test(rawWord)) {
            let cleanNumber = rawWord.replace(/'/g, "");
            cleanNumber = cleanNumber.replace(/(\d+),(\d+)/g, "$1 virgola $2");
            spokenWord = cleanNumber;
          } else if (this.symbolSpelling[rawWord]) {
            spokenWord = this.symbolSpelling[rawWord];
          } else if (rawWord.includes("'")) {
            // Comportamento 1: tutte le parole che terminano con apostrofo (es. SALMI', ATTENTITA', E', po')
            // pronunciano SEMPRE "apostrofo" affinché il tasto fisico non venga omesso (Release v.4.9)
            const endsWithApos = rawWord.endsWith("'");
            spokenWord =
              endsWithApos || this.announceApostrophe
                ? this.formatApostropheExplicit(rawWord)
                : rawWord;
          } else {
            spokenWord = rawWord;
          }

          if (this.announceCaps && !/[0-9]/.test(rawWord)) {
            const isAllUpper =
              rawWord.length > 1 &&
              rawWord === rawWord.toUpperCase() &&
              /[A-Z]/.test(rawWord);

            const isTitleOrSingleUpper =
              !isAllUpper && /^[A-Z]/.test(rawWord[0]);

            if (isAllUpper) {
              spokenWord = `tutto maiuscolo ${spokenWord}`;
            } else if (isTitleOrSingleUpper) {
              spokenWord = `maiuscolo ${spokenWord}`;
            }
          }
        }

        const trailingSpoken = [];
        while (i < len && closingAndPunct.has(text[i])) {
          const sym = text[i];
          if (sym === '"') {
            this.quoteCount++;
            trailingSpoken.push(
              this.quoteCount % 2 === 1
                ? "aperte virgolette"
                : "chiuse virgolette",
            );
          } else if (sym === "→" || sym === "\t") {
            trailingSpoken.push("tàb");
          } else if (this.symbolSpelling[sym]) {
            trailingSpoken.push(this.symbolSpelling[sym]);
          }
          i++;
        }

        if (i === chunkStart) {
          i++;
          continue;
        }

        const parts = [...leadingSpoken];
        if (spokenWord) parts.push(spokenWord);
        parts.push(...trailingSpoken);

        const combinedSpoken = parts.join(" ").trim();
        if (combinedSpoken.length > 0) {
          this.tokens.push({
            startIndex: chunkStart,
            endIndex: i,
            wordStart: wordStart,
            wordEnd: wordEnd,
            rawWord: rawWord,
            spokenText: combinedSpoken,
          });
        }
      }
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODI: startSession, speakCurrentToken e resetStallTimer
  // CONTESTO: Disaccoppiamento timer da speakCurrentToken e ceiling di 1,5s su audio occupato
  // =======================================================

  startSession(text, mode) {
    this.stop();
    this.quoteCount = 0;
    this.currentText = text || "";
    this.lastReplayKey = null;
    this.replayCount = 0;
    this.hasFiredAutoReplay = false;
    this.isSpeakingReplay = false;
    this.isRecoveringFromCorrection = false;
    this.lastKeystrokeTime = Date.now();

    // Inizializzazione metrica di posizione per la nuova sessione
    this.lastTypedLen = 0;
    this.lastMatchLen = 0;

    this.tokenizeText(text, mode);
    this.currentIndex = 0;
    this.hasPendingError = false;

    if (this.enabled && this.tokens.length > 0) {
      setTimeout(() => {
        this.speakCurrentToken();
        // Arma il timer di inattività fin dall'inizio: se l'allievo esita sulla prima lettera, scatterà il Replay
        this.resetStallTimer();
      }, 120);
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODI: speakCurrentToken() e updateProgress()
  // CONTESTO: Riallineamento dinamico istantaneo su scavalcamento parole e protezione da freeze vocale
  // =======================================================

  // Emissione vocale protetta con auto-resume e anti-freeze (Release v6.1)
  speakCurrentToken(forcedVoice = null, customText = null) {
    if (!this.enabled || !this.synth) return;
    if (this.currentIndex >= this.tokens.length && !customText) return;
    if (this.hasPendingError && !customText) return;

    // Sblocco proattivo da eventuali stati di sospensione dell'engine vocale del browser
    try {
      if (this.synth.paused) {
        this.synth.resume();
      }
    } catch (err) {
      // Fallback silenzioso
    }

    const token = this.tokens[this.currentIndex];
    const textToSpeak =
      customText !== null ? customText : token ? token.spokenText : "";
    if (!textToSpeak) return;

    // Applicazione della protezione fonetica
    const phoneticPayload = this._sanitizeForTTS(textToSpeak);

    const utter = new SpeechSynthesisUtterance(phoneticPayload);
    utter.rate = this.speed;
    utter.pitch = 1.05;
    utter.lang = "it-IT";

    const activeVoice = forcedVoice || this.bestVoice;
    if (activeVoice) {
      utter.voice = activeVoice;
      utter.lang = activeVoice.lang;
    }

    // 1. Registrazione nel set di ancoraggio per prevenire il WebKit GC Bug
    this._retainedUtterances.add(utter);

    // 2. Avvio del Watchdog anti-stallo sia per i token standard che per i testi personalizzati (v6.1)
    this._startWatchdog(utter, token);

    utter.onstart = () => {
      this._clearWatchdog();
      this.isSpeaking = true;
    };

    const cleanup = () => {
      this._clearWatchdog();
      this.isSpeaking = false;
      this.isSpeakingReplay = false;
      this._retainedUtterances.delete(utter);
    };

    utter.onend = () => {
      cleanup();
    };

    utter.onerror = (e) => {
      cleanup();
      if (e.error !== "canceled" && e.error !== "interrupted") {
        if (
          !forcedVoice &&
          this.fallbackLocalVoice &&
          this.bestVoice !== this.fallbackLocalVoice
        ) {
          this.speakCurrentToken(this.fallbackLocalVoice, customText);
          return;
        }
      }
    };

    // Annullamento proattivo di eventuale audio precedente senza bloccare il sintetizzatore (Release v6.1)
    if (this.synth.speaking || this.synth.pending) {
      this.synth.cancel();
      try {
        if (this.synth.paused) {
          this.synth.resume();
        }
      } catch (err) {}
    }

    this.isSpeaking = true;
    this.synth.speak(utter);
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODO: updateProgress()
  // CONTESTO: Sincronizzazione fluida e continua senza interruzione forzata dell'audio (Release v6.1)
  // =======================================================
  // Avanzamento progressivo della scrittura con riallineamento dinamico e lookahead predittivo continuo (Release v6.1)
  updateProgress(typedLen, matchLen) {
    if (!this.enabled || this.tokens.length === 0) return;

    const hasError = typedLen > matchLen;

    // Memorizzazione avanzamento reale
    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;
    this.lastKeystrokeTime = Date.now();
    this.hasPendingError = hasError;

    // Reset sequenza replay manuali
    this.lastReplayKey = null;
    this.replayCount = 0;

    // Riabilita il promemoria One-Shot per l'eventuale sosta successiva
    this.hasFiredAutoReplay = false;

    // Riarma il timer dei 3,5 secondi
    this.resetStallTimer();

    // Se vi sono errori pendenti, adotta il Soft Hold
    if (hasError) {
      return;
    }

    // REGOLA ARCHITETTURALE CONFERMATA:
    // Individuazione in tempo reale del token fisico in cui si trova il cursore dell'allievo (matchLen)
    let activeTokenIdx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (
      activeTokenIdx === -1 &&
      matchLen >= this.tokens[this.tokens.length - 1].endIndex
    ) {
      activeTokenIdx = this.tokens.length - 1;
    }
    if (activeTokenIdx === -1) return;

    // Sincronizzazione predittiva avanzata (Release v6.1):
    // Gestione differenziata se il cursore ha scavalcato la parola o se si trova nella parola corrente
    if (activeTokenIdx > this.currentIndex) {
      // Slancio veloce: l'allievo è avanzato oltre il token corrente.
      // Valuta se annunciare subito il nuovo token o anticipare già il successivo in base alla soglia
      const curToken = this.tokens[activeTokenIdx];
      const tokenSpan = curToken.endIndex - curToken.startIndex;
      const progressInToken = matchLen - curToken.startIndex;
      const threshold = Math.max(1, Math.floor(tokenSpan * 0.65));

      if (
        progressInToken >= threshold &&
        activeTokenIdx + 1 < this.tokens.length
      ) {
        this.currentIndex = activeTokenIdx + 1;
        this.speakCurrentToken();
      } else {
        this.currentIndex = activeTokenIdx;
        this.speakCurrentToken();
      }
    } else if (activeTokenIdx === this.currentIndex) {
      // Avanzamento naturale: calcolo della soglia di anticipo (65% del token corrente)
      const curToken = this.tokens[this.currentIndex];
      const tokenSpan = curToken.endIndex - curToken.startIndex;
      const progressInToken = matchLen - curToken.startIndex;
      const threshold = Math.max(1, Math.floor(tokenSpan * 0.65));

      if (
        progressInToken >= threshold &&
        this.currentIndex + 1 < this.tokens.length
      ) {
        this.currentIndex++;
        this.speakCurrentToken();
      }
    }
    // Se activeTokenIdx < this.currentIndex, il token futuro è già stato anticipato dal lookahead:
    // la dettatura procede senza salti né ripetizioni.
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODI REATTIVI: notifyError() e notifyErrorCorrection()
  // =======================================================

  // Notifica vocale istantanea alla battuta errata (Release v6.0)
  notifyError() {
    if (!this.enabled || !this.synth) return;
    this.stopAudioOnly();
    this.speakCurrentToken(null, "errore");
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODO: notifyErrorCorrection()
  // CONTESTO: Ripresa diretta dal primo carattere non ancora digitato ad azzeramento errori (Release v6.1)
  // =======================================================

  // Notifica vocale atomica alla cancellazione con Backspace (Release v6.1)
  notifyErrorCorrection(remainingErrors, typedLen, matchLen, originText) {
    if (!this.enabled || !this.synth) return;
    this.lastKeystrokeTime = Date.now();
    this.hasFiredAutoReplay = false;
    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;
    this.hasPendingError = remainingErrors > 0;
    this.stopAudioOnly();

    if (remainingErrors > 0) {
      // Se restano ancora errori da cancellare, scandisce quanti ne mancano
      const msg = `ancora ${this._formatErrorCount(remainingErrors)}`;
      this.speakCurrentToken(null, msg);
      this.resetStallTimer(); // Riarma il timer dei 3,5s per questa sosta
    } else {
      // Release v6.1: Non appena gli errori tornano a zero, la dettatura riprende direttamente dal primo carattere non ancora digitato
      this.resumeFromKeystroke(matchLen, originText);
    }
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODI AUSILIARI: _getRemainingPrompt() e resumeFromKeystroke()
  // CONTESTO: Calcolo ed emissione vocale della porzione residua non ancora digitata
  // =======================================================
  _getRemainingPrompt(token, matchLen, textRef) {
    if (!token) return "";
    const remainingParts = [];
    let remainingWordLetters = "";

    // C.1 Eventuali spazi antecedenti non ancora digitati
    let curIdx = Math.max(matchLen, token.startIndex);
    if (this.announceSpace && curIdx < token.wordStart) {
      while (
        curIdx < token.wordStart &&
        curIdx < textRef.length &&
        textRef[curIdx] === " "
      ) {
        remainingParts.push("spazio");
        curIdx++;
      }
    } else {
      while (
        curIdx < token.wordStart &&
        curIdx < textRef.length &&
        textRef[curIdx] === " "
      ) {
        curIdx++;
      }
    }

    // C.2 Eventuali simboli di apertura non ancora digitati prima della parola
    while (curIdx < token.wordStart && curIdx < textRef.length) {
      remainingParts.push(this.getSpokenChar(textRef[curIdx], true));
      curIdx++;
    }

    // C.3 Porzione residua della parola o simbolo (con Casing associato direttamente alle lettere)
    if (curIdx < token.wordEnd && curIdx < textRef.length) {
      remainingWordLetters = textRef.slice(curIdx, token.wordEnd);

      let casingPrefix = "";
      const shouldAnnounceCaps =
        this.announceCaps || [1, 3, 5, 6].includes(this.mode);

      if (
        shouldAnnounceCaps &&
        remainingWordLetters.length > 0 &&
        !/[0-9]/.test(remainingWordLetters)
      ) {
        const lettersOnly = remainingWordLetters.replace(
          /[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g,
          "",
        );
        if (lettersOnly.length > 0) {
          const rawWord = token.rawWord || "";
          const cleanRaw = rawWord.replace(/[^a-zA-ZàèéìòùçÀÈÉÌÒÙÇ]/g, "");
          const isOriginalAllUpper =
            cleanRaw.length > 1 &&
            cleanRaw === cleanRaw.toUpperCase() &&
            /[A-Z]/.test(cleanRaw);

          if (isOriginalAllUpper && /[A-Z]/.test(lettersOnly)) {
            casingPrefix = "tutto maiuscolo ";
          } else if (/^[A-Z]/.test(lettersOnly[0])) {
            casingPrefix = "maiuscolo ";
          }
        }
      }

      if (this.symbolSpelling[remainingWordLetters]) {
        remainingParts.push(this.symbolSpelling[remainingWordLetters]);
      } else if (remainingWordLetters === "'") {
        remainingParts.push("apostrofo");
      } else if (remainingWordLetters.endsWith("'")) {
        const baseRem = remainingWordLetters.slice(0, -1);
        remainingParts.push(`${casingPrefix}${baseRem} apostrofo`.trim());
      } else if (remainingWordLetters.includes("'")) {
        remainingParts.push(
          `${casingPrefix}${this.formatApostropheExplicit(remainingWordLetters)}`.trim(),
        );
      } else if (/^[a-zA-ZàèéìòùÀÈÉÌÒÙ0-9]+$/.test(remainingWordLetters)) {
        remainingParts.push(`${casingPrefix}${remainingWordLetters}`.trim());
      } else {
        for (const ch of remainingWordLetters) {
          remainingParts.push(this.getSpokenChar(ch));
        }
      }
      curIdx = token.wordEnd;
    }

    // C.4 Eventuali simboli di chiusura, punteggiatura o layout non ancora digitati
    while (curIdx < token.endIndex && curIdx < textRef.length) {
      remainingParts.push(this.getSpokenChar(textRef[curIdx], false));
      curIdx++;
    }

    return remainingParts.join(" ").trim();
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.1).js)
  // METODO: resumeFromKeystroke()
  // CONTESTO: Ripresa immediata della dettatura vocale dal primo carattere non ancora digitato
  // =======================================================
  resumeFromKeystroke(matchLen, originText) {
    if (!this.enabled || !this.synth || this.tokens.length === 0) return;
    this.hasPendingError = false;
    this.lastReplayKey = null;
    this.replayCount = 0;
    this.hasFiredAutoReplay = false;

    const textRef = originText || this.currentText || "";

    // Individuazione del token corrispondente alla posizione reale del cursore
    let idx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (idx === -1) {
      idx = this.tokens.findIndex((t) => t.startIndex >= matchLen);
    }
    if (idx === -1) idx = Math.max(0, this.tokens.length - 1);

    this.currentIndex = idx;
    const token = this.tokens[idx];
    const isSingleCharFlow =
      this.forceSpelling || [1, 3, 5, 6].includes(this.mode);

    if (isSingleCharFlow || !token) {
      if (textRef && matchLen < textRef.length) {
        const spokenChar = this._spellOutChar(textRef[matchLen]);
        this.speakCurrentToken(null, spokenChar);
      } else if (token) {
        this.speakCurrentToken(null, token.spokenText);
      }
    } else {
      let promptToSpeak = "";
      if (matchLen <= token.startIndex) {
        promptToSpeak = token.spokenText;
      } else {
        promptToSpeak = this._getRemainingPrompt(token, matchLen, textRef);
      }

      if (!promptToSpeak && this.currentIndex + 1 < this.tokens.length) {
        this.currentIndex++;
        promptToSpeak = this.tokens[this.currentIndex].spokenText;
      }

      if (promptToSpeak) {
        this.speakCurrentToken(null, promptToSpeak);
      }
    }

    this.resetStallTimer();
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODO: replay()
  // CONTESTO: Replay assistito con casing associato rigorosamente al vocabolo (spazio prima del casing)
  // =======================================================
  replay(typedLen = 0, matchLen = 0, originText = null, isAutomatic = false) {
    if (!this.synth || this.tokens.length === 0) return;
    this.stopAudioOnly();

    this.lastTypedLen = typedLen;
    this.lastMatchLen = matchLen;

    if (isAutomatic) {
      this.hasFiredAutoReplay = true;
    }

    const textRef = originText || this.currentText || "";
    const numErrors = Math.max(0, typedLen - matchLen);

    // 1. Tracciamento Replay Consecutivi per la stessa posizione
    const posKey = `${typedLen}_${matchLen}`;
    if (!isAutomatic) {
      if (this.lastReplayKey === posKey) {
        this.replayCount++;
      } else {
        this.lastReplayKey = posKey;
        this.replayCount = 1;
      }
    }

    // 2. Individuazione del token corrispondente alla posizione reale di digitazione
    let idx = this.tokens.findIndex(
      (t) => matchLen >= t.startIndex && matchLen < t.endIndex,
    );
    if (idx === -1) {
      idx = this.tokens.findIndex((t) => t.startIndex >= matchLen);
    }
    if (idx === -1) idx = Math.max(0, this.tokens.length - 1);

    this.currentIndex = idx;
    this.hasPendingError = false;
    this.isSpeakingReplay = true; // Segnala che la voce sta riproducendo un messaggio di supporto o completamento (Release v6.0)

    const token = this.tokens[idx];
    const isSingleCharFlow =
      this.forceSpelling || [1, 3, 5, 6].includes(this.mode);

    // =========================================================================
    // CASO A: 3° REPLAY MANUALE CONSECUTIVO -> SPELLING LETTERA PER LETTERA
    // =========================================================================
    if (!isAutomatic && this.replayCount >= 3) {
      const spellParts = [];
      if (numErrors > 0) {
        for (let b = 0; b < numErrors; b++) {
          spellParts.push("back");
        }
      }
      if (textRef && matchLen < textRef.length) {
        if (textRef[matchLen] === " ") {
          spellParts.push("spazio");
        }
        if (token) {
          const spellStart = Math.max(matchLen, token.startIndex);
          const charsToSpell = textRef.slice(spellStart, token.endIndex);
          for (const ch of charsToSpell) {
            spellParts.push(this._spellOutChar(ch));
          }
        } else if (matchLen < textRef.length) {
          spellParts.push(this._spellOutChar(textRef[matchLen]));
        }
      }
      const spelledMessage = spellParts.filter(Boolean).join(", ");
      if (spelledMessage.length > 0) {
        this.speakCurrentToken(null, spelledMessage);
        return;
      }
    }

    // =========================================================================
    // CASO B: MODALITÀ SPELLING ATTIVA O SEQUENZE NON LESSICALI
    // =========================================================================
    if (isSingleCharFlow || !token) {
      let msg = "";
      if (numErrors > 0) {
        msg = `${this._formatErrorCount(numErrors)} `;
      }
      if (textRef && matchLen < textRef.length) {
        msg += this._spellOutChar(textRef[matchLen]);
      } else if (token) {
        msg += token.spokenText;
      }
      this.speakCurrentToken(null, msg.trim());
      return;
    }

    // =========================================================================
    // CASO C: MODALITÀ LESSICALI (Diagnosi Errori + Risoluzione Fonetica e Casing)
    // =========================================================================
    const errorPrefix =
      numErrors > 0 ? `${this._formatErrorCount(numErrors)} ` : "";

    // Calcolo dinamico delle componenti residue non ancora digitate (da matchLen a token.endIndex)
    const remainingPrompt = this._getRemainingPrompt(token, matchLen, textRef);

    // Costruzione del messaggio: se vi sono errori O se la parola è parzialmente digitata
    if (numErrors > 0 || matchLen > token.startIndex) {
      const compositePhrase =
        `${errorPrefix}completa digitando "${remainingPrompt}"`.trim();
      this.speakCurrentToken(null, compositePhrase);
      return;
    }

    // Inizio token senza errori: pronuncia direttamente token.spokenText (già perfettamente ordinato con spazio + casing + vocabolo)
    this.speakCurrentToken(null, token.spokenText);
  }

  // =======================================================
  // CLASSE: DictationEngine (main_A_(v.5.0).js)
  // METODO: resetStallTimer()
  // =======================================================
  // Timer di inattività a 3,5 secondi con tolleranza massima di 1,5 secondi su audio occupato (Release v6.0)
  resetStallTimer() {
    this.clearStallTimer();
    if (!this.enabled || this.tokens.length === 0) return;
    if (this.hasFiredAutoReplay) return;

    this.stallTimer = setTimeout(() => {
      if (!this.enabled || this.hasFiredAutoReplay) return;

      // Auto-healing: verifica se il motore hardware del browser ha realmente audio in corso
      const isHardwareSpeaking = !!(
        this.synth &&
        (this.synth.speaking || this.synth.pending)
      );
      if (!isHardwareSpeaking) {
        this.isSpeaking = false;
      }

      // Calcola il tempo effettivo trascorso dall'ultimo tasto premuto
      const elapsedSinceKey = Date.now() - (this.lastKeystrokeTime || 0);

      // Se non sono ancora trascorsi i 3,5s base (es. micro-ritardi di scheduling)
      if (elapsedSinceKey < 3400) {
        const remainingBase = Math.max(300, 3500 - elapsedSinceKey);
        this.stallTimer = setTimeout(
          () => this.resetStallTimer(),
          remainingBase,
        );
        return;
      }

      // Tolleranza massima confermata: 1,5 secondi oltre i 3,5s (tetto assoluto di 5000 ms)
      const maxAllowedCeiling = 5000;
      if (
        (this.isSpeaking || isHardwareSpeaking) &&
        elapsedSinceKey < maxAllowedCeiling
      ) {
        const prorogaDelay = Math.min(500, maxAllowedCeiling - elapsedSinceKey);
        this.stallTimer = setTimeout(
          () => this.resetStallTimer(),
          Math.max(200, prorogaDelay),
        );
        return;
      }

      // Se la voce risulta ancora occupata oltre i 1,5s di tolleranza (ghost-lock), forziamo la liberazione dell'audio
      if (this.isSpeaking || isHardwareSpeaking) {
        this.stopAudioOnly();
      }

      // Esecuzione One-Shot dell'Auto-Replay
      this.hasFiredAutoReplay = true;

      let tLen = this.lastTypedLen;
      let mLen = this.lastMatchLen;
      let oText = this.currentText;

      // Verifica dinamica in tempo reale delle metriche effettive prima di notificare
      if (this.stateProvider) {
        const live = this.stateProvider();
        if (live) {
          tLen = live.typedLen;
          mLen = live.matchLen;
          oText = live.originText || oText;
          this.lastTypedLen = tLen;
          this.lastMatchLen = mLen;
          this.currentText = oText;
        }
      }

      this.replay(tLen, mLen, oText, true);
    }, 3500);
  }

  clearStallTimer() {
    if (this.stallTimer) {
      clearTimeout(this.stallTimer);
      this.stallTimer = null;
    }
  }

  stopAudioOnly() {
    this._clearWatchdog();
    if (this.synth) {
      this.synth.cancel();
    }
    this._retainedUtterances.clear();
    this.isSpeaking = false;
    this.isSpeakingReplay = false;
    this.isRecoveringFromCorrection = false;
  }

  stop() {
    this.clearStallTimer();
    this.stopAudioOnly();
    this.tokens = [];
    this.currentIndex = 0;
    this.hasPendingError = false;
    this.hasFiredAutoReplay = false;
  }
}
