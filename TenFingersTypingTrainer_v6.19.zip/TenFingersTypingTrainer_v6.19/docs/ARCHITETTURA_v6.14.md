# Architettura — TenFingersTypingTrainer v6.14

## Obiettivo

La release v6.14 perfeziona l'architettura del motore vocale `DictationEngine`, garantendo la totale continuità della voce durante la digitazione: la pressione di tasti corretti non interrompe mai l'audio in corso, che scorre armonico e ininterrotto anche a velocità sostenute, salvaguardando l'emissione completa del troncone post-correzione e assicurando l'attivazione persistente dello spelling guidato al secondo errore consecutivo sulla stessa parola.

---

## Modello Architetturale della Continuità Vocale (Release v6.14)

### 1. Confinamento Rigoroso di `synth.cancel()` (Domanda 4)

Nelle versioni precedenti, ogni chiamata ad anticipo vocale (`speakCurrentToken`) invocava incondizionatamente `synth.cancel()`, troncando le sillabe finali della parola corrente appena l'allievo premeva il primo tasto corretto.
Nella release v6.14, `synth.cancel()` è rigorosamente circoscritto a quattro soli eventi tassativi:
1. **Errore di digitazione** (`notifyError()`): interruzione istantanea dell'audio e pronuncia di segnalazione errore;
2. **Cancellazione Backspace** (`notifyErrorCorrection()`): azzeramento per ricalibrare gli errori rimanenti o rilanciare il troncone;
3. **Replay esplicito o sosta prolungata** (`replay()` / `resetStallTimer()`): riesecuzione dell'audio su richiesta o timeout d'inattività;
4. **Interruzione sessione**: cambio modalità, apertura di modali o arresto dell'esercizio (`stop()`, `stopAudioOnly()`).

In nessun caso la digitazione di caratteri corretti può interrompere la voce.

### 2. Buffer Lookahead a Profondità 1 con Assorbimento del Ritardo (Opzione C - Domanda 1)

Per evitare sia la sovrapposizione caotica delle voci sia l'accumulo di ritardi chilometrici durante la digitazione molto rapida (es. oltre 300 CPM):
* Se la voce sta già parlando (`this.isSpeaking` o `synth.speaking`), il token anticipato calcolato da `updateProgress()` non forza la pronuncia immediata né cancella la precedente, ma viene depositato in `this.pendingLookahead = { forcedVoice, customText, tokenIndex }`.
* Se l'allievo continua a digitare molto velocemente e attraversa ulteriori parole mentre la voce sta ancora terminando la prima, `pendingLookahead` viene semplicemente aggiornato al token più recente, scartando i token intermedi già ampiamente superati e assorbendo il ritardo.
* All'evento naturale di fine parola (`utter.onend`), il buffer `pendingLookahead` viene prelevato e pronunciato immediatamente senza pause artificiali.

### 3. Dettatura Protetta del Troncone Residuo Post-Errore (Domanda 2)

Quando l'allievo cancella un errore con Backspace, `notifyErrorCorrection()` attiva la dicitura della porzione residua come blocco continuo e imposta lo stato `isRecoveringTroncone = true` associato a `recoveringTokenIdx`:
* Fintanto che il cursore si trova all'interno delle lettere del troncone (`matchLen < curToken.endIndex`), la digitazione dei tasti corretti non scatena anticipi né interferisce con la sintesi vocale in corso.
* L'anticipo della parola successiva scatta unicamente nel momento in cui l'allievo raggiunge o supera l'ultima lettera del troncone, garantendo che la parola residua sia ascoltata per intero.

### 4. Spelling Guidato Persistente al 2° Errore sulla Stessa Parola (Domanda 3)

Se l'allievo commette due o più errori sulla medesima parola (`tokenErrorCount >= 2`), il sistema attiva lo stato persistente `wordSpellingTokenIdx = activeTokenIdx`:
* Alla correzione, il cursore scandisce la prima lettera richiesta a spelling;
* Ad ogni successiva battuta corretta all'interno della parola, `updateProgress()` compita lettera per lettera il carattere successivo (`this._spellOutChar()`);
* Grazie alla coda a profondità 1, ogni lettera (es. "effe", "emme", "maiuscola A") viene pronunciata per intero senza mozzature;
* Al completamento del vocabolo (`matchLen >= curToken.endIndex`), lo stato di spelling si disattiva automaticamente ripristinando la normale dettatura a parole intere.

---

## Mappa dei componenti aggiornata

| Componente | Responsabilità v6.14 |
|---|---|
| `engines/dictation-engine.js` | Gestione buffer lookahead `pendingLookahead` (Opzione C), rimozione `cancel()` su battuta corretta, protezione troncone `isRecoveringTroncone` e spelling persistente di parola `wordSpellingTokenIdx` |
| `app/controller/metodi-input-digitazione.js` | Invio progressivo battute con coordinamento fluido audio/dettatura |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.14 (`window.APP_VERSION = "6.14"`) |
| `profiles/profile-manager.js` | Profilo utente e serializzazione persistente aggiornati ad `AppVersion = "6.14"` |
| `index.html` | Intestazione, badge di versione e commenti allineati a v6.14 |
| `help.html` | Note di rilascio v6.14, documentazione didattica della continuità vocale e indice aggiornati |
| `docs/MANUALE_UTENTE_v6.14.md` | Manuale didattico completo per l'utente allineato alla release v6.14 |
| `tests/test-dictation-adaptive.js` | Test suite estesa con verifica di non-interruzione su battuta corretta e persistenza spelling al 2° errore |
