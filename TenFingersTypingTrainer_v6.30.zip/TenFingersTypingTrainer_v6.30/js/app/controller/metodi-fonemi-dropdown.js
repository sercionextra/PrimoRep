/* TenFingersTypingTrainer v6.0 — AppController: phonemes. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
// Sincronizza l'etichetta del pulsante dropdown con tutte le opzioni selezionate
  updateFonemiDropdownSummary() {
    const btnText = document.getElementById("lblFonemiSelectedText");
    const p = this.profileMgr?.profile;
    if (!btnText || !p || !p.FonemiOptions) return;

    const opt = p.FonemiOptions;
    const selected = [];
    if (opt.customFile) selected.push("Custom File");
    if (opt.maiuscole) selected.push("Maiuscole");
    if (opt.punteggiatura) selected.push("Punteggiatura");
    if (opt.parentesi) selected.push("Parentesi");
    if (opt.numeri) selected.push("Numeri");
    if (opt.matematici) selected.push("Matematici");
    if (opt.simboli) selected.push("Simboli");
    if (opt.layout) selected.push("Layout");

    if (selected.length === 0) {
      btnText.textContent = "Fonemi Base (nessun filtro)";
    } else {
      btnText.textContent = selected.join(", ");
    }
  },

setupFonemiDropdown() {
    const container = document.getElementById("fonemiMultiselectContainer");
    const btn = document.getElementById("btnFonemiDropdown");
    const list = document.getElementById("fonemiCheckboxesList");
    if (!container || !btn || !list) return;

    // Apertura/Chiusura menu a tendina
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isOpen = list.classList.contains("show");
      if (isOpen) {
        list.classList.remove("show");
        container.classList.remove("open");
        this.returnFocusToTyping();
      } else {
        list.classList.add("show");
        container.classList.add("open");
      }
    });

    // Chiusura automatica al click esterno con restituzione focus
    document.addEventListener("click", (e) => {
      if (!container.contains(e.target)) {
        if (list.classList.contains("show")) {
          list.classList.remove("show");
          container.classList.remove("open");
          this.returnFocusToTyping();
        }
      }
    });

    // Mappatura delle 8 checkbox
    const chkMap = {
      chkFonemiCustomFile: "customFile",
      chkFonemiMaiuscole: "maiuscole",
      chkFonemiPunteggiatura: "punteggiatura",
      chkFonemiParentesi: "parentesi",
      chkFonemiNumeri: "numeri",
      chkFonemiMatematici: "matematici",
      chkFonemiSimboli: "simboli",
      chkFonemiLayout: "layout",
    };

    Object.keys(chkMap).forEach((elemId) => {
      const chk = document.getElementById(elemId);
      const propKey = chkMap[elemId];
      if (chk) {
        chk.addEventListener("change", () => {
          const p = this.profileMgr?.profile;
          if (!p) return;
          if (!p.FonemiOptions) p.FonemiOptions = {};

          // Gestione guardia: Custom File senza testo caricato
          if (propKey === "customFile" && chk.checked) {
            const hasCustomText =
              p.FonemiCustomText && p.FonemiCustomText.trim().length >= 20;
            if (!hasCustomText) {
              chk.checked = false;
              p.FonemiOptions.customFile = false;
              this.notifyShortcutDisabled(
                "Nessun file custom per Fonemi. Utilizza 'Editor Custom' per caricarlo.",
              );
              this.updateFonemiDropdownSummary();
              this.profileMgr.saveProfile();
              return;
            }
          }

          p.FonemiOptions[propKey] = chk.checked;
          this.profileMgr.saveProfile();
          this.updateFonemiDropdownSummary();

          // Rigenera immediatamente l'esercizio se in Modalità 2
          if (this.typingEng.mode === 2) {
            this.startExercise(false);
          }
          this.returnFocusToTyping();
        });
      }
    });
  },

  setupFonemiEditorButtons() {
    const btnInput = document.getElementById("btnFonemiInput");
    const btnOutput = document.getElementById("btnFonemiOutput");
    const btnDelete = document.getElementById("btnFonemiDelete");
    const btnConfig = document.getElementById("btnFonemiConfig");
    const fileInput = document.getElementById("fonemiFileInput");

    // 1. INPUT FONEMI CON ROLLBACK TRANSAZIONALE (v.4.7)
    btnInput?.addEventListener("click", () => {
      fileInput?.click();
    });

    fileInput?.addEventListener("change", (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const textVal = ev.target?.result || "";
        if (textVal.trim().length >= 20) {
          if (this.profileMgr?.profile) {
            const prevFonemiText =
              this.profileMgr.profile.FonemiCustomText || "";
            this.profileMgr.profile.FonemiCustomText = textVal;
            const saved = this.profileMgr.saveProfile();

            if (saved) {
              this.showAppAlert(
                `Corpus Fonemi caricato con successo (${textVal.length} caratteri)! Ora puoi attivare la voce "Custom File" nella modalità Fonemi.`,
                "📂 Input Fonemi",
              );
            } else {
              // Rollback: memoria satura, ripristina il corpus precedente
              this.profileMgr.profile.FonemiCustomText = prevFonemiText;
              this.showAppAlert(
                `Impossibile importare il corpus fonemico: spazio di memoria del browser esaurito (Local Storage).\n\nL'operazione è stata annullata (rollback). Libera spazio eliminando profili o campioni prima di importare.`,
                "⚠ Importazione Fallita (Memoria Esaurita)",
              );
            }
          }
        } else {
          this.showAppAlert(
            "Il file selezionato è troppo breve per essere utilizzato come corpus fonemico.",
            "⚠ File Non Valido",
          );
        }
        fileInput.value = "";
      };
      reader.readAsText(file);
    });

    // 2. OUTPUT FONEMI
    btnOutput?.addEventListener("click", () => {
      const p = this.profileMgr?.profile;
      const textVal = p?.FonemiCustomText;
      if (textVal && textVal.trim().length > 0) {
        const blob = new Blob([textVal], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `FonemiCorpus_${p.UserID || "custom"}.txt`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        this.showAppAlert(
          "Attualmente l'unica fonte è quella di default (EMBEDDED_FONEMI_CORPUS)",
          "ℹ Output Fonemi",
        );
      }
      this.returnFocusToTyping();
    });

    // 3. ELIMINA FONTE CUSTOM FONEMI (Release v6.7)
    btnDelete?.addEventListener("click", () => {
      const p = this.profileMgr?.profile;
      const hasCustomText =
        p && p.FonemiCustomText && p.FonemiCustomText.trim().length > 0;

      if (!hasCustomText) {
        this.showAppAlert(
          "Nessuna fonte Custom per i Fonemi presente nel profilo corrente.\nL'applicazione sta già utilizzando la fonte predefinita.",
          "ℹ Elimina Fonte Fonemi",
        );
        this.returnFocusToTyping();
        return;
      }

      this.showAppConfirm(
        "Sei sicuro di voler eliminare la fonte Custom per i Fonemi salvata nel tuo profilo?\n\nQuesta azione ripristinerà l'uso esclusivo della fonte predefinita e disattiverà l'opzione 'Custom File'.",
        "🗑 Elimina Fonte Custom Fonemi",
        () => {
          // A. Azzeramento del corpus custom persistito
          p.FonemiCustomText = "";

          // B. Disattivazione automatica del flag e sincronizzazione dell'interfaccia
          if (p.FonemiOptions) {
            p.FonemiOptions.customFile = false;
          }
          const chkCustom = document.getElementById("chkFonemiCustomFile");
          if (chkCustom) {
            chkCustom.checked = false;
          }

          // C. Persistenza immediata nel profilo
          this.profileMgr.saveProfile();
          this.updateFonemiDropdownSummary();

          // D. Se l'utente è attualmente in Modalità Fonemi (2), rigenera l'esercizio con la fonte default
          if (this.typingEng.mode === 2) {
            this.startExercise(false);
          }

          this.showAppAlert(
            "Fonte Custom per i Fonemi eliminata con successo.\nÈ stata ripristinata la fonte predefinita di sistema.",
            "🗑 Fonte Eliminata",
          );
          this.returnFocusToTyping();
        },
        () => {
          this.returnFocusToTyping();
        },
      );
    });

    // 4. CONFIGURAZIONE FONEMI (v.4.4)
    btnConfig?.addEventListener("click", () => {
      this.openFonemiConfigModal();
    });
  },

openFonemiConfigModal() {
    const modal = document.getElementById("fonemiConfigModal");
    const p = this.profileMgr?.profile;
    if (!modal || !p) return;

    // Caricamento parametro N (v.4.4)
    const txtNgram = document.getElementById("txtFonemiNgram");
    if (txtNgram) {
      txtNgram.value = String(p.FonemiNgramLength || 4);
    }

    // Caricamento parametro Lunghezza Esercizio (v6.11)
    const txtTargetLength = document.getElementById("txtFonemiTargetLength");
    if (txtTargetLength) {
      txtTargetLength.value = String(p.FonemiTargetLength || 100);
    }

    const probs = p.FonemiProbabilities || {};
    const toPct = (val) => Math.round((val !== undefined ? val : 0.3) * 100);

    const txtMaiusc = document.getElementById("txtProbMaiuscole");
    const txtAllMaiusc = document.getElementById("txtProbAllMaiuscole");
    const txtPunt = document.getElementById("txtProbPunteggiatura");
    const txtPar = document.getElementById("txtProbParentesi");
    const txtNum = document.getElementById("txtProbNumeri");
    const txtMat = document.getElementById("txtProbMatematici");
    const txtSim = document.getElementById("txtProbSimboli");
    const txtLay = document.getElementById("txtProbLayout");

    if (txtMaiusc) txtMaiusc.value = toPct(probs.maiuscole);
    if (txtAllMaiusc) txtAllMaiusc.value = toPct(probs.allMaiuscole);
    if (txtPunt) txtPunt.value = toPct(probs.punteggiatura);
    if (txtPar) txtPar.value = toPct(probs.parentesi);
    if (txtNum) txtNum.value = toPct(probs.numeri);
    if (txtMat) txtMat.value = toPct(probs.matematici);
    if (txtSim) txtSim.value = toPct(probs.simboli);
    if (txtLay) txtLay.value = toPct(probs.layout);

    this.windowMgr?.bringModalToFront(modal);
    modal.classList.add("active");
  },

setupFonemiConfigModal() {
    const modal = document.getElementById("fonemiConfigModal");
    const btnConfirm = document.getElementById("btnConfirmFonemiConfig");
    const btnCancel = document.getElementById("btnCancelFonemiConfig");
    const btnClose = document.getElementById("btnCloseFonemiConfigModal");
    const btnResetDef = document.getElementById("btnFonemiConfigResetDefault");

    const closeModal = () => {
      if (modal) modal.classList.remove("active");
      this.returnFocusToTyping();
    };

    btnCancel?.addEventListener("click", closeModal);
    btnClose?.addEventListener("click", closeModal);

    // Chiusura da tastiera con tasto Escape
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal?.classList.contains("active")) {
        closeModal();
      }
    });

    // Ripristino singolo parametro default: 100 caratteri (v6.11)
    const btnTargetLengthDef = document.getElementById("btnFonemiTargetLengthDefault");
    btnTargetLengthDef?.addEventListener("click", () => {
      const txtTargetLength = document.getElementById("txtFonemiTargetLength");
      if (txtTargetLength) txtTargetLength.value = "100";
    });

    // Ripristino valori di default completi: N=4, 100 caratteri e probabilità al 30%
    btnResetDef?.addEventListener("click", () => {
      const txtNgram = document.getElementById("txtFonemiNgram");
      if (txtNgram) txtNgram.value = "4";

      const txtTargetLength = document.getElementById("txtFonemiTargetLength");
      if (txtTargetLength) txtTargetLength.value = "100";

      [
        "txtProbMaiuscole",
        "txtProbAllMaiuscole",
        "txtProbPunteggiatura",
        "txtProbParentesi",
        "txtProbNumeri",
        "txtProbMatematici",
        "txtProbSimboli",
        "txtProbLayout",
      ].forEach((id) => {
        const inp = document.getElementById(id);
        if (inp) inp.value = "30";
      });
    });

    btnConfirm?.addEventListener("click", () => {
      const p = this.profileMgr?.profile;
      if (!p) return;

      // Validazione parametro N tra 2 e 15 (v.4.5)
      const txtNgram = document.getElementById("txtFonemiNgram");
      let nVal = txtNgram ? parseInt(txtNgram.value, 10) : 4;
      if (isNaN(nVal) || nVal < 2) nVal = 2;
      if (nVal > 15) nVal = 15;
      p.FonemiNgramLength = nVal;

      // Validazione parametro Numero Caratteri per Esercizio tra 20 e 500 (v6.11)
      const txtTargetLength = document.getElementById("txtFonemiTargetLength");
      let targetLenVal = txtTargetLength ? parseInt(txtTargetLength.value, 10) : 100;
      if (isNaN(targetLenVal)) targetLenVal = 100;
      if (targetLenVal < 20) targetLenVal = 20;
      if (targetLenVal > 500) targetLenVal = 500;
      p.FonemiTargetLength = targetLenVal;

      const fromPct = (id) => {
        const el = document.getElementById(id);
        const val = el ? parseInt(el.value, 10) : 30;
        return Math.max(0, Math.min(100, isNaN(val) ? 30 : val)) / 100;
      };

      p.FonemiProbabilities = {
        maiuscole: fromPct("txtProbMaiuscole"),
        allMaiuscole: fromPct("txtProbAllMaiuscole"),
        punteggiatura: fromPct("txtProbPunteggiatura"),
        parentesi: fromPct("txtProbParentesi"),
        numeri: fromPct("txtProbNumeri"),
        matematici: fromPct("txtProbMatematici"),
        simboli: fromPct("txtProbSimboli"),
        layout: fromPct("txtProbLayout"),
      };

      this.profileMgr.saveProfile();
      closeModal();

      if (this.typingEng.mode === 2) {
        this.startExercise(false);
      }
    });
  }
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
