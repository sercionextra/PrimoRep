# TenFingersTypingTrainer v6.26

Applicazione web stand-alone per l'allenamento alla digitazione a 10 dita su tastiera italiana QWERTY, dotata di dettatura vocale adattiva e modalità di Interrogazione sul layout della tastiera.

## Novità principali v6.26

- **Ripristino voci TTS di alta qualità con consenso per profilo:** nelle impostazioni della dettatura (`⚙ Config.`) è possibile scegliere se consentire le voci di sintesi vocale online/neurali del browser (attivo per impostazione predefinita) oppure limitarsi alle sole voci locali del dispositivo.
- **Protezione di rete applicativa mantenuta:** CSP restrittiva (`connect-src 'none'`) e `network-isolation-guard.js` continuano a bloccare qualsiasi richiesta di rete diretta dal codice applicativo.
- **Nuova modalità Interrogazione:** accessibile dal pulsante **🎓 Interrogazione** nella barra strumenti, permette di esercitarsi e verificare la conoscenza del layout italiano (riga base, tasti fisici, caratteri, dita e mani) in modalità **Casuale**, **Adattiva** (calendario 1 / 3 / 7 / 14 / 30 / 60 giorni) o **Manuale**, con sospensione e ripresa della sessione.

## Verifiche automatiche

Dalla directory del progetto eseguire:

```bash
for f in tests/*.js; do echo "=== $f ==="; node "$f"; done
```
