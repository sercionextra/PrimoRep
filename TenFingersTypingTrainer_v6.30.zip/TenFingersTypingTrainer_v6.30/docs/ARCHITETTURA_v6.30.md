# Architettura TenFingersTypingTrainer v6.30

## Panoramica delle modifiche rispetto alla v6.29

1. **Storico Interrogazioni (`InterrogationUI`, `InterrogationRepository`, `index.html`, `app.css`):**
   - Aggiunto il pulsante `#btnOpenInterrogationHistory` ("📈 Mostra storico") e la vista `#interrogationView_history`.
   - `InterrogationRepository.deleteSessions(profileId, sessionIds)` consente la rimozione atomica delle sessioni completate sia su IndexedDB che sul backend in-memory.
   - `InterrogationUI._renderHistoryChart()` genera un grafico SVG locale con assi graduati, linea orizzontale tratteggiata rossa (valore in ordinata), linea verticale tratteggiata verde (data-ora del campione più prossimo), selezione multipla dei punti cliccabili e filtro per range data-ora (`Da` / `A`).

2. **Interrogazione per Carattere (`index.html`, `interrogation-svg-renderer.js`, `interrogation-ui.js`, `app.css`):**
   - Rimossi i simboli AltGr errati `{`, `[`, `]`, `}` dai tasti `7`, `8`, `9`, `0` (`key_7..key_0`) nel layout SVG principale.
   - Compattazione verticale della finestra (`max-height: 235px` per tastiera e mani, griglia compatta a 2 colonne per Blocco 1 con Modificatore, Conferma e Consulta a destra dell'Estensione Longitudinale).
   - `InterrogationSvgRenderer.calibrateHitRadii()` e CSS `pointer-events: all !important` su `#interr_landmarks_layer, .interr-landmark-node, .interr-landmark-hit` garantiscono la priorità di click sui puntini rispetto alle sagome delle dita sottostanti.
   - Tutti i dropdown del Blocco 1 sono inizializzati su voce vuota (`""`).
   - `key_enter` accetta `0` e `+1` come Estensione Longitudinale e accetta `+` o `ù` come vicino sinistro (svelando entrambi i tasti sulla tastiera).
   - `_openAsciiPopover(anchorEl, ...)` posiziona la palette ASCII in prossimità dell'elemento cliccato, mantenendola entro i margini della viewport.

3. **Interrogazione per Dito (`interrogation-ui.js`, `interrogation-svg-renderer.js`, `app.css`):**
   - Rimossi i suggerimenti preventivi (nessuna evidenziazione dei tasti del dito all'apertura della domanda) e rimossi i filtri Estensione/Direzione.
   - Il click su un tasto B/N lo colora di giallo (`interr-key-yellow`) e apre la palette ASCII accanto al tasto; il carattere scelto viene scritto direttamente sul tasto (`setKeyUserBadge`).
   - Alla conferma/consultazione viene verificata la corrispondenza completa sia dell'insieme dei tasti che dell'abbinamento tasto-carattere: i tasti corretti diventano verdi (`interr-key-ok`) con i caratteri reali svelati, mentre eventuali tasti fuori posto restano gialli con l'indicazione inserita dall'utente.
