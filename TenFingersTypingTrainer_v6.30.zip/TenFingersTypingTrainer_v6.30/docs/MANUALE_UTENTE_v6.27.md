# Manuale Utente — TenFingersTypingTrainer v6.27

**Versione:** 6.27

## Novità della versione 6.27: Interrogazione Grafica sulla Tastiera

La finestra **Interrogazione** (pulsante **Interrogazione** nella barra superiore) permette di verificare quanto hai memorizzato la posizione dei tasti, delle dita e dei caratteri sulla tastiera italiana QWERTY.

### 1. Configurazione e Scelta delle Domande
Prima di avviare una sessione puoi scegliere:
- **Modalità di selezione:**
  - *Casuale*: estrae le domande a caso.
  - *Adattiva*: dà priorità agli argomenti che hai sbagliato più spesso o che non ripassi da tempo.
  - *Manuale*: ti permette di scegliere tu stesso su cosa esercitarti in 4 modi diversi:
    1. cliccando sui tasti della tastiera in bianco e nero senza simboli;
    2. cliccando sui pallini o sulle dita nell'immagine delle mani;
    3. attivando "Ascolta tastiera fisica" e premendo direttamente il tasto sulla tua tastiera;
    4. scegliendo un carattere dalla griglia ASCII.
- **Tipo Interrogazione:**
  - **Per Carattere:** indaga il singolo carattere su 3 aspetti nella stessa schermata.
  - **Per Tasto:** sceglie a caso uno dei caratteri ottenibili con il tasto scelto e avvia l'interrogazione per carattere.
  - **Per Dito:** chiede di individuare i tasti o i caratteri assegnati a un dito specifico, filtrando per estensione normale (0) o sovraccarico laterale (1, 2, 3 a sinistra o destra). Puoi scegliere se rispondere indicando solo i tasti fisici oppure tutti i singoli caratteri.
  - **Tasti Posizione di Riposo:** chiede di individuare i 4 tasti della mano sinistra (`a, s, d, f`) o della mano destra (`j, k, l, ò`) indicando carattere e dito associato.

### 2. Come rispondere (Per Carattere / Per Tasto)
Nella schermata di esecuzione vedrai affiancate la **tastiera in bianco e nero senza simboli** (che si riempie man mano che rispondi) e l'**immagine delle mani**:
1. **Descrizione Accordo:** scegli Mano, Dito, Estensione laterale (0..3) e Direzione (sn/dx), Estensione longitudinale (-1, 0, +1, +2) e i tasti modificatori (`CTRL`, `SHIFT`, `ALT`, `AltGr`).
2. **Caratteri sul Tasto:** completa gli altri caratteri presenti sullo stesso tasto (`NORMALE`, `SHIFT`, `CTRL + ALT`, `CTRL + ALT + SHIFT`) cliccando sui pulsanti per aprire il selettore ASCII. Se uno slot non ha caratteri, scegli `NONE`.
3. **Tasti intorno (Margherita):** indica i tasti attorno a quello interrogato (coppia sopra, sinistra, destra, coppia sotto) tramite il selettore ASCII. Se il tasto è sul bordo della tastiera e non ha vicini su un lato, seleziona `NONE`.

### 3. Punteggio, Consulta e Statistiche
- **Risposta giusta:** assegna **+3 punti** (badge verde `OK`) e mostra la risposta corretta sulla tastiera e sulle mani (punto verde sul dito).
- **Risposta errata:** assegna **0 punti** (badge rosso `KO`) e mostra comunque la soluzione corretta per aiutarti a memorizzarla.
- **Consulta:** mostra subito la soluzione e l'immagine corrispondente, annulla la domanda per l'apprendimento e assegna **+1 punto**.
- Al termine della sessione, il punteggio totale viene salvato nelle statistiche del tuo profilo.
