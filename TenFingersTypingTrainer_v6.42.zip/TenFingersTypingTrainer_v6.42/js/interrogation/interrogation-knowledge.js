/* TenFingersTypingTrainer v6.25 | interrogation-knowledge.js | Motore puro della conoscenza Interrogazione e calendario adattivo 1/3/7/14/30/60 giorni. */
(function (global) {
  "use strict";

  const HALF_LIFE_DAYS = 60;
  const MS_PER_DAY = 86400000;
  const REVIEW_INTERVALS_DAYS = Object.freeze([1, 3, 7, 14, 30, 60]);
  const CALENDAR_POLICY_VERSION = 1;

  const WEIGHTS = Object.freeze({
    error: 0.4,
    consultation: 0.25,
    delay: 0.2,
    consolidation: 0.15,
  });

  function computeTemporalWeight(ageDays) {
    const safeAge = Math.max(0, Number(ageDays) || 0);
    return Math.pow(0.5, safeAge / HALF_LIFE_DAYS);
  }

  function computeReliability(equivalentExposures) {
    const eq = Math.max(0, Number(equivalentExposures) || 0);
    if (eq === 0) return 0;
    return eq / (eq + 5);
  }

  function computeDelayFactor(overdueDays) {
    if (overdueDays === null || overdueDays === undefined) return null;
    const d = Number(overdueDays);
    if (isNaN(d)) return null;
    return Math.min(100, Math.max(0, (d / 30) * 100));
  }

  function computeEventMetrics(events, calculationAt) {
    const refTime = calculationAt !== undefined ? calculationAt : Date.now();
    let effectiveExposureCount = 0;
    let equivalentExposures = 0;
    let weightedErrors = 0;
    let weightedConsultations = 0;

    for (let i = 0; i < (events || []).length; i++) {
      const ev = events[i];
      if (!ev || ev.superseded) continue;
      if (ev.outcome !== "correct" && ev.outcome !== "incorrect" && ev.outcome !== "consulted") {
        continue;
      }

      const ageDays =
        ev.ageDays !== undefined
          ? Math.max(0, Number(ev.ageDays) || 0)
          : Math.max(0, (refTime - (ev.occurredAt || refTime)) / MS_PER_DAY);
      const w = computeTemporalWeight(ageDays);

      effectiveExposureCount += 1;
      equivalentExposures += w;
      if (ev.outcome === "incorrect") {
        weightedErrors += w;
      } else if (ev.outcome === "consulted") {
        weightedConsultations += 0.5 * w;
      }
    }

    const errorFactor =
      equivalentExposures > 0 ? (weightedErrors / equivalentExposures) * 100 : null;
    const consultationFactor =
      equivalentExposures > 0 ? (weightedConsultations / equivalentExposures) * 100 : null;

    return {
      effectiveExposureCount,
      equivalentExposures,
      reliability: computeReliability(equivalentExposures),
      errorFactor,
      consultationFactor,
    };
  }

  function computeCompositeWeakness(factors) {
    const f = factors || {};
    const entries = [
      { key: "error", val: f.errorFactor, w: WEIGHTS.error },
      { key: "consultation", val: f.consultationFactor, w: WEIGHTS.consultation },
      { key: "delay", val: f.delayFactor, w: WEIGHTS.delay },
      { key: "consolidation", val: f.consolidationFactor, w: WEIGHTS.consolidation },
    ];

    let availableWeight = 0;
    let weightedSum = 0;
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      if (e.val !== null && e.val !== undefined && !isNaN(Number(e.val))) {
        availableWeight += e.w;
        weightedSum += e.w * Number(e.val);
      }
    }

    if (availableWeight <= 0) return null;
    return weightedSum / availableWeight;
  }

  function correctWeaknessTowardNeutral(rawWeaknessIndex, reliability) {
    if (rawWeaknessIndex === null || rawWeaknessIndex === undefined) return null;
    const r = Math.max(0, Math.min(1, Number(reliability) || 0));
    return r * Number(rawWeaknessIndex) + (1 - r) * 50;
  }

  function classifyKnowledge(effectiveExposureCount, correctedWeaknessIndex) {
    if (!effectiveExposureCount || effectiveExposureCount <= 0) {
      return "neverVerified";
    }
    if (effectiveExposureCount < 3 || correctedWeaknessIndex === null || correctedWeaknessIndex === undefined) {
      return "insufficientData";
    }
    if (correctedWeaknessIndex >= 60) return "weak";
    if (correctedWeaknessIndex >= 35) return "review";
    return "consolidated";
  }

  function advanceReviewSchedule(currentLevel, outcome, occurredAt) {
    const level = Math.max(0, Math.min(5, Number.isInteger(currentLevel) ? currentLevel : 0));
    const ts = Number(occurredAt) || Date.now();

    if (outcome !== "correct" && outcome !== "incorrect" && outcome !== "consulted") {
      return {
        reviewLevel: level,
        reviewIntervalDays: REVIEW_INTERVALS_DAYS[level],
        nextReviewAt: null,
        changed: false,
      };
    }

    let nextLevel = level;
    if (outcome === "correct") {
      nextLevel = Math.min(5, level + 1);
    } else if (outcome === "incorrect") {
      nextLevel = 0;
    } else if (outcome === "consulted") {
      nextLevel = Math.max(0, level - 1);
    }

    const intervalDays = REVIEW_INTERVALS_DAYS[nextLevel];
    return {
      reviewLevel: nextLevel,
      reviewIntervalDays: intervalDays,
      nextReviewAt: ts + intervalDays * MS_PER_DAY,
      changed: true,
    };
  }

  function applyCorrectionsToEvents(events, corrections) {
    const corrMap = new Map();
    for (let i = 0; i < (corrections || []).length; i++) {
      const c = corrections[i];
      if (c && c.eventId) {
        corrMap.set(c.eventId, c);
      }
    }

    const effective = [];
    for (let i = 0; i < (events || []).length; i++) {
      const ev = events[i];
      if (!ev) continue;
      const corr = corrMap.get(ev.eventId);
      if (!corr) {
        effective.push(ev);
      } else if (corr.action === "void") {
        continue;
      } else if (corr.action === "replace" && corr.newOutcome) {
        effective.push(Object.assign({}, ev, { outcome: corr.newOutcome }));
      } else {
        effective.push(ev);
      }
    }
    return effective;
  }

  function projectQuestionState(questionSemanticId, events, corrections, calculationAt) {
    const refTime = calculationAt !== undefined ? calculationAt : Date.now();
    const effectiveEvents = applyCorrectionsToEvents(events, corrections)
      .filter((e) => e.questionSemanticId === questionSemanticId)
      .sort((a, b) => (a.occurredAt || 0) - (b.occurredAt || 0));

    let reviewLevel = 0;
    let nextReviewAt = null;
    let reviewIntervalDays = REVIEW_INTERVALS_DAYS[0];
    for (let i = 0; i < effectiveEvents.length; i++) {
      const ev = effectiveEvents[i];
      const sched = advanceReviewSchedule(reviewLevel, ev.outcome, ev.occurredAt || refTime);
      if (sched.changed) {
        reviewLevel = sched.reviewLevel;
        reviewIntervalDays = sched.reviewIntervalDays;
        nextReviewAt = sched.nextReviewAt;
      }
    }

    const metrics = computeEventMetrics(effectiveEvents, refTime);
    let delayFactor = null;
    if (nextReviewAt !== null) {
      const overdueDays = Math.max(0, (refTime - nextReviewAt) / MS_PER_DAY);
      delayFactor = computeDelayFactor(overdueDays);
    }

    const consolidationFactor =
      metrics.effectiveExposureCount > 0
        ? Math.max(0, Math.min(100, ((5 - reviewLevel) / 5) * 100))
        : null;

    const rawWeaknessIndex = computeCompositeWeakness({
      errorFactor: metrics.errorFactor,
      consultationFactor: metrics.consultationFactor,
      delayFactor,
      consolidationFactor,
    });

    const correctedWeaknessIndex = correctWeaknessTowardNeutral(
      rawWeaknessIndex,
      metrics.reliability,
    );

    const classification = classifyKnowledge(
      metrics.effectiveExposureCount,
      correctedWeaknessIndex,
    );

    return {
      questionSemanticId,
      effectiveExposureCount: metrics.effectiveExposureCount,
      equivalentExposures: metrics.equivalentExposures,
      reliability: metrics.reliability,
      errorFactor: metrics.errorFactor,
      consultationFactor: metrics.consultationFactor,
      delayFactor,
      consolidationFactor,
      rawWeaknessIndex,
      correctedWeaknessIndex,
      classification,
      reviewLevel,
      reviewIntervalDays,
      nextReviewAt,
      calendarPolicyVersion: CALENDAR_POLICY_VERSION,
    };
  }

  const URGENCY_WEIGHTS = Object.freeze({
    error: 0.4,
    consultation: 0.25,
    delay: 0.2,
    consolidation: 0.15,
    underinvestigated: 0.25,
  });

  /**
   * Calcola la classifica di urgenza aggregata per Tasti/Caratteri e Dita (v6.40).
   * Ogni entità aggrega i quesiti associati su scala omogenea 0..125 in base ai motivi attivi.
   */
  function computeUrgencyRanking(options) {
    const opts = options || {};
    const candidates = Array.isArray(opts.candidates) ? opts.candidates : [];
    const events = Array.isArray(opts.events) ? opts.events : [];
    const corrections = Array.isArray(opts.corrections) ? opts.corrections : [];
    const catalog = opts.catalog || null;
    const entityFilter = opts.entityFilter || "all";
    const refTime = opts.calculationAt !== undefined ? opts.calculationAt : Date.now();

    const activeReasonsInput = opts.activeReasons || {};
    const isReasonActive = (key) => {
      if (Array.isArray(activeReasonsInput)) {
        return activeReasonsInput.includes(key);
      }
      return activeReasonsInput[key] !== false;
    };

    const activeReasons = {
      error: isReasonActive("error"),
      consultation: isReasonActive("consultation"),
      delay: isReasonActive("delay"),
      consolidation: isReasonActive("consolidation"),
      underinvestigated: isReasonActive("underinvestigated"),
    };

    const groupsMap = new Map();

    const ensureGroup = (groupId, entityType) => {
      let g = groupsMap.get(groupId);
      if (!g) {
        g = {
          entityId: groupId,
          entityType,
          label: "",
          fullLabel: "",
          characters: new Set(),
          candidateIds: [],
          questionTypes: new Set(),
          questionSemanticIds: new Set(),
          fingerId: null,
          keyId: null,
        };
        groupsMap.set(groupId, g);
      }
      return g;
    };

    for (let i = 0; i < candidates.length; i++) {
      const c = candidates[i];
      if (!c) continue;
      const qType = c.questionType;

      if (qType === "CARATTERE" || qType === "TASTO") {
        if (entityFilter === "fingers") continue;
        const keyToken = c.keyId || (c.character ? `char_${c.character}` : c.candidateId);
        const groupId = `key:${keyToken}`;
        const g = ensureGroup(groupId, "key");
        if (!g.keyId && c.keyId) g.keyId = c.keyId;
        if (c.character) g.characters.add(c.character);
        g.candidateIds.push(c.candidateId);
        g.questionTypes.add(qType);
        const qIds = c.questionSemanticIds || [];
        for (let k = 0; k < qIds.length; k++) {
          g.questionSemanticIds.add(qIds[k]);
        }
        if (!g.label) {
          let readable = "";
          if (catalog && typeof catalog.getReadableKeyName === "function" && c.keyId) {
            readable = catalog.getReadableKeyName(`key.${c.keyId}`);
          } else if (c.character) {
            readable = c.character === " " ? "Spazio" : c.character;
          } else if (c.keyId) {
            readable = String(c.keyId).replace(/^key_/, "");
          } else {
            readable = c.candidateId;
          }
          g.label = readable;
          g.fullLabel = readable;
        }
      } else if (qType === "DITO" || qType === "HOME_ROW") {
        if (entityFilter === "keys") continue;
        if (!c.fingerId) continue;
        const fingerToken = String(c.fingerId);
        const groupId = `finger:${fingerToken}`;
        const g = ensureGroup(groupId, "finger");
        g.fingerId = fingerToken;
        g.candidateIds.push(c.candidateId);
        g.questionTypes.add(qType);
        const qIds = c.questionSemanticIds || [];
        for (let k = 0; k < qIds.length; k++) {
          g.questionSemanticIds.add(qIds[k]);
        }
        if (!g.label) {
          const fullName =
            catalog && typeof catalog.getReadableFingerName === "function"
              ? catalog.getReadableFingerName(`finger.${fingerToken}`)
              : `Dito ${fingerToken}`;
          g.label = `D${fingerToken}`;
          g.fullLabel = fullName;
        }
      }
    }

    const effectiveEvents = applyCorrectionsToEvents(events, corrections);
    const eventsByQId = new Map();
    const allEventQIds = [];
    for (let i = 0; i < effectiveEvents.length; i++) {
      const ev = effectiveEvents[i];
      if (!ev || !ev.questionSemanticId) continue;
      let list = eventsByQId.get(ev.questionSemanticId);
      if (!list) {
        list = [];
        eventsByQId.set(ev.questionSemanticId, list);
        allEventQIds.push(ev.questionSemanticId);
      }
      list.push(ev);
    }

    const items = [];
    groupsMap.forEach((g) => {
      const matchedQIdSet = new Set(g.questionSemanticIds);
      const candPrefixes = g.candidateIds.map((cid) => `${cid}.`);
      for (let i = 0; i < allEventQIds.length; i++) {
        const eqId = allEventQIds[i];
        if (matchedQIdSet.has(eqId)) continue;
        for (let p = 0; p < candPrefixes.length; p++) {
          if (eqId.startsWith(candPrefixes[p])) {
            matchedQIdSet.add(eqId);
            break;
          }
        }
      }

      const qIds = Array.from(matchedQIdSet);
      const entityEvents = [];
      for (let i = 0; i < qIds.length; i++) {
        const list = eventsByQId.get(qIds[i]);
        if (list) {
          for (let j = 0; j < list.length; j++) {
            entityEvents.push(list[j]);
          }
        }
      }

      const metrics = computeEventMetrics(entityEvents, refTime);
      let delaySum = 0;
      let delayCount = 0;
      let consolSum = 0;
      let consolCount = 0;

      for (let i = 0; i < qIds.length; i++) {
        const qEvs = eventsByQId.get(qIds[i]);
        if (!qEvs || qEvs.length === 0) continue;
        const st = projectQuestionState(qIds[i], qEvs, [], refTime);
        if (st.effectiveExposureCount > 0) {
          if (st.delayFactor !== null && st.delayFactor !== undefined) {
            delaySum += st.delayFactor;
            delayCount += 1;
          }
          if (st.consolidationFactor !== null && st.consolidationFactor !== undefined) {
            consolSum += st.consolidationFactor;
            consolCount += 1;
          }
        }
      }

      const rawError = metrics.errorFactor !== null ? metrics.errorFactor : 0;
      const rawConsultation = metrics.consultationFactor !== null ? metrics.consultationFactor : 0;
      const rawDelay = delayCount > 0 ? delaySum / delayCount : 0;
      const rawConsolidation = consolCount > 0 ? consolSum / consolCount : 0;
      const rawUnderinvestigated = (1 - metrics.reliability) * 100;

      const contributions = {
        error: activeReasons.error ? Number((rawError * URGENCY_WEIGHTS.error).toFixed(2)) : 0,
        consultation: activeReasons.consultation
          ? Number((rawConsultation * URGENCY_WEIGHTS.consultation).toFixed(2))
          : 0,
        delay: activeReasons.delay ? Number((rawDelay * URGENCY_WEIGHTS.delay).toFixed(2)) : 0,
        consolidation: activeReasons.consolidation
          ? Number((rawConsolidation * URGENCY_WEIGHTS.consolidation).toFixed(2))
          : 0,
        underinvestigated: activeReasons.underinvestigated
          ? Number((rawUnderinvestigated * URGENCY_WEIGHTS.underinvestigated).toFixed(2))
          : 0,
      };

      const totalScore = Number(
        (
          contributions.error +
          contributions.consultation +
          contributions.delay +
          contributions.consolidation +
          contributions.underinvestigated
        ).toFixed(2),
      );

      const charsList = Array.from(g.characters);
      const fullLabel =
        g.entityType === "key" && charsList.length > 0
          ? `${g.fullLabel} (${charsList.map((ch) => (ch === " " ? "Spazio" : ch)).join(", ")})`
          : g.fullLabel;

      items.push({
        entityId: g.entityId,
        entityType: g.entityType,
        label: g.label,
        fullLabel,
        fingerId: g.fingerId,
        keyId: g.keyId,
        candidateIds: g.candidateIds.slice(),
        questionTypes: Array.from(g.questionTypes),
        questionCount: qIds.length,
        effectiveExposureCount: metrics.effectiveExposureCount,
        reliability: Number(metrics.reliability.toFixed(4)),
        contributions,
        totalScore,
      });
    });

    items.sort((a, b) => {
      if (Math.abs(b.totalScore - a.totalScore) > 1e-6) {
        return b.totalScore - a.totalScore;
      }
      if (a.entityType !== b.entityType) {
        return a.entityType === "finger" ? -1 : 1;
      }
      return a.label < b.label ? -1 : a.label > b.label ? 1 : 0;
    });

    return {
      items,
      maxPossibleScore: 125,
      activeReasons,
      entityFilter,
    };
  }

  global.InterrogationKnowledge = Object.freeze({
    HALF_LIFE_DAYS,
    MS_PER_DAY,
    REVIEW_INTERVALS_DAYS,
    CALENDAR_POLICY_VERSION,
    WEIGHTS,
    URGENCY_WEIGHTS,
    computeTemporalWeight,
    computeReliability,
    computeDelayFactor,
    computeEventMetrics,
    computeCompositeWeakness,
    correctWeaknessTowardNeutral,
    classifyKnowledge,
    advanceReviewSchedule,
    applyCorrectionsToEvents,
    projectQuestionState,
    computeUrgencyRanking,
  });
})(typeof window !== "undefined" ? window : globalThis);
