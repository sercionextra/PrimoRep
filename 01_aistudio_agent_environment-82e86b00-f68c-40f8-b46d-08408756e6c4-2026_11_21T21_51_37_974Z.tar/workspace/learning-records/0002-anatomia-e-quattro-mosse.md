# Padronanza di anatomia del cubo e sequenza 4-mosse

Lo studente ha completato la Lezione 1 (concetti di centri fissi, spigoli, angoli, notazione base WCA e pratica delle 6 ripetizioni di `R U R' U'` e `L' U' L U` su Cubzor) ed è pronto per applicare i concetti alla prima fase reale di risoluzione: la Croce Bianca.

- **Evidence**: Conferma esplicita dello studente di aver completato la Lezione 1 ed essere pronto a proseguire.
- **Implications**: La Lezione 2 può dare per acquisita la distinzione tra centri e spigoli e la notazione base (`F`, `U`, `D`, `L`, `R`, `'`, `2`).
