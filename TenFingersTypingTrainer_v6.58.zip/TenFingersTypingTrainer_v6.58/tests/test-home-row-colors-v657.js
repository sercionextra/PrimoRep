#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const appCss = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");

function assert(cond, msg) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exit(1);
  }
}

const darkBlock = appCss.match(/body\.theme-dark\s*\{[\s\S]*?\}/);
const matrixBlock = appCss.match(/body\.theme-matrix\s*\{[\s\S]*?\}/);

assert(darkBlock && darkBlock[0].includes("--base-dot: #fdfdfa;"), "body.theme-dark deve avere --base-dot: #fdfdfa;");
assert(matrixBlock && matrixBlock[0].includes("--base-dot: #fdfdfa;"), "body.theme-matrix deve avere --base-dot: #fdfdfa;");

console.log("PASS: test-home-row-colors-v657 verificato.");
