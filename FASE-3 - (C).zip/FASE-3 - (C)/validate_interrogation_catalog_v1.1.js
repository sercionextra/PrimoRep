#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const workspace = path.resolve(__dirname, "..");
const baseline = path.join(workspace, "TenFingersTypingTrainer_v6.23");
const seed = JSON.parse(fs.readFileSync(path.join(__dirname, "Catalogo_QWERTY_Italiano_seed_v1.0.json"), "utf8"));
const questions = JSON.parse(fs.readFileSync(path.join(__dirname, "Catalogo_Domande_Interrogazione_v1.0.json"), "utf8"));
const candidates = JSON.parse(fs.readFileSync(path.join(workspace, "Candidati_Interrogazione_v1.1.json"), "utf8"));

const sourceFiles = [
  "js/domain/keyboard-map.js",
  "js/domain/finger-names.js",
  "js/domain/anatomical-landmarks.js",
];
const source = sourceFiles.map((file) => fs.readFileSync(path.join(baseline, file), "utf8")).join("\n") +
  "\nglobalThis.__catalogBaseline = { KEY_MAP, FINGER_NAMES, ANATOMICAL_KEY_COORDINATES, KEY_ID_TO_LANDMARK_KEY };";
const sandbox = {};
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: "catalog-baseline-validation.js" });
const runtime = sandbox.__catalogBaseline;
const errors = [];

const runtimeEntries = Object.entries(runtime.KEY_MAP);
const runtimeIds = new Set(runtimeEntries.map(([, entry]) => entry.id));
const seedIds = new Set(seed.physicalKeys.map((entry) => entry.keyId));
if (runtimeEntries.length !== 111) errors.push(`KEY_MAP atteso 111, rilevato ${runtimeEntries.length}`);
if (seed.characterMappings.length !== runtimeEntries.length) errors.push("Numero mapping seed diverso da KEY_MAP");
if (seed.physicalKeys.length !== 52) errors.push(`Tasti seed attesi 52, rilevati ${seed.physicalKeys.length}`);
if (runtimeIds.size !== 52) errors.push(`ID fisici runtime attesi 52, rilevati ${runtimeIds.size}`);

for (const keyId of seedIds) {
  if (!runtimeIds.has(keyId)) errors.push(`Tasto seed assente da KEY_MAP: ${keyId}`);
}
for (const keyId of runtimeIds) {
  if (!seedIds.has(keyId)) errors.push(`Tasto KEY_MAP assente dal seed: ${keyId}`);
}

const seedMappings = new Map(seed.characterMappings.map((entry) => [entry.value, entry]));
for (const [character, mapping] of runtimeEntries) {
  const seedMapping = seedMappings.get(character);
  if (!seedMapping) {
    errors.push(`Mapping carattere mancante nel seed: ${JSON.stringify(character)}`);
    continue;
  }
  const physicalKey = seed.physicalKeys.find((entry) => entry.semanticId === seedMapping.physicalKeySemanticId);
  if (!physicalKey || physicalKey.keyId !== mapping.id) errors.push(`Tasto fisico incoerente per ${JSON.stringify(character)}`);
  if (seedMapping.assignedFinger !== mapping.finger) errors.push(`Dito incoerente per ${JSON.stringify(character)}`);
  if (seedMapping.modifier !== mapping.mod) errors.push(`Modificatore incoerente per ${JSON.stringify(character)}`);
}

const questionMap = new Map(questions.questionDefinitions.map((entry) => [entry.questionSemanticId, entry]));
const templateIds = new Set(questions.mainQuestionTemplates.map((entry) => entry.templateId));
const validElements = new Set([
  ...seed.physicalKeys.map((entry) => entry.semanticId),
  ...seed.characterMappings.map((entry) => entry.semanticId),
  ...seed.fingerDefinitions.map((entry) => `finger.${entry.finger}`),
]);
const candidateIds = new Set();
const referencedQuestionIds = new Set();
const counts = {};

for (const candidate of candidates.candidates) {
  if (candidateIds.has(candidate.candidateId)) errors.push(`candidateId duplicato: ${candidate.candidateId}`);
  candidateIds.add(candidate.candidateId);
  counts[candidate.questionType] = (counts[candidate.questionType] || 0) + 1;
  if (!templateIds.has(candidate.templateId)) errors.push(`Template non risolto: ${candidate.templateId}`);
  if (!candidate.questionSemanticIds.length) errors.push(`Candidate senza sotto-quesiti: ${candidate.candidateId}`);
  for (const questionId of candidate.questionSemanticIds) {
    const definition = questionMap.get(questionId);
    if (!definition) errors.push(`Sotto-quesito non risolto: ${questionId}`);
    else if (definition.questionType !== candidate.questionType) errors.push(`Tipologia incoerente: ${candidate.candidateId}/${questionId}`);
    referencedQuestionIds.add(questionId);
  }
  for (const elementId of candidate.elementSemanticIds) {
    if (!validElements.has(elementId)) errors.push(`Elemento semantico non risolto: ${elementId}`);
  }
}

for (const questionId of questionMap.keys()) {
  if (!referencedQuestionIds.has(questionId)) errors.push(`Definizione attiva non referenziata: ${questionId}`);
}

if (candidateIds.size !== 225) errors.push(`Candidate unici attesi 225, rilevati ${candidateIds.size}`);
if (questionMap.size !== 445) errors.push(`Definizioni attive attese 445, rilevate ${questionMap.size}`);
if (templateIds.size !== 5) errors.push(`Template attesi 5, rilevati ${templateIds.size}`);
if (runtime.ANATOMICAL_KEY_COORDINATES.length !== 60) errors.push("Numero coordinate anatomiche runtime diverso da 60");
if (Object.keys(runtime.FINGER_NAMES).length !== 10) errors.push("Numero dita runtime diverso da 10");
if (seed.svgKeyIds.length !== 62) errors.push("Numero ID SVG del seed diverso da 62");

const expectedCounts = { HOME_ROW: 10, TASTO: 52, CARATTERE: 111, DITO: 52 };
for (const [type, expected] of Object.entries(expectedCounts)) {
  if (counts[type] !== expected) errors.push(`Candidate ${type}: attesi ${expected}, rilevati ${counts[type] || 0}`);
}

if (errors.length) {
  console.error(`CATALOGO NON VALIDO: ${errors.length} errori`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log("PASS: 52 tasti fisici e 111 mapping corrispondono alla baseline.");
console.log("PASS: 445 definizioni attive e 5 template sono coerenti.");
console.log("PASS: 225 candidate univoci e tutti i riferimenti sono risolti.");
console.log("PASS: catalogo parziale, nessuna inferenza o dipendenza esterna.");
