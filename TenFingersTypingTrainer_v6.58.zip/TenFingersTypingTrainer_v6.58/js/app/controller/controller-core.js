/* TenFingersTypingTrainer v6.26 — controller core. I metodi sono caricati dai moduli controller/ successivi. */
// =======================================================
// APP CONTROLLER (Coordinatore Principale e Macchina a Stati)
// =======================================================
class AppController {
  constructor(lessons, demoProfile, customDefault, fonemiCorpus) {
    this.version = "6.58"; // Versione applicativa runtime (Release v6.58)
    window.APP_VERSION = "6.58";
    this.currentZoom = 1.0; // Livello di zoom applicativo (Release v6.9)
    this.backupReminderIntervalMs = 10 * 60 * 1000; // Intervallo minimo configurabile (10 minuti) tra due promemoria Toast di backup (v6.58)
    this._lastBackupReminderAt = 0;
    this.standardLessons = lessons || [];
    this.customLessons = [];
    this.activeLessonsSource = "standard";
    this.lessons = this.standardLessons;
    this.profileMgr = new ProfileManager(demoProfile, customDefault);
    this.audio = new AudioEngine();
    this.phonemeEng = new PhonemeEngine(fonemiCorpus);
    this.dictation = new DictationEngine();
    this.typingEng = new TypingEngine(
      this.lessons,
      this.profileMgr,
      this.audio,
      this.phonemeEng,
    );
    this.visual = new VisualRenderer();
    this.windowMgr = new WindowManager();
    this.statsMgr = new StatisticsManager(this.profileMgr);
    this.prevStatsRect = null;
    this._wrongBadgeTimer = null;

    this.modifierSession = {
      activeModifiers: new Set(),
      expectedModsActive: new Set(),
      shortcutExecuted: false,
      abandonErrorReported: false,
    };
  }
}
