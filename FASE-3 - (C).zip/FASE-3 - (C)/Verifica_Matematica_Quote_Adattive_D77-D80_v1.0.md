# Verifica matematica delle quote adattive D77–D80 v1.0

## 1. Scopo e perimetro

Questo documento verifica la coerenza matematica della formalizzazione contenuta nella **SPECIFICA TECNICA INTERROGAZIONE v1.0**, sezione 10.3, senza modificare le decisioni funzionali consolidate e senza intervenire sui sorgenti.

La verifica riguarda esclusivamente:

- quote configurate e normalizzazione sulle categorie disponibili;
- deficit di affidabilità;
- supplemento adattivo e tetto individuale;
- budget globale di 20 punti percentuali;
- prelievo proporzionale dalle quote base;
- quota neutra;
- conservazione del 100% e determinismo.

La specifica distingue correttamente il tetto individuale del 20% della quota base dal budget globale di 20 punti percentuali. Il problema rilevato non è la distinzione concettuale, ma la relazione numerica tra i due valori.

## 2. Regole attualmente formalizzate

Per ogni categoria disponibile `i`:

- `q_i`: quota configurata originaria;
- `b_i`: quota base normalizzata sulle sole categorie disponibili;
- `r_i`: affidabilità categoria, compresa tra 0 e 1;
- `d_i = 1 - r_i`: deficit di affidabilità;
- `c_i = 0,20 × b_i`: tetto del supplemento individuale.

La normalizzazione impone:

`somma(b_i) = 1`.

La specifica fissa inoltre:

- budget globale `B = 0,20`;
- distribuzione proporzionale ai deficit `d_i`;
- redistribuzione iterativa delle eccedenze;
- quota neutra se il budget non può essere assegnato perché le categorie eleggibili hanno raggiunto il tetto;
- prelievo del budget dalle quote base in proporzione a `b_i`;
- ripartizione equa della quota neutra tra tutte le categorie disponibili.

## 3. Verifica dell'invariante dei tetti

Poiché le quote base normalizzate sommano a 1:

`somma(c_i) = somma(0,20 × b_i) = 0,20`.

Quindi, quando tutte le categorie disponibili partecipano al riparto e hanno un deficit strettamente positivo, la capacità complessiva dei tetti individuali è esattamente uguale al budget globale:

`somma(c_i) = B = 0,20`.

Con un algoritmo di redistribuzione iterativa che continua fino a esaurire il budget o la capacità residua, il risultato necessario è che **tutte le categorie raggiungano il proprio tetto**. Il peso relativo dei deficit determina soltanto l'ordine e il percorso delle iterazioni, non il risultato finale.

Di conseguenza:

- ogni categoria riceve `s_i = c_i = 0,20 × b_i`;
- la somma dei supplementi è 20 punti percentuali;
- non resta quota neutra;
- il prelievo proporzionale dalle quote base è anch'esso `0,20 × b_i`;
- supplemento e prelievo si annullano categoria per categoria;
- la quota finale coincide con la quota base iniziale.

**Conclusione:** se tutti i deficit sono positivi, l'algoritmo formalizzato restituisce sempre le quote configurate normalizzate, indipendentemente dai valori di affidabilità. L'adattività tra categorie non produce alcun effetto.

## 4. Casi numerici di verifica

### Caso A — Quattro categorie disponibili, deficit tutti positivi

Quote base: 25%, 25%, 25%, 25%.

Deficit: 100%, 75%, 50%, 25%.

Tetto individuale: 5 punti percentuali per categoria.

Budget globale: 20 punti percentuali.

| Categoria | Deficit | Tetto | Supplemento finale | Prelievo base | Quota finale |
|---|---:|---:|---:|---:|---:|
| A | 100% | 5 pp | 5 pp | 5 pp | 25% |
| B | 75% | 5 pp | 5 pp | 5 pp | 25% |
| C | 50% | 5 pp | 5 pp | 5 pp | 25% |
| D | 25% | 5 pp | 5 pp | 5 pp | 25% |
| **Totale** | | **20 pp** | **20 pp** | **20 pp** | **100%** |

Il risultato è identico anche con deficit 1%, 2%, 3% e 4%: purché siano tutti positivi, la redistribuzione completa porta ogni categoria al tetto.

### Caso B — Una sola categoria con deficit positivo

Quote base: 25%, 25%, 25%, 25%.

Deficit: 100%, 0%, 0%, 0%.

La sola categoria eleggibile per il supplemento può ricevere al massimo 5 punti percentuali. Restano 15 punti percentuali del budget.

Se il residuo viene convertito in quota neutra e ripartito equamente, il risultato è:

| Categoria | Prelievo base | Supplemento | Quota neutra | Quota finale |
|---|---:|---:|---:|---:|
| A | -5 pp | +5 pp | +3,75 pp | 28,75% |
| B | -5 pp | 0 pp | +3,75 pp | 23,75% |
| C | -5 pp | 0 pp | +3,75 pp | 23,75% |
| D | -5 pp | 0 pp | +3,75 pp | 23,75% |
| **Totale** | **-20 pp** | **+5 pp** | **+15 pp** | **100%** |

Questo caso conserva il totale, ma evidenzia un comportamento discontinuo: la categoria A riceve il tetto massimo anche se il suo deficit è appena maggiore di zero; le categorie con deficit zero non partecipano al supplemento, ma ricevono la quota neutra.

### Caso C — Quote configurate non uniformi, deficit tutti positivi

Quote base normalizzate: 10%, 20%, 30%, 40%.

Tetti individuali: 2, 4, 6 e 8 punti percentuali.

La somma dei tetti è 20 punti percentuali. Se tutti i deficit sono positivi, tutti i tetti vengono raggiunti e il prelievo proporzionale li annulla. Le quote finali restano 10%, 20%, 30%, 40%.

Il difetto non dipende quindi dalle quote uniformi.

### Caso D — Tutti i deficit nulli

Se nessuna categoria ha deficit positivo, la distribuzione proporzionale ai deficit non ha un denominatore positivo e non può assegnare il budget.

Se si interpreta il budget residuo come quota neutra, si trasferiscono comunque 20 punti percentuali dalle quote base normalizzate e li si ridistribuisce in parti uguali. Con quote base 10%, 20%, 30%, 40%, le quote finali diventerebbero 17%, 25%, 33%, 25%? No: il calcolo corretto è 0,8 × quota base + 5 punti percentuali per categoria, quindi 13%, 21%, 29%, 37%.

Questo cambiamento delle quote in assenza di deficit non è giustificato da una necessità adattiva e richiede una regola esplicita.

## 5. Altri punti da precisare

### 5.1 Categorie con deficit nullo

La specifica non definisce in modo univoco se una categoria con `d_i = 0`:

- sia esclusa dai destinatari del supplemento ma inclusa nella quota neutra;
- sia considerata una categoria che non ha ancora raggiunto il tetto;
- oppure determini l'assenza di supplemento e quindi l'assenza di prelievo.

Le tre interpretazioni producono risultati differenti.

### 5.2 Budget residuo e quota neutra

La condizione «se tutte le categorie disponibili hanno raggiunto il tetto» non copre il caso in cui alcune categorie abbiano deficit nullo e quindi peso di riparto nullo. Occorre definire se il riferimento sia a tutte le categorie disponibili o soltanto alle categorie eleggibili al supplemento.

### 5.3 Precisione numerica

L'aritmetica decimale controllata e il metodo dei maggiori resti sono appropriati per convertire le quote in conteggi interi. Non risolvono però l'indeterminatezza dell'algoritmo percentuale: l'arrotondamento deve essere applicato solo dopo aver definito senza ambiguità le quote reali.

## 6. Esito della verifica

| Requisito | Esito |
|---|---|
| Conservazione del 100%, se prelievo e riparti sono definiti come descritti | Soddisfacibile |
| Tetto individuale del 20% della quota base | Soddisfacibile |
| Determinismo | Soddisfacibile con ordinamenti e precisione fissati |
| Supplemento realmente proporzionale ai deficit | **Non soddisfatto nel caso generale** |
| Budget globale di 20 pp e tetto individuale di 20% contemporaneamente significativi | **Non soddisfatto: le capacità aggregate coincidono** |
| Quota neutra con deficit nulli | **Regola incompleta** |
| Quote finali adattive quando tutti i deficit sono positivi | **Non soddisfatto: coincidono con le quote base** |

Non è quindi corretto dichiarare l'algoritmo D77–D80 pronto per l'implementazione sulla sola base della formalizzazione attuale.

## 7. Alternative di correzione

Le seguenti alternative sono proposte tecniche, non decisioni già approvate.

### Alternativa A — Budget massimo variabile, supplemento proporzionale al deficit

- Il 20% globale diventa un limite massimo teorico, non un budget da spendere obbligatoriamente.
- Il supplemento individuale è proporzionale al deficit e non supera il 20% della quota base.
- Il totale effettivamente trasferito dipende dai deficit rilevati.
- Il prelievo dalle quote base è pari alla somma effettivamente assegnata ed è proporzionale alle quote base.
- Il budget non utilizzato non viene convertito automaticamente in quota neutra.

Una possibile formula diretta è `s_i = 0,20 × b_i × d_i`. Essa conserva il tetto e rende il supplemento crescente con il deficit. Tuttavia elimina la redistribuzione iterativa e la quota neutra come descritte nella specifica; pertanto non può essere adottata senza approvare questa modifica funzionale.

### Alternativa B — Budget globale fisso inferiore alla capacità aggregata

- Si conserva il budget globale fisso e la redistribuzione iterativa.
- Si conserva il tetto individuale del 20% della quota base.
- Il budget globale viene fissato a un valore inferiore a 20 punti percentuali, così che la distribuzione proporzionale ai deficit possa influenzare il risultato anche quando tutte le categorie hanno deficit positivo.
- Il residuo diventa quota neutra soltanto quando le categorie eleggibili hanno esaurito la capacità complessiva disponibile.

Questa alternativa preserva più direttamente il meccanismo di redistribuzione, ma richiede di scegliere un nuovo budget globale: la specifica non fornisce un valore alternativo giustificato.

### Alternativa C — Mantenere integralmente la formalizzazione attuale

È possibile mantenere i 20 punti percentuali e i tetti individuali, ma occorre accettare che, quando tutte le categorie hanno deficit positivo, il supplemento non modifichi le quote finali. Questa scelta rende sostanzialmente inutile la proporzionalità ai deficit in quel caso e non è coerente con l'obiettivo dichiarato di adattare le quote alla diversa affidabilità.

## 8. Raccomandazione tecnica

Raccomando di non implementare la formalizzazione attuale senza una correzione.

Tra le alternative, **B è quella che conserva meglio la struttura funzionale già descritta**: riparto proporzionale ai deficit, tetto per categoria, redistribuzione iterativa e quota neutra. Il valore del budget globale deve però essere deciso esplicitamente; non va inventato dal codice.

L'alternativa A è matematicamente più semplice e non introduce un nuovo parametro, ma cambia due comportamenti già riportati nella specifica: redistribuzione iterativa e quota neutra.

## 9. Test di accettazione da aggiungere

1. Quattro categorie con quote 25% e deficit tutti positivi ma differenti: le quote finali devono riflettere le differenze di deficit, se l'adattività è effettivamente richiesta.
2. Deficit tutti nulli: nessun trasferimento deve avvenire senza una regola esplicita che lo giustifichi.
3. Una sola categoria con deficit positivo: verificare tetto, residuo e trattamento delle categorie a deficit nullo.
4. Quote base non uniformi: verificare che il risultato non dipenda da un caso di quote uguali.
5. Categoria indisponibile: normalizzare prima le quote disponibili e ricalcolare i tetti sulla base normalizzata, se questa resta la regola approvata.
6. Somma delle quote finali pari esattamente al 100% prima dell'arrotondamento dei conteggi.
7. Nessuna categoria oltre il proprio tetto di supplemento adattivo.
8. Ripetizione degli stessi input: risultato identico, inclusi spareggi e arrotondamenti.
9. Verificare separatamente supplemento, prelievo e quota neutra: non devono essere sommati o compensati due volte.

## 10. Stato e decisione necessaria

- Verifica matematica: completata.
- Modifica della specifica v1.0: non eseguita.
- Modifica dei sorgenti: non eseguita.
- Algoritmo pronto per implementazione: no, finché non viene scelta una delle alternative.

**Decisione richiesta:** preferire l'Alternativa A (budget massimo variabile, senza redistribuzione/neutralità automatica) oppure l'Alternativa B (redistribuzione e quota neutra mantenute, con budget globale fisso inferiore a 20 punti percentuali)?
