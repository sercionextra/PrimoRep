# 01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.11)

## 1. Visione Generale, Mission e Obiettivi del Progetto

Il progetto **Ten Fingers Typing Trainer (Web Edition SPA)** costituisce il porting moderno, fedele ed esteso del software desktop originario per Windows Forms sviluppato in C#/VB.NET (`Tastiera10Dita.exe`), preservandone l'intero patrimonio didattico e potenziandone l'ergonomia, la fedeltà visiva e le prestazioni analitiche.

### 1.1 Mission Didattica ed Ergonomica
L'obiettivo pedagogico inderogabile dell'applicazione è guidare l'utente nell'acquisizione dell'abilità di **digitazione cieca a dieci dita (touch-typing)** su tastiera italiana standard a 105 tasti (layout **QWERTY IT**), eliminando totalmente la necessità di abbassare lo sguardo sulla tastiera fisica durante la scrittura.

La strategia educativa multi-sensoriale è composta da:
1. **Guida Visiva Ergonomica A Schermo**: visualizzazione coordinata di una tastiera virtuale con codifica cromatica unificata per dito e di una finestra fluttuante ausiliaria con le due mani in grafica vettoriale continua SVG.
2. **Keycaps 3D Ingranditi 1.5x sui Polpastrelli**: sui polpastrelli delle dita virtuali compaiono direttamente i tasti bersaglio e premuti (dimensioni 87x78 px, font a 48 px ultra-bold, bordo 4.8 px e alone volumetrico da 16 px, con estensione fino a 174 px per modificatori estesi).
3. **Motore Didattico dell'Errore a Riscontro Immediato**:
   - Inibizione dell'avanzamento errato in modalità guidata.
   - Espansione cromatica rossa sul testo guida (`char-error-target`) proporzionale al numero di errori consecutivi commessi.
   - Generazione dinamica di spazi rossi fittizi (`␣`) per scongiurare sforamenti di rendering.
   - **Badge Fluttuante della Lettera Errata (`#wrongCharFloatingBadge`)**: equivalente fedele della finestra `FormShowWrongLetter` del software WinForms C#, compare per 550 ms esattamente sopra il carattere target errato indicando il glifo errato digitato.
4. **Metronomo e Sintetizzatore Audio Polifonico**: simulazione sonora in tempo reale tramite Web Audio API a campionamento nullo (macchina da scrivere meccanica Underwood con doppio impulso rumore/risonanza, allarme beep d'errore a 440 Hz e campana metallica di fine esercizio a 2000 Hz).
5. **Monitoraggio Analitico Continuo e Persistente**: registrazione rigorosa delle metriche prestazionali (Battute al Minuto lorde e nette, tempo reale, frequenza d'uso ed errori per ciascuno dei 106 caratteri della tastiera, archivio cronologico dei campioni di velocità).

### 1.2 Vincoli Architetturali e di Porting
- **Zero Dipendenze Esterne a Runtime**: architettura Single Page Application (SPA) pura in TypeScript/Vanilla JavaScript, CSS3 e SVG inline. Nessun package manager o runtime server bloccante nel browser.
- **Portabilità Assoluta**: esecuzione garantita con doppio clic su `index.html` in qualsiasi browser conforme W3C.
- **Persistenza e Retrocompatibilità**: memorizzazione locale in `localStorage` (`typingTrainer_users_v1`) affiancata da import/export bidirezionale in JSON e in XML compatibile al 100% con lo schema C# originario (`DataSetArchivio.xsd`).

---

## 2. Cronologia e Decisioni Architetturali Consolidate (v.1.0 - v.2.7)

Tutte le determinazioni assunte nel corso dell'evoluzione della codebase sono pienamente operative e collaudate:

1. **Disaccoppiamento ad Oggetti Enterprise (v.1.0 - v.1.3)**:
   - Separazione rigorosa nelle 8 classi a responsabilità unica: `TypingEngine`, `VisualRenderer`, `StatisticsManager`, `ProfileManager`, `PhonemeEngine`, `AudioEngine`, `WindowManager`, `AppController`.
   - Sistema di finestre fluttuanti (Mani, Tastiera, Statistiche, Help, Editor) dotate di trascinamento, ridimensionamento elastico, gestione del livello z-index e salvataggio coordinate nel profilo.
2. **Corpora Didattici e 6 Modalità Operative (v.1.0 - v.1.3)**:
   - Integrazione completa delle **70 lezioni native** (`EMBEDDED_LESSONS`).
   - Implementazione delle 6 modalità canoniche: `PHRASES` (ALT+P), `RANDOM` (ALT+R), `FONEMI` (ALT+F), `ALL CHARS` (ALT+C / F12), `TYPING` (ALT+T), `RANDOM THIS PHRASE` (ALT+I / F11).
   - Generatore fonetico N-gram basato su catena sillabica italiana (`EMBEDDED_FONEMI_CORPUS`).
3. **Disabilitazione dell'Auto-Repeat da Tastiera (v.1.4)**:
   - Blocco sistematico del flag `e.repeat` in `keydown` per impedire l'accumulo passivo di battute mantenendo premuto un tasto.
4. **Modello Anatomico Vettoriale Continuo SVG per le Mani (v.1.5 - v.1.10)**:
   - Sostituzione integrale degli sprite GIF bitmap 407x172 px con una silhouette bimanuale continua ad alta definizione in formato vettoriale SVG inline (viewBox 1408x768).
   - Definizione semantica dei 10 polpastrelli (`data-finger="1"` .. `"10"`) con baricentri geometrici invarianti `(data-cx, data-cy)`.
5. **Keycaps 3D sui Polpastrelli ed Ergonomia Visiva (v.2.0)**:
   - Elementi rettangolari arrotondati proiettati direttamente sui polpastrelli con colorazione coordinata per dito e filtro d'ombra `drop-shadow`.
6. **Motore Didattico di Errore ad Espansione Cromatica (v.2.0)**:
   - Evidenziazione rossa estesa proporzionale al numero di battute errate (`numErrors`) e iniezione di spazi rossi fittizi `␣` per sforamenti oltre la frase.
7. **Reset Totale con Backspace a Inizio Frase e Arresto Timer (v.2.0)**:
   - Quando `typedText.length === 0`, il motore arresta il cronometro (`timerRunning = false`, `startTime = null`) e ripristina la frase iniziale senza degradare la velocità media WPM/BTM.
8. **Grafici Cartesiani Fullscreen con Crosshair Quota Y (v.2.0)**:
   - Finestra statistiche responsive a tutto schermo con `ResizeObserver`.
   - Crosshair orizzontale mobile con linea rossa e badge quota Y dinamico.
   - Formattazione standardizzata percentuale d'errore a un decimale: `NN.N%`.
9. **Risoluzione Selezione a 3 Click nel Grafico Statistiche (v.2.1)**:
   - 1° Click: selezione intervallo campioni con calcolo media segmento in `lblMediaValori`.
   - 2° Click: selezione puntuale del singolo campione con dettagli analitici in `txtEsercizio`.
   - 3° Click: ripristino immediato della media globale con azzeramento `selectionState = 0`.
10. **Navigazione Diretta Frasi tramite UI e Modale (v.2.2)**:
    - Pulsante dedicato `📖 Vai a Frase...` (`#btnSelectPhraseModal`) nella Toolbar 2.
    - Badge `lblPhraseRange` interattivo e cliccabile con feedback hover.
    - Selettore a discesa delle lezioni (`selSelectPhraseLesson`) nella modale con sincronizzazione automatica bidirezionale rispetto a `cboLessons`.
11. **Persistenza Continua degli Accordi Fisici su Polpastrelli (v.2.3)**:
    - Eliminazione del timer di spegnimento a 180 ms.
    - Macchina a stati hardware `activePhysicalKeys`: i modificatori e i tasti premuti persistono illuminati sui polpastrelli finché il singolo tasto fisico non viene rilasciato (`keyup`), garantendo riscontro fedele su accordi prolungati.
12. **Ingrandimento Keycaps Polpastrelli a 1.5x (v.2.4)**:
    - Dimensioni base elevate a **87x78 px**, font a **48 px** ultra-bold (peso 900) con contorno protettivo scuro da **6 px** (`paint-order: stroke fill`).
    - Bordo colorato elevato a **4.8 px** e raggio di alone volumetrico a **16 px**.
    - Espansione dinamica automatica fino a **174 px** per `SPAZIO` e modificatori ampi.
13. **Revisione Integrale Documentale e Allineamento Speculare (v.2.5 - v.2.6)**:
    - Creazione della cartella centralizzata `/workspace/NEW_DOCS`.
    - Censimento e formalizzazione rigorosa di tutti i metodi, costanti, tabelle di mapping (126 voci di `KEY_MAP`) e controlli UI, inclusa la presenza del badge flottante `wrongCharFloatingBadge`.
14. **Risoluzione Bug e Perfezionamenti Ergonomici Release v.2.11 (v.2.11)**:
    - **Vincolo di completamento esercizio**: la sessione termina con successo solo se tutti i caratteri corrispondono esattamente alla frase (`numErrors === 0` e `typedText === originText`). Se sono presenti errori residui, l'esercizio non termina all'ultimo carattere ma richiede la correzione a ritroso con Backspace.
    - **Reset e pulizia sincrona Mani a fine esercizio**: spegnimento istantaneo di tutti i keycaps e ripristino delle silhouette a riposo con `clearAllPhysicalFingers()` e `setTargetChar(null)` allo scoccare del completamento.
    - **Invarianza metrica del font nel Testo Guida**: normalizzazione di `.char-error-target` con `display: inline; padding: 0; letter-spacing: normal; font-weight: 700;` per eliminare qualsiasi spostamento o scatto orizzontale dei caratteri quando colorati in rosso.
    - **Finestra Mani Resizable**: integrazione delle 8 maniglie perimetrali `.resize-handle` e ridimensionamento elastico con salvataggio delle preferenze (`HandsWidth`, `HandsHeight`, `HandsTop`, `HandsLeft`) nel profilo utente; ritaglio intelligente dello spazio vuoto esterno senza scalare il disegno anatomico e traslazione verso l'alto delle scritte 'MANO SINISTRA' e 'MANO DESTRA' in caso di forte compressione verticale.
    - **Visualizzazione fedele di tutti i modificatori fisici**: mappatura dei tasti fisici reali direttamente sui rispettivi polpastrelli in `activePhysicalKeys` senza forzature teoriche di accordo, permettendo la visualizzazione contemporanea di qualsiasi combinazione di modificatori premuti (Shift, Ctrl, Alt, AltGr).
    - **Riconoscimento e gestione dedicata di AltGr**: soppressione istantanea dell'impulso fittizio di `ControlLeft` generato dai browser su sistema operativo Windows alla pressione di AltGr, illuminando unicamente il tasto AltGr virtuale e il relativo polpastrello (Dito 6).
    - **Finestra Statistiche ad assetto cartesiano invariante**: slot dedicato con `visibility: hidden` per i pulsanti di eliminazione selezione campioni (`#btnClearSelection` e `#btnClearNotSelected`), scongiurando reflow e spostamenti del grafico cartesiano.
    - **Affiancamento layout di default**: quando Tastiera e Mani sono entrambe visibili, la tastiera si allinea a sinistra e la finestra Mani si colloca di default subito alla sua destra; integrazione del pulsante `↺ Default` (`#btnHandsDefaultPos`) sulla barra della finestra Mani per il ripristino immediato.
    - **Correzione modalità TYPING (Libera)**: isolamento di `updateTargetKey` per impedire la cancellazione immediata dei keycaps fisici ad ogni battuta, garantendo l'illuminazione fluida e reattiva di ogni singolo tasto digitato.
    - **Allineamento speculare delle scorciatoie**: armonizzazione nel menu a discesa delle Modalità (`#cboMode`), nella guida HTML (`help_(v.2.11).html`) e nel Manuale Utente con le reali combinazioni `CTRL+SHIFT+...`.

---

## 3. Architettura Logica e Modulare del Software

L'applicazione è strutturata su 8 moduli a classi indipendenti con ciclo di vita orchestrato da `AppController`:

```text
+-----------------------------------------------------------------------------------------+
|                                    AppController                                        |
|  - Inizializzazione applicazione, caricamento profilo attivo e tema                     |
|  - Gestione globale eventi da tastiera (keydown/keyup) e hotkeys F1-F12 / ALT+          |
|  - Coordinamento tra TypingEngine, VisualRenderer, AudioEngine e WindowManager          |
|  - Pilotaggio modali: Seleziona Frase, Editor Custom, Gestione Utenti, Guida            |
|  - Gestione del badge d'errore galleggiante (#wrongCharFloatingBadge)                   |
+---+-------------------+-------------------+-------------------+-------------------+-----+
    |                   |                   |                   |                   |
    v                   v                   v                   v                   v
+---------------+ +---------------+ +---------------+ +---------------+ +---------------+
| TypingEngine  | |VisualRenderer | |StatisticsMgr  | | ProfileManager| |  AudioEngine  |
| - 70 lezioni  | | - Canvas SVG  | | - Istogramma  | | - Gestione    | | - Web Audio   |
| - Timer ms    | | - Keycaps 3D  | |   6 ordinamenti| |   profili     | | - Click tasto |
| - BTM lorde/  | | - Blinking    | | - Grafico     | | - localStorage| | - Beep errore |
|   nette       | | - Modificatori| |   cartesiano  | | - Export/Imp  | | - Campana fine|
| - Reset Bksp  | | - Accordi HW  | | - Crosshair Y | |   JSON / XML  | | - Volume      |
+---------------+ +---------------+ +---------------+ +---------------+ +---------------+
        |                                                                   ^
        v                                                                   |
+---------------+                                                   +---------------+
| PhonemeEngine |                                                   | WindowManager |
| - Algoritmo   |                                                   | - Drag header |
|   N-gram      |                                                   | - Resize el.  |
| - Corpus IT   |                                                   | - Viewport cl.|
|   100 caratt. |                                                   | - Center btn  |
+---------------+                                                   +---------------+
```

### 3.1 `TypingEngine`
- **Scopo**: motore logico di computazione dattilografica e validazione dell'input.
- **Stato Interno**:
  - `lessons`: array delle 70 lezioni native (o lezioni custom attive).
  - `currentLessonIdx`: indice della lezione in corso (0..69).
  - `currentExerciseIdx`: indice della frase all'interno della lezione.
  - `originText`: stringa proposta da digitare.
  - `typedText`: stringa digitata dall'utente.
  - `mode`: modalità operativa attiva (0: Phrases, 1: Random, 2: Fonemi, 3: All Chars, 4: Typing, 5: Random This Phrase).
  - `startTime`, `lastKeystrokeTime`: timestamp di inizio e ultimo input.
  - `timerRunning`, `isCompleted`: flag di stato del cronometro e di completamento.
  - `countTotalChars`, `countBackChars`, `countErrors`: contatori analitici delle battute.
- **Metodi Principali**:
  - `initSession()`: azzera i contatori della sessione e prepara il testo guida.
  - `startTimerIfNeeded()`: avvia il cronometro al primo carattere digitato valido.
  - `stopTimer()`: ferma il timer alla fine della frase o al reset con Backspace.
  - `resetSessionMetrics()`: azzera i contatori parziali di tempo, battute ed errori.
  - `resetTypingSession()`: ripristina la sessione di scrittura libera (modalità 4).
  - `loadExercise(source, lessonIdx, phraseIdx)`: carica un esercizio specifico gestendo intervalli e rimescolamenti.
  - `handleKeyInput(charKey, isBack)`: valida la pressione del tasto:
    - In modalità `TYPING` (4): aggiorna il testo libero, conta i Backspace come errori e aggiorna il pannello Fixing Data.
    - Nelle modalità guidate (0, 1, 2, 3, 5): gestisce il Backspace (con stop timer se si torna a 0 caratteri) oppure convalida il carattere rispetto al target, registrando l'errore o il successo.
  - `recordCharStat(char, isError)`: aggiorna frequenza ed errori per il codice Unicode del carattere nel profilo (con guard-clause out-of-bounds).
  - `recordCompletedSample()`: registra il record prestazionale in `ElencoVelocita`.
  - `recordManualTypingSample()`: registra il record per la digitazione libera tramite il pulsante `#btnAddStatistic`.
  - `getElapsedMinutes()`: calcola la durata precisa della sessione in frazione di minuti.
  - `updateMetrics()`: calcola in tempo reale e visualizza a schermo:
    - Tempo trascorso: formato naturale `MM:SS`.
    - Battute corrette: `rightChars`.
    - Velocità netta: `netBpm = Math.round(rightChars / minutes)`.
    - Velocità lorda: `grossBpm = Math.round(countTotalChars / minutes)`.
    - Conteggio errori: `errCount`.
    - Percentuale d'errore: `errPerc = ((errCount / rightChars) * 100).toFixed(1)` con simbolo `%`.
    - Aggiornamento dei campi del pannello Fixing (`#txtFixingTime`, `#txtFixingRightEverage`, `#txtFixingTotalEverage`).

### 3.2 `VisualRenderer`
- **Scopo**: gestione della grafica vettoriale SVG e coordinamento visivo tra tastiera e mani.
- **Stato Interno**:
  - `activePhysicalKeys`: mappa degli accordi fisici hardware attualmente trattenuti (`code -> Set(fingers)`).
  - `blinkInterval`: timer per l'alternanza visiva del tasto bersaglio (intervallo circa 300 ms).
  - `targetChar`, `targetChord`: glifo bersaglio corrente e relative dita/modificatori richiesti.
- **Metodi Principali**:
  - `highlightTarget(targetChar)`: identifica il tasto corrispondente in `KEY_MAP`, applica la **Regola dei Modificatori Incrociati** e attiva il lampeggio sincronizzato su tastiera e polpastrello.
  - `setTargetChar(targetChar)`: calcola l'accordo target e proietta il keycap 3D sul polpastrello preposto.
  - `updateCapsLockLed(state)`: aggiorna lo stato visivo acceso/spento del LED del Caps Lock sulla tastiera virtuale.
  - `getKeyIdForEvent(e)`: mappa il codice fisico dell'evento tastiera (`e.code` / `e.key`) con l'identificatore SVG corrispondente.
  - `flashPressedKey(keyId, isError)`: illumina brevemente il tasto virtuale premuto (colore neutro se corretto, rosso se errato).
  - `setPhysicalKeyDown(code, key)`: registra la pressione fisica del tasto e accende i relativi polpastrelli senza timeout arbitrari.
  - `setPhysicalKeyUp(code, key)`: rimuove il tasto rilasciato dall'accordo fisico e spegne solo i polpastrelli non più trattenuti.
  - `renderActivePhysicalChord()`: disegna in tempo reale tutti i keycaps dei tasti attualmente abbassati sulla tastiera fisica, applicando il dimensionamento dinamico esteso fino a 174 px per `SPAZIO` e modificatori.
  - `clearAllPhysicalFingers()`: azzera forzatamente tutti i tasti fisici registrati (invocato su `window.blur` o cambio focus).

### 3.3 `StatisticsManager`
- **Scopo**: calcolo, aggregazione e rendering cartesiano responsive dei dati prestazionali.
- **Stato Interno**:
  - `sortMode`: modalità di ordinamento per l'istogramma (`freqRel`, `freqAss`, `errRel`, `errAss`, `fingerRel`, `fingerAss`).
  - `coordYMode`: metrica dell'asse Y per il grafico temporale (`btm`, `chars`, `errRel`, `errAss`).
  - `selectionState`: macchina a stati del mouse sul grafico (0: nessuna selezione, 1: intervallo selezionato, 2: singolo punto isolato).
  - `selectedIndices`: insieme degli indici dei campioni inclusi nella selezione attiva.
  - `chartFilters`: mappa dei flag di filtro per tipologia di esercizio (7 filtri).
- **Metodi Principali**:
  - `renderHistogram()`: genera l'istogramma vettoriale SVG delle frequenze ed errori sui 106 caratteri tracciati (`p.Caratteri`), ordinati secondo il criterio attivo.
  - `renderSpeedChart()`: genera il grafico cartesiano responsive su `#statsSpeedSvgBox` tramite `ResizeObserver`:
    - Disegno assi cartesiani, griglia graduata e linea di tendenza continua dei campioni di `p.ElencoVelocita`.
    - Tracciamento della linea rossa orizzontale mobile di **crosshair** reattiva a `mousemove` con badge quota Y galleggiante.
    - Gestione della **macchina a stati di selezione cartesiana a 3 click**:
      - 1° click/drag: calcola la media del segmento e la visualizza in `#lblMediaValori`.
      - 2° click: isola il singolo punto e popola i campi informativi dell'esercizio in `#txtEsercizio`.
      - 3° click: azzera la selezione e ripristina la media globale dell'archivio.
  - `clearSelection()`: azzera lo stato di selezione del grafico.
  - Eliminazione campioni selezionati (`#btnClearSelection`) e azzeramento totale (`#btnResetAllStats`).

### 3.4 `ProfileManager`
- **Scopo**: gestione multi-utente, storage locale e interscambio dati compatibile C#.
- **Stato Interno**:
  - `currentUserId`: nome del profilo attivo (default: `"ALBERTO"`).
  - `users`: mappa di tutti i profili registrati in memoria locale.
- **Metodi Principali**:
  - `init()`: carica i profili da `localStorage.getItem("typingTrainer_users_v1")` o inizializza l'archivio predefinito con il profilo ALBERTO precaricato.
  - `getUsers()`, `saveUsers()`: accesso e persistenza della mappa profili su `localStorage`.
  - `loadUser(name)`: carica e attiva il profilo specificato.
  - `createUser(name)`: crea un nuovo utente inizializzando la tabella caratteri (106 voci) e l'array campioni vuoto.
  - `deleteUser(name)`: rimuove un profilo (impedendo la cancellazione se è l'unico utente rimasto).
  - `saveProfile()`: memorizza lo stato corrente della sessione (lezione, modalità, opzioni e geometrie finestre).
  - `clearUserStats(name)`: azzera `Caratteri` ed `ElencoVelocita` per il profilo selezionato.
  - `exportJson()`: serializza l'intero archivio in un file `.json` scaricabile.
  - `exportXml()`: genera un file XML conforme al 100% allo schema originario C# `DataSetArchivio.xsd`.

### 3.5 `PhonemeEngine`
- **Scopo**: generazione probabilistica di testo sillabico per l'allenamento N-gram.
- **Stato Interno**:
  - `corpus`: stringa di testo letterario italiano continuo (`EMBEDDED_FONEMI_CORPUS`).
- **Metodi Principali**:
  - `generate(length = 100)`:
    1. Identifica un punto di inizio parola tramite regex `\b(?<NextChar>[^\s\u00AE.])`.
    2. Mantiene una finestra mobile di prefisso di lunghezza 4 (`LUNGHEZZAFONEMA = 4`).
    3. Cerca nel corpus le successive transizioni consonantiche e vocaliche tramite regex dinamica.
    4. Concatena casualmente una transizione valida fino al raggiungimento di 100 caratteri.

### 3.6 `AudioEngine`
- **Scopo**: sintesi sonora polifonica procedurale in tempo reale tramite Web Audio API.
- **Stato Interno**:
  - `ctx`: istanza di `AudioContext` inizializzata in modalità lazy.
  - `mode`: modalità attiva (`"typewriter"`, `"beep"`, `"mute"`).
  - `volume`: ampiezza master (0.0 .. 1.0).
- **Metodi Principali**:
  - `init()`: sblocca l'AudioContext al primo gesto interattivo dell'utente.
  - `setMode(m)`, `setVolume(v)`: configurano la modalità sonora e il livello di guadagno (`GainNode`).
  - `playKey()`: sintesi a due componenti per simulare la macchina da scrivere meccanica:
    - Componente percussiva: burst di rumore bianco filtrato passa-banda a 1200 Hz (durata 25 ms).
    - Risonanza metallica: oscillatore a onda triangolare a 280 Hz con decadimento esponenziale (durata 40 ms).
  - `playError()`: tono a onda quadra pura a 440 Hz (o 880 Hz) con inviluppo percussivo (durata 80 ms).
  - `playBell()`: risonanza sinusoidale smorzata ad alta frequenza a 2000 Hz (durata 450 ms) simulante il campanello di fine riga.

### 3.7 `WindowManager`
- **Scopo**: gestione dell'interfaccia multi-finestra fluttuante all'interno del viewport del browser.
- **Metodi Principali**:
  - `makeDraggable(element, header)`: implementa il trascinamento fluido calcolando i delta del puntatore mouse ed applicando il **viewport clamping** (la finestra non può uscire dai bordi visibili dello schermo).
  - `makeResizable(element, handle)`: implementa il ridimensionamento bidirezionale con dimensioni minime di sicurezza (`min-width: 320px`, `min-height: 180px`).
  - `initGlobalEvents()`: intercetta `mousedown` su qualsiasi finestra per elevarne istantaneamente lo `z-index` portandola in primo piano.
  - Gestione del pulsante `#btnHandsCenter`: ricentra istantaneamente la finestra delle mani al centro del viewport.

### 3.8 `AppController`
- **Scopo**: coordinatore di sistema, dispatcher degli eventi utente e gestore del flusso applicativo.
- **Metodi Principali (34 metodi)**:
  - `start()`: inizializza tutti i moduli, applica il tema salvato, imposta la sorgente lezioni e avvia la prima frase.
  - `setupShortcuts()`: registra il listener globale `keydown` per tutti i tasti funzione (F1 - F12) e le combinazioni `ALT+`, sopprimendo preventivamente i comportamenti di default del browser (`e.preventDefault()`).
  - `setupTypingListeners()`: aggancia l'input utente su `#txtTypedInput` e invia i tasti a `TypingEngine.handleKeyInput`.
  - `processTypingResult(res)`: interpreta il responso del motore:
    - Se corretto: aggiorna l'evidenziazione, emette il suono del tasto e ricalcola le metriche.
    - Se errato: attiva il flash rosso, emette il beep sonoro e invoca `showWrongLetterPopup`.
    - Se completato: colora l'input in verde chiaro, suona la campana e salva il campione.
  - `showWrongLetterPopup(wrongChar)`: **gestione del badge galleggiante temporizzato `#wrongCharFloatingBadge`**:
    - Calcola la posizione del carattere target (`getBoundingClientRect`).
    - Posiziona il badge esattamente sopra il cursore (`top: spanTop - 34px`, centrato orizzontalmente).
    - Mostra il carattere errato (o la scritta `SPAZIO` se era uno spazio bianco).
    - Rimuove automaticamente il badge dopo **550 ms**.
  - `showSelectPhraseModal()`, `confirmSelectPhrase()`: gestione bidirezionale della modale di salto a frase.
  - `openCustomEditor()`, `setupCustomEditor()`: apertura e salvataggio nell'editor di lezioni custom.
  - `setupStatsUI()`: apertura, ridisegno e gestione filtri della finestra statistiche.

---

## 4. Mappatura Completa dei 126 Tasti della Tastiera (`KEY_MAP`)

La mappatura dei caratteri nel file sorgente (`KEY_MAP`) contiene **126 voci di corrispondenza univoca**, associando a ciascun carattere il relativo identificatore SVG, il dito anatomico (1..10) e il modificatore necessario:

### 4.1 Caratteri Speciali Multiriga e di Controllo
- `®` (Unicode `\u00AE` - Invio / Return): id `key_enter`, Dito 10 (Mignolo destro), modificatore `none`.
- `\n` (A capo reale): id `key_enter`, Dito 10 (Mignolo destro), modificatore `none`.
- `→` (Unicode `\u2192` - Tabulatore): id `key_tab`, Dito 1 (Mignolo sinistro), modificatore `none`.
- `\t` (Tabulazione reale): id `key_tab`, Dito 1 (Mignolo sinistro), modificatore `none`.
- ` ` (Spazio bianco): id `key_space`, Dito 5 o 6 (Pollici), modificatore `none`.

### 4.2 Fila Superiore Numerica (Row 1)
- `\` / `|`: id `key_backslash`, Dito 1, mod `none` / `shiftR`.
- `1` / `!`: id `key_1`, Dito 1, mod `none` / `shiftR`.
- `2` / `"`: id `key_2`, Dito 1, mod `none` / `shiftR`.
- `3` / `£`: id `key_3`, Dito 2, mod `none` / `shiftR`.
- `4` / `$`: id `key_4`, Dito 3, mod `none` / `shiftR`.
- `5` / `%`: id `key_5`, Dito 4, mod `none` / `shiftR`.
- `6` / `&`: id `key_6`, Dito 4, mod `none` / `shiftR`.
- `7` / `/`: id `key_7`, Dito 7, mod `none` / `shiftL`.
- `8` / `(`: id `key_8`, Dito 8, mod `none` / `shiftL`.
- `9` / `)`: id `key_9`, Dito 9, mod `none` / `shiftL`.
- `0` / `=`: id `key_0`, Dito 10, mod `none` / `shiftL`.
- `'` / `?`: id `key_quote`, Dito 10, mod `none` / `shiftL`.
- `ì` / `^`: id `key_igrave`, Dito 10, mod `none` / `shiftL`.

### 4.3 Fila Alta (Row 2 - QWERTY)
- Lettere `q`, `w`, `e`, `r`, `t`: Dita 1, 2, 3, 4 (Mano Sinistra). Maiuscole con `shiftR` (Dito 10).
- Lettere `y`, `u`, `i`, `o`, `p`: Dita 7, 8, 9, 10 (Mano Destra). Maiuscole con `shiftL` (Dito 1).
- `é` / `è`: id `key_egrave`, Dito 10, mod `none` / `shiftL`. Modificatori AltGr: `[` (`altgr` su `key_egrave`), `{` (`shiftL` + `altgr`).
- `+` / `*`: id `key_plus`, Dito 10, mod `none` / `shiftL`. Modificatori AltGr: `]` (`altgr` su `key_plus`), `}` (`shiftL` + `altgr`).

### 4.4 Fila Base (Row 3 - ASDFGHJKLÒ)
- Lettere `a`, `s`, `d`, `f`, `g`: Dita 1, 2, 3, 4 (Mano Sinistra). Maiuscole con `shiftR` (Dito 10).
- Lettere `h`, `j`, `k`, `l`: Dita 7, 8, 9 (Mano Destra). Maiuscole con `shiftL` (Dito 1).
- `ç` / `ò`: id `key_ograve`, Dito 10, mod `shiftL` / `none`. Modificatore AltGr: `@` (`altgr` su `key_ograve`).
- `°` / `à`: id `key_agrave`, Dito 10, mod `shiftL` / `none`. Modificatore AltGr: `#` (`altgr` su `key_agrave`).
- `§` / `ù`: id `key_ugrave`, Dito 10, mod `shiftL` / `none`.

### 4.5 Fila Bassa (Row 4 - ZXCVBNM)
- `<` / `>`: id `key_less`, Dito 1 (Mignolo sinistro), mod `none` / `shiftR`.
- Lettere `z`, `x`, `c`, `v`, `b`: Dita 1, 2, 3, 4 (Mano Sinistra). Maiuscole con `shiftR` (Dito 10).
- Lettere `n`, `m`: Dita 7 (Indice destro). Maiuscole con `shiftL` (Dito 1).
- `,` / `;`: id `key_comma`, Dito 8 (Medio destro), mod `none` / `shiftL`.
- `.` / `:`: id `key_period`, Dito 9 (Anulare destro), mod `none` / `shiftL`.
- `-` / `_`: id `key_minus`, Dito 10 (Mignolo destro), mod `none` / `shiftL`.

---

## 5. Formati Dati di Input e Output

### 5.1 File Esercizi Didattici (`TypingTrainerDefault.txt` e `TypingTrainerCustom.txt`)
Utilizzano la sintassi standard con righe di delimitazione a 5 simboli di uguale:

```text
=====NomeLezione=====
Frase 1 dell'esercizio.
=====
Frase 2 dell'esercizio.
Seconda riga della medesima frase.
=====
```

- **Intestazione di Sezione**: riga delimitata da `=====` sia all'inizio che alla fine (`=====NomeLezione=====`).
- **Separatore di Frase**: riga contenente esattamente `=====`.
- **Gestione Multiriga e Tabulazioni**:
  - I ritorni a capo all'interno di una stessa frase vengono serializzati con il glifo `®` (Unicode `\u00AE`).
  - Le tabulazioni o i rientri di 4 spazi vengono convertiti nel glifo `→` (Unicode `\u2192`).

### 5.2 Corpus Fonemi (`TypingTrainerFonemi.txt`)
Stringa di testo continuo letterario italiano priva di marcatori speciali, interrogata dinamicamente dall'algoritmo Markoviano N-gram di `PhonemeEngine`.

### 5.3 Schema XML di Interscambio C# (`DataSetArchivio.xsd` / `XMLApplicationData.xml`)
Garantisce la compatibilità binaria e strutturale con i salvataggi della versione desktop C#:

```xml
<?xml version="1.0" standalone="yes"?>
<DataSetArchivio xmlns="http://tempuri.org/DataSetArchivio.xsd">
  <Utente>
    <UserID>ALBERTO</UserID>
    <Mode>0</Mode>
    <Lesson>0</Lesson>
    <Exercise>0</Exercise>
    <AutomaticCorrection>false</AutomaticCorrection>
    <ShowKeyBoard>true</ShowKeyBoard>
    <ShowHands>true</ShowHands>
    <ShowOrigin>true</ShowOrigin>
    <ShowTyped>true</ShowTyped>
    <KeyBoardX>50</KeyBoardX>
    <KeyBoardY>100</KeyBoardY>
    <KeyBoardWidth>800</KeyBoardWidth>
    <KeyBoardHeight>250</KeyBoardHeight>
    <HandsX>100</HandsX>
    <HandsY>380</HandsY>
    <HandsWidth>700</HandsWidth>
    <HandsHeight>380</HandsHeight>
  </Utente>
  <Caratteri>
    <UserID>ALBERTO</UserID>
    <CharUnicode>97</CharUnicode>
    <Frequenza>142</Frequenza>
    <Errori>3</Errori>
  </Caratteri>
  <CampioniVelocita>
    <UserID>ALBERTO</UserID>
    <DataOra>2026-10-01T12:00:00</DataOra>
    <BattuteMinuto>185</BattuteMinuto>
    <NumeroErrori>2</NumeroErrori>
    <NumeroCaratteri>68</NumeroCaratteri>
    <TipoSessione>0</TipoSessione>
    <TitoloEsercizio>asdfl</TitoloEsercizio>
  </CampioniVelocita>
</DataSetArchivio>
```

### 5.4 Formato JSON di Storage nel Browser (`localStorage`)
Chiave di persistenza `typingTrainer_users_v1`:

```json
{
  "ALBERTO": {
    "UserID": "ALBERTO",
    "Mode": 0,
    "Lesson": 0,
    "Exercise": 0,
    "AutomaticCorrection": false,
    "ShowKeyBoard": true,
    "ShowHands": true,
    "ShowOrigin": true,
    "ShowTyped": true,
    "CustomLessonsText": "",
    "Caratteri": [
      { "CharUnicode": 97, "Frequenza": 142, "Errori": 3 }
    ],
    "ElencoVelocita": [
      {
        "DataOra": "2026-10-01T12:00:00.000Z",
        "BattuteMinuto": 185,
        "NumeroErrori": 2,
        "NumeroCaratteri": 68,
        "TipoSessione": 0,
        "TitoloEsercizio": "asdfl"
      }
    ],
    "windowLayout": {
      "hands": { "left": 100, "top": 380, "width": 700, "height": 380 },
      "keyboard": { "left": 50, "top": 100, "width": 800, "height": 250 }
    }
  }
}
```

---

## 6. Censimento e Mappatura di Tutti i Componenti dell'Interfaccia Utente

L'applicazione include 209 elementi identificati con attributo `id`. I componenti operativi fondamentali sono così ripartiti:

### 6.1 Header Superiore (Barra del Titolo e Controlli Globali)
- `#lblAppTitle`: titolo con versione applicativa consolidata.
- `#themeSelect`: selettore tema (`Dark Modern`, `Light Classic`, `Matrix High-Contrast`).
- `#audioModeSelect`: selettore sonoro (`Typewriter`, `Beep Error`, `Mute`).
- `#audioVolume`: cursore di regolazione lineare ampiezza audio.
- `#lblCurrentUser`: badge indicante il nome del profilo attivo.
- `#btnHeaderSwitchUser`: apre la modale di gestione profili (`#modalUserManager`).
- `#btnOpenCustomEditor`: apre l'editor di lezioni custom (`#modalCustomEditor`).
- `#btnOpenStats`: apre la finestra di analisi prestazionale (`#modalStats`).
- `#btnHelpLink`: apre la guida utente in linea.

### 6.2 Toolbar 1 - Percorso Didattico e Lezioni
- `#cboMode`: selettore a discesa delle 6 modalità di esercizio (valori `0` .. `5`).
- `#btnPrevLesson`, `#btnNextLesson`: pulsanti per navigare tra le lezioni.
- `#cboLessons`: elenco delle 70 lezioni native o dei capitoli del corso personalizzato.
- `#btnToggleLessonSource`: commuta la sorgente attiva tra Standard e Custom.
- `#lblLessonSource`: etichetta di stato della sorgente attiva.
- `#lblPhraseRange`: **badge interattivo e cliccabile** mostrante l'intervallo frasi (es. `📖 Frasi: 1 - 21`).
- `#lblExerciseTitle`: etichetta testuale dinamica recante il titolo dell'esercizio in corso.

### 6.3 Toolbar 2 - Azioni Frasi e Visibilità
- `#btnPrevPhrase`, `#btnNextPhrase`: pulsanti `<` (F6) e `>` (F7).
- `#btnSelectPhraseModal`: pulsante visibile `📖 Vai a Frase...` (hotkey F8 o CTRL+SHIFT+E).
- `#btnRandomPhrase`: estrae una frase casuale nella lezione attiva (ALT+M).
- `#btnRestartPhrase`: riavvia la frase azzerando tempo ed errori (F9 o ALT+A).
- `#btnRandomThisPhrase`: rimescola i caratteri della frase corrente (F11 o ALT+I).
- `#btnRandomAllChars`: carica l'esercizio globale con tutti i caratteri (F12 o ALT+L).
- Checkbox di visibilità e opzioni:
  - `#chkShowKeyBoard` (ALT+K): visualizzazione finestra tastiera.
  - `#chkShowHands` (ALT+W): visualizzazione finestra mani vettoriali.
  - `#chkShowOrigin` (ALT+O): visualizzazione riga testo originale.
  - `#chkShowTyped` (ALT+Y): visualizzazione casella testo digitato.
  - `#chkAutomaticCorrection` (F5 o ALT+B): modalità rigida senza Backspace.

### 6.4 Area di Digitazione e Feedback Didattico
- `#txtOriginContainer`: visualizzazione frase guida con classi dinamiche:
  - `.char-pending`: caratteri futuri.
  - `.char-target`: carattere corrente con cursore pulsante ad alto contrasto.
  - `.char-correct`: caratteri digitati correttamente.
  - `.char-error-target`: sfondo rosso intenso esteso proporzionale agli errori commessi.
  - Glifi fittizi `␣`: spazi rossi per battute eccedenti la lunghezza della frase.
- `#txtTypedInput`: casella di testo con focus permanente e sfondo verde a successo.
- **`#wrongCharFloatingBadge`**: **badge fluttuante temporizzato della lettera errata**:
  - Compare esattamente sopra il cursore del testo target non appena si preme un tasto errato.
  - Mostra il carattere errato (o `SPAZIO` per lo spazio bianco).
  - Scompare automaticamente dopo 550 ms.
- `#panelFixingData`: pannello attivo in modalità `TYPING` con:
  - `#txtFixingTime`: tempo trascorso nella sessione libera.
  - `#txtFixingRightEverage`: battute al minuto nette.
  - `#txtFixingTotalEverage`: battute al minuto lorde.
  - `#btnAddStatistic`: pulsante per salvare la sessione nell'archivio storico.
  - `#btnClearTypingSession`: pulsante per azzerare il testo libero digitato.

### 6.5 Dashboard Metriche in Tempo Reale
- `#txtTime`: durata della sessione nel formato naturale `MM:SS`.
- `#txtRightChars`: battute corrette totali.
- `#txtRightEverage`: velocità netta in Battute al Minuto (BTM/WPM).
- `#txtTotalEverage`: velocità lorda in Battute al Minuto (comprese battute errate).
- `#txtErrors`: conteggio assoluto degli errori.
- `#txtPercErrors`: percentuale di errore standardizzata a un decimale: `NN.N%`.

### 6.6 Finestra Tastiera Virtuale QWERTY IT (105 Tasti)
- Finestra fluttuante con `#keyboardHeader` e maniglia di ridimensionamento.
- Mappatura cromatica per dito e lampeggio del tasto bersaglio a ~300 ms.
- Flash visivo sul tasto fisico premuto.
- Indicatori luminosi a LED per Caps Lock, Num Lock e Scroll Lock.

### 6.7 Finestra Mani SVG Alta Fedeltà Anatomica
- Silhouette vettoriale continua viewBox 1408x768 con `#handsWindowHeader`, pulsante di ripristino posizione/dimensioni `#btnHandsDefaultPos` (`↺ Default`), e chiusura `#btnHandsClose`.
- **Ancoraggio Relativo all'Applicazione e Invarianza di Scrolling (v.2.11)**: la finestra è posizionata con `position: absolute;` rispetto al `body` (avente `position: relative;`). Le coordinate (`HandsLeft`, `HandsTop`) memorizzate nel profilo utente sono relative all'angolo superiore sinistro dell'applicazione (`<main>`). Grazie a tale architettura, la finestra conserva la propria posizione relativa rispetto all'interfaccia dell'applicazione sia durante lo zoom che durante lo scrolling della pagina con accelerazione hardware nativa a 60 fps (zero lag, zero jitter).
- Maniglie perimetrali su tutti gli 8 bordi e angoli per il ridimensionamento elastico bidirezionale (`.resize-handle`), gestite da `WindowManager` con coordinate documento (`e.pageX`, `e.pageY`).
- Baricentri geometrici invarianti `(data-cx, data-cy)` per i 10 polpastrelli (`#f1` .. `#f10`).
- **Keycaps 3D sui Polpastrelli (v.2.4 - v.2.7)**:
  - Dimensioni 87x78 px, raccordi angolari curvi (`rx="14" ry="14"`).
  - Tipografia: font sans-serif 48 px ultra-bold con stroke protettivo di 6 px.
  - Bordo anatomico da 4.8 px e alone volumetrico drop-shadow da 16 px.
  - Espansione automatica fino a 174 px per `SPAZIO` e tasti estesi.
- **Ritaglio Intelligente Non-Scalato (v.2.11)**:
  - Nel resize elastico il disegno delle mani non viene rimpicciolito; il sistema ritaglia lo spazio vuoto perimetrale.
  - In caso di forte riduzione verticale, la base dei polsi viene sacrificata e le etichette `#lblLeftHand` e `#lblRightHand` vengono alzate automaticamente per non scomparire.
- **Macchina a stati hardware `activePhysicalKeys`**: persistenza continua di tutti i modificatori fisici reali fino al rilascio effettivo (`keyup`), con soppressione del finto CtrlLeft alla pressione di AltGr.

### 6.8 Finestra Statistiche Cartesiane Fullscreen
- Modale responsive a tutto schermo con commutazione a selettori radio:
- **Vista Istogramma (`#statsHistogramSvgBox`)**: 6 ordinamenti interattivi (frequenze ed errori assoluti o relativi, per singolo carattere o raggruppati per dito).
- **Vista Grafico Cartesiano (`#statsSpeedSvgBox`)**:
  - Asse Y commutabile (`btm`, `chars`, `errRel`, `errAss`).
  - **7 Filtri selettivi per modalità**:
    1. `#chkFiltroPhrases`: Frasi native
    2. `#chkFiltroCustom`: Lezioni custom
    3. `#chkFiltroRandom`: Caratteri casuali
    4. `#chkFiltroTyping`: Digitazione libera
    5. `#chkFiltroRandomThis`: Frasi rimescolate
    6. `#chkFiltroAllChars`: Tutti i caratteri
    7. `#chkFiltroFonemi`: Catena sillabica fonemi
  - **Crosshair orizzontale rosso** mobile reattivo al puntatore con badge quota Y galleggiante.
  - **Selezione cartesiana a 3 click**: 1° intervallo (calcola media in `#lblMediaValori`), 2° punto singolo (mostra dettagli in `#txtEsercizio`), 3° ripristino media globale.
  - Pulsante `#btnClearSelection`: elimina dal dataset i soli campioni selezionati.
  - Pulsante `#btnResetAllStats`: reset completo dell'archivio utente con dialogo di conferma.

### 6.9 Modali di Servizio
- **Modale Seleziona Frase (`#modalSelectPhrase`)**: selettore lezioni sincronizzato `#selSelectPhraseLesson`, casella numerica `#txtSelectPhraseIndex` e range limite `#lblSelectPhraseMax`.
- **Modale Editor Custom (`#modalCustomEditor`)**: area di testo multilinea `#txtCustomExercises`, pulsanti di salvataggio `#btnSaveCustomExercises` e ripristino `#btnResetCustomExercises`.
- **Modale Gestione Utenti (`#modalUserManager`)**: elenco utenti `#selUserList`, creazione `#txtNewUserName` / `#btnCreateUser`, eliminazione `#btnDeleteUser`, esportazione JSON/XML e importazione con file picker `#fileImportInput`.

---

## 7. Tabella Completa delle Scorciatoie da Tastiera (Hotkeys)

| Scorciatoia Reale SPA | Controllo UI Corrispondente | Azione Eseguita nell'Applicazione |
| :---: | :---: | :--- |
| **F1** / `CTRL+SHIFT+H` | Pulsante [❓ Guida] | Apre la Guida Utente in linea (`help_(v.2.11).html`) |
| `CTRL+SHIFT+1` | Menu Modalità: 0 | Imposta la modalità didattica **PHRASES** (Frasi progressive native) |
| `CTRL+SHIFT+2` | Menu Modalità: 1 | Imposta la modalità didattica **RANDOM** (Caratteri casuali ponderati) |
| `CTRL+SHIFT+3` | Menu Modalità: 2 | Imposta la modalità didattica **FONEMI** (Catena sillabica italiana N-gram) |
| `CTRL+SHIFT+4` / `CTRL+SHIFT+G` | Menu Modalità: 3 / Pulsante | Imposta la modalità didattica **ALL CHARS** (Tutti i tasti della tastiera) |
| `CTRL+SHIFT+5` | Menu Modalità: 4 | Imposta la modalità didattica **TYPING** (Digitazione libera con polpastrelli reattivi) |
| `CTRL+SHIFT+Z` | Menu Modalità: 5 | Imposta la modalità didattica **RANDOM THIS PHRASE** (Rimescola la frase attiva) |
| `CTRL+SHIFT+ArrowLeft` | `<` (Toolbar 2) | Seleziona la **frase precedente** della lezione attiva |
| `CTRL+SHIFT+ArrowRight` | `>` (Toolbar 2) | Seleziona la **frase successiva** della lezione attiva |
| `CTRL+SHIFT+ArrowUp` | Menu Lezioni (Toolbar 1) | Passa alla **lezione didattica precedente** nella lista |
| `CTRL+SHIFT+ArrowDown` | Menu Lezioni (Toolbar 1) | Passa alla **lezione didattica successiva** nella lista |
| `CTRL+SHIFT+X` | Pulsante [🔄 Riavvia] | **Riavvia la frase corrente**, azzerando cronometro ed errori parziali |
| `CTRL+SHIFT+A` | Pulsante [🎲 Casuale] | Estrae casualmente una delle frasi disponibili per la lezione attiva |
| `CTRL+SHIFT+E` | Pulsante [📖 Vai a Frase...] | Apre la modale per saltare direttamente a una frase per indice numerico |
| `CTRL+SHIFT+M` | Checkbox [Mani] | Mostra o nasconde la finestra fluttuante delle **Mani** ("10 Fingers") |
| `CTRL+SHIFT+K` | Checkbox [Tastiera] | Mostra o nasconde la **Tastiera virtuale** a 105 tasti |
| `CTRL+SHIFT+O` | Checkbox [Testo Guida] | Mostra o nasconde la riga del **Testo Guida** proposto |
| `CTRL+SHIFT+Y` | Checkbox [Input] | Mostra o nasconde l'area di testo di digitazione utente |
| `CTRL+SHIFT+B` | Checkbox [Auto-Correzione] | Attiva o disattiva l'Autocorrezione automatica (blocco del Backspace) |
| `CTRL+SHIFT+S` | Pulsante [📊 Statistiche] | Apre o chiude la finestra cartesiana responsive delle **Statistiche** |
| `CTRL+SHIFT+U` | Pulsante [👤 Profilo] | Apre la modale di Gestione Utenti, creazione e cambio profilo |

---

## 8. Linee Guida Operative per il Kickoff delle Chat Successive

1. **Sorgente di Riferimento**: il codice operativo risiede in `index_(v.2.11).html` (e successivi `index_(v.2.x).html`).
2. **Preservazione del Patrimonio Esistente**: vietata qualsiasi alterazione dei metodi già funzionanti delle 8 classi e del dimensionamento a 1.5x dei keycaps sui polpastrelli.
3. **Regola dei Versioni Incrementali**: ogni nuova modifica richiederà l'emissione dei nuovi file `v.2.x+1` con allineamento speculare tra `NEW_DOCS` e `SRC`.
4. **Divieto di Formattazione LaTeX**: tutti i documenti tecnici, metriche e percentuali devono impiegare esclusivamente notazione naturale leggibile (es. `NN.N%`, `1.5x`, `87x78 px`).
