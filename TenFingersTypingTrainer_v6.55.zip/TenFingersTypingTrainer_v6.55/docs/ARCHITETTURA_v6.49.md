# Architettura TenFingersTypingTrainer v6.49

Documento di aggiornamento architetturale rispetto alla v6.48.

## 1. Obiettivo della Release v6.49
Pulizia dell'interfaccia di configurazione della finestra **Interrogazione** mediante rimozione della DropDownList non collegata **"Risposta Per Dito"** (`#interrogationFingerModeSelect`), che non influiva sulla logica di esecuzione né di valutazione dei quesiti `DITO`.

## 2. Interventi
- **`index.html`**: rimosso il blocco `.interr-form-row` contenente `<select id="interrogationFingerModeSelect">`.
- **`js/ui/interrogation-ui.js`**: rimossa la proprietà orfana `this.fingerMode`, il relativo listener su `#interrogationFingerModeSelect` e la lettura in `_handleStartSession()`.
