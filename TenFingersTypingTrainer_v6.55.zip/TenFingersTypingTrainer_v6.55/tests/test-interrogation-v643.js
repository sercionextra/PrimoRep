/* Test v6.43: Interrogazione su Piano di Studio, MaxLessonReached, mascheramento slot e coerenza UI/Help. */
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");

function createLocalStorageMock() {
  const store = new Map();
  return {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
    clear: () => store.clear(),
  };
}

function loadContext() {
  const ctx = {
    window: {},
    globalThis: {},
    console,
    Date,
    Math,
    JSON,
    Set,
    Map,
    Array,
    Object,
    String,
    Number,
    Boolean,
    Promise,
    Error,
    TextEncoder,
    crypto: require("crypto").webcrypto,
    localStorage: createLocalStorageMock(),
  };
  ctx.window = ctx;
  ctx.globalThis = ctx;
  vm.createContext(ctx);

  const files = [
    "js/data/lessons.js",
    "js/data/interrogation-catalog-data.js",
    "js/data/lesson-curriculum-scope.js",
    "js/profiles/profile-manager.js",
    "js/interrogation/interrogation-prng.js",
    "js/interrogation/interrogation-layout-metadata.js",
    "js/interrogation/interrogation-catalog.js",
    "js/interrogation/interrogation-knowledge.js",
    "js/interrogation/interrogation-selector.js",
    "js/interrogation/interrogation-repository.js",
    "js/interrogation/interrogation-session-manager.js",
  ];
  for (const rel of files) {
    const code = fs.readFileSync(path.join(ROOT, rel), "utf8");
    vm.runInContext(code, ctx, { filename: rel });
  }
  vm.runInContext("if (typeof ProfileManager !== 'undefined') this.ProfileManager = ProfileManager;", ctx);
  return ctx;
}

async function run() {
  const ctx = loadContext();
  const Scope = ctx.LessonCurriculumScope;
  assert(Scope, "LessonCurriculumScope deve essere definito");
  assert.strictEqual(Scope.getLessonCount(), 71, "Devono esserci 71 lezioni standard");

  // 1. Verifica scope Lezione 1 (indice 0: asdfl)
  const s0 = Scope.getScopeUpToLesson(0);
  ["a", "s", "d", "f", "l", " "].forEach((ch) => {
    assert(s0.unlockedChars.has(ch), `Lezione 1 deve includere '${ch}'`);
  });
  ["j", "k", "ò", "!", "?", "@", "A"].forEach((ch) => {
    assert(!s0.unlockedChars.has(ch), `Lezione 1 NON deve includere '${ch}'`);
  });

  // 2. Verifica getSlotConstraint
  const shiftAtL1 = Scope.getSlotConstraint("shift", null, 0);
  assert.strictEqual(shiftAtL1.allowed, false);
  assert.strictEqual(shiftAtL1.requiredLesson1Based, 26);

  const exclAtL41 = Scope.getSlotConstraint("shift", "!", 40);
  assert.strictEqual(exclAtL41.allowed, false);
  assert.strictEqual(exclAtL41.requiredLesson1Based, 43);

  const exclAtL43 = Scope.getSlotConstraint("shift", "!", 42);
  assert.strictEqual(exclAtL43.allowed, true);

  // 3. Verifica Catalog getCandidates con maxLessonIndex = 0
  const catalog = new ctx.InterrogationCatalog();
  const charL1 = catalog.getCandidates({ questionTypes: ["CARATTERE"], maxLessonIndex: 0 });
  assert.strictEqual(charL1.length, 6, `Attesi 6 caratteri alla Lezione 1, trovati ${charL1.length}`);

  const homeL1 = catalog.getCandidates({ questionTypes: ["HOME_ROW"], maxLessonIndex: 0 });
  assert(homeL1.length < 10, "HOME_ROW alla Lezione 1 deve escludere dita non ancora studiate (j, k, ò)");
  assert(!homeL1.some((c) => c.fingerId === "7" || c.fingerId === "8"), "Dita 7 (j) e 8 (k) escluse alla Lezione 1");

  // 4. Verifica SessionManager con lessonScope = curriculum e maxLessonIndex = 0
  const repo = new ctx.InterrogationRepository();
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository: repo });
  const created = await mgr.createSession({
    profileId: "test_u",
    mode: "random",
    lessonScope: "curriculum",
    maxLessonIndex: 0,
    questionTypes: ["TASTO"],
    requestedCount: 10,
  });
  assert.strictEqual(created.session.lessonScope, "curriculum");
  assert.strictEqual(created.session.maxLessonIndex, 0);
  assert.strictEqual(created.session.configSnapshot.lessonScope, "curriculum");
  assert.strictEqual(created.session.configSnapshot.maxLessonIndex, 0);
  assert.strictEqual(created.reducedAvailability, true);
  assert.strictEqual(created.session.effectiveCount, 6);
  assert(created.items.every((it) => it.lessonScope === "curriculum" && it.maxLessonIndex === 0));

  // 5. Verifica ProfileManager MaxLessonReached (avanzamento + correzione manuale in riduzione)
  const pm = new ctx.ProfileManager({}, "");
  pm.init();
  assert.strictEqual(pm.getMaxLessonReached(), 1);
  pm.updateMaxLessonReachedIfHigher(15);
  assert.strictEqual(pm.getMaxLessonReached(), 15);
  pm.updateMaxLessonReachedIfHigher(5);
  assert.strictEqual(pm.getMaxLessonReached(), 15, "updateMaxLessonReachedIfHigher non deve ridurre il traguardo");
  pm.setMaxLessonReached(4);
  assert.strictEqual(pm.getMaxLessonReached(), 4, "setMaxLessonReached deve consentire la riduzione esplicita");

  // 6. Verifica index.html e help.html
  const indexHtml = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
  assert(indexHtml.includes('id="interrogationScopeSelect"'), "index.html deve contenere interrogationScopeSelect");
  assert(
    indexHtml.includes('<option value="curriculum" selected>Piano di Studio'),
    "Piano di Studio deve essere la prima opzione selezionata di default",
  );
  assert(indexHtml.includes('id="btnInterrSaveMaxLesson"'), "index.html deve contenere btnInterrSaveMaxLesson");
  assert(indexHtml.includes('id="interrHistScopeFilter"'), "index.html deve contenere interrHistScopeFilter");

  const helpHtml = fs.readFileSync(path.join(ROOT, "help.html"), "utf8");
  assert(helpHtml.includes('id="interrogation"'), "help.html deve contenere la sezione #interrogation");
  assert(helpHtml.includes("Imposta come traguardo"), "help.html deve documentare Imposta come traguardo");

  console.log("PASS: test-interrogation-v643 verificato con successo.");
}

run().catch((err) => {
  console.error("FAIL test-interrogation-v643:", err);
  process.exit(1);
});
