# Architettura — TenFingersTypingTrainer v6.21

## Obiettivo

La release v6.21 perfeziona la logica di transizione automatica allo **Spelling Temporaneo** della Dettatura Adattiva Dinamica, eliminando l'attivazione indebita causata dalla digitazione involontaria di battute consecutive durante la foga di scrittura (*Error Burst*).
Viene introdotta la distinzione formale tra **battuta errata isolata** (che alimenta le metriche e il feedback acustico) ed **episodio di errore sulla parola** (che determina la progressione didattica verso la compitazione lettera per lettera).

---

## Analisi Architetturale del Problema

### 1. Sovraconteggio degli Errori nella Foga di Digitazione (Error Burst)
Nelle versioni precedenti (v6.14 e v6.15), l'algoritmo di Dettatura Adattiva prevedeva:
* Al 1° errore corretto sulla parola: ripresa della lettura del troncone residuo continuo con ritmo prudente;
* Al 2° errore sulla medesima parola: attivazione dello Spelling persistente lettera per lettera fino al completamento del vocabolo.

Tuttavia, nel metodo `notifyError()`, il contatore `tokenErrorCount++` veniva incrementato ad ogni singola pressione di tasto non corrispondente al carattere atteso.
Quando un allievo che digita a velocità sostenuta commette un errore (es. digita `k` al posto di `a` sulla parola *"salsa"*), per inerzia motoria (*foga di digitazione*) tende a battere uno o due caratteri aggiuntivi prima di accorgersi del suono di errore e arrestarsi (digitando ad esempio `skkk`).
Nel vecchio codice:
1. La prima `k` incrementava `tokenErrorCount` da 0 a 1;
2. La seconda `k` lo incrementava da 1 a 2;
3. La terza `k` lo incrementava a 3.

Quando l'allievo premeva tre volte il tasto Backspace tornando alla posizione corretta `la s` (zero errori pendenti), il sistema trovava `tokenErrorCount = 3` e faceva scattare immediatamente e ingiustificatamente lo Spelling guidato, sebbene l'allievo avesse commesso un unico sbaglio concettuale su quella lettera.

---

## Soluzione Architetturale Implementata nella Release v6.21

### 1. Modello a "Episodio di Errore" (Error Burst Session)
È stata introdotta la gestione di stato dell'episodio di errore basata sul flag `this.hasPendingError`:
* Quando l'allievo commette un errore a partire da una digitazione corretta (`hasPendingError === false`), si apre un **nuovo episodio di errore**:
  `const isNewErrorEpisode = !this.hasPendingError;`
  `this.hasPendingError = true;`
* Solo se `isNewErrorEpisode === true`, il contatore di parola `this.tokenErrorCount` viene incrementato;
* Se l'allievo batte ulteriori tasti mentre sono già presenti errori pendenti non ancora cancellati con Backspace (`hasPendingError === true`), tali battute:
  1. Emettono il consueto riscontro vocale istantaneo *"errore"* o segnale acustico;
  2. Vengono registrate nelle metriche generali della sessione (errori totali e calcolo CPM);
  3. **Non incrementano** il contatore `tokenErrorCount` della parola corrente.

### 2. Risoluzione dell'Episodio e Transizione di Stato
* Durante la pressione del tasto Backspace, il metodo `notifyErrorCorrection(remainingErrors, ...)` aggiorna lo stato:
  `this.hasPendingError = remainingErrors > 0;`
* Finché restano errori nel buffer (`remainingErrors > 0`), la voce scandisce il numero scalare di correzioni mancanti (*"ancora 2 errori"*, *"ancora un errore"*);
* Non appena tutti i caratteri errati sono stati cancellati (`remainingErrors === 0`), l'episodio di errore si chiude formalmente (`hasPendingError = false`);
* A questo punto viene valutato il contatore effettivo della parola:
  * Se `tokenErrorCount == 1`: il sistema pronuncia il troncone residuo continuo (es. *"alsa"*);
  * Se `tokenErrorCount >= 2`: si attiva lo **Spelling guidato** (`wordSpellingTokenIdx = activeTokenIdx`), pronunciando immediatamente a compitazione la prima lettera successiva attesa (es. *"elle"*).

### 3. Digitazione Intermedia e Secondo Episodio Distinto
Se l'allievo corregge il primo errore (es. torna a `la s`), digita correttamente una o più lettere intermedie della parola (es. `a`, portandosi a `la sa`) e successivamente commette un nuovo errore sulla lettera `l` (es. `sakkk`):
1. La prima battuta errata trova `hasPendingError === false` ed apre il **2° episodio di errore** (`tokenErrorCount = 2`);
2. Le battute successive nella foga mantengono il contatore a 2;
3. Alla correzione con Backspace tornando a `la sa` (zero errori pendenti), trovando `tokenErrorCount >= 2`, scatta correttamente lo Spelling temporaneo per la parte rimanente della parola.

### 4. Robustezza durante lo Spelling Attivo e Chiusura della Parola
* Se durante lo Spelling guidato l'allievo sbaglia a digitare una delle lettere compitate, alla correzione con Backspace il sistema mantiene lo stato di spelling attivo e ripete la compitazione della lettera attesa;
* Al completamento naturale della parola (raggiungimento dell'indice finale del token), sia `wordSpellingTokenIdx` sia `tokenErrorCount` vengono azzerati a 0 per la parola successiva;
* Nella modalità con *Correzione Automatica* attiva (senza inserimento degli errori nel testo e senza necessità di Backspace), ogni battuta errata isolata costituisce un tentativo singolo e trasparente.

---

## Mappa dei Componenti Modificati (Release v6.21)

1. `js/engines/dictation-engine.js`:
   * `notifyError()`: rilevamento `isNewErrorEpisode = !this.hasPendingError` e incremento condizionato di `tokenErrorCount`;
   * `notifyErrorCorrection()`: chiusura dell'episodio a `remainingErrors === 0` e attivazione dello spelling persistente al 2° episodio corretto;
2. `js/app/controller/controller-core.js`:
   * Aggiornamento numero di versione applicativa runtime a `"6.21"`;
3. `js/profiles/profile-manager.js`:
   * Aggiornamento versione profilo a `"6.21"` in `demoProf` e in `saveProfile()`;
4. `index.html` & `help.html`:
   * Allineamento intestazioni, titoli, note di rilascio e documentazione didattica alla versione v6.21;
5. `tests/test-dictation-adaptive.js`:
   * Inclusione del TEST 15 che valida l'intero ciclo: Error Burst a 3 battute, pronuncia del troncone al 1° episodio, avanzamento corretto, 2° episodio distinto, attivazione dello spelling e ripristino a fine parola.
