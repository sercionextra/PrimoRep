# Manuale Utente — Aggiornamento v6.38

## Novità della versione v6.38

1. **Finestra "Seleziona carattere / tasto" più compatta e centrata:**
   - La larghezza della finestra è stata ottimizzata (ridotta di circa 100px) mantenendo tutte le 26 lettere dell'alfabeto su un'unica riga, con tutte le righe dei tasti centrate orizzontalmente.
