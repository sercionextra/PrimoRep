# Errore di comunicazione: ambiguità nei movimenti fisici e rotazioni dell'intero cubo

Status: active
Riferimento: lessons/0004-il-secondo-strato.html

L'utente ha espresso forte frustrazione per la mancanza di chiarezza ed esplicitezza delle spiegazioni.
Cause individuate:
1. Ambiguità tra "ruotare una faccia" e "ruotare l'intero cubo/cambiare prospettiva visiva".
2. Controintuitività della notazione di sinistra (`L` va in giù, `L'` va in su), facilmente confusa con `R`.
3. Necessità di eliminare il gergo astratto e descrivere le azioni con esattezza meccanica (tasti esatti da premere o movimenti fisici del mouse/dita: 'colonna destra in su', 'striscia superiore verso sinistra', ecc.).
Si passa a una modalità ultra-esplicita, guidata passo dopo passo su un singolo pezzo.
