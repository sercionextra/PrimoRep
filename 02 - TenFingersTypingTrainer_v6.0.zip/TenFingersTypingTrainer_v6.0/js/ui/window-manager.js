/* TenFingersTypingTrainer v6.0 | window-manager.js | Refactoring compatibile: comportamento sorgente preservato. */
class WindowManager {
  constructor() {
    this.activeDrag = null;
    this.activeResize = null;
    this.startX = 0;
    this.startY = 0;
    this.initX = 0;
    this.initY = 0;
    this.initW = 0;
    this.initH = 0;
    this.isAbsoluteDrag = false;
    this.initGlobalEvents();
  }

  // Viewport Boundary Guard: garantisce che la finestra rimanga sempre afferrabile e visibile
  clampWindowToViewport(windowElem, isAbsolute = false) {
    if (!windowElem) return;
    const w = windowElem.offsetWidth || 540;
    const h = windowElem.offsetHeight || 330;

    if (isAbsolute) {
      const docW = Math.max(
        document.documentElement.clientWidth,
        window.innerWidth || 1280,
      );
      const docH = Math.max(
        document.documentElement.scrollHeight,
        window.innerHeight || 800,
      );
      const minLeft = 10;
      const maxLeft = Math.max(minLeft, docW - w - 10);
      const minTop = 60; // Sotto la barra header principale
      const maxTop = Math.max(minTop, docH - 50);

      let curLeft = windowElem.offsetLeft;
      let curTop = windowElem.offsetTop;
      let clampedLeft = Math.max(minLeft, Math.min(maxLeft, curLeft));
      let clampedTop = Math.max(minTop, Math.min(maxTop, curTop));

      windowElem.style.left = clampedLeft + "px";
      windowElem.style.top = clampedTop + "px";
      return { left: clampedLeft, top: clampedTop };
    } else {
      const vpW = window.innerWidth || 1280;
      const vpH = window.innerHeight || 800;
      const minLeft = 10;
      const maxLeft = Math.max(minLeft, vpW - w - 10);
      const minTop = 60; // Sotto la barra header principale
      const maxTop = Math.max(minTop, vpH - 50); // Almeno 50px visibili per riafferrare l'header

      let curLeft = parseInt(windowElem.style.left, 10);
      let curTop = parseInt(windowElem.style.top, 10);
      if (isNaN(curLeft)) curLeft = windowElem.getBoundingClientRect().left;
      if (isNaN(curTop)) curTop = windowElem.getBoundingClientRect().top;

      let clampedLeft = Math.max(minLeft, Math.min(maxLeft, curLeft));
      let clampedTop = Math.max(minTop, Math.min(maxTop, curTop));

      windowElem.style.left = clampedLeft + "px";
      windowElem.style.top = clampedTop + "px";
      return { left: clampedLeft, top: clampedTop };
    }
  }

  makeDraggable(windowElem, headerElem, onPositionChanged) {
    if (!windowElem || !headerElem) return;

    headerElem.addEventListener("mousedown", (e) => {
      if (
        e.target.closest("button") ||
        windowElem.classList.contains("window-fullscreen")
      )
        return;
      this.activeDrag = windowElem;
      this.onPositionChanged = onPositionChanged;
      const isAbsolute =
        window.getComputedStyle(windowElem).position === "absolute";
      this.isAbsoluteDrag = isAbsolute;
      if (isAbsolute) {
        this.startX = e.pageX;
        this.startY = e.pageY;
        this.initX = windowElem.offsetLeft;
        this.initY = windowElem.offsetTop;
      } else {
        this.startX = e.clientX;
        this.startY = e.clientY;
        const rect = windowElem.getBoundingClientRect();
        this.initX = rect.left;
        this.initY = rect.top;
      }
      windowElem.style.zIndex = "1500";
    });
  }

  makeResizable(windowElem, onResized, minW = 520, minH = 360) {
    if (!windowElem) return;
    const handles = windowElem.querySelectorAll(".resize-handle");
    handles.forEach((h) => {
      h.addEventListener("mousedown", (e) => {
        if (windowElem.classList.contains("window-fullscreen")) return;
        e.preventDefault();
        e.stopPropagation();
        const isAbsolute =
          window.getComputedStyle(windowElem).position === "absolute";
        this.activeResize = {
          elem: windowElem,
          dir: h.getAttribute("data-dir"),
          onResized: onResized,
          minW: minW,
          minH: minH,
          isAbsolute: isAbsolute,
        };
        if (isAbsolute) {
          this.startX = e.pageX;
          this.startY = e.pageY;
          this.initX = windowElem.offsetLeft;
          this.initY = windowElem.offsetTop;
          this.initW = windowElem.offsetWidth;
          this.initH = windowElem.offsetHeight;
        } else {
          this.startX = e.clientX;
          this.startY = e.clientY;
          const rect = windowElem.getBoundingClientRect();
          this.initX = rect.left;
          this.initY = rect.top;
          this.initW = rect.width;
          this.initH = rect.height;
        }
        windowElem.style.zIndex = "1500";
      });
    });
  }

  initGlobalEvents() {
    window.addEventListener("mousemove", (e) => {
      if (this.activeDrag) {
        if (this.isAbsoluteDrag) {
          const dx = e.pageX - this.startX;
          const dy = e.pageY - this.startY;
          const docW = Math.max(
            document.documentElement.clientWidth,
            window.innerWidth || 1280,
          );
          const docH = Math.max(
            document.documentElement.scrollHeight,
            window.innerHeight || 800,
          );
          const minLeft = 10;
          const maxLeft = Math.max(
            minLeft,
            docW - this.activeDrag.offsetWidth - 10,
          );
          const minTop = 60; // Protezione barra header principale
          const maxTop = Math.max(minTop, docH - 50);

          let newX = Math.max(minLeft, Math.min(maxLeft, this.initX + dx));
          let newY = Math.max(minTop, Math.min(maxTop, this.initY + dy));
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        } else {
          const dx = e.clientX - this.startX;
          const dy = e.clientY - this.startY;
          const minLeft = 10;
          const maxLeft = Math.max(
            minLeft,
            window.innerWidth - this.activeDrag.offsetWidth - 10,
          );
          const minTop = 60; // Protezione barra header principale
          const maxTop = Math.max(minTop, window.innerHeight - 50);

          let newX = Math.max(minLeft, Math.min(maxLeft, this.initX + dx));
          let newY = Math.max(minTop, Math.min(maxTop, this.initY + dy));
          this.activeDrag.style.left = newX + "px";
          this.activeDrag.style.top = newY + "px";
          if (this.onPositionChanged) {
            this.onPositionChanged(newX, newY);
          }
        }
      }

      if (this.activeResize) {
        const ar = this.activeResize;
        const currentX = ar.isAbsolute ? e.pageX : e.clientX;
        const currentY = ar.isAbsolute ? e.pageY : e.clientY;
        const dx = currentX - this.startX;
        const dy = currentY - this.startY;
        const dir = ar.dir;
        let newW = this.initW;
        let newH = this.initH;
        let newL = this.initX;
        let newT = this.initY;

        const maxAvailW =
          (ar.isAbsolute
            ? document.documentElement.clientWidth
            : window.innerWidth) - 20;
        const maxAvailH =
          (ar.isAbsolute
            ? document.documentElement.scrollHeight
            : window.innerHeight) - 70;

        // Ridimensionamento verso Est (destra): ancoraggio sinistro fisso
        if (dir.includes("e")) {
          newW = Math.max(
            ar.minW,
            Math.min(maxAvailW - this.initX, this.initW + dx),
          );
        }
        // Ridimensionamento verso Sud (basso): ancoraggio superiore fisso
        if (dir.includes("s")) {
          newH = Math.max(
            ar.minH,
            Math.min(maxAvailH - this.initY, this.initH + dy),
          );
        }
        // Ridimensionamento verso Ovest (sinistra): ancoraggio destro rigorosamente fisso
        if (dir.includes("w")) {
          const rightEdge = this.initX + this.initW;
          const minAllowedL = 10;
          const maxAllowedL = rightEdge - ar.minW;
          newL = Math.max(minAllowedL, Math.min(maxAllowedL, this.initX + dx));
          newW = rightEdge - newL;
        }
        // Ridimensionamento verso Nord (alto): ancoraggio inferiore rigorosamente fisso
        if (dir.includes("n")) {
          const bottomEdge = this.initY + this.initH;
          const minAllowedT = 60; // Limite superiore invalicabile
          const maxAllowedT = bottomEdge - ar.minH; // Garantisce l'altezza minima
          newT = Math.max(minAllowedT, Math.min(maxAllowedT, this.initY + dy));
          newH = bottomEdge - newT;
        }

        ar.elem.style.width = newW + "px";
        ar.elem.style.height = newH + "px";
        ar.elem.style.left = newL + "px";
        ar.elem.style.top = newT + "px";
        ar.elem.style.maxWidth = "none";
      }
    });

    window.addEventListener("mouseup", () => {
      if (this.activeDrag) {
        this.clampWindowToViewport(this.activeDrag, this.isAbsoluteDrag);
        this.activeDrag.style.zIndex = "1000";
        this.activeDrag = null;
      }
      if (this.activeResize) {
        const ar = this.activeResize;
        this.clampWindowToViewport(ar.elem, ar.isAbsolute);
        ar.elem.style.zIndex = "1000";
        if (ar.onResized) {
          ar.onResized(
            ar.elem.offsetWidth,
            ar.elem.offsetHeight,
            ar.elem.offsetLeft,
            ar.elem.offsetTop,
          );
        }
        this.activeResize = null;
      }
    });

    // Sanitizzazione al resize della finestra del browser
    window.addEventListener("resize", () => {
      document
        .querySelectorAll(".floating-window.window-visible")
        .forEach((win) => {
          if (!win.classList.contains("window-fullscreen")) {
            const isAbs = window.getComputedStyle(win).position === "absolute";
            this.clampWindowToViewport(win, isAbs);
          }
        });
    });
  }
}

// TYPING ENGINE & STATE MACHINE (con marcatura DataOra)
