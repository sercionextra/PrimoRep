# Matrice di tracciabilità INTERROGAZIONE — v1.1

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Stato:** revisione documentale rispetto a Contratti Backend v1.3, Schema IndexedDB v1.3 e PRNG v1.0; nessuna modifica ai sorgenti  
**Ambito:** contratti backend, schema IndexedDB, motori, cataloghi e test  
**Riferimenti vincolanti:** HANDOFF TECNICO INTERROGAZIONE v1.0; SPECIFICA TECNICA INTERROGAZIONE v1.0; Contratti Backend v1.3; Schema IndexedDB v1.3; Decisione Quote D77–D80 v1.1; Motore Selezione v1.1; specifiche degli altri motori v1.0; cataloghi v1.0; Specifica PRNG v1.0 e relativi test vectors e relativi vettori di test.

---

## 1. Scopo e criterio di verifica

Questa matrice verifica che ogni dato e operazione richiesti dai motori abbiano una rappresentazione persistente, un contratto coerente e test che ne dimostrino il comportamento. Non modifica le decisioni funzionali approvate e non trasforma automaticamente le proposte tecniche in requisiti definitivi.

Esiti usati:

- **COERENTE** — il concetto è rintracciabile e non emerge una contraddizione sostanziale.
- **DELTA** — il concetto esiste, ma nomi, campi, enum o granularità non coincidono.
- **MANCANTE** — un requisito del motore non ha una rappresentazione fisica esplicita.
- **BLOCCANTE** — non è sicuro implementare il flusso interessato prima di chiudere il delta.
- **DA TESTARE** — il contratto è definito, ma la verifica automatica o browser deve ancora essere eseguita.

La presenza di un vettore JSON dimostra che il caso è stato specificato, non che sia già stato eseguito da un'implementazione.

## 2. Esito sintetico

| Area | Esito | Sintesi |
|---|---|---|
| Confini dei sei componenti | COERENTE | Le responsabilità dei componenti sono compatibili tra contratti e piano d'integrazione. |
| Catalogo elementi e relazioni | COERENTE, DA TESTARE | Template versionati e store `questionTemplates` introdotti nello schema v1.2; pubblicazione e materializzazione candidate ancora da testare. |
| Definizioni dei sotto-quesiti | COERENTE | `questionDefinitions` copre identità e versionamento; occorre preservare la distinzione tra definizione e template. |
| Sessioni e item | COERENTE | Snapshot e campi PRNG sono ora esplicitati nello schema v1.3; transazioni e resume restano da testare. |
| Eventi e correzioni | COERENTE | Append-only, idempotenza e riferimenti storici sono rappresentati. |
| Proiezione della conoscenza | COERENTE, DA TESTARE | Schema v1.3 include fattori, affidabilità, classificazione, calendario e versioni; restano test numerici e policy calendario. |
| Priorità consultazioni | COERENTE, DA TESTARE | Store `consultationPriorities` tipizzato e ricostruibile; restano test di consumo, rettifica e recovery. |
| Selettore | COERENTE A LIVELLO SPECIFICA, DA IMPLEMENTARE | Template e candidate deterministici sono definiti; PRNG xoshiro128** v1.0 e snapshot sono congelati; materializzazione e selezione restano da implementare/testare. |
| Calendario | DELTA/BLOCCANTE | Configurazione intervalli presente, ma stato del livello e versione policy non sono persistiti nello schema di esempio. |
| Quote D77–D80 | COERENTE | Budget 10%, tetto individuale 20%, riparto e quota neutra sono allineati; vettori da eseguire sul motore applicativo. |
| Atomicità e idempotenza | COERENTE | La transazione `recordOutcome` e le receipt sono definite; test IndexedDB reali ancora da eseguire. |
| Test e regressione | DA TESTARE | Esistono vettori e suite baseline, ma i test dei nuovi componenti non sono ancora eseguiti su codice implementato. |

**Conclusione:** l'architettura è sufficientemente definita per avviare una fase di allineamento documentale, ma non ancora per implementare senza ambiguità il backend adattivo completo. I blocchi principali sono il modello fisico della conoscenza, le priorità consultazione e i template/candidate.

## 3. Matrice requisito → contratto → persistenza → motore → test

| ID | Requisito / dato | Contratto backend v1.3 | Schema IndexedDB v1.3 | Motore / catalogo | Test / evidenza | Esito |
|---|---|---|---|---|---|---|
| TR-01 | Identità semantica e versioni contenuto | `semanticId`, `contentVersion`, `recordId` | `catalogElements` PK `[semanticId, contentVersion]`; `bySemanticId`, `byRecordId` | Catalogo QWERTY e catalogo domande | Validazione unicità e versioni | COERENTE |
| TR-02 | Relazioni catalografiche versionate | `relationId`, `catalogVersion`, `fromSemanticId`, `toSemanticId`, `relationType` | `catalogRelations`; indici per versione/origine/destinazione/tipo | Catalogo e risoluzione candidate | Riferimenti validi nella versione pubblicata | COERENTE |
| TR-03 | Definizioni autonome dei sotto-quesiti | `questionSemanticId`, `elementSemanticId`, `aspectId`, `answerType`, `answerDefinition`, `contentVersion` | `questionDefinitions` PK `[questionSemanticId, contentVersion]` | Catalogo Domande JSON, 445 definizioni attive | Validazione answerDefinition e identità | COERENTE |
| TR-04 | Template delle domande principali | Record template versionato con componenti e regola di composizione | Store `questionTemplates` con chiave composta per template/versione | JSON Catalogo Domande contiene `mainQuestionTemplates` (5) | Validazione template → definizioni → candidate | COERENTE, DA TESTARE |
| TR-05 | Candidate selezionabili espliciti | Candidate temporaneo immutabile con ID deterministico | Candidate materializzati in memoria; `sessionItems` conserva quelli selezionati | Catalog materializza template + definizioni + relazioni della stessa versione | Test stabilità candidateId, validità e deduplicazione | COERENTE, DA TESTARE |
| TR-06 | Configurazione per profilo | `profileId`, numero domande, modalità, quote | `profileSettings` | Selector e SessionManager | Snapshot invariato dopo modifica impostazioni | COERENTE |
| TR-07 | Snapshot sessione | `configSnapshot`, `selectionSnapshot`, `catalogVersion`, `algorithmVersion` | `sessions` include questi campi | Selector output e SessionManager | Ripresa senza ricalcolo | COERENTE, DELTA NOMI |
| TR-08 | Snapshot item e sotto-quesiti | `itemId`, `order`, `promptSnapshot`, sotto-quesiti con definizione congelata | `sessionItems` con array `subQuestions`, `definitionVersion`, `definitionSnapshot` | SessionManager | Modifica catalogo dopo creazione non altera sessione | COERENTE |
| TR-09 | Timestamp | Millisecondi Unix UTC nei record e API interne | Millisecondi Unix UTC e indici numerici | Tutti i motori usano unità uniformi | Test serializzazione e ordinamento | COERENTE, DA TESTARE |
| TR-10 | Evento immutabile | `outcome`, `score`, `occurredAt`, `eventSequence`, riferimenti versione | `exposureEvents` con chiave `[profileId,eventId]` e indici cronologici/operativi | Knowledge ricostruisce da eventi | Append-only; visualizzazione/non risposta senza evento | COERENTE, DELTA TIMESTAMP |
| TR-11 | Correzioni append-only | `correctionType`, `eventId`, `reversesCorrectionId`, motivo | `eventCorrections` con indici per evento, operationId e data | Knowledge applica sequenza correzioni | Correzione, annullamento, più rettifiche | COERENTE |
| TR-12 | Proiezione conoscenza ricostruibile | Proiezione derivata con fattori, versioni e fingerprint | `knowledgeStates` completo in schema v1.2 | Motore Conoscenza ricostruisce da eventi/correzioni | Ricostruzione deterministica e confronto fingerprint | COERENTE, DA TESTARE |
| TR-13 | Classificazione stabile | Enum canonico `neverVerified`, `weak`, `review`, `consolidated`, `insufficientData` | Codici macchina persistiti; etichette italiane solo UI | Motore Conoscenza usa gli stessi codici | Test soglie 70/30 e mai verificati | COERENTE, DA TESTARE |
| TR-14 | Indice prudenziale | `correctedWeaknessIndex` canonico | `correctedWeaknessIndex` persistito | Motore usa la stessa formula e lo stesso nome | Test formula e soglie | COERENTE, DA TESTARE |
| TR-15 | Fattori di debolezza | `weaknessFactors` esplicita i quattro fattori | `knowledgeStates.weaknessFactors` con valori null quando non disponibili | Motore calcola errori, consultazioni, ritardi; consolidamento fornito dal pianificatore | Vettori numerici e test `consolidationWeakness` | COERENTE STRUTTURALE, DA COMPLETARE |
| TR-16 | Decadimento ed esposizioni equivalenti | `equivalentExposures`, `effectiveExposureCount` | Presenti in `knowledgeStates` | Emivita 60 giorni | Test 0/60/120 giorni e storico immutato | COERENTE |
| TR-17 | Affidabilità individuale | `reliability` | Presente in `knowledgeStates` | Formula prudenziale con costante 5 | Vettori numerici | COERENTE |
| TR-18 | Calendario consolidamento | `reviewLevel`, `reviewIntervalDays`, `nextReviewAt`, policy version | Campi presenti in `profileSettings` e `knowledgeStates` | Policy calendario da confrontare con comportamento baseline | Test corretto/errato/consultato/non risposta | DELTA / BLOCCANTE (POLICY) |
| TR-19 | Priorità consultazione per sessione adattiva successiva della stessa tipologia | Record priorità tipizzato, con origine, tipologia, consumo e invalidazione | Store `consultationPriorities` ricostruibile | Selector/SessionManager applicano e consumano soltanto nella stessa tipologia adattiva | Test stessa tipologia, consumo, annullamento, rettifica | COERENTE, DA TESTARE |
| TR-20 | Quote categoria e disponibilità | `categoryQuotas`, pool per categoria | Elementi hanno `categoryId`; impostazioni per profilo | Selector normalizza categorie disponibili | Somma 100%, categorie vuote escluse | COERENTE |
| TR-21 | Quote adattive interne | Quote 30/40/20/10 | Derivabili da configurazione/versione algoritmo; non necessitano store autonomo se incluse nello snapshot | Selector strati neverVerified/weak/review/consolidated | Vettori selezione | COERENTE |
| TR-22 | Budget globale adattivo | `globalBudget: 0.10`, `individualCapRate: 0.20` | Parametri in `selectionSnapshot` / versione algoritmo | Decisione D77–D80 e Selector | Vettori budget/tetti/quota neutra | COERENTE |
| TR-23 | PRNG riproducibile | `xoshiro128**` v1.0, seed `hex-128be`, stato e contatori | Snapshot PRNG completo in `selectionSnapshot` v1.3 | Specifica PRNG v1.0; ordinamento UTF-16; rejection sampling; Fisher–Yates | 16 vettori verificati indipendentemente in Python e JavaScript; integrazione ancora da testare | COERENTE A LIVELLO SPECIFICA, DA IMPLEMENTARE |
| TR-24 | Esito atomico | `recordOutcome()` coordina evento, item, sessione, conoscenza, receipt | Transazione readwrite su `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `operationReceipts` | SessionManager + Knowledge | Abort senza scritture parziali; retry idempotente | COERENTE, DA TESTARE |
| TR-25 | Una sessione sospesa per profilo | `suspendSession` / `resumeSession` | Indice univoco `oneSuspendedPerProfile` su `suspendedProfileId` | SessionManager | Due schede sospendono simultaneamente | COERENTE, DA TESTARE |
| TR-26 | Più sessioni in corso | Non è stato approvato un limite globale alle sessioni `in-progress` | Nessun indice univoco su `profileId,status` per `in-progress` | SessionManager conserva la regola di una sola sospesa | Test senza introdurre vincolo non approvato | COERENTE |
| TR-27 | Idempotenza cross-domain | `operationId`, payload hash, receipt | `operationReceipts` PK `[scope,operationId]`; indici globali univoci sugli eventi/correzioni/audit | Repository | Stesso ID/stesso payload; stesso ID/payload diverso | COERENTE, VINCOLO UUID GLOBALE |
| TR-28 | Concorrenza ottimistica | `revision` / `expectedRevision` | `revision` su sessioni, item ed entità modificabili | SessionManager/Repository | Conflitto stale record | COERENTE |
| TR-29 | Isolamento profili | `profileId` in record personali | Chiavi composte e indici prefissati da `profileId` | Tutti i servizi | Test profili indipendenti/cancellazione isolata | COERENTE |
| TR-30 | Export/import e recupero | `exportProfile`, `importProfile` | Pacchetto versionato; marker LS/IDB | Repository + ProfileManager | Rollback, retry, interruzione browser | COERENTE, DA TESTARE |
| TR-31 | Dismissione e sostituzione semantica | `status`, `replacedBySemanticId` | `catalogElements.status` e contenuto | Catalogo; nessun trasferimento conoscenza | Catena A→B→C, sessione sospesa | COERENTE |
| TR-32 | UI separata dal dominio | UI chiama SessionManager, niente scritture dirette | Repository unico punto d'accesso | Piano integrazione Fase 6 | Test browser e regressione | DA TESTARE |

## 4. Disallineamenti che richiedono normalizzazione

### 4.1 Timestamp: ISO-8601 contro epoch millisecondi

- Contratti backend: esempi con stringhe ISO-8601.
- Schema IndexedDB: esempi numerici epoch in millisecondi.
- I calcoli di decadimento, intervalli, ordinamento e indici IndexedDB sono più lineari con un unico valore numerico.

**Raccomandazione:** usare epoch millisecondi UTC come rappresentazione canonica in tutti i record e contratti persistenti. Convertire in ISO-8601 soltanto per visualizzazione, log leggibili o pacchetti che lo richiedano esplicitamente. La scelta va recepita in una revisione coordinata dei documenti prima del codice.

### 4.2 Proiezione `knowledgeStates`: campi mancanti

Il motore di conoscenza definisce una proiezione più ricca dell'esempio fisico corrente. Lo schema deve rappresentare almeno:

- `questionType`;
- `calculationAt`;
- `sourceEventVersion`;
- `correctionProjectionVersion`;
- `knowledgeAlgorithmVersion`;
- `consolidationPolicyVersion`;
- `factorValues.errors`, `factorValues.consultations`, `factorValues.delays`, `factorValues.consolidation`;
- `correctedWeaknessIndex` oppure il nome canonico scelto;
- `reviewLevel` e `reviewIntervalDays`;
- stato esplicito per `insufficientData`.

I campi temporali della prima e ultima esposizione devono seguire la stessa convenzione epoch millisecondi. `null` deve significare dato non disponibile e non essere convertito in zero.

### 4.3 Enum di classificazione

Il motore usa codici macchina inglesi; l'esempio schema usa etichette italiane. Non salvare etichette di presentazione come codici persistenti.

**Raccomandazione canonica:** `neverVerified`, `weak`, `review`, `consolidated`, `insufficientData`. Le etichette italiane Debole, Da ripassare, Consolidato e Mai verificato restano responsabilità della UI. `insufficientData` è distinto da `neverVerified`.

### 4.4 Indice corretto/aggiustato

Il documento motore usa `correctedWeaknessIndex`, mentre contratti e schema usano `adjustedWeaknessIndex`.

**Raccomandazione canonica:** `adjustedWeaknessIndex` come nome persistente e pubblico, poiché è già condiviso da contratto e schema. Il nome interno della funzione matematica può essere `correctedWeaknessIndex`, ma non deve propagarsi nei record né nei payload tra componenti.

### 4.5 Template e candidate

Il catalogo JSON contiene `mainQuestionTemplates`, mentre lo schema fisico non ha uno store che li conservi. Il Selector riceve `candidates[]`, ma non è definito in modo univoco come vengono creati e versionati i candidate prima della selezione.

**Raccomandazione:** introdurre uno store versionato `questionTemplates`, con chiave composta `[templateSemanticId, contentVersion]` e indice per `[questionType, layoutId, status]`. Ogni template deve dichiarare gli aspetti/domande componenti e la regola di composizione. `InterrogationCatalog` deve esporre `getAvailableCandidates()` che materializza un candidate deterministico da template + definizioni attive + relazioni della stessa `catalogVersion`. `candidateId` deve essere stabile e derivato da identità/versioni dei componenti, non da UUID casuali. I candidate non selezionati possono restare viste derivate in memoria; lo snapshot selezionato viene persistito in `sessionItems`.

Questa proposta conserva separati template didattico e candidate effettivamente selezionato. Il catalogo delle 445 definizioni e i 5 template esistenti sono la fonte da validare; non si devono generare template mancanti per inferenza.

### 4.6 Priorità delle consultazioni

Il booleano `pendingConsultationPriority` non basta a rappresentare tutti i vincoli: tipologia della consultazione, evento origine, data, consumo soltanto quando incluso in sessione adattiva della stessa tipologia, persistenza in caso di sessione annullata e invalidazione in caso di correzione.

**Raccomandazione:** aggiungere uno store `consultationPriorities`, con record append/update derivato e ricostruibile dagli eventi e correzioni. Campi minimi: `profileId`, `priorityId`, `sourceEventId`, `questionSemanticId`, `questionType`, `createdAt`, `status` (`pending`/`consumed`/`invalidated`), `consumedBySessionId`, `revision`. La fonte storica resta l'evento immutabile; lo store è una proiezione operativa. Se si preferisce evitare un nuovo store, il modello alternativo deve essere formalizzato esplicitamente come array indicizzato/ricostruibile, non come singolo booleano.

### 4.7 PRNG e snapshot di selezione

Il contratto Selector richiede seed e `algorithmVersion`; il piano segnala correttamente che il PRNG non è ancora congelato. Lo schema può conservare i dati nello `selectionSnapshot`, ma deve elencare i campi obbligatori: algoritmo PRNG e versione, seed serializzato, versione algoritmo selettore, ordinamento canonico del pool, parametri quote, input knowledge snapshot o suo hash/versione e risultato selezione.

Non è sufficiente conservare soltanto un seed se l'implementazione del generatore può cambiare tra release.

## 5. Verifica specifica delle transazioni

| Operazione | Store richiesti secondo schema | Dipendenze motore | Controllo da eseguire |
|---|---|---|---|
| `createSession` | `sessions`, `sessionItems`, `operationReceipts`; lettura catalogo/configurazione/stati | Catalog, Selector, Knowledge snapshot, SessionManager | Snapshot completo scritto insieme; priorità consumate solo dopo creazione confermata; disponibilità insufficiente richiede conferma prima della transazione finale |
| `recordOutcome` | `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `operationReceipts` | SessionManager + Knowledge | Evento, item, score, proiezione e receipt atomici; aggiungere `consultationPriorities` quando la consultazione genera priorità |
| `consultSubQuestion` | stessi store di `recordOutcome` + `consultationPriorities` | SessionManager + Knowledge | Priorità stessa tipologia e non duplicata; outcome `consulted`, score +1 |
| `closeMainQuestion` | `sessions`, `sessionItems`, `operationReceipts` | SessionManager | Sotto-quesiti residui `unanswered`, nessun evento knowledge per non risposta |
| `suspendSession` | `sessions`, `operationReceipts` | SessionManager | Indice univoco `oneSuspendedPerProfile`; snapshot invariato |
| `resumeSession` | `sessions`, `operationReceipts` | SessionManager | Rimozione `suspendedProfileId`, revisione ottimistica |
| `abandonSession` | `sessions`, `operationReceipts` | SessionManager | Risultati già registrati conservati; conferma esplicita |
| `completeSession` | `sessions`, `operationReceipts` | SessionManager | Completezza e conferma esplicita |
| `applyCorrection` | `eventCorrections`, `knowledgeStates`, `operationReceipts`, lettura eventi; `consultationPriorities` se coinvolte | Knowledge + Repository | Sequenza append-only; proiezione e priorità coerenti nella stessa transazione |
| `publishCatalog` | `catalogVersions`, `catalogElements`, `catalogRelations`, `questionDefinitions`, `questionTemplates`, `catalogAudit`, `operationReceipts` | Catalog + Repository | Template, definizioni e relazioni validati nella stessa versione prima della pubblicazione |

**Nota:** la tabella è una verifica progettuale. La lista effettiva degli store deve essere congelata nello schema aggiornato prima di implementare le transazioni.

## 6. Matrice test → requisito

| Gruppo test | Requisiti coperti | Artefatto attuale | Stato reale |
|---|---|---|---|
| Quote adattive e selezione | TR-20, TR-21, TR-22, TR-23 | `Motore_Selezione_Interrogazione_test_vectors_v1.0.json`; decisione D77–D80 v1.1 | Vettori definiti; esecuzione su motore non ancora possibile |
| Conoscenza | TR-12, TR-13, TR-14, TR-15, TR-16, TR-17, TR-18, TR-19 | `Motore_Conoscenza_Interrogazione_test_vectors_v1.0.json` | Vettori definiti; schema non ancora completo |
| Sessione | TR-07, TR-08, TR-10, TR-24, TR-25, TR-26 | `Motore_Sessione_Interrogazione_test_vectors_v1.0.json` | Vettori definiti; esecuzione su motore non ancora possibile |
| Persistenza | TR-24, TR-25, TR-27, TR-28, TR-29, TR-30 | Sezione 13 di Schema IndexedDB v1.1 | Casi specificati; test browser IndexedDB da implementare/eseguire |
| Catalogo | TR-01, TR-02, TR-03, TR-04, TR-05, TR-31 | Cataloghi JSON v1.0 | Validazioni documentate; template/store non allineati |
| Regressione baseline | TR-30, TR-32 | Nove test Node della baseline e checklist browser | Nove suite Node già superate nel controllo precedente; checklist browser ancora da eseguire |

Non dichiarare “test superati” per i motori nuovi finché non esiste codice eseguibile e non sono stati lanciati i relativi test. I vettori sono specifiche di test.

## 7. Sequenza di chiusura raccomandata

1. **Allineare il modello fisico v1.2:** aggiungere `questionTemplates`, `consultationPriorities` e completare `knowledgeStates`; definire enum canonici e timestamp.
2. **Allineare i contratti v1.2:** adottare i nomi canonici e fissare le strutture di candidate, template, priorità e snapshot PRNG.
3. **Congelare i contratti del selettore:** PRNG/versione/seed, ordinamento pool e serializzazione deterministica.
4. **Chiudere le regole knowledge residue:** rapporto consultazione/errore e policy calendario, già segnalati nel piano d'integrazione.
5. **Validare catalogo/template:** ogni template deve risolversi in sotto-quesiti attivi, con risposte attese e relazioni coerenti; i 105 tasti non verificati restano esclusi.
6. **Generare test di contratto condivisi:** fixture JSON comuni a Catalog, Selector, Knowledge, SessionManager e Repository, evitando copie divergenti degli stessi valori.
7. **Solo dopo i gate precedenti:** iniziare l'implementazione repository-first secondo il Piano d'integrazione.

## 8. Decisioni tecniche proposte per l'allineamento

Le seguenti sono raccomandazioni tecniche della matrice, non modifiche già approvate alle specifiche funzionali:

| ID | Proposta | Motivazione |
|---|---|---|
| AL-01 | Epoch millisecondi UTC per tutti i timestamp persistenti | Coerenza con schema, indici e calcoli temporali |
| AL-02 | Enum macchina inglesi canonici; localizzazione solo UI | Evita dipendenza della persistenza dalla lingua |
| AL-03 | `adjustedWeaknessIndex` come campo canonico | Allinea motore di persistenza e contratto |
| AL-04 | Store versionato `questionTemplates` | Rappresenta i 5 template presenti nel catalogo JSON |
| AL-05 | `getAvailableCandidates()` come materializzazione pura versionata | Il selector richiede candidate prima della sessione senza persistere pool temporanei |
| AL-06 | Store/proiezione `consultationPriorities` | Rappresenta origine, tipologia, consumo e invalidazione |
| AL-07 | Completare `knowledgeStates` con fattori, versioni e livello review | Rende persistibile la proiezione richiesta dal motore |
| AL-08 | Snapshot selezione con PRNG/versioni/seed/pool canonicalizzato | Riproducibilità fra release |

## 9. Criteri di uscita della matrice

La matrice può essere dichiarata chiusa quando:

- ogni campo letto o scritto dai motori è definito nel contratto e nello schema;
- ogni enum ha un solo insieme di valori canonici;
- ogni timestamp ha un solo tipo e unità;
- template e candidate hanno identità, versione e regola di composizione verificabili;
- le priorità consultazione sono ricostruibili e consumabili senza violare tipologia e quote;
- ogni operazione transazionale elenca tutti gli store coinvolti;
- ogni requisito ha almeno un test collegato e ogni test ha un esito di esecuzione registrato;
- non restano delta BLOCCANTI aperti.

## 10. Esito finale

La verifica non ha rilevato una contraddizione nell'impianto a sei componenti né nella regola delle quote D77–D80 approvata. Ha però identificato quattro incompatibilità strutturali da chiudere prima del codice: **proiezione knowledge incompleta, template/candidate non persistiti o materializzati formalmente, priorità consultazione rappresentate in modo insufficiente, e normalizzazione di timestamp/enum/nomi campo**.

Il prossimo deliverable consigliato è **Schema IndexedDB Interrogazione v1.2**, che recepisca soltanto questi delta e mantenga la versione 1.1 come storico. Nessun sorgente applicativo è stato modificato durante questa verifica.


## 5. Revisione v1.1 — recepimento schema v1.3 e decisione PRNG

La presente revisione aggiorna la matrice rispetto a `Contratti_Backend_Interrogazione_v1.3.md`, `Schema_IndexedDB_Interrogazione_v1.3.md`, `Motore_Selezione_Interrogazione_v1.1.md` e `Specifica_PRNG_Interrogazione_v1.0.md`.

### 5.1 Esiti aggiornati

Il nome persistito dell'indice è `correctedWeaknessIndex`; la raccomandazione storica `adjustedWeaknessIndex` nella §4.4 della matrice v1.0 non è stata adottata.

- **Template e candidate:** la v1.2 dello schema ha introdotto `questionTemplates`; i candidate restano oggetti temporanei immutabili materializzati in memoria. Non è necessario uno store persistente dei candidate.
- **Knowledge state:** lo schema v1.2 esplicita fattori, indice corretto, affidabilità, classificazione, calendario, versioni e fingerprint. Resta da completare la policy del fattore consolidamento e da eseguire i vettori.
- **Priorità consultazioni:** `consultationPriorities` è uno store separato e ricostruibile. Restano da eseguire i test di consumo, rettifica e recovery.
- **PRNG:** la decisione algoritmica è chiusa a livello documentale. `xoshiro128**` v1.0, seed `hex-128be`, rejection sampling, ordinamento `utf16-code-unit-v1` e Fisher–Yates sono descritti in una specifica dedicata. I 16 vettori sono stati confrontati tra un riferimento Python e una seconda implementazione JavaScript. L'integrazione nel selettore non è ancora stata implementata.
- **Calendario:** i campi fisici sono presenti, ma la policy esecutiva deve essere verificata rispetto al comportamento della baseline e ai casi di confine.
- **Catalogo:** il seed resta parziale rispetto ai 105 tasti dichiarati. Le lacune e le tre incongruenze dei modificatori destri restano esplicitamente bloccanti per la copertura completa.

### 5.2 Distinzione tra verifica documentale e test applicativi

La verifica indipendente dei vettori PRNG dimostra la coerenza della specifica e dei valori attesi. Non dimostra che il codice applicativo sia stato implementato, né che IndexedDB, UI, recovery o concorrenza funzionino nel browser.

**Esito della revisione:** il gate documentale PRNG è chiuso; il gate implementativo PRNG resta aperto. I blocchi non correlati elencati nella matrice restano validi.
