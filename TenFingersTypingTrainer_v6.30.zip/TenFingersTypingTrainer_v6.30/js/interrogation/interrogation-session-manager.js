/* TenFingersTypingTrainer v6.25 | interrogation-session-manager.js | Orchestrazione sessioni Interrogazione conforme a Contratti Backend v1.4. */
(function (global) {
  "use strict";

  const SCORE_BY_OUTCOME = Object.freeze({
    correct: 3,
    consulted: 1,
    incorrect: 0,
    unanswered: 0,
  });

  function generateId(prefix) {
    if (
      typeof global.crypto !== "undefined" &&
      global.crypto &&
      typeof global.crypto.randomUUID === "function"
    ) {
      return `${prefix}_${global.crypto.randomUUID()}`;
    }
    return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  function normalizeTextAnswer(value) {
    return String(value === null || value === undefined ? "" : value).trim();
  }

  class InterrogationSessionManager {
    constructor(deps) {
      const d = deps || {};
      this.catalog = d.catalog || new global.InterrogationCatalog();
      this.repository = d.repository || new global.InterrogationRepository();
      this.knowledge = d.knowledge || global.InterrogationKnowledge;
      this.selector = d.selector || global.InterrogationSelector;
    }

    async createSession(input) {
      const profileId = String(input.profileId || "default");
      const mode = input.mode || "random";
      const questionTypes = Array.isArray(input.questionTypes) && input.questionTypes.length > 0
        ? input.questionTypes
        : input.questionType && input.questionType !== "MIXED"
          ? [input.questionType]
          : ["HOME_ROW", "TASTO", "CARATTERE", "DITO"];
      const requestedCount = Math.max(1, parseInt(input.requestedCount, 10) || 10);
      const operationId = input.operationId || generateId("op_create");

      const pool = this.catalog.getCandidates({ questionTypes });
      if (pool.length === 0) {
        throw new Error("Nessuna domanda disponibile per i criteri selezionati.");
      }

      const knowledgeRecords = await this.repository.getKnowledgeStates(profileId);
      const knowledgeMap = new Map(knowledgeRecords.map((r) => [r.questionSemanticId, r]));
      const pendingPriorities = await this.repository.getConsultationPriorities(profileId, "pending");
      const pendingQuestionIds = pendingPriorities.map((p) => p.questionSemanticId);

      const selResult = await this.selector.selectCandidates({
        mode,
        candidates: pool,
        requestedCount,
        seed: input.seed,
        manualCandidateIds: input.manualCandidateIds,
        allowDuplicates: !!input.allowDuplicates,
        knowledgeByQuestionId: knowledgeMap,
        pendingPriorityQuestionIds: pendingQuestionIds,
        baseSharesPercent: input.baseSharesPercent,
      });

      const now = Date.now();
      const sessionId = generateId("sess");
      const sessionRecord = {
        profileId,
        sessionId,
        status: "in-progress",
        mode,
        questionTypes: questionTypes.slice(),
        requestedCount,
        effectiveCount: selResult.effectiveCount,
        catalogVersion: this.catalog.catalogVersion,
        layoutId: this.catalog.layoutId,
        configSnapshot: {
          mode,
          questionTypes: questionTypes.slice(),
          requestedCount,
          effectiveCount: selResult.effectiveCount,
        },
        selectionSnapshot: selResult.selectionSnapshot,
        currentItemIndex: 0,
        score: 0,
        maxScore: selResult.selectedCandidates.reduce(
          (acc, c) => acc + (c.subQuestions ? c.subQuestions.length * 3 : 0),
          0,
        ),
        eventSequence: 0,
        revision: 1,
        createdAt: now,
        updatedAt: now,
        completedAt: null,
      };

      const items = selResult.selectedCandidates.map((cand, idx) => ({
        profileId,
        sessionId,
        itemId: `${sessionId}_item_${idx}`,
        order: idx,
        candidateId: cand.candidateId,
        templateSemanticId: cand.templateSemanticId,
        templateContentVersion: cand.templateContentVersion,
        questionType: cand.questionType,
        categoryId: cand.categoryId,
        mainElementSemanticId: cand.mainElementSemanticId,
        keyId: cand.keyId,
        character: cand.character,
        modifierMode: cand.modifierMode,
        fingerId: cand.fingerId,
        handId: cand.handId,
        status: "pending",
        score: 0,
        subQuestions: (cand.subQuestions || []).map((def, sqIdx) => ({
          subQuestionId: `${sessionId}_item_${idx}_sq_${sqIdx}`,
          questionSemanticId: def.questionSemanticId,
          contentVersion: def.contentVersion,
          aspectId: def.aspectId,
          answerType: def.answerType,
          answerDefinition: JSON.parse(JSON.stringify(def.answerDefinition || {})),
          presentationType: def.presentationType,
          evaluationPolicy: def.evaluationPolicy,
          status: "pending",
          outcome: null,
          userAnswer: null,
          score: 0,
          evaluatedAt: null,
          exposureEventId: null,
        })),
      }));

      await this.repository.saveSessionAtomic(sessionRecord, items, operationId, []);

      return {
        session: sessionRecord,
        items,
        reducedAvailability: selResult.effectiveCount < requestedCount,
      };
    }

    evaluateAnswerAgainstDefinition(subQuestion, rawUserAnswer) {
      const def = subQuestion.answerDefinition || {};
      const type = subQuestion.answerType;

      if (type === "PHYSICAL_KEY_ID") {
        const expectedKey = String(def.acceptedKeyId || "");
        const given = normalizeTextAnswer(rawUserAnswer);
        if (given === expectedKey) return true;
        if (Array.isArray(def.acceptedLabels)) {
          return def.acceptedLabels.some(
            (lbl) => String(lbl).toLowerCase() === given.toLowerCase(),
          );
        }
        return false;
      }

      if (type === "FINGER_ID") {
        return normalizeTextAnswer(rawUserAnswer) === String(def.acceptedFingerId || "");
      }

      if (type === "HAND_ID") {
        return normalizeTextAnswer(rawUserAnswer) === String(def.acceptedHandId || "");
      }

      if (type === "HOME_ROW_STATUS") {
        const expected = !!def.isHomeRow;
        const given = rawUserAnswer === true || String(rawUserAnswer).toLowerCase() === "true";
        return given === expected;
      }

      if (type === "MODIFIER_MODE") {
        if (
          rawUserAnswer &&
          typeof rawUserAnswer === "object" &&
          global.InterrogationLayoutMetadata &&
          typeof global.InterrogationLayoutMetadata.isModifierMatch === "function"
        ) {
          return global.InterrogationLayoutMetadata.isModifierMatch(
            def.acceptedModifierMode || "none",
            rawUserAnswer,
          );
        }
        return normalizeTextAnswer(rawUserAnswer) === String(def.acceptedModifierMode || "");
      }

      if (type === "CHARACTER_VALUE") {
        return String(rawUserAnswer) === String(def.acceptedCharacter || "");
      }

      return false;
    }

    async recordSubQuestionOutcome(input) {
      const profileId = String(input.profileId);
      const sessionId = String(input.sessionId);
      const itemId = String(input.itemId);
      const subQuestionId = String(input.subQuestionId);
      const mode = input.action || "answer"; // "answer" | "consult"
      const operationId = input.operationId || generateId("op_outcome");

      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "in-progress") {
        throw new Error("Sessione non attiva o non trovata.");
      }

      const items = await this.repository.getSessionItems(profileId, sessionId);
      const item = items.find((it) => it.itemId === itemId);
      if (!item) throw new Error("Domanda principale non trovata.");

      const sq = item.subQuestions.find((s) => s.subQuestionId === subQuestionId);
      if (!sq) throw new Error("Sotto-quesito non trovato.");
      if (sq.status !== "pending") {
        throw new Error("Sotto-quesito già valutato (immutabile).");
      }

      const now = Date.now();
      let outcome;
      let status;
      if (mode === "consult") {
        outcome = "consulted";
        status = "consulted";
      } else {
        const isCorrect = this.evaluateAnswerAgainstDefinition(sq, input.userAnswer);
        outcome = isCorrect ? "correct" : "incorrect";
        status = "answered";
      }

      const points = SCORE_BY_OUTCOME[outcome];
      const eventId = generateId("evt");
      const nextSeq = (session.eventSequence || 0) + 1;

      sq.status = status;
      sq.outcome = outcome;
      sq.userAnswer = mode === "consult" ? null : input.userAnswer;
      sq.score = points;
      sq.evaluatedAt = now;
      sq.exposureEventId = eventId;

      item.score = item.subQuestions.reduce((acc, s) => acc + (s.score || 0), 0);
      const allHandled = item.subQuestions.every((s) => s.status !== "pending");
      if (allHandled) {
        item.status = "completed";
      }

      session.score = items.reduce((acc, it) => acc + (it.score || 0), 0);
      session.eventSequence = nextSeq;
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = now;

      const exposureEvent = {
        profileId,
        eventId,
        sessionId,
        itemId,
        subQuestionId,
        questionSemanticId: sq.questionSemanticId,
        questionType: item.questionType,
        outcome,
        occurredAt: now,
        eventSequence: nextSeq,
        operationId,
      };

      const prevEvents = await this.repository.getExposureEvents(profileId);
      const prevCorrections = await this.repository.getEventCorrections(profileId);
      const projected = this.knowledge.projectQuestionState(
        sq.questionSemanticId,
        prevEvents.concat([exposureEvent]),
        prevCorrections,
        now,
      );

      const knowledgeState = Object.assign({ profileId, updatedAt: now }, projected);

      let consultationPriority = null;
      if (outcome === "consulted") {
        consultationPriority = {
          profileId,
          priorityId: generateId("prio"),
          sourceEventId: eventId,
          questionSemanticId: sq.questionSemanticId,
          questionType: item.questionType,
          status: "pending",
          createdAt: now,
          consumedBySessionId: null,
        };
      }

      await this.repository.saveOutcomeAtomic({
        sessionRecord: session,
        sessionItem: item,
        exposureEvent,
        knowledgeState,
        consultationPriority,
        operationId,
      });

      return {
        outcome,
        status,
        score: points,
        sessionScore: session.score,
        itemCompleted: allHandled,
        knowledgeState,
      };
    }

    async recordBlockEvaluation(input) {
      const profileId = String(input.profileId);
      const sessionId = String(input.sessionId);
      const itemId = String(input.itemId);
      const blockId = String(input.blockId || "block");
      const outcome = input.outcome === "correct"
        ? "correct"
        : input.outcome === "consulted"
          ? "consulted"
          : "incorrect";
      const operationId = input.operationId || generateId("op_block");

      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "in-progress") {
        throw new Error("Sessione non attiva o non trovata.");
      }

      const items = await this.repository.getSessionItems(profileId, sessionId);
      const item = items.find((it) => it.itemId === itemId);
      if (!item) throw new Error("Domanda principale non trovata.");

      if (!item.blockEvaluations || typeof item.blockEvaluations !== "object") {
        item.blockEvaluations = {};
      }
      if (item.blockEvaluations[blockId]) {
        return {
          outcome: item.blockEvaluations[blockId].outcome,
          score: item.blockEvaluations[blockId].score,
          sessionScore: session.score,
          alreadyEvaluated: true,
        };
      }

      const points = SCORE_BY_OUTCOME[outcome];
      const now = Date.now();
      const eventId = generateId("evt_blk");
      const nextSeq = (session.eventSequence || 0) + 1;

      item.blockEvaluations[blockId] = {
        blockId,
        outcome,
        score: points,
        evaluatedAt: now,
        userAnswer: input.userAnswer !== undefined ? input.userAnswer : null,
      };

      const subScore = (item.subQuestions || []).reduce((acc, s) => acc + (s.score || 0), 0);
      const blkScore = Object.values(item.blockEvaluations).reduce((acc, b) => acc + (b.score || 0), 0);
      item.score = subScore + blkScore;

      session.score = items.reduce((acc, it) => acc + (it.score || 0), 0);
      session.eventSequence = nextSeq;
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = now;

      await this.repository.saveOutcomeAtomic({
        sessionRecord: session,
        sessionItem: item,
        exposureEvent: {
          profileId,
          eventId,
          sessionId,
          itemId,
          subQuestionId: `${itemId}_${blockId}`,
          questionSemanticId: `${item.candidateId}.${blockId}`,
          questionType: item.questionType,
          outcome,
          occurredAt: now,
          eventSequence: nextSeq,
          operationId,
        },
        knowledgeState: null,
        consultationPriority: null,
        operationId,
      });

      return {
        outcome,
        score: points,
        sessionScore: session.score,
        alreadyEvaluated: false,
      };
    }

    async finishMainQuestion(input) {
      const profileId = String(input.profileId);
      const sessionId = String(input.sessionId);
      const itemId = String(input.itemId);
      const operationId = input.operationId || generateId("op_finish_item");

      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "in-progress") {
        throw new Error("Sessione non attiva.");
      }

      const items = await this.repository.getSessionItems(profileId, sessionId);
      const item = items.find((it) => it.itemId === itemId);
      if (!item) throw new Error("Domanda principale non trovata.");

      const now = Date.now();
      for (let i = 0; i < item.subQuestions.length; i++) {
        if (item.subQuestions[i].status === "pending") {
          item.subQuestions[i].status = "unanswered";
          item.subQuestions[i].outcome = null;
          item.subQuestions[i].score = 0;
        }
      }
      item.status = "completed";
      session.currentItemIndex = Math.min(items.length - 1, (session.currentItemIndex || 0) + 1);
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = now;

      await this.repository.saveOutcomeAtomic({
        sessionRecord: session,
        sessionItem: item,
        exposureEvent: null,
        knowledgeState: null,
        consultationPriority: null,
        operationId,
      });

      return { session, item };
    }

    async suspendSession(profileId, sessionId, operationId) {
      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "in-progress") {
        throw new Error("Solo una sessione in-progress può essere sospesa.");
      }
      const existingSuspended = await this.repository.getSuspendedSession(profileId);
      if (existingSuspended && existingSuspended.sessionId !== sessionId) {
        throw new Error("Esiste già una sessione sospesa per questo profilo.");
      }
      session.status = "suspended";
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = Date.now();
      await this.repository.saveSessionAtomic(
        session,
        [],
        operationId || generateId("op_suspend"),
        [],
      );
      return session;
    }

    async resumeSession(profileId, sessionId, operationId) {
      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "suspended") {
        throw new Error("Sessione sospesa non trovata.");
      }
      session.status = "in-progress";
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = Date.now();
      await this.repository.saveSessionAtomic(
        session,
        [],
        operationId || generateId("op_resume"),
        [],
      );
      const items = await this.repository.getSessionItems(profileId, sessionId);
      return { session, items };
    }

    async abandonSession(profileId, sessionId, operationId) {
      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || (session.status !== "in-progress" && session.status !== "suspended")) {
        throw new Error("Impossibile abbandonare la sessione nello stato attuale.");
      }
      session.status = "abandoned";
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = Date.now();
      session.completedAt = Date.now();
      await this.repository.saveSessionAtomic(
        session,
        [],
        operationId || generateId("op_abandon"),
        [],
      );
      return session;
    }

    async completeSession(profileId, sessionId, operationId) {
      const session = await this.repository.getSession(profileId, sessionId);
      if (!session || session.status !== "in-progress") {
        throw new Error("Solo una sessione in-progress può essere completata.");
      }
      const items = await this.repository.getSessionItems(profileId, sessionId);
      const now = Date.now();
      for (let i = 0; i < items.length; i++) {
        for (let j = 0; j < items[i].subQuestions.length; j++) {
          if (items[i].subQuestions[j].status === "pending") {
            items[i].subQuestions[j].status = "unanswered";
            items[i].subQuestions[j].score = 0;
          }
        }
        items[i].status = "completed";
      }
      session.status = "completed";
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = now;
      session.completedAt = now;
      await this.repository.saveSessionAtomic(
        session,
        items,
        operationId || generateId("op_complete"),
        [],
      );
      return { session, items };
    }

    async getProfileProgress(profileId) {
      const states = await this.repository.getKnowledgeStates(profileId);
      const sessions = await this.repository.getSessionsByProfile(profileId);
      const summary = {
        totalDefinitions: this.catalog.definitionsBySemanticId.size,
        neverVerified: 0,
        weak: 0,
        review: 0,
        consolidated: 0,
        insufficientData: 0,
        dueNow: 0,
        sessionsCount: sessions.length,
        recentSessions: sessions.slice(0, 10),
      };
      const now = Date.now();
      const seenIds = new Set();
      for (let i = 0; i < states.length; i++) {
        const st = states[i];
        seenIds.add(st.questionSemanticId);
        if (summary[st.classification] !== undefined) {
          summary[st.classification] += 1;
        }
        if (st.nextReviewAt && st.nextReviewAt <= now) {
          summary.dueNow += 1;
        }
      }
      summary.neverVerified += Math.max(0, summary.totalDefinitions - seenIds.size);
      return summary;
    }

    // --- Metodi v6.27: Valutazione grafica per Carattere/Tasto, Dito e Posizione di Riposo ---
    evaluateModifierCheckboxes(expectedMod, selectedFlags) {
      const f = selectedFlags || {};
      const ctrl = !!f.ctrl;
      const shift = !!f.shift;
      const alt = !!f.alt;
      const altgr = !!f.altgr;
      const mod = String(expectedMod || "none");

      if (mod === "none") {
        return !ctrl && !shift && !alt && !altgr;
      }
      if (mod === "shiftL" || mod === "shiftR" || mod === "shift") {
        return shift && !ctrl && !alt && !altgr;
      }
      if (mod === "altgr") {
        return (!shift && altgr && !ctrl && !alt) || (!shift && ctrl && alt && !altgr);
      }
      if (mod === "shiftAltgr") {
        return (shift && altgr && !ctrl && !alt) || (shift && ctrl && alt && !altgr);
      }
      return false;
    }

    evaluateChordDescription(keyId, expectedMod, userChord) {
      const meta = this.catalog.getKeyLayoutMeta(keyId);
      if (!meta) return { ok: false, details: {} };
      const u = userChord || {};
      const handOk = String(u.hand || "") === String(meta.hand);
      const fingerOk = Number(u.finger) === Number(meta.finger);
      const dirOk = String(u.lateralDir || "none") === String(meta.lateralDir || "none");
      const latOk = Number(u.lateralExt || 0) === Number(meta.lateralExt || 0);
      const longOk = Number(u.longitudinalExt) === Number(meta.longitudinalExt);
      const modOk = this.evaluateModifierCheckboxes(expectedMod, u.modifiers);
      return {
        ok: handOk && fingerOk && dirOk && latOk && longOk && modOk,
        details: { handOk, fingerOk, dirOk, latOk, longOk, modOk },
        expected: {
          hand: meta.hand,
          finger: meta.finger,
          lateralDir: meta.lateralDir,
          lateralExt: meta.lateralExt,
          longitudinalExt: meta.longitudinalExt,
          modifierMode: expectedMod || "none",
        },
      };
    }

    evaluateKeySlots(keyId, userSlots) {
      const meta = this.catalog.getKeyLayoutMeta(keyId);
      if (!meta || !meta.slots) return { ok: false, expected: {} };
      const expected = {
        normal: meta.slots.normal || "NONE",
        shift: meta.slots.shift || "NONE",
        altgr: meta.slots.altgr || "NONE",
        shiftAltgr: meta.slots.shiftAltgr || "NONE",
      };
      const u = userSlots || {};
      const results = {};
      let allOk = true;
      ["normal", "shift", "altgr", "shiftAltgr"].forEach((slot) => {
        const expVal = expected[slot];
        const usrVal = u[slot] !== undefined && u[slot] !== null ? String(u[slot]) : "";
        const slotOk = usrVal === expVal;
        results[slot] = slotOk;
        if (!slotOk) allOk = false;
      });
      return { ok: allOk, results, expected };
    }

    evaluateKeyNeighbors(keyId, userNeighbors) {
      const neigh = this.catalog.getNeighborsForKey(keyId);
      if (!neigh) return { ok: false, expected: {} };
      const u = userNeighbors || {};
      const expected = neigh.tokens;
      const results = {};
      let allOk = true;
      ["topLeft", "topRight", "left", "right", "bottomLeft", "bottomRight"].forEach((dir) => {
        const expTok = expected[dir];
        const expKeyId = neigh[dir] || "NONE";
        const usrVal = String(u[dir] || "").trim();
        const dirOk = usrVal === expTok || (expKeyId !== "NONE" && usrVal === expKeyId);
        results[dir] = dirOk;
        if (!dirOk) allOk = false;
      });
      return { ok: allOk, results, expected, neighborKeyIds: neigh };
    }

    evaluateFingerSelection(fingerId, filter, mode, userTokens) {
      const keys = this.catalog.getKeysForFinger(fingerId, filter);
      const expectedSet = new Set();
      keys.forEach((k) => {
        if (mode === "tutti_i_singoli_caratteri") {
          ["normal", "shift", "altgr", "shiftAltgr"].forEach((s) => {
            if (k.slots && k.slots[s]) expectedSet.add(k.slots[s]);
          });
        } else {
          expectedSet.add(k.displayLabel);
        }
      });
      const userSet = new Set((userTokens || []).map((t) => String(t)));
      const ok =
        expectedSet.size === userSet.size &&
        Array.from(expectedSet).every((t) => userSet.has(t));
      return {
        ok,
        expectedTokens: Array.from(expectedSet),
        expectedKeyIds: keys.map((k) => k.keyId),
      };
    }

    evaluateHomeRowSelection(side, userEntries) {
      const targets = this.catalog.getHomeRowTargets(side);
      const entries = Array.isArray(userEntries) ? userEntries : [];
      if (targets.length === 0) return { ok: false, expected: [] };
      let allOk = entries.length === targets.length;
      const perKey = {};
      targets.forEach((t) => {
        const found = entries.find((e) => e.keyId === t.keyId);
        const charOk = found && String(found.char || "").toLowerCase() === t.char.toLowerCase();
        const fingerOk = found && Number(found.finger) === t.finger;
        perKey[t.keyId] = !!(charOk && fingerOk);
        if (!perKey[t.keyId]) allOk = false;
      });
      return { ok: allOk, perKey, expected: targets };
    }

    async addVisualBlockScore(profileId, sessionId, outcome, maxPoints) {
      const pts = SCORE_BY_OUTCOME[outcome] !== undefined ? SCORE_BY_OUTCOME[outcome] : 0;
      const session = await this.repository.getSession(profileId, sessionId);
      if (!session) return { score: pts, sessionScore: pts };
      session.score = (session.score || 0) + pts;
      if (maxPoints) {
        session.maxScore = (session.maxScore || 0) + maxPoints;
      }
      session.revision = (session.revision || 1) + 1;
      session.updatedAt = Date.now();
      await this.repository.saveSessionAtomic(
        session,
        [],
        generateId("op_vis_score"),
        [],
      );
      return { score: pts, sessionScore: session.score, maxScore: session.maxScore };
    }
  }

  global.InterrogationSessionManager = InterrogationSessionManager;
})(typeof window !== "undefined" ? window : globalThis);
