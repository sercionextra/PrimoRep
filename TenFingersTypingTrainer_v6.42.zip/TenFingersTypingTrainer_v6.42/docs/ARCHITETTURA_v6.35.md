# Architettura & Note Tecniche — Release v6.35

## 1. Tastiera B/N completamente anonima (`interrogation-svg-renderer.js`, `app.css`)
- **`assets/styles/app.css`**: aggiunta regola `.interr-keyboard-bn .key .base-dot, .interr-keyboard-bn .key .key-bump { display: none; }` per nascondere i punti azzurri sui tasti `[a, s, d, f, j, k, l, ò]` e i trattini in rilievo su `f` e `j`.
- **`js/ui/interrogation-svg-renderer.js`**: in `_mountKeyboard(container)` vengono rimossi i nodi `.base-dot` e `.key-bump` dal clone SVG; in `resetKeyboard()` vengono rimosse anche le classi `interr-key-row-0..3`.

## 2. Evidenziazione scopo domanda (`interrogation-ui.js`, `app.css`)
- **`js/ui/interrogation-ui.js`**: in `_renderRunView()` il titolo `#interrogationQuestionTitle` viene costruito in modo sicuro tramite DOM (`replaceChildren` + `createEl("span", "", ...)` con `id="target"`, senza `innerHTML`) per tutte le tipologie (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`).
- **`assets/styles/app.css`**: aggiunte le regole `#interrogationQuestionTitle` (`color: yellow; font-size: x-large;`) e `#target` (`background-color: yellow; font-size: x-large; color: black; padding: 0.05em 0.2em;`).

## 3. Posizione di Riposo (`HOME_ROW`) — Ordine controlli, colori riga e rimozione indizio
- **`js/ui/interrogation-ui.js`**: in `_renderHomeRowQuestionPanel()`:
  - Spostato il pulsante `Seleziona tasto #x su tastiera` dopo `Carattere...` e `Dito...`.
  - Assegnata la classe `interr-homerow-pick-${ent.idx}` al pulsante e la corrispondente classe `interr-key-row-${activeRowIdx}` al tasto cliccato sulla tastiera B/N, rimuovendo l'evidenziazione precedente della stessa riga in caso di riselezione e ripulendo le classi riga alla conferma/consulta.
  - Testo del pulsante dopo selezione impostato a `Tasto #${ent.idx + 1} selezionato` (senza esporre il nome del tasto tra parentesi).
- **`assets/styles/app.css`**: definite le classi `.interr-homerow-pick-0..3` e `.interr-keyboard-bn .key.interr-key-row-0..3 .key-bg`.

## 4. Finestra "Seleziona carattere / tasto" (`#interrAsciiPopover`) e selezione sequenziale Coppie
- **`index.html`**: aggiunto `id="interrAsciiPopoverTitle"` sullo `<span>` del titolo in `.interr-ascii-popover-header`.
- **`js/ui/interrogation-ui.js`**:
  - In `_openAsciiPopover(anchorEl, options, onSelect)`: riorganizzati i caratteri nelle 7 righe per tipologia e i tasti speciali nelle 2 righe richieste, con pulsante `NESSUNO` (valore logico `"NONE"` per compatibilità backend) sia in alto che in basso, titolo contestuale (`opts.title`) e messaggio guida opzionale (`opts.hint`), più supporto `opts.keepOpen` con `ctx.updateHeader(...)`.
  - In `_renderCharacterQuestionPanel()` (Margherita): per `Coppia sopra` e `Coppia sotto` è presente un unico pulsante `Scegli...` che apre il selettore in modalità sequenziale a 2 passi (1° tasto a sinistra → 2° tasto a destra) prima di chiudersi.
