# Mission: Risolvere il Cubo di Rubik (3x3)

## Why
Imparare a risolvere in piena autonomia un cubo di Rubik 3x3 partendo da qualsiasi configurazione scombinata, padroneggiando la logica spaziale e la memoria procedurale del metodo a strati (Layer by Layer).

## Success looks like
- Riconoscere l'anatomia del cubo: centri fissi, spigoli a due facce e angoli a tre facce.
- Comprendere ed eseguire con naturalezza la notazione standard delle mosse (R, U, L, F, D e i loro inversi).
- Completare in autonomia le tappe del metodo per principianti:
  1. La Margherita / Croce bianca allineata con i centri laterali
  2. Il primo strato (angoli bianchi al posto giusto)
  3. Il secondo strato (inserimento degli spigoli intermedi)
  4. La croce gialla superiore
  5. Allineamento e orientamento degli angoli dell'ultimo strato
- Risolvere interamente un cubo scombinato su simulatore virtuale (o fisico) senza consultare appunti.

## Constraints
- Sessione intensiva di circa 1 ora disponibile adesso.
- Nessun cubo fisico a portata di mano: pratica immediata su simulatore 3D online interattivo.
- Partenza da zero assoluto: nessuna conoscenza pregressa di terminologia o algoritmi.

## Out of scope
- Metodi avanzati di speedcubing (CFOP completo con 57 OLL / 21 PLL, metodo Roux, ZZ).
- Tecniche avanzate di finger tricks per velocità estrema (sub-20 secondi).
- Puzzle cubici o non cubici diversi dal 3x3x3 standard.
