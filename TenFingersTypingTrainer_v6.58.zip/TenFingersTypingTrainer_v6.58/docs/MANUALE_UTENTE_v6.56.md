# Manuale Utente TenFingersTypingTrainer v6.56

Questa guida integra il manuale della versione 6.55 con gli aggiornamenti introdotti nella versione 6.56.

## 1. Riquadri per le posizioni a riposo sulla Tastiera Virtuale
- **Due riquadri dedicati alle mani:** sulla Tastiera Virtuale, i tasti di riposo sono ora racchiusi da due riquadri a bordi arrotondati: il riquadro di sinistra evidenzia i tasti della mano sinistra (`a, s, d, f`), mentre quello di destra evidenzia i tasti della mano destra (`j, k, l, ò`).
- **Trattini tattili mantenuti:** restano visibili i due trattini orizzontali di riferimento sui tasti `f` e `j`, mentre i precedenti pallini azzurri sui singoli tasti di riposo sono stati rimossi per una lettura più chiara e immediata.
- **Adattamento ai temi:** il colore dei due riquadri si adatta automaticamente al tema grafico scelto (`Dark`, `Light`, `Matrix`, `Retro 2003`).
- **Modalità Interrogazione:** durante le sessioni di Interrogazione i due riquadri vengono nascosti automaticamente per non fornire suggerimenti visivi sulle risposte.
