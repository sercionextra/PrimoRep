# Manuale Utente TenFingersTypingTrainer v6.54

Questa guida integra il manuale della versione 6.53 con gli aggiornamenti introdotti nella versione 6.54.

## 1. Evidenziazione più discreta dai filtri del grafico velocità
- Passando il cursore del mouse su uno dei filtri di **"Filtra sessioni:"**, i campioni corrispondenti sul grafico vengono evidenziati con un ingrandimento più discreto (raggio 5 pixel anziché 8 pixel) e senza bordino bianco, mantenendo attenuati tutti gli altri campioni.
