# TenFingersTypingTrainer v6.30

Applicazione web stand-alone per l'allenamento alla digitazione a 10 dita su tastiera italiana QWERTY, dotata di dettatura vocale adattiva e modalità di Interrogazione grafica sul layout della tastiera.

## Novità principali v6.30

- **Mostra storico Interrogazioni:** pulsante **📈 Mostra storico** accanto ad Avvia Interrogazione con grafico interattivo, puntatore a croce (linea rossa orizzontale con valore in ordinata, linea verde verticale con data-ora del campione più prossimo), selezione dei campioni cliccabili, filtro per intervallo data/ora ed eliminazione dei campioni selezionati o esclusi.
- **Interrogazione per Carattere:** rimozione delle parentesi errate `{ [ ] }` dai tasti `7`, `8`, `9`, `0`, compattazione verticale della finestra, palette ASCII posizionata vicino all'elemento cliccato, click diretto su puntini delle mani ed estensioni laterali funzionante, dropdown inizialmente vuoti, doppio supporto per `INVIO` (`0` o `+1`) e sinistra di `INVIO` (`+` e `ù`).
- **Interrogazione per Dito:** nessun suggerimento visivo iniziale sui tasti, rimozione dei filtri Estensione/Direzione, click sui tasti in giallo con abbinamento immediato del carattere dalla palette ASCII e verifica completa tasto-carattere alla conferma (verdi i corretti, gialli persistenti gli errati/fuori posto).
- **Protezione di rete applicativa mantenuta:** CSP restrittiva (`connect-src 'none'`) e `network-isolation-guard.js` continuano a bloccare qualsiasi richiesta di rete diretta dal codice applicativo.

## Verifiche automatiche

Dalla directory del progetto eseguire:

```bash
for f in tests/*.js; do echo "=== $f ==="; node "$f"; done
```
