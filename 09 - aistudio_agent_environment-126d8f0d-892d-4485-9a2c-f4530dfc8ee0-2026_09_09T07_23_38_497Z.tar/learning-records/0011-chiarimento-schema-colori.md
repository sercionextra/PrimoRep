# Chiarimento schema colori e orientamento spaziale dei centri

L'utente ha corretto con precisione l'orientamento relativo dei centri laterali:
Con BIANCO sotto e GIALLO sopra:
- Fronte: ROSSO
- Destra: VERDE
- Retro: ARANCIONE
- Sinistra: BLU
(Disposizione circolare oraria vista dall'alto: Rosso -> Blu -> Arancione -> Verde).
L'assistente deve allinearsi rigorosamente a questa convenzione per tutte le indicazioni di movimento.
