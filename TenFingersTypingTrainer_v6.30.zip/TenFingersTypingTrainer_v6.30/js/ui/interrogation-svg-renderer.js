/* TenFingersTypingTrainer v6.29 | interrogation-svg-renderer.js | Rendering SVG isolato (prefisso interr_) per Tastiera B/N anonima e Mani cliccabili con sagome complete delle dita. */
(function (global) {
  "use strict";

  const SVG_NS = "http://www.w3.org/2000/svg";

  // Tracciati anatomici completi per le 5 dita della mano sinistra (viewBox 1408x768)
  const FULL_FINGER_PATHS_LEFT = {
    1: "M 285 430 C 235 390 190 345 188 326 C 187 315 201 309 216 315 C 236 323 280 368 328 398 C 335 403 310 432 285 430 Z",
    2: "M 342 394 C 314 335 282 252 262 204 C 256 188 267 174 282 175 C 296 177 308 198 336 258 C 358 302 380 338 390 346 C 392 355 362 396 342 394 Z",
    3: "M 397 355 C 395 320 377 205 365 140 C 362 121 372 108 387 108 C 402 108 411 124 421 170 C 433 222 444 275 454 328 C 455 336 404 360 397 355 Z",
    4: "M 467 332 C 473 305 483 222 486 172 C 487 132 496 118 511 118 C 527 118 536 135 537 182 C 538 232 537 288 536 346 C 536 355 466 340 467 332 Z",
    5: "M 565 422 C 584 415 604 378 618 344 C 634 306 663 292 685 301 C 695 307 694 318 682 341 C 668 369 652 406 638 446 C 632 454 574 436 565 422 Z",
  };

  function mirrorPathX(d, center = 1408) {
    return d.replace(/([0-9]+(?:\.[0-9]+)?)\s+([0-9]+(?:\.[0-9]+)?)/g, (_, x, y) => {
      const mx = Math.round((center - parseFloat(x)) * 10) / 10;
      return `${mx} ${y}`;
    });
  }

  const FULL_FINGER_PATHS = {
    1: FULL_FINGER_PATHS_LEFT[1],
    2: FULL_FINGER_PATHS_LEFT[2],
    3: FULL_FINGER_PATHS_LEFT[3],
    4: FULL_FINGER_PATHS_LEFT[4],
    5: FULL_FINGER_PATHS_LEFT[5],
    6: mirrorPathX(FULL_FINGER_PATHS_LEFT[5]),
    7: mirrorPathX(FULL_FINGER_PATHS_LEFT[4]),
    8: mirrorPathX(FULL_FINGER_PATHS_LEFT[3]),
    9: mirrorPathX(FULL_FINGER_PATHS_LEFT[2]),
    10: mirrorPathX(FULL_FINGER_PATHS_LEFT[1]),
  };

  class InterrogationSvgRenderer {
    constructor(callbacks = {}) {
      this.onKeyClick = callbacks.onKeyClick || null;
      this.onFingerClick = callbacks.onFingerClick || null;
      this.onLandmarkClick = callbacks.onLandmarkClick || null;
      this.keyboardSvg = null;
      this.handsSvg = null;
      this._resizeHandler = null;
    }

    mount(keyboardContainer, handsContainer) {
      this._mountKeyboard(keyboardContainer);
      this._mountHands(handsContainer);
    }

    _prefixIds(root, prefix) {
      if (root.id) {
        root.setAttribute("data-orig-id", root.id);
        root.id = prefix + root.id;
      }
      root.querySelectorAll("[id]").forEach((el) => {
        el.setAttribute("data-orig-id", el.id);
        el.id = prefix + el.id;
      });
    }

    _mountKeyboard(container) {
      if (!container) return;
      const source = document.getElementById("keyboardSvg");
      if (!source) return;
      container.innerHTML = "";

      const clone = source.cloneNode(true);
      this._prefixIds(clone, "interr_");
      clone.classList.add("interr-keyboard-bn");
      clone.removeAttribute("width");
      clone.removeAttribute("height");

      clone.querySelectorAll(".key text").forEach((txt) => {
        txt.classList.add("interr-key-label-hidden");
      });

      clone.querySelectorAll(".key").forEach((keyEl) => {
        // Rimuove eventuali stati live dell'esercizio di digitazione sottostante
        keyEl.classList.remove("active-target", "error-target", "pressed", "caps-active");
        keyEl.classList.add("interr-clickable-key");
        const origId = keyEl.getAttribute("data-orig-id");
        keyEl.addEventListener("click", (e) => {
          e.stopPropagation();
          if (typeof this.onKeyClick === "function" && origId) {
            this.onKeyClick(origId, keyEl);
          }
        });
      });

      container.appendChild(clone);
      this.keyboardSvg = clone;
    }

    _mountHands(container) {
      if (!container) return;
      const source = document.getElementById("handsSvg");
      if (!source) return;
      container.innerHTML = "";

      const clone = source.cloneNode(true);
      this._prefixIds(clone, "interr_");
      clone.classList.add("interr-hands-svg");
      clone.removeAttribute("width");
      clone.removeAttribute("height");

      // Rimuove contatore errori e gruppi di pallini nativi per evitare doppioni appiccicati
      clone.querySelector("#interr_handsErrorCountText")?.remove();
      clone.querySelector("#interr_dotsLeftGroup")?.remove();
      clone.querySelector("#interr_dotsRightGroup")?.remove();

      for (let f = 1; f <= 10; f++) {
        const grp = clone.querySelector(`#interr_hand_finger_keycap_group_${f}`);
        if (grp) grp.style.display = "none";
        const fingerEl = clone.querySelector(`#interr_hand_finger_${f}`);
        if (fingerEl) {
          if (FULL_FINGER_PATHS[f]) {
            fingerEl.setAttribute("d", FULL_FINGER_PATHS[f]);
          }
          fingerEl.classList.remove("finger-active");
          fingerEl.classList.add("interr-clickable-finger");
          fingerEl.addEventListener("click", (e) => {
            e.stopPropagation();
            if (typeof this.onFingerClick === "function") {
              this.onFingerClick(String(f), fingerEl);
            }
          });
        }
      }

      const dotsLayer = document.createElementNS(SVG_NS, "g");
      dotsLayer.setAttribute("id", "interr_landmarks_layer");
      clone.appendChild(dotsLayer);

      const coords =
        typeof ANATOMICAL_KEY_COORDINATES !== "undefined"
          ? ANATOMICAL_KEY_COORDINATES
          : [];
      const meta = global.InterrogationLayoutMetadata;

      const seenCoords = new Set();
      coords.forEach((pt, idx) => {
        const coordKey = `${pt.cx}_${pt.cy}`;
        if (seenCoords.has(coordKey)) return;
        seenCoords.add(coordKey);

        let mappedKeyId = null;
        if (meta && typeof meta.getKeyIdForChar === "function") {
          mappedKeyId = meta.getKeyIdForChar(pt.key) || meta.getKeyIdForChar(String(pt.key).toLowerCase());
        }
        if (!mappedKeyId) {
          const specialMap = {
            "CTRL-sn": "key_ctrl_l",
            "SHIFT-sn": "key_shift_l",
            "CAPS": "key_caps",
            "TAB": "key_tab",
            "ALT": "key_alt_l",
            "SPAZIO": "key_space",
            "AltGr": "key_altgr",
            "CTRL-dx": "key_ctrl_r",
            "SHIFT-dx": "key_shift_r",
            "BACK": "key_backspace",
            "INVIO": "key_enter",
          };
          mappedKeyId = specialMap[pt.key] || null;
        }

        const g = document.createElementNS(SVG_NS, "g");
        g.setAttribute("class", "interr-landmark-node");
        g.setAttribute("data-key-label", pt.key);
        g.setAttribute("data-finger", String(pt.finger));
        if (mappedKeyId) g.setAttribute("data-key-id", mappedKeyId);
        g.setAttribute("data-idx", String(idx));

        const hit = document.createElementNS(SVG_NS, "circle");
        hit.setAttribute("class", "interr-landmark-hit");
        hit.setAttribute("cx", pt.cx);
        hit.setAttribute("cy", pt.cy);
        hit.setAttribute("r", "12");
        hit.setAttribute("fill", "transparent");

        const dot = document.createElementNS(SVG_NS, "circle");
        dot.setAttribute("class", "interr-landmark-dot");
        dot.setAttribute("cx", pt.cx);
        dot.setAttribute("cy", pt.cy);
        dot.setAttribute("r", "6");

        g.appendChild(hit);
        g.appendChild(dot);

        g.addEventListener("click", (e) => {
          e.stopPropagation();
          if (typeof this.onLandmarkClick === "function") {
            this.onLandmarkClick({
              keyId: mappedKeyId,
              fingerId: String(pt.finger),
              keyLabel: pt.key,
              point: pt,
            });
          }
        });

        dotsLayer.appendChild(g);
      });

      container.appendChild(clone);
      this.handsSvg = clone;
      this.calibrateHitRadii();
      if (typeof global.requestAnimationFrame === "function") {
        global.requestAnimationFrame(() => this.calibrateHitRadii());
      }

      if (this._resizeHandler) {
        window.removeEventListener("resize", this._resizeHandler);
      }
      this._resizeHandler = () => this.calibrateHitRadii();
      window.addEventListener("resize", this._resizeHandler);
    }

    calibrateHitRadii() {
      if (!this.handsSvg) return;
      const rect = this.handsSvg.getBoundingClientRect();
      const scale = rect.width > 0 ? 1408 / rect.width : 3.2;
      const svgRadius = Math.max(18, Math.round(scale * 7));
      this.handsSvg.querySelectorAll(".interr-landmark-hit").forEach((c) => {
        c.setAttribute("r", String(svgRadius));
      });
    }

    resetKeyboard() {
      if (!this.keyboardSvg) return;
      this.keyboardSvg.querySelectorAll(".key").forEach((el) => {
        el.classList.remove(
          "active-target",
          "error-target",
          "pressed",
          "caps-active",
          "interr-key-target",
          "interr-key-revealed",
          "interr-key-neighbor",
          "interr-key-finger-pool",
          "interr-key-selected",
          "interr-key-yellow",
          "interr-key-ok",
          "interr-key-ko",
          "interr-key-mod",
        );
      });
      this.keyboardSvg.querySelectorAll(".interr-key-user-badge").forEach((b) => b.remove());
      this.keyboardSvg.querySelectorAll(".key text").forEach((txt) => {
        txt.classList.add("interr-key-label-hidden");
      });
    }

    setKeyUserBadge(keyId, label) {
      if (!this.keyboardSvg || !keyId) return;
      const el = this.keyboardSvg.querySelector(`#interr_${keyId}`);
      if (!el) return;
      const prev = el.querySelector(".interr-key-user-badge");
      if (prev) prev.remove();
      if (!label) return;
      const rect = el.querySelector("rect.key-bg");
      const w = rect ? parseFloat(rect.getAttribute("width") || "52") : 52;
      const h = rect ? parseFloat(rect.getAttribute("height") || "52") : 52;
      const txt = document.createElementNS(SVG_NS, "text");
      txt.setAttribute("class", "interr-key-user-badge");
      txt.setAttribute("x", String(w / 2));
      txt.setAttribute("y", String(h / 2 + 5));
      txt.setAttribute("text-anchor", "middle");
      txt.textContent = String(label);
      el.appendChild(txt);
    }

    resetHands() {
      if (!this.handsSvg) return;
      this.handsSvg.querySelectorAll(".interr-landmark-node").forEach((g) => {
        g.classList.remove("is-target-green", "is-modifier-active");
        const dot = g.querySelector(".interr-landmark-dot");
        if (dot) dot.setAttribute("r", "6");
      });
      for (let f = 1; f <= 10; f++) {
        const fingerEl = this.handsSvg.querySelector(`#interr_hand_finger_${f}`);
        if (fingerEl) fingerEl.classList.remove("finger-active", "interr-finger-target");
        const grp = this.handsSvg.querySelector(`#interr_hand_finger_keycap_group_${f}`);
        if (grp) grp.style.display = "none";
      }
    }

    highlightKey(keyId, cls = "interr-key-selected") {
      if (!this.keyboardSvg || !keyId) return;
      const el = this.keyboardSvg.querySelector(`#interr_${keyId}`);
      if (el) el.classList.add(cls);
    }

    unhighlightKey(keyId, cls = "interr-key-selected") {
      if (!this.keyboardSvg || !keyId) return;
      const el = this.keyboardSvg.querySelector(`#interr_${keyId}`);
      if (el) el.classList.remove(cls);
    }

    highlightKeysPool(keyIds, cls = "interr-key-finger-pool") {
      if (!this.keyboardSvg) return;
      this.keyboardSvg.querySelectorAll(`.key.${cls}`).forEach((el) => {
        el.classList.remove(cls);
      });
      (keyIds || []).forEach((kId) => {
        const el = this.keyboardSvg.querySelector(`#interr_${kId}`);
        if (el) el.classList.add(cls);
      });
    }

    revealKey(keyId, cls = "interr-key-revealed", allowedSlots = null) {
      if (!this.keyboardSvg || !keyId) return;
      const el = this.keyboardSvg.querySelector(`#interr_${keyId}`);
      if (!el) return;
      el.classList.add("interr-key-revealed");
      if (cls) el.classList.add(cls);
      el.querySelectorAll("text").forEach((t) => {
        if (!allowedSlots) {
          t.classList.remove("interr-key-label-hidden");
          return;
        }
        const isShift = t.classList.contains("label-shift");
        const isAltgr = t.classList.contains("label-altgr");
        const isShiftAltgr = t.classList.contains("label-shift-altgr");
        const isMain = t.classList.contains("label-main") || (!isShift && !isAltgr && !isShiftAltgr);
        const show =
          (isMain && !!allowedSlots.normal) ||
          (isShift && !!allowedSlots.shift) ||
          (isAltgr && !!allowedSlots.altgr) ||
          (isShiftAltgr && !!allowedSlots.shiftAltgr);
        t.classList.toggle("interr-key-label-hidden", !show);
      });
    }

    highlightFingerOnHands(fingerId) {
      if (!this.handsSvg) return;
      const target = Number(fingerId);
      for (let f = 1; f <= 10; f++) {
        const el = this.handsSvg.querySelector(`#interr_hand_finger_${f}`);
        if (el) el.classList.toggle("interr-finger-target", f === target);
      }
    }

    highlightTargetLandmark(keyId, fingerId, modifierKeyIds = []) {
      if (!this.handsSvg) return;
      this.resetHands();

      let matched = null;
      this.handsSvg.querySelectorAll(".interr-landmark-node").forEach((g) => {
        const gKey = g.getAttribute("data-key-id");
        const gFinger = parseInt(g.getAttribute("data-finger"), 10);
        if (gKey === keyId && (!fingerId || gFinger === Number(fingerId))) {
          matched = g;
        }
      });

      if (matched) {
        matched.classList.add("is-target-green");
        const dot = matched.querySelector(".interr-landmark-dot");
        if (dot) dot.setAttribute("r", "15");
      }

      if (fingerId) {
        this.highlightFingerOnHands(fingerId);
      }

      if (Array.isArray(modifierKeyIds) && modifierKeyIds.length > 0) {
        modifierKeyIds.forEach((mKey) => {
          if (this.keyboardSvg) this.revealKey(mKey, "interr-key-mod");
          this.handsSvg.querySelectorAll(`.interr-landmark-node[data-key-id="${mKey}"]`).forEach((mg) => {
            mg.classList.add("is-modifier-active");
            const dot = mg.querySelector(".interr-landmark-dot");
            if (dot) dot.setAttribute("r", "10");
          });
        });
      }
    }

    renderKeycapPreview(container, keyId, revealedSlots) {
      if (!container || !this.keyboardSvg || !keyId) return;
      const keyEl = this.keyboardSvg.querySelector(`#interr_${keyId}`);
      if (!keyEl) return;
      const meta = global.InterrogationLayoutMetadata;
      const box = meta && meta.KEY_BOXES ? meta.KEY_BOXES[keyId] : null;
      const w = box ? box.w : 52;
      const h = box ? box.h : 52;

      const svg = document.createElementNS(SVG_NS, "svg");
      svg.setAttribute("viewBox", `-4 -4 ${w + 8} ${h + 8}`);
      svg.setAttribute("class", "interr-mini-key-svg");

      const clonedKey = keyEl.cloneNode(true);
      clonedKey.removeAttribute("id");
      clonedKey.setAttribute("transform", "translate(0,0)");
      clonedKey.classList.remove("active-target", "error-target", "pressed", "interr-key-target", "interr-key-neighbor", "interr-key-selected");
      clonedKey.classList.add("interr-key-revealed");

      const slots = revealedSlots || {};
      clonedKey.querySelectorAll("text").forEach((t) => {
        const isShift = t.classList.contains("label-shift");
        const isAltgr = t.classList.contains("label-altgr");
        const isShiftAltgr = t.classList.contains("label-shift-altgr");
        const isMain = t.classList.contains("label-main") || (!isShift && !isAltgr && !isShiftAltgr);
        const show =
          (isMain && !!slots.normal) ||
          (isShift && !!slots.shift) ||
          (isAltgr && !!slots.altgr) ||
          (isShiftAltgr && !!slots.shiftAltgr);
        t.classList.toggle("interr-key-label-hidden", !show);
      });

      svg.appendChild(clonedKey);
      container.innerHTML = "";
      container.appendChild(svg);
    }
  }

  global.InterrogationSvgRenderer = InterrogationSvgRenderer;
})(typeof window !== "undefined" ? window : globalThis);
