# Cubo di Rubik (3x3) Glossary

Terminologia standard e convenzioni di notazione per il metodo a strati del Cubo di Rubik 3x3.

## Struttura del Cubo

**Centro**:
Pezzo centrale a una singola faccia, fissato al nucleo interno. Determina invariabilmente il colore finale di quell'intera faccia.
_Avoid_: Quadratino di mezzo, perno

**Spigolo**:
Pezzo a due colori situato tra due centri. Esistono 12 spigoli in tutto il puzzle.
_Avoid_: Bordo, lato

**Angolo**:
Pezzo a tre colori posizionato in corrispondenza di ciascuno degli 8 vertici del cubo.
_Avoid_: Punta, spigolo esterno

## Tappe del Metodo a Strati

**Margherita**:
Configurazione preliminare in cui i 4 spigoli bianchi sono posizionati attorno al centro giallo, propedeutica alla creazione della Croce Bianca allineata.
_Avoid_: Fiorellino, finta croce

**Croce Bianca**:
Formazione a croce sulla faccia bianca in cui i quattro spigoli bianchi combaciano perfettamente non solo con il centro bianco, ma anche con i rispettivi centri laterali.
_Avoid_: Segno più bianco

**Primo Strato**:
Risoluzione completa della faccia bianca e dell'anello perimetrale inferiore, con sagome a "T" capovolta su tutte le facce laterali.
_Avoid_: Faccia bianca, primo piano

**Secondo Strato**:
Risoluzione dei 4 spigoli della cintura centrale. Insieme al primo strato costituisce i primi due strati (F2L).
_Avoid_: Cintura, anello centrale

**Croce Gialla**:
Orientamento dei quattro spigoli superiori sul tetto giallo tramite l'algoritmo `F (R U R' U') F'`.
_Avoid_: Croce superiore, più giallo

## Notazione e Movimenti

**Prime (')**:
Modificatore di notazione che indica una rotazione di 90° in senso antiorario della faccia specificata.
_Avoid_: Inverso, contrario

**Sexy Move**:
Sequenza di quattro movimenti (`R U R' U'`) che costituisce il blocco costruttivo fondamentale per l'inserimento degli angoli e la gestione dell'ultimo strato.
_Avoid_: Algoritmo base, mossa a quattro

**Sexy Move Sinistra**:
Sequenza speculare della Sexy Move per mano sinistra (`L' U' L U`), impiegata nell'inserimento degli spigoli intermedi.
_Avoid_: Mossa sinistra, trigger mancino
