/* Test v6.44: Mascheramento Margherita (Piano di Studio), coppie miste e scalatura maxScore. */
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.resolve(__dirname, "..");

function loadContext() {
  const ctx = {
    window: {},
    globalThis: {},
    console,
    Date,
    Math,
    JSON,
    Set,
    Map,
    Array,
    Object,
    String,
    Number,
    Boolean,
    Promise,
    Error,
    TextEncoder,
    crypto: require("crypto").webcrypto,
  };
  ctx.window = ctx;
  ctx.globalThis = ctx;
  vm.createContext(ctx);

  const files = [
    "js/data/lessons.js",
    "js/data/interrogation-catalog-data.js",
    "js/data/lesson-curriculum-scope.js",
    "js/interrogation/interrogation-prng.js",
    "js/interrogation/interrogation-layout-metadata.js",
    "js/interrogation/interrogation-catalog.js",
    "js/interrogation/interrogation-knowledge.js",
    "js/interrogation/interrogation-selector.js",
    "js/interrogation/interrogation-repository.js",
    "js/interrogation/interrogation-session-manager.js",
  ];
  for (const rel of files) {
    vm.runInContext(fs.readFileSync(path.join(ROOT, rel), "utf8"), ctx, { filename: rel });
  }
  return ctx;
}

async function run() {
  const ctx = loadContext();
  const Scope = ctx.LessonCurriculumScope;
  const Meta = ctx.InterrogationLayoutMetadata;

  // 1. Verifica getKeyConstraint
  const cNone = Scope.getKeyConstraint(null, 0);
  assert.strictEqual(cNone.allowed, true, "Bordo tastiera (null) deve essere sempre in programma");

  const cS = Scope.getKeyConstraint("key_s", 0);
  assert.strictEqual(cS.allowed, true, "key_s deve essere sbloccato alla Lezione 1");

  const cQ = Scope.getKeyConstraint("key_q", 0);
  assert.strictEqual(cQ.allowed, false, "key_q non deve essere sbloccato alla Lezione 1");
  assert.strictEqual(cQ.requiredLesson1Based, 15, "key_q si sblocca alla Lezione 15");

  const cCaps = Scope.getKeyConstraint("key_caps", 0);
  assert.strictEqual(cCaps.allowed, false, "key_caps non è nel corso standard");
  assert.strictEqual(cCaps.requiredLesson1Based, null, "key_caps deve mostrare Non in programma");

  // 2. Verifica getActiveNeighborGroupCount su key_s alla Lezione 1 (indice 0):
  // Vicini di key_s: left=key_a (ok), right=key_d (ok), top=(key_w Lez48, key_e Lez6), bottom=(key_z Lez14, key_x Lez49)
  // Quindi alla Lezione 1 sono attivi solo 2 gruppi su 4 (left e right).
  const activeS_L1 = Scope.getActiveNeighborGroupCount("key_s", 0, Meta);
  assert.strictEqual(activeS_L1, 2, `Attesi 2 gruppi attivi per key_s alla Lez. 1, trovati ${activeS_L1}`);

  // Alla Lezione 6 (indice 5: e), topRight di key_s (key_e) si sblocca -> coppia mista attiva -> 3 gruppi attivi!
  const activeS_L6 = Scope.getActiveNeighborGroupCount("key_s", 5, Meta);
  assert.strictEqual(activeS_L6, 3, `Attesi 3 gruppi attivi per key_s alla Lez. 6 (coppia mista sopra), trovati ${activeS_L6}`);

  // 3. Verifica SessionManager.createSession: maxScore scalato per key_s alla Lezione 1 (6 + 2*3 = 12)
  const catalog = new ctx.InterrogationCatalog();
  const repo = new ctx.InterrogationRepository();
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository: repo });

  const created = await mgr.createSession({
    profileId: "test_v644",
    mode: "manual",
    lessonScope: "curriculum",
    maxLessonIndex: 0,
    questionTypes: ["TASTO"],
    requestedCount: 1,
    manualCandidateIds: ["candidate.key.key_s"],
  });
  assert.strictEqual(created.session.maxScore, 12, "maxScore per key_s alla Lez. 1 deve essere 12 (6 + 2*3)");

  // In Tastiera Completa, lo stesso tasto vale 18
  const createdFull = await mgr.createSession({
    profileId: "test_v644_full",
    mode: "manual",
    lessonScope: "full",
    questionTypes: ["TASTO"],
    requestedCount: 1,
    manualCandidateIds: ["candidate.key.key_s"],
  });
  assert.strictEqual(createdFull.session.maxScore, 18, "maxScore in Tastiera Completa deve restare 18");

  // 4. Verifica help.html aggiornato a v6.44
  const helpHtml = fs.readFileSync(path.join(ROOT, "help.html"), "utf8");
  assert(helpHtml.includes("Note di rilascio v6.44:"), "help.html deve riportare le note di rilascio v6.44");
  assert(helpHtml.includes("Margherita"), "help.html deve documentare i tasti intorno (Margherita)");

  console.log("PASS: test-interrogation-v644 verificato con successo.");
}

run().catch((err) => {
  console.error("FAIL test-interrogation-v644:", err);
  process.exit(1);
});
