# Documento di Handoff Tecnico (Chiusura Sessione - Versione 1.3)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Documento**: `/handoff` - Trasferimento Tecnico per la Prossima Chat  
**Versione di Rilascio Attuale**: **1.3**  
**Data**: 30 Marzo 2026  
**Autore / Ruolo**: AI Coding Assistant / Porting Engineer  
**Stato Operativo**: **Tutti i requisiti v.1.1, v.1.2 e v.1.3 implementati e collaudati al 100% con esito PASS**

---

## 1. Identificativo e Scopo dell'Handoff

Il presente documento costituisce il riferimento formale e autosufficiente di **Handoff Tecnico** per consentire a un nuovo assistente LLM o sviluppatore di riprendere immediatamente i lavori senza alcuna perdita di contesto, senza regressioni nel codice e nel pieno rispetto delle regole d'oro stabilite per il progetto.

### 1.1 Sintesi dell'Applicazione
*Ten Fingers Typing Trainer* è una celebre applicazione desktop creata nel 2003 da Alberto Modenese per l'insegnamento e l'allenamento alla digitazione cieca con 10 dita sulla tastiera italiana.  
Il porting converte l'applicazione originaria in una **Single Page Application (SPA)** moderna, elegante, reattiva e priva di dipendenze esterne (avviabile direttamente dal file system locale con un doppio clic).

---

## 2. Struttura del File System e Deliverable in `/workspace`

Tutti i file del progetto risiedono esclusivamente nella directory `/workspace`:

```text
/workspace/
├── index_(v.1.1).html       # SPA Versione 1.1 (Risoluzione bug critici, AppController, BlinkTimer)
├── help_(v.1.1).html        # Manuale Utente Versione 1.1
├── 05 - App TypeScript - Avanzamento Porting e Risoluzione Criticita (v.1.1).md
│
├── index_(v.1.2).html       # SPA Versione 1.2 (Riga continua, mira badge, Statistiche ridimensionabili, Selezione grafico)
├── help_(v.1.2).html        # Manuale Utente Versione 1.2
├── 06 - App TypeScript - Selezione Grafico, Finestra Ridimensionabile e Rifiniture UI (v.1.2).md
│
├── index_(v.1.3).html       # SPA Versione 1.3 CORRENTE (Custom multilinea, Invio/Tab, Feedback tasti speciali, Palmi SVG)
├── help_(v.1.3).html        # Manuale Utente Versione 1.3 CORRENTE (Include Sezione 9 - Note di rilascio v.1.3)
├── 07 - App TypeScript - Esercizi Custom, Feedback Tasti Speciali e Centratura Mani (v.1.3).md
│
├── 08 - App TypeScript - Documento Conclusivo di Sintesi Tecnica e Specifica Architetturale (v.1.1 - v.1.3).md
└── 09 - FINE CHAT - Documento di Handoff Tecnico (Versione 1.3).md   <-- [QUESTO DOCUMENTO]
```

---

## 3. Regole d'Oro di Lavoro e Modus Operandi (Tassative)

Nelle sessioni successive dovranno essere rigorosamente applicati i seguenti principi:

1. **Nuovo Numero di Versione a Ogni Modifica**:
   Qualsiasi modifica al codice o alla documentazione genera una nuova versione progressiva (`index_(v.1.4).html`, `help_(v.1.4).html`, ecc.).
2. **Modifiche Puntuali e Circoscritte**:
   Non riscrivere file da zero. Non modificare codice già funzionante e collaudato.
3. **Preservazione dei Commenti e Funzionalità**:
   Conservare i commenti e la struttura dati esistente (70 lezioni propedeutiche, 439 campioni storici, corpus fonetico italiano).
4. **Assoluta Prevenzione di Bug e Regressioni**:
   Ogni rilascio deve essere testato in modo automatizzato tramite headless browser o test unitari prima del rilascio.
5. **Coerenza Assoluta tra Codice, Help e Documentazione**:
   Aggiornare sempre contestualmente l'HTML principale, il manuale Help e i documenti di specifica `.md`.
6. **Tutti i File Salvati in `/workspace`**:
   Nessun file sparso al di fuori del percorso `/workspace`.
7. **Interazione Guidata (/Grill-me)**:
   Mantenere un'interazione maieutica strutturata ponendo **una sola domanda alla volta** (*"Ponimi una domanda per volta"*).

---

## 4. Architettura Tecnica e Modello Dati

L'applicazione è progettata come SPA monolitica scritta in vanilla TypeScript compilato in ECMAScript 2020:

### 4.1 Moduli e Classi Core
- **`TypingEngine`**: Gestisce lo stato della digitazione, il calcolo temporale, le metriche (BPM, WPM, Accuratezza %, Errori), la validazione dei tasti e la commutazione delle modalità (0: Standard, 1: Random Lezione, 2: Random Fonemi, 3: All Chars, 4: Libera, 5: Random Frase).
- **`VisualRenderer`**: Gestisce la tastiera virtuale SVG e la finestra mani SVG. Si occupa dell'animazione pulsante del bersaglio (`.active-target`), del riscontro visivo dei tasti fisici premuti (`.key-pressed`), dell'evidenziazione delle 10 dita e della formattazione delle etichette.
- **`WindowManager`**: Gestisce il drag & drop relativo (mouse e touch), la sovrapposizione z-index e il ridimensionamento a 8 maniglie (`.rh-*`) con memorizzazione di coordinate e dimensioni.
- **`StatisticsManager`**: Genera dinamicamente gli istogrammi SVG (per tasto, per dito, per frequenza ed errore) e il grafico cartesiano di velocità campioni, con supporto alla selezione ad area tramite mouse (drag-to-select) e comandi di cancellazione mirata.
- **`ProfileManager`**: Gestisce l'interfaccia con `localStorage` (`TFTT_USERS`, `TFTT_ACTIVE_USER`, `TFTT_PROFILE_<USER>`), garantendo persistenza locale completa.
- **`AudioEngine`**: Sintetizzatore Web Audio API calibrato per click macchina da scrivere, cicalino d'errore e campanella di fine riga.
- **`AppController`**: Orchestratore centrale dell'applicazione; coordina menu toolbar, eventi tastiera globale, scorciatoie `CTRL+SHIFT`, finestre fluttuanti e commutazione tra lezioni Standard e Custom.

---

## 5. Cronistoria Funzionalità Implementate (v.1.1 - v.1.3)

### Versione 1.1
- Ripristinata la classe `AppController` e la funzione `htmlEscape`, eliminando il blocco totale iniziale.
- Ripristinato l'auto-login automatico al profilo master `ALBERTO` (439 campioni storici).
- Implementata l'animazione pulsante CSS del tasto bersaglio (`keyBlinkTarget` a ~300 ms).
- Risolto il blocco delle finestre fluttuanti (drag & drop e chiusura con pulsante "×").

### Versione 1.2
- **Unica Riga Continua**: Eliminati i salti riga spuri nel testo guida; visualizzazione compatta a flusso continuo.
- **Puntamento Verticale Badge Errore**: Posizionamento dinamico sopra la lettera bersaglio blu (`top: -34px`).
- **Scorciatoie Guida `CTRL+SHIFT+H` ed `F1`**: Apertura affidabile con click nativo su ancora, aggirando i popup-blocker.
- **Finestra Statistiche Ridimensionabile a 8 Vie**: Ridimensionamento fluido da ogni bordo/angolo con persistenza su `localStorage`, pulsante schermo intero e pulsante reset layout.
- **Selezione ad Area sul Grafico Cartesiano**: Evidenziazione campioni con drag del mouse, calcolo velocità media parziale e pulsanti `btnClearSelection` ed `btnClearNotSelected` con finestre di conferma descrittive.

### Versione 1.3
- **Integrazione Lezioni Custom nel Menu a Tendina**: Salvataggio o caricamento di file `.txt` popola istantaneamente `cboLessons` con i titoli estratti (`===== Titolo =====`). Pulsante `📚 Standard / Custom` per commutare istantaneamente catalogo.
- **Supporto Multilinea con Invio e Tab**:
  - Tasto **Invio** (`®` / `↵`, badge *"INVIO ↵"*): assegnato al **mignolo destro (dito 10)** e tasto `key_enter`.
  - Tasto **Tab** (`→` / `⇥`, badge *"TAB ⇥"*): assegnato al **mignolo sinistro (dito 1)** e tasto `key_tab`.
  - Intercettazione con `preventDefault()` per una digitazione fluida senza perdita di focus.
- **Illuminazione Azzurra Tasti Fisici**: Flash azzurro (`.key-pressed`) per tutti i 10 tasti speciali: Tab, CapsLock, Shift (Sx/Dx), Ctrl (Sx/Dx), Alt, AltGr, Win (Sx/Dx), Backspace, Return, Menu.
- **Trattamento come Errore dei Tasti Fuori Luogo**: Segnale acustico, incremento errori e proiezione del badge rosso fluttuante descrittivo (*CAPS LOCK*, *TAB*, *INVIO*, ecc.) se premuti indebitamente.
- **Centratura Anatomica Palmo Mani SVG**: Traslazione del palmo verso i rispettivi mignoli (`translate(-12, 0)` per mano sinistra e `translate(12, 0)` per mano destra).

---

## 6. Prossimo Step di Sviluppo: Versione 1.4

La priorità approvata per la prossima versione **v.1.4** è l'implementazione del flusso di **avanzamento didattico automatico ("continua")**:

1. **Avanzamento Sequenziale Automatico a Fine Frase**:
   - Al completamento con successo di una frase (quando `typedText.length === originText.length`), dopo l'emissione del suono della campanella e il salvataggio del campione di velocità:
     - Applicare una pausa temporizzata ergonomica (~600–800 ms) per consentire all'utente di osservare le metriche WPM e accuratezza raggiunte;
     - Caricare automaticamente la frase successiva (`currentPhraseIdx + 1`) e reimpostare l'area di input e il bersaglio senza richiedere click sul pulsante "Avanti".
2. **Avanzamento a Fine Lezione**:
   - Quando viene completata l'ultima frase di una lezione (sia Standard che Custom):
     - Mostrare un dialog/badge modale di congratulazioni e riepilogo statistico (velocità media della lezione, errori totali, accuratezza media);
     - Al click su OK (o pressione di Invio/Spazio), avanzare automaticamente alla lezione successiva (`currentLessonIdx + 1`).
3. **Mantenimento Versioning**:
   - Produrre `index_(v.1.4).html`, `help_(v.1.4).html` e `08 - App TypeScript - Avanzamento Didattico e Completamento Frasi (v.1.4).md`.

---

## 7. Prompt di Avvio per la Nuova Chat (Copia e Incolla)

Incolla il seguente prompt nella nuova sessione per trasferire istantaneamente tutto il contesto:

```markdown
Scopo di questa sessione è proseguire il porting di "Ten Fingers Typing Trainer" da C# a Web SPA (TypeScript/HTML5).

Fai riferimento ai documenti e sorgenti già presenti e validati nella cartella /workspace:
- Sorgente corrente: index_(v.1.3).html
- Manuale help corrente: help_(v.1.3).html
- Handoff tecnico: 09 - FINE CHAT - Documento di Handoff Tecnico (Versione 1.3).md
- Sintesi tecnica: 08 - App TypeScript - Documento Conclusivo di Sintesi Tecnica e Specifica Architetturale (v.1.1 - v.1.3).md

REGOLE TASSATIVE DI LAVORO:
1. Incrementa sempre il numero di versione a ogni modifica (prossima: v.1.4).
2. Effettua modifiche puntuali e circoscritte, non modificare codice già funzionante.
3. Conserva i commenti e non introdurre bug o regressioni.
4. Mantieni sempre la coerenza tra Codice, Help e Documentazione.
5. Salva tutti i nuovi file nella directory /workspace.
6. Ponimi una sola domanda alla volta (/Grill-me).

OBIETTIVO DELLA VERSIONE 1.4:
Implementare il flusso di avanzamento didattico automatico ("continua"):
- Al completamento con successo di una frase (suono della campanella emesso e campione registrato), avanzare automaticamente alla frase successiva dopo una pausa calibrata (~700 ms);
- Al completamento dell'ultima frase di una lezione (standard o custom), mostrare un riepilogo con congratulazioni e procedere alla lezione successiva.

Leggi l'handoff tecnico in /workspace e confermami quando sei pronto a generare la versione v.1.4.
```
