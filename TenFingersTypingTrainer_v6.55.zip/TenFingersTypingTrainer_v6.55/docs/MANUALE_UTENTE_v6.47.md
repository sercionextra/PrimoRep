# Manuale Utente TenFingersTypingTrainer v6.47

Questa guida integra il manuale della versione 6.46 con l'aggiornamento introdotto nella versione 6.47.

## 1. "Random This Phrase" dopo una sessione di Digitazione Libera completata
Anche dopo aver completato e salvato una sessione di **Digitazione Libera** tramite il pulsante **Aggiungi Statistica**, puoi passare subito a **Random This Phrase** (dal menu delle modalità o dal pulsante dedicato): il programma rimescolerà l'ultima frase libera appena digitata.
