# Metodi completi impattati — TenFingersTypingTrainer v6.24

Questo documento contiene esclusivamente i metodi applicativi modificati, non i file completi. Per ogni metodo sono indicati il percorso nella baseline v6.23 e il percorso aggiornato nella v6.24. I metodi sono estratti dal sorgente v6.24 senza abbreviazioni.

## DictationEngine.constructor()

- **Baseline v6.23:** `js/engines/dictation-engine.js`, riga 7
- **Nuova versione v6.24:** `js/engines/dictation-engine.js`, riga 7

```javascript
// =======================================================
  // CLASSE: DictationEngine (main_A_(v.4.9).js)
  // METODO: constructor()
  // =======================================================
  constructor() {
    this.synth = window.speechSynthesis || null;
    this.enabled = false;
    this.speed = 0.9;
    this.announceCaps = false;
    this.announceApostrophe = false; // Opzione A (Esplicita Didattica) vs Opzione B (Naturale)
    this.announceSpace = false; // Dettatura esplicita dello spazio agganciato alla parola seguente (Release v.5.0)
    this.forceSpelling = false; // Forza la dettatura lettera per lettera (v.4.2)
    this.quoteCount = 0; // Tracciamento alternanza virgolette (dispari: aperte, pari: chiuse)
    this.mode = 0;
    this.tokens = [];
    this.currentIndex = 0;
    this.isSpeaking = false;
    this.hasPendingError = false;
    this.stallTimer = null;
    this.hasFiredAutoReplay = false; // Flag di emissione promemoria/replay per pausa corrente
    this.stallRepetitionCount = 0; // Contatore ripetizioni consecutive di inattività (Release v6.15)
    this.isSpeakingReplay = false; // Flag di emissione attiva di un messaggio di Replay/supporto (Release v6.0)
    this.isRecoveringFromCorrection = false; // Flag di avvenuta correzione degli errori in attesa di ripresa digitazione (Release v6.0)

    // Tracciamento metriche correnti per Replay automatico su inattività (Release v.4.9)
    this.lastTypedLen = 0;
    this.lastMatchLen = 0;
    this.stateProvider = null; // Provider dinamico dello stato di battitura live (Release v.4.9)

    // Dettatura Adattiva Dinamica (Release v6.13 / v6.14 / v6.15 / v6.16 / v6.17 / v6.20)
    this.adaptiveMode = false;
    this.minAnticipationCpm = 100;
    this.maxAnticipationCpm = 200;
    this.tokenErrorCount = 0; // Errori commessi sul token corrente
    this.recoveryStreak = 0; // Battute corrette consecutive dopo una correzione
    this.lastActiveTokenIdx = -1; // Indice dell'ultimo token attivo

    // Configurazione Tempi di Inattività e Anti-Troncamento (Release v6.20)
    this.stallBaseDelay = 1500; // Ritardo base di inattività in ms (default 1,5s)
    this.stallLongDelay = 3500; // Ritardo esteso dopo 3 ripetizioni in ms (default 3,5s)
    this.stallSpeedFactor = 1.0; // Coefficiente modulazione inversa velocità vocale (default 1,0)
    this.currentUtteranceExpectedDuration = 1500; // Durata stimata dell'emissione attiva in ms

    // Coda a profondità 1 con assorbimento del ritardo (Release v6.14 - Domanda 1, Opzione C)
    this.pendingLookahead = null;

    // Gestione troncone post-correzione (Release v6.14 - Domanda 2)
    this.isRecoveringTroncone = false;
    this.recoveringTokenIdx = -1;

    // Gestione Spelling al 2° errore consecutivo (Release v6.14 - Domanda 3)
    this.wordSpellingTokenIdx = -1;

    // Proprietà cross-platform v.4.2 e Auto-Healing Anti-Ghost-Lock (Release v6.16 / v6.17)
    this.bestVoice = null;
    this.fallbackLocalVoice = null;
    this.localVoiceAvailable = false; // v6.24: nessuna sintesi vocale remota consentita.
    this.watchdogTimer = null;
    this.utteranceWatchdogTimer = null; // Watchdog deterministico per singola utterance (Release v6.16)
    this.lastSpeechStartTime = 0; // Timestamp avvio dell'ultima pronuncia effettiva (Release v6.16)
    this._retainedUtterances = new Set(); // Previene il WebKit Garbage Collection Bug su Apple Safari

    // Stato per Replay Assistito e Spelling a 3 pressioni (v.4.2)
    this.currentText = "";
    this.lastReplayKey = null;
    this.replayCount = 0;

    // Dizionario fonetico simboli isolati e parentesi allineate (Release v.4.6 / v.5.0)
    this.symbolSpelling = {
      ".": "punto",
      ",": "virgola",
      ";": "punto e virgola",
      ":": "due punti",
      "?": "punto interrogativo",
      "!": "punto esclamativo",
      "'": "apostrofo",
      '"': "virgolette",
      "(": "aperta tonda",
      ")": "chiusa tonda",
      "[": "aperta quadra",
      "]": "chiusa quadra",
      "{": "aperta graffa",
      "}": "chiusa graffa",
      "<": "minore",
      ">": "maggiore",
      "/": "slash",
      "\\": "backslash",
      "-": "trattino",
      _: "trattino basso",
      "+": "più",
      "=": "uguale",
      "*": "asterisco",
      "@": "chiocciola",
      "#": "cancelletto",
      $: "dollaro",
      "£": "sterlina",
      "€": "euro",
      "%": "percento",
      "&": "e commerciale",
      "®": "invio",
      "\n": "invio",
      "→": "tàb",
      "\t": "tàb",
      "|": "pipe",
      "^": "circonflesso",
      "§": "paragrafo",
      "°": "gradi",
      ç: "cediglia",
      Ç: "cediglia",
    };

    this.charSpelling = {
      a: "a",
      b: "bi",
      c: "ci",
      d: "di",
      e: "e",
      f: "effe",
      g: "gi",
      h: "acca",
      i: "i",
      j: "i lunga",
      k: "cappa",
      l: "elle",
      m: "emme",
      n: "enne",
      o: "o",
      p: "pi",
      q: "qu",
      r: "erre",
      s: "esse",
      t: "ti",
      u: "u",
      v: "vu",
      w: "doppia vu",
      x: "ics",
      y: "ipsilon",
      z: "zeta",
      ç: "cediglia",
      à: "a grave",
      è: "e grave",
      é: "e acuta",
      ì: "i grave",
      ò: "o grave",
      ù: "u grave",
      " ": "spazio",
    };

    this.initVoices();
  }
```

## DictationEngine.initVoices()

- **Baseline v6.23:** `js/engines/dictation-engine.js`, riga 462
- **Nuova versione v6.24:** `js/engines/dictation-engine.js`, riga 463

```javascript
initVoices() {
    if (!this.synth) {
      this.bestVoice = null;
      this.fallbackLocalVoice = null;
      this.localVoiceAvailable = false;
      return;
    }

    const load = () => {
      let voices = [];
      try {
        voices = this.synth.getVoices() || [];
      } catch (error) {
        this.bestVoice = null;
        this.fallbackLocalVoice = null;
        this.localVoiceAvailable = false;
        return;
      }

      // In modalità offline sono ammesse esclusivamente voci italiane dichiarate locali dal browser.
      // localService assente o diverso da true non viene considerato una garanzia sufficiente.
      const itVoices = voices.filter(
        (voice) =>
          voice &&
          voice.localService === true &&
          this._isItalianVoice(voice.lang),
      );

      if (itVoices.length === 0) {
        this.bestVoice = null;
        this.fallbackLocalVoice = null;
        this.localVoiceAvailable = false;
        return;
      }

      // Preferisce la variante it-IT; gli spareggi usano un confronto deterministico per codice UTF-16.
      const ranked = [...itVoices].sort((a, b) => {
        const aExact =
          String(a.lang).toLowerCase().replace(/_/g, "-") === "it-it" ? 1 : 0;
        const bExact =
          String(b.lang).toLowerCase().replace(/_/g, "-") === "it-it" ? 1 : 0;

        if (aExact !== bExact) return bExact - aExact;

        const aName = String(a.name || "");
        const bName = String(b.name || "");
        return aName < bName ? -1 : aName > bName ? 1 : 0;
      });

      this.bestVoice = ranked[0] || null;
      this.fallbackLocalVoice = ranked[1] || ranked[0] || null;
      this.localVoiceAvailable = !!this.bestVoice;
    };

    load();
    if (typeof this.synth.onvoiceschanged !== "undefined") {
      this.synth.onvoiceschanged = load;
    }
  }
```

## DictationEngine.speakCurrentToken()

- **Baseline v6.23:** `js/engines/dictation-engine.js`, riga 926
- **Nuova versione v6.24:** `js/engines/dictation-engine.js`, riga 907

```javascript
// =======================================================
  // CLASSE: DictationEngine (main_A_(v6.0).js)
  // METODI: speakCurrentToken() e updateProgress()
  // CONTESTO: Riallineamento dinamico istantaneo su scavalcamento parole e protezione da freeze vocale
  // =======================================================

  // Emissione vocale protetta con auto-resume, anti-freeze e coda lookahead a profondità 1 (Release v6.14)
  speakCurrentToken(forcedVoice = null, customText = null, isDirect = false) {
    if (!this.enabled || !this.synth) return;
    if (this.currentIndex >= this.tokens.length && !customText) return;
    if (this.hasPendingError && !customText) return;

    // Non avviare mai la voce predefinita del browser: potrebbe essere un servizio remoto.
    // Se l'elenco locale non era ancora pronto, aggiorna la selezione e richiedi una voce locale esplicita.
    if (!this.bestVoice) this.initVoices();
    const activeVoice = forcedVoice || this.bestVoice;
    if (!activeVoice || activeVoice.localService !== true) {
      this.localVoiceAvailable = false;
      this.pendingLookahead = null;
      this.isSpeaking = false;
      this.isSpeakingReplay = false;
      return;
    }
    this.localVoiceAvailable = true;

    // Se l'engine sta già pronunciando e non si tratta di un comando diretto (errore/correzione/replay),
    // applica l'Opzione C: buffer a profondità 1 con assorbimento del ritardo (Release v6.14)
    if (!isDirect && this.isSpeaking) {
      this.pendingLookahead = {
        forcedVoice,
        customText,
        tokenIndex: this.currentIndex,
      };
      return;
    }
    if (isDirect) {
      this.pendingLookahead = null;
    }

    // Se l'applicazione non sta parlando (this.isSpeaking === false) ma l'hardware
    // risulta ancora occupato da residui asincroni del browser, ripulisci preventivamente (Release v6.17)
    if (this.synth && (this.synth.speaking || this.synth.pending)) {
      try {
        this.synth.cancel();
      } catch (e) {}
    }

    // Sblocco proattivo da eventuali stati di sospensione dell'engine vocale del browser
    try {
      if (this.synth.paused) {
        this.synth.resume();
      }
    } catch (err) {
      // Fallback silenzioso
    }

    const token = this.tokens[this.currentIndex];
    const textToSpeak =
      customText !== null ? customText : token ? token.spokenText : "";
    if (!textToSpeak) return;

    // Applicazione della protezione fonetica
    const phoneticPayload = this._sanitizeForTTS(textToSpeak);

    const utter = new SpeechSynthesisUtterance(phoneticPayload);
    utter.rate = this.speed;
    utter.pitch = 1.05;
    utter.lang = "it-IT";

    utter.voice = activeVoice;
    utter.lang = activeVoice.lang;

    // 1. Registrazione nel set di ancoraggio per prevenire il WebKit GC Bug
    this._retainedUtterances.add(utter);

    // 2. Avvio del Watchdog anti-stallo sia per i token standard che per i testi personalizzati (v6.1)
    this._startWatchdog(utter, token);

    // 3. Watchdog deterministico di auto-healing anti-ghost-lock calibrato sul payload fonetico e sulla velocità vocale (Release v6.16 / v6.20)
    const effectiveSpeed = Math.max(0.2, this.speed || 0.9);
    const rawExpectedDuration = Math.max(1500, phoneticPayload.length * 110 + 800);
    const speedAdjustedDuration = Math.round(rawExpectedDuration / effectiveSpeed);
    this.currentUtteranceExpectedDuration = speedAdjustedDuration;
    const expectedDurationMs = speedAdjustedDuration + 1500;
    this._startUtteranceWatchdog(utter, expectedDurationMs);

    utter.onstart = () => {
      this._clearWatchdog();
      this.isSpeaking = true;
    };

    const cleanup = () => {
      this._clearWatchdog();
      this._clearUtteranceWatchdog();
      this.isSpeaking = false;
      this.isSpeakingReplay = false;
      this._retainedUtterances.delete(utter);
    };

    utter.onend = () => {
      cleanup();
      // Scarico proattivo del buffer lookahead a profondità 1 (Opzione C, Release v6.14)
      if (this.pendingLookahead) {
        const next = this.pendingLookahead;
        this.pendingLookahead = null;
        if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
          this.currentIndex = next.tokenIndex;
        }
        this.speakCurrentToken(next.forcedVoice, next.customText);
      } else {
        // Al termine dell'ultima parola o lettera dettata: riavvia il contatore di attesa (Release v6.15)
        this.resetStallTimer();
      }
    };

    utter.onerror = (e) => {
      cleanup();
      if (e.error !== "canceled" && e.error !== "interrupted") {
        if (
          !forcedVoice &&
          this.fallbackLocalVoice &&
          this.bestVoice !== this.fallbackLocalVoice
        ) {
          this.speakCurrentToken(this.fallbackLocalVoice, customText, true);
          return;
        }
        if (this.pendingLookahead) {
          const next = this.pendingLookahead;
          this.pendingLookahead = null;
          if (next.tokenIndex !== undefined && next.tokenIndex !== null) {
            this.currentIndex = next.tokenIndex;
          }
          this.speakCurrentToken(next.forcedVoice, next.customText);
        } else {
          this.resetStallTimer();
        }
      }
    };

    // Release v6.14 (DOMANDA 4): Nessun annullamento arbitrario via synth.cancel() durante la digitazione!
    // synth.cancel() è circoscritto rigorosamente a stopAudioOnly() su errore, backspace, replay o stop.
    this.clearStallTimer();
    this.isSpeaking = true;
    this.lastSpeechStartTime = Date.now();
    this.synth.speak(utter);
  }
```

## StatisticsManager.renderHistogram()

- **Baseline v6.23:** `js/analytics/statistics-manager.js`, riga 12
- **Nuova versione v6.24:** `js/analytics/statistics-manager.js`, riga 12

```javascript
renderHistogram() {
    const container = document.getElementById("statsHistogramSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Caratteri || p.Caratteri.length === 0) {
      container.innerHTML =
        '<div class="stats-empty-state">Nessun dato statistico disponibile</div>';
      return;
    }

    // Process data
    let list = p.Caratteri.map((c) => ({
      char: String.fromCharCode(c.CharUnicode),
      freq: c.Frequenza || 0,
      err: c.Errori || 0,
      errRate: c.Frequenza > 0 ? (c.Errori / c.Frequenza) * 100 : 0,
      finger: (KEY_MAP[String.fromCharCode(c.CharUnicode)] || {}).finger || 0,
    }));

    // Sorting
    const isPerDito =
      this.sortMode === "ditoRel" || this.sortMode === "ditoAss";
    if (this.sortMode === "freqRel" || this.sortMode === "freqAss") {
      list.sort((a, b) => b.freq - a.freq);
    } else if (this.sortMode === "errRel") {
      list.sort((a, b) => b.errRate - a.errRate);
    } else if (this.sortMode === "errAss") {
      list.sort((a, b) => b.err - a.err);
    } else if (this.sortMode === "ditoRel") {
      list.sort(
        (a, b) => (a.finger || 99) - (b.finger || 99) || b.errRate - a.errRate,
      );
    } else if (this.sortMode === "ditoAss") {
      list.sort((a, b) => (a.finger || 99) - (b.finger || 99) || b.err - a.err);
    }

    const maxFreq = Math.max(1, ...list.map((x) => x.freq));
    const maxErr = Math.max(1, ...list.map((x) => x.err));
    const maxErrRate = Math.max(0.1, ...list.map((x) => x.errRate));

    const isErrRelMode =
      this.sortMode === "errRel" || this.sortMode === "ditoRel";
    const isErrAssMode =
      this.sortMode === "errAss" || this.sortMode === "ditoAss";

    const activeMax = isErrRelMode
      ? maxErrRate
      : isErrAssMode
        ? maxErr
        : maxFreq;

    // Risoluzione Dinamica : altezza determinata esattamente dallo spazio residuo della sezione
    const containerH = container.clientHeight || 200;
    const height = Math.max(140, containerH);

    const chartBaseline = height - 26;
    const topLimit = isPerDito ? 24 : 14;
    const maxBarH = Math.max(20, chartBaseline - topLimit - 6);

    const fingerMeta = {
      1: {
        name: "Mignolo Sx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
      2: {
        name: "Anulare Sx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      3: {
        name: "Medio Sx",
        color: "#10b981",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      4: {
        name: "Indice Sx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      5: {
        name: "Pollice Sx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      6: {
        name: "Pollice Dx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      7: {
        name: "Indice Dx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      8: {
        name: "Medio Dx",
        color: "#10b981",
        fill: "rgba(16, 185, 129, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      9: {
        name: "Anulare Dx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      10: {
        name: "Mignolo Dx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
    };

    const barPitch = 36;
    const barWidth = 24;
    const startX = 20;
    const width = Math.max(760, list.length * barPitch + 40);

    let svg = `<svg class="stats-histogram-svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">`;

    if (isPerDito) {
      let currentFinger = null;
      let groupStartIndex = 0;
      let groups = [];

      list.forEach((item, idx) => {
        if (item.finger !== currentFinger) {
          if (currentFinger !== null) {
            groups.push({
              finger: currentFinger,
              start: groupStartIndex,
              count: idx - groupStartIndex,
            });
          }
          currentFinger = item.finger;
          groupStartIndex = idx;
        }
      });
      if (currentFinger !== null) {
        groups.push({
          finger: currentFinger,
          start: groupStartIndex,
          count: list.length - groupStartIndex,
        });
      }

      groups.forEach((grp) => {
        const meta = fingerMeta[grp.finger] || {
          name: `Dito ${grp.finger}`,
          color: "#64748b",
          fill: "rgba(100, 116, 139, 0.08)",
          stroke: "rgba(100, 116, 139, 0.5)",
        };
        const gx = startX + grp.start * barPitch - 5;
        const gw = grp.count * barPitch;
        const gy = 4;
        const gh = chartBaseline - gy + 22;

        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" rx="6" fill="${meta.fill}" stroke="${meta.stroke}" stroke-width="1.6" />`;
        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="17" rx="5" fill="${meta.color}" opacity="0.9" />`;
        svg += `<text x="${gx + gw / 2}" y="${gy + 12.5}" font-size="10" font-weight="700" fill="#ffffff" text-anchor="middle">${meta.name}</text>`;
      });
    }

    svg += `<line x1="6" y1="${chartBaseline}" x2="${width - 6}" y2="${chartBaseline}" stroke="var(--border-color)" stroke-width="1.5" />`;

    list.forEach((item, idx) => {
      const x = startX + idx * barPitch;
      const meta = fingerMeta[item.finger] || { color: "#3b82f6" };
      let primaryVal = item.freq;
      let displayVal = `${item.freq}`;

      if (isErrRelMode) {
        primaryVal = item.errRate;
        displayVal = `${item.errRate.toFixed(1)}%`;
      } else if (isErrAssMode) {
        primaryVal = item.err;
        displayVal = `${item.err}`;
      }

      const barH = activeMax > 0 ? (primaryVal / activeMax) * maxBarH : 0;
      const y = chartBaseline - barH;
      const barColor = isPerDito
        ? meta.color
        : isErrRelMode || isErrAssMode
          ? "#ef4444"
          : "#3b82f6";

      svg += `<g class="hist-bar" data-char="${htmlEscape(item.char)}" data-freq="${item.freq}" data-err="${item.err}" data-rate="${item.errRate.toFixed(1)}" data-finger="${meta.name || ""}">`;

      if (barH > 0) {
        svg += `<rect x="${x}" y="${y}" width="${barWidth}" height="${barH}" rx="3" fill="${barColor}" opacity="0.85" />`;
      }

      if (!isErrRelMode && !isErrAssMode && item.err > 0) {
        const errH = (item.err / maxFreq) * maxBarH;
        const errY = chartBaseline - errH;
        svg += `<rect x="${x}" y="${errY}" width="${barWidth}" height="${errH}" rx="3" fill="#ef4444" opacity="0.9" />`;
      }

      svg += `<text x="${x + barWidth / 2}" y="${chartBaseline + 17}" font-size="12.5" font-weight="700" text-anchor="middle" fill="var(--text-main)">${htmlEscape(item.char === " " ? "␣" : item.char)}</text>`;

      const labelY = Math.max(isPerDito ? 31 : 13, y - 4);
      svg += `<text x="${x + barWidth / 2}" y="${labelY}" font-size="9.5" font-weight="600" text-anchor="middle" fill="var(--text-muted)">${displayVal}</text>`;
      svg += `</g>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    container.querySelectorAll(".hist-bar").forEach((bar) => {
      bar.addEventListener("mouseenter", () => {
        const c = bar.getAttribute("data-char");
        const f = bar.getAttribute("data-freq");
        const er = bar.getAttribute("data-err");
        const rt = bar.getAttribute("data-rate");
        const d = bar.getAttribute("data-finger");
        const dStr = d ? ` | Dito: ${d}` : "";
        document.getElementById("histTooltipText").innerText =
          `Tasto: "${c}" | Frequenza: ${f} | Errori: ${er} (${rt}%)${dStr}`;
      });
    });
  }
```

## StatisticsManager.clearSelection()

- **Baseline v6.23:** `js/analytics/statistics-manager.js`, riga 254
- **Nuova versione v6.24:** `js/analytics/statistics-manager.js`, riga 254

```javascript
clearSelection() {
    this.selectedSampleIndices.clear();
    this.selectionState = 0;
    const selRect = document.getElementById("chartSelectionRect");
    if (selRect) selRect.style.display = "none";
    document.querySelectorAll(".speed-point").forEach((dot) => {
      dot.classList.remove("selected");
      dot.setAttribute("fill", "#3b82f6");
      dot.setAttribute("r", "4");
    });

    const btnClearSel = document.getElementById("btnClearSelection");
    const btnClearNotSel = document.getElementById("btnClearNotSelected");
    if (btnClearSel) {
      btnClearSel.style.visibility = "hidden";
      btnClearSel.disabled = true;
    }
    if (btnClearNotSel) {
      btnClearNotSel.style.visibility = "hidden";
      btnClearNotSel.disabled = true;
    }

    if (this.currentFilteredSamples.length > 0) {
      const vals = this.currentFilteredSamples.map((s) => this.getSampleVal(s));
      const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
      const summary = document.getElementById("lblMediaValori");
      if (summary) {
        summary.textContent = `${avg} (globale su ${this.currentFilteredSamples.length} campioni)`;
      }
    }
  }
```

## StatisticsManager.renderSpeedChart()

- **Baseline v6.23:** `js/analytics/statistics-manager.js`, riga 441
- **Nuova versione v6.24:** `js/analytics/statistics-manager.js`, riga 443

```javascript
// Rendering Grafico Cronologico Velocità con Filtro Temporale e Giorno della Settimana
  renderSpeedChart() {
    const container = document.getElementById("statsSpeedSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Campioni || p.Campioni.length === 0) {
      container.innerHTML =
        '<div class="stats-empty-state">Nessun campione di velocità registrato</div>';
      this.clearSelection();
      return;
    }

    // Valutazione range temporale
    const rangeResult = this.parseDateTimeRange();
    if (!rangeResult.isValid) {
      return;
    }

    let filtered = p.Campioni.filter((s) =>
      this.filterTypes.includes(s.TipoCampione),
    );

    // Applicazione del filtro data-ora
    if (rangeResult.hasFilter) {
      filtered = filtered.filter((s) => {
        let sampleTs = 0;
        if (s.DataOra) {
          sampleTs = new Date(s.DataOra).getTime();
          if (isNaN(sampleTs)) sampleTs = 0;
        }
        return sampleTs >= rangeResult.minTs && sampleTs <= rangeResult.maxTs;
      });
    }

    this.currentFilteredSamples = filtered;
    if (filtered.length === 0) {
      container.innerHTML =
        '<div class="stats-empty-state">Nessun campione corrisponde ai filtri selezionati</div>';
      this.clearSelection();
      return;
    }

    // Risoluzione Dinamica: assorbimento al 100% dell'altezza residua con maggiore risoluzione
    const W = Math.max(760, container.clientWidth || 760);
    const containerH = container.clientHeight || 200;
    const H = Math.max(140, containerH);

    // padL calibrato a 54px per accogliere il font raddoppiato a 22px senza clipping a sinistra
    const padL = 54;
    const padR = 25;
    const padT = 16;
    const padB = 26;
    const plotW = W - padL - padR;
    const plotH = Math.max(20, H - padT - padB);

    const values = filtered.map((s) => this.getSampleVal(s));
    const maxVal = Math.max(10, Math.ceil(Math.max(...values) * 1.15));

    const pts = filtered.map((s, idx) => {
      const x = padL + (idx / Math.max(1, filtered.length - 1)) * plotW;
      const y = padT + plotH - (this.getSampleVal(s) / maxVal) * plotH;
      return { x, y, sample: s, val: this.getSampleVal(s), idx };
    });

    let pathD = "";
    pts.forEach((pt, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${pt.x},${pt.y} `;
    });

    // L'SVG scala ed occupa sempre il 100% dello spazio verticale del box
    let svg = `<svg id="speedSvgPlot" class="stats-speed-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">`;

    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="10" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    svg += `<path d="${pathD}" fill="none" stroke="#3b82f6" stroke-width="2.5" />`;
    svg += `<rect id="chartSelectionRect" x="0" y="${padT}" width="0" height="${plotH}" fill="rgba(59, 130, 246, 0.22)" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4 3" display="none" pointer-events="none" />`;
    svg += `<line id="chartCrosshairH" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2" display="none" pointer-events="none" />`;
    // Font raddoppiato a 22px con dominant-baseline="central" per perfetto allineamento ottico
    svg += `<text id="chartCrosshairYLabel" fill="#ef4444" font-size="22" font-weight="800" text-anchor="end" dominant-baseline="central" display="none" pointer-events="none"></text>`;
    svg += `<line id="chartPreviewVLine" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3" display="none" pointer-events="none" />`;

    const italianWeekDays = [
      "domenica",
      "lunedì",
      "martedì",
      "mercoledì",
      "giovedì",
      "venerdì",
      "sabato",
    ];

    pts.forEach((pt) => {
      const isSel = this.selectedSampleIndices.has(pt.sample.Index);
      const dotCls = isSel ? "speed-point selected" : "speed-point";

      // Formattazione data con giorno della settimana in italiano
      let dateFormatted = "Storico pre-v.2.30";
      if (pt.sample.DataOra) {
        const d = new Date(pt.sample.DataOra);
        if (!isNaN(d.getTime())) {
          const dayName = italianWeekDays[d.getDay()];
          const timeClean = pt.sample.DataOra.replace("T", " ");
          dateFormatted = `${dayName} ${timeClean}`;
        } else {
          dateFormatted = pt.sample.DataOra.replace("T", " ");
        }
      }

      svg += `<circle class="${dotCls}" cx="${pt.x}" cy="${pt.y}" r="${isSel ? 6 : 4}" fill="${isSel ? "#f59e0b" : "#3b82f6"}" stroke="#ffffff" stroke-width="1.5" data-idx="${pt.sample.Index}" data-val="${Math.round(pt.val)}" data-err="${pt.sample.NumErrori}" data-len="${pt.sample.NumCaratteri}" data-title="${htmlEscape(pt.sample.Esercizio || "")}" data-time="${htmlEscape(dateFormatted)}" />`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    const svgEl = document.getElementById("speedSvgPlot");
    if (!svgEl) return;

    // Helper di formattazione per lo scrubber temporale
    const formatScrubberDate = (sample) => {
      if (!sample || !sample.DataOra) return "Data non disponibile";
      const d = new Date(sample.DataOra);
      if (isNaN(d.getTime())) return "Data non disponibile";
      const dayName = italianWeekDays[d.getDay()];
      const [datePart, timePart] = sample.DataOra.split("T");
      return `${datePart} - ${timePart} ( ${dayName} )`;
    };

    const scrubberLabel = document.getElementById("lblChartScrubberTimestamp");
    if (scrubberLabel) {
      scrubberLabel.textContent = "Sposta il mouse sul grafico";
    }

    svgEl.querySelectorAll(".speed-point").forEach((dot) => {
      dot.addEventListener("mouseenter", () => {
        // Rimuove lo stato ispezionato da tutti gli altri campioni
        svgEl
          .querySelectorAll(".speed-point.inspected")
          .forEach((el) => el.classList.remove("inspected"));
        // Aggiunge priorità visiva verde al campione corrente (v.2.32)
        dot.classList.add("inspected");

        const idx = dot.getAttribute("data-idx");
        const val = dot.getAttribute("data-val");
        const err = parseInt(dot.getAttribute("data-err") || "0", 10);
        const len = parseInt(dot.getAttribute("data-len") || "0", 10);
        const title = dot.getAttribute("data-title");
        const timeStr = dot.getAttribute("data-time") || "";
        const errPct = len > 0 ? ((err / len) * 100).toFixed(1) + "%" : "0.0%";

        // Applicazione colore dinamico temattizzato (var(--success-color)) sul valore testuale (v.2.32)
        const inspectText = document.getElementById("speedInspectText");
        if (inspectText) {
          const valueSpan = document.createElement("span");
          valueSpan.className = "stats-value-success";
          valueSpan.textContent = val;
          inspectText.replaceChildren(
            document.createTextNode(`Campione #${idx} | Data: ${timeStr} | Valore: `),
            valueSpan,
            document.createTextNode(` | Errori: ${err} (${errPct}) | Caratteri: ${len} | Esercizio: "${title}"`),
          );
        }
      });
    });

    this.selectionState = 0;
    let startSvgX = 0;

    const getSvgCoords = (e) => {
      const pt = svgEl.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      return pt.matrixTransform(svgEl.getScreenCTM().inverse());
    };

    const applySelection = (selPts) => {
      this.selectedSampleIndices = new Set(selPts.map((p) => p.sample.Index));
      svgEl.querySelectorAll(".speed-point").forEach((dot) => {
        const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
        if (this.selectedSampleIndices.has(sIdx)) {
          dot.classList.add("selected");
          dot.setAttribute("fill", "#f59e0b");
          dot.setAttribute("r", "6");
        } else {
          dot.classList.remove("selected");
          dot.setAttribute("fill", "#3b82f6");
          dot.setAttribute("r", "4");
        }
      });

      if (selPts.length > 0) {
        const selVals = selPts.map((p) => p.val);
        const avg = Math.round(
          selVals.reduce((a, b) => a + b, 0) / selVals.length,
        );
        const countTxt =
          selPts.length === 1
            ? "1 campione selezionato"
            : `${selPts.length} campioni selezionati`;
        const summary = document.getElementById("lblMediaValori");
        if (summary) {
          const averageSpan = document.createElement("span");
          averageSpan.className = "stats-value-warning";
          averageSpan.textContent = String(avg);
          summary.replaceChildren(
            averageSpan,
            document.createTextNode(` (su ${countTxt})`),
          );
        }

        const btnClearSel = document.getElementById("btnClearSelection");
        const btnClearNotSel = document.getElementById("btnClearNotSelected");
        const countNot = filtered.length - selPts.length;

        if (btnClearSel) {
          btnClearSel.style.visibility = "visible";
          btnClearSel.disabled = false;
          document.getElementById("lblSelectedCount").innerText = selPts.length;
        }
        if (btnClearNotSel) {
          btnClearNotSel.style.visibility = countNot > 0 ? "visible" : "hidden";
          btnClearNotSel.disabled = countNot <= 0;
          document.getElementById("lblNotSelectedCount").innerText = countNot;
        }
      } else {
        this.clearSelection();
      }
    };

    svgEl.addEventListener("mousemove", (e) => {
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const curY = Math.max(padT, Math.min(padT + plotH, svgPt.y));

      // Stima del campione più vicino lungo l'asse X per la riga azzurra
      if (pts.length > 0 && scrubberLabel) {
        let closestPt = pts[0];
        let minDist = Math.abs(pts[0].x - curX);
        for (let i = 1; i < pts.length; i++) {
          const dist = Math.abs(pts[i].x - curX);
          if (dist < minDist) {
            minDist = dist;
            closestPt = pts[i];
          } else if (pts[i].x > curX) {
            break;
          }
        }
        scrubberLabel.textContent = formatScrubberDate(closestPt.sample);
      }

      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH && crossY) {
        const yVal = Math.round(maxVal - ((curY - padT) / plotH) * maxVal);
        crossH.setAttribute("x1", padL);
        crossH.setAttribute("y1", curY);
        crossH.setAttribute("x2", W - padR);
        crossH.setAttribute("y2", curY);
        crossH.style.display = "block";

        crossY.setAttribute("x", padL - 8);
        crossY.setAttribute("y", curY);
        crossY.textContent = yVal;
        crossY.style.display = "block";
      }

      const vLine = document.getElementById("chartPreviewVLine");
      const selRect = document.getElementById("chartSelectionRect");

      if (this.selectionState === 0) {
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      } else if (this.selectionState === 1) {
        if (vLine) vLine.style.display = "none";
        const minX = Math.max(padL, Math.min(startSvgX, curX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, curX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(2, selW));
          selRect.style.display = "block";
        }

        let previewPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          previewPts = [closest];
        } else {
          previewPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        svgEl.querySelectorAll(".speed-point").forEach((dot) => {
          const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
          if (previewPts.some((p) => p.sample.Index === sIdx)) {
            dot.setAttribute("fill", "#f59e0b");
            dot.setAttribute("r", "6");
          } else {
            dot.setAttribute("fill", "#3b82f6");
            dot.setAttribute("r", "4");
          }
        });
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      const vLine = document.getElementById("chartPreviewVLine");
      if (vLine && this.selectionState === 0) vLine.style.display = "none";

      if (scrubberLabel) {
        scrubberLabel.textContent = "Sposta il mouse sul grafico";
      }

      // Ripristino stato ispezionato e testuale all'uscita dal grafico (v.2.32)
      svgEl
        .querySelectorAll(".speed-point.inspected")
        .forEach((el) => el.classList.remove("inspected"));
      const inspectText = document.getElementById("speedInspectText");
      if (inspectText) {
        inspectText.textContent =
          "Passa con il mouse sui campioni per le coordinate";
      }
    });

    svgEl.addEventListener("click", (e) => {
      if (e.button !== 0) return;
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const selRect = document.getElementById("chartSelectionRect");
      const vLine = document.getElementById("chartPreviewVLine");

      if (this.selectionState === 0) {
        this.selectionState = 1;
        startSvgX = curX;
        if (vLine) vLine.style.display = "none";
        if (selRect) {
          selRect.setAttribute("x", startSvgX);
          selRect.setAttribute("width", 2);
          selRect.style.display = "block";
        }
        const summary = document.getElementById("lblMediaValori");
        if (summary) {
          const hint = document.createElement("span");
          hint.className = "stats-hint-blue";
          hint.textContent = "Seleziona il secondo punto...";
          summary.replaceChildren(hint);
        }
      } else if (this.selectionState === 1) {
        this.selectionState = 2;
        const endSvgX = curX;
        const minX = Math.max(padL, Math.min(startSvgX, endSvgX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, endSvgX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(4, selW));
          selRect.style.display = "block";
        }

        let selPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          selPts = [closest];
          if (selRect) {
            selRect.setAttribute("x", closest.x - 8);
            selRect.setAttribute("width", 16);
          }
        } else {
          selPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        applySelection(selPts);
      } else if (this.selectionState === 2) {
        this.selectionState = 0;
        this.clearSelection();
        if (selRect) selRect.style.display = "none";
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      }
    });

    if (this.selectedSampleIndices.size === 0) {
      const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
      document.getElementById("lblMediaValori").innerText =
        `${avg} (globale su ${values.length} campioni)`;
    }
  }
```

## AppController.showLoginModal()

- **Baseline v6.23:** `js/app/controller/metodi-profili-modali.js`, riga 4
- **Nuova versione v6.24:** `js/app/controller/metodi-profili-modali.js`, riga 4

```javascript
showLoginModal() {
      const modal = document.getElementById("loginModal");
      const select = document.getElementById("loginUserSelect");
      const input = document.getElementById("loginNewUserInput");
      if (!modal || !select || !input) return;

      const users = this.profileMgr.getUsers();
      select.replaceChildren();

      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "-- Seleziona Utente Esistente --";
      select.appendChild(placeholder);

      users.forEach((userName) => {
        const option = document.createElement("option");
        option.value = userName;
        option.textContent = userName;
        select.appendChild(option);
      });

      if (
        this.profileMgr.activeUser &&
        users.includes(this.profileMgr.activeUser)
      ) {
        select.value = this.profileMgr.activeUser;
      } else {
        select.value = "";
      }
      input.value = "";
      this.windowMgr?.bringModalToFront(modal);
      modal.classList.add("active");
    }
```

## AppController.updateOriginDisplay()

- **Baseline v6.23:** `js/app/controller/metodi-rendering-guida.js`, riga 65
- **Nuova versione v6.24:** `js/app/controller/metodi-rendering-guida.js`, riga 65

```javascript
// =======================================================
  // AGGIORNAMENTO DISPLAY TESTO GUIDA CON AUTO-SCROLL
  // =======================================================
  updateOriginDisplay() {
    const container = document.getElementById("originTextWrapper");
    const badge = document.getElementById("charTargetBadge");
    if (!container) return;

    if (this.typingEng.mode === 4) {
      container.innerHTML =
        '<span class="guide-free-mode-message">Digitazione libera in corso...</span>';
      if (badge) {
        badge.innerText = "LIBERA";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
      return;
    }

    const origin = this.typingEng.originText;
    const typed = this.typingEng.typedText;

    const matchLen = this.typingEng.getMatchLength();

    const partOk = origin.slice(0, matchLen);
    const numErrors = typed.length - matchLen;

    let guideHtml = "";
    if (partOk) {
      guideHtml += `<span class="char-typed-ok">${this.renderGuideSegment(partOk)}</span>`;
    }

    if (numErrors === 0) {
      if (matchLen < origin.length) {
        const targetChar = origin[matchLen];
        guideHtml += `<span class="char-current-target" id="currentTargetCharSpan">${this.renderGuideSegment(targetChar)}</span>`;
        const partRest = origin.slice(matchLen + 1);
        if (partRest) {
          guideHtml += `<span class="char-remaining">${this.renderGuideSegment(partRest)}</span>`;
        }
      }
    } else {
      const remainingChars = origin.slice(matchLen);
      let errorSubstring = "";
      let remainingAfterErrors = "";

      if (numErrors <= remainingChars.length) {
        errorSubstring = remainingChars.slice(0, numErrors);
        remainingAfterErrors = remainingChars.slice(numErrors);
      } else {
        const excess = numErrors - remainingChars.length;
        errorSubstring = remainingChars + " ".repeat(excess);
        remainingAfterErrors = "";
      }

      guideHtml += `<span class="char-error-target" id="currentTargetCharSpan">${this.renderGuideSegment(errorSubstring)}</span>`;

      if (remainingAfterErrors) {
        guideHtml += `<span class="char-remaining">${this.renderGuideSegment(remainingAfterErrors)}</span>`;
      }
    }

    container.innerHTML = guideHtml;

    // Auto-scroll per garantire la costante visibilità del carattere bersaglio
    const targetSpan = document.getElementById("currentTargetCharSpan");
    if (targetSpan) {
      const spanTop = targetSpan.offsetTop;
      const spanHeight = targetSpan.offsetHeight;
      const contHeight = container.clientHeight;
      if (
        spanTop + spanHeight > container.scrollTop + contHeight ||
        spanTop < container.scrollTop
      ) {
        container.scrollTop = Math.max(
          0,
          spanTop - Math.round(contHeight / 2) + Math.round(spanHeight / 2),
        );
      }
    }

    const targetChar = origin[matchLen] || "";
    if (badge) {
      if (this.typingEng.isCompleted) {
        badge.innerText = "FINITO";
        badge.style.background = "var(--success-bg)";
        badge.style.color = "var(--success-color)";
      } else if (numErrors > 0) {
        badge.innerText = "CORREGGI ⌫";
        badge.style.background = "#ef4444";
        badge.style.color = "#ffffff";
      } else if (targetChar === "®" || targetChar === "\n") {
        badge.innerText = "INVIO ↵";
        badge.style.background = "#059669";
        badge.style.color = "#ffffff";
      } else if (targetChar === "→" || targetChar === "\t") {
        badge.innerText = "TAB ⇥";
        badge.style.background = "#2563eb";
        badge.style.color = "#ffffff";
      } else if (targetChar === " ") {
        badge.innerText = "SPAZIO";
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else if (targetChar) {
        badge.innerText = targetChar;
        badge.style.background = "var(--accent-color)";
        badge.style.color = "#ffffff";
      } else {
        badge.innerText = "—";
        badge.style.background = "var(--surface-alt)";
        badge.style.color = "var(--text-muted)";
      }
    }
  }
```

## AppController.renderInstantSpeedChart()

- **Baseline v6.23:** `js/app/controller/metodi-statistiche.js`, riga 287
- **Nuova versione v6.24:** `js/app/controller/metodi-statistiche.js`, riga 287

```javascript
// =======================================================
  // CLASSE: AppController (metodi-statistiche.js)
  // METODO: renderInstantSpeedChart() - Release v6.4
  // CONTESTO: Rendering tachimetrico SVG con formule esatte per Media Netta e Lorda,
  // font maggiorati e ancoraggio dinamico delle etichette alla viewport visibile.
  // =======================================================
  renderInstantSpeedChart() {
    const win = document.getElementById("instantSpeedFloatingWindow");
    if (!win || !win.classList.contains("window-visible")) return;

    const container = document.getElementById("instantSpeedSvgBox");
    if (!container) return;

    const pts = this.typingEng.instantSpeedPoints || [];
    if (pts.length === 0) {
      container.innerHTML =
        '<div class="instant-speed-empty-state">Inizia a digitare per visualizzare la velocità istantanea</div>';
      return;
    }

    const containerW = container.clientWidth || 800;
    const containerH = container.clientHeight || 240;
    const height = Math.max(180, containerH);

    const padL = 60;
    const padR = 30;
    const padT = 32;
    // Margine inferiore maggiorato a 112px per accogliere i font ingranditi e i tempi verticali
    const padB = 112;
    const plotH = Math.max(30, height - padT - padB);

    const pitch = 30;
    const width = Math.max(containerW, padL + padR + pts.length * pitch);

    // =========================================================================
    // CALCOLO ESATTO MEDIE CUMULATIVE (Release v6.4)
    // Media Netta = (N. caratteri corretti * 60) / tempo_trascorso_secondi
    // Media Lorda = (N. caratteri totali * 60) / tempo_trascorso_secondi
    // =========================================================================
    const lastPt = pts[pts.length - 1];
    const elapsedSeconds = lastPt && lastPt.elapsedMs > 0 ? lastPt.elapsedMs / 1000 : 0;
    const correctCount = pts.filter((p) => p.type === "correct").length;
    const totalCount = pts.length;

    const avgCorrectBpm = elapsedSeconds > 0 ? Math.round((correctCount * 60) / elapsedSeconds) : 0;
    const avgAllBpm = elapsedSeconds > 0 ? Math.round((totalCount * 60) / elapsedSeconds) : 0;

    const maxBpmSample = Math.max(...pts.map((p) => p.movingAvgBpm || 0));
    const maxVal = Math.max(120, Math.ceil(Math.max(maxBpmSample, avgAllBpm, avgCorrectBpm) * 1.25));

    const coords = pts.map((pt, idx) => {
      const cx = padL + idx * pitch;
      const cy = padT + plotH - Math.round(((pt.movingAvgBpm || 0) / maxVal) * plotH);
      return { cx, cy, pt, idx };
    });

    let pathD = "";
    coords.forEach((c, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${c.cx},${c.cy} `;
    });

    let svg = `<svg id="instantSpeedSvgPlot" class="instant-speed-svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;

    // Griglia orizzontale e quote numeriche asse Y
    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${width - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="11" font-weight="700" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    // Linea orizzontale media cumulativa lorda (Arancione) con font maggiorato a 15px
    if (avgAllBpm > 0) {
      const yAvgAll = padT + plotH - (avgAllBpm / maxVal) * plotH;
      svg += `<line id="instantLineAvgAll" x1="${padL}" y1="${yAvgAll}" x2="${width - padR}" y2="${yAvgAll}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="6 3" />`;
      svg += `<text id="instantTextAvgAll" x="${width - padR}" y="${yAvgAll - 6}" font-size="15" font-weight="900" text-anchor="end" fill="#f59e0b" class="instant-speed-average-label">Media Lorda: ${avgAllBpm} BPM</text>`;
    }

    // Linea orizzontale media cumulativa netta (Verde) con font maggiorato a 15px
    if (avgCorrectBpm > 0) {
      const yAvgCorrect = padT + plotH - (avgCorrectBpm / maxVal) * plotH;
      svg += `<line id="instantLineAvgCorrect" x1="${padL}" y1="${yAvgCorrect}" x2="${width - padR}" y2="${yAvgCorrect}" stroke="#10b981" stroke-width="2" stroke-dasharray="6 3" />`;
      svg += `<text id="instantTextAvgCorrect" x="${padL + 8}" y="${yAvgCorrect - 6}" font-size="15" font-weight="900" text-anchor="start" fill="#10b981" class="instant-speed-average-label">Media Netta: ${avgCorrectBpm} BPM</text>`;
    }

    // Curva continua di connessione dei campioni
    if (coords.length > 1) {
      svg += `<path d="${pathD}" fill="none" stroke="#38bdf8" stroke-width="2.5" stroke-linejoin="round" />`;
    }

    // Elementi interattivi crosshair con font maggiorati e contorno ad alto risalto
    svg += `<line id="instantCrossH" stroke="#ef4444" stroke-width="1.8" stroke-dasharray="4 2" display="none" pointer-events="none" />`;
    svg += `<text id="instantCrossYLabel" fill="#ef4444" font-size="18" font-weight="900" text-anchor="start" dominant-baseline="central" display="none" pointer-events="none" class="instant-speed-crosshair-label"></text>`;
    svg += `<line id="instantCrossV" stroke="#38bdf8" stroke-width="1.8" stroke-dasharray="3 3" display="none" pointer-events="none" />`;
    svg += `<text id="instantCrossXLabel" fill="#38bdf8" font-size="16" font-weight="900" text-anchor="middle" display="none" pointer-events="none" class="instant-speed-crosshair-label"></text>`;

    // Punti, Glifi tasto (18px) e Timestamp verticali sss.mmm (13px)
    const chartBaseline = padT + plotH;
    coords.forEach((c) => {
      let dotColor = "#10b981"; // Verde se corretto
      if (c.pt.type === "error") dotColor = "#ef4444"; // Rosso se errato
      if (c.pt.type === "back") dotColor = "#f59e0b"; // Arancione se Backspace

      svg += `<circle class="instant-speed-dot" cx="${c.cx}" cy="${c.cy}" r="5" fill="${dotColor}" stroke="#ffffff" stroke-width="1.8" data-char="${htmlEscape(c.pt.char)}" data-bpm="${c.pt.movingAvgBpm}" data-time="${(c.pt.elapsedMs / 1000).toFixed(3)}" />`;

      // Singolo glifo del tasto in ascissa ingrandito a 18px bold
      svg += `<text x="${c.cx}" y="${chartBaseline + 20}" font-size="18" font-weight="900" text-anchor="middle" fill="var(--text-main)">${htmlEscape(c.pt.char)}</text>`;

      // Timestamp sss.mmm verticale ruotato di 90° antiorari ingrandito a 13px bold
      const timeFmt = (c.pt.elapsedMs / 1000).toFixed(3);
      const textX = c.cx;
      const textY = chartBaseline + 34;
      svg += `<text x="${textX}" y="${textY}" font-family="var(--font-mono)" font-size="13" font-weight="700" fill="var(--text-muted)" text-anchor="end" transform="rotate(-90, ${textX}, ${textY})">${timeFmt}</text>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    // Auto-scroll automatico verso destra per inquadrare la battuta più recente
    container.scrollLeft = container.scrollWidth;

    const svgEl = document.getElementById("instantSpeedSvgPlot");
    if (!svgEl) return;

    // Helper per mantenere le etichette delle medie sempre visibili nella porzione di finestra visualizzata
    const updateStickyLabels = () => {
      const scrollX = container.scrollLeft;
      const visibleW = container.clientWidth;
      const textNet = document.getElementById("instantTextAvgCorrect");
      const textGross = document.getElementById("instantTextAvgAll");

      if (textNet) {
        textNet.setAttribute("x", scrollX + padL + 8);
      }
      if (textGross) {
        textGross.setAttribute("x", Math.min(width - padR, scrollX + visibleW - 16));
      }
    };

    updateStickyLabels();
    container.onscroll = updateStickyLabels;

    // Crosshair interattivo vincolato alla porzione visibile della finestra
    svgEl.addEventListener("mousemove", (e) => {
      const rect = svgEl.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;

      const crossH = document.getElementById("instantCrossH");
      const crossY = document.getElementById("instantCrossYLabel");
      const crossV = document.getElementById("instantCrossV");
      const crossX = document.getElementById("instantCrossXLabel");

      const scrollX = container.scrollLeft;
      const visibleW = container.clientWidth;

      if (crossH && crossY) {
        const boundedY = Math.max(padT, Math.min(padT + plotH, mouseY));
        const bpmVal = Math.round(maxVal - ((boundedY - padT) / plotH) * maxVal);

        // La linea orizzontale attraversa l'intera porzione attualmente visibile
        crossH.setAttribute("x1", scrollX);
        crossH.setAttribute("y1", boundedY);
        crossH.setAttribute("x2", scrollX + visibleW);
        crossH.setAttribute("y2", boundedY);
        crossH.style.display = "block";

        // Il testo del valore BPM rimane sempre agganciato al bordo sinistro visibile
        crossY.setAttribute("x", scrollX + 8);
        crossY.setAttribute("y", boundedY);
        crossY.textContent = `${bpmVal} BPM`;
        crossY.style.display = "block";
      }

      if (crossV && crossX && coords.length > 0) {
        let closest = coords[0];
        let minDist = Math.abs(coords[0].cx - mouseX);
        for (let i = 1; i < coords.length; i++) {
          const d = Math.abs(coords[i].cx - mouseX);
          if (d < minDist) {
            minDist = d;
            closest = coords[i];
          }
        }

        crossV.setAttribute("x1", closest.cx);
        crossV.setAttribute("y1", padT);
        crossV.setAttribute("x2", closest.cx);
        crossV.setAttribute("y2", chartBaseline);
        crossV.style.display = "block";

        // Il testo in alto viene mantenuto all'interno dei limiti orizzontali visibili
        const minTextX = scrollX + 90;
        const maxTextX = scrollX + visibleW - 90;
        const clampedX = Math.max(minTextX, Math.min(maxTextX, closest.cx));

        crossX.setAttribute("x", clampedX);
        crossX.setAttribute("y", padT - 10);
        crossX.textContent = `T: ${(closest.pt.elapsedMs / 1000).toFixed(3)} s | ${closest.pt.movingAvgBpm} BPM`;
        crossX.style.display = "block";
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("instantCrossH");
      const crossY = document.getElementById("instantCrossYLabel");
      const crossV = document.getElementById("instantCrossV");
      const crossX = document.getElementById("instantCrossXLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      if (crossV) crossV.style.display = "none";
      if (crossX) crossX.style.display = "none";
    });
  }
```

## ProfileManager.createUser()

- **Baseline v6.23:** `js/profiles/profile-manager.js`, riga 292
- **Nuova versione v6.24:** `js/profiles/profile-manager.js`, riga 292

```javascript
createUser(userId) {
    const trimmed = userId.trim();
    if (!trimmed) return null;
    const users = this.getUsers();
    if (!users.includes(trimmed)) {
      users.push(trimmed);
      this.saveUsers(users);
    }
    this.profile = {
      UserID: trimmed,
      Mode: 0,
      Lesson: 1,
      Exercise: 0,
      AutomaticCorrection: false,
      ShowKeyBoard: true,
      ShowHands: true,
      ShowOrigin: true,
      ShowTyped: true,
      ShowErrors: true,
      ShowInstantSpeed: false,
      UseKeyPositions: false,
      UseCustomKeyDistances: false,
      Theme: "theme-dark",
      AudioMode: "typewriter",
      AudioVolume: 0.7,
      DictationEnabled: false,
      DictationSpeed: 0.9,
      DictationCaps: false,
      DictationApostrophe: false,
      DictationSpelling: false,
      DictationSpace: false,
      DictationAdaptive: false,
      DictationMinCpm: 100,
      DictationMaxCpm: 200,
      DictationStallBaseDelay: 1.5,
      DictationStallLongDelay: 3.5,
      DictationStallSpeedFactor: 1.0,
      HandsTop: 120,
      HandsLeft: 956,
      HandsWidth: 460,
      HandsHeight: 286,
      HandsPinned: true,
      HandsOffsetTop: 45,
      StatTop: 95,
      StatLeft: 630,
      StatWidth: 820,
      StatHeight: 548,
      InstantSpeedTop: 120,
      InstantSpeedLeft: 10,
      InstantSpeedWidth: 1240,
      InstantSpeedHeight: 340,
      InstantSpeedPinned: true,
      InstantSpeedOffsetTop: 16,
      InstantSpeedMovingAvgWindow: 3,
      ZoomLevel: 1.0,
      CustomText: this.defaultCustomText,
      FonemiCustomText: "",
      FonemiNgramLength: 4, // Default N=4 (Release v.4.4)
      FonemiTargetLength: 100, // Default 100 (Release v6.11)
      FonemiOptions: {
        customFile: false,
        maiuscole: false,
        punteggiatura: false,
        parentesi: false,
        numeri: false,
        matematici: false,
        simboli: false,
        layout: false,
      },
      FonemiProbabilities: {
        maiuscole: 0.3,
        allMaiuscole: 0.3,
        punteggiatura: 0.3,
        parentesi: 0.3,
        numeri: 0.3,
        matematici: 0.3,
        simboli: 0.3,
        layout: 0.3,
      },
      TotaleCaratteri: 0,
      TotaleErrori: 0,
      Caratteri: [],
      Campioni: [],
    };
    this.activeUser = trimmed;
    this._safeSetItem(this.STORAGE_KEY_ACTIVE, trimmed);
    this.saveProfile();
    return this.profile;
  }
```

## ProfileManager.saveProfile()

- **Baseline v6.23:** `js/profiles/profile-manager.js`, riga 409
- **Nuova versione v6.24:** `js/profiles/profile-manager.js`, riga 409

```javascript
saveProfile() {
    if (this.activeUser && this.profile) {
      this.profile.AppVersion = "6.24";
      return this._safeSetItem(
        this.STORAGE_PREFIX + this.activeUser,
        JSON.stringify(this.profile),
      );
    }
    return false;
  }
```

## AppController.constructor()

- **Baseline v6.23:** `js/app/controller/controller-core.js`, riga 6
- **Nuova versione v6.24:** `js/app/controller/controller-core.js`, riga 6

```javascript
constructor(lessons, demoProfile, customDefault, fonemiCorpus) {
    this.version = "6.24"; // Versione applicativa runtime (Release v6.24)
    window.APP_VERSION = "6.24";
    this.currentZoom = 1.0; // Livello di zoom applicativo (Release v6.9)
    this.standardLessons = lessons || [];
    this.customLessons = [];
    this.activeLessonsSource = "standard";
    this.lessons = this.standardLessons;
    this.profileMgr = new ProfileManager(demoProfile, customDefault);
    this.audio = new AudioEngine();
    this.phonemeEng = new PhonemeEngine(fonemiCorpus);
    this.dictation = new DictationEngine();
    this.typingEng = new TypingEngine(
      this.lessons,
      this.profileMgr,
      this.audio,
      this.phonemeEng,
    );
    this.visual = new VisualRenderer();
    this.windowMgr = new WindowManager();
    this.statsMgr = new StatisticsManager(this.profileMgr);
    this.prevStatsRect = null;
    this._wrongBadgeTimer = null;

    this.modifierSession = {
      activeModifiers: new Set(),
      expectedModsActive: new Set(),
      shortcutExecuted: false,
      abandonErrorReported: false,
    };
  }
```

## Modifiche non riconducibili a metodi

- Versione applicativa: `window.APP_VERSION`, `AppController.version`, `ProfileManager.createUser().AppVersion` e `ProfileManager.saveProfile().AppVersion` aggiornati a `6.24`. Le assegnazioni sono incluse nei metodi pertinenti sopra.
- `index.html` e `help.html`: CSP, referrer policy, script locali e rimozione degli attributi inline.
- `assets/styles/app.css` e `assets/styles/help.css`: stili estratti e classi per markup dinamico.
- Nuovo file `js/security/network-isolation-guard.js`: guard runtime locale completo, incluso nella release.
- `js/ui/help.js`: script della guida estratto dal documento HTML.
- Test, manuale, Help, changelog, architettura e build manifest aggiornati.
