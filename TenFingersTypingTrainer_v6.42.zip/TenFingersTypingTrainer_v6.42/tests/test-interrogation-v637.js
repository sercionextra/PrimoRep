#!/usr/bin/env node
"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const uiJs = fs.readFileSync(path.join(root, "js/ui/interrogation-ui.js"), "utf8");

// 1. Verifica CSS: larghezza popover 780px, righe centrate e #target in grassetto
assert(css.includes("width: min(780px, 96vw);"), "Popover ASCII deve avere width: min(780px, 96vw)");
const rowCss = css.match(/\.interr-ascii-row\s*\{[\s\S]*?\}/);
assert(rowCss && rowCss[0].includes("justify-content: center;"), ".interr-ascii-row deve avere justify-content: center;");
const targetCss = css.match(/#target\s*\{[\s\S]*?\}/);
assert(targetCss && targetCss[0].includes("font-weight: bold;"), "#target deve avere font-weight: bold");
assert(uiJs.includes('btnStart.classList.toggle("is-blocked", !!suspended)'), "showSetupView deve marcare btnStartInterrogation come is-blocked se esiste una sessione sospesa");

// 2. Verifica runtime: createSession rifiuta avvio se esiste una sessione sospesa, e consente dopo abbandono
const ctx = {
  document: { getElementById: () => null },
  crypto: require("crypto").webcrypto,
  TextEncoder,
  Uint8Array,
  console,
  Math,
  Date,
  JSON,
  Set,
  Map,
};
ctx.window = ctx;
ctx.window.addEventListener = () => {};
ctx.globalThis = ctx;
vm.createContext(ctx);
[
  "js/data/interrogation-catalog-data.js",
  "js/interrogation/interrogation-layout-metadata.js",
  "js/interrogation/interrogation-catalog.js",
  "js/interrogation/interrogation-prng.js",
  "js/interrogation/interrogation-repository.js",
  "js/interrogation/interrogation-selector.js",
  "js/interrogation/interrogation-session-manager.js",
].forEach((rel) => {
  vm.runInContext(fs.readFileSync(path.join(root, rel), "utf8"), ctx, { filename: rel });
});

(async () => {
  const catalog = new ctx.InterrogationCatalog();
  const repo = new ctx.InterrogationRepository({ useMemory: true });
  const mgr = new ctx.InterrogationSessionManager({ catalog, repository: repo });

  const s1 = await mgr.createSession({
    profileId: "u_susp",
    mode: "random",
    questionTypes: ["CARATTERE"],
    requestedCount: 1,
  });
  await mgr.suspendSession("u_susp", s1.session.sessionId);

  let blocked = false;
  try {
    await mgr.createSession({
      profileId: "u_susp",
      mode: "random",
      questionTypes: ["CARATTERE"],
      requestedCount: 1,
    });
  } catch (err) {
    blocked = err && /sospesa/i.test(err.message);
  }
  assert(blocked, "createSession deve bloccare l'avvio di una nuova sessione se ne esiste una sospesa");

  await mgr.abandonSession("u_susp", s1.session.sessionId);
  const s2 = await mgr.createSession({
    profileId: "u_susp",
    mode: "random",
    questionTypes: ["CARATTERE"],
    requestedCount: 1,
  });
  assert(s2 && s2.session && s2.session.status === "in-progress", "Dopo l'abbandono deve essere possibile avviare una nuova sessione");

  console.log("PASS: Tutte le verifiche v6.37 superate.");
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
