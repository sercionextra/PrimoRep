# Architettura TenFingersTypingTrainer v6.32

## Panoramica delle modifiche rispetto alla v6.31

1. **Fix `_activeRunLandmarkClickHandler` (`InterrogationUI._renderCharacterQuestionPanel`):**
   - Corretta la chiamata errata `meta.getKeyExtensions(info.keyId)` in `meta.getKeyExtension(resolvedKeyId)` (con fallback `meta.resolveKeyIdFromToken(info.keyLabel)`), ripristinando la valorizzazione automatica di `selLatExt`, `selLatDir` e `selLongExt` al click sui pallini delle mani nei quesiti `CARATTERE`/`TASTO`.

2. **Riordino UI Blocco 1 (`InterrogationUI._renderCharacterQuestionPanel`):**
   - `leftCol`: `Mano`, `Dito`, `Direzione sovraccarico`, `Estensione laterale`.
   - `rightCol`: `Estensione longitudinale`, `Accordo Modificatore`, `Conferma Accordo` / `Consulta (+1)`.

3. **Chiusura automatica con riepilogo (`InterrogationUI`):**
   - Introdotto `_buildSessionSummaryAlertText(session, prefixText)` per formattare punteggio, massimo conseguibile, percentuale e conteggi (`Corrette`, `Errate`, `Consultate`, `Ignorate`).
   - `handleComplete()`, `handleSuspend()` e `handleAbandonActive()` chiudono `#interrogationModal` tramite `this.close()` e invocano `this.showAlert(...)` con il riepilogo sintetico.
