/* TenFingersTypingTrainer v6.0 — AppController: profiles. Metodi estratti mantenendo corpi e ordine della v5.1. */
(() => {
  const controllerMethods = {
    showLoginModal() {
      const modal = document.getElementById("loginModal");
      const select = document.getElementById("loginUserSelect");
      const input = document.getElementById("loginNewUserInput");
      if (!modal || !select || !input) return;

      const users = this.profileMgr.getUsers();
      select.innerHTML =
        '<option value="">-- Seleziona Utente Esistente --</option>';
      users.forEach((u) => {
        select.innerHTML += `<option value="${htmlEscape(u)}">${htmlEscape(u)}</option>`;
      });

      if (
        this.profileMgr.activeUser &&
        users.includes(this.profileMgr.activeUser)
      ) {
        select.value = this.profileMgr.activeUser;
      } else {
        select.value = "";
      }
      input.value = "";
      modal.classList.add("active");
    },

    showSelectPhraseModal() {
      const modal = document.getElementById("selectPhraseModal");
      const lessonSelect = document.getElementById("selSelectPhraseLesson");
      const numInput = document.getElementById("txtSelectPhraseNum");
      const rangeLabel = document.getElementById("lblSelectPhraseRange");
      if (!modal || !lessonSelect || !numInput) return;

      const lessons = this.typingEng.lessons || [];
      if (lessons.length === 0) return;

      lessonSelect.innerHTML = "";
      lessons.forEach((les, idx) => {
        const opt = document.createElement("option");
        opt.value = String(idx);
        opt.textContent = `${idx + 1}. ${les.name || les.title || "Lezione " + (idx + 1)}`;
        lessonSelect.appendChild(opt);
      });

      const currentLessonIdx = this.typingEng.currentLessonIdx || 0;
      lessonSelect.value = String(currentLessonIdx);

      const updateRange = () => {
        const lesIdx = parseInt(lessonSelect.value, 10);
        const chosenLesson = lessons[lesIdx] || lessons[0];
        const phrases = chosenLesson?.phrases || [];
        const totalPhrases = Math.max(1, phrases.length);

        if (rangeLabel) {
          rangeLabel.innerText = `Numero Frase consentito (da 1 a ${totalPhrases}):`;
        }
        numInput.min = "1";
        numInput.max = String(totalPhrases);

        if (lesIdx === currentLessonIdx) {
          numInput.value = String((this.typingEng.currentPhraseIdx || 0) + 1);
        } else {
          numInput.value = "1";
        }
      };

      lessonSelect.onchange = updateRange;
      updateRange();

      modal.classList.add("active");
      setTimeout(() => {
        numInput.focus();
        numInput.select();
      }, 50);
    },

    confirmSelectPhrase() {
      const modal = document.getElementById("selectPhraseModal");
      const lessonSelect = document.getElementById("selSelectPhraseLesson");
      const numInput = document.getElementById("txtSelectPhraseNum");
      if (!modal || !numInput) return;

      const lessons = this.typingEng.lessons || [];
      const lesIdx = lessonSelect
        ? parseInt(lessonSelect.value, 10)
        : this.typingEng.currentLessonIdx;
      const chosenLesson = lessons[lesIdx] || lessons[0];
      const phrases = chosenLesson?.phrases || [];
      const totalPhrases = phrases.length;
      const val = parseInt(numInput.value, 10);

      if (!isNaN(val) && val >= 1 && val <= totalPhrases) {
        this.typingEng.currentLessonIdx = lesIdx;
        this.typingEng.currentPhraseIdx = val - 1;

        const toolbarLesson =
          document.getElementById("cboLessons") ||
          document.getElementById("selLesson");
        if (toolbarLesson) {
          toolbarLesson.value = String(lesIdx);
        }

        this.startExercise();
        modal.classList.remove("active");
        setTimeout(() => {
          this.returnFocusToTyping();
        }, 50);
      } else {
        numInput.classList.add("error-active");
        setTimeout(() => numInput.classList.remove("error-active"), 300);
      }
    },

    setupSelectPhraseModal() {
      const modal = document.getElementById("selectPhraseModal");
      const numInput = document.getElementById("txtSelectPhraseNum");
      const lessonSelect = document.getElementById("selSelectPhraseLesson");
      const btnConfirm = document.getElementById("btnConfirmSelectPhrase");
      const btnCancel = document.getElementById("btnCancelSelectPhrase");
      const btnClose = document.getElementById("btnCloseSelectPhraseModal");

      const closeModal = () => {
        if (modal) modal.classList.remove("active");
        this.startExercise();
      };

      btnConfirm?.addEventListener("click", () => this.confirmSelectPhrase());
      btnCancel?.addEventListener("click", closeModal);
      btnClose?.addEventListener("click", closeModal);

      numInput?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          this.confirmSelectPhrase();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closeModal();
        }
      });

      lessonSelect?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          this.confirmSelectPhrase();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closeModal();
        }
      });

      // Chiusura globale da tastiera con tasto Escape
      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal?.classList.contains("active")) {
          closeModal();
        }
      });

      modal?.addEventListener("click", (e) => {
        if (e.target === modal) closeModal();
      });

      document
        .getElementById("btnSelectPhraseModal")
        ?.addEventListener("click", () => {
          if (![1, 2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
            this.showSelectPhraseModal();
          } else {
            this.notifyShortcutDisabled(
              "Selezione frase non disponibile in questa modalità",
            );
          }
        });

      document
        .getElementById("lblPhraseRange")
        ?.addEventListener("click", () => {
          if (![1, 2, 3, 4, 5, 6].includes(this.typingEng.mode)) {
            this.showSelectPhraseModal();
          }
        });
    },

    // Ripristina all'istante la geometria e il posizionamento standard di tutte le finestre fluttuanti (v.4.2)
    resetAllWindowLayouts() {
      // 1. Ripristino Finestra Mani ("10 Fingers")
      this.resetHandsDefaultPosition();

      // 2. Ripristino Finestra Statistiche
      const statsWin = document.getElementById("statsFloatingWindow");
      const btnMax = document.getElementById("btnStatsMaximize");
      if (statsWin) {
        statsWin.classList.remove("window-fullscreen");
        document.body.style.overflow = "";
        statsWin.style.left = "180px";
        statsWin.style.top = "80px";
        statsWin.style.width = "820px";
        statsWin.style.height = "600px";
        statsWin.style.maxWidth = "95vw";
        if (btnMax) {
          btnMax.innerText = "⛶ Ingrandisci";
          btnMax.title = "Massimizza / Schermo intero (o ripristina)";
        }
        this.windowMgr.clampWindowToViewport(statsWin, false);

        if (this.profileMgr?.profile) {
          this.profileMgr.profile.StatLeft = 180;
          this.profileMgr.profile.StatTop = 80;
          this.profileMgr.profile.StatWidth = 820;
          this.profileMgr.profile.StatHeight = 600;
        }
      }

      // 3. Ripristino Finestra Editor Frasi Personalizzate
      const customWin = document.getElementById("customEditorWindow");
      if (customWin) {
        customWin.style.left = "240px";
        customWin.style.top = "120px";
        customWin.style.width = "680px";
        customWin.style.height = "480px";
        customWin.style.minWidth = "650px";
        customWin.style.minHeight = "360px";
        this.windowMgr.clampWindowToViewport(customWin, false);
      }

      // 4. Ripristino Finestra Velocità Istantanea (Release v6.3)
      if (typeof this.resetInstantSpeedDefaultPosition === "function") {
        this.resetInstantSpeedDefaultPosition();
      }

      // 5. Ripristino pulito dello stile di zoom (Release v6.10)
      if (typeof this.applyZoom === "function") {
        this.applyZoom();
      } else if (typeof document !== "undefined" && document.body) {
        document.body.style.zoom = "";
      }

      // 6. Salvataggio atomico delle impostazioni nel profilo
      if (this.profileMgr?.profile) {
        this.profileMgr.saveProfile();
      }

      // 7. Notifica visiva di conferma
      this.showAppAlert(
        "Le posizioni e le dimensioni di tutte le finestre fluttuanti (Mani, Statistiche, Editor Custom, Velocità Istantanea) sono state ripristinate ai valori predefiniti all'interno dello schermo.",
        "🪟 Reset Layout Finestre",
      );
    },

    setupLoginModal() {
      const modal = document.getElementById("loginModal");
      const select = document.getElementById("loginUserSelect");
      const input = document.getElementById("loginNewUserInput");
      const btnEnter = document.getElementById("btnLoginEnter");
      const btnDelete = document.getElementById("btnLoginDelete");
      const btnResetArchive = document.getElementById("btnResetDefaultArchive");
      const btnClose = document.getElementById("btnLoginClose");

      // Controlli Backup, Ripristino e Reset Layout (v.4.2)
      const btnExport = document.getElementById("btnExportProfile");
      const btnImport = document.getElementById("btnImportProfile");
      const importInput = document.getElementById("statsImportInput");
      const btnResetLayout = document.getElementById("btnResetWindowsLayout");

      const closeModal = () => {
        // Barriera: impossibile uscire senza un utente loggato
        if (!this.profileMgr.activeUser) {
          this.showAppAlert(
            "È obbligatorio selezionare o creare un utente per accedere all'applicazione.",
            "⚠ Accesso Richiesto",
          );
          return;
        }
        if (modal) modal.classList.remove("active");
        this.startExercise();
      };

      const doEnter = () => {
        const newName = input.value.trim();
        const chosen = newName || select.value;
        if (!chosen) {
          this.showAppAlert(
            "Selezionare un utente esistente o digitare un nuovo nome.",
            "👤 Gestione Utenti",
          );
          return;
        }
        this.loginUser(chosen);
        if (modal) modal.classList.remove("active");
      };

      btnEnter?.addEventListener("click", doEnter);
      btnClose?.addEventListener("click", closeModal);
      btnResetLayout?.addEventListener("click", () =>
        this.resetAllWindowLayouts(),
      );

      modal?.addEventListener("click", (e) => {
        if (e.target === modal) closeModal();
      });

      input?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          doEnter();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closeModal();
        }
      });

      select?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          doEnter();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closeModal();
        }
      });

      window.addEventListener("keydown", (e) => {
        const navModal = document.getElementById("lessonNavModal");
        if (navModal && navModal.classList.contains("active")) return;
        if (e.key === "Escape" && modal?.classList.contains("active"))
          closeModal();
      });

      btnDelete?.addEventListener("click", () => {
        const chosen = select.value;
        if (!chosen) {
          this.showAppAlert(
            "Selezionare un utente da eliminare.",
            "👤 Gestione Utenti",
          );
          return;
        }
        this.showAppConfirm(
          `Eliminare definitivamente tutti i dati dell'utente "${chosen}"?`,
          "⚠ Conferma Eliminazione",
          () => {
            this.profileMgr.deleteUser(chosen);
            if (!this.profileMgr.activeUser) {
              const badge = document.getElementById("loggedUserBadge");
              if (badge) badge.innerText = "Utente: --";
            }
            this.showLoginModal();
          },
        );
      });

      btnResetArchive?.addEventListener("click", () => {
        this.showAppConfirm(
          "Ripristinare l'archivio demo originale (UTENTE_DEMO)?",
          "🔄 Ripristino Archivio",
          () => {
            this.profileMgr.resetToDefaultArchive();
            this.loginUser("UTENTE_DEMO");
            if (modal) modal.classList.remove("active");
          },
        );
      });

      // 1. ESPORTA PROFILO: Esporta l'utente selezionato nel menu (Opzione 1)
      btnExport?.addEventListener("click", () => {
        const targetUser = select.value || this.profileMgr.activeUser;
        if (!targetUser) {
          this.showAppAlert(
            "Selezionare un utente dal menu a tendina da esportare.",
            "⚠ Esportazione Profilo",
          );
          return;
        }

        const jsonStr = this.profileMgr.exportUserJson(targetUser);
        if (!jsonStr) {
          this.showAppAlert(
            `Impossibile recuperare i dati dell'utente "${targetUser}".`,
            "⚠ Errore Esportazione",
          );
          return;
        }

        const fileName = getExportFileName(targetUser);
        const blob = new Blob([jsonStr], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        a.click();
        URL.revokeObjectURL(url);
      });

      // 2. IMPORTA PROFILO: Apertura selettore file JSON
      btnImport?.addEventListener("click", () => {
        importInput?.click();
      });

      importInput?.addEventListener("change", (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
          const text = ev.target?.result || "";
          try {
            if (file.name.endsWith(".json") || text.trim().startsWith("{")) {
              const data = JSON.parse(text);
              if (data && data.UserID) {
                const incomingId = data.UserID.trim();
                const existingUsers = this.profileMgr.getUsers();

                const applyImport = (targetId) => {
                  const importedId = this.profileMgr.importProfileData(
                    data,
                    targetId,
                  );
                  if (importedId) {
                    this.showAppAlert(
                      `Profilo utente "${importedId}" ripristinato con successo!`,
                      "📂 Importazione Profilo",
                      () => {
                        if (modal) modal.classList.remove("active");
                        this.loginUser(importedId);
                        this.statsMgr.renderHistogram();
                        this.statsMgr.renderSpeedChart();
                        this.returnFocusToTyping();
                      },
                    );
                  } else {
                    // Rollback confermato: avvisa l'utente del mancato salvataggio
                    this.showAppAlert(
                      `Impossibile importare il profilo "${targetId}": spazio di memoria del browser esaurito (Local Storage).\n\nLe modifiche sono state annullate (rollback). Elimina prima altri profili o campioni storici per liberare spazio, quindi riprova.`,
                      "⚠ Importazione Fallita (Memoria Esaurita)",
                    );
                  }
                };

                // Risoluzione conflitti: se l'utente esiste già, apre il modale dedicato
                if (existingUsers.includes(incomingId)) {
                  this.showImportConflictModal(
                    data,
                    incomingId,
                    (resolvedName) => applyImport(resolvedName),
                    () => {
                      importInput.value = "";
                    },
                  );
                } else {
                  applyImport(incomingId);
                }
              } else {
                this.showAppAlert(
                  "Il file selezionato non contiene un profilo utente valido.",
                  "⚠ Errore Profilo",
                );
              }
            } else {
              this.showAppAlert(
                "Formato non supportato. Selezionare un file di backup valido in formato .json.",
                "⚠ Formato Non Valido",
              );
            }
          } catch (err) {
            this.showAppAlert(
              "Errore durante l'apertura del file: " + err.message,
              "⚠ Errore Importazione",
            );
          }
          importInput.value = "";
        };
        reader.readAsText(file);
      });

      document
        .getElementById("btnHeaderSwitchUser")
        ?.addEventListener("click", () => {
          this.showLoginModal();
        });
    },

    // Configurazione dei listener per il modale di risoluzione conflitto importazione (Release v.4.1)
    setupImportConflictModal() {
      const modal = document.getElementById("importConflictModal");
      const btnCancel = document.getElementById("btnImportCancelConflict");
      const btnClose = document.getElementById("btnCloseImportConflictModal");

      const closeModal = () => {
        if (modal) {
          modal.classList.remove("active");
          modal.style.zIndex = "";
        }
        if (this._onImportConflictCancel) {
          this._onImportConflictCancel();
          this._onImportConflictCancel = null;
        }
        // Se il modale Utenti è aperto sotto, rimette il focus sul suo pulsante Importa
        const btnImport = document.getElementById("btnImportProfile");
        if (
          btnImport &&
          document.getElementById("loginModal")?.classList.contains("active")
        ) {
          btnImport.focus();
        } else {
          this.returnFocusToTyping();
        }
      };

      btnCancel?.addEventListener("click", closeModal);
      btnClose?.addEventListener("click", closeModal);

      modal?.addEventListener("click", (e) => {
        if (e.target === modal) closeModal();
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal?.classList.contains("active")) {
          e.stopPropagation(); // Impedisce la chiusura contemporanea della finestra Utenti sottostante
          closeModal();
        }
      });
    },

    // Mostra il dialogo unificato di risoluzione conflitto a Livello 2 (sopra a loginModal)
    showImportConflictModal(
      incomingData,
      conflictingName,
      onResolve,
      onCancel,
    ) {
      const modal = document.getElementById("importConflictModal");
      const lblName = document.getElementById("lblConflictUserName");
      const txtNewName = document.getElementById("txtImportNewUserName");
      const btnOverwrite = document.getElementById("btnImportOverwrite");
      const btnSaveAsNew = document.getElementById("btnImportSaveAsNew");

      if (!modal || !txtNewName) return;

      this._onImportConflictCancel = onCancel;

      // Genera automaticamente la prima proposta di nome libera (es. ALBERTO_1, ALBERTO_2...)
      const existingUsers = this.profileMgr.getUsers();
      let suffix = 1;
      let proposed = `${conflictingName}_${suffix}`;
      while (existingUsers.includes(proposed)) {
        suffix++;
        proposed = `${conflictingName}_${suffix}`;
      }

      if (lblName) lblName.textContent = conflictingName;
      txtNewName.value = proposed;

      // Forzatura programmatic z-index Livello 2 per sovrapporsi a loginModal
      modal.style.zIndex = "3000";
      modal.classList.add("active");

      setTimeout(() => {
        txtNewName.focus();
        txtNewName.select();
      }, 60);

      // Gestione Azione: Sovrascrivi Esistente
      btnOverwrite.onclick = () => {
        this._onImportConflictCancel = null;
        modal.classList.remove("active");
        modal.style.zIndex = "";
        onResolve(conflictingName);
      };

      // Gestione Azione: Salva come Nuovo
      const handleSaveAsNew = () => {
        const chosenName = txtNewName.value.trim();
        if (!chosenName) {
          this.showAppAlert(
            "Inserire un nome valido per il nuovo profilo utente.",
            "⚠ Nome Non Valido",
          );
          return;
        }
        if (chosenName === conflictingName) {
          this.showAppAlert(
            `Il nome "${chosenName}" è già quello in conflitto. Per sovrascriverlo premi "Sovrascrivi", altrimenti specifica un nome differente.`,
            "⚠ Conflitto Nome",
          );
          return;
        }
        if (existingUsers.includes(chosenName)) {
          this.showAppAlert(
            `Nel sistema esiste già un altro profilo denominato "${chosenName}". Scegliere un nome differente.`,
            "⚠ Utente Esistente",
          );
          return;
        }

        this._onImportConflictCancel = null;
        modal.classList.remove("active");
        modal.style.zIndex = "";
        onResolve(chosenName);
      };

      btnSaveAsNew.onclick = handleSaveAsNew;
      txtNewName.onkeydown = (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          handleSaveAsNew();
        }
      };
    },

    // GESTIONE SORGENTE LEZIONI: STANDARD VS CUSTOM
    setLessonsSource(source) {
      this.activeLessonsSource = source;
      const isCustom =
        source === "custom" &&
        this.customLessons &&
        this.customLessons.length > 0;
      this.lessons = isCustom ? this.customLessons : this.standardLessons;
      this.typingEng.lessons = this.lessons;
      this.typingEng.currentLessonIdx = 0;
      this.typingEng.currentPhraseIdx = 0;

      const lbl = document.getElementById("lblLessonSource");
      if (lbl) lbl.innerText = isCustom ? "Custom" : "Standard";

      const cboLessons = document.getElementById("cboLessons");
      if (cboLessons) {
        cboLessons.innerHTML = "";
        this.lessons.forEach((l, idx) => {
          const prefix = isCustom ? "Custom " : "Lezione ";
          cboLessons.innerHTML += `<option value="${idx}">${prefix}${idx + 1}: ${htmlEscape(l.name)}</option>`;
        });
        cboLessons.value = "0";
      }

      this.startExercise();
    },

    loginUser(userId) {
      const prof = this.profileMgr.loadUser(userId);
      const badge = document.getElementById("loggedUserBadge");
      if (badge) badge.innerText = `Utente: ${userId}`;

      const theme = prof.Theme || "theme-dark";
      document.body.classList.remove(
        "theme-dark",
        "theme-light",
        "theme-retro",
        "theme-matrix",
      );
      document.body.classList.add(theme);
      const themeSel = document.getElementById("themeSelect");
      if (themeSel) themeSel.value = theme;

      const audioMode = prof.AudioMode || "typewriter";
      this.audio.setMode(audioMode);
      const audioSel = document.getElementById("audioModeSelect");
      if (audioSel) audioSel.value = audioMode;

      const audioVol = prof.AudioVolume !== undefined ? prof.AudioVolume : 0.7;
      this.audio.setVolume(audioVol);
      const volSlider = document.getElementById("audioVolumeSlider");
      if (volSlider) volSlider.value = String(Math.round(audioVol * 100));

      // Ripristino stato Dettatura Vocale nel profilo utente (v.3.8 e v.3.9)

      const dictEn = !!prof.DictationEnabled;
      this.dictation.setEnabled(dictEn);
      const chkDict = document.getElementById("chkDictation");
      if (chkDict) chkDict.checked = dictEn;

      const dictSpeed =
        prof.DictationSpeed !== undefined ? prof.DictationSpeed : 0.9;
      this.dictation.setSpeed(dictSpeed);
      const rngSpeed = document.getElementById("rngDictationSpeed");
      if (rngSpeed) rngSpeed.value = String(Math.round(dictSpeed * 100));

      const dictCaps = !!prof.DictationCaps;
      this.dictation.setAnnounceCaps(dictCaps);
      const chkCaps = document.getElementById("chkDictationCaps");
      if (chkCaps) chkCaps.checked = dictCaps;

      // Ripristino casella Spelling lettera per lettera (v.4.2)
      const dictSpell = !!prof.DictationSpelling;
      this.dictation.setSpelling(dictSpell);
      const chkSpell = document.getElementById("chkDictationSpelling");
      if (chkSpell) chkSpell.checked = dictSpell;

      // Ripristino casella Apostrofo (v.3.9)
      const dictApos = !!prof.DictationApostrophe;
      this.dictation.setAnnounceApostrophe(dictApos);
      const chkApos = document.getElementById("chkDictationApostrophe");
      if (chkApos) chkApos.checked = dictApos;

      // Ripristino casella Spazio (v.5.0)
      const dictSpace = !!prof.DictationSpace;
      this.dictation.setAnnounceSpace(dictSpace);
      const chkSpace = document.getElementById("chkDictationSpace");
      if (chkSpace) chkSpace.checked = dictSpace;

      this.toggleHandsVis(prof.ShowHands !== false);
      const handsWin = document.getElementById("handsFloatingWindow");
      if (handsWin) {
        this.updateHandsPinButtonUI();
        this.updateHandsWindowPosition();
        if (prof.HandsWidth && prof.HandsHeight) {
          handsWin.style.width = prof.HandsWidth + "px";
          handsWin.style.height = prof.HandsHeight + "px";
          this.visual.adjustHandsViewport(prof.HandsWidth, prof.HandsHeight);
        } else {
          handsWin.style.width = "580px";
          handsWin.style.height = "330px";
          this.visual.adjustHandsViewport(580, 330);
        }
        this.windowMgr.clampWindowToViewport(handsWin, true);
      }

      const useKeyPos = !!(prof.UseKeyPositions !== undefined
        ? prof.UseKeyPositions
        : prof.UseCustomKeyDistances);
      this.visual.useCustomKeyDistances = useKeyPos;
      const btnTogglePos =
        document.getElementById("btnToggleKeyPositions") ||
        document.getElementById("btnToggleKeyDistances");
      if (btnTogglePos) {
        btnTogglePos.classList.toggle("active", useKeyPos);
      }
      this.visual.updatePositionDots(useKeyPos);

      const statsWin = document.getElementById("statsFloatingWindow");
      if (statsWin) {
        if (prof.StatLeft && prof.StatTop) {
          statsWin.style.left = prof.StatLeft + "px";
          statsWin.style.top = prof.StatTop + "px";
        }
        if (prof.StatWidth && prof.StatHeight) {
          statsWin.style.width = prof.StatWidth + "px";
          statsWin.style.height = prof.StatHeight + "px";
          statsWin.style.maxWidth = "none";
        }
        this.windowMgr.clampWindowToViewport(statsWin, false);
      }

      // Ripristino Finestra Velocità Istantanea (Release v6.8)
      const instantWin = document.getElementById("instantSpeedFloatingWindow");
      if (instantWin) {
        this.updateInstantSpeedPinButtonUI();
        this.updateInstantSpeedWindowPosition();
        if (prof.InstantSpeedWidth && prof.InstantSpeedHeight) {
          instantWin.style.width = `${prof.InstantSpeedWidth}px`;
          instantWin.style.height = `${prof.InstantSpeedHeight}px`;
          instantWin.style.maxWidth = "none";
        } else {
          instantWin.style.width = "1240px";
          instantWin.style.height = "340px";
        }
        this.windowMgr.clampWindowToViewport(instantWin, true);
      }
      this.toggleInstantSpeedVis(prof.ShowInstantSpeed === true);

      // Reset pulito dello stile di zoom applicativo (Release v6.10)
      if (typeof this.applyZoom === "function") {
        this.applyZoom();
      } else if (typeof document !== "undefined" && document.body) {
        document.body.style.zoom = "";
      }

      this.toggleKeyboardVis(prof.ShowKeyBoard !== false);
      this.toggleOriginVis(prof.ShowOrigin !== false);
      this.toggleTypedVis(prof.ShowTyped !== false);
      this.toggleErrorsVis(prof.ShowErrors !== false);
      const chkAuto = document.getElementById("chkAutomaticCorrection");
      if (chkAuto) chkAuto.checked = !!prof.AutomaticCorrection;

      // Sincronizzazione visiva checkbox Fonemi dal profilo utente (v.4.3)
      if (prof.FonemiOptions) {
        const chkMap = {
          chkFonemiCustomFile: "customFile",
          chkFonemiMaiuscole: "maiuscole",
          chkFonemiPunteggiatura: "punteggiatura",
          chkFonemiParentesi: "parentesi",
          chkFonemiNumeri: "numeri",
          chkFonemiMatematici: "matematici",
          chkFonemiSimboli: "simboli",
          chkFonemiLayout: "layout",
        };
        Object.keys(chkMap).forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.checked = !!prof.FonemiOptions[chkMap[id]];
        });
        this.updateFonemiDropdownSummary();
      }

      this.typingEng.mode = prof.Mode || 0;
      const cboMode = document.getElementById("cboMode");
      if (cboMode) cboMode.value = String(this.typingEng.mode);

      this.setLessonsSource("standard");
      this.typingEng.currentLessonIdx = Math.max(
        0,
        Math.min(prof.Lesson || 0, this.lessons.length - 1),
      );
      this.typingEng.currentPhraseIdx = prof.Exercise || 0;
      const cboLessons = document.getElementById("cboLessons");
      if (cboLessons)
        cboLessons.value = String(this.typingEng.currentLessonIdx);

      this.updateModeUI();
      this.startExercise();
    },

    // =======================================================
    // CLASSE: AppController (metodi-profili-modali.js)
    // METODI: setupInstantSpeedParamsModal() e openInstantSpeedParamsModal()
    // CONTESTO: Gestione del modale parametri N della Velocità Istantanea (Release v6.4)
    // =======================================================
    openInstantSpeedParamsModal() {
      const modal = document.getElementById("instantSpeedParamsModal");
      const input = document.getElementById("txtInstantSpeedN");
      if (!modal || !input) return;

      const currentN =
        this.profileMgr?.profile?.InstantSpeedMovingAvgWindow || 3;
      input.value = String(currentN);
      modal.style.zIndex = "4000";
      modal.classList.add("active");

      setTimeout(() => {
        input.focus();
        input.select();
      }, 60);
    },

    // =======================================================
    // CLASSE: AppController (metodi-profili-modali.js)
    // METODO: setupInstantSpeedParamsModal() - Release v6.5
    // CONTESTO: Gestione modale parametri N con ricalcolo immediato del grafico.
    // =======================================================
    setupInstantSpeedParamsModal() {
      const modal = document.getElementById("instantSpeedParamsModal");
      if (!modal) return;

      const input = document.getElementById("txtInstantSpeedN");
      const btnConfirm = document.getElementById(
        "btnConfirmInstantSpeedParams",
      );
      const btnCancel = document.getElementById("btnCancelInstantSpeedParams");
      const btnClose = document.getElementById(
        "btnCloseInstantSpeedParamsModal",
      );
      const btnResetDef = document.getElementById(
        "btnInstantSpeedParamsResetDefault",
      );

      const closeModal = () => {
        modal.classList.remove("active");
        modal.style.zIndex = "";
        this.returnFocusToTyping();
      };

      btnClose?.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeModal();
      });

      btnCancel?.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeModal();
      });

      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          closeModal();
        }
      });

      btnResetDef?.addEventListener("click", (e) => {
        e.preventDefault();
        if (input) input.value = "3";
      });

      const doConfirm = () => {
        let val = input ? parseInt(input.value, 10) : 3;
        if (isNaN(val) || val < 1) val = 1;
        if (val > 10) val = 10;

        if (this.profileMgr?.profile) {
          this.profileMgr.profile.InstantSpeedMovingAvgWindow = val;
          this.profileMgr.saveProfile();
        }

        // Ricalcola la Media Mobile su tutta la serie di campioni dell'esercizio corrente (Release v6.5)
        this.typingEng.recalculateInstantSpeedMovingAverages();

        closeModal();
        this.renderInstantSpeedChart();
      };

      btnConfirm?.addEventListener("click", (e) => {
        e.preventDefault();
        doConfirm();
      });

      input?.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          doConfirm();
        } else if (e.key === "Escape") {
          e.preventDefault();
          closeModal();
        }
      });

      window.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal.classList.contains("active")) {
          e.preventDefault();
          closeModal();
        }
      });
    },
  };
  for (const [name, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(controllerMethods))) {
    Object.defineProperty(AppController.prototype, name, { ...descriptor, enumerable: false });
  }
})();
