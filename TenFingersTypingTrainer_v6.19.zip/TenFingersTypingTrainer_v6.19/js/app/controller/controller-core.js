/* TenFingersTypingTrainer v6.19 — controller core. I metodi sono caricati dai moduli controller/ successivi. */
// =======================================================
// APP CONTROLLER (Coordinatore Principale e Macchina a Stati)
// =======================================================
class AppController {
  constructor(lessons, demoProfile, customDefault, fonemiCorpus) {
    this.version = "6.19"; // Versione applicativa runtime (Release v6.19)
    window.APP_VERSION = "6.19";
    this.currentZoom = 1.0; // Livello di zoom applicativo (Release v6.9)
    this.standardLessons = lessons || [];
    this.customLessons = [];
    this.activeLessonsSource = "standard";
    this.lessons = this.standardLessons;
    this.profileMgr = new ProfileManager(demoProfile, customDefault);
    this.audio = new AudioEngine();
    this.phonemeEng = new PhonemeEngine(fonemiCorpus);
    this.dictation = new DictationEngine();
    this.typingEng = new TypingEngine(
      this.lessons,
      this.profileMgr,
      this.audio,
      this.phonemeEng,
    );
    this.visual = new VisualRenderer();
    this.windowMgr = new WindowManager();
    this.statsMgr = new StatisticsManager(this.profileMgr);
    this.prevStatsRect = null;
    this._wrongBadgeTimer = null;

    this.modifierSession = {
      activeModifiers: new Set(),
      expectedModsActive: new Set(),
      shortcutExecuted: false,
      abandonErrorReported: false,
    };
  }
}
