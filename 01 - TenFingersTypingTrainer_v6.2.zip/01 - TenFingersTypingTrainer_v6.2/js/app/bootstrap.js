/* TenFingersTypingTrainer v6.0 — avvio browser */
window.addEventListener("DOMContentLoaded", () => {
  const app = new AppController(
    EMBEDDED_LESSONS,
    EMBEDDED_DEMO_PROFILE,
    EMBEDDED_CUSTOM_DEFAULT,
    EMBEDDED_FONEMI_CORPUS,
  );
  app.start();
  window.app = window.__app = app;
});
