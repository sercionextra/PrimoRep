# Documento di Handoff Tecnico per le Chat Future (Release v.2.11)

---

## 1. Identità e Obiettivo Primario del Progetto

- **Nome Progetto**: Ten Fingers Typing Trainer (Web Edition SPA)
- **Origine Software**: Porting moderno in TypeScript / Vanilla JavaScript da applicativo desktop WinForms C# (.NET 1.1) denominato `Tastiera10Dita.exe`.
- **Mission Didattica**: Insegnamento rigoroso della **dattilografia alla cieca a dieci dita (touch-typing)** su layout italiano standard **QWERTY IT a 105 tasti**, con la regola aurea di non guardare mai la tastiera fisica durante la scrittura.
- **Architettura di Distribuzione**: Single Page Application (SPA) pura a zero dipendenze esterne a runtime. L'intera logica, grafica SVG e stili risiedono in file HTML autoportanti, eseguibili direttamente con doppio clic in qualsiasi browser moderno aderente agli standard W3C.

---

## 2. Stato Attuale del Repository (`/workspace`)

La struttura delle directory e degli asset attivi alla Release v.2.11 si presenta in perfetto ordine, testata e sincronizzata:

```text
/workspace/
└── TenFingersTypingTrainer - (Porting TypeScript)/
    ├── DOCS/
    │   ├── NEW_DOCS/                                                                        <-- CARTELLA FOCALE PER I KICKOFF FUTURI
    │   │   ├── 01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.11).md
    │   │   ├── 02 - Manuale Utente Dettagliato ed Ergonomia di Utilizzo (v.2.11).md
    │   │   ├── 03 - Documento Conclusivo di Riepilogo Tecnico e Decisioni Architetturali dell'Intera Chat (v.2.11).md
    │   │   ├── 04 - Documento di Handoff Tecnico per le Chat Future (v.2.11).md                [Questo documento]
    │   │   └── help_(v.2.11).html                                                              [Guida HTML5 sincronizzata]
    │   ├── ALL DOCS/                                                                        <-- Archivio storico consolidato
    │   │   ├── ... (documenti storici da v.1.0 a v.2.4)
    │   │   ├── 25 - App TypeScript - Documento Conclusivo... (v.2.6).md
    │   │   └── 26 - FINE CHAT - Documento di Handoff Tecnico (Versione 2.6).md
    │   └── Ultima Chat/
    └── SRC/
        ├── help_(v.2.4).html                                                                <-- Storico
        ├── help_(v.2.6).html                                                                <-- Storico
        ├── help_(v.2.7).html                                                                <-- Storico
        ├── help_(v.2.8).html                                                                <-- Storico
        ├── help_(v.2.9).html                                                                <-- Storico
        ├── help_(v.2.10).html                                                               <-- Storico
        ├── help_(v.2.11).html                                                               <-- GUIDA ATTIVA & LINKATA DALL'APPLICAZIONE
        ├── index_(v.2.4).html                                                               <-- Storico
        ├── index_(v.2.7).html                                                               <-- Storico
        ├── index_(v.2.8).html                                                               <-- Storico
        ├── index_(v.2.9).html                                                               <-- Storico
        ├── index_(v.2.10).html                                                              <-- Storico
        └── index_(v.2.11).html                                                              <-- CODICE SORGENTE ATTIVO COLLAUDATO (v.2.11)
```

---

## 3. Regole d'Oro del Modus Operandi (Mandatorie per le Nuove Chat)

Qualsiasi agente o ingegnere software che subentri nelle sessioni successive **DEVE rispettare rigorosamente i seguenti 7 principi**:

1. **Versionamento Incrementale Sequenziale**:
   - Qualsiasi modifica ai sorgenti o alla documentazione deve comportare l'emissione di una nuova versione con **nuovo numero incrementale** (la prossima release sarà `v.2.12`).
   - Mai sovrascrivere file storici preesistenti; creare sempre il file con suffisso progressivo (es. `index_(v.2.12).html`, `help_(v.2.12).html`).
2. **Modifiche Chirurgiche e Non Invasive**:
   - Vietato riscrivere o refactorizzare codice già funzionante e collaudato.
   - Gli interventi devono essere puntuali, circoscritti e strettamente mirati al fabbisogno richiesto.
3. **Preservazione dei Commenti e della Memoria Storica**:
   - Mantenere tutti i commenti tecnici preesistenti nel codice sorgente e nella documentazione.
4. **Zero Bug e Zero Regressioni**:
   - Nessun errore di console (0 eccezioni DevTools).
   - Nessuna perdita di funzionalità precedentemente implementata (da v.1.0 a v.2.11).
5. **Allineamento Speculare Triangolare**:
   - Mantenere sincronizzati in modo speculare **Sorgenti (`SRC`)**, **Documentazione (`NEW_DOCS`)** e **Guida Utente (`help.html`)**.
6. **Dislocazione dei File**:
   - Tutti i nuovi file prodotti devono risiedere sotto la directory `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/`.
7. **Divieto Assoluto di Formattazione LaTeX**:
   - È tassativamente vietato l'uso di formule o sintassi LaTeX (delimitatori dollaro, comandi matematici LaTeX). Esporre sempre numeri, percentuali e formule in notazione naturale chiara (es. 99.5%, 87x78 px, 1.5x, 550 ms).

---

## 4. Architettura del Software e Asset di Riferimento (Release v.2.11)

### 4.1 Modello ad Oggetti (8 Classi Disaccoppiate)
Il sorgente operativo `index_(v.2.11).html` (circa 5.480 righe) è articolato in:
- `TypingEngine`: Motore didattico di computazione, gestione errori, spazi fittizi, vincolo rigido di completamento esercizio (blocco finale se vi sono errori residui non sanati con Backspace), supporto caratteri speciali `{}` e simboli estesi.
- `VisualRenderer`: Silhouette vettoriale SVG bimanuale e tastiera virtuale:
  - Keycaps dinamici con gestione ergonomica accordi sinistra: CTRL (Dito 1) + SHIFT (Dito 2), e con ALT (Dito 5).
  - Tracciamento della variabile `currentTargetChar` e persistenza dell'accordo proposto sulle dita (risolto bug scomparsa graffe `{}`).
  - Viewport cropping elastico su finestra resizable con traslazione dinamica scritte bimanuali.
  - Pulizia sistematica tasti attivi alla fine dell'esercizio (`clearHandsActiveKeys`).
- `StatisticsManager`:
  - **Istogramma normalizzato**: Riscalamento al massimo valore attualmente presente per esaltare le differenze visive relative o assolute.
  - **Raggruppamento per dito**: Riquadri colorati perimetrali con badge di testata abbinati alla palette cromatica ufficiale delle dita (1..10).
  - Grafico cronologico cartesiano ad altezza massimizzata (320 px) con asse Y commutabile e slot pulsanti a layout invariante (`visibility: hidden`).
- `ProfileManager`: Gestione multi-utente su `localStorage` e XML, supporto a 4 temi grafici (Dark Modern, Light Classic, Retro 2003, Matrix High-Contrast).
- `PhonemeEngine`: Algoritmo sillabico N-gram italiano su corpus continuo.
- `AudioEngine`: Sintesi sonora procedurale Web Audio API (Underwood meccanica a 2 componenti, beep errore, campana).
- `WindowManager`: Gestione finestre trascinabili e ridimensionabili a 8 maniglie con supporto duale per elementi `position: absolute` (coordinate documento `e.pageX`, `e.pageY`, `offsetLeft`, `offsetTop`) ed elementi `position: fixed`.
- `AppController`: Orchestratore generale, listener hotkeys unificato con `e.code` (`Digit1`..`Digit5` per modalità), modale integrata `#lessonNavModal` per il cambio lezione, centratura responsive del layout con testata su due righe, ancoraggio applicativo solido della finestra Mani con invarianza da zoom e da scrolling della pagina (`position: absolute;`).

---

## 5. Istruzioni per il Kickoff delle Chat Successive

Per riprendere il lavoro in una nuova chat senza sprecare token:
1. **Leggere come riferimento prioritario la cartella `/workspace/TenFingersTypingTrainer - (Porting TypeScript)/DOCS/NEW_DOCS`**, in particolare il file `01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.11).md` e `03 - Documento Conclusivo di Riepilogo Tecnico e Decisioni Architetturali dell'Intera Chat (v.2.11).md`.
2. Quando l'utente richiede modifiche o nuove funzionalità al codice sorgente:
   - Partire dalla base validata e collaudata di `index_(v.2.11).html`.
   - Produrre il nuovo sorgente con versione progressiva **`index_(v.2.12).html`**.
   - Aggiornare specularmente la documentazione e la guida ad Help progressivo **`help_(v.2.12).html`** e suite doc **`v.2.12`**.
   - Eseguire sempre un controllo di sintassi JS (`node --check`) e richiamare `sync` nel filesystem per persistere lo stato.
