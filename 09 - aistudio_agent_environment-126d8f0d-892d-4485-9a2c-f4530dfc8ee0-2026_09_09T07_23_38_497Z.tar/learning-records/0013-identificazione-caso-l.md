# Identificazione configurazione spigoli dell'ultimo strato (Caso 'L')

L'utente ha mappato con precisione gli adesivi gialli del tetto:
Celle 1, 5, 6, 8, 9.
Filtrando gli angoli (1 e 9), gli spigoli gialli sono nelle posizioni 6 (destra) e 8 (basso).
Questo configura esattamente il caso a 'L' (due spigoli adiacenti).
Procedura:
1. Ruotare il tetto di 180° (`U2`) per orientare la 'L' verso ore 9:00 e ore 12:00 (posizioni 4 e 2).
2. Applicare `F (R U R' U') F'` per trasformare la 'L' nella Linea orizzontale.
3. Riapplicare `F (R U R' U') F'` per ottenere la Croce Gialla completa.
