## [6.34]
- Finestra Interrogazione (`#interrogationDialog`): abilitato il ridimensionamento fino a tutta l'altezza visibile (`100vh`) e il trascinamento (drag) fino a `top: 0` (coprendo anche l'header dell'app) tramite `data-allow-full-viewport="1"` in `WindowManager`, mantenendo `minTop = 60` per le altre finestre fluttuanti.
- Fix layout italiano QWERTY: rimossi i caratteri AltGr errati `~` dal tasto `ì`/`^` (`key_igrave`) e `` ` `` dal tasto `'`/`?` (`key_quote`) in `index.html`, `keyboard-map.js`, `interrogation-layout-metadata.js` e `interrogation-catalog-data.js` (catalogo aggiornato a 109 mapping, 439 definizioni, 223 candidate).
- Popover "Seleziona carattere / tasto" (`#interrAsciiPopover`): in `_openAsciiPopover`, calcolata dinamicamente la posizione orizzontale (centrata sul pulsante cliccato) e verticale (sotto o sopra a seconda dello spazio disponibile) entro i margini della viewport via CSSOM (CSP-safe).

## [6.33]
- Finestra Interrogazione (`#interrogationDialog`) resa traslabile dalla barra del titolo (`#interrogationWindowHeader`) con salvataggio di posizione e dimensioni nel profilo utente.
- Aggiunti i pulsanti `↺ Ripristina` (`#btnInterrogationResetLayout`) e `⛶ Ingrandisci` / `🗗 Riduci` (`#btnInterrogationMaximize`) nell'header della finestra Interrogazione, allineati alla finestra Statistiche.
- Integrato il ripristino della finestra Interrogazione nel pulsante `Reset finestre` della finestra "Gestione Utenti" (`resetAllWindowLayouts()`).
- Risolto il bug di ridimensionamento che spostava progressivamente `#interrogationDialog` verso il basso e fuori schermo (impostando `position: fixed; margin: 0;` invece di `position: relative;` all'interno della modale flex-centrata).

## [6.32]
- Corretto bug sul click dei pallini sulle mani nei quesiti `CARATTERE`/`TASTO` (`meta.getKeyExtension` invece di `meta.getKeyExtensions`, con fallback `resolveKeyIdFromToken`) per valorizzare Mano, Dito, Direzione sovraccarico, Estensione laterale ed Estensione longitudinale.
- Riordinati i controlli in "1) Descrizione Accordo": colonna sinistra (`Mano`, `Dito`, `Direzione sovraccarico`, `Estensione laterale`), colonna destra (`Estensione longitudinale`, `Accordo Modificatore`, pulsanti `Conferma Accordo` e `Consulta (+1)`).
- I pulsanti `Concludi sessione`, `Sospendi` e `Abbandona` ora chiudono la finestra Interrogazione e mostrano un breve riepilogo tramite `showAppAlert` con punteggio e conteggi (Corrette, Errate, Consultate, Ignorate).

## [6.31]
- Selezione manuale nell'Interrogazione: un secondo click su tasto, dito o pallino delle mani rimuove l'elemento dall'elenco e deseleziona l'evidenziazione verde; anche la rimozione tramite "✕" sul chip toglie l'evidenziazione verde da tastiera e mani; supportata la multi-selezione delle dita e la sincronizzazione al cambio tipo interrogazione.
- Finestra Interrogazione (`#interrogationDialog`) resa ridimensionabile con ricalcolo dinamico del grafico dello storico.
- Vista "Mostra storico" allineata al grafico delle velocità delle Statistiche:
  - Filtri per tipologia quesito (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`) e range Date/Ore separati con cancellazione singola, validazione e pulsante "Reset Periodo".
  - Selettori metriche: `Punteggio`, `% Rendimento`, `N. Totale`, `N. Corrette`, `N. Errate`, `N. Consultate`, `N. Ignorate`.
  - Selezione campioni/intervalli a 3 click, crosshair rosso/azzurro, scrubber Data/Ora, evidenziazione verde in hover con dettaglio completo (`score / maxScore pt (pct%)`, tipo, numero domande e conteggi).
  - Pulsanti `Elimina Selezionati`, `Elimina Non Selezionati` (visibili nel range), `Elimina Archivio Storico` con conferma modale.
  - Pulsante `🔁 Ripeti interrogazione` su singolo campione selezionato per ripetere tutti i quesiti o filtrarli per esito (`Corrette`, `Errate`, `Consultate`, `Ignorate`).
- Memorizzazione su `sessions` (e fallback da `sessionItems`) di `maxScore` reale, `questionTypes`, `totalBlocks`, `correctCount`, `incorrectCount`, `consultedCount` e `ignoredCount`.

## [6.30]
- Aggiunto pulsante "Mostra storico" nella finestra Interrogazione con grafico SVG interattivo, crosshair rosso/verde, filtro data/ora ed eliminazione campioni selezionati o esclusi.
- Rimossi simboli AltGr errati `{`, `[`, `]`, `}` dai tasti `7`, `8`, `9`, `0` su tastiera principale, tastiera Interrogazione e anteprima tasto.
- Compattata ulteriormente la finestra Interrogazione (spazi ridotti sopra/sotto tastiera e mani, layout compatto per Accordo Modificatore, Conferma e Consulta).
- Posizionata la palette ASCII "Seleziona carattere / tasto" in prossimità dell'elemento cliccato.
- Fix priorità click sui puntini delle mani e delle estensioni laterali (`pointer-events` + raggio hit aumentato) per valorizzare tutti i dropdown di Descrizione Accordo.
- Impostati tutti i dropdown di "1) Descrizione Accordo" su voce vuota iniziale.
- Accettati `0` e `+1` per `INVIO` (estensione longitudinale) e `+` / `ù` a sinistra di `INVIO` (con svelamento di entrambi).
- Rinnovata Interrogazione per Dito: nessun suggerimento iniziale, rimossi filtri Estensione/Direzione, click su tasto -> giallo + palette ASCII -> badge utente sul tasto -> verifica abbinamento tasto-carattere -> verde per corretti, giallo persistente per fuori posto.

## [6.29]
- Rimossi gli stati live dell'esercizio di digitazione (tasto rosso lampeggiante e contatore Errori) dalla finestra Interrogazione.
- Impedita l'anticipazione dei caratteri non ancora risposti sulle anteprime keycap e sulla tastiera B/N.
- Ridotta l'altezza della finestra Interrogazione spostando Domanda/Target/Punteggio (p/max) nella barra del titolo ed eliminando il footer duplicato.
- Sostituiti i tracciati dei polpastrelli con sagome anatomiche complete delle 10 dita e rimosso il doppio layer di pallini sulle mani.
- Collegato il clic su dita e pallini delle mani alla compilazione automatica dei dropdown del Blocco 1 (senza conferma automatica).

## [6.28]
- Spostato il pulsante Interrogazione tra Zoom-in e Zoom-out e Utenti nell'header.
- Rimosso il vincolo max-width: 460px sulla finestra Interrogazione (larghezza 98vw, tastiera B/N e mani affiancate senza scroll laterale).
- Risolta la derivazione di keyId, character e fingerId in InterrogationCatalog per sbloccare sia la modalita Casuale sia la modalita Manuale.
- Attivato automaticamente l'ascolto tastiera fisica in modalita Manuale e pointer-events sulle mani/pallini SVG.

# Changelog — TenFingersTypingTrainer

## v6.27
- Riprogettata l'interfaccia grafica della modalità **Interrogazione**:
  - Vista superiore affiancata con **Tastiera B/N anonima** (priva di simboli, che si popola progressivamente) e **Mani SVG interattive** con pallini cliccabili calibrati (almeno 3px reali) e dita selezionabili.
  - Scelta manuale multi-canale: clic su tastiera B/N, clic su pallini/dita mani SVG, ascolto tastiera fisica o griglia ASCII.
  - Interrogazione **Per Carattere / Per Tasto** strutturata in 3 blocchi sulla stessa pagina: 1) Descrizione Accordo (Mano, Dito, Estensione laterale 0..3 e direzione, Estensione longitudinale -1..+2, Modificatori `CTRL`, `SHIFT`, `ALT`, `AltGr` con equivalenza `AltGr` <-> `CTRL+ALT`), 2) Caratteri sul Tasto con mini-keycap SVG e popover ASCII/`NONE`, 3) Tasti intorno ("margherita") con popover ASCII/`NONE` e rosa completa sulla tastiera.
  - Interrogazione **Per Dito** con filtro progressivo di estensione laterale/direzione e opzione configurabile (`soli_tasti_fisici` | `tutti_i_singoli_caratteri`).
  - Interrogazione **Tasti Posizione di Riposo** (Sinistra / Destra) con selezione grafica dei 4 tasti, carattere e dito.
  - Salvataggio automatico del punteggio finale nelle statistiche del profilo (`profile.interrogationStats`).
- Aggiunti i moduli `js/interrogation/interrogation-layout-metadata.js` e `js/ui/interrogation-svg-renderer.js`, e aggiornati `docs/ARCHITETTURA_v6.27.md`, `docs/MANUALE_UTENTE_v6.27.md`, `help.html`, `README.md` e `BUILD_MANIFEST.json`.

## v6.26
- Migliorata la leggibilità di tutti gli esercizi di **Interrogazione**:
  - Sostituiti gli identificativi tecnici `finger.nn` con il nome italiano del dito e l'indicazione della mano ` - (sn)` o ` - (dx)` (es. `[HOME_ROW] mignolo - (sn)`).
  - Nelle voci `[DITO]` aggiunto anche il nome del tasto tra parentesi graffe (es. `[DITO] mignolo - (dx) - {meno}` nel selettore manuale), mantenendo il titolo della domanda in esecuzione privo di spoiler (`Tasto {meno}`).
  - Nelle voci `[TASTO]` mostrato il nome leggibile del tasto tra parentesi graffe (es. `[TASTO] {meno}`).
  - Nelle voci `[CARATTERE]` mostrati i nomi in chiaro dei caratteri e simboli dalla tabella di riferimento (es. `[CARATTERE] Euro`, `[CARATTERE] BACK`, `[CARATTERE] Spazio`).
- Centralizzata la formattazione leggibile in `InterrogationCatalog` (`js/interrogation/interrogation-catalog.js`).
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.26.md`, `docs/MANUALE_UTENTE_v6.26.md`, `README.md` e `BUILD_MANIFEST.json`.

## v6.25
- Ripristinata la selezione delle migliori voci di sintesi vocale (TTS) con consenso esplicito per profilo (`AllowRemoteTtsVoices`, predefinito `true`).
- Integrata la nuova funzionalità **Interrogazione sul layout della tastiera italiana** (Casuale, Adattiva 1/3/7/14/30/60 giorni, Manuale).
