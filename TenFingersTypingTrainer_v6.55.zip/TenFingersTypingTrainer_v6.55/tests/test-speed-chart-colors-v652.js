const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

const sandbox = {
  console,
  htmlEscape: (s) => String(s),
  document: {
    getElementById: () => null,
  },
};

const code = fs.readFileSync(
  path.join(root, "js/analytics/statistics-manager.js"),
  "utf8",
);
vm.runInNewContext(code, sandbox, { filename: "statistics-manager.js" });

const StatisticsManager = vm.runInNewContext("StatisticsManager", sandbox);
const mgr = new StatisticsManager({ profile: null });

// 1. Verifica che tutte le 8 modalità abbiano colori distinti e diversi da verde e arancione
const colors = [];
for (let t = 1; t <= 8; t++) {
  const c = mgr.getSampleTypeColor(t);
  assert.ok(c && c.startsWith("#"), `Colore non valido per TipoCampione ${t}`);
  assert.notStrictEqual(c.toLowerCase(), "#f59e0b", "Non deve usare arancione selezionato");
  assert.notStrictEqual(c.toLowerCase(), "#22c55e", "Non deve usare verde evidenziato");
  assert.notStrictEqual(c.toLowerCase(), "#10b981", "Non deve usare verde evidenziato");
  colors.push(c.toLowerCase());
}
assert.strictEqual(new Set(colors).size, 8, "Tutti gli 8 colori devono essere distinti");

// Fallback per tipo sconosciuto
assert.strictEqual(mgr.getSampleTypeColor(99), "#94a3b8");

// 2. Verifica coerenza tra colori in StatisticsManager, app.css e classi in index.html
const css = fs.readFileSync(path.join(root, "assets/styles/app.css"), "utf8");
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");

for (let t = 1; t <= 8; t++) {
  const expectedColor = mgr.getSampleTypeColor(t).toLowerCase();
  assert.ok(
    css.toLowerCase().includes(`.speed-filter-type-${t} { border-bottom-color: ${expectedColor}; }`),
    `CSS mancante o non allineato per .speed-filter-type-${t}`,
  );
  assert.ok(
    html.includes(`class="speed-filter-label speed-filter-type-${t}"`),
    `Classe mancante in index.html per speed-filter-type-${t}`,
  );
}

// 3. Verifica che la linea del grafico sia neutra e non blu #3b82f6
const chartJs = fs.readFileSync(
  path.join(root, "js/analytics/statistics-manager.js"),
  "utf8",
);
assert.ok(
  chartJs.includes('stroke="rgba(148, 163, 184, 0.55)"'),
  "La polilinea del grafico deve essere grigio-ardesia semi-trasparente",
);

console.log("PASS test-speed-chart-colors-v652");
