# Architettura & Note Tecniche — Release v6.39

## 1. Notifica Toast per avvio bloccato da sessione sospesa
- **`js/app/controller/metodi-interrogazione.js`**: passata la callback `showToast: (msg, icon) => this.showNotificationToast(msg, icon)` a `InterrogationUI` (stesso meccanismo dei pulsanti `zoomIn()` / `zoomOut()`).
- **`js/ui/interrogation-ui.js`** & **`assets/styles/app.css`**:
  - In `showSetupView()` sostituito `btnStart.disabled = !!suspended` con `btnStart.classList.toggle("is-blocked", !!suspended)`: un pulsante `disabled` non emette eventi `click`, quindi l'uso della classe visiva consente a `handleStartSession()` di intercettare il tentativo di avvio e mostrare il toast `"Esiste una sessione sospesa: riprendila o abbandonala prima di avviarne una nuova."`.
  - Lo stesso toast viene mostrato in `_startRepeatSession()` se esiste una sessione sospesa.

## 2. Richiamo target nella barra del titolo di `#interrAsciiPopover`
- **`index.html`** & **`assets/styles/app.css`**: aggiunto `<span id="interrAsciiPopoverTarget" class="interr-target-badge is-hidden"></span>` nella `.interr-ascii-popover-header` prima del pulsante `✕`, allineato a destra con `margin-left: auto;`.
- **`js/ui/interrogation-ui.js`**: `_openAsciiPopover()` legge automaticamente `#interrTargetBadge` quando la vista `run` è attiva (o `opts.targetBadge` se passato esplicitamente) e lo espone in `#interrAsciiPopoverTarget`.
