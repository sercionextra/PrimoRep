# Catalogo domande e sotto-quesiti INTERROGAZIONE — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Fonti funzionali:** Specifica Tecnica Interrogazione v1.0 e decisioni consolidate  
**Fonte dati:** Catalogo QWERTY Italiano seed v1.0  
**Stato:** catalogo parziale attivo per dati verificati; nessuna modifica ai sorgenti.

## 1. Scopo e criterio di attivazione

Questo documento definisce le domande principali, i sotto-quesiti e le relative risposte ammesse per le quattro tipologie approvate. Sono attivate soltanto definizioni la cui risposta è ricavabile in modo univoco dal seed verificato. Le lacune restano esplicitamente bloccate: non vengono colmate con conoscenza ergonomica presunta.

La specifica stabilisce che ogni sotto-quesito possiede identità, stato, valutazione, storico e statistiche autonomi. La composizione di una domanda principale non fonde le statistiche dei suoi sotto-quesiti.

## 2. Inventario delle definizioni generate

| Tipologia | Definizioni attive | Aspetto | Fonte risposta |
|---|---:|---|---|
| HOME_ROW | 8 | Insieme esatto dei tasti Home row per dito operativo | `physicalKeys.row`, `assignedFinger` |
| TASTO | 52 | Identificazione del tasto fisico evidenziato | `physicalKeys.keyId`, `labelVariants` |
| CARATTERE | 333 | Tasto produttore, dito assegnato, modificatore richiesto | `characterMappings` |
| DITO | 52 | Dito competente per il tasto evidenziato | `physicalKeys.assignedFinger` |
| **Totale** | **445** | | |

Il JSON contiene le definizioni complete e deterministiche. I numeri indicano definizioni, non domande che devono necessariamente comparire tutte in una sessione. La selezione rispetta le modalità e le quote definite dalla specifica.

## 3. Domande principali e composizione

### 3.1 HOME_ROW

- **Singolo dito:** una domanda principale contiene il sotto-quesito relativo all’insieme dei tasti Home row assegnati al dito scelto.
- **Mano completa:** una domanda principale contiene quattro sotto-quesiti indipendenti, relativi ai quattro dita operativi della mano (sinistra: 1–4; destra: 7–10).
- Ogni sotto-quesito richiede l’insieme esatto dei tasti assegnati a quel dito, senza confondere il pollice con i quattro dita operativi.
- La modalità mano completa non crea una statistica aggregata aggiuntiva. Il punteggio della domanda principale è la somma dei quattro sotto-quesiti, secondo le regole generali.

I tasti Home row sono ricavati dal campo `row` del seed, non da una ricostruzione visiva. Il mignolo destro risulta associato a `key_ograve`, `key_agrave` e `key_ugrave`; questa è la mappatura della baseline, da sottoporre a validazione didattica prima di dichiarare completo il catalogo.

### 3.2 TASTO

Una domanda principale presenta un tasto fisico evidenziato sulla tastiera grafica e richiede di identificarne l’identità fisica. La risposta viene confrontata con `keyId`/`semanticId`, non con una semplice stringa visualizzata: in questo modo i simboli alternativi stampati sullo stesso tasto non diventano tasti fisici distinti.

Le etichette accettate sono conservate come metadato di presentazione e non sostituiscono l’identità fisica. I 52 elementi sono quelli realmente presenti nel seed, non l’intero layout dichiarato da 105 tasti.

### 3.3 CARATTERE

Per ogni carattere verificato sono definiti tre sotto-quesiti autonomi:

1. `producedByKey`: dato il carattere, identificare il tasto fisico che lo produce.
2. `assignedFinger`: dato il carattere, identificare il dito assegnato nella mappa.
3. `requiredModifier`: dato il carattere, identificare il modificatore richiesto (`none`, `shiftL`, `shiftR`, `altgr`, `shiftAltgr`).

La definizione non trasferisce conoscenza tra CARATTERE, TASTO e DITO. Anche se le risposte derivano dalla stessa relazione fisica, ogni sotto-quesito ha un `questionSemanticId` distinto.

Sono mantenute le 111 identità carattere del seed. Alias di controllo come newline e tabulazione sono inclusi soltanto se presenti come mapping sorgente; non vengono confusi con caratteri stampabili. La generazione inversa da tasto+modificatore a carattere non viene attivata per coppie non univoche: Enter/none e Tab/none hanno alias multipli.

### 3.4 DITO

Per ogni tasto fisico verificato è definito un sotto-quesito DITO: dato il tasto evidenziato, identificare il dito competente secondo la baseline. Il sotto-quesito usa un’identità di conoscenza DITO autonoma, distinta dalla stessa relazione interrogata in CARATTERE o TASTO.

La specifica comprende anche le caratteristiche di movimento/estensione. La baseline esaminata non fornisce misure o classificazioni sufficienti per domande univoche su questi aspetti: tali definizioni sono quindi **bloccate**, non attive.

## 4. Regole di risposta e valutazione

| Tipo risposta | Confronto |
|---|---|
| `PHYSICAL_KEY_ID` | Identità esatta del tasto fisico |
| `FINGER_ID` | Identificativo numerico esatto 1–10 |
| `MODIFIER_ID` | Valore enumerato esatto |
| `PHYSICAL_KEY_SET` | Insieme esatto, senza elementi mancanti o aggiuntivi |

Le policy sono deterministiche. Normalizzazioni cosmetiche dell’input possono essere applicate dalla UI, ma non devono trasformare una risposta semanticamente diversa in una risposta corretta. Il punteggio rimane quello generale: corretta +3, consultata +1, errata 0, non risposta 0.

## 5. Identità e versionamento

- Le identità `questionSemanticId` sono stabili finché resta invariato l’aspetto didattico verificato.
- Una modifica di testo o presentazione non crea una nuova identità.
- L’aggiunta di un aspetto autonomo crea un nuovo `questionSemanticId`.
- La modifica sostanziale della risposta attesa crea una nuova identità o una nuova versione secondo le regole di identità semantica; non trasferisce automaticamente conoscenza.
- Ogni sessione conserva snapshot della definizione usata; aggiornamenti successivi del catalogo non modificano sessioni in corso o sospese.

## 6. Elementi non attivati e dipendenze

| Area | Stato | Motivo |
|---|---|---|
| Catalogo completo 105 tasti | Bloccato/parziale | Seed certifica 52 tasti fisici; i restanti non sono ricostruibili dalle fonti esaminate. |
| DITO — movimento | Bloccato | Nessun modello per traiettoria, spostamento o movimento per dito nella baseline. |
| DITO — estensione | Bloccato | Nessuna misura o classificazione verificata di estensione per dito. |
| Home row — mignolo destro | Da validare didatticamente | La baseline associa tre tasti accentati al dito 10 nella riga centrale. |
| Identificazione inversa carattere da tasto+modificatore | Parziale | Coppie non univoche per alias Enter/newline e Tab/tabulazione. |
| Correzione incongruenza modificatori destri | Non effettuata | Richiede decisione sulla mappatura sorgente/SVG; nessuna correzione implicita. |

## 7. Criteri di accettazione

1. Ogni definizione attiva ha risposta attesa deterministica e fonte dati tracciabile.
2. Nessuna domanda usa uno dei 43 tasti non certificati.
3. Ogni sotto-quesito ha identità distinta e statistiche indipendenti.
4. HOME_ROW mano completa produce esattamente quattro sotto-quesiti indipendenti.
5. TASTO confronta identità fisica, non la sola etichetta stampata.
6. CARATTERE separa tasto, dito e modificatore.
7. DITO non attiva movimento/estensione finché non esiste una fonte verificata.
8. Le coppie tasto+modificatore non univoche non sono usate per domande inverse.
9. Le definizioni e i prompt sono congelati nello snapshot della sessione.
10. Casuale pura non legge statistiche; adattiva usa statistiche della specifica tipologia.

## 8. File strutturato

Il file `Catalogo_Domande_Interrogazione_v1.0.json` contiene 445 definizioni attive, template di domanda principale e definizioni bloccate. È derivato esclusivamente dal seed v1.0. Il file è un artefatto progettuale e non viene ancora caricato dall’applicazione.

## 9. Esito

La struttura delle quattro tipologie è definita per i dati attualmente verificabili. Il catalogo è **parziale ma utilizzabile per progettare e testare i contratti**; non è ancora un seed di produzione completo per il layout italiano a 105 tasti. Per dichiararlo completo servono il completamento verificato dei tasti mancanti e la validazione didattica dei casi esplicitamente elencati.
