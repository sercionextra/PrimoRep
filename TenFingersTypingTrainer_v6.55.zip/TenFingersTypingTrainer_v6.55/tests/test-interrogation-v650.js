#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const assert = require("assert");

const ROOT = path.resolve(__dirname, "..");

const sb = {
  console,
  window: {},
};
sb.globalThis = sb;
vm.createContext(sb);

const metaCode = fs.readFileSync(
  path.join(ROOT, "js/interrogation/interrogation-layout-metadata.js"),
  "utf8"
);
vm.runInContext(metaCode, sb, { filename: "interrogation-layout-metadata.js" });

const meta = sb.window.InterrogationLayoutMetadata || sb.InterrogationLayoutMetadata;
assert(meta, "InterrogationLayoutMetadata deve essere definito");

// 1. Verifica key_backslash ("|" / "\"): estensione laterale = 2 (sn), longitudinale = 2
const backslashExt = meta.getKeyExtension("key_backslash");
assert.strictEqual(backslashExt.lateralExt, 2, "key_backslash lateralExt deve essere 2");
assert.strictEqual(backslashExt.lateralDir, "sn", "key_backslash lateralDir deve essere sn");
assert.strictEqual(backslashExt.longitudinalExt, 2, "key_backslash longitudinalExt deve essere 2");

// 2. Verifica key_space ("SPAZIO"): estensione longitudinale = -2
const spaceExt = meta.getKeyExtension("key_space");
assert.strictEqual(spaceExt.longitudinalExt, -2, "key_space longitudinalExt deve essere -2");

// 3. Verifica che selLongExt in interrogation-ui.js contenga l'opzione "-2"
const uiCode = fs.readFileSync(
  path.join(ROOT, "js/ui/interrogation-ui.js"),
  "utf8"
);
assert(
  uiCode.includes('{ v: "-2", l: "-2 (2 righe sotto riposo)" }'),
  "selLongExt deve includere l'opzione -2 (2 righe sotto riposo)"
);

console.log("PASS: test-interrogation-v650.js (key_backslash lateralExt=2, selLongExt -2 per SPAZIO)");
