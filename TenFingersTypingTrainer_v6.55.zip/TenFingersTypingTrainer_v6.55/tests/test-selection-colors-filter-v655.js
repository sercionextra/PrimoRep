const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");

function makeDot(idx, type) {
  const attrs = {
    "data-idx": String(idx),
    "data-type": String(type),
    fill: "",
    stroke: "none",
    "stroke-width": "0",
    r: "4",
  };
  return {
    classList: {
      _set: new Set(["speed-point"]),
      add(c) {
        this._set.add(c);
      },
      remove(c) {
        this._set.delete(c);
      },
      contains(c) {
        return this._set.has(c);
      },
    },
    setAttribute(k, v) {
      attrs[k] = String(v);
    },
    getAttribute(k) {
      return attrs[k];
    },
  };
}

const dots = [makeDot(0, 2), makeDot(1, 6), makeDot(2, 5)];
const elements = new Map();
function getEl(id) {
  if (!elements.has(id)) {
    elements.set(id, {
      id,
      value: "",
      innerText: "",
      textContent: "",
      disabled: false,
      style: {},
    });
  }
  return elements.get(id);
}

const sandbox = {
  console,
  htmlEscape: (s) => String(s),
  document: {
    getElementById: getEl,
    querySelectorAll: (sel) => (sel === ".speed-point" ? dots : []),
  },
};

const code = fs.readFileSync(
  path.join(root, "js/analytics/statistics-manager.js"),
  "utf8",
);
vm.runInNewContext(code, sandbox, { filename: "statistics-manager.js" });

const StatisticsManager = vm.runInNewContext("StatisticsManager", sandbox);
const profile = {
  Campioni: [
    { Index: 0, TipoCampione: 2, BattuteMinuto: 120, DataOra: "2026-11-20T09:15:10" },
    { Index: 1, TipoCampione: 6, BattuteMinuto: 150, DataOra: "2026-11-21T14:05:30" },
    { Index: 2, TipoCampione: 5, BattuteMinuto: 180, DataOra: "2026-11-22T18:45:00" },
  ],
};
const mgr = new StatisticsManager({ profile });
mgr.currentFilteredSamples = profile.Campioni;

// 1. Verifica che clearSelection() ripristini i colori originali e azzeri stroke/raggio
dots[0].setAttribute("fill", "#f59e0b");
dots[0].setAttribute("stroke", "#ffffff");
dots[0].setAttribute("r", "6");
dots[1].setAttribute("fill", "#f59e0b");
dots[2].setAttribute("fill", "#f59e0b");

mgr.selectedSampleIndices = new Set([0, 1, 2]);
mgr.clearSelection();

assert.strictEqual(dots[0].getAttribute("fill"), mgr.getSampleTypeColor(2));
assert.strictEqual(dots[1].getAttribute("fill"), mgr.getSampleTypeColor(6));
assert.strictEqual(dots[2].getAttribute("fill"), mgr.getSampleTypeColor(5));
for (const d of dots) {
  assert.strictEqual(d.getAttribute("stroke"), "none");
  assert.strictEqual(d.getAttribute("stroke-width"), "0");
  assert.strictEqual(d.getAttribute("r"), "4");
}
assert.strictEqual(getEl("btnFilterToSelection").style.visibility, "hidden");
assert.strictEqual(getEl("btnFilterToSelection").disabled, true);

// 2. Verifica applySelectionDateTimeRange() sui campioni 0 e 1
let renderCalled = false;
mgr.renderSpeedChart = () => {
  renderCalled = true;
};
mgr.selectedSampleIndices = new Set([0, 1]);
const res = mgr.applySelectionDateTimeRange();
assert.strictEqual(res.ok, true);
assert.strictEqual(getEl("filterStartDate").value, "2026-11-20");
assert.strictEqual(getEl("filterStartTime").value, "09:15");
assert.strictEqual(getEl("filterEndDate").value, "2026-11-21");
assert.strictEqual(getEl("filterEndTime").value, "14:05");
assert.strictEqual(mgr.selectedSampleIndices.size, 0);
assert.strictEqual(renderCalled, true);

// 3. Verifica che il pulsante sia presente in index.html e cablato in metodi-statistiche.js
const html = fs.readFileSync(path.join(root, "index.html"), "utf8");
const ctrl = fs.readFileSync(
  path.join(root, "js/app/controller/metodi-statistiche.js"),
  "utf8",
);
assert.ok(html.includes('id="btnFilterToSelection"'));
assert.ok(ctrl.includes("applySelectionDateTimeRange"));

console.log("PASS test-selection-colors-filter-v655");
