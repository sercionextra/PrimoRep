# 01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.5)

## 1. Visione Generale, Mission e Obiettivi del Progetto

Il progetto **Ten Fingers Typing Trainer (Web Edition SPA)** costituisce il porting moderno, fedele e potenziato dell'omonimo applicativo desktop originario sviluppato in C#/VB.NET per Windows Forms (`Tastiera10Dita.exe`).

### 1.1 Mission Didattica ed Ergonomica
L'obiettivo primario ed inderogabile dell'applicazione è guidare l'utente nell'acquisizione dell'abilità di **digitazione cieca a dieci dita (touch-typing)** su tastiera italiana standard a 105 tasti (layout **QWERTY IT**), eliminando totalmente la necessità di abbassare lo sguardo sulla tastiera fisica.

Per raggiungere questo scopo pedagogico, l'applicazione adotta una strategia multi-sensoriale simultanea:
1. **Guida Visiva Ergonomica A Schermo**: visualizzazione coordinata di una tastiera virtuale con codifica cromatica unificata per dito e di una finestra con le due mani anatomiche in grafica vettoriale continua SVG.
2. **Keycaps 3D sui Polpastrelli**: sui polpastrelli delle dita virtuali compare direttamente il tasto da premere, con evidenziazione del dito esatto e dei modificatori incrociati.
3. **Motore Didattico dell'Errore in Tempo Reale**: inibizione dell'avanzamento errato, espansione cromatica rossa sul testo guida proporzionale al numero di errori commessi e generazione di spazi rossi fittizi per gli sforamenti.
4. **Metronomo / Feedback Sonoro Polifonico**: simulazione sonora ad alta risoluzione tramite Web Audio API di macchine da scrivere meccaniche, allarmi di errore e campanello di fine esercizio.
5. **Monitoraggio Analitico Continuo**: tracciamento rigoroso e persistente delle metriche prestazionali (Battute al Minuto lorde e nette, frequenza ed errori per ciascuno dei 106 caratteri della tastiera, cronologia di apprendimento).

### 1.2 Vincoli Architetturali e di Porting
- **Zero Dipendenze Esterne**: architettura Single Page Application (SPA) pura in TypeScript/Vanilla JavaScript, CSS3 e SVG inline. Nessun runtime bloccante (Node.js/npm) a runtime nel client, nessun server applicativo obbligatorio.
- **Portabilità Assoluta**: esecuzione garantita "out-of-the-box" aprendo il file sorgente `index.html` in qualsiasi browser web moderno aderente agli standard W3C.
- **Isolamento e Sicurezza**: persistenza nativa nel client tramite `localStorage`, con esportazione e importazione diretta di file in formato JSON e XML retrocompatibili con lo schema C# originale (`DataSetArchivio.xsd`).

---

## 2. Cronologia e Decisioni Architetturali Consolidate (v.1.0 - v.2.4)

Tutte le determinazioni assunte nel corso delle sessioni di sviluppo pregresse sono consolidate nell'attuale release operativa `v.2.4` e costituiscono requisiti intangibili:

1. **Disaccoppiamento ad Oggetti (v.1.0 - v.1.3)**:
   - Suddivisione della logica in 8 moduli di classe specializzati: `TypingEngine`, `VisualRenderer`, `StatisticsManager`, `ProfileManager`, `PhonemeEngine`, `AudioEngine`, `WindowManager`, `AppController`.
   - Finestre fluttuanti indipendenti (Mani, Tastiera, Statistiche, Help, Editor) dotate di gestione drag & drop e ridimensionamento elastico con salvataggio delle coordinate geometriche nel profilo utente.
2. **Corpora Didattici e 6 Modalità Operative (v.1.0 - v.1.3)**:
   - Integrazione completa delle **70 lezioni didattiche native** di `TypingTrainerDefault.txt`.
   - Implementazione delle 6 modalità canoniche: `PHRASES` (ALT+P), `RANDOM` (ALT+R), `FONEMI` (ALT+F), `ALL CHARS` (ALT+C / F12), `TYPING` (ALT+T), `RANDOM THIS PHRASE` (ALT+I / F11).
   - Generatore fonetico probabilistico basato su N-gram sillabici estratti dal corpus letterario italiano `TypingTrainerFonemi.txt`.
3. **Disabilitazione dell'Auto-Repeat da Tastiera (v.1.4)**:
   - Blocco sistematico del flag `e.repeat` nei listener degli eventi da tastiera per impedire l'accumulo passivo di battute mantenendo premuto un tasto.
4. **Modello Anatomico Vettoriale Continuo SVG per le Mani (v.1.5 - v.1.10)**:
   - Dismissione completa delle vecchie bitmap/GIF rasterizzate a bassa risoluzione.
   - Creazione di un modello SVG bimanuale a silhouette chiusa unificata (viewBox 1408x768), ad altissima fedeltà anatomica, con identificatori geometrici precisi per i 10 polpastrelli (`#f1` - `#f10`) e baricentri fissati con attributi semantici `data-cx` e `data-cy`.
5. **Keycaps 3D sui Polpastrelli ed Ergonomia Visiva (v.2.0)**:
   - Posizionamento dinamico di bottoni vettoriali (keycaps) arrotondati direttamente sopra i polpastrelli del modello delle mani.
   - Bordo cromatico coordinato con il codice colore del rispettivo dito e filtro `drop-shadow` volumetrico.
6. **Motore Didattico di Errore ad Espansione Cromatica (v.2.0)**:
   - In presenza di errori di digitazione, il testo originale espande un background rosso intenso (`char-error-target`) per un numero di glifi esattamente pari a quello degli errori commessi.
   - Se l'utente digita tasti errati oltre la fine della frase, vengono sintetizzati a schermo glifi fittizi di spazio rosso (`␣`), scongiurando eccezioni di string slicing o disallineamenti di layout.
7. **Reset Totale con Backspace a Inizio Frase (v.2.0)**:
   - Se l'utente preme il tasto Backspace cancellando tutti i caratteri digitati fino a lunghezza 0, il motore ferma il timer della sessione (`timerRunning = false`, `startTime = null`) e ripristina la frase iniziale. Le metriche BTM/WPM non si azzerano né degradano per il tempo trascorso a vuoto.
8. **Grafici Cartesiani Fullscreen con Crosshair Quota Y (v.2.0)**:
   - Finestra statistiche responsive a tutto schermo con ridisegno automatico tramite `ResizeObserver`.
   - Crosshair cartesiano mobile con linea orizzontale rossa e badge dinamico mostrante l'esatta quota del valore Y sotto il puntatore del mouse.
   - Formattazione naturale standardizzata per le percentuali d'errore a un decimale: `NN.N%`.
9. **Risoluzione Selezione a 3 Click nel Grafico Statistiche (v.2.1)**:
   - 1° Click: selezione dell'intervallo campioni.
   - 2° Click: selezione puntuale del singolo campione.
   - 3° Click: ripristino immediato della media globale con azzeramento `selectionState = 0`.
10. **Navigazione Diretta Frasi tramite UI e Modale (v.2.2)**:
    - Inserimento del pulsante esplicito `📖 Vai a Frase...` nella Toolbar 2.
    - Badge `lblPhraseRange` reso interattivo/cliccabile con cursore pointer e stato hover.
    - Integrazione nella modale del selettore a discesa delle lezioni (`selSelectPhraseLesson`) con sincronizzazione automatica bidirezionale rispetto a `cboLessons`.
11. **Persistenza Continua degli Accordi Fisici su Polpastrelli (v.2.3)**:
    - Eliminazione del timer di spegnimento a 180 ms.
    - Macchina a stati hardware `activePhysicalKeys`: i tasti premuti rimangono costantemente illuminati sui polpastrelli finché i rispettivi tasti fisici non vengono sollevati (`keyup`), consentendo la visualizzazione fedele di modificatori trattenuti a tempo indefinito.
12. **Ingrandimento Keycaps Polpastrelli a 1.5x (v.2.4)**:
    - Scalatura delle dimensioni dei keycaps sui polpastrelli a 87x78 px.
    - Font tipografico a 48 px ultra-bold (peso 900) con contorno protettivo anti-alone da 6 px (`paint-order: stroke fill`).
    - Bordo colorato elevato a 4.8 px e raggio di sfumatura dell'ombra a 16 px.
    - Espansione dinamica automatica della larghezza fino a 174 px per la barra spaziatrice e modificatori estesi con preservazione del centraggio sul baricentro del dito.

---

## 3. Architettura Logica e Modulare del Software

L'applicazione è strutturata su 8 classi JavaScript/TypeScript a responsabilità unica e rigorosamente disaccoppiate:

```text
+-----------------------------------------------------------------------------------------+
|                                    AppController                                        |
|  - Orchestratore globale e ciclo di vita della Single Page Application                  |
|  - Binding eventi interfaccia, hotkeys globali, commutazione temi, menu e modali        |
+---+-------------------+-------------------+-------------------+-------------------+-----+
    |                   |                   |                   |                   |
    v                   v                   v                   v                   v
+---------------+ +---------------+ +---------------+ +---------------+ +---------------+
| TypingEngine  | |VisualRenderer | |StatisticsMgr  | | ProfileManager| |  AudioEngine  |
| - Gestore     | | - Renderer    | | - Istogrammi  | | - Gestione    | | - Sintetizzatore|
|   didattico   | |   SVG mani    | |   frequenze   | |   profili     | |   Web Audio   |
|   digitazione | | - Keycaps 3D  | | - Grafico     | |   multi-utente| | - Click tasti |
| - Timer e WPM | | - Tastiera    | |   velocità    | | - I/O JSON/XML| | - Beep errore |
| - Error logic | | - Accordi HW  | | - Crosshair Y | | - localStorage| | - Campana fine|
+---------------+ +---------------+ +---------------+ +---------------+ +---------------+
        |                                                                   ^
        v                                                                   |
+---------------+                                                   +---------------+
| PhonemeEngine |                                                   | WindowManager |
| - Algoritmo   |                                                   | - Finestre    |
|   Markoviano  |                                                   |   fluttuanti  |
| - N-gram IT   |                                                   | - Drag/Resize |
+---------------+                                                   +---------------+
```

### 3.1 `TypingEngine`
- **Scopo**: cuore logico del calcolo dattilografico e della verifica didattica.
- **Responsabilità**:
  - Mantenimento del testo proposto (`targetText`) e del testo digitato (`typedText`).
  - Misurazione temporale ad alta precisione (`startTime`, `endTime`, `timerRunning`).
  - Calcolo delle metriche istantanee: battute lorde al minuto, battute nette al minuto (BTM), conteggio errori, percentuale di errore formattata a un decimale (`NN.N%`).
  - Gestione della modalità autocorrezione (`automaticCorrection`): inibizione del Backspace e rifiuto dell'avanzamento su tasto errato.
  - Generazione dinamica di sequenze per le modalità casuali (`RANDOM`, `ALL CHARS`, `RANDOM THIS PHRASE`).
  - Reset pulito con Backspace a inizio riga e arresto del cronometro.

### 3.2 `VisualRenderer`
- **Scopo**: coordinamento grafico vettoriale della tastiera a schermo e delle mani anatomiche.
- **Responsabilità**:
  - Evidenziazione del tasto target corrente sulla tastiera virtuale con effetto lampeggio (`BlinkTimer` a circa 300 ms).
  - Gestione della **Regola dei Modificatori Incrociati**:
    - Se il carattere target appartiene alla mano sinistra (dita 1, 2, 3, 4), viene illuminato lo **Shift Destro** (dito 10).
    - Se il carattere target appartiene alla mano destra (dita 7, 8, 9, 10), viene illuminato lo **Shift Sinistro** (dito 1).
    - Se richiede `AltGr`, viene attivato il pollice/indice destro (dito 6).
  - Proiezione dinamica dei keycaps 3D (87x78 px) sui polpastrelli anatomici SVG con colorazione associata al dito.
  - Gestione della macchina a stati hardware `activePhysicalKeys` per la persistenza e il rilascio selettivo dei singoli tasti durante accordi complessi.
  - Aggiornamento dello stato dei LED della tastiera (Caps Lock, Num Lock, Scroll Lock).

### 3.3 `StatisticsManager`
- **Scopo**: aggregazione, elaborazione statistica e rendering grafico dei dati prestazionali.
- **Responsabilità**:
  - **Vista 1 (Istogramma Frequenze ed Errori)**: rendering SVG vettoriale delle frequenze d'uso e del tasso di errore per ciascuno dei caratteri utilizzati, ordinabili per:
    1. Frequenza decrescente (con errore relativo)
    2. Frequenza decrescente (con errore assoluto)
    3. Errori relativi decrescenti
    4. Errori assoluti decrescenti
    5. Raggruppamento per dito (errore relativo)
    6. Raggruppamento per dito (errore assoluto)
  - **Vista 2 (Grafico Cronologico di Velocità)**: rendering cartesiano continuo della successione temporale delle sessioni completate (`CampioniVelocita`).
    - Commutazione asse Y: Battute/min, Numero caratteri, % Errore relativo, Errori assoluti.
    - Filtro per tipologia di esercizio (Phrases All Letters, Phrases Custom, Random, Typing, Fonemi, ecc.).
    - Crosshair responsive con tracking orizzontale della quota Y sotto il puntatore.
    - Macchina a stati di selezione a 3 click (Intervallo -> Singolo Punto -> Reset globale).
    - Eliminazione campioni selezionati o azzeramento completo delle statistiche del profilo.

### 3.4 `ProfileManager`
- **Scopo**: persistenza locale e gestione multi-utente.
- **Responsabilità**:
  - Creazione, caricamento, selezione ed eliminazione dei profili utente (`UserID`).
  - Salvataggio dello stato della sessione per ciascun profilo (ultima lezione selezionata, indice esercizio, modalità d'uso, flag autocorrezione, geometrie delle finestre fluttuanti).
  - Archivio delle prestazioni: tabella dei 106 caratteri (`AlfabetoType`) con frequenza ed errori commessi; array cronologico dei campioni di velocità (`CampioniVelocita`).
  - Funzioni di esportazione e importazione in formato JSON proprietario e in formato XML conforme allo schema C# originale (`DataSetArchivio.xsd`).

### 3.5 `PhonemeEngine`
- **Scopo**: generazione algoritmica di sequenze testuali pseudo-linguistiche per l'allenamento sillabico.
- **Responsabilità**:
  - Caricamento del corpus fonetico italiano di riferimento (`TypingTrainerFonemi.txt`).
  - Generazione N-gram: ricerca di confini di parola tramite espressioni regolari e costruzione di catene sillabiche a finestra mobile (lunghezza 4 caratteri), fino alla saturazione del limite impostato (100 caratteri).

### 3.6 `AudioEngine`
- **Scopo**: generazione sintetica a bassa latenza dei segnali audio senza campioni audio esterni.
- **Responsabilità**:
  - Inizializzazione lazy dell'AudioContext di Web Audio al primo gesto dell'utente.
  - Sintesi polifonica di 4 modalità audio:
    1. `Mute`: silenzioso.
    2. `Typewriter`: sintesi impulsiva a doppia componente (rumore bianco filtrato + risonanza metallica percussiva) che simula la pressione di tasti meccanici.
    3. `Beep`: onda quadra a 440 Hz / 880 Hz per segnalazione immediata di errore dattilografico.
    4. `Bell`: risonanza sinusoidale smorzata ad alta frequenza (2000 Hz) per segnalare il completamento della riga o dell'esercizio.
  - Regolazione volumetrica master.

### 3.7 `WindowManager`
- **Scopo**: gestione dell'interfaccia a finestre fluttuanti nel viewport del browser.
- **Responsabilità**:
  - Riconoscimento del trascinamento (drag) tramite header delle finestre fluttuanti (Mani, Tastiera, Statistiche, Help, Editor Custom) con limiti di contenimento all'interno della finestra del browser.
  - Riconoscimento del ridimensionamento elastico (resize) tramite maniglie angolari.
  - Coordinamento dello z-index per portare in primo piano la finestra cliccata.
  - Salvataggio e ripristino delle coordinate `(left, top, width, height)` nel profilo utente attivo.

### 3.8 `AppController`
- **Scopo**: controllore generale, mediatore di comunicazione tra i moduli e dispatcher degli eventi di sistema.
- **Responsabilità**:
  - Intercettazione globale degli eventi `keydown` e `keyup` della tastiera.
  - Dispatching delle scorciatoie da tastiera (Hotkeys) con inibizione selettiva dei tasti funzione di default del browser.
  - Gestione della selezione lezioni, commutazione modalità didattiche e apertura/chiusura modali.
  - Controllo dei temi grafici dell'applicazione (Light Mode, Dark Slate, High Contrast).

---

## 4. Formati Dati di Input e Output

### 4.1 Formato File Esercizi Didattici (`TypingTrainerDefault.txt` e `TypingTrainerCustom.txt`)
I testi per le lezioni didattiche strutturate e per i corsi personalizzati utilizzano un formato testuale semplice basato su marcatori di riga:

```text
=====NomeLezione=====
Frase 1 della lezione.
=====
Frase 2 della lezione.
=====
Frase su più righe.
Seconda riga della stessa frase.
=====
```

- **Intestazione di Lezione**: riga delimitata da `=====` sia all'inizio che alla fine. Il nome della lezione viene ricavato estraendo il testo interno: `line.substring(5, line.length - 5)`. Esempi: `=====asdfl=====`, `=====g=====`, `=====Custom File=====`.
- **Separatore di Frase**: una riga costituita esattamente da 5 caratteri di uguale (`=====`). Separa due esercizi successivi all'interno della medesima lezione.
- **Caratteri Speciali Multiriga e Rientri**:
  - Quando una frase contiene ritorni a capo interni prima del successivo `=====`, il parser concatena le righe inserendo il carattere speciale `®` (Unicode `\u00AE`), che simboleggia graficamente e funzionalmente il tasto **Invio**.
  - Le sequenze di 4 spazi consecutivi (`"    "`) o i caratteri di tabulazione vengono convertiti nel glifo speciale `→` (Unicode `\u2192`), simboleggiante il tasto **Tab**.

### 4.2 Formato Corpus Fonemi (`TypingTrainerFonemi.txt`)
Contiene prosa letteraria italiana continua non formattata, utilizzata dall'algoritmo di `PhonemeEngine` per estrarre la frequenza empirica di accoppiamento sillabico e consonantico tipico della lingua italiana.

### 4.3 Formato XML di Persistenza Originale C# (`XMLApplicationData.xml`)
L'interscambio con i salvataggi della versione desktop C# rispetta fedelmente la struttura `DataSetArchivio.xsd`:

```xml
<?xml version="1.0" standalone="yes"?>
<DataSetArchivio xmlns="http://tempuri.org/DataSetArchivio.xsd">
  <Utente>
    <UserID>ALBERTO</UserID>
    <Mode>0</Mode>
    <Lesson>0</Lesson>
    <Exercise>0</Exercise>
    <AutomaticCorrection>false</AutomaticCorrection>
    <ShowKeyBoard>true</ShowKeyBoard>
    <ShowHands>true</ShowHands>
    <ShowOrigin>true</ShowOrigin>
    <ShowTyped>true</ShowTyped>
    <KeyBoardX>50</KeyBoardX>
    <KeyBoardY>100</KeyBoardY>
    <KeyBoardWidth>800</KeyBoardWidth>
    <KeyBoardHeight>250</KeyBoardHeight>
    <HandsX>100</HandsX>
    <HandsY>380</HandsY>
    <HandsWidth>700</HandsWidth>
    <HandsHeight>380</HandsHeight>
  </Utente>
  <Caratteri>
    <UserID>ALBERTO</UserID>
    <CharAscii>97</CharAscii>
    <Frequenza>142</Frequenza>
    <Errori>3</Errori>
  </Caratteri>
  <CampioniVelocita>
    <UserID>ALBERTO</UserID>
    <DataOra>2026-10-01T12:00:00</DataOra>
    <BattuteMinuto>185</BattuteMinuto>
    <NumeroErrori>2</NumeroErrori>
    <NumeroCaratteri>68</NumeroCaratteri>
    <TipoSessione>0</TipoSessione>
    <TitoloEsercizio>asdfl</TitoloEsercizio>
  </CampioniVelocita>
</DataSetArchivio>
```

### 4.4 Formato JSON di Storage nel Browser (`localStorage`)
La persistenza web utilizza la chiave `typingTrainer_users_v1` in `localStorage` contenente una mappa serializzata dei profili:

```json
{
  "ALBERTO": {
    "userId": "ALBERTO",
    "mode": 0,
    "lesson": 0,
    "exercise": 0,
    "automaticCorrection": false,
    "showKeyBoard": true,
    "showHands": true,
    "showOrigin": true,
    "showTyped": true,
    "customLessonsText": "",
    "chars": {
      "97": { "freq": 142, "errors": 3 }
    },
    "samples": [
      {
        "date": "2026-10-01T12:00:00.000Z",
        "btm": 185,
        "errors": 2,
        "chars": 68,
        "mode": 0,
        "title": "asdfl"
      }
    ],
    "windowLayout": {
      "hands": { "left": 100, "top": 380, "width": 700, "height": 380 },
      "keyboard": { "left": 50, "top": 100, "width": 800, "height": 250 }
    }
  }
}
```

---

## 5. Mappatura Dettagliata dei Componenti dell'Interfaccia Utente

L'interfaccia utente è interamente reattiva e organizzata in sezioni ergonomiche ben distinte:

### 5.1 Header Superiore (Barra del Titolo e Controlli Globali)
- `#lblAppTitle`: titolo dell'applicazione recante l'indicazione della versione consolidata (`Ten Fingers Typing Trainer (v.2.4) - Web Edition`).
- `#themeSelect`: menu a discesa per la selezione del tema cromatico dell'interfaccia (`Dark Modern`, `Light Classic`, `High Contrast Matrix`).
- `#audioModeSelect`: selettore audio polifonico (`Typewriter`, `Beep Error`, `Mute`).
- `#audioVolume`: slider per la regolazione lineare del volume audio (0% - 100%).
- `#lblCurrentUser`: badge che mostra l'identificativo del profilo utente attualmente loggato (default: `ALBERTO`).
- `#btnHeaderSwitchUser`: pulsante per l'apertura della modale di gestione e commutazione utenti/profili.
- `#btnOpenCustomEditor`: pulsante con icona matita per l'apertura dell'editor di lezioni personalizzate.
- `#btnOpenStats`: pulsante grafico per l'apertura a schermo della finestra di visualizzazione statistiche.
- `#btnHelpLink`: pulsante per l'accesso immediato alla guida in linea e manuale utente.

### 5.2 Toolbar 1 - Navigazione Didattica e Selezione Esercizi
- `#cboMode`: selettore a discesa della modalità di funzionamento:
  - `0`: PHRASES (Esercizi guidati su frasi di senso compiuto)
  - `1`: RANDOM (Sequenze di 20 caratteri casuali ponderati sulla lezione)
  - `2`: FONEMI (Sillabario continuo N-gram della lingua italiana)
  - `3`: ALL CHARS (Sequenze rimescolate di tutti i tasti e simboli)
  - `4`: TYPING (Digitazione libera con conteggio errori su Backspace)
  - `5`: RANDOM THIS PHRASE (Rimescolamento dei soli caratteri della frase corrente)
- `#btnPrevLesson`: pulsante freccia sinistra per retrocedere alla lezione didattica precedente.
- `#cboLessons`: selettore a discesa delle 70 lezioni native (o delle lezioni del file personalizzato).
- `#btnNextLesson`: pulsante freccia destra per avanzare alla lezione didattica successiva.
- `#btnToggleLessonSource`: pulsante per commutare tra il corpus standard (`Default 70 Lezioni`) e il file personalizzato (`Custom File`).
- `#lblLessonSource`: etichetta di stato che evidenzia la sorgente corrente attiva (`Standard` o `Custom`).
- `#lblPhraseRange`: **badge interattivo e cliccabile** che indica l'intervallo numerico delle frasi appartenenti alla lezione attiva (es. `Frasi: 1 - 21`). Cliccando apre direttamente la modale di salto a frase.
- `#lblExerciseTitle`: etichetta testuale dinamica recante il titolo della lezione o dell'esercizio correntemente visualizzato.

### 5.3 Toolbar 2 - Controlli Frasi e Gestione Visibilità Finestre
- `#btnPrevPhrase`: pulsante `<` (o hotkey `F6`) per passare alla frase precedente della lezione.
- `#btnNextPhrase`: pulsante `>` (o hotkey `F7`) per passare alla frase successiva della lezione.
- `#btnSelectPhraseModal`: pulsante esplicito `📖 Vai a Frase...` per l'apertura della modale di selezione diretta per indice numerico (hotkey `F8` o `CTRL+SHIFT+E`).
- `#btnRandomPhrase`: pulsante `🔀 Frase Casuale` (hotkey `ALT+M`) per estrarre una frase casuale tra quelle della lezione.
- `#btnRestartPhrase`: pulsante `🔄 Riavvia Frase` (hotkey `ALT+A` o `F9`) per azzerare la sessione corrente e ripartire dal primo carattere.
- `#btnRandomThisPhrase`: pulsante `🔀 Rimescola Frase` (hotkey `ALT+I` o `F11`) per rimescolare i glifi della frase corrente.
- `#btnRandomAllChars`: pulsante `⌨️ Tutti i Tasti` (hotkey `ALT+L` o `F12`) per caricare un esercizio globale con tutti i simboli.
- Checkbox di visibilità e opzioni:
  - `#chkShowKeyBoard`: attiva/disattiva la finestra della tastiera virtuale (hotkey `ALT+K`).
  - `#chkShowHands`: attiva/disattiva la finestra vettoriale delle mani (hotkey `ALT+W`).
  - `#chkShowOrigin`: visualizza/nasconde la riga del testo guida originale (hotkey `ALT+O`).
  - `#chkShowTyped`: visualizza/nasconde la casella del testo digitato (hotkey `ALT+Y`).
  - `#chkAutomaticCorrection`: attiva la modalità rigorosa di autocorrezione senza Backspace (hotkey `ALT+B` o `F5`).

### 5.4 Area di Digitazione e Feedback Didattico
- `#txtOriginContainer`: contenitore del testo guida di riferimento. Ogni carattere della frase è inserito in uno `span` indipendente:
  - Classe `.char-pending`: carattere futuro non ancora digitato.
  - Classe `.char-target`: carattere bersaglio corrente, evidenziato con cursore visivo lampeggiante e contrasto cromatico elevato.
  - Classe `.char-correct`: carattere digitato correttamente (colore attenuato).
  - Classe `.char-error-target`: evidenziazione con background rosso scuro intenso su tutti i caratteri coinvolti in errori consecutivi.
  - Glifi fittizi `␣`: spazi rossi generati dinamicamente qualora l'utente abbia digitato caratteri errati eccedenti la lunghezza residua della frase.
- `#txtTypedInput`: casella di input attiva con focus permanente. Mostra in tempo reale il testo digitato dall'utente e applica lo sfondo verde chiaro al completamento positivo dell'esercizio.
- `#panelFixingData`: pannello a scomparsa attivo esclusivamente in modalità `TYPING` (libera):
  - `#txtFixingTime`: tempo impiegato nella sessione di scrittura libera.
  - `#txtFixingRightEverage`: battute al minuto nette registrate.
  - `#txtFixingTotalEverage`: battute al minuto lorde registrate.
  - `#btnAddStatistic`: pulsante per consolidare e salvare la sessione libera nell'archivio storico dei campioni.
  - `#btnClearTypingSession`: pulsante per azzerare il testo libero digitato.

### 5.5 Dashboard Metriche in Tempo Reale
- `#txtTime`: visualizzazione del tempo trascorso in formato naturale `MM:SS`.
- `#txtRightChars`: numero assoluto di battute valide/corrette digitate nella sessione.
- `#txtRightEverage`: velocità netta espressa in **Battute al Minuto (BTM / WPM)** calcolata sui soli caratteri corretti.
- `#txtTotalEverage`: velocità lorda espressa in Battute al Minuto complessive (inclusi errori).
- `#txtErrors`: conteggio assoluto degli errori commessi nella sessione.
- `#txtPercErrors`: percentuale di errore complessiva esposta nel formato standard a un decimale: `NN.N%`.

### 5.6 Finestra Tastiera Virtuale QWERTY IT (105 Tasti)
- Finestra fluttuante, spostabile tramite barra superiore `#keyboardHeader` e ridimensionabile tramite maniglia ad angolo.
- Schema grafico completo del layout italiano QWERTY a 105 tasti con codice colore per dito:
  - Tasti Mignolo Sinistro / Destro (Dita 1 e 10): Rosso (`#ef4444`)
  - Tasti Anulare Sinistro / Destro (Dita 2 e 9): Arancione (`#f59e0b`)
  - Tasti Medio Sinistro / Destro (Dita 3 e 8): Verde Smeraldo (`#10b981`)
  - Tasti Indice Sinistro / Destro (Dita 4 e 7): Blu Elettrico (`#3b82f6`)
  - Tasti Pollici (Dita 5 e 6): Viola (`#a855f7`) per barra spaziatrice e AltGr
- Feedback del tasto bersaglio: lampeggio a circa 300 ms (`BlinkTimer`) sul tasto da premere.
- Feedback del tasto premuto: flash transitorio sul tasto fisico effettivamente intercettato.
- Indicatori di stato a LED: indicatori luminosi per `Bloc Maiusc` (Caps Lock), `Bloc Num` (Num Lock) e `Bloc Scorr`.

### 5.7 Finestra Mani SVG Alta Fedeltà Anatomica
- Finestra fluttuante con barra `#handsHeader`, controlli di centratura `#btnHandsCenter`, chiusura `#btnHandsClose` e maniglia di ridimensionamento elastico.
- Disegno vettoriale continuo SVG bimanuale (viewBox 1408x768):
  - Sagoma chiusa con raccordi anatomici tra dita, palmi e polsi.
  - Tracciamento semantico dei 10 polpastrelli (`data-finger="1"` .. `"10"`) con coordinate baricentriche fisse `(data-cx, data-cy)`.
  - **Keycaps 3D sui Polpastrelli (v.2.4)**:
    - Rettangoli arrotondati (`rx="14" ry="14"`) posizionati sopra ciascun polpastrello.
    - Dimensioni base: **87x78 px**, scalate uniformemente a 1.5x rispetto alle prime bozze.
    - Bordo colorato coordinato con il dito di spessore **4.8 px** e filtro ombra `drop-shadow` volumetrico con sfumatura di **16 px**.
    - Tipografia: font sans-serif ultra-bold a **48 px** (peso 900) con contorno protettivo anti-alone scuro da **6 px** per preservare la leggibilità contro qualsiasi contrasto.
    - Espansione dimensionale dinamica per etichette lunghe: larghezza aumentata automaticamente oltre 108 px (fino a **174 px** per la barra `SPAZIO`), preservando il centraggio sul polpastrello.
  - **Motore di Persistenza Accordi Fisici (`activePhysicalKeys`)**:
    - Ogni tasto premuto fisicamente sulla tastiera hardware illumina istantaneamente il keycap sul polpastrello del dito preposto.
    - Lo stato permane attivo senza limiti di tempo finché il tasto non viene rilasciato fisicamente (`keyup`).
    - Il rilascio di un tasto dell'accordo spegne solo quel componente, mantenendo attivi gli altri tasti ancora trattenuti.

### 5.8 Finestra Statistiche Cartesiane Fullscreen
- Finestra modale ingrandibile a tutto schermo con ridisegno responsive immediato:
- **Pannello Istogramma (Frequenze ed Errori)**:
  - Raggruppamento per singoli caratteri o per 8 colonne anatomiche corrispondenti alle dita.
  - 6 opzioni di ordinamento interattivo tramite selettori radio.
  - Barre cromatiche a doppio indicatore (frequenza d'uso complessiva vs numero di errori commessi).
- **Pannello Grafico Cartesiano (Velocità e Serie Temporali)**:
  - Tracciamento cartesiano continuo dei campioni storici con asse Y commutabile (BTM, battute totali, % errore, errori assoluti).
  - Filtri selettivi per tipologia di sessione didattica.
  - **Crosshair mobile**: linea guida rossa orizzontale reattiva al cursore con badge galleggiante mostrante la quota esatta del valore Y corrispondente.
  - **Selezione cartesiana a 3 click**: 1° click per selezionare un intervallo di campioni con calcolo istantaneo della media; 2° click per isolare il singolo campione; 3° click per azzerare la selezione e ripristinare la media globale.
  - Pulsante `#btnClearSelection`: elimina dall'archivio i soli campioni selezionati.
  - Pulsante `#btnResetAllStats`: reset generale dell'archivio del profilo (con dialogo di conferma).

### 5.9 Modali Ausiliarie di Servizio
- **Modale Seleziona Frase (`modalSelectPhrase`)**:
  - Selettore a discesa della lezione (`selSelectPhraseLesson`) sincronizzato con la toolbar principale.
  - Casella numerica `#txtSelectPhraseIndex` per inserire l'indice della frase desiderata.
  - Informazione testuale sul range valido di frasi disponibili per la lezione selezionata.
- **Modale Editor Esercizi Custom (`modalCustomEditor`)**:
  - Area di testo multilinea `#txtCustomExercises` per redigere o incollare lezioni custom conformi alla sintassi con delimitatori `=====`.
  - Pulsante `#btnSaveCustomExercises`: convalida sintattica, parsing e salvataggio nel profilo utente.
  - Pulsante `#btnResetCustomExercises`: ripristino dell'esercizio custom predefinito di esempio.
- **Modale Gestione Utenti (`modalUserManager`)**:
  - Elenco dei profili registrati con selezione rapida.
  - Creazione nuovo profilo utente con inizializzazione delle relative strutture dati.
  - Eliminazione profilo selezionato.
  - Pulsanti di esportazione/importazione archivi in formato JSON e XML.

---

## 6. Tabella Completa delle Scorciatoie da Tastiera (Hotkeys)

Tutte le funzioni operative dell'applicazione sono mappate su combinazioni di tasti rapide conformi alla versione classica C#, con soppressione preventiva delle interferenze native del browser:

| Scorciatoia Principale | Scorciatoia Alternativa | Azione Eseguita |
| :---: | :---: | :--- |
| **F1** | `ALT+H` | Apre la Guida Utente in linea (`help.html`) |
| **F5** | `ALT+B` | Attiva o disattiva l'Autocorrezione automatica (blocco del Backspace) |
| **F6** | `<` (Toolbar) | Seleziona la **frase precedente** della lezione attiva |
| **F7** | `>` (Toolbar) | Seleziona la **frase successiva** della lezione attiva |
| **F8** | `ALT+E` / `CTRL+SHIFT+E` | Apre la maschera per saltare a una **frase specifica** per indice |
| **F9** | `ALT+A` | **Riavvia la frase corrente**, azzerando i contatori della sessione |
| **F11** | `ALT+I` | Rimescola casualmente i caratteri della frase corrente (**Random This Phrase**) |
| **F12** | `ALT+L` / `ALT+C` | Avvia l'esercizio globale con tutti i tasti e simboli (**Random All Chars**) |
| - | `ALT+M` | Estrae casualmente una delle frasi disponibili per la lezione attiva |
| - | `ALT+P` | Imposta la modalità didattica **PHRASES** (Frasi strutturate) |
| - | `ALT+R` | Imposta la modalità didattica **RANDOM** (Caratteri casuali ponderati) |
| - | `ALT+F` | Imposta la modalità didattica **FONEMI** (Catena sillabica italiana) |
| - | `ALT+T` | Imposta la modalità didattica **TYPING** (Digitazione libera) |
| - | `ALT+W` | Mostra o nasconde la finestra ausiliaria delle **Mani** (Hands Window) |
| - | `ALT+K` | Mostra o nasconde la finestra della **Tastiera virtuale** |
| - | `ALT+O` | Mostra o nasconde la casella del **testo proposto** (`txtOrigin`) |
| - | `ALT+Y` | Mostra o nasconde la casella del **testo digitato** (`txtTyped`) |
| - | `ALT+U` | Passa alla **lezione didattica precedente** nella lista |
| - | `ALT+D` | Passa alla **lezione didattica successiva** nella lista |
| - | `ALT+S` | Apre la finestra modale delle **Statistiche analitiche** |
| - | `ALT+Z` | (Nella finestra statistiche) Azzera tutti i dati statistici dell'utente |
| - | `ALT+Q` | Salva le impostazioni correnti nel profilo utente attivo |

---

## 7. Linee Guida Operative per il Kickoff delle Chat Successive

Per consentire l'avvio efficiente di future sessioni di sviluppo e bug-fixing minimizzando il consumo di token di contesto, il presente documento sintetizza esaustivamente l'intero impianto normativo e funzionale del progetto:

1. **Stato della Codebase**: il codice sorgente attivo e collaudato risiede nel file monolitico `index_(v.2.4).html` (e successivi `v.2.x`).
2. **Contratto delle Modifiche**: ogni nuovo intervento deve generare una nuova versione sequenziale dei file (ad es. `v.2.5`), preservando al 100% i metodi esistenti delle 8 classi e aggiornando specularmente il manuale e la guida `help.html`.
3. **Divieto di Notazione LaTeX**: qualsiasi report, metrica, formula e documento tecnico deve impiegare la sola notazione naturale leggibile (es. `NN.N%`, `WPM = (Caratteri / 5) / Minuti`).
4. **Validazione Continua**: ogni rilascio deve garantire conformità a zero errori ed eccezioni nella console del browser e preservare la coerenza tra i baricentri SVG delle mani e il dimensionamento scalato a 1.5x dei keycaps sui polpastrelli.
