## [6.30]
- Aggiunto pulsante "Mostra storico" nella finestra Interrogazione con grafico SVG interattivo, crosshair rosso/verde, filtro data/ora ed eliminazione campioni selezionati o esclusi.
- Rimossi simboli AltGr errati `{`, `[`, `]`, `}` dai tasti `7`, `8`, `9`, `0` su tastiera principale, tastiera Interrogazione e anteprima tasto.
- Compattata ulteriormente la finestra Interrogazione (spazi ridotti sopra/sotto tastiera e mani, layout compatto per Accordo Modificatore, Conferma e Consulta).
- Posizionata la palette ASCII "Seleziona carattere / tasto" in prossimità dell'elemento cliccato.
- Fix priorità click sui puntini delle mani e delle estensioni laterali (`pointer-events` + raggio hit aumentato) per valorizzare tutti i dropdown di Descrizione Accordo.
- Impostati tutti i dropdown di "1) Descrizione Accordo" su voce vuota iniziale.
- Accettati `0` e `+1` per `INVIO` (estensione longitudinale) e `+` / `ù` a sinistra di `INVIO` (con svelamento di entrambi).
- Rinnovata Interrogazione per Dito: nessun suggerimento iniziale, rimossi filtri Estensione/Direzione, click su tasto -> giallo + palette ASCII -> badge utente sul tasto -> verifica abbinamento tasto-carattere -> verde per corretti, giallo persistente per fuori posto.

## [6.29]
- Rimossi gli stati live dell'esercizio di digitazione (tasto rosso lampeggiante e contatore Errori) dalla finestra Interrogazione.
- Impedita l'anticipazione dei caratteri non ancora risposti sulle anteprime keycap e sulla tastiera B/N.
- Ridotta l'altezza della finestra Interrogazione spostando Domanda/Target/Punteggio (p/max) nella barra del titolo ed eliminando il footer duplicato.
- Sostituiti i tracciati dei polpastrelli con sagome anatomiche complete delle 10 dita e rimosso il doppio layer di pallini sulle mani.
- Collegato il clic su dita e pallini delle mani alla compilazione automatica dei dropdown del Blocco 1 (senza conferma automatica).

## [6.28]
- Spostato il pulsante Interrogazione tra Zoom-in e Zoom-out e Utenti nell'header.
- Rimosso il vincolo max-width: 460px sulla finestra Interrogazione (larghezza 98vw, tastiera B/N e mani affiancate senza scroll laterale).
- Risolta la derivazione di keyId, character e fingerId in InterrogationCatalog per sbloccare sia la modalita Casuale sia la modalita Manuale.
- Attivato automaticamente l'ascolto tastiera fisica in modalita Manuale e pointer-events sulle mani/pallini SVG.

# Changelog — TenFingersTypingTrainer

## v6.27
- Riprogettata l'interfaccia grafica della modalità **Interrogazione**:
  - Vista superiore affiancata con **Tastiera B/N anonima** (priva di simboli, che si popola progressivamente) e **Mani SVG interattive** con pallini cliccabili calibrati (almeno 3px reali) e dita selezionabili.
  - Scelta manuale multi-canale: clic su tastiera B/N, clic su pallini/dita mani SVG, ascolto tastiera fisica o griglia ASCII.
  - Interrogazione **Per Carattere / Per Tasto** strutturata in 3 blocchi sulla stessa pagina: 1) Descrizione Accordo (Mano, Dito, Estensione laterale 0..3 e direzione, Estensione longitudinale -1..+2, Modificatori `CTRL`, `SHIFT`, `ALT`, `AltGr` con equivalenza `AltGr` <-> `CTRL+ALT`), 2) Caratteri sul Tasto con mini-keycap SVG e popover ASCII/`NONE`, 3) Tasti intorno ("margherita") con popover ASCII/`NONE` e rosa completa sulla tastiera.
  - Interrogazione **Per Dito** con filtro progressivo di estensione laterale/direzione e opzione configurabile (`soli_tasti_fisici` | `tutti_i_singoli_caratteri`).
  - Interrogazione **Tasti Posizione di Riposo** (Sinistra / Destra) con selezione grafica dei 4 tasti, carattere e dito.
  - Salvataggio automatico del punteggio finale nelle statistiche del profilo (`profile.interrogationStats`).
- Aggiunti i moduli `js/interrogation/interrogation-layout-metadata.js` e `js/ui/interrogation-svg-renderer.js`, e aggiornati `docs/ARCHITETTURA_v6.27.md`, `docs/MANUALE_UTENTE_v6.27.md`, `help.html`, `README.md` e `BUILD_MANIFEST.json`.

## v6.26
- Migliorata la leggibilità di tutti gli esercizi di **Interrogazione**:
  - Sostituiti gli identificativi tecnici `finger.nn` con il nome italiano del dito e l'indicazione della mano ` - (sn)` o ` - (dx)` (es. `[HOME_ROW] mignolo - (sn)`).
  - Nelle voci `[DITO]` aggiunto anche il nome del tasto tra parentesi graffe (es. `[DITO] mignolo - (dx) - {meno}` nel selettore manuale), mantenendo il titolo della domanda in esecuzione privo di spoiler (`Tasto {meno}`).
  - Nelle voci `[TASTO]` mostrato il nome leggibile del tasto tra parentesi graffe (es. `[TASTO] {meno}`).
  - Nelle voci `[CARATTERE]` mostrati i nomi in chiaro dei caratteri e simboli dalla tabella di riferimento (es. `[CARATTERE] Euro`, `[CARATTERE] BACK`, `[CARATTERE] Spazio`).
- Centralizzata la formattazione leggibile in `InterrogationCatalog` (`js/interrogation/interrogation-catalog.js`).
- Aggiornati `help.html`, `docs/ARCHITETTURA_v6.26.md`, `docs/MANUALE_UTENTE_v6.26.md`, `README.md` e `BUILD_MANIFEST.json`.

## v6.25
- Ripristinata la selezione delle migliori voci di sintesi vocale (TTS) con consenso esplicito per profilo (`AllowRemoteTtsVoices`, predefinito `true`).
- Integrata la nuova funzionalità **Interrogazione sul layout della tastiera italiana** (Casuale, Adattiva 1/3/7/14/30/60 giorni, Manuale).
