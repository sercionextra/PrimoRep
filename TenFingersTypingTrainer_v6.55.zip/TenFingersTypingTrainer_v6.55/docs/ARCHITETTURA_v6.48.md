# Architettura TenFingersTypingTrainer v6.48

Documento di aggiornamento architetturale rispetto alla v6.47.

## 1. Obiettivo della Release v6.48
Conservare nel campo `Esercizio` dei campioni statistici registrati in modalità **Random This Phrase** (`TipoCampione: 5`) anche il nome della modalità o dell'esercizio di origine da cui è stato attinto il testo da rimescolare, nel formato `"Random This Phrase (<Origine>)"`.

## 2. Tracciamento dell'Origine in `TypingEngine` (`js/engines/typing-engine.js`)
- Nel costruttore inizializzate `this.lastOriginTitle = ""` e `this.randomSourceTitle = ""`.
- In `loadExercise()`:
  - Per le modalità guidate (`0, 1, 2, 3, 6`), al termine del caricamento vengono azzerate `this.randomSourceTitle = ""` e aggiornate `this.lastOriginTitle = this.getCurrentExerciseTitle()` (catturando quindi anche `Custom X: ...` prima di un eventuale reset della sorgente al cambio modalità).
  - Per `mode === 4` (*Digitazione Libera*), `this.randomSourceTitle` viene azzerato.
  - Per `mode === 5` (*Random This Phrase*):
    - se la sorgente scelta è `this.originText` e `this.randomSourceTitle` è ancora vuoto, viene fissato a `this.lastOriginTitle` (rimanendo immutato nei rimescolamenti consecutivi per evitare annidamenti);
    - se la sorgente scelta è `this.lastTypedPhrase`, `this.randomSourceTitle` viene impostato a `"Digitazione Libera"`;
    - se la sorgente cade sul fallback di lezione, `this.randomSourceTitle` viene derivato da `this.lessonsSource` e `this.lessons[this.currentLessonIdx]`.
- In `getCurrentExerciseTitle()`, per `mode === 5`, viene restituito `` `Random This Phrase (${this.randomSourceTitle})` `` se `this.randomSourceTitle` è valorizzato.
