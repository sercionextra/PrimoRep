#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const listeners = {};
const elements = {};

function makeElement(id, tagName = 'div') {
  return {
    id,
    tagName: tagName.toUpperCase(),
    style: {},
    classList: {
      _classes: new Set(),
      add(c){ this._classes.add(c); },
      remove(c){ this._classes.delete(c); },
      toggle(c, force){
        if (force === undefined) {
          if (this._classes.has(c)) this._classes.delete(c); else this._classes.add(c);
        } else if (force) this._classes.add(c); else this._classes.delete(c);
      },
      contains(c){ return this._classes.has(c); }
    },
    checked: false,
    value: '',
    innerText: '',
    title: '',
    offsetWidth: 580,
    offsetHeight: 330,
    offsetLeft: 100,
    offsetTop: 200,
    getBoundingClientRect() {
      return {
        left: 100,
        top: 200,
        right: 680,
        bottom: 530,
        width: 580,
        height: 330
      };
    },
    appendChild(child){ this._children = this._children || []; this._children.push(child); },
    setAttribute(){},
    getAttribute(){ return ''; },
    querySelectorAll(){ return []; },
    querySelector(){ return null; },
    addEventListener(evt, fn) {
      listeners[`${id}:${evt}`] = fn;
    },
    click() {
      if (listeners[`${id}:click`]) listeners[`${id}:click`]({ target: this });
    },
    focus() {}
  };
}

const sandbox = {
  console,
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: (sel) => {
      if (sel === 'main') {
        if (!elements['main']) elements['main'] = makeElement('main', 'main');
        return elements['main'];
      }
      return null;
    },
    querySelectorAll: () => [],
    addEventListener: (name, cb) => { (listeners['document:' + name] ||= []).push(cb); },
    createElement: (tag) => makeElement('anon_' + Math.random(), tag),
    body: { appendChild(){}, classList: { add(){}, remove(){}, toggle(){} }, style: {} },
    documentElement: { style: { setProperty(){} }, classList: { add(){}, remove(){}, toggle(){} }, clientWidth: 1920, scrollHeight: 1080 }
  },
  localStorage: {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    key(i) { return Object.keys(this._data)[i] || null; },
    get length() { return Object.keys(this._data).length; }
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  requestAnimationFrame: (cb) => { cb(); return 0; },
  cancelAnimationFrame: () => {},
  performance: { now: () => 0 },
  Blob: function(){},
  URL: { createObjectURL: () => '', revokeObjectURL(){} },
  navigator: {},
  alert(){}, confirm(){ return false; }, prompt(){ return null; },
  getComputedStyle: () => ({ display: 'block', position: 'absolute' }),
  scrollY: 0,
  scrollX: 0,
  Event: class { constructor(type) { this.type = type; } }
};
sandbox.window = sandbox;
sandbox.window.addEventListener = (name, cb) => { (listeners['window:' + name] ||= []).push(cb); };
sandbox.window.dispatchEvent = (evt) => {
  const cbs = listeners['window:' + evt.type] || [];
  for (const cb of cbs) cb(evt);
};
sandbox.window.speechSynthesis = null;
sandbox.window.localStorage = sandbox.localStorage;
sandbox.window.navigator = sandbox.navigator;
sandbox.listeners = listeners;

vm.createContext(sandbox);

const files = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];

for (const f of files) {
  const code = fs.readFileSync(path.join(root, f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
}

// 1. Verifica statica in index.html dei pulsanti, modale e scorciatoie richieste
const indexHtml = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
assert.ok(indexHtml.includes('id="btnZoomIn"'), 'index.html deve contenere il pulsante id="btnZoomIn"');
assert.ok(indexHtml.includes('id="btnZoomOut"'), 'index.html deve contenere il pulsante id="btnZoomOut"');
assert.ok(indexHtml.includes('id="btnZoomInfo"'), 'index.html deve contenere il pulsante id="btnZoomInfo"');
assert.ok(indexHtml.includes('Zoom-in e Zoom-out'), 'btnZoomInfo deve mostrare il testo Zoom-in e Zoom-out');
assert.ok(indexHtml.includes('id="zoomHelpModal"'), 'index.html deve contenere il modale id="zoomHelpModal"');
assert.ok(indexHtml.includes('CTRL+RotellinaMouse'), 'zoomHelpModal deve mostrare la combinazione CTRL+RotellinaMouse');
assert.ok(indexHtml.includes('CTRL+SHIFT++'), 'zoomHelpModal deve mostrare la combinazione CTRL+SHIFT++');
assert.ok(indexHtml.includes('CTRL+SHIFT+-'), 'zoomHelpModal deve mostrare la combinazione CTRL+SHIFT+-');

// 2. Test funzionale di apertura modale, chiusura e notifiche mini-toast
const testScript = `
(() => {
  const ctrl = new AppController(EMBEDDED_LESSONS, EMBEDDED_DEMO_PROFILE, EMBEDDED_CUSTOM_DEFAULT, EMBEDDED_FONEMI_CORPUS);
  ctrl.profileMgr.init();
  ctrl.setupZoomControls();
  ctrl.setupShortcuts();

  ctrl.returnFocusToTyping = () => {};

  const btnZoomIn = document.getElementById("btnZoomIn");
  const btnZoomOut = document.getElementById("btnZoomOut");
  const btnZoomInfo = document.getElementById("btnZoomInfo");
  const modal = document.getElementById("zoomHelpModal");
  const btnClose = document.getElementById("btnCloseZoomHelpModal");
  const btnOk = document.getElementById("btnOkZoomHelpModal");

  // TEST 1: Apertura modale scorciatoie tramite btnZoomInfo
  btnZoomInfo.click();
  if (!modal.classList.contains("active")) {
    throw new Error("Click su btnZoomInfo deve aprire zoomHelpModal aggiungendo la classe active");
  }

  // TEST 2: Chiusura modale tramite pulsante Chiudi (X)
  btnClose.click();
  if (modal.classList.contains("active")) {
    throw new Error("Click su btnCloseZoomHelpModal deve chiudere zoomHelpModal rimuovendo la classe active");
  }

  // TEST 3: Riapertura e chiusura tramite pulsante OK
  btnZoomInfo.click();
  if (!modal.classList.contains("active")) {
    throw new Error("Riapertura modale fallita");
  }
  btnOk.click();
  if (modal.classList.contains("active")) {
    throw new Error("Click su btnOkZoomHelpModal deve chiudere zoomHelpModal");
  }

  // TEST 4: Click su Zoom-in e Zoom-out scatena showNotificationToast informativa
  let toastMsg = "";
  ctrl.showNotificationToast = (msg) => { toastMsg = msg; };

  btnZoomIn.click();
  if (!toastMsg.includes("CTRL+SHIFT++")) {
    throw new Error("Click su btnZoomIn deve invocare showNotificationToast con CTRL+SHIFT++, trovato: " + toastMsg);
  }

  btnZoomOut.click();
  if (!toastMsg.includes("CTRL+SHIFT+-")) {
    throw new Error("Click su btnZoomOut deve invocare showNotificationToast con CTRL+SHIFT+-, trovato: " + toastMsg);
  }

  // TEST 5: Nessuna modifica forzata a document.body.style.zoom (delega nativa al browser)
  if (document.body.style.zoom) {
    throw new Error("document.body.style.zoom non deve essere manipolato via software, trovato: " + document.body.style.zoom);
  }

  // TEST 6: resetAllWindowLayouts mantiene document.body.style.zoom pulito
  ctrl.showAppAlert = () => {};
  ctrl.resetInstantSpeedDefaultPosition = () => {};
  ctrl.resetHandsDefaultPosition = () => {};
  ctrl.resetAllWindowLayouts();
  if (document.body.style.zoom) {
    throw new Error("resetAllWindowLayouts deve assicurare document.body.style.zoom vuoto");
  }

  // TEST 7 & 8: Bypass scorciatoie native di Zoom ad esercizio completato e durante digitazione (Release v6.18)
  ctrl.setupTypingListeners();
  ctrl.typingEng.mode = 0;

  const zoomShortcutCases = [
    { name: "CTRL+SHIFT++ (layout IT)", key: "+", code: "BracketRight", ctrlKey: true, shiftKey: true, altKey: false },
    { name: "CTRL+SHIFT++ (layout US)", key: "+", code: "Equal", ctrlKey: true, shiftKey: true, altKey: false },
    { name: "CTRL+NumpadAdd", key: "+", code: "NumpadAdd", ctrlKey: true, shiftKey: false, altKey: false },
    { name: "CTRL+SHIFT+- (layout IT)", key: "-", code: "Slash", ctrlKey: true, shiftKey: true, altKey: false },
    { name: "CTRL+SHIFT+- (layout US)", key: "-", code: "Minus", ctrlKey: true, shiftKey: true, altKey: false },
    { name: "CTRL+NumpadSubtract", key: "-", code: "NumpadSubtract", ctrlKey: true, shiftKey: false, altKey: false },
    { name: "CTRL+0 (Reset 100%)", key: "0", code: "Digit0", ctrlKey: true, shiftKey: false, altKey: false },
    { name: "CTRL+Numpad0 (Reset 100%)", key: "0", code: "Numpad0", ctrlKey: true, shiftKey: false, altKey: false }
  ];

  for (const sessionState of [false, true]) {
    ctrl.typingEng.isCompleted = sessionState;
    for (const sc of zoomShortcutCases) {
      let isPrevented = false;
      const fakeEvt = {
        ...sc,
        repeat: false,
        target: document.getElementById("txtTypedInput"),
        getModifierState: () => false,
        preventDefault: () => { isPrevented = true; }
      };

      const wListeners = listeners['window:keydown'] || [];
      for (const listener of wListeners) {
        listener(fakeEvt);
      }

      if (isPrevented) {
        throw new Error("Scorciatoia " + sc.name + " bloccata con preventDefault quando isCompleted=" + sessionState);
      }
    }
  }

  return "TUTTI I TEST SUPERATI CON SUCCESSO!";
})()
`;

const res = vm.runInContext(testScript, sandbox);
console.log("TEST RESULT:", res);
