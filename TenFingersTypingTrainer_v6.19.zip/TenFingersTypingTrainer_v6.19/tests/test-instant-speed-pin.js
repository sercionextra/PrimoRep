#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const listeners = {};
const elements = {};

function makeElement(id, tagName = 'div') {
  return {
    id,
    tagName: tagName.toUpperCase(),
    style: {},
    classList: {
      _classes: new Set(),
      add(c){ this._classes.add(c); },
      remove(c){ this._classes.delete(c); },
      toggle(c, force){
        if (force === undefined) {
          if (this._classes.has(c)) this._classes.delete(c); else this._classes.add(c);
        } else if (force) this._classes.add(c); else this._classes.delete(c);
      },
      contains(c){ return this._classes.has(c); }
    },
    checked: false,
    value: '',
    innerText: '',
    title: '',
    offsetWidth: 580,
    offsetHeight: 330,
    offsetLeft: 100,
    offsetTop: 200,
    getBoundingClientRect() {
      return {
        left: 100,
        top: 200,
        right: 680,
        bottom: 530,
        width: 580,
        height: 330
      };
    },
    appendChild(){},
    setAttribute(){},
    getAttribute(){ return ''; },
    querySelectorAll(){ return []; },
    querySelector(){ return null; },
    addEventListener(evt, fn) {
      listeners[`${id}:${evt}`] = fn;
    },
    click() {
      if (listeners[`${id}:click`]) listeners[`${id}:click`]({ target: this });
    },
    focus() {}
  };
}

const sandbox = {
  console,
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: (sel) => {
      if (sel === 'main') {
        if (!elements['main']) elements['main'] = makeElement('main', 'main');
        return elements['main'];
      }
      return null;
    },
    querySelectorAll: () => [],
    addEventListener: (name, cb) => { (listeners['document:' + name] ||= []).push(cb); },
    createElement: (tag) => makeElement('anon_' + Math.random(), tag),
    body: { appendChild(){}, classList: { add(){}, remove(){}, toggle(){} }, style: {} },
    documentElement: { style: { setProperty(){} }, classList: { add(){}, remove(){}, toggle(){} }, clientWidth: 1920, scrollHeight: 1080 }
  },
  localStorage: {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    key(i) { return Object.keys(this._data)[i] || null; },
    get length() { return Object.keys(this._data).length; }
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  requestAnimationFrame: (cb) => { cb(); return 0; },
  cancelAnimationFrame: () => {},
  performance: { now: () => 0 },
  Blob: function(){},
  URL: { createObjectURL: () => '', revokeObjectURL(){} },
  navigator: {},
  alert(){}, confirm(){ return false; }, prompt(){ return null; },
  getComputedStyle: () => ({ display: 'block', position: 'absolute' }),
  scrollY: 0,
  scrollX: 0
};
sandbox.window = sandbox;
sandbox.window.addEventListener = (name, cb) => { (listeners['window:' + name] ||= []).push(cb); };
sandbox.window.speechSynthesis = null;
sandbox.window.localStorage = sandbox.localStorage;
sandbox.window.navigator = sandbox.navigator;

vm.createContext(sandbox);

const files = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];

for (const f of files) {
  const code = fs.readFileSync(path.join(root, f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
}

const testScript = `
(() => {
  const ctrl = new AppController(EMBEDDED_LESSONS, EMBEDDED_DEMO_PROFILE, EMBEDDED_CUSTOM_DEFAULT, EMBEDDED_FONEMI_CORPUS);
  ctrl.profileMgr.init();
  ctrl.setupFloatingWindows();

  const p = ctrl.profileMgr.profile;
  const btnPin = document.getElementById("btnInstantSpeedPin");
  const win = document.getElementById("instantSpeedFloatingWindow");

  // TEST 1: Toggle del pulsante Pin/Pinned
  p.InstantSpeedPinned = true;
  ctrl.updateInstantSpeedPinButtonUI();
  if (btnPin.innerText !== "📍 Pinned" || !btnPin.classList.contains("pinned")) {
    throw new Error("TEST 1 Fallito: stato UI pinned non impostato correttamente");
  }

  btnPin.click();
  if (p.InstantSpeedPinned !== false) {
    throw new Error("TEST 1 Fallito: click su btnInstantSpeedPin non ha sbloccato il pin nel profilo");
  }
  if (btnPin.innerText !== "📌 Pin" || btnPin.classList.contains("pinned")) {
    throw new Error("TEST 1 Fallito: stato UI unpinned non coerente dopo click");
  }

  // TEST 2: Reset Default Position
  ctrl.resetInstantSpeedDefaultPosition();
  if (p.InstantSpeedPinned !== true) {
    throw new Error("TEST 2 Fallito: resetInstantSpeedDefaultPosition non ha ripristinato InstantSpeedPinned a true");
  }
  if (p.InstantSpeedWidth < 920 || p.InstantSpeedHeight < 300) {
    throw new Error("TEST 2 Fallito: dimensioni di default non coerenti (" + p.InstantSpeedWidth + "x" + p.InstantSpeedHeight + ")");
  }
  if (btnPin.innerText !== "📍 Pinned") {
    throw new Error("TEST 2 Fallito: UI del pulsante Pin non sincronizzata a Pinned dopo Default");
  }

  // TEST 3: updateInstantSpeedWindowPosition ancoraggio
  p.InstantSpeedPinned = true;
  p.InstantSpeedLeft = 20;
  p.InstantSpeedOffsetTop = 15;
  ctrl.updateInstantSpeedWindowPosition();
  const leftPx = parseInt(win.style.left, 10);
  const topPx = parseInt(win.style.top, 10);
  if (isNaN(leftPx) || isNaN(topPx)) {
    throw new Error("TEST 3 Fallito: coordinate numeriche left/top non calcolate");
  }

  return "TUTTI I TEST SUPERATI CON SUCCESSO!";
})()
`;

const res = vm.runInContext(testScript, sandbox);
console.log("TEST RESULT:", res);
