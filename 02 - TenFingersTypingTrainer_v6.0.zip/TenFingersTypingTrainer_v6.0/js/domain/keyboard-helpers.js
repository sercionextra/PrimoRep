/* TenFingersTypingTrainer v6.0 — Risoluzione landmark e accordi; contenuto estratto senza cambiare le regole del dominio. */
// Funzione di risoluzione coordinate con fallback difensivo
function getAnatomicalLandmark(finger, labelOrChar, keyId = null) {
  if (!labelOrChar && !keyId) return null;

  // 1. Risoluzione diretta tramite ID tasto fisico (se presente)
  if (keyId && KEY_ID_TO_LANDMARK_KEY[keyId]) {
    const lk = KEY_ID_TO_LANDMARK_KEY[keyId];
    const match =
      KEY_LANDMARK_MAP.get(`${finger}_${lk.toUpperCase()}`) ||
      KEY_LANDMARK_MAP.get(`${finger}_${lk}`);
    if (match) return match;
  }

  // 2. Normalizzazione etichette speciali e tasti estesi
  let norm = String(labelOrChar).trim();
  if (norm === "␣" || norm === " " || norm === "SPAZIO") norm = "SPAZIO";
  else if (
    norm === "↵" ||
    norm === "®" ||
    norm === "\n" ||
    norm === "INVIO" ||
    norm === "Invio"
  )
    norm = "INVIO";
  else if (
    norm === "⇥" ||
    norm === "→" ||
    norm === "\t" ||
    norm === "TAB" ||
    norm === "Tab"
  )
    norm = "TAB";
  else if (norm === "⌫" || norm === "BACK" || norm === "Backspace")
    norm = "BACK";
  else if (norm === "SHIFT" || norm === "Shift")
    norm = finger <= 5 ? "SHIFT-sn" : "SHIFT-dx";
  else if (norm === "CTRL" || norm === "Ctrl")
    norm = finger <= 5 ? "CTRL-sn" : "CTRL-dx";
  else if (norm === "ALT" || norm === "Alt") norm = "ALT";
  else if (norm === "ALT GR" || norm === "AltGr" || norm === "ALTGR")
    norm = "AltGr";
  else if (norm === "CAPS" || norm === "Caps") norm = "CAPS";

  let direct =
    KEY_LANDMARK_MAP.get(`${finger}_${norm.toUpperCase()}`) ||
    KEY_LANDMARK_MAP.get(`${finger}_${norm}`);
  if (direct) return direct;

  // 3. Risoluzione tramite dizionario tastiera KEY_MAP (accordi e caratteri shiftati)
  const keyInfo =
    KEY_MAP[labelOrChar] || KEY_MAP[String(labelOrChar).toLowerCase()];
  if (keyInfo && keyInfo.id && KEY_ID_TO_LANDMARK_KEY[keyInfo.id]) {
    const lk = KEY_ID_TO_LANDMARK_KEY[keyInfo.id];
    const match =
      KEY_LANDMARK_MAP.get(`${finger}_${lk.toUpperCase()}`) ||
      KEY_LANDMARK_MAP.get(`${finger}_${lk}`);
    if (match) return match;
  }

  // 4. Tentativo diretto per carattere maiuscolo/minuscolo
  return (
    KEY_LANDMARK_MAP.get(`${finger}_${String(labelOrChar).toUpperCase()}`) ||
    KEY_LANDMARK_MAP.get(`${finger}_${String(labelOrChar)}`) ||
    null
  );
}

// RISOLUTORE ACCORDI TASTI (CHORD ENGINE v.1.4)
function resolveTargetChord(char) {
  if (!char) return null;
  const info = KEY_MAP[char];
  if (!info) return null;

  const keyIds = [info.id];
  const fingers = [];
  const allowedMods = new Set();
  const isLeftHandBase = info.finger >= 1 && info.finger <= 5;

  if (info.mod === "shiftR") {
    keyIds.push("key_shift_r");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 10, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "shiftL") {
    keyIds.push("key_shift_l");
    fingers.push({ finger: info.finger, label: char });
    fingers.push({ finger: 1, label: "Shift" });
    allowedMods.add("Shift");
    if (/^[A-Z]$/.test(char)) {
      allowedMods.add("CapsLock");
    }
  } else if (info.mod === "altgr") {
    if (!isLeftHandBase) {
      keyIds.push("key_ctrl_l", "key_alt_l");
      fingers.push({ finger: 1, label: "Ctrl" });
      fingers.push({ finger: 5, label: "Alt" });
      fingers.push({ finger: info.finger, label: char });
      allowedMods.add("Control");
      allowedMods.add("Alt");
      allowedMods.add("AltGraph");
    } else {
      keyIds.push("key_altgr");
      fingers.push({ finger: info.finger, label: char });
      fingers.push({ finger: 6, label: "AltGr" });
      allowedMods.add("AltGraph");
      allowedMods.add("Control");
      allowedMods.add("Alt");
    }
  } else if (info.mod === "shiftAltgr") {
    keyIds.push("key_ctrl_l", "key_shift_l", "key_alt_l");
    fingers.push({ finger: 1, label: "Ctrl" });
    fingers.push({ finger: 2, label: "Shift" });
    fingers.push({ finger: 5, label: "Alt" });
    fingers.push({ finger: info.finger, label: char });
    allowedMods.add("Control");
    allowedMods.add("Shift");
    allowedMods.add("Alt");
    allowedMods.add("AltGraph");
  } else {
    let lbl = char;
    if (char === " " || info.name === "Spazio") lbl = "␣";
    else if (char === "®" || char === "\n" || info.name === "Invio") lbl = "↵";
    else if (char === "→" || char === "\t" || info.name === "Tabulazione")
      lbl = "⇥";
    else if (info.name && info.name.length <= 4) lbl = info.name;
    fingers.push({ finger: info.finger, label: lbl });
  }

  return { info, keyIds, fingers, allowedMods };
}

