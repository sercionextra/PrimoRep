# Specifica PRNG deterministico INTERROGAZIONE — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Documento:** `Specifica_PRNG_Interrogazione_v1.0.md`  
**Data:** 9 novembre 2026  
**Stato:** decisione tecnica proposta e verificata tramite vettori indipendenti; da recepire nei contratti prima dell'implementazione  
**Ambito:** generazione casuale riproducibile per il motore di selezione INTERROGAZIONE  
**Dipendenze:** `Motore_Selezione_Interrogazione_v1.0.md`; `Schema_IndexedDB_Interrogazione_v1.2.md`; `Contratti_Backend_Interrogazione_v1.2.md`

---

## 1. Decisione

Si adotta **xoshiro128\*\*** nella variante a 32 bit, identificata in modo immutabile come:

- `prngAlgorithmId`: `xoshiro128**`
- `prngAlgorithmVersion`: `1.0`
- `seedEncoding`: `hex-128be`
- `canonicalOrderingVersion`: `utf16-code-unit-v1`

La scelta è motivata da:

1. implementazione compatta e verificabile in JavaScript classico;
2. stato interno di quattro parole unsigned a 32 bit;
3. operazioni bitwise definite e disponibili nei browser supportati;
4. moltiplicazioni a 32 bit riproducibili tramite `Math.imul`;
5. algoritmo pubblicamente documentato e dotato di vettori di riferimento;
6. assenza di dipendenze esterne;
7. separazione netta tra seed iniziale e sequenza pseudo-casuale successiva.

Il generatore è adatto alla selezione didattica riproducibile. **Non è un generatore crittografico** e non deve essere usato per segreti, token, autenticazione o protezione di dati.

La generazione crittograficamente sicura del seed iniziale, quando disponibile, è responsabilità separata del chiamante.

## 2. Modello di determinismo

La stessa combinazione di:

- algoritmo e versione;
- seed normalizzato;
- input del selettore;
- versioni delle regole di selezione e delle quote;
- pool di candidate;
- ordinamento canonico;
- snapshot di conoscenza e priorità, quando la modalità è adattiva;

deve produrre lo stesso ordine di candidate selezionati.

Il PRNG produce soltanto una sequenza di interi unsigned a 32 bit. Non determina quote, classificazioni, priorità, punteggi o regole didattiche.

Non si deve invocare `Math.random()` durante le estrazioni. L'unica eccezione è il fallback esplicitamente diagnosticato per generare il seed iniziale quando `crypto.getRandomValues` non è disponibile.

## 3. Rappresentazione del seed

### 3.1 Formato canonico

Il seed è composto da 16 byte, cioè 128 bit, serializzati come 32 caratteri esadecimali minuscoli:

- encoding: `hex-128be`;
- lunghezza: esattamente 32 caratteri;
- caratteri ammessi in input: `0-9`, `a-f`, `A-F`;
- rappresentazione persistita: minuscola;
- ordine dei byte: big-endian per ciascuna parola da 32 bit;
- prefissi `0x`, spazi, separatori e whitespace non sono ammessi.

Esempio:

`000102030405060708090a0b0c0d0e0f`

Viene convertito nelle quattro parole iniziali:

- S0 = 66051
- S1 = 67438087
- S2 = 134810123
- S3 = 202182159

Ogni parola è un intero unsigned a 32 bit. Lo stato composto da quattro parole tutte uguali a zero è vietato e produce `PRNG_ZERO_STATE`.

Il parser accetta lettere esadecimali maiuscole, ma normalizza immediatamente il valore in minuscolo. Non effettua trim o correzioni automatiche di input malformati.

### 3.2 Generazione in produzione

Il seed viene generato una sola volta, prima della selezione della sessione.

Procedura preferita:

1. verificare l'esistenza di `crypto.getRandomValues`;
2. creare un `Uint8Array` di 16 byte;
3. riempirlo con `crypto.getRandomValues`;
4. convertire i byte in 32 caratteri esadecimali minuscoli;
5. verificare che il seed non sia all-zero;
6. in caso di stato all-zero, ripetere la generazione fino a un massimo di 8 tentativi;
7. se la sorgente fallisce o restituisce soltanto stati vietati, passare al fallback e registrare la diagnostica.

`crypto.getRandomValues` è usato soltanto per inizializzare il seed. Non deve essere richiamato per ogni estrazione del selettore.

### 3.3 Fallback non crittografico

Se `crypto.getRandomValues` non è disponibile o genera un'eccezione, il chiamante può generare i 16 byte con `Math.random()`.

Il fallback deve:

- essere esplicitamente marcato `seedSource: "Math.random-fallback"`;
- essere marcato `seedSecurity: "non-cryptographic"`;
- aggiungere il warning `PRNG_SEED_FALLBACK_NON_CRYPTOGRAPHIC`;
- non essere mai descritto come equivalente a `crypto.getRandomValues`;
- conservare il seed effettivamente generato nello snapshot, così la sequenza successiva resta riproducibile.

Quando è disponibile la sorgente preferita, lo snapshot registra:

- `seedSource: "crypto.getRandomValues"`;
- `seedSecurity: "cryptographic"`.

Il termine `cryptographic` descrive esclusivamente la sorgente del seed. Non trasforma xoshiro128\*\* in un PRNG crittografico.

Se anche il fallback produce uno stato all-zero, il generatore deve ritentare fino a 8 volte. Come ultima misura di recupero, può impostare l'ultimo byte a `01`, ma deve registrare `PRNG_SEED_DEGENERATE_FALLBACK`; tale sessione è riproducibile, ma la qualità casuale del seed è da considerare degradata.

## 4. Inizializzazione e stato

Il parser converte il seed in quattro parole unsigned:

- S0 = byte 0..3 interpretati big-endian;
- S1 = byte 4..7 interpretati big-endian;
- S2 = byte 8..11 interpretati big-endian;
- S3 = byte 12..15 interpretati big-endian.

Non viene applicata una funzione di espansione del seed. I 128 bit del seed costituiscono direttamente lo stato iniziale.

Lo stato all-zero è rifiutato perché xoshiro128\*\* non deve essere avviato da quello stato.

Lo stato operativo è:

`[S0, S1, S2, S3]`

Il generatore mantiene inoltre due contatori diagnostici:

- `drawCount`: numero totale di output uint32 prodotti;
- `rejectionCount`: numero totale di output scartati dal bounded integer.

I contatori non partecipano alla sequenza e non modificano lo stato.

## 5. Generazione di un uint32

A ogni chiamata a `nextUint32()` si applicano esattamente queste operazioni, nell'ordine indicato.

1. Calcolare `result = rotl32(imul32(S1, 5), 7) * 9`, mantenendo il risultato a 32 bit.
2. Calcolare `t = S1 << 9`, mantenendo il risultato a 32 bit.
3. Aggiornare `S2 = S2 XOR S0`.
4. Aggiornare `S3 = S3 XOR S1`.
5. Aggiornare `S1 = S1 XOR S2`.
6. Aggiornare `S0 = S0 XOR S3`.
7. Aggiornare `S2 = S2 XOR t`.
8. Aggiornare `S3 = rotl32(S3, 11)`.
9. Incrementare `drawCount`.
10. Restituire `result` come intero unsigned compreso tra 0 e 4294967295.

Definizioni:

- `imul32(a, b)` è la moltiplicazione a 32 bit ottenuta con `Math.imul(a, b) >>> 0`;
- `rotl32(x, k)` è la rotazione a sinistra di una parola da 32 bit;
- `XOR` è l'operatore bitwise JavaScript `^`;
- dopo ogni operazione che può produrre un valore signed, applicare `>>> 0` quando il valore viene conservato nello stato o restituito.

Non sostituire `Math.imul` con la normale moltiplicazione JavaScript: la normale moltiplicazione usa numeri floating point e non esprime lo stesso contratto di overflow a 32 bit.

## 6. Estrazione di interi bounded senza bias da modulo

Il selettore usa `nextInt(bound)` per ottenere un intero nell'intervallo da 0 incluso a `bound` escluso.

Vincoli:

- `bound` deve essere un intero;
- `1 <= bound <= 4294967296`;
- input non valido: `PRNG_INVALID_BOUND`.

Per evitare il bias introdotto da un semplice modulo, si applica il rejection sampling.

Per `bound` minore di 4294967296:

1. calcolare `threshold = (4294967296 - bound) % bound`;
2. generare `r = nextUint32()`;
3. se `r < threshold`, scartare `r`, incrementare `rejectionCount` e ripetere;
4. altrimenti restituire `r % bound`.

Per `bound` uguale a 4294967296, restituire direttamente `nextUint32()`.

Per `bound` uguale a 1, il risultato è sempre 0 e viene consumato un output del generatore. Questa regola mantiene un comportamento uniforme e documentabile anche nei test.

Il calcolo di `4294967296` è esatto in JavaScript Number. Il valore massimo del bound non deve essere convertito in signed int32.

## 7. Ordinamento canonico del pool

Prima di qualunque mescolamento, il pool deve essere trasformato in un elenco di `candidateId` univoci e ordinati canonicamente.

Regole:

1. `candidateId` deve essere una stringa non vuota;
2. gli identificativi composti soltanto da whitespace sono invalidi;
3. non applicare `trim`, conversione maiuscolo/minuscolo, normalizzazione Unicode o `localeCompare`;
4. la comparazione è case-sensitive;
5. l'ordine è lessicografico sui code unit UTF-16, come definito dal confronto stringhe ECMAScript;
6. usare un comparatore equivalente a `a < b ? -1 : a > b ? 1 : 0`;
7. duplicati di `candidateId` sono un errore di validazione e non vanno eliminati silenziosamente;
8. l'ordine canonico deve essere registrato nello snapshot.

La versione della regola è `utf16-code-unit-v1`.

Non usare `localeCompare`: il risultato può dipendere dalla lingua e dalle impostazioni locali dell'ambiente.

Il fingerprint del pool è un dato di controllo separato dal PRNG. La codifica canonica è `JSON.stringify(canonicalCandidateOrder)` senza spazi aggiuntivi, codificata in UTF-8 con `TextEncoder`; il digest è SHA-256 tramite `crypto.subtle.digest`. La stringa persistita è `sha256:` seguita da 64 caratteri esadecimali minuscoli.

Se `TextEncoder`, `crypto.subtle` o il digest SHA-256 non sono disponibili, la creazione della sessione deve fallire prima di qualsiasi scrittura con `SELECTION_FINGERPRINT_UNAVAILABLE`. Non sostituire il digest con un hash debole o dipendente dalla piattaforma.

Il fingerprint non sostituisce l'elenco degli identificativi, non è una fonte di identità e non deve essere trattato come prova di autenticità del catalogo. Serve a rilevare differenze accidentali del pool e a rendere confrontabili gli snapshot.

## 8. Fisher–Yates

Il mescolamento usa Fisher–Yates discendente, applicato a una copia dell'array canonico.

Per un array di lunghezza N:

1. impostare `i = N - 1`;
2. finché `i > 0`, estrarre `j = nextInt(i + 1)`;
3. scambiare gli elementi agli indici `i` e `j`;
4. decrementare `i` di uno.

Il ciclo visita gli indici in ordine N-1, N-2, ..., 1. Non cambiare direzione, ordine delle chiamate al PRNG o convenzione degli indici in una release che dichiara la stessa versione.

Casi limite:

- array vuoto: restituisce un array vuoto, zero draw;
- array con un elemento: restituisce lo stesso elemento, zero draw;
- array con duplicati: errore prima del mescolamento.

Per una sessione casuale, il selettore prende i primi `effectiveCount` elementi dell'array mescolato.

## 9. Confine tra modalità casuale e adattiva

### 9.1 Modalità casuale

La modalità `random`:

- non legge `knowledgeSnapshot`;
- non legge `pendingConsultationPriorities`;
- non applica quote categoria o quote di strato;
- non ordina per debolezza, affidabilità o scadenza;
- ordina canonicamente il pool valido;
- applica Fisher–Yates con il PRNG congelato;
- prende i primi `effectiveCount` candidate.

La modalità casuale deve produrre lo stesso risultato anche se i dati di conoscenza del profilo cambiano, a parità di pool, seed e versioni.

### 9.2 Modalità adattiva

La modalità `adaptive`:

- calcola quote, deficit, priorità e conteggi usando i motori e gli snapshot previsti;
- non delega al PRNG alcuna decisione didattica;
- usa il PRNG soltanto per randomizzare gli spareggi o gli elementi all'interno di gruppi che hanno già un ordine di priorità e una quota determinati;
- non modifica quote, priorità, classificazioni, punteggi o conteggi;
- usa un ordine canonico prima di ogni tie-break seeded.

Per evitare dipendenze accidentali dall'ordine di iterazione degli object store, categorie e strati devono essere attraversati secondo gli ordini canonici già definiti dal motore di selezione. I candidate all'interno di ciascun gruppo devono essere ordinati per `candidateId` prima del tie-break seeded.

La stessa versione del PRNG deve essere usata in entrambe le modalità. Le modalità differiscono per la preparazione del pool e per le regole del selettore, non per il generatore.

## 10. Snapshot di riproducibilità

La sessione deve conservare almeno:

- `prngAlgorithmId: "xoshiro128**"`;
- `prngAlgorithmVersion: "1.0"`;
- `seed`: 32 caratteri esadecimali minuscoli;
- `seedEncoding: "hex-128be"`;
- `seedSource`;
- `seedSecurity`;
- `canonicalOrderingVersion: "utf16-code-unit-v1"`;
- `candidatePoolFingerprint`;
- `canonicalCandidateOrder`: elenco completo e ordinato degli ID del pool effettivamente considerato;
- `prngStateAfterSelection`: quattro parole unsigned a 32 bit;
- `prngDrawCount`;
- `prngRejectionCount`;
- `selectionAlgorithmVersion`;
- `adaptiveQuotaAlgorithmVersion`;
- snapshot di conoscenza e relativo fingerprint, se applicabili;
- quote, conteggi, priorità, warning e candidate selezionati secondo il contratto del selettore.

Il seed e le versioni consentono di ricostruire la sequenza dall'inizio. Lo stato finale e i contatori consentono di verificare che il numero di estrazioni e di rejection sia coerente con l'esecuzione registrata.

Lo snapshot dei candidate selezionati e dei rispettivi contenuti rimane quello persistito in `sessionItems`. Una sessione sospesa o ripresa non deve richiamare il PRNG, rigenerare l'ordine o ricalcolare le quote.

La lista canonica del pool deve essere salvata perché il fingerprint da solo non permette di ricostruire i candidate disponibili se il catalogo o il codice cambiano.

## 11. Compatibilità futura

Una versione pubblicata non può cambiare algoritmo, seed encoding, parsing, ordine canonico, bounded integer o Fisher–Yates mantenendo lo stesso `prngAlgorithmVersion`.

Ogni modifica incompatibile richiede una nuova versione esplicita, ad esempio `1.1`, e nuovi test vectors.

Il software futuro deve mantenere il codice di replay delle versioni PRNG ancora referenziate da sessioni persistite. Non è consentito ricalcolare una sessione storica con il generatore più recente.

La ripresa operativa di una sessione usa sempre gli item persistiti. Il replay PRNG è una funzione di audit e verifica, non una fase del normale resume.

## 12. Errori e diagnostica

Codici minimi:

| Codice | Significato |
|---|---|
| `PRNG_INVALID_SEED` | Seed non esadecimale o lunghezza diversa da 32 caratteri |
| `PRNG_ZERO_STATE` | Stato iniziale composto da quattro parole zero |
| `PRNG_INVALID_BOUND` | Bound non intero o fuori intervallo |
| `PRNG_DUPLICATE_CANDIDATE_ID` | Identificativo candidato duplicato |
| `PRNG_INVALID_CANDIDATE_ID` | Identificativo candidato vuoto o composto soltanto da whitespace |
| `PRNG_SEED_FALLBACK_NON_CRYPTOGRAPHIC` | Seed inizializzato tramite Math.random |
| `PRNG_SEED_DEGENERATE_FALLBACK` | Fallback degenerato corretto con stato minimo non nullo |

Gli errori di input devono interrompere la selezione prima della creazione della sessione. I warning sul seed fallback non devono bloccare automaticamente la sessione, ma devono essere conservati nello snapshot e resi disponibili alla diagnostica.

## 13. Verifica indipendente e test vectors

I vettori sono contenuti in `Specifica_PRNG_Interrogazione_test_vectors_v1.0.json`.

La verifica è stata effettuata con due implementazioni indipendenti:

- riferimento Python, con mascheramento esplicito a 32 bit;
- riferimento JavaScript su Node.js, con `Math.imul`, operatori bitwise e conversioni unsigned.

Il file contiene 16 vettori, che coprono:

- fingerprint SHA-256 del pool canonico;
- parsing big-endian e normalizzazione del seed;
- seed malformati e stato all-zero;
- sequenze di output;
- stato interno dopo un numero noto di estrazioni;
- rejection sampling con un valore effettivamente scartato;
- bound minimo e massimo;
- Fisher–Yates e ordine canonico;
- pool vuoto e singleton;
- riproducibilità a parità di seed e input.

I vettori sono risultati coerenti tra le due implementazioni indipendenti. L'esecuzione nella codebase applicativa resta da implementare e testare: questa verifica non equivale a un test del software integrato.

## 14. Impatto documentale e implementativo

Questa specifica chiude la decisione algoritmica PRNG, ma richiede l'allineamento dei documenti contrattuali con nuove versioni:

- Motore Selezione v1.1: algoritmo, seed, bounded integer, ordinamento, shuffle e snapshot;
- Contratti Backend v1.3: campi canonici e diagnostica seed;
- Schema IndexedDB v1.3: campi addizionali in `sessions.selectionSnapshot`.

I campi aggiuntivi sono proprietà del record `sessions.selectionSnapshot`. Non richiedono nuovi object store o indici. La versione fisica IndexedDB va incrementata soltanto se l'implementazione già distribuita richiede una migrazione reale; la baseline v6.23 non contiene ancora il database Interrogazione.

La decisione PRNG non chiude gli altri gate di progetto: catalogo completo, calendario, policy consultazione, fattore consolidamento, mapping dei modificatori destri, import/export, recovery e test browser restano da completare.

**Modifiche ai sorgenti applicativi:** nessuna.
