# Documento di Handoff Tecnico per le Chat Future (Release v.2.6)

---

## 1. Identità e Obiettivo Primario del Progetto

- **Nome Progetto**: Ten Fingers Typing Trainer (Web Edition SPA)
- **Origine Software**: Porting moderno in TypeScript / Vanilla JavaScript da applicativo desktop WinForms C# (.NET 1.1) denominato `Tastiera10Dita.exe`.
- **Mission Didattica**: Insegnamento rigoroso della **dattilografia alla cieca a dieci dita (touch-typing)** su layout italiano standard **QWERTY IT a 105 tasti**, con la regola aurea di non guardare mai la tastiera fisica durante la scrittura.
- **Architettura di Distribuzione**: Single Page Application (SPA) pura a zero dipendenze esterne a runtime. L'intera logica, grafica SVG e stili risiedono in file HTML autoportanti, eseguibili direttamente con doppio clic in qualsiasi browser moderno aderente agli standard W3C.

---

## 2. Stato Attuale del Repository (`/workspace`)

La struttura delle directory e degli asset attivi si presenta in perfetto ordine e sincronizzata:

```text
/workspace/
├── NEW_DOCS/                                                                                <-- CARTELLA FOCALE PER I KICKOFF FUTURI
│   ├── 01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.6).md  [38 KB - Specifica Tecnica Completa]
│   ├── 02 - Manuale Utente Dettagliato ed Ergonomia di Utilizzo (v.2.6).md                    [34 KB - Manuale Utente e Metodo]
│   ├── 03 - Documento Conclusivo di Riepilogo Tecnico e Decisioni... (v.2.6).md               [11 KB - Consuntivo Decisioni]
│   ├── 04 - Documento di Handoff Tecnico per le Chat Future (v.2.6).md                        [Questo documento]
│   └── help_(v.2.6).html                                                                      [38 KB - Guida HTML5 Interattiva]
│
└── TenFingersTypingTrainer - (Porting TypeScript)/
    ├── DOCS/
    │   ├── ALL DOCS/                                                                        <-- Archivio storico consolidato (file 01 .. 26)
    │   │   ├── ... (documenti storici da v.1.0 a v.2.4)
    │   │   ├── 24 - App TypeScript - Documento Conclusivo... (v.2.4).md
    │   │   ├── 25 - App TypeScript - Documento Conclusivo... (v.2.6).md
    │   │   └── 26 - FINE CHAT - Documento di Handoff Tecnico (Versione 2.6).md
    │   └── Ultima Chat/
    └── SRC/
        ├── help_(v.2.4).html                                                                <-- Storico
        ├── help_(v.2.5).html                                                                <-- Storico
        ├── help_(v.2.6).html                                                                <-- ATTIVO & SINCRONIZZATO (v.2.6)
        └── index_(v.2.4).html                                                               <-- CODICE SORGENTE ATTIVO COLLAUDATO
```

---

## 3. Regole d'Oro del Modus Operandi (Mandatorie per le Nuove Chat)

Qualsiasi agente o ingegnere software che subentri nelle sessioni successive **DEVE rispettare rigorosamente i seguenti 7 principi**:

1. **Versionamento Incrementale Sequenziale**:
   - Qualsiasi modifica ai sorgenti o alla documentazione deve comportare l'emissione di una nuova versione con **nuovo numero incrementale** (ad esempio: `v.2.7`).
   - Mai sovrascrivere file storici preesistenti; creare sempre il file con suffisso progressivo (es. `index_(v.2.7).html`, `help_(v.2.7).html`).
2. **Modifiche Chirurgiche e Non Invasive**:
   - Vietato riscrivere o refactorizzare codice già funzionante e collaudato.
   - Gli interventi devono essere puntuali, circoscritti e strettamente mirati al fabbisogno richiesto.
3. **Preservazione dei Commenti e della Memoria Storica**:
   - Mantenere tutti i commenti tecnici preesistenti nel codice sorgente e nella documentazione.
4. **Zero Bug e Zero Regressioni**:
   - Nessun errore di console (0 eccezioni DevTools).
   - Nessuna perdita di funzionalità precedentemente implementata (da v.1.0 a v.2.6).
5. **Allineamento Speculare Triangolare**:
   - Mantenere sincronizzati in modo speculare **Sorgenti (`SRC`)**, **Documentazione (`NEW_DOCS` e `ALL DOCS`)** e **Guida Utente (`help.html`)**.
6. **Dislocazione dei File**:
   - Tutti i nuovi file prodotti devono risiedere sotto la directory `/workspace`.
7. **Divieto Assoluto di Formattazione LaTeX**:
   - È tassativamente vietato l'uso di formule o sintassi LaTeX (`$...$`, `$$...$$`, `\frac`, `\times`). Esporre sempre numeri, percentuali e formule in notazione naturale chiara (es. `NN.N%`, `87x78 px`, `1.5x`, `550 ms`).

---

## 4. Architettura del Software e Asset di Riferimento

### 4.1 Modello ad Oggetti (8 Classi Disaccoppiate)
Il sorgente operativo `index_(v.2.4).html` (circa 5.000 righe) è articolato in:
- `TypingEngine`: motore logico di computazione, cronometro, calcolo WPM/BTM lorde e nette, gestione errori, spazi fittizi `␣`, reset con Backspace a inizio frase con arresto del timer, 70 lezioni native incorporate (`EMBEDDED_LESSONS`).
- `VisualRenderer`: rendering tastiera virtuale e silhouette continua bimanuale SVG (viewBox 1408x768). Keycaps 3D ingranditi a 1.5x (87x78 px, font 48 px ultra-bold, bordo 4.8 px e alone 16 px, espansione fino a 174 px per `SPAZIO`). Regola dei modificatori incrociati e persistenza reale degli accordi fisici hardware (`activePhysicalKeys`) fino al rilascio (`keyup`).
- `StatisticsManager`: visualizzazione cartesiana responsive fullscreen su `ResizeObserver`. Istogramma a 6 ordinamenti dei 106 caratteri tracciati, grafico cronologico di velocità con asse Y commutabile, crosshair orizzontale a quota Y, macchina a stati di selezione a 3 click (intervallo -> singolo punto -> media globale) e 7 filtri selettivi per modalità.
- `ProfileManager`: gestione multi-utente su `localStorage` (`typingTrainer_users_v1`), salvataggio geometrie finestre, esportazione e importazione in formato JSON proprietario e in formato XML conforme allo schema C# originale (`DataSetArchivio.xsd`).
- `PhonemeEngine`: algoritmo probabilistico N-gram a finestra mobile di 4 caratteri su corpus letterario italiano continuo per generare sequenze sillabiche da 100 caratteri.
- `AudioEngine`: sintesi procedurale in tempo reale tramite Web Audio API (macchina da scrivere meccanica Underwood a 2 componenti rumore/risonanza, beep d'errore a 440 Hz e campana di fine esercizio a 2000 Hz).
- `WindowManager`: gestione finestre fluttuanti (drag & drop, resize elastico, z-index dinamico, contenimento anti-sforamento Viewport Clamping e pulsante di ricentratura rapida `#btnHandsCenter`).
- `AppController`: orchestratore generale (34 metodi), listener globale tastiera per hotkeys (F1-F12, ALT+), gestione modali (Seleziona Frase bidirezionale, Editor Custom, Gestione Utenti) e gestione del **badge d'errore galleggiante temporizzato (`#wrongCharFloatingBadge`, 550 ms)**.

### 4.2 Tabella di Mappatura Tasti (`KEY_MAP`)
- Mappatura completa e univoca di **126 glifi** su 4 file fisiche (Row 1 a Row 4).
- Gestione caratteri multiriga `®` e `\n` per `key_enter` (Dito 10) e rientri `→` e `\t` per `key_tab` (Dito 1).

---

## 5. Istruzioni per il Kickoff delle Chat Successive

Per riprendere il lavoro in una nuova chat senza sprecare token:
1. **Leggere come riferimento prioritario la cartella `/workspace/NEW_DOCS`**, in particolare il file `01 - Documento di Specifica Funzionale, Architettura Logica e Formati Dati (v.2.6).md`. Contiene già tutto il contesto condensato ed esaustivo.
2. Quando l'utente richiede modifiche o nuove funzionalità al codice sorgente:
   - Partire dalla base di `index_(v.2.4).html`.
   - Produrre il nuovo sorgente con versione progressiva **`index_(v.2.7).html`**.
   - Aggiornare specularmente la documentazione a **`v.2.7`**.
   - Collaudare e sincronizzare sempre il filesystem con `sync`.
