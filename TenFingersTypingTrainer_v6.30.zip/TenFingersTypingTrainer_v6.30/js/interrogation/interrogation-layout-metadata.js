/* TenFingersTypingTrainer v6.27 | interrogation-layout-metadata.js | Topologia margherita, slot tasti, estensioni anatomiche e dizionario ASCII per Interrogazione. */
(function (global) {
  "use strict";

  const KEY_BOXES = Object.freeze({
  "key_backslash": {
    "id": "key_backslash",
    "x": 10,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 36,
    "cy": 36
  },
  "key_1": {
    "id": "key_1",
    "x": 68,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 94,
    "cy": 36
  },
  "key_2": {
    "id": "key_2",
    "x": 126,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 152,
    "cy": 36
  },
  "key_3": {
    "id": "key_3",
    "x": 184,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 210,
    "cy": 36
  },
  "key_4": {
    "id": "key_4",
    "x": 242,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 268,
    "cy": 36
  },
  "key_5": {
    "id": "key_5",
    "x": 300,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 326,
    "cy": 36
  },
  "key_6": {
    "id": "key_6",
    "x": 358,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 384,
    "cy": 36
  },
  "key_7": {
    "id": "key_7",
    "x": 416,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 442,
    "cy": 36
  },
  "key_8": {
    "id": "key_8",
    "x": 474,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 500,
    "cy": 36
  },
  "key_9": {
    "id": "key_9",
    "x": 532,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 558,
    "cy": 36
  },
  "key_0": {
    "id": "key_0",
    "x": 590,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 616,
    "cy": 36
  },
  "key_quote": {
    "id": "key_quote",
    "x": 648,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 674,
    "cy": 36
  },
  "key_igrave": {
    "id": "key_igrave",
    "x": 706,
    "y": 10,
    "w": 52,
    "h": 52,
    "cx": 732,
    "cy": 36
  },
  "key_backspace": {
    "id": "key_backspace",
    "x": 764,
    "y": 10,
    "w": 96,
    "h": 52,
    "cx": 812,
    "cy": 36
  },
  "key_tab": {
    "id": "key_tab",
    "x": 10,
    "y": 68,
    "w": 76,
    "h": 52,
    "cx": 48,
    "cy": 94
  },
  "key_q": {
    "id": "key_q",
    "x": 92,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 118,
    "cy": 94
  },
  "key_w": {
    "id": "key_w",
    "x": 150,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 176,
    "cy": 94
  },
  "key_e": {
    "id": "key_e",
    "x": 208,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 234,
    "cy": 94
  },
  "key_r": {
    "id": "key_r",
    "x": 266,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 292,
    "cy": 94
  },
  "key_t": {
    "id": "key_t",
    "x": 324,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 350,
    "cy": 94
  },
  "key_y": {
    "id": "key_y",
    "x": 382,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 408,
    "cy": 94
  },
  "key_u": {
    "id": "key_u",
    "x": 440,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 466,
    "cy": 94
  },
  "key_i": {
    "id": "key_i",
    "x": 498,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 524,
    "cy": 94
  },
  "key_o": {
    "id": "key_o",
    "x": 556,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 582,
    "cy": 94
  },
  "key_p": {
    "id": "key_p",
    "x": 614,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 640,
    "cy": 94
  },
  "key_egrave": {
    "id": "key_egrave",
    "x": 672,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 698,
    "cy": 94
  },
  "key_plus": {
    "id": "key_plus",
    "x": 730,
    "y": 68,
    "w": 52,
    "h": 52,
    "cx": 756,
    "cy": 94
  },
  "key_enter": {
    "id": "key_enter",
    "x": 788,
    "y": 68,
    "w": 72,
    "h": 110,
    "cx": 824,
    "cy": 123
  },
  "key_caps": {
    "id": "key_caps",
    "x": 10,
    "y": 126,
    "w": 88,
    "h": 52,
    "cx": 54,
    "cy": 152
  },
  "key_a": {
    "id": "key_a",
    "x": 104,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 130,
    "cy": 152
  },
  "key_s": {
    "id": "key_s",
    "x": 162,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 188,
    "cy": 152
  },
  "key_d": {
    "id": "key_d",
    "x": 220,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 246,
    "cy": 152
  },
  "key_f": {
    "id": "key_f",
    "x": 278,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 304,
    "cy": 152
  },
  "key_g": {
    "id": "key_g",
    "x": 336,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 362,
    "cy": 152
  },
  "key_h": {
    "id": "key_h",
    "x": 394,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 420,
    "cy": 152
  },
  "key_j": {
    "id": "key_j",
    "x": 452,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 478,
    "cy": 152
  },
  "key_k": {
    "id": "key_k",
    "x": 510,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 536,
    "cy": 152
  },
  "key_l": {
    "id": "key_l",
    "x": 568,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 594,
    "cy": 152
  },
  "key_ograve": {
    "id": "key_ograve",
    "x": 626,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 652,
    "cy": 152
  },
  "key_agrave": {
    "id": "key_agrave",
    "x": 684,
    "y": 126,
    "w": 52,
    "h": 52,
    "cx": 710,
    "cy": 152
  },
  "key_ugrave": {
    "id": "key_ugrave",
    "x": 742,
    "y": 126,
    "w": 40,
    "h": 52,
    "cx": 762,
    "cy": 152
  },
  "key_shift_l": {
    "id": "key_shift_l",
    "x": 10,
    "y": 184,
    "w": 68,
    "h": 52,
    "cx": 44,
    "cy": 210
  },
  "key_less": {
    "id": "key_less",
    "x": 84,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 110,
    "cy": 210
  },
  "key_z": {
    "id": "key_z",
    "x": 142,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 168,
    "cy": 210
  },
  "key_x": {
    "id": "key_x",
    "x": 200,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 226,
    "cy": 210
  },
  "key_c": {
    "id": "key_c",
    "x": 258,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 284,
    "cy": 210
  },
  "key_v": {
    "id": "key_v",
    "x": 316,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 342,
    "cy": 210
  },
  "key_b": {
    "id": "key_b",
    "x": 374,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 400,
    "cy": 210
  },
  "key_n": {
    "id": "key_n",
    "x": 432,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 458,
    "cy": 210
  },
  "key_m": {
    "id": "key_m",
    "x": 490,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 516,
    "cy": 210
  },
  "key_comma": {
    "id": "key_comma",
    "x": 548,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 574,
    "cy": 210
  },
  "key_period": {
    "id": "key_period",
    "x": 606,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 632,
    "cy": 210
  },
  "key_minus": {
    "id": "key_minus",
    "x": 664,
    "y": 184,
    "w": 52,
    "h": 52,
    "cx": 690,
    "cy": 210
  },
  "key_shift_r": {
    "id": "key_shift_r",
    "x": 722,
    "y": 184,
    "w": 138,
    "h": 52,
    "cx": 791,
    "cy": 210
  },
  "key_ctrl_l": {
    "id": "key_ctrl_l",
    "x": 10,
    "y": 242,
    "w": 68,
    "h": 52,
    "cx": 44,
    "cy": 268
  },
  "key_win_l": {
    "id": "key_win_l",
    "x": 84,
    "y": 242,
    "w": 52,
    "h": 52,
    "cx": 110,
    "cy": 268
  },
  "key_alt_l": {
    "id": "key_alt_l",
    "x": 142,
    "y": 242,
    "w": 62,
    "h": 52,
    "cx": 173,
    "cy": 268
  },
  "key_space": {
    "id": "key_space",
    "x": 210,
    "y": 242,
    "w": 350,
    "h": 52,
    "cx": 385,
    "cy": 268
  },
  "key_altgr": {
    "id": "key_altgr",
    "x": 566,
    "y": 242,
    "w": 64,
    "h": 52,
    "cx": 598,
    "cy": 268
  },
  "key_win_r": {
    "id": "key_win_r",
    "x": 636,
    "y": 242,
    "w": 52,
    "h": 52,
    "cx": 662,
    "cy": 268
  },
  "key_menu": {
    "id": "key_menu",
    "x": 694,
    "y": 242,
    "w": 52,
    "h": 52,
    "cx": 720,
    "cy": 268
  },
  "key_ctrl_r": {
    "id": "key_ctrl_r",
    "x": 752,
    "y": 242,
    "w": 108,
    "h": 52,
    "cx": 806,
    "cy": 268
  }
});

  const KEY_NEIGHBORS = Object.freeze({
  "key_backslash": {
    "topLeft": null,
    "topRight": null,
    "left": null,
    "right": "key_1",
    "bottomLeft": "key_tab",
    "bottomRight": null
  },
  "key_1": {
    "topLeft": null,
    "topRight": null,
    "left": "key_backslash",
    "right": "key_2",
    "bottomLeft": "key_tab",
    "bottomRight": "key_q"
  },
  "key_2": {
    "topLeft": null,
    "topRight": null,
    "left": "key_1",
    "right": "key_3",
    "bottomLeft": "key_q",
    "bottomRight": "key_w"
  },
  "key_3": {
    "topLeft": null,
    "topRight": null,
    "left": "key_2",
    "right": "key_4",
    "bottomLeft": "key_w",
    "bottomRight": "key_e"
  },
  "key_4": {
    "topLeft": null,
    "topRight": null,
    "left": "key_3",
    "right": "key_5",
    "bottomLeft": "key_e",
    "bottomRight": "key_r"
  },
  "key_5": {
    "topLeft": null,
    "topRight": null,
    "left": "key_4",
    "right": "key_6",
    "bottomLeft": "key_r",
    "bottomRight": "key_t"
  },
  "key_6": {
    "topLeft": null,
    "topRight": null,
    "left": "key_5",
    "right": "key_7",
    "bottomLeft": "key_t",
    "bottomRight": "key_y"
  },
  "key_7": {
    "topLeft": null,
    "topRight": null,
    "left": "key_6",
    "right": "key_8",
    "bottomLeft": "key_y",
    "bottomRight": "key_u"
  },
  "key_8": {
    "topLeft": null,
    "topRight": null,
    "left": "key_7",
    "right": "key_9",
    "bottomLeft": "key_u",
    "bottomRight": "key_i"
  },
  "key_9": {
    "topLeft": null,
    "topRight": null,
    "left": "key_8",
    "right": "key_0",
    "bottomLeft": "key_i",
    "bottomRight": "key_o"
  },
  "key_0": {
    "topLeft": null,
    "topRight": null,
    "left": "key_9",
    "right": "key_quote",
    "bottomLeft": "key_o",
    "bottomRight": "key_p"
  },
  "key_quote": {
    "topLeft": null,
    "topRight": null,
    "left": "key_0",
    "right": "key_igrave",
    "bottomLeft": "key_p",
    "bottomRight": "key_egrave"
  },
  "key_igrave": {
    "topLeft": null,
    "topRight": null,
    "left": "key_quote",
    "right": "key_backspace",
    "bottomLeft": "key_egrave",
    "bottomRight": "key_plus"
  },
  "key_backspace": {
    "topLeft": null,
    "topRight": null,
    "left": "key_igrave",
    "right": null,
    "bottomLeft": "key_plus",
    "bottomRight": "key_enter"
  },
  "key_tab": {
    "topLeft": "key_backslash",
    "topRight": "key_1",
    "left": null,
    "right": "key_q",
    "bottomLeft": "key_caps",
    "bottomRight": null
  },
  "key_q": {
    "topLeft": "key_1",
    "topRight": "key_2",
    "left": "key_tab",
    "right": "key_w",
    "bottomLeft": "key_caps",
    "bottomRight": "key_a"
  },
  "key_w": {
    "topLeft": "key_2",
    "topRight": "key_3",
    "left": "key_q",
    "right": "key_e",
    "bottomLeft": "key_a",
    "bottomRight": "key_s"
  },
  "key_e": {
    "topLeft": "key_3",
    "topRight": "key_4",
    "left": "key_w",
    "right": "key_r",
    "bottomLeft": "key_s",
    "bottomRight": "key_d"
  },
  "key_r": {
    "topLeft": "key_4",
    "topRight": "key_5",
    "left": "key_e",
    "right": "key_t",
    "bottomLeft": "key_d",
    "bottomRight": "key_f"
  },
  "key_t": {
    "topLeft": "key_5",
    "topRight": "key_6",
    "left": "key_r",
    "right": "key_y",
    "bottomLeft": "key_f",
    "bottomRight": "key_g"
  },
  "key_y": {
    "topLeft": "key_6",
    "topRight": "key_7",
    "left": "key_t",
    "right": "key_u",
    "bottomLeft": "key_g",
    "bottomRight": "key_h"
  },
  "key_u": {
    "topLeft": "key_7",
    "topRight": "key_8",
    "left": "key_y",
    "right": "key_i",
    "bottomLeft": "key_h",
    "bottomRight": "key_j"
  },
  "key_i": {
    "topLeft": "key_8",
    "topRight": "key_9",
    "left": "key_u",
    "right": "key_o",
    "bottomLeft": "key_j",
    "bottomRight": "key_k"
  },
  "key_o": {
    "topLeft": "key_9",
    "topRight": "key_0",
    "left": "key_i",
    "right": "key_p",
    "bottomLeft": "key_k",
    "bottomRight": "key_l"
  },
  "key_p": {
    "topLeft": "key_0",
    "topRight": "key_quote",
    "left": "key_o",
    "right": "key_egrave",
    "bottomLeft": "key_l",
    "bottomRight": "key_ograve"
  },
  "key_egrave": {
    "topLeft": "key_quote",
    "topRight": "key_igrave",
    "left": "key_p",
    "right": "key_plus",
    "bottomLeft": "key_ograve",
    "bottomRight": "key_agrave"
  },
  "key_plus": {
    "topLeft": "key_igrave",
    "topRight": "key_backspace",
    "left": "key_egrave",
    "right": "key_enter",
    "bottomLeft": "key_agrave",
    "bottomRight": "key_ugrave"
  },
  "key_enter": {
    "topLeft": "key_backspace",
    "topRight": null,
    "left": "key_plus",
    "right": null,
    "bottomLeft": "key_shift_r",
    "bottomRight": null
  },
  "key_caps": {
    "topLeft": "key_tab",
    "topRight": "key_q",
    "left": null,
    "right": "key_a",
    "bottomLeft": "key_shift_l",
    "bottomRight": "key_less"
  },
  "key_a": {
    "topLeft": "key_q",
    "topRight": "key_w",
    "left": "key_caps",
    "right": "key_s",
    "bottomLeft": "key_less",
    "bottomRight": "key_z"
  },
  "key_s": {
    "topLeft": "key_w",
    "topRight": "key_e",
    "left": "key_a",
    "right": "key_d",
    "bottomLeft": "key_z",
    "bottomRight": "key_x"
  },
  "key_d": {
    "topLeft": "key_e",
    "topRight": "key_r",
    "left": "key_s",
    "right": "key_f",
    "bottomLeft": "key_x",
    "bottomRight": "key_c"
  },
  "key_f": {
    "topLeft": "key_r",
    "topRight": "key_t",
    "left": "key_d",
    "right": "key_g",
    "bottomLeft": "key_c",
    "bottomRight": "key_v"
  },
  "key_g": {
    "topLeft": "key_t",
    "topRight": "key_y",
    "left": "key_f",
    "right": "key_h",
    "bottomLeft": "key_v",
    "bottomRight": "key_b"
  },
  "key_h": {
    "topLeft": "key_y",
    "topRight": "key_u",
    "left": "key_g",
    "right": "key_j",
    "bottomLeft": "key_b",
    "bottomRight": "key_n"
  },
  "key_j": {
    "topLeft": "key_u",
    "topRight": "key_i",
    "left": "key_h",
    "right": "key_k",
    "bottomLeft": "key_n",
    "bottomRight": "key_m"
  },
  "key_k": {
    "topLeft": "key_i",
    "topRight": "key_o",
    "left": "key_j",
    "right": "key_l",
    "bottomLeft": "key_m",
    "bottomRight": "key_comma"
  },
  "key_l": {
    "topLeft": "key_o",
    "topRight": "key_p",
    "left": "key_k",
    "right": "key_ograve",
    "bottomLeft": "key_comma",
    "bottomRight": "key_period"
  },
  "key_ograve": {
    "topLeft": "key_p",
    "topRight": "key_egrave",
    "left": "key_l",
    "right": "key_agrave",
    "bottomLeft": "key_period",
    "bottomRight": "key_minus"
  },
  "key_agrave": {
    "topLeft": "key_egrave",
    "topRight": "key_plus",
    "left": "key_ograve",
    "right": "key_ugrave",
    "bottomLeft": "key_minus",
    "bottomRight": "key_shift_r"
  },
  "key_ugrave": {
    "topLeft": "key_plus",
    "topRight": null,
    "left": "key_agrave",
    "right": "key_enter",
    "bottomLeft": "key_shift_r",
    "bottomRight": null
  },
  "key_shift_l": {
    "topLeft": "key_caps",
    "topRight": null,
    "left": null,
    "right": "key_less",
    "bottomLeft": "key_ctrl_l",
    "bottomRight": null
  },
  "key_less": {
    "topLeft": "key_caps",
    "topRight": "key_a",
    "left": "key_shift_l",
    "right": "key_z",
    "bottomLeft": "key_win_l",
    "bottomRight": null
  },
  "key_z": {
    "topLeft": "key_a",
    "topRight": "key_s",
    "left": "key_less",
    "right": "key_x",
    "bottomLeft": "key_alt_l",
    "bottomRight": null
  },
  "key_x": {
    "topLeft": "key_s",
    "topRight": "key_d",
    "left": "key_z",
    "right": "key_c",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_c": {
    "topLeft": "key_d",
    "topRight": "key_f",
    "left": "key_x",
    "right": "key_v",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_v": {
    "topLeft": "key_f",
    "topRight": "key_g",
    "left": "key_c",
    "right": "key_b",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_b": {
    "topLeft": "key_g",
    "topRight": "key_h",
    "left": "key_v",
    "right": "key_n",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_n": {
    "topLeft": "key_h",
    "topRight": "key_j",
    "left": "key_b",
    "right": "key_m",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_m": {
    "topLeft": "key_j",
    "topRight": "key_k",
    "left": "key_n",
    "right": "key_comma",
    "bottomLeft": "key_space",
    "bottomRight": null
  },
  "key_comma": {
    "topLeft": "key_k",
    "topRight": "key_l",
    "left": "key_m",
    "right": "key_period",
    "bottomLeft": "key_space",
    "bottomRight": "key_altgr"
  },
  "key_period": {
    "topLeft": "key_l",
    "topRight": "key_ograve",
    "left": "key_comma",
    "right": "key_minus",
    "bottomLeft": "key_altgr",
    "bottomRight": "key_win_r"
  },
  "key_minus": {
    "topLeft": "key_ograve",
    "topRight": "key_agrave",
    "left": "key_period",
    "right": "key_shift_r",
    "bottomLeft": "key_win_r",
    "bottomRight": "key_menu"
  },
  "key_shift_r": {
    "topLeft": "key_ugrave",
    "topRight": "key_enter",
    "left": "key_minus",
    "right": null,
    "bottomLeft": "key_menu",
    "bottomRight": "key_ctrl_r"
  },
  "key_ctrl_l": {
    "topLeft": "key_shift_l",
    "topRight": null,
    "left": null,
    "right": "key_win_l",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_win_l": {
    "topLeft": "key_less",
    "topRight": null,
    "left": "key_ctrl_l",
    "right": "key_alt_l",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_alt_l": {
    "topLeft": "key_z",
    "topRight": null,
    "left": "key_win_l",
    "right": "key_space",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_space": {
    "topLeft": "key_v",
    "topRight": "key_b",
    "left": "key_alt_l",
    "right": "key_altgr",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_altgr": {
    "topLeft": "key_comma",
    "topRight": "key_period",
    "left": "key_space",
    "right": "key_win_r",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_win_r": {
    "topLeft": "key_period",
    "topRight": "key_minus",
    "left": "key_altgr",
    "right": "key_menu",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_menu": {
    "topLeft": "key_minus",
    "topRight": "key_shift_r",
    "left": "key_win_r",
    "right": "key_ctrl_r",
    "bottomLeft": null,
    "bottomRight": null
  },
  "key_ctrl_r": {
    "topLeft": "key_shift_r",
    "topRight": null,
    "left": "key_menu",
    "right": null,
    "bottomLeft": null,
    "bottomRight": null
  }
});

  const KEY_SLOTS = Object.freeze({
  "key_0": {
    "normal": "0",
    "shift": "=",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_1": {
    "normal": "1",
    "shift": "!",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_2": {
    "normal": "2",
    "shift": "\"",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_3": {
    "normal": "3",
    "shift": "£",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_4": {
    "normal": "4",
    "shift": "$",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_5": {
    "normal": "5",
    "shift": "%",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_6": {
    "normal": "6",
    "shift": "&",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_7": {
    "normal": "7",
    "shift": "/",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_8": {
    "normal": "8",
    "shift": "(",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_9": {
    "normal": "9",
    "shift": ")",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_a": {
    "normal": "a",
    "shift": "A",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_agrave": {
    "normal": "à",
    "shift": "°",
    "altgr": "#",
    "shiftAltgr": null
  },
  "key_b": {
    "normal": "b",
    "shift": "B",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_backslash": {
    "normal": "\\",
    "shift": "|",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_backspace": {
    "normal": "Backspace",
    "shift": null,
    "altgr": null,
    "shiftAltgr": null
  },
  "key_c": {
    "normal": "c",
    "shift": "C",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_comma": {
    "normal": ",",
    "shift": ";",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_d": {
    "normal": "d",
    "shift": "D",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_e": {
    "normal": "e",
    "shift": "E",
    "altgr": "€",
    "shiftAltgr": null
  },
  "key_egrave": {
    "normal": "è",
    "shift": "é",
    "altgr": "[",
    "shiftAltgr": "{"
  },
  "key_enter": {
    "normal": "®",
    "shift": null,
    "altgr": null,
    "shiftAltgr": null
  },
  "key_f": {
    "normal": "f",
    "shift": "F",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_g": {
    "normal": "g",
    "shift": "G",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_h": {
    "normal": "h",
    "shift": "H",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_i": {
    "normal": "i",
    "shift": "I",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_igrave": {
    "normal": "ì",
    "shift": "^",
    "altgr": "~",
    "shiftAltgr": null
  },
  "key_j": {
    "normal": "j",
    "shift": "J",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_k": {
    "normal": "k",
    "shift": "K",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_l": {
    "normal": "l",
    "shift": "L",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_less": {
    "normal": "<",
    "shift": ">",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_m": {
    "normal": "m",
    "shift": "M",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_minus": {
    "normal": "-",
    "shift": "_",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_n": {
    "normal": "n",
    "shift": "N",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_o": {
    "normal": "o",
    "shift": "O",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_ograve": {
    "normal": "ò",
    "shift": "ç",
    "altgr": "@",
    "shiftAltgr": null
  },
  "key_p": {
    "normal": "p",
    "shift": "P",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_period": {
    "normal": ".",
    "shift": ":",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_plus": {
    "normal": "+",
    "shift": "*",
    "altgr": "]",
    "shiftAltgr": "}"
  },
  "key_q": {
    "normal": "q",
    "shift": "Q",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_quote": {
    "normal": "'",
    "shift": "?",
    "altgr": "`",
    "shiftAltgr": null
  },
  "key_r": {
    "normal": "r",
    "shift": "R",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_s": {
    "normal": "s",
    "shift": "S",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_space": {
    "normal": " ",
    "shift": null,
    "altgr": null,
    "shiftAltgr": null
  },
  "key_t": {
    "normal": "t",
    "shift": "T",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_tab": {
    "normal": "→",
    "shift": null,
    "altgr": null,
    "shiftAltgr": null
  },
  "key_u": {
    "normal": "u",
    "shift": "U",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_ugrave": {
    "normal": "ù",
    "shift": "§",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_v": {
    "normal": "v",
    "shift": "V",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_w": {
    "normal": "w",
    "shift": "W",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_x": {
    "normal": "x",
    "shift": "X",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_y": {
    "normal": "y",
    "shift": "Y",
    "altgr": null,
    "shiftAltgr": null
  },
  "key_z": {
    "normal": "z",
    "shift": "Z",
    "altgr": null,
    "shiftAltgr": null
  }
});

  const KEY_EXTENSIONS = Object.freeze({
  "key_backslash": {
    "longitudinalExt": 2,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_1": {
    "longitudinalExt": 2,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_2": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_3": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_4": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_5": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_6": {
    "longitudinalExt": 2,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_7": {
    "longitudinalExt": 2,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_8": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_9": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_0": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_quote": {
    "longitudinalExt": 2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_igrave": {
    "longitudinalExt": 2,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_backspace": {
    "longitudinalExt": 2,
    "lateralExt": 2,
    "lateralDir": "dx"
  },
  "key_tab": {
    "longitudinalExt": 1,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_q": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_w": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_e": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_r": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_t": {
    "longitudinalExt": 1,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_y": {
    "longitudinalExt": 1,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_u": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_i": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_o": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_p": {
    "longitudinalExt": 1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_egrave": {
    "longitudinalExt": 1,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_plus": {
    "longitudinalExt": 1,
    "lateralExt": 2,
    "lateralDir": "dx"
  },
  "key_enter": {
    "longitudinalExt": 1,
    "lateralExt": 3,
    "lateralDir": "dx"
  },
  "key_caps": {
    "longitudinalExt": 0,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_a": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_s": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_d": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_f": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_g": {
    "longitudinalExt": 0,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_h": {
    "longitudinalExt": 0,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_j": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_k": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_l": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_ograve": {
    "longitudinalExt": 0,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_agrave": {
    "longitudinalExt": 0,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_ugrave": {
    "longitudinalExt": 0,
    "lateralExt": 2,
    "lateralDir": "dx"
  },
  "key_shift_l": {
    "longitudinalExt": -1,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_less": {
    "longitudinalExt": -1,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_z": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_x": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_c": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_v": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_b": {
    "longitudinalExt": -1,
    "lateralExt": 1,
    "lateralDir": "dx"
  },
  "key_n": {
    "longitudinalExt": -1,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_m": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_comma": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_period": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_minus": {
    "longitudinalExt": -1,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_shift_r": {
    "longitudinalExt": -1,
    "lateralExt": 2,
    "lateralDir": "dx"
  },
  "key_ctrl_l": {
    "longitudinalExt": -2,
    "lateralExt": 1,
    "lateralDir": "sn"
  },
  "key_win_l": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_alt_l": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_space": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_altgr": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_win_r": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_menu": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  },
  "key_ctrl_r": {
    "longitudinalExt": -2,
    "lateralExt": 0,
    "lateralDir": "none"
  }
});

  const SPECIAL_KEY_LABELS = Object.freeze({
  "key_tab": "TAB",
  "key_caps": "CAPS",
  "key_shift_l": "SHIFT-sn",
  "key_shift_r": "SHIFT-dx",
  "key_ctrl_l": "CTRL-sn",
  "key_ctrl_r": "CTRL-dx",
  "key_win_l": "WIN-sn",
  "key_win_r": "WIN-dx",
  "key_alt_l": "ALT",
  "key_altgr": "ALTGR",
  "key_menu": "MENU",
  "key_space": "SPAZIO",
  "key_enter": "INVIO",
  "key_backspace": "BACK"
});

  const ASCII_CHARACTERS = Object.freeze(["!","\"","#","$","%","&","'","(",")","*","+",",","-",".","/","0","1","2","3","4","5","6","7","8","9",":",";","<","=",">","?","@","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","[","\\","]","^","_","`","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","{","|","}","~","£","§","°","à","ç","è","é","ì","ò","ù","€"]);

  const SPECIAL_PICKER_KEYS = Object.freeze([
    { keyId: "key_tab", label: "TAB" },
    { keyId: "key_caps", label: "CAPS" },
    { keyId: "key_shift_l", label: "SHIFT-sn" },
    { keyId: "key_shift_r", label: "SHIFT-dx" },
    { keyId: "key_ctrl_l", label: "CTRL-sn" },
    { keyId: "key_ctrl_r", label: "CTRL-dx" },
    { keyId: "key_win_l", label: "WIN-sn" },
    { keyId: "key_win_r", label: "WIN-dx" },
    { keyId: "key_alt_l", label: "ALT" },
    { keyId: "key_altgr", label: "ALTGR" },
    { keyId: "key_menu", label: "MENU" },
    { keyId: "key_space", label: "SPAZIO" },
    { keyId: "key_enter", label: "INVIO" },
    { keyId: "key_backspace", label: "BACK" }
  ]);

  const HOME_ROW_KEYS = Object.freeze({
    left: [
      { keyId: "key_a", char: "a", fingerId: "1", fingerLabel: "mignolo - (sn)" },
      { keyId: "key_s", char: "s", fingerId: "2", fingerLabel: "anulare - (sn)" },
      { keyId: "key_d", char: "d", fingerId: "3", fingerLabel: "medio - (sn)" },
      { keyId: "key_f", char: "f", fingerId: "4", fingerLabel: "indice - (sn)" }
    ],
    right: [
      { keyId: "key_j", char: "j", fingerId: "7", fingerLabel: "indice - (dx)" },
      { keyId: "key_k", char: "k", fingerId: "8", fingerLabel: "medio - (dx)" },
      { keyId: "key_l", char: "l", fingerId: "9", fingerLabel: "anulare - (dx)" },
      { keyId: "key_ograve", char: "ò", fingerId: "10", fingerLabel: "mignolo - (dx)" }
    ]
  });

  function getKeyBox(keyId) {
    return KEY_BOXES[keyId] || null;
  }

  function getNeighbors(keyId) {
    return KEY_NEIGHBORS[keyId] || null;
  }

  function getKeySlots(keyId) {
    return KEY_SLOTS[keyId] || null;
  }

  function getKeyExtension(keyId) {
    return KEY_EXTENSIONS[keyId] || { longitudinalExt: 0, lateralExt: 0, lateralDir: "none" };
  }

  function getKeyDisplayToken(keyId) {
    if (!keyId) return "NONE";
    if (SPECIAL_KEY_LABELS[keyId]) return SPECIAL_KEY_LABELS[keyId];
    const slots = KEY_SLOTS[keyId];
    if (slots && slots.normal) return slots.normal;
    return keyId.replace(/^key_/, "");
  }

  function resolveKeyIdFromToken(token) {
    if (!token || token === "NONE") return null;
    const t = String(token).trim();
    if (KEY_BOXES[t]) return t;
    for (const [kId, lbl] of Object.entries(SPECIAL_KEY_LABELS)) {
      if (lbl.toLowerCase() === t.toLowerCase()) return kId;
    }
    for (const [kId, slots] of Object.entries(KEY_SLOTS)) {
      if (slots.normal === t || slots.shift === t || slots.altgr === t || slots.shiftAltgr === t) {
        return kId;
      }
    }
    return null;
  }

  /**
   * Normalizza la selezione dei checkbox modificatori (CTRL, SHIFT, ALT, ALTGR)
   * e verifica l'equivalenza AltGr <-> CTRL + ALT.
   */
  function normalizeModifierMode(modMode) {
    const raw = String(modMode || "none").trim();
    if (raw === "shiftL" || raw === "shiftR") return "shift";
    return raw;
  }

  function isModifierMatch(expectedModMode, selectedCheckboxes) {
    const sel = selectedCheckboxes || {};
    const hasCtrl = !!sel.ctrl;
    const hasShift = !!sel.shift;
    const hasAlt = !!sel.alt;
    const hasAltGr = !!sel.altgr;

    const norm = normalizeModifierMode(expectedModMode);
    if (norm === "none") {
      return !hasCtrl && !hasShift && !hasAlt && !hasAltGr;
    }
    if (norm === "shift") {
      return hasShift && !hasCtrl && !hasAlt && !hasAltGr;
    }
    if (norm === "altgr") {
      // Accetta sia AltGr sia CTRL + ALT (senza Shift)
      return !hasShift && ((hasAltGr && !hasCtrl && !hasAlt) || (hasCtrl && hasAlt && !hasAltGr));
    }
    if (norm === "shiftAltgr") {
      // Accetta sia SHIFT + AltGr sia CTRL + ALT + SHIFT
      return hasShift && ((hasAltGr && !hasCtrl && !hasAlt) || (hasCtrl && hasAlt && !hasAltGr));
    }
    return false;
  }

  function getKeysForFinger(catalog, fingerId, filter) {
    const f = filter || {};
    const fNum = parseInt(String(fingerId).replace(/^finger\./, ""), 10);
    const keys = catalog.getAllPhysicalKeys().filter((k) => Number(k.assignedFinger) === fNum);
    return keys.filter((k) => {
      const ext = getKeyExtension(k.keyId);
      if (f.lateralExt !== undefined && f.lateralExt !== null && f.lateralExt !== "") {
        if (ext.lateralExt !== Number(f.lateralExt)) return false;
      }
      if (f.lateralDir && f.lateralDir !== "any") {
        if (ext.lateralDir !== f.lateralDir) return false;
      }
      return true;
    });
  }

  const api = {
    KEY_BOXES,
    KEY_NEIGHBORS,
    KEY_SLOTS,
    KEY_EXTENSIONS,
    SPECIAL_KEY_LABELS,
    ASCII_CHARACTERS,
    SPECIAL_PICKER_KEYS,
    HOME_ROW_KEYS,
    getKeyBox,
    getNeighbors,
    getKeySlots,
    getKeyExtension,
    getKeyDisplayToken,
    resolveKeyIdFromToken,
    normalizeModifierMode,
    isModifierMatch,
    getKeysForFinger,
  };

  global.InterrogationLayoutMetadata = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof window !== "undefined" ? window : globalThis);
