# Checklist di regressione — v6.12

Eseguire in un browser aggiornato e verificare sia il comportamento UI sia la persistenza.

## Avvio e dati

- [ ] L'app si apre direttamente da `index.html` senza errori JavaScript.
- [ ] Il titolo della pagina e l'header mostrano la versione v6.12.
- [ ] La proprietà `app.version` nella console del browser restituisce "6.12".
- [ ] I profili esistenti caricati dal Local Storage restano accessibili e vengono aggiornati alla v6.12 al salvataggio.

## Controlli Zoom e Finestra Scorciatoie del Browser (Novità v6.10)
- [ ] Verificare la presenza dei tre pulsanti sulla barra del titolo: "🔍+ Zoom-in", "🔍- Zoom-out" e "🔍 Zoom-in e Zoom-out" (`#btnZoomInfo`).
- [ ] Verificare che il click sul pulsante "🔍 Zoom-in e Zoom-out" apra la finestra modale `#zoomHelpModal`.
- [ ] Verificare che la finestra modale contenga in chiaro le tre scorciatoie native universali del browser:
  - "CTRL+RotellinaMouse"
  - "CTRL+SHIFT++"
  - "CTRL+SHIFT+-"
- [ ] Verificare che la modale si chiuda con il pulsante `&times;`, con il pulsante `OK`, cliccando all'esterno o premendo il tasto `Escape`, restituendo il focus alla battitura.
- [ ] Verificare che il click su "🔍+ Zoom-in" e "🔍- Zoom-out" mostri la notifica temporizzata mini-toast (`showNotificationToast`) con l'indicazione della combinazione nativa, senza forzare modifiche CSS artificiali a `document.body.style.zoom`.
- [ ] Verificare che la pressione fisica delle scorciatoie native del browser (`CTRL+SHIFT++`, `CTRL+SHIFT+-`, `CTRL+RotellinaMouse`) esegua lo zoom nativo senza essere intercettata o bloccata con `preventDefault()`.
- [ ] Verificare che il drag, resize e ancoraggio (Pin) delle finestre flottanti rimangano perfetti senza distorsioni geometriche o derive delle coordinate.

## Metodo e input
- [ ] Verificare le sette modalità: PHRASES, RANDOM, FONEMI, ALL CHARS, TYPING, RANDOM THIS PHRASE, WEAKNESSES.
- [ ] Verificare mappatura dita, posizione di riposo e indicazioni visive.
- [ ] Verificare caratteri accentati, Shift, modificatori e combinazioni.
- [ ] Verificare spazi, Invio (`®`), Tab (`→`), Backspace e correzione progressiva.
- [ ] Verificare auto-correction attiva e disattivata.
- [ ] Verificare avanzamento, ripetizione e completamento frase.

## Voce e feedback
- [ ] Verificare audio feedback e relative opzioni.
- [ ] Verificare dettatura, velocità, voci italiane, maiuscole, apostrofi e spazi.
- [ ] Verificare replay e recupero dopo un errore.
- [ ] Verificare che il watchdog non lasci la dettatura bloccata.

## Finestre e visualizzazione

- [ ] Verificare che digitando una frase con la finestra Velocità Istantanea aperta compaia la curva a punti.
- [ ] Cliccare su ⚙ Parametri, modificare N (es. da 3 a 1 oppure da 3 a 7) e cliccare su Conferma.
- [ ] Verificare che la curva si ricalcoli e si rimodelli immediatamente a video su tutti i caratteri già battuti.
- [ ] Verificare che il tasto "x" e il tasto Escape chiudano regolarmente il modale e restituiscano il focus alla battuta.

## Velocità Istantanea: Ancoraggio Pin e Layout di Default (Novità v6.8)
- [ ] Verificare che nell'header della finestra "Velocità Istantanea" sia presente il pulsante "📍 Pinned" tra "⚙ Parametri" e "↺ Default".
- [ ] Con stato "📍 Pinned" attivo:
  - Nascondere/mostrare il Testo Guida, l'Input o gli Errori: verificare che la finestra trasli verticalmente in modo perfettamente solidale con la scheda di digitazione, mantenendo inalterata la distanza relativa dalla card.
  - Modificare lo zoom della pagina del browser: verificare che la finestra rimanga ancorata alla base della scheda senza distacchi né sovrapposizioni spurie.
- [ ] Cliccare sul pulsante "📍 Pinned": verificare che lo stato si alterni a "📌 Pin" (unpinned), con relativo aggiornamento del tooltip.
- [ ] Con stato "📌 Pin" disattivo:
  - Spostare la finestra e poi nascondere/mostrare elementi della scheda: verificare che la finestra conservi le proprie coordinate libere e non segua il reflow della card.
- [ ] Cliccare su "↺ Default" della finestra Velocità Istantanea:
  - Verificare che la finestra si ridisponga in primo piano sopra la tastiera e la finestra "10 Fingers (Mani)".
  - Verificare che le sue dimensioni coprano l'intera area congiunta di Tastiera e Mani.
  - Verificare che lo stato si reimposti automaticamente su "📍 Pinned".

## Fonemi ed Editor Custom (Novità v6.11)
- [ ] Verificare che nella finestra "Editor Frasi Personalizzate" sia visibile il pulsante "🗑 Elimina" tra "Export Testo di Input per Fonemi" e "Configurazione Fonemi".
- [ ] Verificare che eliminando la fonte custom venga ripristinato il corpus di default senza errori bloccanti.
- [ ] Verificare che nella finestra modale "⚙ Configurazione Fonemi" sia presente il campo "Numero Caratteri per Esercizio" (`#txtFonemiTargetLength`) con valore predefinito 100 e range da 20 a 500.
- [ ] Verificare la presenza del pulsante dedicato "↺ 100" (`#btnFonemiTargetLengthDefault`) a fianco del campo.
- [ ] Cliccare su "↺ 100": verificare che il campo si reimposti a 100 senza modificare N-grammi o probabilità.
- [ ] Cliccare su "↺ Default (N=4, 100 car., 30%)": verificare che anche il campo caratteri torni a 100 insieme a N=4 e tutte le probabilità al 30%.
- [ ] Impostare un valore personalizzato (es. 150): confermare con "Salva" e verificare che, se la modalità attiva è Fonemi, la frase generata rifletta la nuova lunghezza target e il valore rimanga memorizzato nel profilo attivo.

## Statistiche e profili
- [ ] Verificare metriche di sessione, statistiche per carattere e grafico della velocità.
- [ ] Verificare filtri per modalità e intervallo temporale.
- [ ] Verificare selezione e cancellazione dei campioni con "Elimina non selezionati".
- [ ] Verificare creazione, rinomina, cambio ed eliminazione profili.
- [ ] Verificare backup, esportazione e importazione.
- [ ] Verificare Editor Custom, formato titoli/separatori e token `®`/`→`.

## Accettazione finale
- [ ] Nessuna perdita di dati osservata.
- [ ] Nessuna funzione precedente risulta rimossa o alterata.
- [ ] Manuale, guida HTML e applicazione sono coerenti.
