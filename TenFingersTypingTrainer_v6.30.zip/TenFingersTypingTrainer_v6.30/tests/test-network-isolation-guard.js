#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const source = fs.readFileSync(
  path.join(root, "js/security/network-isolation-guard.js"),
  "utf8",
);

const listeners = {};
const documentListeners = {};
const opened = [];
const navigator = {
  sendBeacon() { return true; },
  serviceWorker: { register() { return Promise.resolve(); } },
  mediaDevices: {
    getUserMedia() { return Promise.resolve(); },
    enumerateDevices() { return Promise.resolve([]); },
    getDisplayMedia() { return Promise.resolve(); },
  },
  geolocation: {
    getCurrentPosition() {},
    watchPosition() {},
  },
  clipboard: {
    readText() { return Promise.resolve(""); },
    writeText() { return Promise.resolve(); },
  },
  share() { return Promise.resolve(); },
  credentials: {
    get() { return Promise.resolve(); },
    create() { return Promise.resolve(); },
  },
  bluetooth: { requestDevice() { return Promise.resolve(); } },
  usb: { requestDevice() { return Promise.resolve(); } },
  serial: { requestPort() { return Promise.resolve(); } },
  hid: { requestDevice() { return Promise.resolve(); } },
  nfc: { scan() { return Promise.resolve(); }, write() { return Promise.resolve(); } },
};

const sandbox = {
  URL,
  Date,
  Error,
  Object,
  navigator,
  location: { href: "file:///local-app/index.html" },
  document: {
    addEventListener(name, callback, capture) { documentListeners[name] = { callback, capture }; },
  },
  fetch() { return Promise.resolve(); },
  XMLHttpRequest: function XMLHttpRequest() {},
  WebSocket: function WebSocket() {},
  EventSource: function EventSource() {},
  Worker: function Worker() {},
  SharedWorker: function SharedWorker() {},
  WebTransport: function WebTransport() {},
  RTCPeerConnection: function RTCPeerConnection() {},
  BroadcastChannel: function BroadcastChannel() {},
  addEventListener(name, callback) { listeners[name] = callback; },
  open(url) { opened.push(url); return { url }; },
};
sandbox.window = sandbox;
vm.createContext(sandbox);
vm.runInContext(source, sandbox, { filename: "network-isolation-guard.js" });

function mustBlock(label, action) {
  let blocked = false;
  try { action(); } catch (error) { blocked = error && error.name === "SecurityError"; }
  if (!blocked) throw new Error(`${label}: tentativo non bloccato.`);
}

mustBlock("fetch", () => sandbox.fetch("https://example.invalid"));
mustBlock("XMLHttpRequest", () => new sandbox.XMLHttpRequest());
mustBlock("WebSocket", () => new sandbox.WebSocket("wss://example.invalid"));
mustBlock("EventSource", () => new sandbox.EventSource("https://example.invalid/events"));
mustBlock("Worker", () => new sandbox.Worker("https://example.invalid/worker.js"));
mustBlock("sendBeacon", () => navigator.sendBeacon("https://example.invalid", "x"));
mustBlock("serviceWorker.register", () => navigator.serviceWorker.register("sw.js"));
mustBlock("getUserMedia", () => navigator.mediaDevices.getUserMedia({ audio: true }));
mustBlock("geolocation", () => navigator.geolocation.getCurrentPosition(() => {}));
mustBlock("clipboard read", () => navigator.clipboard.readText());
mustBlock("share", () => navigator.share({ text: "private" }));
mustBlock("credentials", () => navigator.credentials.get());
mustBlock("screen capture", () => navigator.mediaDevices.getDisplayMedia());
mustBlock("Bluetooth", () => navigator.bluetooth.requestDevice());
mustBlock("USB", () => navigator.usb.requestDevice());
mustBlock("Serial", () => navigator.serial.requestPort());
mustBlock("HID", () => navigator.hid.requestDevice());
mustBlock("NFC", () => navigator.nfc.scan());
mustBlock("WebTransport", () => new sandbox.WebTransport("https://example.invalid"));
mustBlock("WebRTC", () => new sandbox.RTCPeerConnection());
mustBlock("BroadcastChannel", () => new sandbox.BroadcastChannel("cross-tab"));
mustBlock("external window.open", () => sandbox.open("https://example.invalid"));

const helpWindow = sandbox.open("help.html", "_blank");
if (!helpWindow || opened.length !== 1 || opened[0] !== "help.html") {
  throw new Error("La guida locale help.html non è stata autorizzata.");
}

function clickAnchor(href) {
  let prevented = false;
  let stopped = false;
  const anchor = { getAttribute: () => href };
  documentListeners.click.callback({
    target: { closest: () => anchor },
    preventDefault() { prevented = true; },
    stopImmediatePropagation() { stopped = true; },
  });
  return { prevented, stopped };
}
const externalAnchor = clickAnchor("https://example.invalid/private");
if (!externalAnchor.prevented || !externalAnchor.stopped) {
  throw new Error("La navigazione tramite anchor esterno non è stata bloccata.");
}
const localAnchor = clickAnchor("help.html");
if (localAnchor.prevented || localAnchor.stopped) {
  throw new Error("La navigazione verso la guida locale è stata bloccata.");
}

if (typeof listeners.securitypolicyviolation !== "function") {
  throw new Error("Listener securitypolicyviolation non registrato.");
}
listeners.securitypolicyviolation({
  effectiveDirective: "connect-src",
  blockedURI: "https://example.invalid/telemetry",
  disposition: "enforce",
});

const diagnostics = sandbox.TTTNetworkIsolationGuard.getDiagnostics();
if (diagnostics.blockedAttempts.length < 20) {
  throw new Error("Le invocazioni bloccate non sono state registrate.");
}
if (diagnostics.cspViolations.length !== 1 || diagnostics.cspViolations[0].directive !== "connect-src") {
  throw new Error("La violazione CSP non è stata registrata correttamente.");
}

console.log(`PASS: ${diagnostics.blockedAttempts.length} tentativi di comunicazione/accesso sono stati bloccati.`);
console.log("PASS: l'unica apertura di finestra ammessa è la guida locale help.html.");
console.log("PASS: anchor esterni bloccati, navigazioni locali consentite.");
console.log("PASS: gli eventi securitypolicyviolation sono registrati per la diagnostica.");
