# Motore della conoscenza INTERROGAZIONE — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Fonti:** Specifiche Tecniche Interrogazione v1.0; HANDOFF Tecnico Interrogazione v1.0; Contratti Backend Interrogazione v1.1; Schema IndexedDB Interrogazione v1.1; Catalogo Domande Interrogazione v1.0; Motore Selezione Interrogazione v1.0  
**Stato:** specifica esecutiva proposta; nessuna modifica ai sorgenti  
**Ambito:** proiezione della conoscenza individuale e per categoria, decadimento, affidabilità, debolezza, classificazione, priorità e calendario di consolidamento.

---

## 1. Responsabilità e confini

`InterrogationKnowledge` trasforma lo storico immutabile degli eventi di esposizione e delle relative correzioni in una proiezione di conoscenza aggiornata. Non seleziona domande, non assegna punteggi di sessione e non decide la presentazione UI.

Responsabilità:

1. ricostruire gli eventi effettivi di ogni sotto-quesito;
2. applicare le correzioni append-only senza alterare lo storico originale;
3. calcolare esposizioni equivalenti e decadimento;
4. calcolare fattori di debolezza, affidabilità e classe;
5. calcolare le metriche di categoria;
6. gestire priorità temporanee da consultazione;
7. aggiornare il calendario di consolidamento secondo la policy configurata;
8. esporre una proiezione versionata e riproducibile al motore di selezione.

Non deve riutilizzare `StatisticsManager`: le sue statistiche riguardano la digitazione, non la conoscenza didattica.

## 2. Fonti dei dati e unità di calcolo

L'unità statistica è il **sotto-quesito identificato da `questionSemanticId`**, non la domanda principale che lo contiene. Due sotto-quesiti della stessa domanda possono avere affidabilità, debolezza, classe e calendario differenti.

Sono esposizioni effettive esclusivamente:

- risposta corretta;
- risposta errata;
- consultazione della soluzione.

Non sono esposizioni effettive:

- visualizzazione della domanda;
- domanda preparata ma non mostrata;
- domanda mostrata senza risposta;
- sessione sospesa prima di una risposta o consultazione;
- semplice avanzamento UI senza esito.

Una non risposta non diventa errore e non modifica il calendario. Un elemento senza esposizioni effettive rimane `neverVerified`.

Gli eventi originali sono immutabili. Una correzione aggiunge un record collegato all'evento; l'annullamento di una correzione è un ulteriore record. La proiezione usa la catena cronologica delle correzioni valide e conserva sempre la possibilità di ricostruire il dato originario.

## 3. Decadimento temporale

Il decadimento è esponenziale continuo con emivita di 60 giorni. Per ogni evento effettivo:

- `ageDays` è la differenza tra `calculationAt` e il timestamp dell'evento, espressa in giorni;
- `temporalWeight` è 2 elevato a `(-ageDays / 60)`.

Esempi di controllo:

| Età evento | Peso temporale atteso |
|---:|---:|
| 0 giorni | 1,000000 |
| 30 giorni | circa 0,707107 |
| 60 giorni | 0,500000 |
| 120 giorni | 0,250000 |
| 180 giorni | 0,125000 |

Il decadimento influenza esclusivamente i calcoli adattivi. Non cancella eventi, non riduce i conteggi cumulativi mostrati all'utente e non modifica i risultati storici.

Tutti i calcoli di una singola proiezione devono usare lo stesso `calculationAt` (tempo di riferimento congelato), per evitare risultati incoerenti durante l'elaborazione.

## 4. Esposizioni equivalenti e affidabilità

`effectiveExposureCount` è il numero cumulativo di eventi effettivi validi, senza decadimento. `equivalentExposures` è la somma dei pesi temporali degli eventi effettivi validi.

L'affidabilità individuale prudenziale è:

`reliability = equivalentExposures / (equivalentExposures + 5)`

L'affidabilità è un numero compreso tra 0 e 1. Cinque esposizioni equivalenti corrispondono ad affidabilità 0,5; non sono una soglia minima per classificare l'elemento.

Gli eventi corretti da una rettifica valida sono esclusi dalla proiezione effettiva secondo la semantica della correzione, ma restano nello storico append-only. Una correzione non può essere applicata due volte; l'operazione è idempotente tramite `operationId`.

## 5. Fattori di debolezza

L'indice grezzo è una media ponderata dei fattori disponibili. I pesi definiti dalla specifica sono:

| Fattore | Peso nominale |
|---|---:|
| Errori | 40% |
| Consultazioni | 25% |
| Ritardi delle verifiche | 20% |
| Mancato consolidamento | 15% |

I fattori sono normalizzati tra 0 e 100. Se un fattore non è disponibile, viene escluso e i pesi dei soli fattori disponibili vengono rinormalizzati in modo che la somma sia 100%. Un fattore disponibile con valore zero non è un fattore mancante.

### 5.1 Fattore errori

Per ogni risposta errata valida si somma il suo `temporalWeight`. Il fattore è la somma dei pesi temporali delle risposte errate divisa per la somma dei pesi temporali di tutte le esposizioni effettive, moltiplicata per 100.

Le risposte corrette contribuiscono al denominatore ma non al numeratore. Le consultazioni non contribuiscono al numeratore degli errori. Se non esistono esposizioni effettive, il fattore non è disponibile e l'elemento resta mai verificato.

### 5.2 Fattore consultazioni

Per ogni consultazione valida si somma `0,5 × temporalWeight`. Il fattore è tale somma divisa per la somma dei pesi temporali di tutte le esposizioni effettive, moltiplicata per 100.

La consultazione ha quindi intensità intrinseca pari al 50% di una risposta errata. Il fattore consultazioni resta distinto dal fattore errori, come richiesto dai quattro pesi nominali.

**Nota matematica importante:** poiché il fattore consultazioni ha peso nominale 25% e il fattore errori 40%, a parità di denominatore una consultazione contribuisce all'indice composito per il 31,25% del contributo di un errore (25% × 0,5 rispetto a 40%). La specifica originaria stabilisce sia pesi distinti sia intensità 50%; non è possibile ottenere contemporaneamente un rapporto complessivo esatto di 50% senza cambiare uno dei due parametri. Questa v1.0 conserva entrambi i parametri espliciti e rende visibile l'effetto. La decisione potrà essere rivista prima dell'implementazione, ma non va corretta implicitamente.

### 5.3 Fattore ritardi

Per ogni elemento con `nextReviewAt` valorizzato, il ritardo è il numero di giorni trascorsi oltre la data prevista, con minimo zero. La penalizzazione individuale è:

- 0% se non è scaduto;
- crescita lineare fino al 100% nei 30 giorni successivi alla scadenza;
- 100% dal trentesimo giorno di ritardo in avanti.

Il fattore individuale è quindi `min(100, max(0, overdueDays / 30 × 100))`.

Per l'indice del singolo sotto-quesito si usa il suo valore. Nelle aggregazioni di categoria si considerano soltanto gli elementi con data di verifica pianificata. Gli elementi senza `nextReviewAt` sono esclusi sia dal numeratore sia dal denominatore di questo fattore.

Il tempo di riferimento è `calculationAt`, non l'ora di lettura della UI.

### 5.4 Fattore mancato consolidamento

Il fattore è fornito dal componente di pianificazione/consolidamento già responsabile della progressione degli intervalli. `InterrogationKnowledge` non introduce un secondo algoritmo autonomo e non ricava il fattore dal solo numero di successi.

Contratto richiesto al pianificatore: `consolidationWeakness` numerico tra 0 e 100, più `consolidationPolicyVersion` e `calculatedAt`. Il valore deve tenere conto della storia di risposte, intervalli, errori e consultazioni. Se il pianificatore non fornisce un valore valido, il fattore è assente e i pesi disponibili vengono rinormalizzati.

## 6. Indice grezzo, prudenza e classificazione

`rawWeaknessIndex` è la media dei fattori disponibili ponderata con i rispettivi pesi nominali rinormalizzati.

`correctedWeaknessIndex` avvicina l'indice grezzo al valore neutro 50 in funzione dell'affidabilità:

`correctedWeaknessIndex = 50 + reliability × (rawWeaknessIndex - 50)`

Il risultato viene limitato all'intervallo 0–100 e arrotondato solo per la visualizzazione; i calcoli e le classificazioni usano il valore non arrotondato.

Classificazione:

| Indice corretto | Classe |
|---:|---|
| da 70 incluso a 100 | `weak` — Debole |
| da 30 incluso a meno di 70 | `review` — Da ripassare |
| da 0 a meno di 30 | `consolidated` — Consolidato |

Un elemento senza esposizioni effettive è `neverVerified`: non riceve indice composito né classe derivata. Un elemento verificato ma privo di tutti i fattori utilizzabili non deve essere classificato artificialmente; restituisce `insufficientData` e viene segnalato per diagnostica. Non va confuso con `neverVerified`.

Il ricalcolo avviene dopo ogni sotto-quesito valutato o consultato e dopo ogni correzione valida. La nuova proiezione influenza soltanto sessioni create successivamente. Una sessione già iniziata o sospesa conserva lo snapshot originale.

## 7. Priorità dedicate

### 7.1 Mai verificati

Gli elementi senza esposizioni effettive sono esclusi dalle medie di debolezza e hanno lo strato `neverVerified`. La priorità non crea posti aggiuntivi e non può violare quote o disponibilità.

### 7.2 Consultazioni pendenti

Una consultazione crea una priorità temporanea per la successiva sessione adattiva della stessa tipologia. La priorità:

- è associata al `questionSemanticId` e alla tipologia;
- non modifica indice, classe o quota;
- non vale per selezione casuale o manuale;
- viene consumata soltanto quando l'elemento è effettivamente incluso in una sessione adattiva ammissibile;
- resta pendente se il candidato non viene selezionato o se la sessione viene annullata prima della creazione;
- non si duplica se la stessa operazione viene ritentata.

Se una consultazione è successivamente rettificata o annullata, la proiezione delle priorità deve seguire la correzione append-only: la priorità è rimossa solo se la correzione dichiara esplicitamente non valido l'evento di consultazione.

## 8. Calendario di consolidamento

Intervalli configurabili, ordinati per livello:

`[1, 3, 7, 14, 30, 60]` giorni.

La seguente policy è la formalizzazione tecnica proposta per la prima implementazione e deve essere confrontata con eventuali comportamenti preesistenti prima di essere attivata:

| Esito | Transizione livello |
|---|---|
| Corretta | avanza di un livello, massimo 60 giorni |
| Errata | torna al livello minimo, 1 giorno |
| Consultata | retrocede di un livello, minimo 1 giorno |
| Non risposta | nessuna modifica al livello o alla data pianificata |

Dopo una risposta corretta, errata o consultata, `nextReviewAt` è calcolata aggiungendo l'intervallo del nuovo livello al timestamp dell'esito. Per la non risposta non si crea esposizione e non si riscrive la pianificazione.

L'indice del livello è compreso tra 0 e 5. La configurazione degli intervalli è versionata. Se l'utente modifica gli intervalli, il sistema deve chiedere se ricalcolare le date già pianificate; se sceglie di non ricalcolarle, i timestamp esistenti restano invariati e i nuovi esiti usano la nuova configurazione.

La policy non richiede un numero fisso di successi consecutivi. Il fattore mancato consolidamento continua a essere prodotto dal pianificatore, che deve considerare storia delle risposte, intervalli, errori e consultazioni.

## 9. Metriche di categoria

Per ciascuna categoria si calcolano separatamente:

- `eligibleCount`: numero di sotto-quesiti attivi e selezionabili;
- `verifiedCount`: numero di sotto-quesiti con almeno un'esposizione effettiva valida;
- `coverage = verifiedCount / eligibleCount`, se `eligibleCount > 0`;
- `meanReliability`: media aritmetica delle affidabilità individuali dei soli elementi verificati;
- `categoryReliability = meanReliability × coverage`;
- `categoryWeakness`: media degli indici corretti degli elementi verificati, ponderata per affidabilità individuale.

Per `categoryWeakness`, gli elementi con affidabilità zero non contribuiscono al numeratore né al denominatore della media ponderata. Se la somma dei pesi è zero, il valore è non disponibile. Gli elementi mai verificati non entrano nella media di debolezza.

Se `eligibleCount` è zero, la categoria è esclusa dalla selezione. Se non esistono elementi verificati, `verifiedCount = 0`, `coverage = 0`, `categoryReliability = 0` e `categoryWeakness` è non disponibile.

Le categorie non mescolano dati di tipologie differenti. Il selettore riceve le metriche già calcolate e non le ricostruisce.

## 10. Snapshot, versioni e coerenza

Ogni proiezione deve includere almeno:

```js
{
  profileId,
  questionSemanticId,
  questionType,
  calculationAt,
  sourceEventVersion,
  correctionProjectionVersion,
  catalogVersion,
  knowledgeAlgorithmVersion: "knowledge-1.0",
  consolidationPolicyVersion,
  effectiveExposureCount,
  equivalentExposures,
  reliability,
  factorValues: {
    errors: null,
    consultations: null,
    delays: null,
    consolidation: null
  },
  rawWeaknessIndex: null,
  correctedWeaknessIndex: null,
  classification: "neverVerified | weak | review | consolidated | insufficientData",
  reviewLevel,
  reviewIntervalDays,
  nextReviewAt,
  pendingConsultationPriority
}
```

I valori `null` sono espliciti e significano dato non disponibile; non vanno convertiti in zero. Tutti i record di una stessa ricostruzione usano la stessa versione dello storico e delle correzioni.

Il motore di selezione deve ricevere una proiezione coerente e congelarla nello snapshot della sessione. Il ricalcolo successivo non può cambiare le domande, le quote o le classificazioni già congelate.

## 11. Persistenza e atomicità

La registrazione di un esito e l'aggiornamento della conoscenza devono avvenire nella stessa transazione IndexedDB prevista dai contratti backend: evento immutabile, eventuale receipt idempotente, aggiornamento proiezione, calendario e priorità.

Regole:

- `operationId` identico e payload identico: restituisce il risultato già registrato;
- `operationId` identico e payload differente: conflitto;
- nuova operazione: nuovo evento;
- errore prima del commit: nessun aggiornamento parziale;
- correzione: nuova registrazione append-only e ricostruzione della proiezione interessata;
- cancellazione profilo: isolamento rigoroso per `profileId`, secondo la policy di conservazione concordata.

La proiezione `knowledgeStates` è una cache derivata ricostruibile. Gli eventi e le correzioni restano la fonte di verità.

## 12. API logiche proposte

Le firme sono contratti logici, da adattare allo stile dei file JavaScript classici esistenti senza introdurre moduli ES o nuove dipendenze:

- `rebuildQuestionKnowledge(profileId, questionSemanticId, calculationAt)`
- `rebuildProfileKnowledge(profileId, questionType, calculationAt)`
- `applyOutcomeToReviewSchedule(currentSchedule, outcome, evaluatedAt, policy)`
- `calculateCategoryKnowledge(profileId, categoryId, questionSemanticIds, calculationAt)`
- `getKnowledgeSnapshot(profileId, questionType, calculationAt)`
- `rebuildAfterCorrection(profileId, eventId, correctionId, calculationAt)`

Le funzioni di calcolo pure non eseguono I/O. Il repository coordina lettura, transazione e persistenza.

## 13. Casi limite e gestione errori

| Caso | Comportamento richiesto |
|---|---|
| Nessuna esposizione | `neverVerified`; nessun indice |
| Solo visualizzazioni | `neverVerified` |
| Solo risposte corrette | affidabilità calcolata; errore e consultazioni pari a zero; fattori mancanti gestiti esplicitamente |
| Solo consultazioni | esposizioni equivalenti valorizzate; priorità pendente; consultazioni con intensità 0,5 |
| Tutte le esposizioni molto vecchie | affidabilità ridotta dal decadimento; storico cumulativo intatto |
| Fattore consolidamento assente | peso 15% escluso e pesi disponibili rinormalizzati |
| Nessuna data di verifica | fattore ritardi non disponibile |
| Correzione duplicata | nessun doppio effetto |
| Correzione annullata | proiezione ricostruita secondo la sequenza append-only |
| Elemento dismesso | storico conservato; escluso da nuove selezioni |
| Sostituzione semantica | nessun trasferimento di conoscenza |
| Sessione sospesa | snapshot originario invariato |
| Timestamp futuro o non valido | errore di validazione; nessuna scrittura parziale |

## 14. Test di accettazione

Il file `Motore_Conoscenza_Interrogazione_test_vectors_v1.0.json` contiene casi numerici riproducibili. La suite automatica deve inoltre verificare:

1. emivita: peso dimezzato a 60 giorni e ridotto a un quarto a 120;
2. decadimento applicato solo alle metriche adattive;
3. esposizioni equivalenti includono corrette, errate e consultazioni;
4. visualizzazioni e non risposte non aumentano esposizioni equivalenti;
5. affidabilità con 0, 5 e 10 esposizioni equivalenti;
6. fattore errori e fattore consultazioni separati;
7. consultazione con intensità 0,5;
8. rinormalizzazione dei pesi in caso di fattore assente;
9. soglie esatte 30 e 70;
10. `neverVerified` escluso dall'indice;
11. `insufficientData` distinto da `neverVerified`;
12. ritardo 0, 7, 15, 30 e oltre 30 giorni;
13. categoria senza elementi verificati;
14. copertura e affidabilità categoria;
15. transizioni calendario corretto/errato/consultato/non risposta;
16. intervalli limitati a 1, 3, 7, 14, 30, 60;
17. consultazione pendente consumata una sola volta e solo nella tipologia corretta;
18. correzione e annullamento append-only;
19. idempotenza e conflitto `operationId`;
20. snapshot sessione stabile dopo ricalcolo;
21. nessuna contaminazione tra profili;
22. ricostruzione deterministica a parità di storico e `calculationAt`.

## 15. Questioni da non occultare prima dell'implementazione

1. **Rapporto effettivo consultazione/errore:** la specifica assegna pesi distinti 25% e 40% e contemporaneamente intensità 50%. La presente formalizzazione conserva entrambi, con contributo composito relativo del 31,25%. Se l'intento fosse che una consultazione pesi esattamente la metà di un errore sull'indice finale, occorrerebbe modificare un parametro.
2. **Fattore consolidamento:** il contratto è definito, ma la formula deve provenire dal pianificatore esistente o da una decisione tecnica separata; non è corretto inventare un secondo indicatore.
3. **Calendario:** le transizioni sono formalizzate come proposta tecnica già presente nella specifica, ma vanno confrontate con l'eventuale pianificazione esistente prima di attivarle.
4. **Aggregazione dei ritardi di categoria:** l'aggregazione deve essere ponderata sui soli elementi pianificati; gli elementi senza data restano esclusi. L'implementazione deve fissare una regola stabile di ponderazione temporale e versionarla.

## 16. Sequenza implementativa raccomandata

1. Implementare funzioni pure per decadimento, affidabilità, fattori e classificazione.
2. Aggiungere test unitari per tutti i vettori numerici.
3. Implementare il calcolo categoria.
4. Implementare calendario e priorità consultazione.
5. Integrare la ricostruzione transazionale nel repository.
6. Collegare lo snapshot al motore di selezione.
7. Eseguire test browser, ripresa sessione e concorrenza tra schede.

**Esito:** specifica esecutiva v1.0 pronta per revisione tecnica e implementazione autorizzata. Nessun sorgente applicativo è stato modificato.
