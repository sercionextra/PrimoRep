# Manuale Utente TenFingersTypingTrainer v6.48

Questa guida integra il manuale della versione 6.47 con l'aggiornamento introdotto nella versione 6.48.

## 1. Indicazione dell'esercizio di origine in "Random This Phrase"
Quando completi un esercizio in modalità **Random This Phrase** e apri la finestra **Statistiche**, passando il mouse sui punti del grafico corrispondenti alla categoria **Random Phrase** viene ora indicato anche l'esercizio o la modalità da cui la frase è stata ricavata, ad esempio:
- `Random This Phrase (Lezione 3: ...)`
- `Random This Phrase (Custom 1: ...)`
- `Random This Phrase (Digitazione Libera)`
- `Random This Phrase (Fonemi Italiani)`
