/* Reusable interactive quiz widget with immediate feedback */
(function () {
  function initQuizzes() {
    const questions = document.querySelectorAll('.quiz-question');
    questions.forEach((q) => {
      const options = q.querySelectorAll('.quiz-option');
      const feedback = q.querySelector('.quiz-feedback');
      options.forEach((btn) => {
        btn.addEventListener('click', () => {
          const isCorrect = btn.dataset.correct === 'true';
          options.forEach((o) => {
            o.disabled = true;
            if (o.dataset.correct === 'true') {
              o.classList.add('is-correct');
            }
          });
          if (!isCorrect) {
            btn.classList.add('is-wrong');
          }
          if (feedback) {
            feedback.textContent = isCorrect
              ? (btn.dataset.feedback || 'Esatto!')
              : (btn.dataset.feedback || 'Non proprio: guarda la risposta evidenziata in verde.');
            feedback.className = 'quiz-feedback ' + (isCorrect ? 'is-correct' : 'is-wrong');
          }
        });
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initQuizzes);
  } else {
    initQuizzes();
  }
})();
