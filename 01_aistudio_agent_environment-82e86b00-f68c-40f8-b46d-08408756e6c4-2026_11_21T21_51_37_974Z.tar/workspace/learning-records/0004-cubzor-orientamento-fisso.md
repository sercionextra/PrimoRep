# Vincolo di orientamento su Cubzor: bianco fisso in alto

Su [Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3), lo studente non può capovolgere stabilmente il cubo per tenere la croce bianca in basso (`D`); può tenerla solo in alto (`U`).

- **Evidence**: Segnalazione diretta dello studente durante la Lezione 3.
- **Implications**: Per il Primo Strato usiamo la sequenza `R' D' R D` (invece di `R U R' U'`) mantenendo il bianco in alto. Anche per le lezioni successive sul secondo e terzo strato dovremo adattare le istruzioni all'orientamento usato su Cubzor (lavorando sullo strato `D` oppure adattando la visuale).
