# Architettura — TenFingersTypingTrainer v6.13

## Obiettivo

La release v6.13 introduce la modalità di **Dettatura Adattiva Dinamica**, trasformando il motore vocale da un generatore rigido a soglia fissa in un sistema di assistenza intelligente capace di sincronizzare il proprio ritmo di lettura sulla velocità effettiva dell'allievo (CPM istantaneo e media mobile), gestendo in modo pedagogico la ripresa progressiva del ritmo dopo la correzione degli errori.

---

## Modello Architetturale della Dettatura Adattiva (Release v6.13)

L'architettura estende il modulo `DictationEngine` e lo integra reattivamente con il buffer tachimetrico di `TypingEngine` e il profilo utente, operando secondo quattro pilastri:

### 1. Coefficiente Dinamico di Anticipo (Lookahead Continuo)

Nelle versioni precedenti la soglia di anticipo della parola successiva era rigidamente ancorata al 65% della lunghezza del token (`Math.floor(tokenSpan * 0.65)`).
Nella release v6.13, quando l'opzione `DictationAdaptive` è abilitata, il coefficiente varia in modo continuo tra **1.00** (nessun anticipo a ritmo lento) e **0.65** (anticipo massimo a ritmo veloce):

* **Sotto la Soglia Minima (`minAnticipationCpm`, default 100 CPM):** il coefficiente è pari a 1.00. La parola successiva viene annunciata esattamente al digitare dell'ultimo carattere del token corrente, consentendo a chi scrive piano di non sentirsi incalzato dalla voce.
* **Sopra la Soglia Massima (`maxAnticipationCpm`, default 200 CPM):** il coefficiente scende a 0.65, garantendo il pieno anticipo predittivo per chi digita velocemente.
* **Nella Fascia Intermedia (tra 100 e 200 CPM):** il coefficiente viene calcolato per interpolazione lineare continua:
  `baseCoeff = 1.00 - ((cpm - minCpm) / (maxCpm - minCpm)) * (1.00 - 0.65)`

### 2. Protocollo di Recupero e Rampa di Accelerazione Post-Errore

Quando l'allievo commette un errore e si ferma per correggerlo, la velocità istantanea subisce una naturale flessione. Per prevenire ripartenze disorientanti, l'algoritmo adotta una ripresa graduale a due livelli:

1. **Al 1° Errore Corretto sulla Parola:**
   * Non appena gli errori tornano a zero con Backspace, il motore pronuncia il troncone residuo mancante come blocco fonetico continuo (Opzione B, es. "stiera");
   * Il ritmo viene reimpostato a passo prudente azzerando `recoveryStreak` e forzando il coefficiente a 1.00;
   * Nelle prime 4 battute corrette consecutive (`recoveryStreak`), il coefficiente transita gradualmente da 1.00 al valore nominale di velocità, ripristinando l'accelerazione in modo fluido e naturale.
2. **Al 2° Errore Consecutivo sulla Medesima Parola (`tokenErrorCount >= 2`):**
   * Il sistema rileva la specifica difficoltà dell'allievo sul vocabolo in corso e commuta temporaneamente in modalità **SPELLING**: compita lettera per lettera il solo troncone residuo (es. "s, t, i, e, r, a"), scandendo i singoli caratteri;
   * A parola completata, `tokenErrorCount` e `recoveryStreak` si resettano e la parola successiva riprende con la normale pronuncia continua.

### 3. Gerarchia delle Regole e Precedenze

1. **Spelling Globale attivo (`chkDictationSpelling`):** Prevalenza assoluta (100% compitazione di ogni carattere, scavalcando qualsiasi automatismo lessicale o adattivo).
2. **Modalità Adattiva Disattivata (Default):** Comportamento identico alla release v6.12 (anticipo fisso a 0.65, nessuna rilettura a troncone intero post-errore, nessuno spelling selettivo al secondo errore).
3. **Modalità Adattiva Attivata:** Esecuzione del calcolo dinamico e della rampa post-errore.

---

## Mappa dei componenti

| Componente | Responsabilità |
|---|---|
| `engines/dictation-engine.js` | Calcolo del coefficiente dinamico (1.00 - 0.65), gestione `tokenErrorCount`, `recoveryStreak`, rampa post-errore e compitazione selettiva al secondo errore |
| `engines/typing-engine.js` | Calcolo e fornitura della media mobile di velocità istantanea in CPM tramite `getCurrentMovingAvgBpm()` |
| `app/controller/metodi-dettatura.js` | Apertura e gestione della finestra modale `#dictationConfigModal`, binding slider/input e salvataggio nel profilo |
| `app/controller/metodi-input-digitazione.js` | Passaggio di `currentCpm` ad ogni battuta verso `dictation.updateProgress()` |
| `app/controller/metodi-avvio-temi-audio.js` | Registrazione di `currentCpm` nello `stateProvider` di dettatura all'avvio |
| `app/controller/metodi-profili-modali.js` | Ripristino al login delle impostazioni `DictationAdaptive`, `DictationMinCpm`, `DictationMaxCpm` |
| `profiles/profile-manager.js` | Normalizzazione difensiva e persistenza delle impostazioni di dettatura adattiva nel profilo utente |
| `app/controller/controller-core.js` | Costruttore del controller applicativo (versione runtime v6.13) |
| `index.html` | Markup del pulsante `⚙ Dettatura` e della modale `#dictationConfigModal` |
| `tests/test-dictation-adaptive.js` | Test suite automatica a 14 asserzioni per la validazione della logica adattiva |
