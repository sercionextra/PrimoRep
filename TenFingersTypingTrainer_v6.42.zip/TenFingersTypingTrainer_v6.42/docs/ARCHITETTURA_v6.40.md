# Architettura TenFingersTypingTrainer v6.40

Documento di aggiornamento architetturale rispetto alla v6.39.

## 1. Obiettivo della Release v6.40
Estendere la vista **Mostra storico** (`#interrogationView_history`) della finestra Interrogazioni con un secondo grafico (**Classifica Urgenza Interrogazione per Tasti e Dita**), navigabile tramite gli stessi pulsanti e meccanismi di scorrimento adottati dalla finestra **Statistiche**.

## 2. Motore Puro di Classifica Urgenza (`js/interrogation/interrogation-knowledge.js`)
Aggiunti `URGENCY_WEIGHTS` e `computeUrgencyRanking(options)`:
- **Entità aggregate:**
  - **Tasti/Caratteri** (`entityType: "key"`): raggruppamento dei quesiti `CARATTERE` e `TASTO` per `keyId` fisico.
  - **10 Dita** (`entityType: "finger"`): raggruppamento dei quesiti `DITO` e `HOME_ROW` per `fingerId` (D1..D10).
- **Modello a 5 motivazioni normalizzate (scala totale 0–125):**
  1. `error` (peso 0.40, max 40 pt): tasso di errori pesato nel tempo sugli eventi dell'entità.
  2. `consultation` (peso 0.25, max 25 pt): tasso di consultazioni/aiuti pesato nel tempo.
  3. `delay` (peso 0.20, max 20 pt): media del fattore di ritardo rispetto alla scadenza del calendario 1/3/7/14/30/60 giorni.
  4. `consolidation` (peso 0.15, max 15 pt): media del mancato consolidamento rispetto al livello massimo 5.
  5. `underinvestigated` (peso 0.25, max 25 pt): `(1 - reliability) * 25`, derivato dalle esposizioni equivalenti dell'entità.
- **Isolamento:** il calcolo legge esclusivamente lo stato globale attuale del profilo (`events` + `corrections` a `Date.now()`), risultando indipendente dai filtri temporali e dalle metriche del Grafico 1.
- **Ordinamento:** decrescente per punteggio totale sui soli motivi attivi, a parità di punteggio priorità alle Dita poi ordine alfabetico.

## 3. UI e Navigazione (`index.html`, `assets/styles/app.css`, `js/ui/interrogation-ui.js`)
- **Switcher nell'header (`#interrHistoryNavGroup`):** pulsanti `#btnInterrHistNavChrono` (`📈 1. Storico`) e `#btnInterrHistNavUrgency` (`📊 2. Urgenza`), visibili solo quando la vista attiva è `history`.
- **Sezioni scroll-snap (`#interrHistorySection1`, `#interrHistorySection2`):** scorrimento fluido tramite `scrollIntoView({ behavior: "smooth", block: "start" })` e sincronizzazione dello stato `active` su scroll manuale, replicando il pattern di `statsFloatingWindow`.
- **Istogramma impilato SVG (`#interrUrgencyChartHost`):**
  - 5 checkbox (`.interr-urgency-reason-chk`) per includere/escludere dinamicamente ciascuna motivazione.
  - Filtro entità (`Tutti`, `Solo Tasti`, `Solo Dita`).
  - Larghezza minima per barra con scroll orizzontale automatico.
  - Hover sulla barra: aggiornamento di `#interrUrgencyDetailBox` con i 5 contributi, numero di verifiche e quesiti associati.
  - Click sulla barra: verifica di eventuale sessione sospesa e richiesta di conferma tramite `showConfirm()` per avviare immediatamente una sessione manuale mirata sui `candidateIds` dell'entità selezionata.
