# Architettura TenFingersTypingTrainer v6.33

## Panoramica delle modifiche rispetto alla v6.32

1. **Risoluzione bug ridimensionamento `#interrogationDialog` (`assets/styles/app.css`):**
   - Impostato `position: fixed; margin: 0;` su `.interrogation-dialog-wide` al posto di `position: relative;`. In precedenza, essendo figlio diretto di `#interrogationModal` (`.modal-overlay` flex-centrato), le coordinate `left`/`top` scritte da `WindowManager.makeResizable()` venivano sommate come offset relativi al centro flex, causando uno spostamento progressivo verso il basso a ogni tentativo di resize.
   - Aggiunta la classe `.interrogation-dialog-wide.window-fullscreen` (`z-index: 2005 !important`, `inset: 0 !important`) e `cursor: move; user-select: none;` su `#interrogationWindowHeader`.

2. **Controlli finestra e persistenza geometria (`index.html`, `js/app/controller/metodi-interrogazione.js`):**
   - Aggiunto `id="interrogationWindowHeader"` e i pulsanti `#btnInterrogationResetLayout` (`↺ Ripristina`) e `#btnInterrogationMaximize` (`⛶ Ingrandisci` / `🗗 Riduci`).
   - Collegato `windowMgr.makeDraggable(dialog, header, ...)` e `windowMgr.makeResizable(dialog, ...)` con salvataggio di `InterrLeft`, `InterrTop`, `InterrWidth`, `InterrHeight` nel profilo utente e ripristino in `openInterrogationModal()`.
   - Implementato `resetInterrogationWindowLayout(saveToProfile)` e ripristino di `document.body.style.overflow = ""` alla chiusura in `onClose`.

3. **Integrazione in `resetAllWindowLayouts()` (`metodi-finestre-layout.js`, `metodi-profili-modali.js`):**
   - Aggiunta la chiamata a `this.resetInterrogationWindowLayout(false)` prima di `saveProfile()` in entrambi i file, così il pulsante **Reset finestre** di Gestione Utenti ripristina anche la finestra Interrogazione.
