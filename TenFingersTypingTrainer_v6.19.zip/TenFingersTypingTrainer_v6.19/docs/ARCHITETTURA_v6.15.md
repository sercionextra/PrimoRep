# Architettura — TenFingersTypingTrainer v6.15

## Obiettivo

La release v6.15 evolve l'architettura temporale del motore vocale `DictationEngine`, ottimizzando i tempi di reazione all'esitazione dell'allievo: il contatore di inattività interviene dopo 1 secondo calcolato al termine della pronuncia dell'ultima parola o lettera dettata, eliminando tempi morti; introduce l'Auto-Replay Ultra-Sintetico privo di preamboli (Ipotesi A), la cadenza progressiva a 3 tentativi con transizione a 3 secondi, il Promemoria di Correzione Cadenzato (Opzione B) e l'ancoraggio affidabile del token d'errore alla posizione fisica del cursore.

---

## Modello Temporale e Didattico della Dettatura (Release v6.15)

### 1. Riavvio Dinamico del Contatore di Attesa al Termine della Pronuncia (`utter.onend`)
Nelle versioni precedenti, il timer di sosta veniva avviato al momento della pressione del tasto (`updateProgress`), potendo scadere mentre la sintesi vocale stava ancora terminando la lettura.
Nella release v6.15:
* Ogni volta che un'emissione audio ha inizio, qualsiasi timer di stallo pendente viene revocato (`clearStallTimer()`).
* Il contatore di inattività viene riarmato unicamente all'evento naturale di conclusione della voce (`utter.onend`), garantendo che il tempo di attesa concesso all'allievo decorra esattamente dal momento in cui l'audio è terminato.
* Se l'allievo digita un carattere mentre la voce non è occupata, il timer viene armato immediatamente per l'intervallo corrente (1000 ms).

### 2. Cadenza a 3 Ripetizioni e Transizione a 3 Secondi
Per conciliare la tempestività dell'aiuto didattico con il rispetto dei tempi cognitivi dell'allievo:
* **Primi 3 tentativi consecutivi**: l'intervallo tra le ripetizioni è di 1 secondo (1000 ms).
* **Dal 4° tentativo in poi**: se l'allievo rimane ancora fermo, l'intervallo si estende a 3 secondi (3000 ms) tra un tentativo e il successivo, prevenendo ansia da prestazione e saturazione acustica.
* **Ripristino istantaneo**: non appena l'allievo preme un tasto qualsiasi (corretto o errato) oppure preme Backspace, la proprietà `stallRepetitionCount` viene azzerata istantaneamente e il tempo di attesa si reimposta immediatamente a 1 secondo (1000 ms).

### 3. Auto-Replay Ultra-Sintetico — Ipotesi A
Viene eliminato qualsiasi preambolo verbale prolisso (come "completa digitando..."). L'intervento di supporto dell'Auto-Replay scandisce unicamente l'unità minima attesa per guidare la mano dell'allievo:
1. **A inizio parola** (cursore all'indice iniziale del token): pronuncia direttamente e senza prefissi la parola intera (`token.spokenText`);
2. **A metà parola** (vocabolo parzialmente digitato): pronuncia unicamente il troncone residuo continuo non ancora digitato come blocco fonetico continuo (ad esempio, per la parola "tastiera" con "ta" già digitato, pronuncia direttamente "stiera");
3. **In modalità Spelling** (globale o guidata al secondo errore consecutivo sulla parola): pronuncia unicamente il nome fonetico della singola lettera attesa (ad esempio "esse").

### 4. Promemoria di Correzione Cadenzato — Opzione B
Quando l'allievo commette uno o più errori di digitazione (`typedLen > matchLen`), il sistema non ripete la parola:
* Il replay scandisce esclusivamente l'avviso di correzione essenziale (ad esempio *"ancora un errore"* o *"ancora due errori"*);
* L'avviso viene ripetuto alla medesima cadenza assistita (1 secondo per le prime 3 volte, poi ogni 3 secondi);
* La parola o il relativo troncone vengono nuovamente pronunciati solo dopo che tutti gli errori sono stati ripuliti con la pressione di Backspace (`remainingErrors === 0`).

### 5. Ancoraggio Fisico del Token d'Errore (`lastMatchLen`)
Risolta l'anomalia di sincronizzazione che poteva inibire lo spelling al 2° errore sulla stessa parola:
* In `notifyError()`, il token su cui è avvenuto lo sbaglio viene identificato dinamicamente a partire dalla posizione reale di battuta corretta (`this.lastMatchLen`), non dall'indice lookahead `this.currentIndex` (che durante la digitazione rapida può trovarsi proiettato sul vocabolo futuro);
* Il contatore `tokenErrorCount` viene preservato fedelmente sulla parola in corso: al verificarsi del 2° errore consecutivo, `this.wordSpellingTokenIdx` si attiva in modo deterministico e lo spelling lettera per lettera guida l'allievo fino alla conclusione della parola.

---

## Mappa dei componenti aggiornata

| Componente | Responsabilità v6.15 |
|---|---|
| `engines/dictation-engine.js` | Timer cadenzato 1s/3s con azzeramento immediato alla digitazione, riavvio su `utter.onend`, Auto-Replay ultra-sintetico (Ipotesi A), Promemoria correzione (Opzione B) e ancoraggio fisico token in `notifyError()` |
| `app/controller/controller-core.js` | Versione applicativa runtime aggiornata a v6.15 (`window.APP_VERSION = "6.15"`) |
| `profiles/profile-manager.js` | Profilo utente e serializzazione persistente aggiornati ad `AppVersion = "6.15"` |
| `index.html` | Intestazione, badge di versione e commenti allineati a v6.15 |
| `help.html` | Note di rilascio v6.15, documentazione didattica della cadenza vocale, indice e badge aggiornati |
| `docs/MANUALE_UTENTE_v6.15.md` | Manuale didattico completo per l'utente allineato alla release v6.15 |
| `tests/test-dictation-adaptive.js` | Test suite con verifica cadenza 1s/3s, azzeramento su digitazione, Ipotesi A, Opzione B e trigger su `utter.onend` |
| `tests/runtime-smoke.js` | Verifica fumo runtime allineata alla versione 6.15 |
| `tests/static-check.js` | Validazione statica allineata alla versione 6.15 |
