# Manuale Utente TenFingersTypingTrainer v6.44 (Interrogazione su Piano di Studio, Storico e Classifica Urgenza)

Questa guida descrive le funzioni disponibili nella finestra **🎓 Interrogazione** e nella vista **📈 Mostra storico** dalla versione 6.44.

## 0. Interrogazione su Piano di Studio (Modalità Predefinita)
Quando apri **🎓 Interrogazione**, la prima opzione selezionata automaticamente è **Piano di Studio (solo lezioni seguite)**, pensata appositamente per chi sta ancora seguendo il corso:
- **Domande coerenti con il tuo livello:** vengono proposti solo caratteri, tasti fisici, dita e tasti di riposo già introdotti fino alla lezione raggiunta.
- **Livelli e tasti vicini futuri segnalati e non richiesti:** nei quesiti sui caratteri di un tasto e nella sezione *Tasti intorno (Margherita)*, eventuali livelli o tasti confinanti non ancora studiati (ad esempio *Shift*, *AltGr* o tasti di altre righe) compaiono come **"Da studiare (Lez. X)"** (o **"Non in programma"** per tasti di servizio) e non vengono richiesti né penalizzati nel punteggio.
- **Correzione del traguardo salvato:** il programma ricorda la lezione più avanzata raggiunta nel tuo profilo. Se hai aperto per errore o curiosità una lezione futura, scegli la tua lezione effettiva nella tendina **Fino alla lezione** e premi **Imposta come traguardo** per correggere il profilo.
- **Passaggio a Tastiera Completa:** quando hai completato il corso o desideri esercitarti sull'intero layout, seleziona **Tastiera Completa (tutto il layout)** nel menu *Ambito Interrogazione*.
- **Filtro nello Storico:** nella vista **Mostra storico** puoi filtrare le sessioni per ambito (**Tutte**, **Piano di Studio** o **Tastiera Completa**).

## 1. Passare tra i due grafici nello Storico Interrogazioni
Quando apri **📈 Mostra storico** dalla finestra **🎓 Interrogazione**, nella barra del titolo compaiono due pulsanti:
- **📈 1. Storico**: mostra il grafico cronologico delle sessioni completate (andamento punteggi, % rendimento, filtri per data/ora, filtro ambito, eliminazione campioni e ripetizione sessioni).
- **📊 2. Urgenza**: scorre al secondo grafico dedicato alla classifica dei tasti e delle dita che richiedono maggiore attenzione.

Puoi passare da un grafico all'altro cliccando i due pulsanti nella barra del titolo oppure scorrendo verticalmente con la rotellina del mouse.

## 2. Come leggere la Classifica Urgenza (Tasti e Dita)
Il grafico ordina automaticamente tutti i tasti della tastiera e le 10 dita dal **più urgente** (a sinistra) al **meno urgente** (a destra).

Ogni barra è composta da **5 fasce di colore diverso**, la cui altezza indica il peso di ciascuna motivazione:
- **Rosso — Errori (fino a 40 pt)**: errori commessi nelle interrogazioni precedenti.
- **Arancione — Consultazioni (fino a 25 pt)**: ricorso all'aiuto durante la risposta.
- **Viola — Ritardo Ripasso (fino a 20 pt)**: quesiti scaduti rispetto al calendario di ripasso consigliato.
- **Azzurro — Non Consolidato (fino a 15 pt)**: argomenti non ancora portati al livello massimo di padronanza.
- **Grigio — Scarsa Indagine (fino a 25 pt)**: tasti o dita interrogati poche volte o mai verificati.

## 3. Filtrare le motivazioni e gli elementi
- **Caselle delle motivazioni**: puoi spuntare o deselezionare una o più motivazioni per ricalcolare subito le altezze delle barre e l'ordine della classifica in base a ciò che vuoi allenare.
- **Filtro entità**: puoi scegliere se visualizzare **Tutti** (tasti e dita insieme), **Solo Tasti** oppure **Solo Dita**.
