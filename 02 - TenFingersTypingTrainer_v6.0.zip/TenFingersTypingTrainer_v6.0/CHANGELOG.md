# Changelog

## v6.0 — 27/10/2026

- Avviato il refactoring strutturale dei sorgenti in file separati per responsabilità.
- Estratto il CSS dell'interfaccia in un asset dedicato.
- Conservati dataset didattico, motori, interfaccia e persistenza della v5.1 come baseline di equivalenza.
- Allineati titolo, percorsi degli asset e guida HTML alla v6.0.
- Aggiunti documentazione architetturale e checklist di regressione.
- Nessuna migrazione distruttiva dei dati browser introdotta.

Nota: questa release privilegia la compatibilità; la conversione completa a moduli ES/TypeScript richiede una fase ulteriore di estrazione delle dipendenze e test runtime.
