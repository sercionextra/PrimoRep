#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const listeners = {};
const elements = {};

function makeElement(id) {
  return {
    id,
    style: {},
    classList: { add(){}, remove(){}, toggle(){} },
    checked: false,
    value: '',
    appendChild(){},
    setAttribute(){},
    addEventListener(evt, fn) {
      listeners[`${id}:${evt}`] = fn;
    },
    click() {
      if (listeners[`${id}:click`]) listeners[`${id}:click`]({ target: this });
    },
    focus() {}
  };
}

const sandbox = {
  console,
  document: {
    getElementById(id) {
      if (!elements[id]) elements[id] = makeElement(id);
      return elements[id];
    },
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: (name, cb) => { (listeners['document:' + name] ||= []).push(cb); },
    createElement: () => ({ style: {}, classList: { add(){}, remove(){}, toggle(){} }, appendChild(){}, setAttribute(){}, addEventListener(){} }),
    body: { appendChild(){}, classList: { add(){}, remove(){}, toggle(){} } },
    documentElement: { style: { setProperty(){} }, classList: { add(){}, remove(){}, toggle(){} } }
  },
  localStorage: {
    _data: {},
    getItem(k) { return this._data[k] || null; },
    setItem(k, v) { this._data[k] = String(v); },
    removeItem(k) { delete this._data[k]; },
    key(i) { return Object.keys(this._data)[i] || null; },
    get length() { return Object.keys(this._data).length; }
  },
  setTimeout: () => 0,
  clearTimeout: () => {},
  setInterval: () => 0,
  clearInterval: () => {},
  requestAnimationFrame: () => 0,
  cancelAnimationFrame: () => {},
  performance: { now: () => 0 },
  Blob: function(){},
  URL: { createObjectURL: () => '', revokeObjectURL(){} },
  navigator: {},
  alert(){}, confirm(){ return false; }, prompt(){ return null; }
};
sandbox.window = sandbox;
sandbox.window.addEventListener = (name, cb) => { (listeners['window:' + name] ||= []).push(cb); };
sandbox.window.speechSynthesis = null;
sandbox.window.localStorage = sandbox.localStorage;
sandbox.window.navigator = sandbox.navigator;

vm.createContext(sandbox);

const files = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];

for (const f of files) {
  const code = fs.readFileSync(path.join(root, f), 'utf8');
  vm.runInContext(code, sandbox, { filename: f });
}

const testScript = `
(() => {
  const ctrl = new AppController(EMBEDDED_LESSONS, EMBEDDED_DEMO_PROFILE, EMBEDDED_CUSTOM_DEFAULT, EMBEDDED_FONEMI_CORPUS);
  ctrl.profileMgr.init();
  
  // Setup elements needed
  ctrl.setupFonemiEditorButtons();
  
  let lastAlert = null;
  let lastConfirm = null;
  let confirmCallback = null;
  let cancelCallback = null;
  let exerciseStarted = false;
  
  ctrl.showAppAlert = (msg, title) => { lastAlert = { msg, title }; };
  ctrl.showAppConfirm = (msg, title, onOk, onCancel) => {
    lastConfirm = { msg, title };
    confirmCallback = onOk;
    cancelCallback = onCancel;
  };
  ctrl.startExercise = (reset) => { exerciseStarted = true; };
  ctrl.returnFocusToTyping = () => {};

  const p = ctrl.profileMgr.profile;
  const btnDelete = document.getElementById("btnFonemiDelete");
  const chkCustom = document.getElementById("chkFonemiCustomFile");

  // CASO 1: Nessuna fonte custom caricata
  p.FonemiCustomText = "";
  btnDelete.click();
  if (!lastAlert || !lastAlert.title.includes("Elimina Fonte Fonemi")) {
    throw new Error("Caso 1 fallito: alert non mostrato per testo vuoto");
  }

  // CASO 2: Fonte custom presente ma l'utente annulla il confirm
  p.FonemiCustomText = "Corpus personalizzato di prova con più di venti caratteri validi";
  p.FonemiOptions = p.FonemiOptions || {};
  p.FonemiOptions.customFile = true;
  chkCustom.checked = true;
  lastAlert = null;
  lastConfirm = null;

  btnDelete.click();
  if (!lastConfirm || !lastConfirm.title.includes("Elimina Fonte Custom Fonemi")) {
    throw new Error("Caso 2 fallito: modale di conferma non mostrato");
  }
  // Simuliamo Annulla
  cancelCallback();
  if (p.FonemiCustomText === "" || !chkCustom.checked) {
    throw new Error("Caso 2 fallito: i dati sono stati cancellati nonostante l'annullamento!");
  }

  // CASO 3: Fonte custom presente e l'utente conferma
  ctrl.typingEng.mode = 2; // Modalità Fonemi
  exerciseStarted = false;
  btnDelete.click();
  confirmCallback();

  if (p.FonemiCustomText !== "") {
    throw new Error("Caso 3 fallito: FonemiCustomText non azzerato");
  }
  if (p.FonemiOptions.customFile !== false) {
    throw new Error("Caso 3 fallito: FonemiOptions.customFile non impostato a false");
  }
  if (chkCustom.checked !== false) {
    throw new Error("Caso 3 fallito: chkFonemiCustomFile non deselezionato");
  }
  if (!exerciseStarted) {
    throw new Error("Caso 3 fallito: startExercise non invocato per modalità Fonemi");
  }
  if (!lastAlert || !lastAlert.title.includes("Fonte Eliminata")) {
    throw new Error("Caso 3 fallito: alert di conferma avvenuta eliminazione non mostrato");
  }

  return "TUTTI I TEST SUPERATI CON SUCCESSO";
})()
`;

const res = vm.runInContext(testScript, sandbox);
console.log("TEST RESULT:", res);
