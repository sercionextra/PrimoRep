/* TenFingersTypingTrainer v6.22 — test-window-stacking.js
   Test automatizzato per la gestione dello z-index ordinato (stacking dinamico: ultima finestra/modale in primo piano)
   e verifica dell'uniformità dei pulsanti e delle classi CSS. */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const windowMgrSource = fs.readFileSync(path.join(root, 'js/ui/window-manager.js'), 'utf8');
const indexHtml = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const appCss = fs.readFileSync(path.join(root, 'assets/styles/app.css'), 'utf8');

let totalTests = 0;
let passedTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    console.log(`  [PASS] ${message}`);
    passedTests++;
  } else {
    console.error(`  [FAIL] ${message}`);
    process.exitCode = 1;
  }
}

console.log("=== TEST SUITE: Window Manager Stacking & UI Alignment (v6.22) ===");

// 1. Test WindowManager Stacking Logic in mock DOM
class MockElement {
  constructor(id, tagName = 'div') {
    this.id = id;
    this.tagName = tagName;
    this.style = {};
    this.classList = {
      _classes: new Set(),
      add(c) { this._classes.add(c); },
      remove(c) { this._classes.delete(c); },
      contains(c) { return this._classes.has(c); }
    };
    this._listeners = {};
  }
  addEventListener(evt, fn) {
    if (!this._listeners[evt]) this._listeners[evt] = [];
    this._listeners[evt].push(fn);
  }
  removeEventListener(evt, fn) {
    if (this._listeners[evt]) {
      this._listeners[evt] = this._listeners[evt].filter(f => f !== fn);
    }
  }
  dispatchEvent(evt) {
    const type = typeof evt === 'string' ? evt : evt.type;
    const fns = this._listeners[type] || [];
    fns.forEach(fn => fn(evt));
  }
  querySelector(sel) {
    return new MockElement('mock-' + sel);
  }
  querySelectorAll(sel) {
    return [];
  }
  getBoundingClientRect() {
    return { left: 50, top: 50, width: 300, height: 200, right: 350, bottom: 250 };
  }
}

const mockDocument = {
  getElementById: (id) => new MockElement(id),
  querySelector: (sel) => new MockElement(sel),
  querySelectorAll: (sel) => [],
  addEventListener: () => {},
  removeEventListener: () => {},
  documentElement: { clientWidth: 1200, clientHeight: 800 },
  body: new MockElement('body')
};

const mockWindow = {
  innerWidth: 1200,
  innerHeight: 800,
  addEventListener: () => {},
  removeEventListener: () => {}
};

const context = {
  document: mockDocument,
  window: mockWindow,
  console: console
};
vm.createContext(context);
vm.runInContext(windowMgrSource + '\nthis.WindowManager = WindowManager;\n', context);

const WindowManagerClass = context.WindowManager;
assert(typeof WindowManagerClass === 'function', "WindowManager class successfully defined");

const wm = new WindowManagerClass();
assert(typeof wm.bringToFront === 'function', "wm.bringToFront exists");
assert(typeof wm.bringModalToFront === 'function', "wm.bringModalToFront exists");

// Test floating windows z-index stacking
const win1 = new MockElement('handsFloatingWindow');
const win2 = new MockElement('statsWindow');
const win3 = new MockElement('instantSpeedFloatingWindow');

wm.bringToFront(win1);
const z1 = parseInt(win1.style.zIndex, 10);
assert(z1 >= 1001, `win1 brought to front, zIndex: ${z1} >= 1001`);

wm.bringToFront(win2);
const z2 = parseInt(win2.style.zIndex, 10);
assert(z2 > z1, `win2 brought to front, zIndex: ${z2} > win1 zIndex (${z1})`);

wm.bringToFront(win3);
const z3 = parseInt(win3.style.zIndex, 10);
assert(z3 > z2, `win3 brought to front, zIndex: ${z3} > win2 zIndex (${z2})`);

// Bring win1 back to front
wm.bringToFront(win1);
const z1_new = parseInt(win1.style.zIndex, 10);
assert(z1_new > z3, `win1 brought to front again, zIndex: ${z1_new} > win3 zIndex (${z3})`);

// Test modal stacking
const mod1 = new MockElement('loginModal');
const mod2 = new MockElement('dictationConfigModal');
const mod3 = new MockElement('lessonNavModal');

wm.bringModalToFront(mod1);
const mz1 = parseInt(mod1.style.zIndex, 10);
assert(mz1 >= 2001, `mod1 brought to front, zIndex: ${mz1} >= 2001`);

wm.bringModalToFront(mod2);
const mz2 = parseInt(mod2.style.zIndex, 10);
assert(mz2 > mz1, `mod2 brought to front, zIndex: ${mz2} > mod1 zIndex (${mz1})`);

wm.bringModalToFront(mod3);
const mz3 = parseInt(mod3.style.zIndex, 10);
assert(mz3 > mz2, `mod3 brought to front, zIndex: ${mz3} > mod2 zIndex (${mz2})`);

// Bring mod1 back to front
wm.bringModalToFront(mod1);
const mz1_new = parseInt(mod1.style.zIndex, 10);
assert(mz1_new > mz3, `mod1 brought to front again, zIndex: ${mz1_new} > mod3 zIndex (${mz3})`);

// Modals are strictly above floating windows
assert(mz1_new > z1_new, `Modals band (${mz1_new}) strictly above floating windows band (${z1_new})`);

// 2. Test makeDraggable mousedown brings window to front
const winDrag = new MockElement('draggableTestWindow');
const headerDrag = new MockElement('draggableTestHeader');
wm.makeDraggable(winDrag, headerDrag);

// winDrag should have mousedown registered
assert(Array.isArray(winDrag._listeners['mousedown']) && winDrag._listeners['mousedown'].length > 0,
  "makeDraggable registers mousedown on windowElem to bring to front on click");

// Fire mousedown on winDrag
const prevHighest = wm.highestZIndex;
winDrag.dispatchEvent({ type: 'mousedown' });
assert(parseInt(winDrag.style.zIndex, 10) === prevHighest + 1,
  `Clicking on window increments zIndex to ${prevHighest + 1}`);

// 3. Test index.html buttons highlighting and captions
console.log("=== Checking index.html Buttons & Captions ===");

assert(/<(?:button|a)[^>]*id="btnHeaderSwitchUser"[^>]*class="[^"]*btn-primary[^"]*"/.test(indexHtml),
  'Pulsante "Utenti" (#btnHeaderSwitchUser) has class btn-primary');

assert(/<(?:button|a)[^>]*id="btnHelpLink"[^>]*class="[^"]*btn-primary[^"]*"/.test(indexHtml),
  'Pulsante "Guida (Help)" (#btnHelpLink) has class btn-primary');

assert(/<(?:button|a)[^>]*id="btnDictationConfig"[^>]*class="[^"]*btn-primary[^"]*"/.test(indexHtml),
  'Pulsante "⚙ Config." (#btnDictationConfig) has class btn-primary');

assert(/<(?:button|a)[^>]*id="btnOpenCustomEditor"[^>]*class="[^"]*btn-primary[^"]*"/.test(indexHtml),
  'Pulsante "Editor Custom" (#btnOpenCustomEditor) has class btn-primary');

assert(/<(?:button|a)[^>]*id="btnOpenStats"[^>]*class="[^"]*btn-primary[^"]*"/.test(indexHtml),
  'Pulsante "Statistiche" (#btnOpenStats) has class btn-primary');

assert(/<button[^>]*id="btnDictationConfig"[^>]*>[\s\S]*?⚙ Config\.[\s\S]*?<\/button>/.test(indexHtml),
  'Pulsante caption updated to "⚙ Config."');

assert(/<button[^>]*id="btnDictationConfig"[^>]*title="Configurazione avanzata Dettatura Adattiva Dinamica \(Soglie velocità & ripresa ritmo\)"/.test(indexHtml),
  'Pulsante tooltip preserved as "Configurazione avanzata Dettatura Adattiva Dinamica (Soglie velocità & ripresa ritmo)"');

// 4. Test Close buttons unified classes
console.log("=== Checking Modal Close Buttons Uniformity ===");

assert(/<button[^>]*id="btnCloseDictationConfigModal"[^>]*class="[^"]*floating-window-close[^"]*"/.test(indexHtml),
  'btnCloseDictationConfigModal has floating-window-close class');

assert(/<button[^>]*id="btnCloseLessonNavModal"[^>]*class="[^"]*floating-window-close[^"]*"/.test(indexHtml),
  'btnCloseLessonNavModal has floating-window-close class');

assert(/<button[^>]*id="btnCloseZoomHelpModal"[^>]*class="[^"]*floating-window-close[^"]*"/.test(indexHtml),
  'btnCloseZoomHelpModal has floating-window-close class');

// Check CSS rules for close buttons
assert(/\.floating-window-close[\s\S]*?height:\s*26px;/m.test(appCss),
  'CSS .floating-window-close defines uniform 26px height');

assert(/\.floating-window-close:hover[\s\S]*?background:\s*var\(--error-color\);/m.test(appCss),
  'CSS .floating-window-close:hover defines uniform error/danger hover effect');

console.log(`\nWindow Stacking & UI Tests: ${passedTests}/${totalTests} PASSED`);
if (passedTests !== totalTests) {
  process.exit(1);
}
