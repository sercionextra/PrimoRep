# Checklist di regressione — v6.19

Eseguire in un browser aggiornato e verificare sia il comportamento UI sia la persistenza.

## Avvio e dati

- [ ] L'app si apre direttamente da `index.html` senza errori JavaScript.
- [ ] Il titolo della pagina e l'header mostrano la versione v6.19.
- [ ] La proprietà `app.version` nella console del browser restituisce "6.19".
- [ ] I profili esistenti caricati dal Local Storage restano accessibili e vengono aggiornati alla v6.19 al salvataggio.

## Dettatura a Singola Lettera, Spelling Fluido e Layout a 1610px (Novità v6.19)
- [ ] Verificare che nella dettatura a singola lettera (Modalità 1, 3, 5, 6 e flag Spelling attivo) nessuna lettera venga mai ripetuta due volte alla pressione del tasto corretto.
- [ ] Verificare l'Ipotesi A: se scatta un Replay da inattività e l'utente preme il tasto corretto, il Replay della lettera passata viene interrotto all'istante e parte subito la pronuncia della nuova lettera attesa.
- [ ] Verificare che il timer di stallo a 1 secondo rispetti la battuta dell'utente: se l'allievo digita a ritmo costante, non si verificano mai replay di stallo sovrapposti.
- [ ] Verificare che il layout orizzontale a 1610px mantenga tutti i controlli della Dettatura vocale (Replay, Impostazioni, statistiche) allineati su un'unica riga orizzontale senza andare a capo.
- [ ] Verificare che le combinazioni native di Zoom del browser funzionino sia durante l'esercizio che ad esercizio ultimato:
  - `CTRL+SHIFT++` ingrandisce la visuale a schermo intero.
  - `CTRL+SHIFT+-` riduce la visuale.
  - `CTRL+Numpad+` e `CTRL+Numpad-` (tastierino numerico) funzionano all'istante senza richiedere Shift.
  - `CTRL+0` ripristina la visuale al 100% di default.
  - Nessuna di queste combinazioni subisce `e.preventDefault()` o viene bloccata dalla barriera di completamento esercizio.
- [ ] Verificare che i test automatici specifici (`tests/test-zoom-buttons.js`, TEST 7 e TEST 8) certifichino il superamento dei controlli con esito positivo.

## Auto-Healing e Disaccoppiamento Hardware della Dettatura Vocale (Novità v6.17)
- [ ] Verificare che la dettatura non si interrompa mai silenziosamente durante la digitazione fluida del testo:
  - Il motore vocale è completamente disaccoppiato da stati orfani o congelati del sintetizzatore (`isSpeaking === false` prevale sullo stato asincrono di `speechSynthesis.speaking`).
  - Se il sintetizzatore del browser omette l'evento `onend` o mantiene lo stato `speaking: true`, `speakCurrentToken()` e `resetStallTimer()` eseguono `synth.cancel()` e riavviano regolarmente l'audio e il timer di inattività a 1000 ms.
  - Il buffer lookahead viene scaricato proattivamente all'onend e ad ogni avanzamento di battuta in `updateProgress()`, impedendo che parole rimangano bloccate nella coda.
  - Nessuna necessità di premere Backspace, commettere errori o forzare `CTRL+SHIFT+SPAZIO` per continuare ad ascoltare la dettatura.
- [ ] Verificare che i test automatici specifici (`tests/test-dictation-adaptive.js`) certifichino il superamento dei controlli TEST 11 e TEST 12.

## Cadenza Inattività a 1s/3s e Auto-Replay Ultra-Sintetico (Novità v6.15)
- [ ] Verificare che dopo una pausa di 1 secondo al termine della pronuncia dell'ultima parola o lettera dettata, l'Auto-Replay intervenga automaticamente.
- [ ] Verificare che l'Auto-Replay applichi l'**Ipotesi A (Formula Didattica Ultra-Sintetica)** senza preamboli verbali:
  - Se a inizio vocabolo: pronuncia direttamente la parola intera;
  - Se a metà vocabolo (troncone residuo): pronuncia unicamente il troncone residuo come blocco fonetico continuo (es. "stiera");
  - Se in modalità Spelling (o dopo il 2° errore consecutivo): pronuncia unicamente il nome fonetico della singola lettera attesa (es. "esse").
- [ ] Verificare la cadenza a 3 ripetizioni e rallentamento a 3 secondi: le prime 3 ripetizioni avvengono a intervalli di 1 secondo, dalla 4a ripetizione in poi l'intervallo si allunga a 3 secondi.
- [ ] Verificare che non appena l'allievo preme un tasto qualsiasi o Backspace, il contatore si riazzera e l'intervallo torna istantaneamente a 1 secondo.
- [ ] Verificare che in presenza di errori non corretti (Opzione B), il sistema ripeta cadenzatamente l'avviso di correzione (es. "ancora un errore") senza ripetere la parola finché non si cancella con Backspace.

## Continuità Vocale e Dettatura Adattiva Dinamica (Release v6.14)
- [ ] Verificare che la digitazione di tasti corretti **non interrompa mai** la dettatura vocale in corso (la parola o lettera viene pronunciata per intero).
- [ ] Verificare che se l'allievo digita molto velocemente (> 300 CPM), la parola successiva si accodi armoniosamente senza troncare la parola in corso e senza accumulare ritardo infinito (buffer lookahead Opzione C).
- [ ] Verificare che dopo aver corretto un errore con Backspace, la pronuncia del troncone residuo non venga troncata dalla digitazione dei tasti corretti e che l'anticipo della parola successiva scatti solo alla fine del troncone.
- [ ] Verificare che al 2° errore consecutivo sulla medesima parola, lo spelling lettera per lettera si attivi in modo persistente per l'intera durata della parola, scandendo ciascun carattere a ogni battuta corretta.
- [ ] Verificare che a parola ultimata lo spelling della parola si disattivi e la successiva torni alla normale pronuncia lessicale.
- [ ] Verificare che `synth.cancel()` intervenga solo ed esclusivamente su errore di battuta, backspace, replay o stop sessione.
- [ ] Verificare che nella barra Dettatura sia visibile il pulsante "⚙ Dettatura" (`#btnDictationConfig`) accanto a "🔁 Replay".
- [ ] Cliccando su "⚙ Dettatura", verificare l'apertura della finestra modale `#dictationConfigModal`.
- [ ] Verificare che la modale contenga la casella "Dettatura Adattiva Dinamica" e i controlli per Soglia Minima (40-300 CPM, default 100) e Velocità Anticipo Massimo (100-500 CPM, default 200).
- [ ] Verificare la sincronizzazione bidirezionale tra campi di testo numerici e slider range.
- [ ] Cliccare su "↺ Default (100 CPM, 200 CPM)": verificare che i campi si reimpostino a 100 e 200 con la casella attiva.
- [ ] Chiudere con "Annulla", con il pulsante "x", cliccando sullo sfondo o premendo Escape: verificare la corretta chiusura e la restituzione del focus al campo di digitazione.
- [ ] Con Dettatura Adattiva attiva:
  - Verificare che a velocità bassa (< 100 CPM) la parola successiva sia annunciata solo al completamento della parola corrente;
  - Verificare che a velocità elevata (> 200 CPM) scatti l'anticipo al 65% della parola.
- [ ] Verificare che con la casella globale "Spelling" attiva, la compitazione lettera per lettera prevalga al 100% su qualsiasi altra impostazione.

## Controlli Zoom e Finestra Scorciatoie del Browser (Novità v6.10)
- [ ] Verificare la presenza dei tre pulsanti sulla barra del titolo: "🔍+ Zoom-in", "🔍- Zoom-out" e "🔍 Zoom-in e Zoom-out" (`#btnZoomInfo`).
- [ ] Verificare che il click sul pulsante "🔍 Zoom-in e Zoom-out" apra la finestra modale `#zoomHelpModal`.
- [ ] Verificare che la finestra modale contenga in chiaro le tre scorciatoie native universali del browser:
  - "CTRL+RotellinaMouse"
  - "CTRL+SHIFT++"
  - "CTRL+SHIFT+-"
- [ ] Verificare che la modale si chiuda con il pulsante `&times;`, con il pulsante `OK`, cliccando all'esterno o premendo il tasto `Escape`, restituendo il focus alla battitura.
- [ ] Verificare che il click su "🔍+ Zoom-in" e "🔍- Zoom-out" mostri la notifica temporizzata mini-toast (`showNotificationToast`) con l'indicazione della combinazione nativa, senza forzare modifiche CSS artificiali a `document.body.style.zoom`.
- [ ] Verificare che la pressione fisica delle scorciatoie native del browser (`CTRL+SHIFT++`, `CTRL+SHIFT+-`, `CTRL+RotellinaMouse`) esegua lo zoom nativo senza essere intercettata o bloccata con `preventDefault()`.
- [ ] Verificare che il drag, resize e ancoraggio (Pin) delle finestre flottanti rimangano perfetti senza distorsioni geometriche o derive delle coordinate.

## Metodo e input
- [ ] Verificare le sette modalità: PHRASES, RANDOM, FONEMI, ALL CHARS, TYPING, RANDOM THIS PHRASE, WEAKNESSES.
- [ ] Verificare mappatura dita, posizione di riposo e indicazioni visive.
- [ ] Verificare caratteri accentati, Shift, modificatori e combinazioni.
- [ ] Verificare spazi, Invio (`®`), Tab (`→`), Backspace e correzione progressiva.
- [ ] Verificare auto-correction attiva e disattivata.
- [ ] Verificare avanzamento, ripetizione e completamento frase.

## Voce e feedback
- [ ] Verificare audio feedback e relative opzioni.
- [ ] Verificare dettatura, velocità, voci italiane, maiuscole, apostrofi e spazi.
- [ ] Verificare replay e recupero dopo un errore.
- [ ] Verificare che il watchdog non lasci la dettatura bloccata.

## Finestre e visualizzazione

- [ ] Verificare che digitando una frase con la finestra Velocità Istantanea aperta compaia la curva a punti.
- [ ] Cliccare su ⚙ Parametri, modificare N (es. da 3 a 1 oppure da 3 a 7) e cliccare su Conferma.
- [ ] Verificare che la curva si ricalcoli e si rimodelli immediatamente a video su tutti i caratteri già battuti.
- [ ] Verificare che il tasto "x" e il tasto Escape chiudano regolarmente il modale e restituiscano il focus alla battuta.

## Velocità Istantanea: Ancoraggio Pin e Layout di Default (Novità v6.8)
- [ ] Verificare che nell'header della finestra "Velocità Istantanea" sia presente il pulsante "📍 Pinned" tra "⚙ Parametri" e "↺ Default".
- [ ] Con stato "📍 Pinned" attivo:
  - Nascondere/mostrare il Testo Guida, l'Input o gli Errori: verificare che la finestra trasli verticalmente in modo perfettamente solidale con la scheda di digitazione, mantenendo inalterata la distanza relativa dalla card.
  - Modificare lo zoom della pagina del browser: verificare che la finestra rimanga ancorata alla base della scheda senza distacchi né sovrapposizioni spurie.
- [ ] Cliccare sul pulsante "📍 Pinned": verificare che lo stato si alterni a "📌 Pin" (unpinned), con relativo aggiornamento del tooltip.
- [ ] Con stato "📌 Pin" disattivo:
  - Spostare la finestra e poi nascondere/mostrare elementi della scheda: verificare che la finestra conservi le proprie coordinate libere e non segua il reflow della card.
- [ ] Cliccare su "↺ Default" della finestra Velocità Istantanea:
  - Verificare che la finestra si ridisponga in primo piano sopra la tastiera e la finestra "10 Fingers (Mani)".
  - Verificare che le sue dimensioni coprano l'intera area congiunta di Tastiera e Mani.
  - Verificare che lo stato si reimposti automaticamente su "📍 Pinned".

## Fonemi ed Editor Custom (Novità v6.11)
- [ ] Verificare che nella finestra "Editor Frasi Personalizzate" sia visibile il pulsante "🗑 Elimina" tra "Export Testo di Input per Fonemi" e "Configurazione Fonemi".
- [ ] Verificare che eliminando la fonte custom venga ripristinato il corpus di default senza errori bloccanti.
- [ ] Verificare che nella finestra modale "⚙ Configurazione Fonemi" sia presente il campo "Numero Caratteri per Esercizio" (`#txtFonemiTargetLength`) con valore predefinito 100 e range da 20 a 500.
- [ ] Verificare la presenza del pulsante dedicato "↺ 100" (`#btnFonemiTargetLengthDefault`) a fianco del campo.
- [ ] Cliccare su "↺ 100": verificare che il campo si reimposti a 100 senza modificare N-grammi o probabilità.
- [ ] Cliccare su "↺ Default (N=4, 100 car., 30%)": verificare che anche il campo caratteri torni a 100 insieme a N=4 e tutte le probabilità al 30%.
- [ ] Impostare un valore personalizzato (es. 150): confermare con "Salva" e verificare che, se la modalità attiva è Fonemi, la frase generata rifletta la nuova lunghezza target e il valore rimanga memorizzato nel profilo attivo.

## Statistiche e profili
- [ ] Verificare metriche di sessione, statistiche per carattere e grafico della velocità.
- [ ] Verificare filtri per modalità e intervallo temporale.
- [ ] Verificare selezione e cancellazione dei campioni con "Elimina non selezionati".
- [ ] Verificare creazione, rinomina, cambio ed eliminazione profili.
- [ ] Verificare backup, esportazione e importazione.
- [ ] Verificare Editor Custom, formato titoli/separatori e token `®`/`→`.

## Accettazione finale
- [ ] Nessuna perdita di dati osservata.
- [ ] Nessuna funzione precedente risulta rimossa o alterata.
- [ ] Manuale, guida HTML e applicazione sono coerenti.
