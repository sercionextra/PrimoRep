# Architettura TenFingersTypingTrainer v6.31

## Panoramica delle modifiche rispetto alla v6.30

1. **Toggle selezione manuale e sincronizzazione grafica (`InterrogationUI`, `InterrogationSvgRenderer`):**
   - Aggiunto `InterrogationSvgRenderer.highlightFingersOnHands(fingerIds)` per supportare l'evidenziazione simultanea di più dita sulle sagome anatomiche.
   - Aggiunti `InterrogationUI._syncManualVisualSelection()` e `InterrogationUI._toggleManualCandidate(match)` per gestire il toggle al secondo click su tasti B/N, dita, pallini landmark e tastiera fisica, nonché la rimozione tramite pulsante `✕` sul chip e la sincronizzazione al cambio di `interrogationTypeSelect`.

2. **Modello dati storico sessioni (`InterrogationSessionManager`, `InterrogationRepository`):**
   - `createSession()` calcola `maxScore` in base ai blocchi grafici reali (18 punti per `CARATTERE`/`TASTO`, 3 punti per `DITO`/`HOME_ROW`).
   - `completeSession()` calcola e persiste su `sessions` tramite `_computeSessionStats(items, session)` i campi `maxScore`, `totalBlocks`, `correctCount`, `incorrectCount`, `consultedCount`, `ignoredCount` e `questionTypes`.
   - Aggiunti `getCompletedSessionsWithStats(profileId)` (con ricostruzione in fallback da `sessionItems` per le sessioni pre-v6.31) e `getSessionItemsForRepeat(profileId, sessionId, outcomeFilters)`.
   - `InterrogationRepository.deleteSessions()` rimuove anche i `sessionItems` associati; aggiunto `deleteAllCompletedSessions(profileId)`.

3. **Finestra ridimensionabile e Storico allineato al grafico delle velocità (`InterrogationUI`, `metodi-interrogazione.js`, `index.html`, `app.css`):**
   - Aggiunti gli 8 `.resize-handle` su `#interrogationDialog`, collegati a `windowMgr.makeResizable` in `metodi-interrogazione.js` e a `ResizeObserver` / `window.resize` verso `InterrogationUI.handleResize()`.
   - `#interrogationView_history` allineata a `#statsFloatingWindow`: radio per metriche (`score`, `pct`, `total`, `correct`, `incorrect`, `consulted`, `ignored`), checkbox tipologia (`CARATTERE`, `TASTO`, `DITO`, `HOME_ROW`), 4 input separati Data/Ora con cancellazione singola, `Reset Periodo` e validazione `_parseHistoryDateTimeRange()`.
   - Grafico SVG dinamico con crosshair rosso/azzurro, scrubber timestamp italiano, hover `.inspected` verde, macchina a 3 click per selezione intervallo/singolo punto, azioni `Elimina Selezionati`, `Elimina Non Selezionati`, `Elimina Archivio Storico` con conferma modale, e pannello `🔁 Ripeti interrogazione` su singolo campione.
   - Risolto anche il passaggio di `result.session` in `InterrogationUI.handleComplete()`.
