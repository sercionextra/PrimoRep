# Piano e stato verifiche sicurezza offline — v1.1

**Progetto:** TenFingersTypingTrainer  
**Baseline di partenza:** v6.23  
**Baseline hardening:** v6.24  
**Data:** 09/11/2026  
**Dipendenze esterne introdotte:** 0

## 1. Requisito vincolante

L'applicazione non deve effettuare comunicazioni di rete, inviare dati, telemetria o analytics, né caricare risorse remote. Deve funzionare come applicazione statica locale, apribile da disco. La riservatezza dei dati di digitazione, dei profili e delle statistiche è un requisito di progetto.

## 2. Stato dei gate

| Gate | Verifica | Stato | Evidenza |
|---|---|---|---|
| S0 | Audit statico risorse/API | SUPERATO | Nessun URL remoto, CDN, @import, API di rete o navigazione esterna nel codice applicativo |
| S1 | CSP restrittiva | IMPLEMENTATA, BROWSER TEST PENDENTE | Meta CSP su index/help; nessun `unsafe-inline`/`unsafe-eval`; `connect-src 'none'` |
| S2 | Traffico effettivo browser | PENDENTE | DevTools Network in Edge/Chrome, cache vuota e connettività disabilitata |
| S3 | Guard runtime | SUPERATO IN TEST NODE | 23 tentativi di comunicazione/accesso bloccati e registrati; anchor esterni bloccati |
| S4 | Sintesi vocale locale | SUPERATO IN TEST NODE | Solo voci italiane `localService === true`; nessun fallback remoto/predefinito |
| S5 | DOM injection | SUPERATO IN TEST NODE | htmlEscape verificato; nomi profilo e titoli esercizi inseriti come testo |
| S6 | Regressione Node | SUPERATO | 14/14 suite eseguite con esito positivo |
| S7 | Regressione browser completa | PENDENTE | Checklist manuale v6.24 non ancora eseguita |

## 3. CSP applicata

`index.html` e `help.html` applicano una CSP restrittiva con:

- `default-src 'none'`;
- `connect-src 'none'`;
- script e CSS dalla stessa origine o dallo schema `file:` per l'apertura diretta da disco;
- immagini locali, `file:`, `data:` e `blob:`;
- font locali;
- media, frame, worker, object e manifest negati;
- `script-src-attr 'none'` e `style-src-attr 'none'`;
- `base-uri 'none'` e `form-action 'none'`;
- nessuna deroga `unsafe-inline` o `unsafe-eval`;
- `referrer` impostato a `no-referrer`.

Tutti gli stili inline statici sono stati migrati in CSS locale; gli stili HTML/SVG generati dinamicamente sono stati sostituiti con classi CSS o attributi di presentazione SVG. Gli script e gli stili della guida sono file locali.

La sorgente `file:` è ammessa per compatibilità con l'apertura diretta da disco. Il test statico verifica che i riferimenti effettivi restino risorse relative contenute nella cartella applicativa.

## 4. Guard runtime

`js/security/network-isolation-guard.js` è caricato prima del codice applicativo e blocca, quando disponibili:

- fetch, XMLHttpRequest, WebSocket, EventSource e WebTransport;
- Worker, SharedWorker, WebRTC e BroadcastChannel;
- sendBeacon e registrazione Service Worker;
- accesso a microfono, videocamera, schermo, geolocalizzazione e dispositivi non necessari;
- clipboard API, condivisione di sistema e accesso alle credenziali;
- anchor esterni e `window.open` diverso dalla guida locale `help.html`.

Le violazioni CSP e le invocazioni bloccate sono registrate solo nella memoria del contesto locale. Non vengono memorizzati testo digitato, profili o contenuti delle esercitazioni.

## 5. Sintesi vocale

Il motore accetta esclusivamente voci italiane con `localService === true`. Voci remote o non classificate come locali vengono scartate. Se non è disponibile una voce italiana locale, la sintesi non viene avviata e non viene utilizzata la voce predefinita del browser.

La proprietà `localService` è una dichiarazione del browser: non certifica il comportamento interno del sistema operativo né eventuali download preventivi di pacchetti vocali effettuati dall'utente.

## 6. Test automatici

Dalla directory `TenFingersTypingTrainer_v6.24`:

```bash
node tests/security-static-check.js
node tests/test-network-isolation-guard.js
node tests/test-offline-voice-selection.js
node tests/test-dom-injection-safety.js
node tests/test-build-manifest.js
```

Per la regressione completa, eseguire tutti i file `tests/*.js` e verificare l'esito 14/14.

## 7. Collaudo browser obbligatorio prima della distribuzione

1. Aprire `index.html` direttamente dal disco in Edge e Chrome.
2. Verificare che tutte le risorse JavaScript e CSS locali vengano caricate correttamente.
3. Controllare che gli stili dinamici, le finestre, le statistiche e le interazioni continuino a funzionare con `style-src-attr 'none'`.
4. Svuotare la cache, ricaricare e osservare DevTools Network: nessuna richiesta HTTP/HTTPS, WebSocket, beacon, DNS prefetch o risorsa remota.
5. Eseguire tutte le funzionalità, inclusi profili, import/export, audio, grafici, zoom e Help.
6. Verificare che non si generino violazioni CSP durante il normale funzionamento.
7. Ripetere con connettività di sistema disabilitata.
8. Verificare che, senza voce italiana locale, la sintesi vocale resti silenziosa e le funzioni di digitazione continuino a funzionare.

## 8. Limiti espliciti

- La CSP è inserita tramite meta tag. Non può applicare tutte le direttive disponibili negli header HTTP; in particolare `frame-ancestors` non è applicabile tramite meta CSP.
- CSP e guard runtime proteggono il contesto dell'applicazione, non il browser, le estensioni, il sistema operativo o altri processi.
- L'assenza di traffico dell'applicazione deve essere verificata con DevTools Network; per isolare anche browser e sistema operativo occorrono firewall/regole di rete del sistema.
- Il collaudo browser non è stato eseguito nell'ambiente di build: fino al suo completamento la v6.24 resta una baseline candidata, non una release certificata.
