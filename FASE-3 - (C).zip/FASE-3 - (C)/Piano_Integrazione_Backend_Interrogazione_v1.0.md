# Piano d'integrazione Backend INTERROGAZIONE — v1.0

**Progetto:** TenFingersTypingTrainer  
**Baseline:** v6.23  
**Stato:** piano esecutivo; nessuna modifica ai sorgenti  
**Stack vincolante:** JavaScript classico, script `defer`, DOM e storage browser nativi  
**Documenti di riferimento:**
- `HANDOFF TECNICO INTERROGAZIONE v1.0`
- `SPECIFICA TECNICA INTERROGAZIONE v1.0`
- `Contratti_Backend_Interrogazione_v1.1.md`
- `Schema_IndexedDB_Interrogazione_v1.1.md`
- `Decisione_Quote_Adattive_D77-D80_v1.1.md`
- `Catalogo_QWERTY_Italiano_v1.0.md` e seed JSON
- `Catalogo_Domande_Interrogazione_v1.0.md` e JSON
- `Motore_Selezione_Interrogazione_v1.0.md` e vettori JSON
- `Motore_Conoscenza_Interrogazione_v1.0.md` e vettori JSON
- `Motore_Sessione_Interrogazione_v1.0.md` e vettori JSON

---

## 1. Obiettivo

Definire l'ordine d'integrazione e i gate di qualità necessari per introdurre INTERROGAZIONE nella baseline senza alterare le funzionalità esistenti. Il backend deve poter essere verificato in isolamento prima del collegamento alla UI.

Il piano non autorizza né esegue modifiche ai sorgenti. I nomi dei file proposti sono organizzativi: prima di crearli si dovrà verificare la compatibilità con i contratti già approvati e con le convenzioni effettive del repository.

## 2. Stato verificato della baseline

L'ispezione della directory `/workspace/TenFingersTypingTrainer_v6.23` conferma:

- applicazione JavaScript senza `package.json` e senza framework;
- caricamento mediante script classici con attributo `defer` e ordine esplicito in `index.html`;
- dominio in `js/domain`, motori in `js/engines`, persistenza profili in `js/profiles`, statistiche digitazione in `js/analytics`, controller in `js/app/controller`;
- avvio da `js/app/bootstrap.js`, che costruisce `AppController` al `DOMContentLoaded`;
- `ProfileManager` persiste profili e impostazioni in LocalStorage;
- `StatisticsManager` è dedicato alle statistiche di digitazione e non deve essere riutilizzato come archivio della conoscenza INTERROGAZIONE;
- non è presente un repository IndexedDB né un dominio INTERROGAZIONE nella baseline;
- i test esistenti sono script Node autonomi nella directory `tests`.

### 2.1 Baseline testata

Esecuzione completata con Node.js v22.16.0:

- `runtime-smoke.js`: superato;
- `static-check.js`: superato;
- `test-dictation-adaptive.js`: superato;
- `test-dictation-config-dialog.js`: 7 controlli superati;
- `test-fonemi-delete.js`: superato;
- `test-fonemi-length.js`: superato;
- `test-instant-speed-pin.js`: superato;
- `test-window-stacking.js`: 26 controlli superati;
- `test-zoom-buttons.js`: superato.

La checklist browser `tests/REGRESSION_CHECKLIST.md` resta da eseguire manualmente. I test Node non sostituiscono il collaudo browser.

## 3. Architettura target e confini

I componenti logici restano separati:

1. **InterrogationRepository** — apertura IndexedDB, transazioni, query, idempotenza, concorrenza e recovery.
2. **InterrogationCatalog** — lettura/validazione del catalogo versionato, relazioni, candidate e definizioni.
3. **InterrogationKnowledge** — proiezione degli eventi, decadimento, affidabilità, classificazioni, priorità e calendario.
4. **InterrogationSelector** — selezione pura casuale/adattiva/manuale e calcolo quote.
5. **InterrogationSessionManager** — ciclo di vita, snapshot, valutazione, punteggio, avanzamento e chiusura.
6. **UI INTERROGAZIONE** — configurazione, visualizzazione, acquisizione risposta e riepiloghi; nessuna regola di conoscenza o selezione duplicata nella UI.

Dipendenze consentite:

- Catalog e Knowledge possono leggere dal Repository attraverso API esplicite.
- Selector riceve input già normalizzati e snapshot coerenti; non accede direttamente allo storage.
- SessionManager orchestra Catalog, Knowledge, Selector e Repository.
- UI invoca SessionManager e presenta risultati; non scrive direttamente negli object store.
- `StatisticsManager` rimane indipendente.

## 4. Sequenza d'implementazione vincolante

### Fase 0 — Consolidamento contratti e gate preliminari

Prima di scrivere codice:

- fissare in un unico riferimento le versioni effettive di contratti, schema IndexedDB, decisioni D77–D80 e specifiche dei motori;
- verificare che ogni campo usato da Selector, Knowledge e SessionManager esista nello schema fisico;
- congelare la versione del PRNG e i vettori noti del seed;
- confermare la regola di calendario di consolidamento e la gestione del rapporto consultazione/errore;
- materializzare i candidate di domanda principale in modo esplicito, senza generarli implicitamente a runtime;
- verificare che l'algoritmo quote usi budget globale fisso 10 punti percentuali e tetto individuale 20% della quota base normalizzata.

**Gate 0:** nessuna implementazione se un contratto usa campi assenti dallo schema o se due documenti attribuiscono significati diversi allo stesso campo.

### Fase 1 — Repository IndexedDB e test di persistenza

Implementare prima il repository, isolato dalla UI:

- apertura database, creazione store e indici;
- upgrade versionato e gestione `versionchange` / `blocked`;
- wrapper transazionali con completamento/abort osservabile;
- CRUD vincolato a `profileId`;
- receipt idempotenti per `operationId`;
- controllo ottimistico di `recordVersion`;
- transazioni atomiche per `recordOutcome`, creazione sessione, sospensione, ripresa, abbandono, completamento e correzioni;
- recovery delle operazioni a fasi tra LocalStorage e IndexedDB;
- export/import e cancellazione profilo secondo lo schema.

Non introdurre transazioni finte che simulino atomicità tra LocalStorage e IndexedDB: il protocollo deve usare marker persistenti, fasi verificabili e recupero idempotente.

**Gate 1:** test IndexedDB superati su browser reale; abort non lascia scritture parziali; ripetizione della stessa operationId non duplica eventi; profili distinti non si contaminano.

### Fase 2 — Catalogo e candidate espliciti

Implementare caricamento, validazione e risoluzione di:

- versioni catalogo;
- elementi fisici e identità semantiche;
- relazioni;
- definizioni di sotto-quesito;
- template di domanda principale;
- candidate materializzati e loro sotto-quesiti ordinati.

Il catalogo attualmente verificato contiene 52 tasti fisici, 111 mapping carattere, 62 ID SVG e 60 coordinate anatomiche; non copre il layout completo di 105 tasti. Le definizioni attive del catalogo domande sono 445, ma non costituiscono da sole l'inventario completo dei candidate.

**Gate 2:** nessun candidate può essere selezionato se non è presente, attivo, versionato e validato. Le lacune del layout restano escluse; niente completamento per inferenza.

### Fase 3 — Motore della conoscenza puro

Separare il calcolo in funzioni pure testabili:

- ricostruzione della proiezione da eventi e correzioni append-only;
- decadimento esponenziale emivita 60 giorni;
- esposizioni equivalenti e affidabilità prudenziale;
- fattori di debolezza e indice composito;
- correzione dell'indice verso il neutro 50;
- classificazioni e aggregazioni di categoria;
- priorità temporanee delle consultazioni;
- calendario e `nextReviewAt`.

La persistenza della nuova proiezione avviene tramite Repository e non dentro le funzioni matematiche.

**Gate 3:** vettori numerici superati; ricostruzione da eventi produce la stessa proiezione; esposizione, consultazione e visualizzazione sono distinte; ricalcoli non modificano gli eventi immutabili.

### Fase 4 — Motore di selezione puro

Implementare in ordine:

1. normalizzazione e validazione input;
2. preparazione pool e filtri;
3. PRNG deterministico versionato;
4. casuale pura;
5. quote categoria e quote adattive interne;
6. budget globale 10 punti percentuali, tetto individuale 20% della quota base, redistribuzione e quota neutra;
7. conversione a conteggi interi con maggiori resti e spareggi deterministici;
8. priorità consultazioni senza violare quote;
9. selezione manuale con duplicati vietati salvo opt-in esplicito.

Il Selector non registra eventi e non scrive nel Repository. L'eventuale consumo delle priorità deve essere coordinato dal SessionManager nella transazione di creazione sessione.

**Gate 4:** tutti i vettori di selezione e i test di proprietà superati; somme 100%; conteggi interi corretti; nessun candidato duplicato fuori dall'eccezione manuale; stesso input/seed/versioni produce lo stesso output.

### Fase 5 — Motore di sessione

Implementare:

- creazione sessione e snapshot atomico di configurazione, catalogo, algoritmo, candidate e sotto-quesiti;
- gestione stati e transizioni;
- conferma esplicita della risposta prima della valutazione;
- `recordOutcome` atomico per evento, conoscenza, punteggio, avanzamento e receipt;
- consultazione come esito dedicato;
- non risposta senza evento di errore;
- sospensione e ripresa dallo snapshot;
- abbandono con conservazione risultati;
- completamento solo dopo conferma esplicita;
- recupero dopo reload o crash.

La regola di una sola sessione sospesa per profilo deve essere applicata nel repository. Non estendere il vincolo a tutte le sessioni `in-progress` finché non esiste una decisione funzionale esplicita.

**Gate 5:** test di transizione, idempotenza, atomicità, sospensione/ripresa e recovery superati.

### Fase 6 — Integrazione controller e UI

Solo dopo i gate backend:

- aggiungere la UI INTERROGAZIONE senza modificare il flusso di digitazione;
- collegare configurazione profilo, scelta tipologia/modalità, numero domande e selezione manuale;
- gestire avviso di disponibilità insufficiente con procedi/annulla;
- presentare prompt e sotto-quesiti con risposte appropriate al tipo;
- distinguere conferma, consultazione, salto, sospensione, abbandono e completamento;
- mostrare riepilogo punteggio e classificazioni senza esporre dettagli tecnici interni;
- rendere accessibili storico, progressi e calendario senza consentire alterazioni dirette dello storico.

Gli script restano classici con `defer`. I nuovi file devono essere inseriti in `index.html` nell'ordine di dipendenza, prima dei consumer e prima del bootstrap. Non convertire a ES modules.

**Gate 6:** test UI e browser superati; nessuna regressione alle modalità esistenti.

### Fase 7 — Export/import, migrazione e resilienza

- definire un pacchetto portabile con versione formato e checksum;
- validare tutto il pacchetto prima di applicare modifiche;
- applicare import con strategia atomica/recuperabile e rollback;
- gestire conflitti di identità semantica e versioni catalogo senza trasferire automaticamente conoscenza;
- verificare quota storage, database bloccato, upgrade concorrente, scheda chiusa durante transazione e profilo eliminato;
- documentare recovery e messaggi utente.

**Gate 7:** test import/export, rollback, recovery e compatibilità superati.

### Fase 8 — Rilascio e documentazione

- aggiornare versione applicativa secondo il processo di release del progetto;
- aggiornare changelog, architettura, manuale e HELP soltanto per comportamenti visibili all'utente;
- mantenere i dettagli interni nei documenti tecnici;
- eseguire tutti i test Node e la checklist browser completa;
- verificare installazione/avvio da `index.html`, profili esistenti e assenza di perdita dati.

**Gate 8:** tutti i gate precedenti superati, documentazione coerente, nessuna regressione e piano di rollback pronto.

## 5. Questioni bloccanti da chiudere prima del codice

| ID | Questione | Perché blocca | Criterio di chiusura |
|---|---|---|---|
| B01 | PRNG deterministico | Riproducibilità selezione | Algoritmo, seed, serializzazione e vettori noti congelati |
| B02 | Candidate espliciti | Il selector opera su domande principali, non su sole definizioni | Inventario candidate validato e versionato |
| B03 | Copertura layout 105 tasti | Il catalogo attuale è parziale | Tutti i tasti mancanti verificati da fonti applicative/visuali |
| B04 | Rapporto consultazione/errore | Pesi 25%/40% e intensità 50% producono contributo relativo 31,25%, non 50% | Decisione esplicita: prevale il peso composto o il rapporto effettivo 1:2 |
| B05 | Calendario consolidamento | Il selettore usa `nextReviewAt` ma il comportamento deve essere univoco | Regola completa per corretto, errato, consultato, non risposta e scadenza |
| B06 | Sessioni attive concorrenti | È definito il limite di una sospesa, non l'unicità `in-progress` | Mantenere il comportamento attuale senza vincolo aggiuntivo oppure decisione esplicita |
| B07 | Relazione DITO / landmark / SVG | Tre modificatori destri presentano discordanza già rilevata | Mapping approvato e test di coerenza |
| B08 | Coerenza schema/contratti | Le transazioni devono usare store e indici reali | Matrice campo/indice/operazione verificata e versionata |

Le questioni B03 e B07 possono essere gestite con un sottoinsieme dichiarato, ma impediscono di dichiarare completo il catalogo iniziale. B01, B02, B04, B05 e B08 devono essere chiuse prima di dichiarare pronto il backend adattivo.

## 6. Strategia di test

### 6.1 Livello unitario

- funzioni pure di normalizzazione, quote, PRNG, conoscenza, transizioni e punteggio;
- test con vettori JSON versionati;
- test di proprietà per quote, conteggi, classificazioni e invarianti;
- test di identità semantica e versioni catalogo.

### 6.2 Livello repository

- IndexedDB reale in browser headless/ambiente browser di test;
- transazioni multi-store, abort, chiusura connessione, upgrade e concorrenza;
- operationId ripetuto e operationId in conflitto;
- due schede sullo stesso profilo e su profili differenti;
- crash/reload in ogni fase del protocollo LocalStorage/IndexedDB.

### 6.3 Livello integrazione

- creazione sessione → risposta → evento → knowledge state → punteggio;
- consultazione → priorità successiva;
- sessione sospesa → reload → ripresa identica;
- abbandono e completamento esplicito;
- import/export e cancellazione profilo;
- catalogo aggiornato durante sessione sospesa.

### 6.4 Regressione

A ogni fase eseguire i nove test baseline elencati al §2.1. Prima del rilascio eseguire anche l'intera `tests/REGRESSION_CHECKLIST.md` su browser aggiornato. I test INTERROGAZIONE devono essere aggiunti senza rimuovere o indebolire quelli esistenti.

## 7. Strategia di versionamento e contenimento del rischio

- Nuovi file sorgente e documentazione ricevono una nuova versione secondo le convenzioni di progetto.
- Le modifiche alla baseline sono circoscritte; nessun refactoring generale del controller o di `ProfileManager`.
- Non riutilizzare `StatisticsManager` per la conoscenza didattica.
- Non cambiare storage dei profili esistenti: IndexedDB ospita il nuovo dominio, con protocollo esplicito per le impostazioni profilo e le operazioni cross-storage.
- Non modificare l'ordine esistente degli script se non per inserire i nuovi script nelle posizioni necessarie.
- Ogni fase produce test ripetibili e una baseline verde prima di procedere alla successiva.
- In caso di fallimento di un gate, fermare l'integrazione al confine della fase; non compensare con logica duplicata nella UI.

## 8. Esito e prossimo deliverable

Il percorso di integrazione è definito in otto fasi, con gate verificabili e dipendenze esplicite. La baseline esistente è verde sui test Node disponibili, ma il collaudo browser resta pendente.

Il prossimo deliverable tecnico, prima di implementare, è una **Matrice di tracciabilità Contratti ↔ Schema IndexedDB ↔ Motori ↔ Test**, che chiuda B08 e intercetti discrepanze di campi, indici, transazioni e responsabilità. In parallelo vanno formalizzate le decisioni B01, B04 e B05 e materializzati i candidate B02.

**Nessun sorgente applicativo è stato modificato in questa fase.**
