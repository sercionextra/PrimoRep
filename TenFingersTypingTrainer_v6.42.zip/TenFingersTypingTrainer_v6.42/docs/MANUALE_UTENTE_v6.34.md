# Manuale Utente — Aggiornamento v6.34

## Novità della versione v6.34

1. **Finestra Interrogazione a piena altezza (`100vh`) e trascinabile fino al bordo superiore (`top: 0`):**
   - La finestra **Interrogazione Layout Tastiera Italiana** può essere ridimensionata fino a coprire l'intera altezza visibile della finestra del browser (`100vh`) e trascinata dalla barra del titolo fino a `top: 0`, coprendo all'occorrenza anche la barra superiore dell'applicazione.
   - Le altre finestre fluttuanti (Mani, Statistiche, Editor Custom, Velocità Istantanea) mantengono la protezione standard sotto l'header principale (`minTop = 60`).

2. **Correzione layout italiano QWERTY per i tasti `ì` e `'`:**
   - Il tasto **`ì` / `^`** (`key_igrave`) non presenta più il carattere `~` in AltGr.
   - Il tasto **`'` / `?`** (`key_quote`) non presenta più il carattere `` ` `` in AltGr.
   - I caratteri `~` e `` ` `` restano disponibili nella palette **"Seleziona carattere / tasto"** come possibili distrattori durante l'interrogazione.

3. **Posizionamento orizzontale della finestra "Seleziona carattere / tasto":**
   - Cliccando un pulsante per scegliere un carattere (nella sezione `2) Caratteri sul Tasto` o `3) Tasti intorno a margherita`), il selettore ASCII si apre orizzontalmente centrato rispetto al pulsante cliccato (e sopra o sotto a seconda dello spazio disponibile), restando sempre visibile entro i margini della finestra.
