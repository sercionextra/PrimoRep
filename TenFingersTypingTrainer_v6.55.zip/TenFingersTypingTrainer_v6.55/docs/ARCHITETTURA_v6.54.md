# Architettura TenFingersTypingTrainer v6.54

Documento di aggiornamento architetturale rispetto alla v6.53.

## 1. Obiettivo della Release v6.54
Calibrare la dimensione dei pallini evidenziati nel grafico delle velocità durante l'hover sui filtri di sessione, riducendo il raggio da `8px` a `5px` e rimuovendo il bordino bianco aggiunto in hover.

## 2. Interventi Architetturali
- **`assets/styles/app.css`:** nella regola `#speedSvgPlot.hover-type-1 .speed-point[data-type="1"], ... , #speedSvgPlot.hover-type-8 .speed-point[data-type="8"]`, impostato `r: 5 !important;` e rimossi `stroke: #ffffff !important;` e `stroke-width: 1.5px !important;`.
