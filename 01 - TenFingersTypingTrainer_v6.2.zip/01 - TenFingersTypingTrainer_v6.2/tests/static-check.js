#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const expected = [
  'js/domain/helpers.js', 'js/data/lessons.js', 'js/data/demo-profile.js',
  'js/data/custom-default.js', 'js/data/phoneme-corpus.js', 'js/domain/keyboard-map.js',
  'js/domain/finger-names.js', 'js/domain/anatomical-landmarks.js', 'js/domain/keyboard-helpers.js',
  'js/engines/audio-engine.js', 'js/profiles/profile-manager.js',
  'js/domain/phoneme-engine.js', 'js/ui/window-manager.js', 'js/engines/typing-engine.js',
  'js/ui/visual-renderer.js', 'js/engines/dictation-engine.js', 'js/shared/export-utils.js',
  'js/analytics/statistics-manager.js',
  'js/app/controller/controller-core.js',
  'js/app/controller/metodi-fonemi-dropdown.js',
  'js/app/controller/metodi-avvio-temi-audio.js',
  'js/app/controller/metodi-finestre-layout.js',
  'js/app/controller/metodi-profili-modali.js',
  'js/app/controller/metodi-toolbar-modalita.js',
  'js/app/controller/metodi-navigazione-dialoghi.js',
  'js/app/controller/metodi-rendering-guida.js',
  'js/app/controller/metodi-input-digitazione.js',
  'js/app/controller/metodi-scorciatoie-editor-custom.js',
  'js/app/controller/metodi-statistiche.js',
  'js/app/controller/metodi-dettatura.js',
  'js/app/bootstrap.js'
];
let failed = false;
for (const file of expected) {
  const exists = fs.existsSync(path.join(root, file));
  if (!exists || !html.includes(file)) { console.error('FAIL script missing or not wired:', file); failed = true; }
  else console.log('OK', file);
}
if (!html.includes('v6.2')) { console.error('FAIL version marker v6.2 missing from index'); failed = true; }
if (!html.includes('assets/styles/app.css')) { console.error('FAIL stylesheet not linked'); failed = true; }
if (!fs.existsSync(path.join(root, 'help.html'))) { console.error('FAIL help.html missing'); failed = true; }
if (!fs.existsSync(path.join(root, 'docs/MANUALE_UTENTE_v6.2.md'))) { console.error('FAIL user manual missing'); failed = true; }
if (failed) process.exit(1);
console.log('Static package checks passed. Browser regression checklist still required.');

