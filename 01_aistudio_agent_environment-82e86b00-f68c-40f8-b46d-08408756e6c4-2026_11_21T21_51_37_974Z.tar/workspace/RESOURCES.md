# Cubo di Rubik 3x3 Resources

## Knowledge

- [Guide: How To Solve The 3x3 Rubik's Cube — J Perm](https://www.jperm.net/3x3)
  Metodo per principianti a 7 fasi basato quasi interamente su due sequenze di 4 mosse (destra e sinistra). Use for: percorso principale passo-passo con il minimo carico di memorizzazione.
- [Course: The Beginner's Method for Solving the Rubik's Cube — CubeSkills (Feliks Zemdegs)](https://www.cubeskills.com/tutorials/the-beginners-method-for-solving-the-rubiks-cube)
  Corso strutturato del campione del mondo Feliks Zemdegs sulla struttura del cubo e sul metodo a strati. Use for: approfondimenti visivi su croce, primo strato e casi particolari.
- [Reference: Rubik's Cube Notation Explained — Ruwix](https://ruwix.com/the-rubiks-cube/notation/)
  Spiegazione chiara della notazione standard WCA (`F, R, U, L, B, D`, apici e doppi giri). Use for: decifrare qualsiasi algoritmo scritto.
- [Regulations: WCA Official Regulations](https://www.worldcubeassociation.org/regulations/)
  Regolamento ufficiale della World Cube Association. Use for: standard di notazione e orientamento ufficiale.
- [Simulator: Cubzor 3x3](https://www.cubzor.com/it/simulator/3x3)
  Simulatore 3D interattivo in italiano scelto dallo studente. Use for: tutta la pratica attiva e la verifica delle sequenze.

## Wisdom (Communities)

- [r/Cubers (Reddit)](https://www.reddit.com/r/Cubers/) e [r/Cubers Solution Guides Wiki](https://www.reddit.com/r/Cubers/wiki/solution_guides/)
  Community attiva di appassionati con una wiki dedicata ai principianti. Use for: domande su casi bloccati, consigli pratici e confronto con altri cuber.
