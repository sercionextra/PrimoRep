# TenFingersTypingTrainer – Contratti Backend INTERROGAZIONE

**Documento:** Contratti_Backend_Interrogazione_v1.2  
**Baseline applicativa:** TenFingersTypingTrainer v6.23  
**Schema persistente di riferimento:** Schema_IndexedDB_Interrogazione_v1.2  
**Riferimenti funzionali:** HANDOFF TECNICO INTERROGAZIONE v1.0; SPECIFICA TECNICA INTERROGAZIONE v1.0; Decisione Quote Adattive D77–D80 v1.1  
**Documenti correlati:** Motore_Selezione_Interrogazione_v1.0; Motore_Conoscenza_Interrogazione_v1.0; Motore_Sessione_Interrogazione_v1.0; Catalogo_Domande_Interrogazione_v1.0; Matrice_Tracciabilita_Interrogazione_v1.0  
**Stato:** contratti progettuali allineati; implementazione non avviata  
**Destinazione canonica:** `/workspace/Contratti_Backend_Interrogazione_v1.2.md`

---

## 1. Obiettivo e vincoli

Questo documento definisce i contratti tra i componenti backend di INTERROGAZIONE e li allinea allo schema fisico IndexedDB v1.2. Specifica responsabilità, payload, risultati, invarianti e confini transazionali; non contiene implementazioni e non autorizza modifiche ai sorgenti.

Vincoli non negoziabili:

- mantenere JavaScript classico e l'architettura della baseline v6.23; niente ES modules, TypeScript, framework o conversioni di stack;
- mantenere `KEY_MAP`, `resolveTargetChord()`, `FINGER_NAMES` e i dati anatomici esistenti come fonti tecniche, senza duplicare o alterare arbitrariamente le mappe;
- tenere separate le statistiche di digitazione da quelle di conoscenza;
- usare IndexedDB per il dominio Interrogazione e lasciare al `ProfileManager` la gestione profili già esistente in LocalStorage;
- congelare configurazione, catalogo, definizioni, candidate e parametri di selezione all'avvio della sessione;
- mantenere eventi, correzioni e audit append-only;
- non trasferire automaticamente conoscenza tra identità semantiche sostituite;
- mantenere tutte le scritture di una singola operazione logica in una transazione IndexedDB;
- non dichiarare completata una funzionalità finché i test automatici e la checklist browser previsti non sono superati.

## 2. Componenti e responsabilità

I sei componenti sono confini logici. Possono essere distribuiti in file JavaScript distinti secondo l'organizzazione della baseline, senza introdurre un sistema di moduli.

| Componente | Responsabilità | Dipendenze ammesse | Non deve fare |
|---|---|---|---|
| `InterrogationCatalog` | Caricare, validare e risolvere catalogo, relazioni, definizioni e template; materializzare candidate | Repository, fonti keyboard esistenti | Calcolare conoscenza o accedere al DOM |
| `InterrogationSelector` | Applicare modalità casuale, adattiva e manuale; quote, priorità e ordinamento deterministico | Catalog, Knowledge snapshot | Scrivere IndexedDB o mutare statistiche |
| `InterrogationKnowledge` | Ricostruire eventi effettivi, esposizioni equivalenti, fattori, affidabilità, classificazione e calendario | Repository, policy versionate | Selezionare domande o aggiornare UI |
| `InterrogationSessionManager` | Orchestrare creazione, valutazione, consultazione, avanzamento, sospensione, ripresa, abbandono e completamento | Catalog, Selector, Knowledge, Repository | Accedere direttamente al DOM |
| `InterrogationRepository` | Incapsulare IndexedDB, transazioni, indici, migrazioni, idempotenza, concorrenza e recovery | IndexedDB API | Contenere regole di presentazione o selezione |
| UI Interrogazione | Acquisire configurazione e risposte; mostrare domanda, feedback, riepilogo e stati | Session Manager e API di lettura | Calcolare punteggi/conoscenza o scrivere direttamente negli store |

Il repository è l'unico componente autorizzato a effettuare scritture IndexedDB. I motori producono risultati puri o comandi che il repository persiste tramite il Session Manager.

## 3. Convenzioni condivise

### 3.1 Asincronia e formato delle API

Le operazioni che leggono o scrivono IndexedDB restituiscono `Promise`. Le funzioni pure (calcolo quote, classificazione, materializzazione candidate da snapshot già caricati) possono essere sincrone.

Le API ricevono un singolo oggetto `input` e restituiscono un singolo oggetto risultato. Le funzioni non leggono parametri impliciti dalla UI o da variabili globali, salvo l'adapter esplicito verso le fonti keyboard della baseline.

Convenzione:

```js
service.operation({
  profileId: "...",
  operationId: "...",
  // dati specifici dell'operazione
}).then(function (result) {
  // risultato tipizzato
});
```

Le firme sono contratti progettuali. Non si impone l'uso di `async/await` se incompatibile con il livello JavaScript supportato dalla baseline; l'implementazione può usare Promise e callback mantenendo lo stesso comportamento.

### 3.2 Timestamp

Tutti i timestamp interni sono numeri interi Unix in millisecondi UTC. ISO 8601 è ammesso solo ai confini di visualizzazione e import/export. Non convertire o mescolare unità all'interno dei record.

### 3.3 Codici canonici

Le enumerazioni persistite sono codici macchina stabili:

- classificazione: `neverVerified`, `weak`, `review`, `consolidated`, `insufficientData`;
- esito: `correct`, `incorrect`, `consulted`;
- stato sotto-quesito: `pending`, `answered`, `consulted`, `unanswered`;
- stato priorità: `pending`, `consumed`, `invalidated`, `notApplicable`;
- modalità: `random`, `adaptive`, `manual`;
- stato sessione: `in-progress`, `suspended`, `abandoned`, `completed`.

Le etichette italiane sono responsabilità della UI e non vanno persistite come enumerazioni.

### 3.4 Identificativi e versioni

- `profileId`, `sessionId`, `itemId`, `eventId`, `correctionId`, `priorityId`, `auditId` e `operationId` sono identificativi opachi.
- `semanticId`, `questionSemanticId` e `templateSemanticId` rappresentano identità semantiche.
- `contentVersion` versiona il contenuto mantenendo l'identità.
- `catalogVersion` identifica una fotografia pubblicata del catalogo.
- `revision` protegge i record modificabili da aggiornamenti concorrenti.
- `operationId` è generato una volta per comando persistente e non viene riutilizzato per un payload diverso.

### 3.5 Esito, stato e punteggio

Esito didattico e stato di avanzamento sono concetti distinti:
- `correct`: stato `answered`, punteggio 3;
- `incorrect`: stato `answered`, punteggio 0;
- `consulted`: stato `consulted`, punteggio 1;
- non risposta: stato `unanswered`, nessun evento di conoscenza e punteggio 0;
- semplice visualizzazione: nessun evento e nessuna variazione della conoscenza.

Il punteggio domanda principale è la somma dei punteggi dei sotto-quesiti; il punteggio sessione è la somma dei punteggi delle domande principali.

## 4. Contratti dei record di dominio

La struttura fisica completa è definita in `Schema_IndexedDB_Interrogazione_v1.2`. Questa sezione stabilisce i campi che i componenti devono scambiarsi e le invarianti che non possono reinterpretare.

### 4.1 Elemento catalogo

Campi contrattuali: `semanticId`, `contentVersion`, `recordId`, `type`, `layoutId`, `subjectType`, `subjectId`, `categoryId`, `status`, `replacedBySemanticId`, `validFromCatalogVersion`, `revision`.

`semanticId` resta stabile finché il significato didattico non cambia. Un cambiamento sostanziale crea una nuova identità. Un elemento già referenziato da eventi o sessioni viene dismesso (`retired`), non eliminato fisicamente.

### 4.2 Relazione catalogo

Campi: `relationId`, `catalogVersion`, `fromSemanticId`, `relationType`, `toSemanticId`, `attributes`, `status`.

Tipi iniziali: `producedBy`, `requiresModifier`, `assignedToFinger`, `belongsToHand`, `neighborOf`, `homeRowPosition`, `replacedBy`. I valori effettivamente disponibili devono essere verificati contro il catalogo pubblicato; non vanno inventati per completare una query.

### 4.3 Definizione sotto-quesito

Campi: `questionSemanticId`, `contentVersion`, `elementSemanticId`, `aspectId`, `answerType`, `answerDefinition`, `presentationType`, `evaluationPolicy`, `status`, `catalogVersion`.

Ogni sotto-quesito misura un aspetto autonomo e mantiene statistiche individuali. Una modifica di sola formulazione non cambia `questionSemanticId`; un nuovo aspetto autonomo richiede una nuova identità.

### 4.4 Template domanda principale

Campi: `templateSemanticId`, `contentVersion`, `catalogVersion`, `questionType`, `layoutId`, `status`, `mainElementSemanticId`, `compositionRule`, `components`, `candidatePolicyVersion`.

Il template descrive in modo versionato come comporre una domanda principale e i relativi sotto-quesiti. Non contiene conoscenza del profilo né punteggi.

### 4.5 Candidate

Un candidate è un oggetto temporaneo, puro e immutabile, materializzato da template, elementi, relazioni e definizioni della stessa `catalogVersion`.

Campi minimi in memoria:
- `candidateId` deterministico;
- `templateSemanticId` e `templateContentVersion`;
- `catalogVersion`, `questionType`, `layoutId`;
- `mainElementSemanticId`;
- componenti ordinati, ciascuno con `questionSemanticId`, `elementSemanticId`, `definitionVersion` e snapshot di definizione;
- `categoryId` e dati necessari al selettore.

Non esiste uno store persistente dei candidate. La sessione salva soltanto i candidate selezionati.

### 4.6 Sessione e item

La sessione conserva `profileId`, `sessionId`, `status`, `mode`, `questionType`, quantità richiesta/effettiva, `configSnapshot`, `selectionSnapshot`, `catalogVersion`, `currentItemIndex`, `score`, `revision`, timestamp e stato di completamento.

Ogni `sessionItem` conserva ordine, candidate/template di origine, domanda principale, prompt snapshot e sotto-quesiti congelati. Ogni sotto-quesito contiene `status`, `outcome`, `score`, `evaluatedAt` ed `exposureEventId`.

La ripresa non ricalcola candidate, quote o ordine.

### 4.7 Evento, correzione e priorità consultazione

`exposureEvents` è la fonte storica append-only per gli esiti `correct`, `incorrect`, `consulted`. La semplice visualizzazione e la non risposta non generano eventi.

`eventCorrections` aggiunge rettifiche senza alterare l'evento originale. Un annullamento è una nuova correzione collegata a quella annullata.

`consultationPriorities` è una proiezione operativa ricostruibile dagli eventi consultati e dalle correzioni. La priorità:
- è riferita al candidate e alla tipologia sorgente;
- può essere consumata soltanto da una sessione successiva `adaptive` della stessa tipologia;
- è consumata solo se il candidate entra nella sessione creata;
- non aggiunge posti e non altera le quote;
- non viene trasferita a un'identità sostitutiva;
- mantiene la storia del consumo anche se una correzione successiva invalida la priorità.

### 4.8 Stato conoscenza

`knowledgeStates` è una proiezione ricostruibile per `profileId` e `questionSemanticId`. Deve contenere i fattori disponibili, indice grezzo, affidabilità, `correctedWeaknessIndex`, classificazione, dati calendario, versioni di policy, conteggi fonti, fingerprint e `calculatedAt`.

La formula canonica dell'indice corretto è:

`correctedWeaknessIndex = 50 + reliability × (rawWeaknessIndex - 50)`

Per gli elementi mai verificati: conteggi zero, affidabilità zero, classificazione `neverVerified`, nessun indice di debolezza numerico. Se mancano tutti i fattori necessari su un elemento già verificato, usare `insufficientData`, non una classe artificiale.

## 5. Contratti dei componenti

### 5.1 `InterrogationRepository`

Responsabilità: tutte le operazioni IndexedDB e le transazioni atomiche.

| API | Input essenziale | Output |
|---|---|---|
| `open()` | nessuno | `{ database, schemaVersion, ready: true }` |
| `close()` | nessuno | `{ closed: true }` |
| `getCatalogSnapshot({ catalogVersion })` | versione catalogo | `{ catalogVersion, elements, relations, definitions, templates }` |
| `getProfileSettings({ profileId })` | profilo | `{ settings, revision }` |
| `saveProfileSettings({ profileId, expectedRevision, settings, operationId })` | configurazione e revisione attesa | `{ settings, revision }` |
| `getKnowledgeSnapshot({ profileId, questionSemanticIds, asOf })` | profilo, elementi e tempo di riferimento | `{ states, sourceFingerprint, calculatedAt }` |
| `getSuspendedSession({ profileId })` | profilo | `{ session }` oppure `null` |
| `getSession({ profileId, sessionId })` | chiavi sessione | `{ session, items }` |
| `commitSessionCreation(command)` | sessione, item, priorità da consumare, receipt | `{ session, items, consumedPriorityIds }` |
| `commitOutcome(command)` | evento, item/sessione aggiornati, knowledge state, receipt | `{ event, session, item, knowledgeState, duplicate }` |
| `commitConsultation(command)` | evento consultato, priorità, item/sessione, knowledge state, receipt | `{ event, priority, session, item, knowledgeState, duplicate }` |
| `commitSessionTransition(command)` | stato atteso/nuovo, revision, receipt | `{ session, duplicate }` |
| `commitCorrection(command)` | correzione, proiezioni interessate, receipt | `{ correction, affectedStates, affectedPriorities }` |
| `rebuildKnowledge(command)` | profilo, question IDs, tempo congelato, policy versions | `{ rebuiltCount, sourceFingerprint }` |
| `rebuildPriorities(command)` | profilo, ambito e fonti | `{ rebuiltCount, sourceFingerprint }` |
| `publishCatalog(command)` | manifest, elementi, relazioni, definizioni, template, audit, receipt | `{ catalogVersion, contentHash }` |
| `exportProfile({ profileId })` | profilo | pacchetto versionato completo |
| `importProfile({ package, conflictStrategy, operationId })` | pacchetto e strategia | `{ imported, skipped, conflicts, warnings }` |
| `deleteProfileData({ profileId, expectedRevision, operationId })` | profilo e revisione | `{ deletedStores, recoveryMarker }` |

Le funzioni `commit*` sono interne al confine Session Manager/Repository; la UI non le invoca direttamente.

Il repository non espone un metodo generico che consenta alla UI di scrivere liberamente negli object store. Le query restituiscono copie/DTO, non riferimenti mutabili ai record persistiti.

### 5.2 `InterrogationCatalog`

| API | Input | Output |
|---|---|---|
| `validateCatalogSnapshot({ snapshot })` | fotografia catalogo | `{ valid, errors, warnings }` |
| `getAvailableElements({ snapshot, questionType, layoutId, categoryId })` | snapshot e filtri | elementi attivi validi |
| `getQuestionDefinitions({ snapshot, elementSemanticId })` | snapshot ed elemento | definizioni attive versionate |
| `getQuestionTemplates({ snapshot, questionType, layoutId })` | snapshot e filtri | template attivi |
| `getAvailableCandidates({ snapshot, questionType, layoutId })` | snapshot e filtri | candidate ordinati canonicamente |
| `getCandidateById({ snapshot, candidateId })` | snapshot e ID | candidate o `null` |
| `validateCandidate({ snapshot, candidate })` | snapshot e candidate | `{ valid, errors }` |

Invarianti:
- ogni componente richiesto deve risolversi in elemento e definizione attivi;
- template, relazioni, elementi e definizioni devono riferirsi alla stessa `catalogVersion`;
- elementi `retired` non entrano in nuove sessioni;
- il candidate ID è deterministico e include le versioni semantiche/contenutistiche necessarie;
- un candidate non valido viene escluso con diagnostica; nella selezione manuale l'invalidità è bloccante, senza sostituzione silenziosa.

### 5.3 `InterrogationKnowledge`

| API | Input | Output |
|---|---|---|
| `getEffectiveEvents({ events, corrections })` | eventi e sequenza correzioni | eventi effettivi ordinati |
| `calculateEquivalentExposures({ events, asOf, halfLifeDays })` | eventi validi e tempo congelato | conteggio equivalente |
| `calculateWeaknessFactors({ events, asOf, policyVersion })` | eventi e policy | fattori disponibili e motivazioni |
| `calculateReliability({ equivalentExposures })` | esposizioni equivalenti | affidabilità 0–1 |
| `calculateCorrectedWeakness({ rawWeaknessIndex, reliability })` | indice grezzo e affidabilità | indice corretto |
| `classifyKnowledge({ correctedWeaknessIndex, effectiveExposureCount, dataAvailability })` | metriche | codice classificazione |
| `calculateReviewSchedule({ previousLevel, outcome, intervalsDays, evaluatedAt, policyVersion })` | stato calendario ed esito | nuovo livello, intervallo e prossima data |
| `buildQuestionState({ profileId, questionSemanticId, events, corrections, asOf, policies })` | fonti e policy versionate | record `knowledgeStates` completo |
| `buildCategoryMetrics({ questionStates })` | stati individuali | indice medio ponderato, copertura e affidabilità categoria |

Regole:
- emivita del decadimento: 60 giorni;
- lo storico non decade e non viene cancellato;
- esposizioni equivalenti sono una misura adattiva, non il conteggio storico;
- pesi debolezza: errori 40%, consultazioni 25%, ritardi 20%, mancato consolidamento 15%;
- consultazione: intensità 50% di un errore nel relativo fattore;
- affidabilità individuale prudenziale: esposizioni equivalenti / (esposizioni equivalenti + 5);
- indice corretto avvicinato al neutro 50 secondo la formula sopra;
- classi: `weak` da 70 a 100; `review` da 30 a meno di 70; `consolidated` da 0 a meno di 30;
- mai verificati sono esclusi dall'indice composito e gestiti con priorità dedicata;
- ricalcolo immediato dopo un esito/correzione; nuove classificazioni influenzano soltanto sessioni successive;
- categoria: indice medio ponderato per affidabilità; copertura separata; affidabilità categoria = affidabilità media × copertura.

Il calendario utilizza gli intervalli configurati 1, 3, 7, 14, 30 e 60 giorni. Regola funzionale: corretta avanza un livello, errata torna al minimo, consultata retrocede un livello, non risposta non modifica il calendario. L'implementazione deve mantenere la policy versionata e testare i limiti del primo/ultimo livello.

**Nota di coerenza:** la specifica conserva i pesi consultazioni 25% e intensità consultazione 50% del fattore errore. Il contributo composito risultante non equivale matematicamente alla metà del contributo di un errore: il rapporto è 31,25%. Non modificare i parametri senza una nuova decisione funzionale.

### 5.4 `InterrogationSelector`

| API | Input | Output |
|---|---|---|
| `buildSelection({ mode, questionType, questionCount, candidates, categoryQuotas, knowledgeSnapshot, priorities, seed, algorithmVersions })` | input completo congelato | `{ selectedCandidates, selectionSnapshot, warnings }` |
| `calculateCategoryQuotas({ candidates, categoryQuotas, knowledgeSnapshot, budgetPolicy })` | disponibilità e metriche | quote finali e dettaglio redistribuzione |
| `allocateIntegerCounts({ quotas, totalCount, tieBreakData })` | quote e totale | conteggi interi con somma esatta |
| `allocateAdaptiveStrata({ categoryCandidates, stratumQuotas })` | candidate classificati | conteggi e candidate per strato |
| `applyConsultationPriorities({ selectedCandidates, priorities, questionType })` | selezione e priorità compatibili | selezione ordinata e priorità effettivamente applicate |
| `validateManualSelection({ candidateIds, candidates, allowDuplicates })` | scelta manuale | `{ valid, errors, selectedCandidates }` |

Modalità:
- `random`: campionamento uniforme senza leggere statistiche di conoscenza né priorità;
- `adaptive`: quote tra categorie, distribuzione interna per strati, budget supplementare, quota neutra e priorità consultazione;
- `manual`: rispetta ordine e scelte esplicite; duplicati vietati salvo opzione esplicita prevista dalla specifica.

Regole adattive consolidate:
- quote miste iniziali: 25% ciascuna;
- quote interne: mai verificati 30%, deboli 40%, da ripassare 20%, consolidati 10%;
- budget supplementare globale: 10 punti percentuali;
- tetto individuale: 20% della quota base normalizzata della categoria;
- ripartizione proporzionale ai deficit di affidabilità con redistribuzione iterativa;
- residuo non assegnabile: quota neutra distribuita equamente tra le categorie disponibili;
- tutti i deficit nulli: nessun supplemento e nessun prelievo dalle quote base;
- categorie senza elementi escluse; quote inutilizzabili redistribuite secondo le quote configurate originarie delle categorie disponibili;
- conteggi interi con metodo dei maggiori resti; spareggio per debolezza, affidabilità minore, poi ordine canonico;
- priorità consultazione non aumenta il numero di posti e non viola quote o capienza.

**Gate PRNG:** il contratto richiede un generatore pseudo-casuale deterministico, ma algoritmo, versione, codifica seed e vettori noti devono essere congelati in una decisione tecnica prima dell'implementazione. Non è autorizzato scegliere un PRNG per supposizione. `selectionSnapshot` deve comunque contenere `prngAlgorithmId`, `prngAlgorithmVersion`, `seed`, `seedEncoding`, fingerprint del pool, ordine canonico, versione selettore, versione quote, snapshot conoscenza, quote, conteggi, candidate scelti e priorità applicate/non applicate.

### 5.5 `InterrogationSessionManager`

| API | Input | Output |
|---|---|---|
| `createSession({ profileId, settings, mode, questionType, questionCount, manualSelection, operationId })` | configurazione e modalità | `{ session, items, warnings }` |
| `getCurrentSession({ profileId })` | profilo | sessione attiva o `null` |
| `getSuspendedSession({ profileId })` | profilo | sessione sospesa o `null` |
| `getSessionDetails({ profileId, sessionId })` | chiavi | `{ session, items }` |
| `recordOutcome({ profileId, sessionId, itemId, questionSemanticId, answer, operationId, expectedRevision })` | risposta esplicita | `{ outcome, score, session, item, knowledgeState, nextAction }` |
| `consultSubQuestion({ profileId, sessionId, itemId, questionSemanticId, operationId, expectedRevision })` | richiesta consultazione | `{ event, score, priority, session, item, nextAction }` |
| `closeMainQuestion({ profileId, sessionId, itemId, operationId, expectedRevision })` | chiusura domanda | `{ item, unansweredCount, nextAction }` |
| `advanceSession({ profileId, sessionId, operationId, expectedRevision })` | richiesta avanzamento | `{ currentItem, completedItems, session }` |
| `suspendSession({ profileId, sessionId, operationId, expectedRevision })` | sessione | `{ session }` |
| `resumeSession({ profileId, sessionId, operationId, expectedRevision })` | sessione sospesa | `{ session, currentItem }` |
| `abandonSession({ profileId, sessionId, confirmed, operationId, expectedRevision })` | conferma esplicita | `{ session, score, resultsSummary }` |
| `completeSession({ profileId, sessionId, confirmed, operationId, expectedRevision })` | conferma esplicita | `{ session, score, resultsSummary }` |

Regole:
- una sola sessione sospesa per profilo;
- sospensione conserva posizione, snapshot e risultati;
- ripresa non ricalcola la selezione;
- abbandono richiede conferma e conserva tutti i risultati già registrati;
- completamento formale richiede conferma esplicita;
- non risposta non genera evento di conoscenza e non è un errore;
- la valutazione di un sotto-quesito è idempotente e non può essere duplicata;
- nuove classificazioni non modificano la selezione della sessione già avviata;
- il numero effettivo di domande può essere inferiore al richiesto solo dopo avviso e scelta esplicita di procedere;
- una sola sessione sospesa è vincolo; non si introduce un limite ulteriore alle sessioni storiche o attive oltre quanto previsto dalla specifica.

### 5.6 UI Interrogazione

La UI:
- legge configurazione, sessione e item attraverso Session Manager;
- raccoglie modalità, tipologia, quantità, eventuale selezione manuale e conferme;
- mostra risposte, feedback, punteggi, stato e riepilogo;
- invia comandi espliciti al Session Manager;
- non scrive direttamente in IndexedDB;
- non aggiorna autonomamente knowledge state;
- non usa `StatisticsManager` per le statistiche di conoscenza;
- localizza i codici canonici in etichette italiane.

## 6. Contratti transazionali obbligatori

### 6.1 `createSession`

Sequenza:
1. leggere impostazioni profilo e snapshot catalogo;
2. materializzare candidate validi;
3. acquisire snapshot conoscenza con `asOf` congelato;
4. calcolare selezione e priorità applicabili;
5. costruire sessione, snapshot e `sessionItems`;
6. aprire transazione IndexedDB sugli store necessari;
7. verificare revisioni di configurazione e stato delle priorità;
8. inserire sessione e item;
9. consumare solo le priorità i cui candidate sono realmente inclusi;
10. scrivere receipt e completare la transazione.

Se il numero disponibile è inferiore al richiesto, la UI deve ottenere l'avviso e la scelta prima della transazione finale. Annullando, nessuna sessione viene creata e nessuna priorità viene consumata.

Store coinvolti in scrittura: `sessions`, `sessionItems`, `consultationPriorities`, `operationReceipts`.

### 6.2 `recordOutcome`

È l'operazione atomica centrale:
1. verificare profilo, sessione, item e sotto-quesito;
2. verificare stato `pending` e `expectedRevision`;
3. verificare `operationId` e `payloadHash`;
4. validare la risposta rispetto allo snapshot della definizione;
5. determinare `correct` o `incorrect` e punteggio 3 o 0;
6. inserire evento append-only;
7. aggiornare stato del sotto-quesito e punteggio item/sessione;
8. ricostruire la proiezione knowledge usando eventi e correzioni effettivi;
9. aggiornare `knowledgeStates`;
10. inserire receipt;
11. commit atomico.

Store in scrittura: `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `operationReceipts`.

### 6.3 `consultSubQuestion`

La consultazione è un comando distinto dalla valutazione:
1. verificare che il sotto-quesito sia `pending`;
2. creare evento `consulted`, punteggio 1;
3. aggiornare sotto-quesito, item e sessione;
4. aggiornare knowledge state secondo policy;
5. creare priorità per la successiva sessione adattiva della stessa tipologia;
6. inserire receipt;
7. commit atomico.

Store in scrittura: `sessions`, `sessionItems`, `exposureEvents`, `knowledgeStates`, `consultationPriorities`, `operationReceipts`.

La consultazione non può essere registrata due volte per lo stesso sotto-quesito/sessione.

### 6.4 `closeMainQuestion` e `advanceSession`

La chiusura marca come `unanswered` i sotto-quesiti ancora `pending`, senza creare eventi, errori o modifiche alla conoscenza. L'avanzamento è consentito soltanto quando la domanda corrente è stata chiusa secondo le regole del motore. L'operazione aggiorna l'indice corrente e la revisione della sessione in modo atomico.

Store in scrittura: `sessions`, `sessionItems`, `operationReceipts`.

### 6.5 Transizioni di sessione

- `in-progress → suspended`: imposta `suspendedProfileId = profileId`; l'indice univoco impedisce una seconda sessione sospesa per il profilo.
- `suspended → in-progress`: rimuove `suspendedProfileId`, conserva tutti gli snapshot e ripristina l'item corrente.
- `in-progress → abandoned`: richiede conferma; conserva eventi e risultati.
- `in-progress → completed`: richiede conferma esplicita e verifica delle condizioni di completamento.

Store in scrittura: `sessions`, `operationReceipts`.

### 6.6 `applyCorrection`

La correzione:
- aggiunge un record `eventCorrections`;
- non modifica l'evento originale;
- ricalcola le proiezioni conoscenza interessate;
- se invalida un evento consultato, invalida la priorità derivata senza cancellare la storia del consumo;
- conserva la sequenza di correzioni e l'eventuale annullamento.

Store in scrittura: `eventCorrections`, `knowledgeStates`, `consultationPriorities`, `operationReceipts`.

### 6.7 `publishCatalog`

La pubblicazione è atomica e valida prima del commit:
- unicità identità/versioni;
- coerenza tra catalogo, relazioni, definizioni e template;
- risoluzione di ogni componente obbligatorio;
- assenza di riferimenti a elementi dismessi per nuove domande;
- validità di `contentHash`;
- audit append-only e receipt.

Store in scrittura: `catalogVersions`, `catalogElements`, `catalogRelations`, `questionDefinitions`, `questionTemplates`, `catalogAudit`, `operationReceipts`.

## 7. Contratto delle priorità consultazione

La fonte storica è `exposureEvents`; `consultationPriorities` è una proiezione operativa.

Una priorità è applicabile solo se:
- deriva da un evento `consulted` ancora effettivo;
- il candidate è ancora attivo e compatibile con la versione di catalogo corrente;
- la sessione target è successiva, `adaptive` e della stessa tipologia;
- non è già stata consumata o invalidata.

Il selettore può dare precedenza a candidate prioritari solo dopo aver calcolato conteggi e quote. Non può:
- aumentare il totale richiesto;
- superare capienza categoria o strato;
- violare le quote finali;
- duplicare un candidate quando i duplicati non sono ammessi.

Se la priorità non trova posto nella selezione, resta `pending`. Se il candidate è dismesso o incompatibile, diventa `notApplicable`; non viene trasferita a `replacedBySemanticId`.

La ricostruzione delle priorità non riapre automaticamente quelle già consumate. Se una correzione successiva invalida l'evento sorgente, la proiezione registra l'invalidazione e conserva i riferimenti a sessione e tempo di consumo.

## 8. Contratto di persistenza e schema

Il repository deve rispettare esattamente `Schema_IndexedDB_Interrogazione_v1.2`:

- database `TenFingersTypingTrainer_Interrogation`;
- 14 object store: `catalogVersions`, `catalogElements`, `catalogRelations`, `questionDefinitions`, `questionTemplates`, `profileSettings`, `sessions`, `sessionItems`, `exposureEvents`, `eventCorrections`, `consultationPriorities`, `knowledgeStates`, `catalogAudit`, `operationReceipts`;
- keyPath, indici, unicità e ambito come definiti nello schema v1.2;
- timestamp interni Unix in millisecondi UTC;
- codici canonici per classificazioni, esiti e stati;
- nessuna eliminazione ordinaria di eventi, correzioni o audit;
- revisioni ottimistiche per record modificabili;
- `operationId` più hash canonico del payload per idempotenza;
- nessuna transazione aperta durante input utente, timer o chiamate esterne.

Le proiezioni `knowledgeStates` e `consultationPriorities` sono ricostruibili, ma la ricostruzione deve preservare versioni policy, fingerprint e storia di consumo.

## 9. Import/export, profili e confine LocalStorage

`ProfileManager` continua a essere il proprietario dei dati profilo già presenti in LocalStorage. Il repository Interrogazione gestisce soltanto i dati del proprio dominio IndexedDB.

Il pacchetto export deve includere almeno:
- `packageFormatVersion`;
- `appVersion`;
- `profileId`;
- `exportedAt`;
- `catalogVersion`;
- `profileData`;
- `interrogationData`.

L'import:
1. valida integralmente il pacchetto;
2. verifica versioni, chiavi, riferimenti e hash;
3. definisce conflitti prima di scrivere;
4. applica i dati Interrogazione in transazione;
5. applica i dati LocalStorage tramite `ProfileManager`;
6. verifica entrambi i risultati;
7. chiude il marker di recovery.

IndexedDB e LocalStorage non condividono una transazione. Il processo è recuperabile a fasi, non atomicamente distribuito.

**Adattamento baseline da pianificare:** `ProfileManager.importProfileData()` esegue la scrittura finale di `TFT_ACTIVE_USER` dopo il salvataggio del profilo e della lista utenti, ma il risultato di quella scrittura non è verificato. In implementazione va corretto con una modifica circoscritta e test di rollback/ripresa; non va riscritto l'intero `ProfileManager`.

La cancellazione profilo:
- richiede export completato e verificato secondo la policy concordata;
- rimuove solo i dati del profilo selezionato dagli store Interrogazione;
- non cancella catalogo condiviso o audit catalografico;
- non dichiara successo se una fase non è stata verificata;
- è isolata da tutti gli altri profili.

## 10. Errori applicativi canonici

| Codice | Significato | Comportamento |
|---|---|---|
| `DB_UNAVAILABLE` | IndexedDB non disponibile/apertura fallita | Bloccare operazioni persistenti; non simulare successo |
| `DB_UPGRADE_BLOCKED` | Upgrade bloccato da altra scheda | Richiedere chiusura/ricarica delle altre schede |
| `QUOTA_EXCEEDED` | Spazio storage insufficiente | Rollback e messaggio comprensibile |
| `PROFILE_NOT_FOUND` | Profilo inesistente | Nessuna scrittura |
| `SESSION_NOT_FOUND` | Sessione inesistente | Nessuna scrittura |
| `SESSION_STATE_CONFLICT` | Transizione non consentita | Conservare stato precedente |
| `REVISION_CONFLICT` | Revisione obsoleta | Rileggere e chiedere risoluzione |
| `IDEMPOTENCY_CONFLICT` | Stesso operationId con payload diverso | Rifiutare il comando |
| `DUPLICATE_OPERATION` | Comando già applicato con stesso payload | Restituire risultato precedente |
| `SEMANTIC_ID_CONFLICT` | Identità semantica con significato incompatibile | Non fondere automaticamente |
| `CATALOG_VALIDATION_FAILED` | Catalogo/template/relazioni incoerenti | Non pubblicare |
| `CANDIDATE_INVALID` | Candidate non risolvibile | Escludere con diagnostica; manuale bloccante |
| `INSUFFICIENT_CANDIDATES` | Elementi disponibili inferiori al richiesto | Avviso e scelta procedere/annullare |
| `SUBQUESTION_ALREADY_EVALUATED` | Sotto-quesito già valutato | Nessun secondo evento |
| `PRIORITY_NOT_APPLICABLE` | Priorità non più compatibile | Non trasferire a identità sostitutiva |
| `IMPORT_VALIDATION_FAILED` | Pacchetto non valido | Nessuna scrittura |
| `EXPORT_VERIFICATION_FAILED` | Export non verificato | Non autorizzare cancellazione |
| `RECOVERY_REQUIRED` | Operazione cross-storage incompleta | Riprendere o rollback secondo marker |

Gli errori tecnici dettagliati restano nel registro diagnostico. La UI e l'HELP mostrano messaggi orientati all'utente.

## 11. Gate tecnici prima dell'implementazione

I contratti sono allineati allo schema, ma i seguenti punti devono essere chiusi prima di dichiarare implementabile e riproducibile l'intero backend:

1. **PRNG:** scegliere algoritmo, versione, seed encoding e vettori noti; aggiornare selettore e snapshot.
2. **Calendario:** verificare la policy 1/3/7/14/30/60 giorni con il comportamento della baseline e completare i test di confine.
3. **Consultazione:** mantenere documentata la conseguenza matematica dei pesi correnti (contributo composito relativo 31,25% rispetto all'errore); nessuna modifica senza decisione.
4. **Catalogo 105 tasti:** completare e validare il catalogo; i dati mancanti non vanno inventati.
5. **Modificatori destri:** risolvere la discordanza tra associazioni dita e landmark prima di attivare i relativi candidate.
6. **Consolidamento:** formalizzare il contributo del fattore mancato consolidamento e i relativi eventi/policy.
7. **ProfileManager:** correggere in modo circoscritto la verifica di `TFT_ACTIVE_USER` e testare il processo cross-storage.
8. **Browser:** verificare IndexedDB, upgrade bloccati, quota, crash/recovery e concorrenza tra schede nei browser supportati.

Il completamento di questi gate non autorizza automaticamente una modifica sorgente: l'implementazione resta soggetta all'autorizzazione esplicita prevista dal protocollo di progetto.

## 12. Test di accettazione contrattuali

I test sono requisiti da implementare, non risultati già ottenuti.

| ID | Area | Verifica richiesta |
|---|---|---|
| API-01 | Repository | Apertura verifica tutti i 14 store e gli indici v1.2 |
| API-02 | Timestamp | Tutti i record interni usano millisecondi UTC |
| API-03 | Enumerazioni | Codici non canonici rifiutati |
| API-04 | Catalogo | Elementi/relazioni/definizioni/template coerenti per catalogVersion |
| API-05 | Candidate | Candidate ID stabile a parità di input/versioni |
| API-06 | Candidate | Template incompleto escluso con diagnostica |
| API-07 | Selettore random | Nessuna lettura di knowledge/priorità |
| API-08 | Selettore adaptive | Quote finali sommano 100% |
| API-09 | Quote D77–D80 | Budget globale 10 punti e tetto individuale rispettati |
| API-10 | Quote D77–D80 | Deficit nulli non generano supplemento/prelievo |
| API-11 | Quote D77–D80 | Residuo diventa quota neutra secondo regola |
| API-12 | Conteggi | Maggiori resti producono conteggi interi con somma esatta |
| API-13 | Priorità | Solo adattiva e stessa tipologia possono consumare |
| API-14 | Priorità | Solo candidate effettivamente inclusi consumano |
| API-15 | Priorità | Candidate non selezionato resta pending |
| API-16 | Sessione | Snapshot completo e item persistiti atomicamente |
| API-17 | Sessione | Ripresa non ricalcola selezione o snapshot |
| API-18 | Sessione | Una sola sessione sospesa per profilo |
| API-19 | Valutazione | Correct +3, incorrect 0, consulted +1 |
| API-20 | Valutazione | Non risposta e visualizzazione non generano eventi |
| API-21 | Valutazione | Seconda valutazione dello stesso sotto-quesito bloccata |
| API-22 | Valutazione | Evento, punteggio, knowledge e receipt atomici |
| API-23 | Knowledge | Decadimento 60 giorni solo nei calcoli |
| API-24 | Knowledge | Formula affidabilità e indice corretto verificata |
| API-25 | Knowledge | Classi e soglie 70/30 rispettate |
| API-26 | Knowledge | Correzione evento ricalcola proiezione senza alterare storico |
| API-27 | Calendario | Correct/incorrect/consulted/unanswered applicano regole concordate |
| API-28 | Idempotenza | Stesso ID/payload restituisce risultato precedente |
| API-29 | Idempotenza | Stesso ID/payload diverso genera conflitto |
| API-30 | Concorrenza | Revision mismatch non sovrascrive dati concorrenti |
| API-31 | Catalogo | Pubblicazione atomica; audit append-only |
| API-32 | Profilo | Nessuna lettura/scrittura cross-profile |
| API-33 | Import/export | Validazione completa prima della scrittura |
| API-34 | Recovery | Marker cross-storage consente ripresa/rollback |
| API-35 | Cancellazione | Rimuove solo dati profilo e preserva catalogo/audit |
| API-36 | Browser | Quota, upgrade bloccato, crash e concorrenza verificati |

## 13. Esito e sequenza d'implementazione raccomandata

I contratti sono ora allineati allo schema IndexedDB v1.2 per nomi degli store, chiavi, timestamp, codici, priorità, template, knowledge state e snapshot.

Sequenza d'implementazione raccomandata, subordinata alla chiusura dei gate:
1. validatori puri e convenzioni comuni;
2. `InterrogationRepository` e test IndexedDB;
3. `InterrogationCatalog` e seed versionato;
4. `InterrogationKnowledge` e test numerici;
5. `InterrogationSelector` dopo congelamento PRNG;
6. `InterrogationSessionManager` e transazioni;
7. adapter UI e integrazione circoscritta con `ProfileManager`;
8. test regressione, browser, import/export e recovery.

**Stato finale:** contratti progettuali v1.2 allineati allo schema fisico v1.2.  
**Implementazione:** non avviata.  
**Modifiche ai sorgenti:** nessuna.
