# Manuale Utente TenFingersTypingTrainer v6.53

Questa guida integra il manuale della versione 6.52 con gli aggiornamenti introdotti nella versione 6.53.

## 1. Grafico delle velocità più leggibile ed evidenziatore per modalità
- **Colori ben distinti e senza bordo bianco:** ogni modalità di esercizio utilizza ora un colore netto e ben separato dagli altri, senza il bordino bianco attorno ai pallini normali, così da distinguersi chiaramente anche nei tratti più affollati del grafico.
- **Ingrandimento rapido dal filtro:** passando il cursore del mouse sopra uno qualsiasi dei filtri in **"Filtra sessioni:"** (ad esempio *Custom*, *Random*, *Fonemi*), tutti i campioni di quella modalità vengono immediatamente ingranditi sul grafico mentre gli altri si attenuano, permettendo di individuare a colpo d'occhio dove si trovano.
