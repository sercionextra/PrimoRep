# Applicazione Strada A: Inserimento spigolo Verde-Arancione

L'utente ha scelto la 'Strada A': inserire lo spigolo Verde-Arancione presente sul tetto.
Questo inserimento risolverà lo slot Verde-Arancione e provocherà l'espulsione simultanea dell'eventuale pezzo incastrato, liberando l'ultimo spigolo (Blu-Rosso) per il completamento definitivo del secondo strato.
La sincronizzazione della conversazione è ora ristabilita.
