# 02 - Manuale Utente Dettagliato ed Ergonomia di Utilizzo (v.2.11)

---

## 1. Introduzione, Mission Dattilografica e Bontà del Metodo

Benvenuto in **Ten Fingers Typing Trainer (Web Edition SPA)**, l'ambiente di addestramento interattivo avanzato progettato per guidarti passo dopo passo nell'apprendimento della **digitazione alla cieca a dieci dita (Touch-Typing)** su tastiera italiana standard a 105 tasti (layout **QWERTY IT**).

```text
       ┌────────────────────────────────────────────────────────┐
       │             LA REGOLA D'ORO DEL TOUCH-TYPING           │
       │                                                        │
       │       "NON GUARDARE MAI LA TASTIERA FISICA!"          │
       │                                                        │
       │  I tuoi occhi devono rimanere costantemente rivolti     │
       │  allo schermo. L'applicazione proietta davanti a te    │
       │  tutte le informazioni visive, ergonomiche e sonore     │
       │  necessarie per guidare le tue dita al tasto esatto.   │
       └────────────────────────────────────────────────────────┘
```

### 1.1 Perché Imparare la Digitazione a 10 Dita?
La maggior parte delle persone che non hanno seguito un corso formale di dattilografia digita utilizzando il metodo "visivo a due dita" (o *hunting and pecking*):
- Gli occhi rimbalzano continuamente tra lo schermo, il foglio e i tasti fisici.
- Il collo e le spalle sono costantemente incurvati verso il basso, generando affaticamento muscolare e cefalee tensive.
- Il flusso cognitivo è costantemente interrotto: la mente deve pensare a "dove si trova la lettera" prima di formulare il pensiero.
- La velocità media raramente supera le 100-150 battute al minuto, con un tasso d'errore elevato.

Con il **metodo touch-typing a 10 dita**:
1. **Memoria Muscolare (Cinestetica)**: ogni dito acquisisce la competenza esclusiva di una specifica colonna di tasti. Le dita si muovono istintivamente, senza bisogno di controllo oculare.
2. **Fluidità Cognitiva Assoluta**: la scrittura diventa trasparente. Le parole fluiscono direttamente dalla mente allo schermo senza frizione motoria.
3. **Ergonomia e Salute**: la colonna vertebrale e il collo rimangono rilassati in posizione eretta con lo sguardo orizzontale.
4. **Produttività Raddoppiata o Triplicata**: un dattilografo addestrato raggiunge con naturalezza velocità tra le 250 e le 450 battute al minuto (50-90 parole al minuto) con un tasso d'errore inferiore all'1%.

### 1.2 La Posizione Fondamentale di Riposo (Home Row)
L'intera architettura del metodo si basa sulla **Riga Base (Home Row)**, la fila centrale della tastiera su cui le dita devono sempre riposare e a cui devono sempre fare ritorno dopo aver premuto un tasto superiore o inferiore:

```text
 Mano Sinistra:                         Mano Destra:
 ┌──────────┬──────────┬──────────┬──────────┐   ┌──────────┬──────────┬──────────┬──────────┐
 │ Mignolo  │ Anulare  │  Medio   │  Indice  │   │  Indice  │  Medio   │ Anulare  │ Mignolo  │
 │    A     │    S     │    D     │    F     │   │    J     │    K     │    L     │    Ò     │
 └──────────┴──────────┴──────────┴──────────┘   └──────────┴──────────┴──────────┴──────────┘
                         [ Pollici: Barra Spaziatrice ]
```

- **I Trattini Tattili in Rilievo**: sui tasti **`F`** e **`J`** sono presenti piccole barrette in rilievo percepibili al tatto. Servono a ricentrare istantaneamente entrambi gli indici sulla riga base senza mai guardare la tastiera!
- Ogni volta che muovi un dito verso l'alto (es. `R`, `E`, `T`, `U`, `I`) o verso il basso (es. `V`, `C`, `X`, `N`, `M`), quel dito deve **ritornare immediatamente alla sua posizione di guardia**.

---

## 2. Panoramica Generale dell'Interfaccia Utente (UI Walkthrough)

L'applicazione si presenta come una console di pilotaggio dattilografico completa, fluida e reattiva:

```text
+---------------------------------------------------------------------------------------------------------+
| [Header] Ten Fingers Typing Trainer (v.2.6)   Tema: [Dark Modern v]  Audio: [Typewriter v]  Vol: [====]  |
|          Profilo: [ALBERTO]  [Cambia Utente]  [Modifica Custom]  [Statistiche (ALT+S)]  [Guida (F1)]   |
+---------------------------------------------------------------------------------------------------------+
| [Toolbar 1] Modalità: [PHRASES (Frasi) v]  Lezione: [<] [Lezione 1: asdfl v] [>]  Sorgente: [Standard v]|
|             Range Frasi: [📖 Frasi: 1 - 21]       Esercizio: "asdfl - sala falsa"                       |
+---------------------------------------------------------------------------------------------------------+
| [Toolbar 2] Frase: [<] [>]  [📖 Vai a Frase... (Ctrl+Shift+E)]  [🔀 Casuale]  [🔄 Riavvia (Ctrl+Shift+X)]  |
|             [🔀 Rimescola (Ctrl+Shift+Z)]  [⌨️ Tutti i Tasti (Ctrl+Shift+4 o Ctrl+Shift+G)]               |
|             Mostra: [X] Tastiera (Ctrl+Shift+K) [X] Mani (Ctrl+Shift+M) [X] Guida [X] Input [ ] Autocorr|
+---------------------------------------------------------------------------------------------------------+
| [Area di Battitura]                                                                                    |
|                                       [ E R R O R E ] <- Badge Fluttuante Temporizzato (550 ms)        |
| Testo Guida: [ s a l a   f a l s a ] (il carattere bersaglio è evidenziato; gli errori si espandono in rosso) |
| Testo Utente: [ s a l _           ] (casella attiva a ricezione immediata)                             |
|                                                                                                         |
| [Pannello Metriche in Tempo Reale]                                                                     |
| Tempo: 00:14  |  Caratteri: 12  |  Netto: 185 BTM  |  Lordo: 192 BTM  |  Errori: 1  |  % Errore: 2.3%    |
+---------------------------------------------------------------------------------------------------------+
| [Finestra Fluttuante Tastiera 105 Tasti]            [Finestra Fluttuante Mani Anatomiche Vettoriali SVG]|
| +-----------------------------------------------+   +-------------------------------------------------+ |
| | [1][2][3][4][5][6][7][8][9][0]['][ì] [<-BKSP] |   | [⊕ Ricentra]                        [X Chiudi]  | |
| | [TAB] [Q][W][E][R][T][Y][U][I][O][P][é][*][INV]|   |          /---\   /---\     /---\   /---\        | |
| | [CAPS] [A][S][D][F][G][H][J][K][L][ò][à][ù]   |   |         | M | | | A | |   | I | | | M | |       | |
| | [SHIFT] [<][Z][X][C][V][B][N][M][,][.][-][SHF]|   |   (Polpastrelli con Keycaps 3D Ingranditi 1.5x) | |
| | [CTRL][WIN][ALT]    [  SPAZIO  ]    [ALTGR]   |   |      [ S ]   [ D ]       [ K ]   [ L ]          | |
| +-----------------------------------------------+   +-------------------------------------------------+ |
+---------------------------------------------------------------------------------------------------------+
```

### 2.1 Gestione delle Finestre Fluttuanti
Tutte le finestre ausiliarie (Tastiera, Mani, Statistiche, Editor Custom, Gestione Profili, Guida) sono finestre fluttuanti indipendenti:
- **Trascinamento Fluido (Drag & Drop)**: clicca e trascina la barra del titolo della finestra per spostarla ovunque desideri sul monitor.
- **Protezione Anti-Sforamento (Viewport Clamping)**: il sistema impedisce alle finestre di finire accidentalmente fuori dallo schermo o sotto le barre del browser.
- **Ridimensionamento Elastico (Resize)**: afferra la maniglia triangolare posizionata nell'angolo inferiore destro per ingrandire o rimpicciolire la finestra a piacere.
- **Finestra Completamente Resizable (v.2.11)**: tramite le 8 maniglie perimetrali (`.resize-handle`), l'utente può allargare, stringere o accorciare la finestra Mani. Il sistema sacrifica lo spazio vuoto esterno senza scalare né rimpicciolire il disegno anatomico delle mani o dei keycaps 3D; comprimendo verticalmente la finestra, la base dei polsi viene sacrificata e le etichette "MANO SINISTRA" e "MANO DESTRA" si alzano automaticamente per rimanere sempre perfettamente visibili.
- **Pulsante di Ripristino Default (`↺ Default`)**: posto sulla barra del titolo della finestra (`#btnHandsDefaultPos`), ripristina all'istante la dimensione ottimale standard (580x330 px) e la collocazione ergonomica affiancata subito a destra della tastiera virtuale.
- **Persistenza Automatica**: le coordinate `(left, top)` e le dimensioni `(width, height)` vengono salvate automaticamente nel profilo attivo dell'utente al termine di ogni spostamento.

---

## 3. Guida Dettagliata alle Sezioni e ai Controlli dell'Interfaccia

### 3.1 Barra Superiore (Header e Impostazioni Globali)
Posta in cima alla pagina, racchiude le preferenze di sistema e l'identità dell'utente:

1. **Selettore del Tema Grafico (`themeSelect`)**:
   - `Dark Modern` (predefinito): sfondo antracite scuro ad alto riposo visivo con tasti a contrasto calibrato.
   - `Light Classic`: sfondo chiaro tradizionale in stile WinForms/Office.
   - `High Contrast Matrix`: sfondo nero profondo con accenti verde fosforo ad altissimo contrasto per ipovedenti o ambienti luminosi.
2. **Configurazione Audio (`audioModeSelect`) e Cursore Volume**:
   - `Typewriter` (Macchina da scrivere meccanica): a ogni pressione di un tasto corretto produce il tipico "clac" metallico percussivo di una macchina per scrivere Underwood d'epoca, mentre a fine esercizio suona un brillante campanello metallico!
   - `Beep`: emette un segnale acustico elettronico sintetizzato (tono puro a 440 Hz) non appena viene premuto un tasto errato.
   - `Mute`: disabilita completamente qualsiasi suono per lavorare in ambienti silenziosi o con cuffie spente.
   - Lo slider orizzontale consente di regolare con continuità il volume da 0 a 100%.
3. **Badge Utente e Pulsante `Cambia Utente` (`btnHeaderSwitchUser`)**:
   - Mostra il profilo attivo (es. `ALBERTO`).
   - Cliccando sul pulsante si apre la **Finestra di Gestione Profili**, dove puoi creare un nuovo profilo nominativo, selezionarne uno esistente, cancellare i profili obsoleti oppure esportare e importare i tuoi dati su file in formato JSON o XML.
4. **Pulsanti di Utilità**:
   - `✏️ Modifica Custom` (`btnOpenCustomEditor`): apre l'ambiente di redazione degli esercizi personalizzati.
   - `📊 Statistiche (ALT+S)` (`btnOpenStats`): apre la sofisticata sala di analisi delle prestazioni.
   - `❓ Guida (F1)` (`btnHelpLink`): apre la guida rapida in linea.

---

### 3.2 Toolbar 1 - Percorso Didattico, Lezioni e Sorgente Dati
È la plancia di comando per navigare all'interno del programma pedagogico:

```text
[ Modalità: PHRASES (Frasi) v ]  [<] [Lezione 1: asdfl v] [>]  [Sorgente: Standard v]  [📖 Frasi: 1 - 21]
```

1. **Selettore della Modalità (`cboMode`)**: consente di passare in qualsiasi momento tra le 6 modalità di apprendimento (`PHRASES`, `RANDOM`, `FONEMI`, `ALL CHARS`, `TYPING`, `RANDOM THIS PHRASE`).
2. **Pulsanti Freccia Lezione (`<` e `>`) e Menu Lezioni (`cboLessons`)**:
   - Permettono di sfogliare in sequenza o scegliere a colpo sicuro una qualsiasi delle **70 Lezioni Didattiche Native**.
   - Le lezioni introducono i tasti gradualmente: partono dalla posizione base (`asdfl`), integrano i tasti centrali (`g`, `h`), le vocali superiori (`i`, `o`, `e`), le consonanti inferiori (`n`, `m`, `c`, `v`, `z`), le lettere accentate (`ò`, `à`, `ù`, `è`, `ì`), la punteggiatura (`.`, `,`, `'`), i tasti Shift, i numeri da `1` a `0`, e infine tutti i simboli complessi (`+`, `-`, `@`, `#`, `[`, `]`, `{`, `}`, ecc.).
3. **Pulsante Sorgente Lezioni (`btnToggleLessonSource`)**:
   - Commuta con un solo clic tra il corpus ufficiale (**Standard 70 Lezioni**) e il tuo archivio personale (**Custom File**).
4. **Badge Range Frasi Interattivo (`lblPhraseRange`)**:
   - Mostra quante frasi compongono la lezione attiva e quale intervallo occupano (ad esempio: `📖 Frasi: 1 - 21`).
   - **Interattività Completa**: questo badge è un pulsante interattivo! Posizionando il mouse noterai l'effetto hover e l'icona del cursore a manina: cliccandolo si aprirà immediatamente la finestra modale **"Vai a Frase..."**.

---

### 3.3 Toolbar 2 - Gestione Frasi, Azioni Rapide e Visibilità
Fornisce il controllo puntuale sulla frase in corso e sulla personalizzazione visiva dell'ambiente di lavoro:

```text
[<] [>]  [📖 Vai a Frase... (CTRL+SHIFT+E)]  [🔀 Frase Casuale (CTRL+SHIFT+A)]  [🔄 Riavvia Frase (CTRL+SHIFT+X)]
[🔀 Rimescola Frase (CTRL+SHIFT+Z)]  [⌨️ Tutti i Tasti (CTRL+SHIFT+4 / CTRL+SHIFT+G)]
[X] Tastiera (CTRL+SHIFT+K)   [X] Mani (CTRL+SHIFT+M)   [X] Testo Guida (CTRL+SHIFT+O)   [X] Digitato (CTRL+SHIFT+Y)   [ ] Autocorrezione (CTRL+SHIFT+B)
```

1. **Navigazione Frasi (`<` o `>` nella Toolbar 2, oppure `CTRL+SHIFT+ArrowLeft` / `CTRL+SHIFT+ArrowRight`)**: avanza o retrocede tra gli esercizi della stessa lezione.
2. **Pulsante `📖 Vai a Frase...` (`btnSelectPhraseModal` o scorciatoia `CTRL+SHIFT+E`)**:
   - Apre una comoda finestra modale in cui puoi digitare direttamente il numero della frase a cui desideri saltare.
   - La finestra include un menu a discesa delle lezioni (`selSelectPhraseLesson`) sincronizzato in tempo reale con la schermata principale.
3. **Pulsante `🔀 Frase Casuale` (`CTRL+SHIFT+A`)**: estrae a sorte una frase all'interno della lezione attiva, ideale per verificare se hai davvero memorizzato i tasti o se stai solo ripetendo a memoria l'ordine degli esercizi.
4. **Pulsante `🔄 Riavvia Frase` (`CTRL+SHIFT+X`)**: riazzera istantaneamente la frase corrente, riportando il cursore al primo carattere e resettando il cronometro e gli errori parziali.
5. **Pulsante `🔀 Rimescola Frase` (`CTRL+SHIFT+Z`)**: prende esattamente le lettere della frase in corso e ne scombina l'ordine (modalità *Random This Phrase*), costringendoti a leggere ogni singolo carattere.
6. **Pulsante `⌨️ Tutti i Tasti` (`CTRL+SHIFT+4` o `CTRL+SHIFT+G`)**: avvia un esercizio speciale a sorpresa che raggruppa tutti i caratteri della tastiera.
7. **Opzioni di Visibilità a Schermo**:
   - `Tastiera (CTRL+SHIFT+K)`: accende o spegne la finestra della tastiera virtuale.
   - `Mani (CTRL+SHIFT+M)`: accende o spegne la finestra anatomica delle mani.
   - `Testo Guida (CTRL+SHIFT+O)`: mostra o nasconde la riga con la frase proposta (per sfide avanzate di dettatura alla cieca).
   - `Digitato (CTRL+SHIFT+Y)`: mostra o nasconde la casella dove appaiono le tue battute.
8. **Opzione `Autocorrezione` (`CTRL+SHIFT+B`)**:
   - È la modalità di addestramento rigorosa per dattilografi professionisti.
   - Quando è attiva, **l'uso del tasto Backspace viene totalmente bloccato**: se premi il tasto sbagliato, la battuta non viene accettata, il cursore non avanza e il sistema attende che tu prema il tasto corretto prima di farti proseguire.

---

## 4. Gli Scopi Didattici dei Diversi Tipi di Esercizi (Le 6 Modalità)

Per garantire un apprendimento completo che stimoli sia la memoria cinestetica che la flessibilità visuo-spaziale, l'applicazione offre **6 modalità operative distinte**:

```text
+-----------------------+---------------------------------------------------------------------------------+
| Modalità              | Scopo Pedagogico e Meccanica Operativa                                          |
+-----------------------+---------------------------------------------------------------------------------+
| 1. PHRASES (Frasi)    | Apprendimento progressivo basato su parole e frasi di senso compiuto.           |
| (CTRL+SHIFT+1)        | Permette di interiorizzare le sequenze lessicali e il ritmo naturale del testo. |
+-----------------------+---------------------------------------------------------------------------------+
| 2. RANDOM (Caratteri) | Sequenze di 20 caratteri non lessicali con IPER-FREQUENZA della nuova lettera   |
| (CTRL+SHIFT+2)        | introdotta nella lezione. Forza la memorizzazione muscolare del nuovo tasto     |
|                       | impedendo al cervello di anticipare le parole per intuizione lessicale.          |
+-----------------------+---------------------------------------------------------------------------------+
| 3. FONEMI             | Costruzione di sequenze testuali da 100 caratteri assemblando fonemi e sillabe  |
| (CTRL+SHIFT+3)        | tipiche della lingua italiana (algoritmo N-gram). Costringe lo sguardo a seguire |
|                       | grafemi reali senza basarsi sul riconoscimento di parole preesistenti.          |
+-----------------------+---------------------------------------------------------------------------------+
| 4. ALL CHARS          | Sessione globale che rimescola l'intero alfabeto: lettere minuscole, maiuscole,  |
| (CTRL+SHIFT+4 / G)    | cifre 0-9, lettere accentate, punteggiatura e simboli complessi (@, #, [], {}). |
+-----------------------+---------------------------------------------------------------------------------+
| 5. TYPING (Libera)    | Foglio bianco senza testo guida prefissato. Mostra i singoli tasti e modificatori|
| (CTRL+SHIFT+5)        | sui polpastrelli in tempo reale. Ogni Backspace è contato come errore; al        |
|                       | termine l'utente può salvare la sessione con il pulsante "Aggiungi".            |
+-----------------------+---------------------------------------------------------------------------------+
| 6. RANDOM THIS PHRASE | Mantiene gli stessi identici caratteri della frase corrente ma ne scombina      |
| (CTRL+SHIFT+Z)        | la posizione. Ottimo per collaudare la padronanza della frase appena svolta.    |
+-----------------------+---------------------------------------------------------------------------------+
```

---

## 5. La Guida Visiva Ergonomica: Tastiera Virtuale e Mani con Keycaps 3D

La combinazione della **Tastiera a Colori** e delle **Mani Anatomiche SVG** rappresenta il cuore ergonomico dell'applicazione.

### 5.1 Codifica Cromatica Universale delle Dita
Sia sui tasti a schermo che sulle mani anatomiche viene applicata la medesima codifica cromatico-funzionale:

```text
- Dita 1 e 10 (Mignoli):       ROSSO          -> Tasti periferici, Shift, Invio, Tab, lettere A, Ò, P, Q, Z, ecc.
- Dita 2 e 9  (Anulari):       ARANCIONE      -> Lettere S, W, X e L, O, punto (.)
- Dita 3 e 8  (Medi):          VERDE SMERALDO -> Lettere D, E, C e K, I, virgola (,)
- Dita 4 e 7  (Indici):        BLU ELETTRICO  -> Lettere F, R, V, G, T, B e J, U, M, H, Y, N
- Dita 5 e 6  (Pollici):       VIOLA          -> Barra Spaziatrice e tasto AltGr
```

### 5.2 I Keycaps 3D Ingranditi 1.5x sui Polpastrelli
Nella finestra delle mani anatomiche, ogni polpastrello ospita un **Keycap 3D vettoriale** ad alta leggibilità:
- **Dimensioni Generose (87x78 px)**: ingranditi del 150% rispetto ai layout convenzionali, consentono una lettura periferica nitida e istantanea senza dover distogliere lo sguardo dal centro dello schermo.
- **Tipografia Ultra-Bold a 48 px**: il carattere impresso sul polpastrello è chiaramente distinguibile anche con la coda dell'occhio, protetto da un contorno scuro anti-alone da 6 px (`paint-order: stroke fill`).
- **Bordo Colorato da 4.8 px e Alone Volumetrico (Drop-Shadow a 16 px)**: ogni tasto proietta una morbida ombra volumetrica illuminata con il colore anatomico del dito preposto.
- **Adattamento Dinamico per Modificatori Lunghi**: per tasti con diciture estese (come `SPAZIO`, `SHIFT`, `INVIO`), il keycap espande automaticamente la sua larghezza fino a **174 px**, mantenendosi sempre perfettamente centrato sul polpastrello del pollice o del mignolo.

### 5.3 La Regola Ergonomica dei Modificatori Incrociati
Quando un carattere richiede l'uso del tasto **Shift (Maiusc)** per ottenere una maiuscola o un simbolo superiore:
- Se la lettera da battere appartiene alla **Mano Sinistra** (es. `A`, `S`, `D`, `F`, `R`, `E`):
  -> Il software ti indica di premere il tasto **Shift Destro** con il **Mignolo Destro (Dito 10)**.
- Se la lettera da battere appartiene alla **Mano Destra** (es. `J`, `K`, `L`, `I`, `O`, `P`):
  -> Il software ti indica di premere il tasto **Shift Sinistro** con il **Mignolo Sinistro (Dito 1)**.

Questa regola impedisce contorsioni innaturali di una sola mano per premere contemporaneamente Shift e lettera, mantenendo la posizione ergonomica e aumentando drasticamente la velocità di battitura.

### 5.4 Persistenza degli Accordi Fisici in Tempo Reale
L'applicazione riconosce la tastiera fisica come uno strumento polifonico:
- Quando premi e trattieni fisicamente un tasto (es. lo `Shift` sinistro), il polpastrello del rispettivo dito **rimane costantemente acceso** per tutto il tempo in cui il tasto è trattenuto.
- Se mentre mantieni abbassato il modificatore batti una sequenza di lettere con l'altra mano, ogni singola lettera si accende e si spegne in tempo reale sul polpastrello corrispondente, mentre il modificatore rimane costantemente illuminato.
- Il keycap del modificatore si spegnerà soltanto quando solleverai fisicamente il dito dal tasto della tastiera (`keyup`).

---

## 6. Comportamento Durante la Digitazione e Motore Didattico di Errore

Il motore didattico vigila costantemente sulla precisione di battitura, offrendo un triplice riscontro immediato:

```text
Digitazione Corretta:      [ s a l a   f a l s a ] -> Il cursore avanza fluido; i caratteri battuti si attenuano.
Errore Singolo:            [ s a l a   [f] a l s a ] -> Il carattere corrente assume uno sfondo ROSSO INTENSO.
Badge Fluttuante Errore:               [ E R R O R E ] -> Compare per 550 ms sopra il cursore indicando la lettera digitata!
Errori Consecutivi (3):    [ s a l a   [f a l] s a ] -> Lo sfondo ROSSO si espande a tutti e 3 i caratteri errati!
Sforamento Oltre la Fine:  [ s a l a   f a l s a [␣][␣] ] -> Vengono generati glifi di spazio fittizi rossi!
```

1. **Badge Fluttuante della Lettera Errata (`#wrongCharFloatingBadge`)**:
   - Nel momento esatto in cui batti un tasto errato, un badge fluttuante ad alto contrasto compare per **550 millisecondi** esattamente sopra il cursore del testo di battitura.
   - Il badge mostra la lettera che hai premuto per errore (oppure la parola `SPAZIO` se hai premuto erroneamente la barra spaziatrice), permettendoti di capire all'istante quale dito ha deviato senza dover guardare le mani!
2. **Espansione Cromatica Rossa dell'Errore (`char-error-target`)**:
   - Se commetti uno sbaglio e continui a digitare senza correggerti, il sistema estende la colorazione rossa a tanti caratteri quanti sono gli errori consecutivi commessi. In questo modo percepisci immediatamente l'entità della deviazione visiva.
3. **Glifi Fittizi di Spazio Rosso (`␣`)**:
   - Se digiti lettere errate oltre la fine del testo proposto, l'interfaccia sintetizza automaticamente glifi di spazio rosso evitando che il layout si rompa o che il testo scorra fuori visibilità.
4. **Comportamento Intelligente del Tasto Backspace**:
   - Premendo il tasto Backspace puoi cancellare a ritroso gli errori commessi. Lo sfondo rosso si ritira gradualmente fino a ripristinare il carattere corretto.
   - **Reset Completo a Inizio Frase con Arresto Timer**: se cancelli tutto il testo digitato fino a tornare alla primissima battuta (0 caratteri), **il sistema arresta automaticamente il cronometro della sessione** e ripristina la frase iniziale. In questo modo puoi prenderti una pausa o ripartire da capo senza che il calcolo delle battute al minuto (BTM) degradi verso lo zero a causa dei secondi di inattività!
5. **Vincolo Rigoroso di Completamento dell'Esercizio (v.2.11)**:
   - L'esercizio viene considerato concluso solo e soltanto quando **tutti i caratteri digitati corrispondono perfettamente alla frase originale e non vi sono errori residui**.
   - Se commetti errori durante la frase e arrivi in fondo digitando l'ultimo carattere, **l'esercizio non termina**: devi obbligatoriamente cancellare a ritroso con Backspace fino a eliminare le lettere errate e ribatterle correttamente.
   - Solo a correzione ultimata e al perfetto pareggio testuale, la casella si illumina di Verde Chiaro, suona la campana di vittoria, tutti i keycaps sulle mani si spengono istantaneamente tornando a riposo e il campione viene registrato.
6. **Invarianza Metrica dei Caratteri nel Testo Guida (v.2.11)**:
   - Quando una o più lettere si colorano di rosso per segnalare un errore (`char-error-target`), la larghezza del glifo a spaziatura fissa (monospace) rimane rigorosamente identica al carattere neutro. È stato eliminato qualsiasi scatto o spostamento orizzontale del testo rimanente.

---

## 7. Il Modulo Statistiche: Misurare e Analizzare i Propri Progressi

Accessibile tramite il pulsante `📊 Statistiche` nell'Header o premendo la scorciatoia **`ALT+S`**, la finestra Statistiche offre due potenti viste analitiche ingrandibili a tutto schermo:

### 7.1 Vista 1: Istogramma Frequenze ed Errori dei Singoli Caratteri
Visualizza un diagramma a barre verticali con una colonna per ciascuno dei caratteri che hai utilizzato durante gli esercizi. Ogni barra presenta due informazioni sovrapposte: la frequenza complessiva di battitura e la quota di errori commessi.

Puoi ordinare e raggruppare i dati secondo 6 criteri cliccando sui pulsanti radio dedicati:
1. `Frequenza (Err. Rel.)`: ordina dal carattere più digitato a quello meno digitato, mostrando il tasso d'errore percentuale.
2. `Frequenza (Err. Ass.)`: ordina per frequenza d'uso mostrando il numero totale di errori.
3. `Errori Relativi`: mette in cima alla lista i tasti sui quali sbagli più frequentemente in percentuale (i tuoi "tasti deboli").
4. `Errori Assoluti`: ordina i caratteri che contano il maggior numero assoluto di errori.
5. `Per Dito (Err. Rel.)`: raggruppa tutti i tasti in 8 macro-colonne anatomiche corrispondenti alle dita (esclusi i pollici), evidenziando quale dito necessita di ulteriore allenamento.
6. `Per Dito (Err. Ass.)`: raggruppamento per dito con somma assoluta degli errori.

### 7.2 Vista 2: Grafico Cronologico di Velocità Cartesiano
Mostra l'evoluzione temporale delle tue performance tracciando una curva continua attraverso tutti i campioni registrati:

- **Asse Y Selezionabile**:
  - `Battute/min`: mostra la tua velocità netta in Battute al Minuto (BTM/WPM).
  - `Caratteri`: mostra la lunghezza degli esercizi completati.
  - `% Errori Relativi`: visualizza l'andamento della precisione (con precisione naturale a un decimale: `NN.N%`).
  - `Errori Assoluti`: numero assoluto di errori commessi in ciascuna sessione.
- **I 7 Filtri Selettivi per Tipologia di Esercizio**:
  Puoi isolare esattamente le sessioni da analizzare selezionando o deselezionando le caselle di spunta:
  1. `Frasi Standard`: include i campioni delle 70 lezioni native.
  2. `Custom File`: include i campioni eseguiti sul tuo corso personalizzato.
  3. `Caratteri Casuali`: include i test della modalità RANDOM.
  4. `Digitazione Libera (Typing)`: include le sessioni salvate dal foglio libero.
  5. `Rimescola Frase`: include le sessioni di RANDOM THIS PHRASE.
  6. `Tutti i Tasti`: include le sessioni globali di ALL CHARS.
  7. `Fonemi Sillabici`: include i campioni della catena sillabica italiana.
- **Crosshair Mobile con Quota Y**: muovendo il mouse sul grafico, una linea orizzontale rossa segue il cursore mostrando un badge galleggiante che indica la quota numerica esatta del valore Y sotto il puntatore.
- **Selezione Cartesiana Intelligente a 3 Click**:
  - **1° Click (Intervallo)**: cliccando e trascinando sul grafico selezioni un intervallo di campioni. L'etichetta `lblMediaValori` calcola all'istante la velocità media del segmento selezionato.
  - **2° Click (Singolo Punto)**: cliccando su un punto isoli quel singolo campione, visualizzandone nel pannello data, ora, titolo dell'esercizio e parametri precisi.
  - **3° Click (Reset Globale)**: un terzo clic azzera la selezione e ripristina la media calcolata sull'intero archivio storico.
- **Pulsante `Cancella Selezione` (`btnClearSelection`)**: rimuove permanentemente dal dataset i soli campioni selezionati (utile se hai interrotto una sessione o vuoi eliminare un test anomalo).
- **Pulsante `Azzera Statistiche` (`btnResetAllStats` o scorciatoia `ALT+Z`)**: previa conferma, azzera l'intero archivio del profilo attivo per ripartire da zero.

---

## 8. Guida alla Creazione di Esercizi Personalizzati (Customization Guide)

L'applicazione include un potente modulo per creare i tuoi corsi didattici personalizzati (ad esempio per allenarti su codice di programmazione in Python o TypeScript, su terminologia medica, su brani letterari o su testi legali).

### 8.1 Apertura dell'Editor Custom
Clicca sul pulsante `✏️ Modifica Custom` nell'Header. Si aprirà la finestra dell'Editor, dotata di una casella di testo multilinea precompilata con un corso d'esempio.

### 8.2 La Sintassi dei File di Esercizi
La sintassi è estremamente semplice e basata sull'indicatore `=====` (cinque simboli di uguale):

```text
=====Nome del Capitolo o Lezione=====
Prima frase dell'esercizio.
=====
Seconda frase dell'esercizio.
Altra riga della medesima frase.
=====
=====Altra Lezione di Programmazione=====
const x = 10;
const y = 20;
=====
```

- **Intestazione di Sezione**: ogni riga racchiusa tra due blocchi di 5 uguali (es. `=====Python Base=====` o `=====Diritto Commerciale=====`) crea una nuova lezione separata all'interno del corso.
- **Separatore di Frase**: una riga contenente solo `=====` sancisce la fine della frase corrente e l'inizio della successiva.
- **Testi Multiriga e Rientri**:
  - Se una frase si sviluppa su più righe consecutive prima del successivo `=====`, il sistema unisce le righe visualizzando automaticamente il simbolo speciale `®` (che indica di premere il tasto **Invio**).
  - I rientri di 4 spazi o le tabulazioni vengono trasformati nel simbolo speciale `→` (che indica di premere il tasto **Tab**).

### 8.3 Salvataggio e Utilizzo
1. Dopo aver digitato o incollato il tuo testo, clicca su **`Salva nel Profilo`**. L'applicazione convaliderà la struttura e aggiornerà immediatamente il tuo profilo.
2. Chiudi l'editor e, nella Toolbar 1, premi il pulsante **`Sorgente: Standard`**: la dicitura cambierà in **`Sorgente: Custom`**.
3. Il menu delle lezioni mostrerà ora l'elenco dei capitoli personalizzati appena inseriti!
4. In qualsiasi momento puoi cliccare su **`Ripristina Esempio`** per ricaricare il modello predefinito.

---

## 9. Gestione dei Profili Utente e Salvataggio Dati

L'applicazione include un gestore multi-utente integrato, accessibile dal pulsante `Cambia Utente` nell'Header:

1. **Profili Multipli Indipendenti**:
   - Ogni utente ha il proprio archivio separato contenente lo storico di velocità, la mappa dei 106 caratteri, la lezione raggiunta, la modalità attiva e la posizione personalizzata delle finestre.
   - Per creare un nuovo utente, inserisci il nome nel campo `Nuovo Utente` e clicca su `Crea`.
2. **Esportazione e Salvataggio di Backup**:
   - **Esporta JSON**: genera un file compatto con l'intero database locale, ideale per trasferire i dati su un altro browser.
   - **Esporta XML**: produce un file conforme al 100% allo schema originario del software C# desktop (`DataSetArchivio.xsd`), consentendo il salvataggio o l'elaborazione esterna.
3. **Importazione Dati**:
   - Clicca su `Importa File` e seleziona un file JSON o XML precedentemente salvato per ripristinare all'istante l'intero archivio senza perdite.

---

## 10. Tavola Sinottica delle Scorciatoie da Tastiera (Quick Reference)

Per allenarsi come veri professionisti, tutte le funzioni operative sono attivabili da tastiera senza mai toccare il mouse:

| Scorciatoia Reale SPA | Controllo UI / Alternativa | Funzione Dattilografica |
| :---: | :---: | :--- |
| **F1** / `CTRL+SHIFT+H` | Pulsante [❓ Guida] | Apre la Guida Utente interattiva in linea (`help_(v.2.11).html`) |
| `CTRL+SHIFT+1` | Menu Modalità: 0 | Attiva la modalità **PHRASES (Frasi progressive)** |
| `CTRL+SHIFT+2` | Menu Modalità: 1 | Attiva la modalità **RANDOM (Caratteri casuali)** |
| `CTRL+SHIFT+3` | Menu Modalità: 2 | Attiva la modalità **FONEMI (Sillabario italiano N-gram)** |
| `CTRL+SHIFT+4` / `CTRL+SHIFT+G` | Menu Modalità: 3 | Attiva la modalità **ALL CHARS (Tutti i tasti della tastiera)** |
| `CTRL+SHIFT+5` | Menu Modalità: 4 | Attiva la modalità **TYPING (Digitazione libera con polpastrelli reattivi)** |
| `CTRL+SHIFT+Z` | Menu Modalità: 5 | Attiva la modalità **RANDOM THIS PHRASE (Rimescola frase)** |
| `CTRL+SHIFT+ArrowLeft` | `<` nella Toolbar 2 | Seleziona la **frase precedente** della lezione |
| `CTRL+SHIFT+ArrowRight` | `>` nella Toolbar 2 | Seleziona la **frase successiva** della lezione |
| `CTRL+SHIFT+ArrowUp` | Menu Lezioni (Toolbar 1) | Passa alla **lezione didattica precedente** |
| `CTRL+SHIFT+ArrowDown` | Menu Lezioni (Toolbar 1) | Passa alla **lezione didattica successiva** |
| `CTRL+SHIFT+X` | Pulsante [🔄 Riavvia] | **Ricomincia da capo** la frase attiva azzerando cronometro ed errori |
| `CTRL+SHIFT+A` | Pulsante [🎲 Casuale] | Estrae una frase a caso all'interno della lezione attiva |
| `CTRL+SHIFT+E` | Pulsante [📖 Vai a Frase...] | Apre la modale per saltare direttamente a una frase specifica |
| `CTRL+SHIFT+M` | Checkbox [Mani] | Mostra o nasconde la finestra fluttuante delle **Mani** ("10 Fingers") |
| `CTRL+SHIFT+K` | Checkbox [Tastiera] | Mostra o nasconde la finestra della **Tastiera virtuale** a 105 tasti |
| `CTRL+SHIFT+O` | Checkbox [Testo Guida] | Mostra o nasconde la riga del **Testo Guida** proposto |
| `CTRL+SHIFT+Y` | Checkbox [Input] | Mostra o nasconde la casella del **Testo Digitato** |
| `CTRL+SHIFT+B` | Checkbox [Auto-Correzione] | Attiva o disattiva l'Autocorrezione (blocco del Backspace) |
| `CTRL+SHIFT+S` | Pulsante [📊 Statistiche] | Apre o chiude la finestra cartesiana fullscreen delle **Statistiche** |
| `CTRL+SHIFT+U` | Pulsante [👤 Profilo] | Apre la modale per la gestione degli utenti e cambio profilo |

---

## 11. Consigli Pratici per una Progressione Rapida

1. **La Precisione Prima della Velocità**: non tentare di andare veloce all'inizio. Concentrati esclusivamente sul non commettere errori e sul premere ogni tasto con il dito corretto. La velocità aumenterà da sola, in modo naturale e senza sforzo, man mano che la memoria muscolare si consoliderà.
2. **Sessioni Brevi ma Costanti**: 15-20 minuti di esercitazione quotidiana costante producono risultati tre volte superiori rispetto a una maratona di 2 ore una sola volta alla settimana.
3. **Ascolta il Ritmo**: se usi l'audio in modalità `Typewriter`, cerca di ottenere un ticchettio regolare e costante come quello di un metronomo. Un ritmo uniforme riduce l'affaticamento e previene gli errori da precipitazione.
4. **Affronta i Tuoi Tasti Deboli**: consulta regolarmente l'istogramma delle statistiche ordinato per `Errori Relativi`. Se noti che lettere come `C`, `B`, `P` o le lettere accentate presentano un alto tasso di errore, dedicagli qualche sessione mirata in modalità `RANDOM` o `FONEMI`.
