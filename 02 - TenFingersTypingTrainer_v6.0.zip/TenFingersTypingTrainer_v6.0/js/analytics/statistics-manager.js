/* TenFingersTypingTrainer v6.0 | statistics-manager.js | Refactoring compatibile: comportamento sorgente preservato. */
class StatisticsManager {
  constructor(profileMgr) {
    this.profileMgr = profileMgr;
    this.sortMode = "freqRel"; // freqRel, freqAss, errRel, errAss, ditoRel, ditoAss
    this.speedMetric = "bpm"; // bpm, chars, errRel, errAss
    this.filterTypes = [1, 2, 3, 4, 5, 6, 7, 8];
    this.selectedSampleIndices = new Set();
    this.currentFilteredSamples = [];
  }

  renderHistogram() {
    const container = document.getElementById("statsHistogramSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Caratteri || p.Caratteri.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun dato statistico disponibile</div>';
      return;
    }

    // Process data
    let list = p.Caratteri.map((c) => ({
      char: String.fromCharCode(c.CharUnicode),
      freq: c.Frequenza || 0,
      err: c.Errori || 0,
      errRate: c.Frequenza > 0 ? (c.Errori / c.Frequenza) * 100 : 0,
      finger: (KEY_MAP[String.fromCharCode(c.CharUnicode)] || {}).finger || 0,
    }));

    // Sorting
    const isPerDito =
      this.sortMode === "ditoRel" || this.sortMode === "ditoAss";
    if (this.sortMode === "freqRel" || this.sortMode === "freqAss") {
      list.sort((a, b) => b.freq - a.freq);
    } else if (this.sortMode === "errRel") {
      list.sort((a, b) => b.errRate - a.errRate);
    } else if (this.sortMode === "errAss") {
      list.sort((a, b) => b.err - a.err);
    } else if (this.sortMode === "ditoRel") {
      list.sort(
        (a, b) => (a.finger || 99) - (b.finger || 99) || b.errRate - a.errRate,
      );
    } else if (this.sortMode === "ditoAss") {
      list.sort((a, b) => (a.finger || 99) - (b.finger || 99) || b.err - a.err);
    }

    const maxFreq = Math.max(1, ...list.map((x) => x.freq));
    const maxErr = Math.max(1, ...list.map((x) => x.err));
    const maxErrRate = Math.max(0.1, ...list.map((x) => x.errRate));

    const isErrRelMode =
      this.sortMode === "errRel" || this.sortMode === "ditoRel";
    const isErrAssMode =
      this.sortMode === "errAss" || this.sortMode === "ditoAss";

    const activeMax = isErrRelMode
      ? maxErrRate
      : isErrAssMode
        ? maxErr
        : maxFreq;

    // Risoluzione Dinamica : altezza determinata esattamente dallo spazio residuo della sezione
    const containerH = container.clientHeight || 200;
    const height = Math.max(140, containerH);

    const chartBaseline = height - 26;
    const topLimit = isPerDito ? 24 : 14;
    const maxBarH = Math.max(20, chartBaseline - topLimit - 6);

    const fingerMeta = {
      1: {
        name: "Mignolo Sx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
      2: {
        name: "Anulare Sx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      3: {
        name: "Medio Sx",
        color: "#10b981",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      4: {
        name: "Indice Sx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      5: {
        name: "Pollice Sx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      6: {
        name: "Pollice Dx",
        color: "#a855f7",
        fill: "rgba(168, 85, 247, 0.08)",
        stroke: "rgba(168, 85, 247, 0.6)",
      },
      7: {
        name: "Indice Dx",
        color: "#3b82f6",
        fill: "rgba(59, 130, 246, 0.08)",
        stroke: "rgba(59, 130, 246, 0.6)",
      },
      8: {
        name: "Medio Dx",
        color: "#10b981",
        fill: "rgba(16, 185, 129, 0.08)",
        stroke: "rgba(16, 185, 129, 0.6)",
      },
      9: {
        name: "Anulare Dx",
        color: "#f59e0b",
        fill: "rgba(245, 158, 11, 0.08)",
        stroke: "rgba(245, 158, 11, 0.6)",
      },
      10: {
        name: "Mignolo Dx",
        color: "#ef4444",
        fill: "rgba(239, 68, 68, 0.08)",
        stroke: "rgba(239, 68, 68, 0.6)",
      },
    };

    const barPitch = 36;
    const barWidth = 24;
    const startX = 20;
    const width = Math.max(760, list.length * barPitch + 40);

    let svg = `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" style="width:${width}px;min-width:${width}px;height:${height}px;display:block;">`;

    if (isPerDito) {
      let currentFinger = null;
      let groupStartIndex = 0;
      let groups = [];

      list.forEach((item, idx) => {
        if (item.finger !== currentFinger) {
          if (currentFinger !== null) {
            groups.push({
              finger: currentFinger,
              start: groupStartIndex,
              count: idx - groupStartIndex,
            });
          }
          currentFinger = item.finger;
          groupStartIndex = idx;
        }
      });
      if (currentFinger !== null) {
        groups.push({
          finger: currentFinger,
          start: groupStartIndex,
          count: list.length - groupStartIndex,
        });
      }

      groups.forEach((grp) => {
        const meta = fingerMeta[grp.finger] || {
          name: `Dito ${grp.finger}`,
          color: "#64748b",
          fill: "rgba(100, 116, 139, 0.08)",
          stroke: "rgba(100, 116, 139, 0.5)",
        };
        const gx = startX + grp.start * barPitch - 5;
        const gw = grp.count * barPitch;
        const gy = 4;
        const gh = chartBaseline - gy + 22;

        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="${gh}" rx="6" fill="${meta.fill}" stroke="${meta.stroke}" stroke-width="1.6" />`;
        svg += `<rect x="${gx}" y="${gy}" width="${gw}" height="17" rx="5" fill="${meta.color}" opacity="0.9" />`;
        svg += `<text x="${gx + gw / 2}" y="${gy + 12.5}" font-size="10" font-weight="700" fill="#ffffff" text-anchor="middle">${meta.name}</text>`;
      });
    }

    svg += `<line x1="6" y1="${chartBaseline}" x2="${width - 6}" y2="${chartBaseline}" stroke="var(--border-color)" stroke-width="1.5" />`;

    list.forEach((item, idx) => {
      const x = startX + idx * barPitch;
      const meta = fingerMeta[item.finger] || { color: "#3b82f6" };
      let primaryVal = item.freq;
      let displayVal = `${item.freq}`;

      if (isErrRelMode) {
        primaryVal = item.errRate;
        displayVal = `${item.errRate.toFixed(1)}%`;
      } else if (isErrAssMode) {
        primaryVal = item.err;
        displayVal = `${item.err}`;
      }

      const barH = activeMax > 0 ? (primaryVal / activeMax) * maxBarH : 0;
      const y = chartBaseline - barH;
      const barColor = isPerDito
        ? meta.color
        : isErrRelMode || isErrAssMode
          ? "#ef4444"
          : "#3b82f6";

      svg += `<g class="hist-bar" data-char="${htmlEscape(item.char)}" data-freq="${item.freq}" data-err="${item.err}" data-rate="${item.errRate.toFixed(1)}" data-finger="${meta.name || ""}">`;

      if (barH > 0) {
        svg += `<rect x="${x}" y="${y}" width="${barWidth}" height="${barH}" rx="3" fill="${barColor}" opacity="0.85" />`;
      }

      if (!isErrRelMode && !isErrAssMode && item.err > 0) {
        const errH = (item.err / maxFreq) * maxBarH;
        const errY = chartBaseline - errH;
        svg += `<rect x="${x}" y="${errY}" width="${barWidth}" height="${errH}" rx="3" fill="#ef4444" opacity="0.9" />`;
      }

      svg += `<text x="${x + barWidth / 2}" y="${chartBaseline + 17}" font-size="12.5" font-weight="700" text-anchor="middle" fill="var(--text-main)">${htmlEscape(item.char === " " ? "␣" : item.char)}</text>`;

      const labelY = Math.max(isPerDito ? 31 : 13, y - 4);
      svg += `<text x="${x + barWidth / 2}" y="${labelY}" font-size="9.5" font-weight="600" text-anchor="middle" fill="var(--text-muted)">${displayVal}</text>`;
      svg += `</g>`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    container.querySelectorAll(".hist-bar").forEach((bar) => {
      bar.addEventListener("mouseenter", () => {
        const c = bar.getAttribute("data-char");
        const f = bar.getAttribute("data-freq");
        const er = bar.getAttribute("data-err");
        const rt = bar.getAttribute("data-rate");
        const d = bar.getAttribute("data-finger");
        const dStr = d ? ` | Dito: ${d}` : "";
        document.getElementById("histTooltipText").innerText =
          `Tasto: "${c}" | Frequenza: ${f} | Errori: ${er} (${rt}%)${dStr}`;
      });
    });
  }

  getSampleVal(s) {
    if (this.speedMetric === "bpm") return s.BattuteMinuto || 0;
    if (this.speedMetric === "chars") return s.NumCaratteri || 0;
    if (this.speedMetric === "errRel")
      return s.NumCaratteri > 0 ? (s.NumErrori / s.NumCaratteri) * 100 : 0;
    if (this.speedMetric === "errAss") return s.NumErrori || 0;
    return s.BattuteMinuto || 0;
  }

  clearSelection() {
    this.selectedSampleIndices.clear();
    this.selectionState = 0;
    const selRect = document.getElementById("chartSelectionRect");
    if (selRect) selRect.style.display = "none";
    document.querySelectorAll(".speed-point").forEach((dot) => {
      dot.classList.remove("selected");
      dot.setAttribute("fill", "#3b82f6");
      dot.setAttribute("r", "4");
    });

    const btnClearSel = document.getElementById("btnClearSelection");
    const btnClearNotSel = document.getElementById("btnClearNotSelected");
    if (btnClearSel) btnClearSel.style.visibility = "hidden";
    if (btnClearNotSel) btnClearNotSel.style.visibility = "hidden";

    if (this.currentFilteredSamples.length > 0) {
      const vals = this.currentFilteredSamples.map((s) => this.getSampleVal(s));
      const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
      document.getElementById("lblMediaValori").innerHTML =
        `${avg} (globale su ${this.currentFilteredSamples.length} campioni)`;
    }
  }

  // =======================================================
  // PARSER E VALIDATORE RANGE DATA-ORA
  // =======================================================
  parseDateTimeRange() {
    const elDateA = document.getElementById("filterStartDate");
    const elTimeB = document.getElementById("filterStartTime");
    const elDateC = document.getElementById("filterEndDate");
    const elTimeD = document.getElementById("filterEndTime");
    const msgEl = document.getElementById("lblDateRangeValidationMessage");

    const clearInputErrors = () => {
      [elDateA, elTimeB, elDateC, elTimeD].forEach((inp) => {
        if (inp) {
          inp.classList.remove("input-field-error");
          inp.classList.toggle("filter-active", inp.value.trim().length > 0);
        }
      });
      if (msgEl) {
        msgEl.style.display = "none";
        msgEl.textContent = "";
      }
    };

    // Helper: assegna la classe di errore e rimuove contestualmente lo stato attivo
    const markError = (inp) => {
      if (!inp) return;
      inp.classList.add("input-field-error");
      inp.classList.remove("filter-active");
    };

    if (!elDateA || !elTimeB || !elDateC || !elTimeD) {
      return {
        isValid: true,
        hasFilter: false,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    clearInputErrors();

    const valA = elDateA.value.trim(); // YYYY-MM-DD
    const valB = elTimeB.value.trim(); // HH:mm
    const valC = elDateC.value.trim(); // YYYY-MM-DD
    const valD = elTimeD.value.trim(); // HH:mm

    const hasA = valA.length > 0;
    const hasB = valB.length > 0;
    const hasC = valC.length > 0;
    const hasD = valD.length > 0;

    // Caso 1: Nessun filtro attivo
    if (!hasA && !hasB && !hasC && !hasD) {
      return {
        isValid: true,
        hasFilter: false,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    // Regola 6: Vincolo asimmetrico
    if (hasA && hasD && !hasC) {
      markError(elDateC);
      markError(elTimeD);
      if (msgEl) {
        msgEl.textContent =
          "⚠ Specificare la data di fine per applicare il filtro temporale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    if (hasC && hasB && !hasA) {
      markError(elDateA);
      markError(elTimeB);
      if (msgEl) {
        msgEl.textContent =
          "⚠ Specificare la data di inizio per applicare il filtro temporale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    const todayObj = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const todayStr = `${todayObj.getFullYear()}-${pad(todayObj.getMonth() + 1)}-${pad(todayObj.getDate())}`;

    let startTs = 0;
    let endTs = todayObj.getTime();

    const areDatesMissing = !hasA && !hasC;

    if (areDatesMissing) {
      if (hasB && !hasD) {
        startTs = new Date(`${todayStr}T${valB}:00`).getTime();
        endTs = todayObj.getTime();
      } else if (!hasB && hasD) {
        startTs = new Date(`${todayStr}T00:00:00`).getTime();
        endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
      } else if (hasB && hasD) {
        startTs = new Date(`${todayStr}T${valB}:00`).getTime();
        endTs = new Date(`${todayStr}T${valD}:59.999`).getTime();
      }
    } else {
      if (hasA) {
        const timePart = hasB ? `${valB}:00` : "00:00:00";
        startTs = new Date(`${valA}T${timePart}`).getTime();
      } else {
        startTs = 0;
      }

      if (hasC) {
        const timePart = hasD ? `${valD}:59.999` : "23:59:59.999";
        endTs = new Date(`${valC}T${timePart}`).getTime();
      } else {
        endTs = todayObj.getTime();
      }
    }

    // Regola 9: Inversione cronologica (Inizio > Fine)
    if (startTs > endTs) {
      if (hasA) markError(elDateA);
      if (hasB) markError(elTimeB);
      if (hasC) markError(elDateC);
      if (hasD) markError(elTimeD);

      if (!hasA && hasB) markError(elTimeB);
      if (!hasC && hasD) markError(elTimeD);

      if (msgEl) {
        msgEl.textContent =
          "⚠ La data/ora iniziale non può essere successiva a quella finale.";
        msgEl.style.display = "block";
      }
      return {
        isValid: false,
        hasFilter: true,
        minTs: -Infinity,
        maxTs: Infinity,
      };
    }

    return { isValid: true, hasFilter: true, minTs: startTs, maxTs: endTs };
  }

  // Rendering Grafico Cronologico Velocità con Filtro Temporale e Giorno della Settimana
  renderSpeedChart() {
    const container = document.getElementById("statsSpeedSvgBox");
    if (!container) return;
    const p = this.profileMgr.profile;
    if (!p || !p.Campioni || p.Campioni.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione di velocità registrato</div>';
      this.clearSelection();
      return;
    }

    // Valutazione range temporale
    const rangeResult = this.parseDateTimeRange();
    if (!rangeResult.isValid) {
      return;
    }

    let filtered = p.Campioni.filter((s) =>
      this.filterTypes.includes(s.TipoCampione),
    );

    // Applicazione del filtro data-ora
    if (rangeResult.hasFilter) {
      filtered = filtered.filter((s) => {
        let sampleTs = 0;
        if (s.DataOra) {
          sampleTs = new Date(s.DataOra).getTime();
          if (isNaN(sampleTs)) sampleTs = 0;
        }
        return sampleTs >= rangeResult.minTs && sampleTs <= rangeResult.maxTs;
      });
    }

    this.currentFilteredSamples = filtered;
    if (filtered.length === 0) {
      container.innerHTML =
        '<div style="display:flex;height:100%;align-items:center;justify-content:center;color:var(--text-muted);">Nessun campione corrisponde ai filtri selezionati</div>';
      this.clearSelection();
      return;
    }

    // Risoluzione Dinamica: assorbimento al 100% dell'altezza residua con maggiore risoluzione
    const W = Math.max(760, container.clientWidth || 760);
    const containerH = container.clientHeight || 200;
    const H = Math.max(140, containerH);

    // padL calibrato a 54px per accogliere il font raddoppiato a 22px senza clipping a sinistra
    const padL = 54;
    const padR = 25;
    const padT = 16;
    const padB = 26;
    const plotW = W - padL - padR;
    const plotH = Math.max(20, H - padT - padB);

    const values = filtered.map((s) => this.getSampleVal(s));
    const maxVal = Math.max(10, Math.ceil(Math.max(...values) * 1.15));

    const pts = filtered.map((s, idx) => {
      const x = padL + (idx / Math.max(1, filtered.length - 1)) * plotW;
      const y = padT + plotH - (this.getSampleVal(s) / maxVal) * plotH;
      return { x, y, sample: s, val: this.getSampleVal(s), idx };
    });

    let pathD = "";
    pts.forEach((pt, i) => {
      pathD += (i === 0 ? "M " : "L ") + `${pt.x},${pt.y} `;
    });

    // L'SVG scala ed occupa sempre il 100% dello spazio verticale del box
    let svg = `<svg id="speedSvgPlot" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:100%;cursor:crosshair;user-select:none;display:block;">`;

    for (let g = 0; g <= 4; g++) {
      const gy = padT + (plotH / 4) * g;
      const valLabel = Math.round(maxVal - (maxVal / 4) * g);
      svg += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="var(--border-color)" stroke-dasharray="3 3" />`;
      svg += `<text x="${padL - 8}" y="${gy + 4}" font-size="10" text-anchor="end" fill="var(--text-muted)">${valLabel}</text>`;
    }

    svg += `<path d="${pathD}" fill="none" stroke="#3b82f6" stroke-width="2.5" />`;
    svg += `<rect id="chartSelectionRect" x="0" y="${padT}" width="0" height="${plotH}" fill="rgba(59, 130, 246, 0.22)" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4 3" style="display:none;pointer-events:none;" />`;
    svg += `<line id="chartCrosshairH" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2" style="display:none;pointer-events:none;" />`;
    // Font raddoppiato a 22px con dominant-baseline="central" per perfetto allineamento ottico
    svg += `<text id="chartCrosshairYLabel" fill="#ef4444" font-size="22" font-weight="800" text-anchor="end" dominant-baseline="central" style="display:none;pointer-events:none;"></text>`;
    svg += `<line id="chartPreviewVLine" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="3 3" style="display:none;pointer-events:none;" />`;

    const italianWeekDays = [
      "domenica",
      "lunedì",
      "martedì",
      "mercoledì",
      "giovedì",
      "venerdì",
      "sabato",
    ];

    pts.forEach((pt) => {
      const isSel = this.selectedSampleIndices.has(pt.sample.Index);
      const dotCls = isSel ? "speed-point selected" : "speed-point";

      // Formattazione data con giorno della settimana in italiano
      let dateFormatted = "Storico pre-v.2.30";
      if (pt.sample.DataOra) {
        const d = new Date(pt.sample.DataOra);
        if (!isNaN(d.getTime())) {
          const dayName = italianWeekDays[d.getDay()];
          const timeClean = pt.sample.DataOra.replace("T", " ");
          dateFormatted = `${dayName} ${timeClean}`;
        } else {
          dateFormatted = pt.sample.DataOra.replace("T", " ");
        }
      }

      svg += `<circle class="${dotCls}" cx="${pt.x}" cy="${pt.y}" r="${isSel ? 6 : 4}" fill="${isSel ? "#f59e0b" : "#3b82f6"}" stroke="#ffffff" stroke-width="1.5" data-idx="${pt.sample.Index}" data-val="${Math.round(pt.val)}" data-err="${pt.sample.NumErrori}" data-len="${pt.sample.NumCaratteri}" data-title="${htmlEscape(pt.sample.Esercizio || "")}" data-time="${htmlEscape(dateFormatted)}" />`;
    });

    svg += `</svg>`;
    container.innerHTML = svg;

    const svgEl = document.getElementById("speedSvgPlot");
    if (!svgEl) return;

    // Helper di formattazione per lo scrubber temporale
    const formatScrubberDate = (sample) => {
      if (!sample || !sample.DataOra) return "Data non disponibile";
      const d = new Date(sample.DataOra);
      if (isNaN(d.getTime())) return "Data non disponibile";
      const dayName = italianWeekDays[d.getDay()];
      const [datePart, timePart] = sample.DataOra.split("T");
      return `${datePart} - ${timePart} ( ${dayName} )`;
    };

    const scrubberLabel = document.getElementById("lblChartScrubberTimestamp");
    if (scrubberLabel) {
      scrubberLabel.textContent = "Sposta il mouse sul grafico";
    }

    svgEl.querySelectorAll(".speed-point").forEach((dot) => {
      dot.addEventListener("mouseenter", () => {
        // Rimuove lo stato ispezionato da tutti gli altri campioni
        svgEl
          .querySelectorAll(".speed-point.inspected")
          .forEach((el) => el.classList.remove("inspected"));
        // Aggiunge priorità visiva verde al campione corrente (v.2.32)
        dot.classList.add("inspected");

        const idx = dot.getAttribute("data-idx");
        const val = dot.getAttribute("data-val");
        const err = parseInt(dot.getAttribute("data-err") || "0", 10);
        const len = parseInt(dot.getAttribute("data-len") || "0", 10);
        const title = dot.getAttribute("data-title");
        const timeStr = dot.getAttribute("data-time") || "";
        const errPct = len > 0 ? ((err / len) * 100).toFixed(1) + "%" : "0.0%";

        // Applicazione colore dinamico temattizzato (var(--success-color)) sul valore testuale (v.2.32)
        document.getElementById("speedInspectText").innerHTML =
          `Campione #${idx} | Data: ${timeStr} | Valore: <span style="color: var(--success-color); font-weight: 800;">${val}</span> | Errori: ${err} (${errPct}) | Caratteri: ${len} | Esercizio: "${title}"`;
      });
    });

    this.selectionState = 0;
    let startSvgX = 0;

    const getSvgCoords = (e) => {
      const pt = svgEl.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      return pt.matrixTransform(svgEl.getScreenCTM().inverse());
    };

    const applySelection = (selPts) => {
      this.selectedSampleIndices = new Set(selPts.map((p) => p.sample.Index));
      svgEl.querySelectorAll(".speed-point").forEach((dot) => {
        const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
        if (this.selectedSampleIndices.has(sIdx)) {
          dot.classList.add("selected");
          dot.setAttribute("fill", "#f59e0b");
          dot.setAttribute("r", "6");
        } else {
          dot.classList.remove("selected");
          dot.setAttribute("fill", "#3b82f6");
          dot.setAttribute("r", "4");
        }
      });

      if (selPts.length > 0) {
        const selVals = selPts.map((p) => p.val);
        const avg = Math.round(
          selVals.reduce((a, b) => a + b, 0) / selVals.length,
        );
        const countTxt =
          selPts.length === 1
            ? "1 campione selezionato"
            : `${selPts.length} campioni selezionati`;
        document.getElementById("lblMediaValori").innerHTML =
          `<span style="color:#f59e0b;font-weight:800;">${avg}</span> (su ${countTxt})`;

        const btnClearSel = document.getElementById("btnClearSelection");
        const btnClearNotSel = document.getElementById("btnClearNotSelected");
        const countNot = filtered.length - selPts.length;

        if (btnClearSel) {
          btnClearSel.style.visibility = "visible";
          document.getElementById("lblSelectedCount").innerText = selPts.length;
        }
        if (btnClearNotSel) {
          btnClearNotSel.style.visibility = countNot > 0 ? "visible" : "hidden";
          document.getElementById("lblNotSelectedCount").innerText = countNot;
        }
      } else {
        this.clearSelection();
      }
    };

    svgEl.addEventListener("mousemove", (e) => {
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const curY = Math.max(padT, Math.min(padT + plotH, svgPt.y));

      // Stima del campione più vicino lungo l'asse X per la riga azzurra
      if (pts.length > 0 && scrubberLabel) {
        let closestPt = pts[0];
        let minDist = Math.abs(pts[0].x - curX);
        for (let i = 1; i < pts.length; i++) {
          const dist = Math.abs(pts[i].x - curX);
          if (dist < minDist) {
            minDist = dist;
            closestPt = pts[i];
          } else if (pts[i].x > curX) {
            break;
          }
        }
        scrubberLabel.textContent = formatScrubberDate(closestPt.sample);
      }

      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH && crossY) {
        const yVal = Math.round(maxVal - ((curY - padT) / plotH) * maxVal);
        crossH.setAttribute("x1", padL);
        crossH.setAttribute("y1", curY);
        crossH.setAttribute("x2", W - padR);
        crossH.setAttribute("y2", curY);
        crossH.style.display = "block";

        crossY.setAttribute("x", padL - 8);
        crossY.setAttribute("y", curY);
        crossY.textContent = yVal;
        crossY.style.display = "block";
      }

      const vLine = document.getElementById("chartPreviewVLine");
      const selRect = document.getElementById("chartSelectionRect");

      if (this.selectionState === 0) {
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      } else if (this.selectionState === 1) {
        if (vLine) vLine.style.display = "none";
        const minX = Math.max(padL, Math.min(startSvgX, curX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, curX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(2, selW));
          selRect.style.display = "block";
        }

        let previewPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          previewPts = [closest];
        } else {
          previewPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        svgEl.querySelectorAll(".speed-point").forEach((dot) => {
          const sIdx = parseInt(dot.getAttribute("data-idx"), 10);
          if (previewPts.some((p) => p.sample.Index === sIdx)) {
            dot.setAttribute("fill", "#f59e0b");
            dot.setAttribute("r", "6");
          } else {
            dot.setAttribute("fill", "#3b82f6");
            dot.setAttribute("r", "4");
          }
        });
      }
    });

    svgEl.addEventListener("mouseleave", () => {
      const crossH = document.getElementById("chartCrosshairH");
      const crossY = document.getElementById("chartCrosshairYLabel");
      if (crossH) crossH.style.display = "none";
      if (crossY) crossY.style.display = "none";
      const vLine = document.getElementById("chartPreviewVLine");
      if (vLine && this.selectionState === 0) vLine.style.display = "none";

      if (scrubberLabel) {
        scrubberLabel.textContent = "Sposta il mouse sul grafico";
      }

      // Ripristino stato ispezionato e testuale all'uscita dal grafico (v.2.32)
      svgEl
        .querySelectorAll(".speed-point.inspected")
        .forEach((el) => el.classList.remove("inspected"));
      const inspectText = document.getElementById("speedInspectText");
      if (inspectText) {
        inspectText.innerHTML =
          "Passa con il mouse sui campioni per le coordinate";
      }
    });

    svgEl.addEventListener("click", (e) => {
      if (e.button !== 0) return;
      const svgPt = getSvgCoords(e);
      const curX = Math.max(padL, Math.min(W - padR, svgPt.x));
      const selRect = document.getElementById("chartSelectionRect");
      const vLine = document.getElementById("chartPreviewVLine");

      if (this.selectionState === 0) {
        this.selectionState = 1;
        startSvgX = curX;
        if (vLine) vLine.style.display = "none";
        if (selRect) {
          selRect.setAttribute("x", startSvgX);
          selRect.setAttribute("width", 2);
          selRect.style.display = "block";
        }
        document.getElementById("lblMediaValori").innerHTML =
          `<span style="color:#3b82f6;font-style:italic;">Seleziona il secondo punto...</span>`;
      } else if (this.selectionState === 1) {
        this.selectionState = 2;
        const endSvgX = curX;
        const minX = Math.max(padL, Math.min(startSvgX, endSvgX));
        const maxX = Math.min(W - padR, Math.max(startSvgX, endSvgX));
        const selW = Math.max(0, maxX - minX);

        if (selRect) {
          selRect.setAttribute("x", minX);
          selRect.setAttribute("width", Math.max(4, selW));
          selRect.style.display = "block";
        }

        let selPts = [];
        if (selW <= 14 && pts.length > 0) {
          let closest = pts[0];
          let minDist = Math.abs(pts[0].x - minX);
          for (const p of pts) {
            const d = Math.abs(p.x - minX);
            if (d < minDist) {
              minDist = d;
              closest = p;
            }
          }
          selPts = [closest];
          if (selRect) {
            selRect.setAttribute("x", closest.x - 8);
            selRect.setAttribute("width", 16);
          }
        } else {
          selPts = pts.filter((p) => p.x >= minX && p.x <= maxX);
        }

        applySelection(selPts);
      } else if (this.selectionState === 2) {
        this.selectionState = 0;
        this.clearSelection();
        if (selRect) selRect.style.display = "none";
        if (vLine) {
          vLine.setAttribute("x1", curX);
          vLine.setAttribute("y1", padT);
          vLine.setAttribute("x2", curX);
          vLine.setAttribute("y2", padT + plotH);
          vLine.style.display = "block";
        }
      }
    });

    if (this.selectedSampleIndices.size === 0) {
      const avg = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
      document.getElementById("lblMediaValori").innerText =
        `${avg} (globale su ${values.length} campioni)`;
    }
  }
}
