# Documento Conclusivo di Sintesi Tecnica e Specifica Architetturale (Versioni 1.1 - 1.3)

**Progetto**: Porting Web SPA di *Ten Fingers Typing Trainer* (C# WinForms 2003 -> TypeScript/HTML5 Web Edition)  
**Ambito**: Sintesi Tecnica Completa delle Modifiche Approvate ed Implementate nella Chat  
**Data di Rilascio**: 30 Marzo 2026  
**File Sorgenti di Riferimento in `/workspace`**:
- `index_(v.1.1).html` / `help_(v.1.1).html` (Risoluzione Blocchi Critici e BlinkTimer)
- `index_(v.1.2).html` / `help_(v.1.2).html` (Riga Continua, Puntamento Badge, Selezione Grafico e Finestra Ridimensionabile)
- `index_(v.1.3).html` / `help_(v.1.3).html` (Esercizi Custom, Feedback Tasti Speciali, Rilevamento Errori e Centratura Palmi SVG)

---

## 1. Obiettivi del Progetto e Filosofia di Porting

Il progetto ha l'obiettivo di realizzare il porting fedele, moderno e reattivo della storica applicazione desktop Windows Forms del 2003 (*Ten Fingers Typing Trainer*, ideata da Alberto Modenese) in un'applicazione web moderna ad architettura **Single Page Application (SPA)**, priva di dipendenze runtime esterne e avviabile localmente al semplice doppio clic nel browser.

### Principi Architetturali Fondamentali
1. **Autonomia Totale (Zero Dependencies / Zero Build Step)**:
   L'applicazione è interamente racchiusa in un singolo file HTML contenente stili CSS, grafica vettoriale SVG e codice JavaScript compilato (target ECMAScript 2020), funzionante sia su protocollo `file:///` sia via server HTTP.
2. **Preservazione Integrale del Patrimonio Dati**:
   - Mantenimento delle 70 lezioni propedeutiche standard e del corpus fonetico italiano.
   - Piena compatibilità con l'archivio storico dell'utente master "ALBERTO", comprendente 439 campioni storici di velocità e parametri di configurazione.
   - Struttura dei dati persistita su `localStorage` compatibile con lo schema dati originale C#.
3. **Ergonomia e Fedeltà Comportamentale**:
   - Riscontro visivo delle dita sulla finestra fluttuante delle mani.
   - Evidenziazione dinamica dei tasti bersaglio e riscontro fisico dei tasti premuti.
   - Motore audio sintetico Web Audio API che riproduce fedelmente il tocco della macchina da scrivere, l'avvisatore d'errore e la campanella di fine riga.

---

## 2. Quadro Sinottico delle Versioni Rilasciate

| Versione | Focus Principale | Deliverable Codice | Deliverable Guida | Deliverable Documentale |
|:---:|---|---|---|---|
| **v.1.1** | Risoluzione 5 blocchi critici v.1.0, ripristino `AppController`, animazione pulsante bersaglio (*BlinkTimer*). | `index_(v.1.1).html` | `help_(v.1.1).html` | `05 - ... (v.1.1).md` |
| **v.1.2** | Riga guida continua, mira verticale badge rosso, scorciatoia `CTRL+SHIFT+H`, finestra Statistiche ridimensionabile a 8 vie, selezione ad area drag-to-select su grafico con eliminazione mirata. | `index_(v.1.2).html` | `help_(v.1.2).html` | `06 - ... (v.1.2).md` |
| **v.1.3** | Integrazione esercizi custom multilinea (Invio e Tab), illuminazione azzurra di 10 tasti speciali con gestione errori fuori luogo, ricentratura anatomica palmi mani SVG. | `index_(v.1.3).html` | `help_(v.1.3).html` | `07 - ... (v.1.3).md` |

---

## 3. Dettaglio Tecnico di Tutte le Modifiche Implementate

### 3.1 Risoluzione Criticità e Ripristino Architetturale (Versione 1.1)

#### 3.1.1 Causa Radice del Blocco Totale di v.1.0
Nel file originario `index_(v.1.0).html` la dichiarazione della classe orchestratrice `AppController` era rimasta tronca a causa di una precedente interruzione della generazione del codice. All'evento `DOMContentLoaded`, la chiamata `new AppController(...)` sollevava l'eccezione non gestita:
```
ReferenceError: AppController is not defined
```
Tale errore bloccava l'esecuzione dell'intero thread JavaScript, impedendo l'avvio dell'applicazione (`app.start()`), l'auto-login dell'utente, l'aggancio di tutti gli event listener della UI, il drag & drop delle finestre fluttuanti e l'ascolto della tastiera fisica. In aggiunta, la funzione di utilità `htmlEscape` risultava assente durante il rendering degli SVG statistici.

#### 3.1.2 Interventi Applicati in v.1.1
- **Ricostruzione di `AppController`**:
  - `start()`: sequenza ordinata di avvio e auto-login non bloccante.
  - `loginUser(userId)`: valorizzazione badge `Utente: ALBERTO`, applicazione tema grafico, parametri audio e caricamento campioni storici.
  - `setupFloatingWindows()`: abilitazione del trascinamento fluido (drag & drop mouse e touch) con coordinate relative per la Finestra Mani, la Finestra Statistiche e l'Editor Custom. Sincronizzazione dei pulsanti di chiusura ("×") con le relative checkbox della toolbar.
  - `setupTypingListeners()`: intercettazione globale di `keydown` con inoltro a `TypingEngine`, calcolo in tempo reale di battute al minuto (BPM), parole al minuto (WPM), accuratezza (%) ed errori.
- **Implementazione di `keyBlinkTarget` (*BlinkTimer* fedele a C#)**:
  - Introdotta animazione CSS pulsante a frequenza calibrata (~300 ms) sul tasto bersaglio:
    ```css
    @keyframes keyBlinkTarget {
      0%, 100% { fill: #ef4444; filter: drop-shadow(0 0 12px rgba(239, 68, 68, 0.95)); }
      50% { fill: #b91c1c; filter: drop-shadow(0 0 4px rgba(185, 28, 28, 0.6)); }
    }
    .key.active-target .key-bg {
      stroke: #ffffff !important;
      stroke-width: 2.8 !important;
      animation: keyBlinkTarget 0.6s infinite ease-in-out;
    }
    ```

---

### 3.2 Raffinamento Grafico, Ergonomia UI e Strumenti Statistici (Versione 1.2)

#### 3.2.1 Riga Guida Unica e Continua (`updateOriginDisplay`)
Nella versione 1.1, il rendering del testo suggerito spezzava la frase in tre righe sovrapposte a causa della regola `white-space: pre-wrap;` combinata con ritorni a capo involontari nei template literal JavaScript.  
**Soluzione**: il testo viene concatenato in stringa pura priva di spazi spuri con `display: inline !important;` e `box-decoration-break: clone;`, consentendo alle porzioni verde (digitato), azzurro (bersaglio) e grigio (rimanente) di fluire naturalmente su una sola riga continua con a-capo automatico standard.

#### 3.2.2 Puntamento Dinamico Verticale del Badge Rosso d'Errore
Nella v.1.1, il badge rosso indicante il carattere errato premuto appariva fisso in alto a sinistra.  
**Soluzione**: nel metodo `showWrongLetterPopup(wrongChar)` vengono rilevate le coordinate dinamiche dell'elemento `#charTarget` tramite `targetSpan.getBoundingClientRect()` rispetto al contenitore padre `.typing-box-container`. Il badge viene proiettato direttamente sulla verticale della lettera bersaglio blu, a una distanza di sicurezza superiore (con freccetta indicatrice CSS `:after`), garantendo la contemporanea leggibilità di entrambi i caratteri.

#### 3.2.3 Scorciatoie Universali per la Guida (`CTRL+SHIFT+H` ed `F1`)
Per aggirare il blocco popup integrato nei moderni browser contro le chiamate dirette a `window.open()`, l'attivazione della guida è stata collegata all'evento nativo di click sull'elemento ancora:
```javascript
const helpBtn = document.getElementById("btnHelpLink");
if (helpBtn) helpBtn.click();
```

#### 3.2.4 Finestra Statistiche Ridimensionabile a 8 Vie con Persistenza e Schermo Intero
- **Maniglie a 8 direzioni**: Inserite maniglie CSS dedicate (`.rh-n`, `.rh-s`, `.rh-e`, `.rh-w`, `.rh-ne`, `.rh-nw`, `.rh-se`, `.rh-sw`) gestite tramite il metodo `makeResizable()` in `WindowManager`.
- **Pulsante Schermo Intero (`btnStatMaximize`)**: Commuta la finestra a visualizzazione estesa (100vw × 100vh) memorizzando le dimensioni precedenti per il ripristino.
- **Pulsante Reset Layout (`btnStatResetLayout`)**: Ripristina istantaneamente le dimensioni (840×620 px) e la centratura di fabbrica.
- **Persistenza**: Le coordinate (`StatLeft`, `StatTop`) e le dimensioni (`StatWidth`, `StatHeight`) vengono registrate nel profilo dell'utente su `localStorage` a ogni ridimensionamento.

#### 3.2.5 Selezione ad Area Drag-to-Select sul Grafico Cartesiano di Velocità
- Aggiunto rettangolo SVG semitrasparente `#chartSelectionRect` con contorno tratteggiato azzurro.
- Il trascinamento del mouse evidenzia l'intervallo temporale di campioni, ingrandendone i nodi grafici con colore ambra (`#f59e0b`).
- La label `lblMediaValori` calcola e mostra in tempo reale la velocità media ristretta ai soli campioni inclusi nell'area selezionata.
- **Pulsante `🗑 Elimina Selezionati` (`btnClearSelection`)**: Rimuove definitivamente dall'archivio i campioni selezionati previa finestra modale di conferma con conteggio dettagliato.
- **Pulsante `✂ Elimina Non Selezionati` (`btnClearNotSelected`)**: Rimuove tutti i campioni esterni alla selezione conservando unicamente quelli scelti dall'utente, previa conferma dettagliata di sicurezza.

---

### 3.3 Esercizi Custom, Feedback Tasti Speciali e Centratura Mani (Versione 1.3)

#### 3.3.1 Integrazione Diretta delle Lezioni Custom nel Menu a Tendina
- **Parser di Esercizi**: La funzione `parseCustomExercises(rawText)` individua le intestazioni delimitate da sintassi `===== Titolo =====` estraendo titolo, frasi e paragrafi multilinea.
- **Popolamento Immediato**: Sia il click su **"Salva nel Profilo"** (`btnCustomSave`) sia il **Caricamento file `.txt`** (`customFileInput`) analizzano il testo, popolano l'array `this.customLessons` e aggiornano istantaneamente il selettore `cboLessons`.
- **Pulsante Commutazione Sorgente (`btnToggleLessonSource`)**: Collocato nella toolbar accanto al menu delle lezioni, consente di alternare istantaneamente tra le 70 lezioni propedeutiche standard e le lezioni personalizzate caricate.

#### 3.3.2 Supporto Digitazione Multilinea con Tasti Invio (`®`) e Tab (`→`)
- **Tasto Invio (Return / A capo)**:
  - Codificato internamente con `®` (visualizzato come `↵` e badge *"INVIO ↵"*).
  - Associato al **mignolo destro (dito 10)** e al tasto virtuale `key_enter`.
- **Tasto Tabulazione (Tab / Rientro)**:
  - Codificato internamente con `→` (visualizzato come `⇥` e badge *"TAB ⇥"*).
  - Associato al **mignolo sinistro (dito 1)** e al tasto virtuale `key_tab`.
- **Gestione Eventi**: In `setupTypingListeners()`, gli eventi `keydown` per `Tab` ed `Enter` intercettano e sopprimono l'azione nativa del browser (`e.preventDefault()`), garantendo digitazione continua senza perdita di focus.

#### 3.3.3 Illuminazione Azzurra alla Pressione di Tasti Funzione e Speciali
Il metodo `VisualRenderer.flashPressedKey(keyName, code, location)` associa l'evento fisico ai corrispettivi elementi SVG della tastiera virtuale:
- `Tab` -> `#key_tab`
- `CapsLock` -> `#key_caps`
- `Shift` -> `#key_shift_l` o `#key_shift_r` (in base a `location` o `code`)
- `Control` -> `#key_ctrl_l` o `#key_ctrl_r`
- `Alt` -> `#key_alt_l`
- `AltGraph` -> `#key_altgr`
- `Meta / Windows` -> `#key_win_l` o `#key_win_r`
- `Backspace` -> `#key_backspace`
- `Enter` -> `#key_enter`
- `ContextMenu` -> `#key_menu`

L'elemento riceve la classe CSS `.key-pressed` (sfondo azzurro tenue con alone di contrasto) per una durata calibrata di 180 ms.

#### 3.3.4 Trattamento come Errore della Pressione Fuori Luogo
La pressione ingiustificata di tasti speciali durante la scrittura (es. pressione di Tab, Invio, CapsLock, Ctrl, Alt o Menu quando l'esercizio richiede un altro carattere) produce:
1. Emissione del suono d'errore (audio sintetizzatore Web Audio);
2. Incremento del contatore errori (`countErrors`) e ricalcolo percentuale accuratezza;
3. Proiezione del badge rosso fluttuante sopra la lettera bersaglio con il nome descrittivo del tasto premuto (es. *CAPS LOCK*, *TAB*, *INVIO*, *CTRL*, *ALT*, *BACKSPACE*).
I tasti modificatori solitari (`Shift` e `AltGr`), premuti come prefisso per digitare lettere maiuscole o simboli terziari, non generano falso errore prima della digitazione del carattere associato.

#### 3.3.5 Correzione Grafica Anatomica del Palmo delle Mani SVG
Nel file `index_(v.1.3).html`, all'interno dei due gruppi SVG `#leftHand` e `#rightHand`, i vettori del palmo sono stati riallineati lateralmente verso i rispettivi mignoli per compensare il disassamento originario:
- Mano Sinistra: `<path class="palm" transform="translate(-12, 0)" ... />`
- Mano Destra: `<path class="palm" transform="translate(12, 0)" ... />`
Le etichette descrittive testuali sono state centrate coerentemente per offrire un perfetto bilanciamento estetico e anatomico.

---

## 4. Matrice Completa dei Collaudi E2E (Google Chrome Headless via CDP)

Tutte le funzionalità sono state convalidate mediante script automatici di collaudo end-to-end eseguiti su motore Google Chrome Headless via Chrome DevTools Protocol (CDP):

| # | Funzionalità Verificata | Risultato | Dettaglio Collaudo |
|:---:|---|:---:|---|
| **1** | Sintassi JavaScript e Inizializzazione | **PASS** | 0 errori di sintassi, `AppController` istanziato, auto-login "ALBERTO" eseguito. |
| **2** | Finestra Mani Fluttuante | **PASS** | Chiusura con "×" e riapertura da checkbox della toolbar sincronizzate. |
| **3** | BlinkTimer su Bersaglio | **PASS** | Animazione CSS `keyBlinkTarget` verificata sul tasto corrente. |
| **4** | Riga Guida a Flusso Continuo | **PASS** | Elementi `<span>` inline concatenati, nessun ritorno a capo parassita. |
| **5** | Puntamento Verticale Badge Errore | **PASS** | Badge centrato su asse X della lettera bersaglio e distanziato a `top: -34px`. |
| **6** | Scorciatoia Guida `CTRL+SHIFT+H` | **PASS** | Attivazione click su ancora nativa con puntamento a `help_(v.1.3).html`. |
| **7** | Maniglie Finestra Statistiche | **PASS** | 8 maniglie attive, ingrandimento a tutto schermo e ripristino verificati. |
| **8** | Selezione Area Grafico di Velocità | **PASS** | Selezione intervallo campioni, calcolo media parziale e bottoni eliminazione operativi. |
| **9** | Centratura Palmi Mani SVG | **PASS** | Traslazioni `translate(-12,0)` e `translate(12,0)` confermate nel DOM SVG. |
| **10** | Illuminazione 10 Tasti Speciali | **PASS** | Classe `.key-pressed` validata su tutti i 10 tasti speciali e modificatori. |
| **11** | Errore Tasto Fuori Luogo | **PASS** | Pressione indebita `CapsLock` incrementa errori a 1 e mostra badge "CAPS LOCK". |
| **12** | Esercizi Custom nel Menu Lezioni | **PASS** | Parsing blocchi `===== Titolo =====`, popolamento `cboLessons` in modalità Custom. |
| **13** | Digitazione Multilinea (Invio e Tab) | **PASS** | Bersaglio `⇥` (dito 1) digitato con Tab; bersaglio `↵` (dito 10) digitato con Invio. |

---

## 5. Elenco dei File e Manutenzione Versioning in `/workspace`

In adempimento alle regole operative, tutti i deliverable sono stati generati con progressione di versione e archiviati in `/workspace`:
- **Versione 1.1**:
  - `index_(v.1.1).html` (253.698 byte)
  - `help_(v.1.1).html` (34.061 byte)
  - `05 - App TypeScript - Avanzamento Porting e Risoluzione Criticita (v.1.1).md`
- **Versione 1.2**:
  - `index_(v.1.2).html` (272.927 byte)
  - `help_(v.1.2).html` (34.294 byte)
  - `06 - App TypeScript - Selezione Grafico, Finestra Ridimensionabile e Rifiniture UI (v.1.2).md`
- **Versione 1.3**:
  - `index_(v.1.3).html` (282.361 byte)
  - `help_(v.1.3).html` (34.265 byte)
  - `07 - App TypeScript - Esercizi Custom, Feedback Tasti Speciali e Centratura Mani (v.1.3).md`
- **Documenti di Chiusura Chat**:
  - `08 - App TypeScript - Documento Conclusivo di Sintesi Tecnica e Specifica Architetturale (v.1.1 - v.1.3).md` (Il presente documento)
  - `09 - FINE CHAT - Documento di Handoff Tecnico (Versione 1.3).md`
