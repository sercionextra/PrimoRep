# Pipeline di Analisi Video YouTube con Sequenza di Prompt (Source Inline Ready)

Questo repository contiene la suite completa di prompt per l'analisi avanzata, la sincronizzazione temporale e la verifica tecnica e visiva di video YouTube e delle relative trascrizioni.

## Acquisizione Variabili tramite Source Inline
Il flusso estrae automaticamente le 3 variabili chiave da un file di testo/markdown caricato come **Source Inline** (es. `INPUT_SOURCE.md`):
- `{{URL}}`: Link del video YouTube.
- `{{LINGUA}}`: Lingua originale del video ("IT" / "EN"). Se "IT", il Prompt 2 viene automaticamente escluso.
- `{{TESTO_ORIGINALE}}`: Trascrizione temporizzata completa del video.

## Struttura dei Prompt e Flusso delle Variabili

| File | Titolo / Funzione | Input | Output / Variabile Prodotta | Condizione / Note |
|---|---|---|---|---|
| `Prompt_N_1.md` | Protocollo Omni-Verifier (Revisione Tecnica) | `{{TESTO_ORIGINALE}}` | `{{OUTPUT_PROMPT_1}}` | Verifica data live, fact-checking tool |
| `Prompt_N_2.md` | Traduzione in Italiano con Timestamps | `{{OUTPUT_PROMPT_1}}` | `{{OUTPUT_PROMPT_2}}` | **Condizionale**: eseguito solo se `{{LINGUA}} != IT` |
| `Prompt_N_3.md` | Riformattazione Strutturata e Paragrafi | `{{INPUT_TESTO_PROMPT_3}}` | `{{OUTPUT_PROMPT_3}}` | Orari tra quadre, grassetti, paragrafi |
| `Prompt_N_4.md` | Sfoltimento Timestamp e Revisione Dettagliata | `{{TESTO_INPUT_PROMPT_4}}` | `{{TESTO_REVISIONATO_P4}}` | **Punto cardine**: produce l'input per Prompt 5 e 6 |
| `Prompt_N_5.md` | Protocollo Chronos & Tech (Analisi Avanzata) | `{{TESTO_REVISIONATO_P4}}` | `{{OUTPUT_PROMPT_5}}` | Rielaborazione ad alta granularità |
| `Prompt_N_6.md` | Protocollo Chronos & Vision (Multimodale) | `{{URL}}` + `{{TESTO_REVISIONATO_P4}}` | `{{OUTPUT_PROMPT_6}}` | Analisi visiva OCR frame-by-frame (2 FPS) e audio |

## Gestione File di Output
Tutte le risposte generate dai prompt vengono visualizzate a video e accodate in:
`ANALISI_VIDEO.md`

## Decompressione nel Workspace
```bash
unzip "/new_repository/PROMPT_PER_ANALISI_VIDEO_YOUTUBE.zip" -d /workspace
```
I file saranno estratti nella directory `/workspace/PROMPT_PER_ANALISI_VIDEO_YOUTUBE/`.
