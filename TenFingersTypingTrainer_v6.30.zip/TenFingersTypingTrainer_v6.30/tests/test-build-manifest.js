#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(root, "BUILD_MANIFEST.json"), "utf8"));
const failures = [];

if (manifest.version !== "6.30") failures.push("Versione manifest diversa da 6.30.");
if (!Array.isArray(manifest.externalDependencies) || manifest.externalDependencies.length !== 0) {
  failures.push("Il manifest dichiara dipendenze esterne.");
}
if (manifest.files.length !== manifest.fileCount) failures.push("fileCount non corrisponde al numero di record.");

for (const entry of manifest.files) {
  const fullPath = path.resolve(root, entry.path);
  if (!fullPath.startsWith(root + path.sep)) {
    failures.push(`Percorso fuori dalla release: ${entry.path}`);
    continue;
  }
  if (!fs.existsSync(fullPath)) {
    failures.push(`File mancante: ${entry.path}`);
    continue;
  }
  const bytes = fs.readFileSync(fullPath);
  if (bytes.length !== entry.bytes) failures.push(`Dimensione non coerente: ${entry.path}`);
  const hash = crypto.createHash("sha256").update(bytes).digest("hex");
  if (hash !== entry.sha256) failures.push(`SHA-256 non coerente: ${entry.path}`);
}

if (manifest.files.some((entry) => entry.path === "BUILD_MANIFEST.json")) {
  failures.push("Il manifest non deve includere se stesso nella lista hash.");
}

if (failures.length) {
  console.error(`BUILD MANIFEST FAILED (${failures.length})`);
  failures.forEach((failure) => console.error(`- ${failure}`));
  process.exit(1);
}
console.log(`PASS: ${manifest.files.length} file presenti, dimensioni e SHA-256 verificati.`);
console.log("PASS: nessuna dipendenza esterna dichiarata.");
